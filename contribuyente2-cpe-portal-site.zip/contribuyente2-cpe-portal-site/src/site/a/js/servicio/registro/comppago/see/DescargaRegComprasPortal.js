/**
 * DescargaRegCompPortal.js - JavaScript de RVI.
 * Author: Patricia Chacaliaza
 * Since: 11-03-2013
 * ResponseBean : codeError; messageError; data;
 */
if (!dojo._hasResource["servicio.registro.comppago.see.DescargaRegComprasPortal"]) {
dojo._hasResource["servicio.registro.comppago.see.DescargaRegComprasPortal"] = true;
dojo.provide("servicio.registro.comppago.see.DescargaRegComprasPortal");

  dojo.require("dojox.grid.DataGrid");
  dojo.require("dojox.grid.cells.dijit");
dojo.require("dojo.data.ItemFileWriteStore");
dojo.require("dojo.data.ItemFileReadStore");
dojo.require("dojo.io.iframe");
    dojo.require("dijit.Dialog");

dojo.require("dijit.form.DateTextBox");
			dojo.require("dojox.widget.Standby");
dojo.declare("servicio.registro.comppago.see.DescargaRegComprasPortal", null, {

	
	store: null,
	beanDatosCP: null,
	controller: "descargarRegCompPortal.do",

	otherDocStore: null,
	ptoemiStore: null,	
	
	constructor: function() {},

        initialize: function(){
    		this.content = dijit.byId("content");    		
            this.waitMessage = dijit.byId("waitMessage");
        },
        
        startup: function(){
            dojo.parser.parse(dojo.byId('container'));
            setTimeout(dojo.hitch(this, function(){
                this.hideLoader();
            }), 250);
        },

		
      	initContent: function() {
      	    this.initialize();
             
      		 // dijit.focus(dojo.byId("inicio.periodo"));
      		
      	},
	
	      hideLoader: function(){
            this.initialize();
            var loader = dojo.byId('loader');
            var _this = this;
            dojo.fadeOut({
                node: loader,
                duration: 250,
                onEnd: function(){
                	dijit.byId('content').domNode.style.visibility = "visible";            	
                    loader.style.display = "none";
                }
            }).play();
        },
		
    formatDescarga: function(value,rowindex) {
        var grilla =dijit.byId('rvisGrid');
        var fila = grilla.getItem(rowindex);
        if (fila.ind_registro_rc == "2") {
          return "<a href=\"#\" onclick=\"descargaRegCompPortal.descargarZip('" + rowindex +  "')\"> <img src=\"/a/imagenes/see/icons/download_16p.gif\" /></a>"
        }else{
          return "-";
        }
  	},
	
    formatDescargaRVI: function(value,rowindex) {
        
        
    var grilla =dijit.byId('rvisGrid');
		var fila = grilla.getItem(rowindex);
  		if (fila.ind_movi_vta == "1" ||  fila.ind_movi_vta == "2") {			
  		  return "<a href=\"#\" onclick=\"descargaRegCompPortal.descargarZip('" + rowindex +  "')\"> <img src=\"/a/imagenes/see/icons/download_16p.gif\" /></a>"
        } {
		  return "-";
		}
        
  	},  
    	
   checkMovimientos: function(rowindex,value){
   		if (rowindex == "2") {
				  return "<img src=\"/a/imagenes/see/icons/icon-complete.gif\" />";
			} else {
				  return "NO";
			}
   
   },  
    	
   checkSimplificado: function(rowindex,value){

   		if (rowindex == "1") {
				  return "<img src=\"/a/imagenes/see/icons/icon-complete.gif\" />";
			} else {
				  return "NO";
			}
   
   },  
    	
   checkNoDomiciliado: function(rowindex,value){
      if (rowindex == "1") {
				  return "<img src=\"/a/imagenes/see/icons/icon-complete.gif\" />";
			} else {
				  return "-";
			}
   
   },

   formatDescargaRCP: function(value,rowindex) {
		var grilla =dijit.byId('rvisGrid');
		var fila = grilla.getItem(rowindex);
  		if (fila.ind_movi_rcp == "1" ||  fila.ind_movi_rcp == "2") {			
  		  return "<a href=\"#\" onclick=\"descargaRegCompPortal.descargarZipRCP('" + rowindex +  "')\"> <img src=\"/a/imagenes/see/icons/download_16p.gif\" /></a>"
        } {
		  return "-";
		}
  	},
	
    formatDescargaNoDomiciliado: function(value,rowindex) {
		var grilla =dijit.byId('rvisGrid');
		var fila = grilla.getItem(rowindex);
  		//if (fila.ind_movimientos_nodom == "1") {
		if (fila.ind_movi_cnd == "1" || fila.ind_movi_cnd == "2") {			
  		  return "<a href=\"#\" onclick=\"descargaRegCompPortal.descargarZipND('" + rowindex +  "')\"> <img src=\"/a/imagenes/see/icons/download_16p.gif\" /></a>"
        } {
		  return "-";
		}
  	},
	
    formatDescargaCasillas: function(value,rowindex) {
		//return "<a href=\"#\" onclick=\"descargaRegCompPortal.descargarZipCasillas('" + rowindex +  "')\"> <img src=\"/a/imagenes/see/icons/download_16p.gif\" /></a>"
		var grilla =dijit.byId('rvisGrid');
		var fila = grilla.getItem(rowindex);
		if (fila.uid_casilla != "-") {
			return "<a href=\"#\" onclick=\"descargaRegCompPortal.descargarZipCasillas('" + rowindex +  "')\"> <img src=\"/a/imagenes/see/icons/download_16p.gif\" /></a>"
		} else {
			return "-";
		}
  	},
    
    descargarZip: function(rowindex){
        var grilla =dijit.byId('rvisGrid');
        var fila = grilla.getItem(rowindex);
        //var periodo = grilla.store.getValue(fila, "num_per_regven");
		var periodo = grilla.store.getValue(fila, "numper");
        //var indice = grilla.store.getValue(fila, "uid");
		var indice = grilla.store.getValue(fila, "uid_vta");
        window.open(this.controller + "?action=descargaZip&periodo=" + periodo + "&indice=" + indice );        
    },
	
	descargarZipRCP: function(rowindex){
        var grilla =dijit.byId('rvisGrid');
        var fila = grilla.getItem(rowindex);
        var periodo = grilla.store.getValue(fila, "numper");
        var indice = grilla.store.getValue(fila, "uid_rcp");
        window.open(this.controller + "?action=descargaZip&periodo=" + periodo + "&indice=" + indice );        
    },
	
	descargarZipND: function(rowindex){
        var grilla =dijit.byId('rvisGrid');
        var fila = grilla.getItem(rowindex);
        
        //var periodo = grilla.store.getValue(fila, "num_per_regven");
		var periodo = grilla.store.getValue(fila, "numper");
        //var indice = grilla.store.getValue(fila, "uid");
		var indice = grilla.store.getValue(fila, "uid_cnd");
        window.open(this.controller + "?action=descargaZip&periodo=" + periodo + "&indice=" + indice );        
    },
    
    descargarZipCasillas: function(rowindex){
        var grilla =dijit.byId('rvisGrid');
        var fila = grilla.getItem(rowindex);
        
        var periodo = grilla.store.getValue(fila, "numper");
        var indice = grilla.store.getValue(fila, "uid_casilla");
        window.open(this.controller + "?action=descargaZipCasillas&periodo=" + periodo + "&indice=" + indice );
    },
    
    realizarConsultaFiltro: function(){
      	  var periodoDesde = dijit.byId("filtro.periodoDesde").getValue();
      	  var periodoHasta = dijit.byId("filtro.periodoHasta").getValue();
          if (periodoDesde.length != 7){
                this.iconTooltipMessage("filtro.periodoDesde", "icon-ok-tooltip", "El periodo desde debe tener el formato MM/YYYY.");
                return;
          }
          if (periodoDesde.substring(0,2) != "01" && periodoDesde.substring(0,2) != "02" && periodoDesde.substring(0,2) != "03" &&
              periodoDesde.substring(0,2) != "04" && periodoDesde.substring(0,2) != "05" && periodoDesde.substring(0,2) != "06" &&
              periodoDesde.substring(0,2) != "07" && periodoDesde.substring(0,2) != "08" && periodoDesde.substring(0,2) != "09" &&
              periodoDesde.substring(0,2) != "10" && periodoDesde.substring(0,2) != "11" && periodoDesde.substring(0,2) != "12" ){
                this.iconTooltipMessage("filtro.periodoDesde", "icon-ok-tooltip", "El mes del periodo es inv�lido.");
                return;
          }   
   
          if (periodoHasta.length != 7){
                this.iconTooltipMessage("filtro.periodoHasta", "icon-ok-tooltip", "El periodo hasta debe tener el formato MM/YYYY.");
                return;
          }
          if (periodoHasta.substring(0,2) != "01" && periodoHasta.substring(0,2) != "02" && periodoHasta.substring(0,2) != "03" &&
              periodoHasta.substring(0,2) != "04" && periodoHasta.substring(0,2) != "05" && periodoHasta.substring(0,2) != "06" &&
              periodoHasta.substring(0,2) != "07" && periodoHasta.substring(0,2) != "08" && periodoHasta.substring(0,2) != "09" &&
              periodoHasta.substring(0,2) != "10" && periodoHasta.substring(0,2) != "11" && periodoHasta.substring(0,2) != "12" ){
                this.iconTooltipMessage("filtro.periodoHasta", "icon-ok-tooltip", "El mes del periodo es inv�lido.");
                return;
          }        
      		var periodo1 = dojo.byId("filtro.minPeriodoRCPresentados").value;
      		var periodo2 = dojo.byId("filtro.maxPeriodoRCPresentados").value;
          if (periodoDesde != null && periodoDesde !=""){
              periodoDesde = periodoDesde.substring(3,7) + periodoDesde.substring(0,2);
              if (periodoDesde*1 <  periodo1*1 ){
                this.iconTooltipMessage("filtro.periodoDesde", "icon-ok-tooltip", "El periodo inicial debe ser mayor o igual a " + dojo.byId("filtro.minPeriodoRCPresentados_f").value + " que es el primer RC Portal generado.");
                return;              
              }
          }else{
              periodoDesde = "";
          } 
          if (periodoHasta != null && periodoHasta !=""){
              periodoHasta = periodoHasta.substring(3,7) + periodoHasta.substring(0,2);
              if (periodoHasta*1 >  periodo2*1 ){
                this.iconTooltipMessage("filtro.periodoHasta", "icon-ok-tooltip", "El periodo final debe ser menor o igual a " + dojo.byId("filtro.maxPeriodoRCPresentados_f").value + " que es el �ltimo RC Portal generado.");
                return;              
              }
          }else{
              periodoHasta = "";
          } 
     		
          if (periodoDesde != null && periodoDesde !="" && periodoHasta != null && periodoHasta !=""  ){
              if (periodoHasta<  periodoDesde){
                  this.iconTooltipMessage("filtro.periodoDesde", "icon-ok-tooltip", "El periodo inicial debe ser menor o igual al periodo final");
                  return;                 
                 
              }
          }
          var handler = dojo.xhrGet({
                    url: this.controller + "?action=realizarConsultaFiltro&periodoDesde=" + periodoDesde +"&periodoHasta=" + periodoHasta ,
                    handleAs: "json",
                    sync: true,
                    timeout: 10000
               });    		
    			handler.addCallback(dojo.hitch(this, function(res){
    				//this.waitMessage.hide();
    				if(res.codeError == 0) {

    					//	var data = eval("(" + res.data + ")");						
    						//this.store = new dojo.data.ItemFileWriteStore({data: {identifier: 'id', items: data}});
    			    		var grid = dijit.byId("rvisGrid");
                    var newStore = new dojo.data.ItemFileWriteStore({url: 'descargarRegCompPortal.do?action=getRCPresentados'});
                      grid.setStore(newStore);
					
    				} else {
    					alert(res.messageError);
    				}
    			}));
    			handler.addErrback(dojo.hitch(this, function(res) {
        			this.waitMessage.hide();
    				alert("Ocurrio un error al momento de ejecutar la consulta.");
    			}));
    	},     

  	preventCache: function() {
  		return new Date().valueOf();
  	},
	
  	wait: function(message, width) {
		dojo.byId("waitMessage").innerHTML="<div class='dijitInline box-message'></div><div class='dijitInline'>&nbsp;" + message + "...</div>";
	    dojo.byId("waitMessage").style.width = width;
	    this.waitMessage.show();
	},
	


  	setContentPaneLoading: function(content) {
		this.setContentPaneLoadingBg(content, "ext-el-mask");
	},
	
	iconTooltipMessage: function(node, iconClass, message) {
		if(dojo.isString(node)) node = dojo.byId(node);
		dijit.focus(node);
		node.focus();
		dijit.showTooltip('<div class="' + iconClass + '"><div>' + message + '</div></div>', node, []);
		var blur = dojo.connect(node, "onBlur", function() {
			dijit.hideTooltip(node);
			dojo.disconnect(blur);
		});
	}, 
  	
	setContentPaneLoadingBg: function(content, bg) {
		var size = dojo.marginBox(content.domNode);
		x = Math.floor((size.w - 102)/2);
		y = Math.floor((size.h - 34)/2);
		content.loadingMessage = 
		'<div class="' + bg + '"></div>' +
		'<div class="ext-el-mask-msg x-mask-loading" style="left: ' + x + 'px; top: ' + y + 'px;"><div>Cargando...</div></div>';
	},
     showHiddenDiv: function(node,show) {
     	if (show == true) { //Mostrar
	       node.style.display = "";
      } else { //Ocultar
        	node.style.display = "none";
     	}
    }
          
});
}
