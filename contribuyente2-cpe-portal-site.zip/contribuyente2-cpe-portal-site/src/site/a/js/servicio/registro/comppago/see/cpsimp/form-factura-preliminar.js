// (function(window, $, _) {
    /*
     * :::: CONTAINERS :::: START
     */
    /*
   	*  :::: CONTAINERS :::: END
   	*/

   	/*
   	*  :::: HELPERS :::: START
   	*/

   	/*
   	*  :::: HELPERS :::: END
   	*/

   	/*
   	*  :::: FUNCTION :::: START
   	*/


   	/*
   	*  :::: FUNCTION :::: END
   	*/

   	/*
   	*  :::: SETUP :::: START
   	*/

    $('.footable').footable();

   	/*
   	*  :::: Form Validate :::: END
   	*/

// })(window, jQuery, _);