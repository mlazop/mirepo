var $txtRuc = $('#txtRuc');	
var $selCodCpe = $('#selCodCpe');	
var $txtSerie = $('#txtSerie');	
var $txtFechaInicio = $('#txtFechaInicio');	
var $txtFechaFin = $('#txtFechaFin');	
var $txtNumeroInicial = $('#txtNumeroInicial');	
var $txtNumeroFin = $('#txtNumeroFin');	
var $formConsulta = $('#formConsulta');	
var $modalPreloader = $('#modalPreloader');
var $btnLimpiar = $('#btnLimpiar');
var $bloqueResultado = $('#bloqueResultado');



$('#btnLimpiar').on('click', function(e) {
									  
	$txtSerie.val("");							  
	$txtFechaInicio.val("");							  
	$txtFechaFin.val("");		
	$selCodCpe.val("00");		
	$txtNumeroInicial.val("");			
	$txtNumeroFin.val("");					
	$formConsulta.find('.error').text('');
	$bloqueResultado.addClass('hidden');
	$txtRuc.prop("readonly", false);
});	

$txtFechaInicio.inputmask("dd/mm/yyyy");
$txtFechaFin.inputmask("dd/mm/yyyy");

   
$(".readonly").on('keydown paste', function(e){
	//e.preventDefault();
});

var tOption="";
$.each(jsonTipoComprobante, function( index, value ) {
									 
	if(value.nombre!='Todos los rangos de contingencia'){								 
		tOption = tOption + " <option value='"+$.trim(value.id) +"'>"+$.trim(value.nombre)+"</option>";
	}
	
});	

$selCodCpe.append(tOption);
$selCodCpe.val("00");	
$bloqueResultado.addClass('hidden');


$formConsulta.validate({
	rules: {
		txtSerie: { required: false,
					validSerieDocRel: { 
									param: ["#selCodCpe"],
									depends: 
									function(element){									
										if($txtSerie.val()!=''){
											return true;
										}else{
											return false;
										}
									}
								}		
		},
		txtNumeroInicial: {
						 validaNumerico: true
						},
		txtNumeroFin: {
						 validaNumerico: true
						},						
		txtFechaInicio: {required: true,
						 validaFormatoFecha: ["#txtFechaInicio"],		
						 comparaSiFechaInicioMenorIgualFechaFin: ["#txtFechaInicio", "#txtFechaFin"]
						},
		txtFechaFin: {  required: true,
						validaFormatoFecha: ["#txtFechaFin"],
						}			
	},
	messages: {
		txtSerie: {
			required: 'Ingrese su Serie',
			validSerieDocRel: 'El formato v&aacute;lido para el n&uacute;mero de serie es 9999'
		},
		txtNumeroInicial: {
			validaNumerico: 'El formato v&aacute;lido para el campo es num&eacute;rico'
		},	
		txtNumeroFin: {
			validaNumerico: 'El formato v&aacute;lido para el campo es num&eacute;rico'
		},			
		txtFechaInicio: {
			required: 'Seleccione fecha de inicio',
			validaFormatoFecha: 'El formato v&aacute;lido para la fecha ingresada tiene que ser "dd/MM/YYYY"',
			comparaSiFechaInicioMenorIgualFechaFin:'El rango de fechas no v&aacute;lido, corrija la fecha ingresada'
		},
		txtFechaFin: {
			required: 'Seleccione fecha de fin',
			validaFormatoFecha: 'El formato v&aacute;lido para la fecha ingresada tiene que ser "dd/MM/YYYY"'			
		}	
	},
	submitHandler: function(form){
		$modalPreloader.modal('show');		
		$bloqueResultado.removeClass('hidden');	
		$modalPreloader.modal('hide');
		consultar(form);
	}
		
});	


function consultar(form){
	
	var json = {txtRuc: $txtRuc.val(),
				selCodCpe: $selCodCpe.val(),
				txtSerie: $txtSerie.val(),
				txtFechaInicio: $txtFechaInicio.val(),
				txtFechaFin: $txtFechaFin.val(),
				txtNumeroInicial: $txtNumeroInicial.val(),
				txtNumeroFin: $txtNumeroFin.val()
				};
	
	var url = 'index.do?action=consultar'; 		

	var result = $.ajax({
		type: "POST",
		url: url,  
		data: json,	
		dataType: "json"
	});
	result.success(function(response) {							
		cargarLista(response.lista);		
	});                          
	result.error(function(xmlHttpRequest, textStatus, errorThrown){
		alert("Hubo un problema, int&eacute;ntelo en unos minutos");						  
	});   
  
}	




function cargarLista(lista){

	var oTable = $("#tblLista").dataTable(

			{
				"iDisplayLength": 10,
				"aLengthMenu": [[5, 10, 25, 50, -1], [5, 10, 25, 50, "Todos"]],
				"responsive": true,
				/*"order": [[ 2, "asc" ]],*/
				"retrieve": true, 
				"bProcessing": true,
				"bFilter": false,
				"bSort": true,
				"bAutoWidth": false,
				"bLengthChange": false, 
				"aaData": lista,// <-- your array of objects
				"oLanguage": {
				"sProcessing":     "Procesando...",
				"sLengthMenu":     "Mostrar _MENU_ registros",
				"sZeroRecords":    "No existen CP relacionados a la consulta",
				"sEmptyTable":     "No existen CP relacionados a la consulta",
				"sInfo":           "Mostrando registros del _START_ al _END_ de un total de _TOTAL_ registros",
				"sInfoEmpty":      "Mostrando registros del 0 al 0 de un total de 0 registros",
				"sInfoThousands":  ",",
				"sLoadingRecords": "Cargando...",
				"oPaginate": {
				"sFirst":    "Primero",
				"sLast":     "�ltimo",
				"sNext":     "Siguiente",
				"sPrevious": "Anterior"
							}
				}, 		
			
				"aoColumns": [
							  { "mData": "fecha_contingencia", sDefaultContent: "-", "sClass":""},
							  //{ "mData": "tipo_cp", sDefaultContent: "-", "sClass":""},			 						 
                              { "mRender": function (data, type, row) {
								 
 								 //console.log("codigo_cp:"+row.codigo_cp);
  								 //console.log("jsonTipoComprobante:"+jsonTipoComprobante);
								 var tipo = buscarValorArray(row.codigo_cp, jsonTipoComprobante);	
								 
								 if(row.estado=='2' ||  row.estado=='02')
								 {
									tipo = tipo + " <span id='marcado'>(Baja)</span>";
								}
								 
								 //console.log("tipo:"+tipo);
                                 return tipo;
                                  
                                 }, sDefaultContent: "-"},							  
							  { "mData": "num_serie_cpe", sDefaultContent: "-", "sClass":""},			 						 
							  { "mData": "num_cpe", sDefaultContent: "-", "sClass":""},
							  { "mData": "receptor", sDefaultContent: "-", "sClass":""},			 						 
							  { "mData": "importe", sDefaultContent: "-", "sClass":""},			 						 
							  { "mData": "moneda", sDefaultContent: "-", "sClass":""}
   							 ]
			 }
			);

	oTable.fnClearTable();
	if(lista.length>0){
		oTable.fnAddData(lista);	
	}

}


//Pantalla flotante de calendario de busqueda de inicio
var $modalDatepickerInicio = $('#modal-datepickerInicio');
var $datepickerInicio = $modalDatepickerInicio.find("#datepickerInicio-placeholder");
var $datepickerHiddenInicio = $modalDatepickerInicio.find("#datepickerInicio-value");
var $btnCloseDatepickerInicio = $modalDatepickerInicio.find('#modal-datepickerInicio-close')

var _CURR_DATE_PICKERInicio = null;
$('.datepickerInicio').on('click', function(e) {
	_CURR_DATE_PICKERInicio = $(e.target);
	$modalDatepickerInicio.modal('show');
});

$datepickerInicio.datepicker({
	language: 'es',
	format: "dd/mm/yyyy",
	// endDate: new Date(),
	endDate: '0d'//,
		//startDate: '-2d'
		//maxDate:'1'
}).on('changeDate', function(e) {
	$datepickerHiddenInicio.val(e.format());
	console.log("clik al seleccionar");
	cerrandoCalendario1();
});

function cerrandoCalendario1(){
	if($datepickerHiddenInicio.val()!=""){
		var selectedDate = $datepickerHiddenInicio.val();
		_CURR_DATE_PICKERInicio.val(selectedDate).trigger('change');
		$datepickerHiddenInicio.val('');
		_CURR_DATE_PICKERInicio = null;
		$modalDatepickerInicio.modal('hide');
	}else{
		alert("Haga click en la fecha deseada");	
	}
}



$btnCloseDatepickerInicio.on('click', function(e) {
	cerrandoCalendario1();
});		

$('#butoncalendar1').on('click', function(e) {
	_CURR_DATE_PICKERInicio = $(".datepickerInicio");
	$modalDatepickerInicio.modal('show');
});	




//Pantalla flotante de calendario de busqueda de fin
var $modalDatepickerFin = $('#modal-datepickerFin');
var $datepickerFin = $modalDatepickerFin.find("#datepickerFin-placeholder");
var $datepickerHiddenFin = $modalDatepickerFin.find("#datepickerFin-value");
var $btnCloseDatepickerFin = $modalDatepickerFin.find('#modal-datepickerFin-close')

var _CURR_DATE_PICKERFin = null;
$('.datepickerFin').on('click', function(e) {
	_CURR_DATE_PICKERFin = $(e.target);
	$modalDatepickerFin.modal('show');
});

$datepickerFin.datepicker({
	// endDate: new Date(),
	//endDate: '0d',
	language: 'es',
	format: "dd/mm/yyyy"
	
		//startDate: '-2d'
		//maxDate:'1'
}).on('changeDate', function(e) {
	$datepickerHiddenFin.val(e.format());
	cerrandoCalendario2();
});


function cerrandoCalendario2(){
	if($datepickerHiddenFin.val()!=""){
		var selectedDate = $datepickerHiddenFin.val();
		_CURR_DATE_PICKERFin.val(selectedDate).trigger('change');
		$datepickerHiddenFin.val('');
		_CURR_DATE_PICKERFin = null;
		$modalDatepickerFin.modal('hide');
	}else{
		alert("Haga click en la fecha deseada");	
	}
}


$btnCloseDatepickerFin.on('click', function(e) {
	cerrandoCalendario2();
});		

$('#butoncalendar2').on('click', function(e) {
	_CURR_DATE_PICKERFin = $(".datepickerFin");
	$modalDatepickerFin.modal('show');
});	


/*
$txtRuc.val("20100055237");	
$txtSerie.val("1111");	
$txtFechaInicio.val("01/08/2018");	
$txtFechaFin.val("08/08/2018");	*/
