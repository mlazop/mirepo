/**
 * GeneracionRVIPortal.js - JavaScript de RVI.
 * Author: Patricia Chacaliaza
 * Since: 03-01-2012
 * ResponseBean : codeError; messageError; data;
 */
if (!dojo._hasResource["servicio.registro.comppago.see.GeneracionRVIPortal"]) {
	dojo._hasResource["servicio.registro.comppago.see.GeneracionRVIPortal"] = true;
	dojo.provide("servicio.registro.comppago.see.GeneracionRVIPortal");
	dojo.require("dojox.grid.DataGrid");
	dojo.require("dojox.grid.cells.dijit");
	dojo.require("dojo.data.ItemFileWriteStore");
	dojo.require("dojo.data.ItemFileReadStore");
	dojo.require("dojo.io.iframe");
	dojo.require("dojox.grid.EnhancedGrid");
	dojo.require("dojox.grid.enhanced.plugins.IndirectSelection");
	dojo.require("dijit.form.DateTextBox");
	dojo.require("dojox.widget.Standby");
	
	dojo.ready(function(){
	   
	});
	
	dojo.declare("servicio.registro.comppago.see.GeneracionRVIPortal", null, {
	
	store: null,
	beanDatosCP: null,
	controller: "regvtasing.do",

	otherDocStore: null,
	ptoemiStore: null,	
	marcados : false,
	constructor: function() {},

	initialize: function() {
		this.content = dijit.byId("content");
		this.setContentPaneLoading(this.content);
		this.dialogHistorial =  dijit.byId("dialogHistorial");
		this.dialogTC =  dijit.byId("dialogTipoDeCambio");
		this.waitMessage = dijit.byId("waitMessage");

		var size = dojo.marginBox(this.content.domNode);
		x = Math.floor((size.w - 102)/2);
		y = Math.floor((size.h - 34)/2);

		this.content.loadingMessage = 
		'<div class="ext-el-mask-msg x-mask-loading" style="left: ' + x + 'px; top: ' + y + 'px;"><div>Cargando...</div></div>';		
	},

		
	initContent: function() {
	    this.initialize();
       
		 // dijit.focus(dojo.byId("inicio.periodo"));
		
	},
	
   
	//funciones para eventos
    startup: function(){
    	  dojo.parser.parse(dojo.byId('container'));
    	  setTimeout(dojo.hitch(this, function(){
		   this.initialize();
    	  }), 250);

    },    

    salirPrelimRVIConMovim: function(){
              this.content.setHref(this.controller + "?action=mostrarInicial" + "&preventCache=" + this.preventCache() );	
    },

    salirPrelimRVISinMovim: function(){
              this.content.setHref(this.controller + "?action=mostrarInicial" + "&preventCache=" + this.preventCache() );	
    },
    
    salirInicial: function(){
              this.content.setHref(this.controller + "?action=mostrarInicial" + "&preventCache=" + this.preventCache() );	
    },
    
    validateAcceptTerminos: function(){
          var acepta = dijit.byId("condiciones.cbTerminos");
          if (!acepta.getValue()) {
              alert("Debe aceptar las condiciones.");
              //this.messageBoxError("Debe aceptar las condiciones.","icon-alert-warn");
              return;
          }
                  this.content.setHref(this.controller + "?action=mostrarInicial2");
      },
  
      validacionRVILibre: function(){
      
       dijit.hideTooltip(dojo.byId("inicioRVI.periodoRegistroVentasConMovim"));
     var periodo =  dijit.byId("inicioRVI.periodoRegistroVentasConMovim" ).getValue().substring(3,7) + dijit.byId("inicioRVI.periodoRegistroVentasConMovim" ).getValue().substring(0,2);
          		var periodoRVI = dijit.byId("inicioRVI.periodoRegistroVentasConMovim" ).getValue();
          		    if (periodoRVI.length != 7){
                        this.iconTooltipMessage("inicioRVI.periodoRegistroVentasConMovim", "icon-ok-tooltip", "El periodo debe tener el formato MM/YYYY.");
                        return;
                  }
                  if (periodoRVI.substring(0,2) != "01" && periodoRVI.substring(0,2) != "02" && periodoRVI.substring(0,2) != "03" &&
                      periodoRVI.substring(0,2) != "04" && periodoRVI.substring(0,2) != "05" && periodoRVI.substring(0,2) != "06" &&
                      periodoRVI.substring(0,2) != "07" && periodoRVI.substring(0,2) != "08" && periodoRVI.substring(0,2) != "09" &&
                      periodoRVI.substring(0,2) != "10" && periodoRVI.substring(0,2) != "11" && periodoRVI.substring(0,2) != "12" ){
                        this.iconTooltipMessage("inicioRVI.periodoRegistroVentasConMovim", "icon-ok-tooltip", "El mes del periodo es inv�lido.");
                        return;
                  } 
              var periodoActual  = dojo.date.locale.format(new Date(), {datePattern: "yyyyMM", selector: "date"});
              if (periodo > periodoActual){
                  this.iconTooltipMessage("inicioRVI.periodoRegistroVentasConMovim", "icon-ok-tooltip", "Periodo no puede ser mayor al actual.");
                  return;
              }      		
  
               if (periodo < 201304){
                  //pase 00051
                  this.iconTooltipMessage("inicioRVI.periodoRegistroVentasConMovim", "icon-ok-tooltip", "Periodo no puede ser menor a 04/2013.");
                  return;
              } 
            var handler = dojo.xhrGet({
              url: this.controller + "?action=validaExisteRVIGenerados&perIni=" + periodo + "&perFin=" + periodo,
              handleAs: "json",
		         	preventCache: true,
              sync: true,
              timeout: 10000
            }); 

      		
    			handler.addCallback(dojo.hitch(this, function(res){
    				this.waitMessage.hide();
    				if(res.codeError == 0) {
                var periodoSeleccionado = dojo.byId("inicioRVI.periodoRegistroVentasConMovim").value.substring(3,7)+ dojo.byId("inicioRVI.periodoRegistroVentasConMovim").value.substring(0,2);
      
                 this.content.setHref(this.controller + "?action=mostrarInicial3" + "&preventCache=" + this.preventCache() + "&periodoSeleccionado=" + periodoSeleccionado);	

    				} else {
    					alert(res.messageError);
    					return;
    				}
    			}));
    			handler.addErrback(dojo.hitch(this, function(res) {
        			this.waitMessage.hide();
    				alert("Ocurrio un error al momento de ejecutar la consulta.");
    				return;
    			}));
  
  
    },
    
    generarRvi: function(){
    
        if(dojo.byId("inicio.periodoRegistroVentas").value == "") {
    			alert("Debe seleccionar un periodo.");
    			return;
    		}
        //var periodoSeleccionado = dojo.byId("inicio.periodoRegistroVentas").value;
        var periodoSeleccionado = dojo.byId("inicio.periodoRegistroVentas").value.substring(3,7)+ dojo.byId("inicio.periodoRegistroVentas").value.substring(0,2);
      
        this.content.setHref(this.controller + "?action=mostrarInicial2" + "&preventCache=" + this.preventCache() + "&periodoSeleccionado=" + periodoSeleccionado);	
    },
    
   getValorOpcionSinMovim: function() {
		var valRet="";		
		for(i = 0; i < 2; i++) {
			if(dijit.byId("inicioRVI.opcRVIVacio" + i).getValue() != false) {
				valRet = dijit.byId("inicioRVI.opcRVIVacio" + i).getValue()
			}
		}
		return valRet;
	},  
    
  getValorOpcionSimplificado: function() {
		var valSimp="";		
		for(i = 0; i < 2; i++) {
		  if(dojo.byId("inicioRVI.opcSimp" + i).checked == true) {
				valSimp = dijit.byId("inicioRVI.opcSimp" + i).getValue()
			}
		}
		return valSimp;
	},
	
	  getValorOpcionSimplificadoSM: function() {
		var valSimpSM="";		
		for(i = 0; i < 2; i++) {
		  if(dojo.byId("inicioRVI.opcSimpSM" + i).checked == true) {
				valSimpSM = dijit.byId("inicioRVI.opcSimpSM" + i).getValue()
			}
		}
		return valSimpSM;
	},
	
    generarPreliminarRvi:function(sinMovimientos){

      //dijit.hideTooltip(dojo.byId("inicioRVI.periodoRegistroVentasSinMovimHasta"));

      if (sinMovimientos == 0){

       		//this.wait("Consultando", "150px");
       		 //var periodo = dojo.byId("inicioRVI.periodoRegistroVentasConMovim").value;
        		var periodo = dojo.byId("inicioRVI.periodoRegistroVentasConMovim").value.substring(3,7)+ dojo.byId("inicioRVI.periodoRegistroVentasConMovim").value.substring(0,2);
          		var periodoRVI = dijit.byId("inicioRVI.periodoRegistroVentasConMovim" ).getValue();
          		    if (periodoRVI.length != 7){
                        this.iconTooltipMessage("inicioRVI.periodoRegistroVentasConMovim", "icon-ok-tooltip", "El periodo debe tener el formato MM/YYYY.");
                        return;
                  }
                  if (periodoRVI.substring(0,2) != "01" && periodoRVI.substring(0,2) != "02" && periodoRVI.substring(0,2) != "03" &&
                      periodoRVI.substring(0,2) != "04" && periodoRVI.substring(0,2) != "05" && periodoRVI.substring(0,2) != "06" &&
                      periodoRVI.substring(0,2) != "07" && periodoRVI.substring(0,2) != "08" && periodoRVI.substring(0,2) != "09" &&
                      periodoRVI.substring(0,2) != "10" && periodoRVI.substring(0,2) != "11" && periodoRVI.substring(0,2) != "12" ){
                        this.iconTooltipMessage("inicioRVI.periodoRegistroVentasConMovim", "icon-ok-tooltip", "El mes del periodo es inv�lido.");
                        return;
                  } 
              var periodoActual  = dojo.date.locale.format(new Date(), {datePattern: "yyyyMM", selector: "date"});
              if (periodo > periodoActual){
                  this.iconTooltipMessage("inicioRVI.periodoRegistroVentasConMovim", "icon-ok-tooltip", "Periodo no puede ser mayor al actual.");
                  return;
              }          		
        		/////////////////////////////////////7
            var handler = dojo.xhrGet({
              url: this.controller + "?action=validaExisteRVIGenerados&perIni=" + periodo + "&perFin=" + periodo,
              handleAs: "json",
		         	preventCache: true,
              sync: true,
              timeout: 100000
            }); 

      		
    			handler.addCallback(dojo.hitch(this, function(res){
    				this.waitMessage.hide();
    				if(res.codeError == 0) {
                    handler = dojo.xhrGet({
                          url: this.controller + "?action=validaCPME&periodo=" + periodo,
                          handleAs: "json",
            		         	preventCache: true,
                          sync: true,
                          timeout: 1990000
                    }); 
        
              		
            			handler.addCallback(dojo.hitch(this, function(res1){
            				this.waitMessage.hide();
              			if(res1.codeError == 0 || res1.codeError == 1) {
              			   if(res1.codeError == 1) {
              			       alert("Debe Registrar el Tipo de Cambio de los Comprobantes de Pago Electr�nicos Portal Emitidos en Moneda Extranjera.");
                       }

                        var opcSimp =this.getValorOpcionSimplificado() ;
              			   if(opcSimp== "1") {
              			       alert("Ud. ha elegido generar el RVI en formato simplificado. De tener informaci�n en sus comprobantes de pago f�sicos o electr�nicos que no cumplan con los requisitos se generar� el formato completo.");
                       }                                      	
        			          //Generamos RVI con Movimientos
                       		  this.content.setHref(this.controller + "?action=generaPreliminarRVIConMovim&periodo=" + periodo + "&opcSimp="+opcSimp);
              		        //
              		    
            				} else {
            					alert(res1.messageError);
            				}
            			}));
            			handler.addErrback(dojo.hitch(this, function(res1) {
                			this.waitMessage.hide();
            				alert("Ocurrio un error al momento de ejecutar la consulta.");
            			}));
    				} else {
    					alert(res.messageError);
    					return;
    				}
    			}));
    			handler.addErrback(dojo.hitch(this, function(res) {
        			this.waitMessage.hide();
    				alert("Ocurrio un error al momento de ejecutar la consulta.");
    				return;
    			}));
    			/////////////////////////////
        		

        
        

    			
    			
      }else{

          var periodoDesde = dojo.byId("inicioRVI.periodoRegistroVentasSinMovimDesde").value.substring(3,7)+ dojo.byId("inicioRVI.periodoRegistroVentasSinMovimDesde").value.substring(0,2);
          //var periodoHasta = dojo.byId("inicioRVI.periodoRegistroVentasSinMovimHasta").value.substring(3,7)+ dojo.byId("inicioRVI.periodoRegistroVentasSinMovimHasta").value.substring(0,2);      
          
          /*
          if (periodoHasta ==  ""){
              this.iconTooltipMessage("inicioRVI.periodoRegistroVentasSinMovimHasta", "icon-ok-tooltip", "Debe registrar el periodo final.");
              return;
          }
          
          if (periodoHasta <  periodoDesde){
              this.iconTooltipMessage("inicioRVI.periodoRegistroVentasSinMovimHasta", "icon-ok-tooltip", "El periodo final debe ser mayor o igual que el inicial.");
              return;
          }  
      */
          		var periodoRVI = dojo.byId("inicioRVI.periodoRegistroVentasSinMovimDesde" ).value;
          		    if (periodoRVI.length != 7){
                        this.iconTooltipMessage("inicioRVI.periodoRegistroVentasSinMovimDesde", "icon-ok-tooltip", "El periodo debe tener el formato MM/YYYY.");
                        return;
                  }
                  if (periodoRVI.substring(0,2) != "01" && periodoRVI.substring(0,2) != "02" && periodoRVI.substring(0,2) != "03" &&
                      periodoRVI.substring(0,2) != "04" && periodoRVI.substring(0,2) != "05" && periodoRVI.substring(0,2) != "06" &&
                      periodoRVI.substring(0,2) != "07" && periodoRVI.substring(0,2) != "08" && periodoRVI.substring(0,2) != "09" &&
                      periodoRVI.substring(0,2) != "10" && periodoRVI.substring(0,2) != "11" && periodoRVI.substring(0,2) != "12" ){
                        this.iconTooltipMessage("inicioRVI.periodoRegistroVentasSinMovimDesde", "icon-ok-tooltip", "El mes del periodo es inv�lido.");
                        return;
                  }           
            var fecHoy = new Date();
            var mesAnterior = fecHoy.setMonth(fecHoy.getMonth()-1);
            var periodoAnterior = dojo.date.locale.format(new Date(mesAnterior), {datePattern: "yyyyMM", selector: "date"});
            if(periodoDesde > periodoAnterior){
               this.iconTooltipMessage("inicioRVI.periodoRegistroVentasSinMovimDesde", "icon-ok-tooltip", "El periodo debe ser menor o igual al periodo anterior al actual.");
               return;
            }   
           
          if (this.getValorOpcionSinMovim() == 0){
              alert("Debe Seleccionar SI en la Pregunta si Desea Generar el Registro de Ventas Electronico Sin Movimientos.")
              return;
          } 
          
          /////////////////////////////////////7
            var handler = dojo.xhrGet({
              url: this.controller + "?action=validaExisteRVIGenerados&perIni=" + periodoDesde + "&perFin=" + periodoDesde,
              handleAs: "json",
		         	preventCache: true,
              sync: true,
              timeout: 10000
            }); 

      		
    			handler.addCallback(dojo.hitch(this, function(res){
    				//this.waitMessage.hide();
    				if(res.codeError == 0) {
               		//this.wait("Consultando", "150px");
                  
                    handler = dojo.xhrGet({
                          url: this.controller + "?action=validaCPPeriodosSinMovim&perIni=" + periodoDesde + "&perFin=" + periodoDesde,
                          handleAs: "json",
            		         	preventCache: true,
                          sync: true,
                          timeout: 10000
                    }); 
        
              		
            			handler.addCallback(dojo.hitch(this, function(res2){
            				//this.waitMessage.hide();
            				if(res2.codeError == 0) {
            				    var opcSimp =this.getValorOpcionSimplificadoSM() ;
              			   if(opcSimp== "1") {
              			       alert("Ud. ha elegido generar el RVI sin movimientos en versi�n simplificado. ");
                       }     
        			          //Generamos RVI sin Movimientos
                       		  this.content.setHref(this.controller + "?action=generaPreliminarRVISinMovim&perIni=" + periodoDesde + "&perFin=" + periodoDesde + "&opcSimp="+opcSimp);
              		        //
            				} else {
            					alert(res2.messageError);
            				}
            			}));
            			handler.addErrback(dojo.hitch(this, function(res2) {
                			//this.waitMessage.hide();
            				alert("Ocurrio un error al momento de ejecutar la consulta.");
            			}));
    				} else {
    					alert(res.messageError);
    					return;
    				}
    			}));
    			handler.addErrback(dojo.hitch(this, function(res) {
        			this.waitMessage.hide();
    				  alert("Ocurrio un error al momento de ejecutar la consulta.");
    				  return;
    			}));
    			/////////////////////////////

			            
            
      }
    },
    
	generarRviSinMovim: function(){
		if (confirm("Confirme que Desea Generar el Registro de Ventas Electronico")) {
			this.wait("Generaci�n del Registro de Ventas Electr�nico en Proceso", "1000px", true);
			
            var handler = dojo.xhrGet({
				url: this.controller + "?action=generaPrelimRVISinMovimFinal",
                handleAs: "json",
    		         	  preventCache: true,
                          sync: true,
                          timeout: 10000
            });
      		
      		handler.addCallback(dojo.hitch(this, function(res){
				this.waitMessage.hide();
      			if(res.codeError == 0) {
  			        //Generamos RVI sin Movimientos
					this.content.setHref(this.controller + "?action=finalTemporalRVI&preventCache=" + this.preventCache());
        		    //
      			} else {
      				alert(res.messageError);
      			}
      		}));
      		handler.addErrback(dojo.hitch(this, function(res) {
          		this.waitMessage.hide();
      			alert("Ocurrio un error al momento de ejecutar la consulta.");
      		}));
		}
    },
    
    capturarTipoDeCambio: function(){
		if(dojo.byId("inicioRVI.periodoRegistroVentasConMovim").value == "") {
    		alert("Debe seleccionar un periodo.");
    		return;
    	}
		//var periodoSeleccionado = dojo.byId("inicioRVI.periodoRegistroVentasConMovim").value;
		//this.wait("Consultando", "150px");
		var periodoSeleccionado = dojo.byId("inicioRVI.periodoRegistroVentasConMovim").value.substring(3,7)+ dojo.byId("inicioRVI.periodoRegistroVentasConMovim").value.substring(0,2);
		
		var handler = dojo.xhrGet({
			url: this.controller + "?action=getTipoDeCambio&periodoSeleccionado=" + periodoSeleccionado,
            handleAs: "json",
            sync: true,
            timeout: 90000
        }); 
        
		handler.addCallback(dojo.hitch(this, function(res){
			this.waitMessage.hide();
			if(res.codeError == 0) {
				var data = eval("(" + res.data + ")");						
				this.store = new dojo.data.ItemFileWriteStore({data: {identifier: 'uid', items: data}});
			    var grid = dijit.byId("CPOtrasMonedasGrid");
				grid.setStore(this.store);
				grid.startup();
				this.dialogTC.show();            	
			} else {
				alert(res.messageError);
			}
		}));
		handler.addErrback(dojo.hitch(this, function(res) {
    		this.waitMessage.hide();
			alert("Ocurrio un error al momento de ejecutar la consulta.");
		}));
    },
    
  	showDialogHistorial: function(rowIndex) {    		
   		this.wait("Consultando", "150px");
		
        var handler = dojo.xhrGet({
			url: this.controller + "?action=getHistorial",
            handleAs: "json",
		   	preventCache: true,
            sync: true,
            timeout: 10000
        }); 
        
		handler.addCallback(dojo.hitch(this, function(res){
			this.waitMessage.hide();
			if(res.codeError == 0) {
      			var data = eval("(" + res.data + ")");			
      			this.store = new dojo.data.ItemFileWriteStore({data: {identifier: 'id', items: data}});
      		   	var grid = dijit.byId("historialRVIPresentadosGrid");
      			grid.setStore(this.store);
      			grid.startup();
      			this.dialogHistorial.show();		
			} else {
				alert(res.messageError);
			}
		}));
		
		handler.addErrback(dojo.hitch(this, function(res) {
    		this.waitMessage.hide();
			alert("Ocurrio un error al momento de ejecutar la consulta.");
		}));  
  	},
  	
  	salirHistorico:function(){
  	   this.dialogHistorial.hide();
    },
  	
  	salirTC:function(){
  	   if (confirm("Desea Salir de la Captura de Tipo de Cambio?")){
  	     this.dialogTC.hide();
  	   }
    },
    
    registrarTC:function(){
		//var periodoSeleccionado = dojo.byId("inicioRVI.periodoRegistroVentasConMovim").value;
		var periodoSeleccionado = dojo.byId("inicioRVI.periodoRegistroVentasConMovim").value.substring(3,7)+ dojo.byId("inicioRVI.periodoRegistroVentasConMovim").value.substring(0,2);
      
		var grilla =dijit.byId('CPOtrasMonedasGrid');
		var datos =grilla.store._arrayOfAllItems;
		var filas = grilla.store._arrayOfAllItems.length;
		var numSeleccionados=0;
		var numNoGrabadosConCheck=0;
		var numGrabadosCambiados=0;
		var data ="[";
		for (i=0; i< filas;i++){
			var fila = grilla.getItem(i);
			var valorCheck = grilla.store.getValue(fila, "ind_confirma");
			if (valorCheck==true){
				if ( grilla.store.getValue(fila, "tipo_cambio") ==" "  || grilla.store.getValue(fila, "tipo_cambio") =="" || grilla.store.getValue(fila, "tipo_cambio") == null  || grilla.store.getValue(fila, "fec_nacim_obliga") ==" " || grilla.store.getValue(fila, "fec_nacim_obliga") =="" || grilla.store.getValue(fila, "fec_nacim_obliga") ==null){
					alert("Si confirma un Tipo de cambio debe registrar el monto de tipo de cambio y la fecha de nacimiento de la obligacion");
					return;
				}
                        
				if ( grilla.store.getValue(fila, "tipo_cambio") > 99.994  ){
					alert("El tipo de cambio no puede ser mayor a 99.994");
					return;
				}
				numSeleccionados ++;
				var indGrabado = grilla.store.getValue(fila, "ind_grabado");
				var fec_nacim_obliga = dojo.date.locale.format( new Date(grilla.store.getValue(fila, "fec_nacim_obliga")) , {datePattern: "MM/dd/yyyy", selector: "date"});
				if (indGrabado == "0"  ){
					numNoGrabadosConCheck++;
                
                if (data.length > 1){ data = data +",";}
				data = data + "{uid:'" +grilla.store.getValue(fila, "uid") +"'," +
							  "ind_grabado:'" +indGrabado +"'," +
							  "origen:'" +grilla.store.getValue(fila, "origen") +"'," +
							  "cod_cp:'" +grilla.store.getValue(fila, "cod_cp")  +"'," +
							  "num_serie_cp:'" +grilla.store.getValue(fila, "num_serie_cp")  +"'," +
							  "num_cp:'" +grilla.store.getValue(fila, "num_cp")  +"'," +
							  "id_cp:'" +grilla.store.getValue(fila, "id_cp")  +"'," +
							  "tipo_cambio:'" +grilla.store.getValue(fila, "tipo_cambio") +"'," +
							  "fec_nacim_obliga:'" +fec_nacim_obliga+"'}";              
				}
				if (indGrabado == "1"  ){
					var tcOriginal = grilla.store.getValue(fila, "tipo_cambio_orig");
					var tc= grilla.store.getValue(fila, "tipo_cambio");
					var fecNacimObligOrig = grilla.store.getValue(fila, "fec_nacim_obliga_orig");
					var fecNacimOblig = grilla.store.getValue(fila, "fec_nacim_obliga");  
					
					if ( ( tcOriginal != tc) || (fecNacimObligOrig != fecNacimOblig)){
						numGrabadosCambiados++;
						if (data.length > 1){ data = data +",";}
						data = data + "{uid:'" +grilla.store.getValue(fila, "uid") +"'," +
									  "ind_grabado:'" +indGrabado +"'," +
									  "origen:'" +grilla.store.getValue(fila, "origen") +"'," +
									  "cod_cp:'" +grilla.store.getValue(fila, "cod_cp")  +"'," +
									  "num_serie_cp:'" +grilla.store.getValue(fila, "num_serie_cp")  +"'," +
									  "num_cp:'" +grilla.store.getValue(fila, "num_cp")  +"'," +
									  "id_cp:'" +grilla.store.getValue(fila, "id_cp")  +"'," +
									  "tipo_cambio:'" +grilla.store.getValue(fila, "tipo_cambio") +"'," +
									  "fec_nacim_obliga:'" +fec_nacim_obliga +"'}";                       
					}
				}
			}
		}
		data = data + "]";
		
		if (numSeleccionados == 0){
			alert("No se ha confirmado ningun tipo de cambio.");
			return;
		}else{
			if (numNoGrabadosConCheck == 0 && numGrabadosCambiados==0 ){
				alert("No se ha confirmado ningun tipo de cambio.");
				return;
			}
		}
		
		var this2 = this;
		
		// \xe1   == �
		if (confirm("\xbfDesea Registrar el(los) Tipo(s) de Cambio Confirmado(s)?")){
			this.wait(" Registro de Tipo de Cambio en proceso ", "1000px");
			var contentData = {
				periodoSeleccionado: periodoSeleccionado,
				items: data
			};
			
			dojo.xhrPost({
				url: this.controller + "?action=registrarTC",
				content: contentData,
				handleAs: "json",
				preventCache:true,
				load: function(response, ioArgs) {
					this2.waitMessage.hide();
					if (response.codeError == 0) {
						var dataResp = eval("(" + response.data + ")");						
						this2.store = new dojo.data.ItemFileWriteStore({data: {identifier: 'uid', items: dataResp}});
						var grid = dijit.byId("CPOtrasMonedasGrid");
						grid.setStore(this2.store);
						alert("Los tipo de cambio han sido registrados satisfactoriamente.");
						grid.startup();
					}
					else {
						alert("Problemas al grabar los TC:" + response.messageError);
					}					
				},
				error: function(error, ioArgs) {
					this2.waitMessage.hide();
					alert("Problemas al conectarse con el servidor");
					document.getElementById("divFormTipoCambio").disabled = false;
				}
			});
			
			/*
			var handler = dojo.xhrGet({
                url: this.controller + "?action=registrarTC&periodoSeleccionado=" + periodoSeleccionado + "&items=" +data,
                handleAs: "json",
                sync: true,
                timeout: 30000
            });
			
            handler.addCallback(dojo.hitch(this, function(res){
				if (res.codeError == 0) {
        			var dataResp = eval("(" + res.data + ")");						
        			this.store = new dojo.data.ItemFileWriteStore({data: {identifier: 'uid', items: dataResp}});
        		   	var grid = dijit.byId("CPOtrasMonedasGrid");
        			grid.setStore(this.store);
        			alert("Los tipo de cambio han sido registrados satisfactoriamente.");
        			grid.startup();
           		}
          		else {
          			alert("Problemas al grabar los TC:" + res.messageError);
          		}
            }));
        	handler.addErrback(function(res){
				alert("Problemas al conectarse con el servidor");
        	});
			*/
		}
    },
    
  	formatMedioPresenta: function(value) {
			if (value == "1") {
				return "PLE";
			} else {		
         	if (value == "2") {
				    return "SOL";
			    } else {
				    return "";
			    }
			}
		},
		
		formatFecNacOblig: function(value, rowindex) {
		//dd/MM/yyyy
		  if (value!= null){
            return dojo.date.locale.format(new Date(value), {datePattern: "dd/MM/yyyy", selector: "date"});
          }
		},
		
		marcar: function() {
			  var grilla =dijit.byId('CPOtrasMonedasGrid');
        var filas = grilla.store._arrayOfAllItems.length;
        var store = grilla.store;

        for (i=0; i< filas;i++){
          var fila = grilla.getItem(i);
          if (this.marcados == true){ 
            store.setValue(fila, "ind_confirma", false);
          }else{
            store.setValue(fila, "ind_confirma", true);
          }
        }
        this.marcados=(!this.marcados);
        
		},
		
		
		workTipoDeCambio: function(rowindex,object) {
		   if (object!=null){
		          var grilla =dijit.byId('CPOtrasMonedasGrid');
              var fila = grilla.getItem(rowindex);
              var store = grilla.store;
              var tipoCambio =  grilla.store.getValue(fila, "tipo_cambio");
              var ind_confirma = grilla.store.getValue(fila, "ind_confirma");
              var tipoCambioOrig =  grilla.store.getValue(fila, "tipo_cambio_ref");
              //if (grilla.store._onFetchComplete) {return dojo.trim(tipoCambio);}
              if (isNaN(tipoCambio)){
                  grilla.store.setValue(fila, "tipo_cambio","");
                  tipoCambio="";
              }else{
                
                 
                if (tipoCambio != tipoCambioOrig){
                    store.setValue(fila, "ind_confirma", false);
                    store.setValue(fila, "tipo_cambio_ref", tipoCambio);
                }
              }
              return tipoCambio ;
		   }
		},
		
		loadFecNacOblig: function(rowindex,object) {  //item, attribute, oldValue, newValue
       if (object!=null){

              var grilla =dijit.byId('CPOtrasMonedasGrid');
              var fila = grilla.getItem(rowindex);

				      var dato = grilla.store.getValue(fila, "fec_nacim_obliga");
          return dato;
        }
    },
    
    workFecNacOblig: function(rowindex,object) {  //item, attribute, oldValue, newValue
       if (object!=null){

              var grilla =dijit.byId('CPOtrasMonedasGrid');
              var fila = grilla.getItem(rowindex);
              var node = grilla.getCell(9).getHeaderNode(); 
              var store = grilla.store;
              var ind_confirma = grilla.store.getValue(fila, "ind_confirma");
              dijit.hideTooltip(node);  
              
				      var fec_nacim_obliga = grilla.store.getValue(fila, "fec_nacim_obliga");
				      var fec_nacim_obliga_orig = grilla.store.getValue(fila, "fec_nacim_obliga_ref");
              
				      var fec = dojo.date.locale.format(new Date(fec_nacim_obliga), {datePattern: "dd/MM/yyyy"});
				      var fec2 = dojo.date.locale.format(new Date(fec_nacim_obliga_orig), {datePattern: "dd/MM/yyyy"});

              //if(store._loadFinished != true) {return dato;}

              if (fec != fec2){
                  store.setValue(fila, "ind_confirma", false);
                  store.setValue(fila, "tipo_cambio", null);
                  store.setValue(fila, "fec_nacim_obliga_ref", fec_nacim_obliga);
                  //Tenemos que recuperar el tipo de cambio
                  var moneda = grilla.store.getValue(fila, "cod_moneda");
                   
                    var handler = dojo.xhrGet({
                          url: "regvtasing.do?action=obtieneTipoDeCambio&moneda=" + moneda + "&fechaNacObliga=" +  dojo.date.locale.format(new Date(fec_nacim_obliga), {datePattern: "MM-dd-yyyy", selector: "date"}),
                          handleAs: "json",
            		         	preventCache: true,
                          sync: true,
                          timeout: 10000
                    }); 
  		
              			handler.addCallback(dojo.hitch(this, function(res){

              				if(res.codeError == 0) {
                    						var data = eval("(" + res.data + ")");			
                                store.setValue(fila, "tipo_cambio", data);				
              		
              				} else {
              					alert(res.messageError);
              				}
              			}));
              			handler.addErrback(dojo.hitch(this, function(res) {

              				alert("Ocurrio un error al momento de ejecutar la consulta:" + res.messageError);
              			}));
                  /////////////////////////////////////////
              }
              return fec_nacim_obliga ;
        }
    },
    		setCheck: function(rowindex,object, oldValue, newValue){
    		  /* if (object!=null){
    		        alert(oldValue);
    		        alert(newValue);
    		   }*/
        },
   
    descargarTC : function(){
            window.open(this.controller + "?action=imprimirPDFTC" );
    },
    
    generarRviConMovimientos : function(periodo){

            var fecHoy = new Date();

            var periodoActual = dojo.date.locale.format(fecHoy, {datePattern: "yyyyMM", selector: "date"});
            if(periodo >= periodoActual){
              alert("No puede generarse aun el Preliminar del Registro de Ventas Electronico")
              return;
            }   
           if (confirm("Est� Ud. conforme con la informaci�n contenida en el Preliminar del Registro de Ventas Electr�nico.?")){  
           
                if (confirm("Confirme que desea generar el Preliminar del Registro de Ventas Electr�nico")){
                     //this.wait(" Generaci�n del Registro de Ventas electr�nico en Proceso ", "1000px", true);
                     
                     var handler = dojo.xhrGet({
                          url: this.controller + "?action=generaTemporalRVIConMovimFinal",
                          handleAs: "json",
                          sync: true,
                          timeout: 990000
                      });        
                      handler.addCallback(dojo.hitch(this, function(res){
                         this.waitMessage.hide();
                    			if (res.codeError == 0) {
                              this.content.setHref(this.controller + "?action=finalTemporalRVI&preventCache=" + this.preventCache());
                     			}
                    			else {
                    				alert("Problemas al generar el Preliminar del Registro de Ventas:" + res.messageError);
                    			}
                      }));
                			handler.addErrback(dojo.hitch(this, function(res) {
                    			this.waitMessage.hide();
                				alert("Ocurrio un error al momento de ejecutar la consulta.");
                			}));
                }
            }
    },
    
        generarRviConMovimientosSimp : function(periodo){

            var fecHoy = new Date();

            var periodoActual = dojo.date.locale.format(fecHoy, {datePattern: "yyyyMM", selector: "date"});
            if(periodo >= periodoActual){
              alert("No puede generarse aun el Preliminar del Registro de Ventas Electronico")
              return;
            }   
           if (confirm("Est� Ud. conforme con la informaci�n contenida en el Preliminar del Registro de Ventas Electr�nico.?")){  
           
                if (confirm("Confirme que desea generar el Preliminar del Registro de Ventas Electr�nico")){
                     //this.wait(" Generaci�n del Registro de Ventas electr�nico en Proceso ", "1000px", true);
                     
                     var handler = dojo.xhrGet({
                          url: this.controller + "?action=generaTemporalRVIConMovimFinal",
                          handleAs: "json",
                          sync: true,
                          timeout: 990000
                      });        
                      handler.addCallback(dojo.hitch(this, function(res){
                         this.waitMessage.hide();
                    			if (res.codeError == 0) {
                              this.content.setHref(this.controller + "?action=finalTemporalRVI&preventCache=" + this.preventCache());
                     			}
                    			else {
                    				alert("Problemas al generar el Preliminar del Registro de Ventas:" + res.messageError);
                    			}
                      }));
                			handler.addErrback(dojo.hitch(this, function(res) {
                    			this.waitMessage.hide();
                				alert("Ocurrio un error al momento de ejecutar la consulta.");
                			}));
                }
            }
    },
    
    descargarPrelimRviConMovim : function(){
       if (confirm("Confirme la Descarga del Preliminar del Registro de Ventas Electronico.")) {
           window.open(this.controller + "?action=imprimirPDFRVI" );
      }
    
    },
    
    descargarPrelimRviConMovimSimp : function(){
       if (confirm("Confirme la Descarga del Preliminar del Registro de Ventas Electronico Version Simplificada.")) {
           window.open(this.controller + "?action=imprimirPDFRVISimp" );
      }
    
    }, 
    
    descargaZip: function(){
      window.open(this.controller + "?action=descargaZip" );
    },
    
    sendMail: function(){
            var correo = dijit.byId("generada.correoUser");
            if (correo.getValue() == "") {
                alert("Debe consignar el Correo Electronico.");
                return;
            }
 
            var handler = dojo.xhrGet({
                url: this.controller + "?action=enviarCorreo&correoUser=" + correo.getValue(),
                handleAs: "json",
                preventCache: true,
                sync: true,
                timeout: 10000
            });
            handler.addCallback(dojo.hitch(this, function(res){
                if (res.codeError == 0) {
                    //this.messageBoxError("Se envio constancia al buz�n electr�nico.", "icon-alert-warn");
                    alert("Se envio correo electronico.");
                    return;
                }
                else {
                    alert(res.messageError);
                }
            }));
/*
            handler.addErrback(dojo.hitch(this, function(res){
                this.waitMessage.hide();
                alert("Problemas al enviar mail de afiliaci�n.");
            }));
*/
        },
		pause: function(milisec){
		var d = new Date();
		var begin = d.getTime();
		
		while ((d.getTime() - begin ) > milisec){
		// nothing... 
		} 
	},
	 
	preventCache: function() {
		return new Date().valueOf();
  	},
	
	wait: function(message, width) {
		dojo.byId("waitMessage").innerHTML="<img src='/a/imagenes/wait.gif' align='' border='0'><div class='dijitInline box-message'></div><div class='dijitInline'>&nbsp;" + message + "...</div>";
	    dojo.byId("waitMessage").style.width = width;
	    dojo.byId("waitMessage").style.display = "";
	    this.waitMessage.show();
	},

	/*
	wait: function(message, width, elapsed) {
		this.waitMessage.setMessage("<div class='dijitInline box-message'></div><div class='dijitInline'>&nbsp;" + message + "...</div>");
		this.waitMessage.setWidth(width);
		if(elapsed) this.waitMessage.showElapsed(elapsed);
		else this.waitMessage.show()
	},
	*/
	
	  iconTooltipMessage: function(node, iconClass, message) {
  		if(dojo.isString(node)) node = dojo.byId(node);
  		dijit.focus(node);
  		node.focus();
  		dijit.showTooltip('<div class="' + iconClass + '"><div>' + message + '</div></div>', node, []);
  		//node._refreshState();
  		var blur = dojo.connect(node, "onBlur", function() {
  			dijit.hideTooltip(node);
  			//node._refreshState();
  			dojo.disconnect(blur);
  		});
	  },   
  
	  warnTooltipMessage: function(node, message) {
		  this.iconTooltipMessage(node, "icon-warn-tooltip", message);
	  },
	
	  noSort: function(index){ 
		   return false;
	  },
	
	onFocus: function(id){
    var dato = dojo.byId(id).value;
     dijit.byId(id).attr('value',"");	
     dijit.byId(id).attr('value',dojo.trim(dato));	
  },

      roundNumber: function(number, digits) {
                   var multiple = Math.pow(10, digits);
                   var rndedNum = Math.round(number * multiple) / multiple;

                   return rndedNum;
     } ,
  
  	setContentPaneLoading: function(content) {
		this.setContentPaneLoadingBg(content, "ext-el-mask");
	},
	
	setContentPaneLoadingBg: function(content, bg) {
		var size = dojo.marginBox(content.domNode);
		x = Math.floor((size.w - 102)/2);
		y = Math.floor((size.h - 34)/2);
		content.loadingMessage = 
		'<div class="' + bg + '"></div>' +
		'<div class="ext-el-mask-msg x-mask-loading" style="left: ' + x + 'px; top: ' + y + 'px;"><div>Cargando...</div></div>';
	},
     showHiddenDiv: function(node,show) {
     	if (show == true) { //Mostrar
	       node.style.display = "";
      } else { //Ocultar
        	node.style.display = "none";
     	}
    }
          
});
}
