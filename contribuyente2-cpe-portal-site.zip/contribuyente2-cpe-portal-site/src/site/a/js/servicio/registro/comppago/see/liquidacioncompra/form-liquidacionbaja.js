var $txtSerie = $("#txtSerie");
var $txtNumero = $("#txtNumero");
var $btnLiquidacionBaja = $("#btnLiquidacionBaja");
var $btnVolverFactura = $('#btnVolverFactura');
var $btnVolverMenu = $("#btnVolverMenu");
var $btnEnviarCorreo = $("#btnEnviarCorreo");
var $btnNuevaBaja = $("#btnNuevaBaja");
var $btnValidar = $("#btnValidar");
var $formBaja = $("#form-baja");
var $formModalCorreo = $("#form-modal-correo");
var $formModalBaja = $("#form-modal-baja");
var $modalPreloader = $('#modalPreloader');
var $modalCorreo = $("#modal-correo");
var $modalBaja = $("#modal-baja");
//Campos para motivo de baja y envio de correo
var $txtEmail = $('#txtEmail');
var $txtFechaBaja = $("#txtFechaBaja");
var $selMotivoBaja = $("#selMotivoBaja");
var $serie = $("#serie");
var $nro = $("#nro");
var $fecEmision = $('#fecEmision');
var $senior = $("#senior");
var $dni = $("#dni");
var $domicilioVendedor = $('#domicilioVendedor');
var $lugarVenta = $("#lugarVenta");
var $tipoMoneda = $("#tipoMoneda");
var $motivoBaja = $('#motivoBaja');
var $hiddenRucEmisor = $('#rucEmisor');
var $hiddenRazonSocialEmisor = $('#razonSocialEmisor');
var $hiddenNombreComercialEmisor = $('#nombreComercialEmisor');

var _DocumentosRelacionados = [];
var _Vehiculos = [];
var _Items = [];
var pagina ;
var	$tipocpe;
var $esAPP = $("#esAPP").val();
var $fechaSimulacion = $("#fechaSimulacion").val();

//console.log("fechaSimulacion:"+$fechaSimulacion);

$txtSerie.focus();

var isMobile = {
		Android: function() {
			return navigator.userAgent.match(/Android/i);
		},
		BlackBerry: function() {
			return navigator.userAgent.match(/BlackBerry/i);
		},
		iOS: function() {
			return navigator.userAgent.match(/iPhone|iPad|iPod/i);
		},
		Opera: function() {
			return navigator.userAgent.match(/Opera Mini/i);
		},
		Windows: function() {
			return navigator.userAgent.match(/IEMobile/i);
		},
		any: function() {
			return (isMobile.Android() || isMobile.BlackBerry() || isMobile.iOS() || isMobile.Opera() || isMobile.Windows());
		}
	};	
	
	if( isMobile.any() ) //si es movil
	{
	}else{// si no es movil
        
	}
	
	if( isMobile.any() && $esAPP=="1") //si es movil y viene de aplicacion
	{
		pagina = 'bajaliquidacion.htm';
	}else{// si no es movil
		pagina = 'bajaliquidacion.do';
		$btnVolverMenu.addClass('hidden');		
	}	
	
//console.log("$esAPP:"+$esAPP);	
	

var jsonDistritos = (function() {
    var json = null;
    $.ajax({
        async: false,
        global: false,
        url: '/a/js/servicio/registro/comppago/see/liquidacioncompra/json/Distritos.json',
        dataType: 'JSON',
        success: function(data) {
            json = data.distritos;
        }
    });
    return json;
})();

var jsonProvincias = (function() {
    var json = null;
    $.ajax({
        async: false,
        global: false,
        url: '/a/js/servicio/registro/comppago/see/liquidacioncompra/json/Provincias.json',
        dataType: 'JSON',
        success: function(data) {
            json = data.provincias;
        }
    });
    return json;
})();

var jsonDepartamentos = (function() {
    var json = null;
    $.ajax({
        async: false,
        global: false,
        url: '/a/js/servicio/registro/comppago/see/liquidacioncompra/json/Departamentos.json',
        dataType: 'JSON',
        success: function(data) {
            json = data.departamentos;
        }
    });
    return json;
})();

var _tipoBaja = {
    '01': 'Error en los datos del vendedor',
    '02': 'Error en la descripci&oacute;n del bien'
    //'03': 'Otros',
}

var _tipoDocumentoRelacionado = {
    '09': 'Guia de Remisi&oacute;n Remitente',
    '31': 'Guia de Remisi&oacute;n de Transportista',
    'G9': 'Guia de Remisi&oacute;n por Eventos',
    '00': 'Otro documento'
}

var _moneda = {
    'USD': '&dollar;',
    'PEN': 'S/',
    //'EUR': '&euro;',
    'XEU': '&euro;',
    'GBP': '&pound;',
    'JPY': '&yen;',
    'SEK': 'kr',
    'CAD': 'C&dollar;',
    'CHF': 'CHF'
}

var _monedaDescripcion = {
    'PEN': 'SOLES',
    //'EUR': 'EUROS',
    //'XEU': 'EUROS',
    'USD': 'DOLAR AMERICANO'
    /*,
    	'GBP': 'LIBRA ESTERLINA',
    	'JPY': 'YEN',
    	'SEK': 'CORONA SUECA',
    	'CHF': 'FRANCO SUIZO',
    	'CAD': 'DOLAR CANADIENSE'*/
}

var _tipoMedida = {
    '4A': 'BOBINAS',
    'BE': 'FARDO',
    'BG': 'BOLSA',
    'BJ': 'BALDE',
    'BLL': 'BARRILES',
    'BO': 'BOTELLAS',
    'BX': 'CAJA',
    'C62': 'PIEZAS',
    'CA': 'LATAS',
    'CEN': 'CIENTO DE UNIDADES',
    'CJ': 'CONOS',
    'CMK': 'CENTIMETRO CUADRADO',
    'CMQ': 'CENTIMETRO CUBICO',
    'CMT': 'CENTIMETRO LINEAL',
    'CT': 'CARTONES',
    'CY': 'CILINDRO',
    'DR': 'TAMBOR',
    'DZN': 'DOCENA',
    'DZP': 'DOCENA POR 0**6 ',
    'FOT': 'PIES',
    'FTK': 'PIES CUADRADOS',
    'FTQ': 'PIES CUBICOS',
    'GLI': 'GALON INGLES (4,545956L)',
    'GLL': 'US GALON (3,7843 L)',
    'GRM': 'GRAMO',
    'GRO': 'GRUESA',
    'HLT': 'HECTOLITRO',
    'INH': 'PULGADAS',
    'KGM': 'KILOGRAMO',
    'KT': 'KIT',
    'KTM': 'KILOMETRO',
    'KWH': 'KILOVATIO HORA',
    'LBR': 'LIBRAS',
    'LEF': 'HOJA',
    'LTN': 'TONELADA LARGA',
    'LTR': 'LITRO',
    'MGM': 'MILIGRAMOS',
    'MLL': 'MILLARES',
    'MLT': 'MILILITRO',
    'MMK': 'MILIMETRO CUADRADO',
    'MMQ': 'MILIMETRO CUBICO',
    'MMT': 'MILIMETRO ',
    'MTK': 'METRO CUADRADO',
    'MTQ': 'METRO CUBICO',
    'MTR': 'METRO',
    'MWH': 'MEGAWATT HORA',
    'NIU': 'UNIDAD',
    'ONZ': 'ONZAS',
    'PF': 'PALETAS',
    'PG': 'PLACAS ',
    'PK': 'PAQUETE',
    'PR': 'PAR',
    'RM': 'RESMA',
    'SET': 'JUEGO',
    'ST': 'PLIEGO',
    'STN': 'TONELADA CORTA',
    'TNE': 'TONELADAS',
    'TU': 'TUBOS',
    'UM': 'MILLON DE UNIDADES',
    'YDK': 'YARDA CUADRADA',
    'YRD': 'YARDA',
    'ZZ': 'UNIDAD'
}

_.each(_tipoBaja, function(v, k) {
    $('<option/>', {
        value: k
    }).html(v).appendTo($selMotivoBaja);
});


//Inicializando acciones boton	
$btnEnviarCorreo.on('click', function(e) {
    $modalCorreo.modal('show');

});

$btnVolverFactura.on('click', function(e) {
    $('#root-panels').removeClass('hidden')
    $("#panel-preview").addClass('hidden');
	$txtSerie.val("");
	$txtNumero.val("");
	if(habilitarFisico==1){
		$txtSerie.focus();		
	}else{
		$txtNumero.focus();		
		$txtSerie.val("E001");			
	}

});

$btnNuevaBaja.on('click', function(e) {
    $('#root-panels').removeClass('hidden')
    $("#panel-preview").addClass('hidden');
	$txtSerie.val("");
    $txtNumero.val("");
	$selMotivoBaja.val("");	
    //$txtSerie.focus();	
	if(habilitarFisico==1){
		$txtSerie.focus();			
	}else{
		$txtSerie.val("E001");			
		$txtNumero.focus();		
	}	
});

$btnLiquidacionBaja.on('click', function(e) {
    $modalBaja.modal('show');
});

function formatearDocumentos(documentos) {
    _DocumentosRelacionados = [];
    var dataDocumento = [];
    _.each(documentos, function(documento, k) {
        dataDocumento = [];
        dataDocumento["txtSerie"] = documento.num_serie_doc_rel;
        dataDocumento["txtNumero"] = documento.num_doc_rel.trim();
        dataDocumento["selTipoDocumentoRelacionado_val"] = _tipoDocumentoRelacionado[documento.cod_doc_rel];
        _DocumentosRelacionados.push(dataDocumento);
    })
};

function formatearVehiculos(vehiculos) {
    _Vehiculos = [];
    var dataVehiculo = [];
    _.each(vehiculos, function(vehiculo, k) {
        dataVehiculo = [];
        dataVehiculo["txtPlaca"] = vehiculo.num_placa.trim();
        _Vehiculos.push(dataVehiculo);
    })
};

function formatearItems(items) {
    _Items = [];
    var numFilaAct = 0;
    var numFilaAnt = 0;
    var dataItem = [];
    var bandCab;
    var bandDet;
    _.each(items, function(item, k) {
        bandCab = false;
        bandDet = false;
        numFilaAct = item.num_fila_item;
        if (numFilaAnt == 0) {
            bandCab = true;
            bandDet = true;
            numFilaAnt = numFilaAct;
        } else {
            if (numFilaAct == numFilaAnt) {
                bandDet = true;
            } else {
                if (dataItem["txtIGV"] == undefined) {
                    dataItem["txtIGV"] = "0.00";
                }
                _Items.push(dataItem);
                bandCab = true;
                bandDet = true;
                numFilaAnt = numFilaAct;
                numFilaAct = 0;
            }
        }

        if (bandCab) {
            dataItem = [];
            dataItem["txtCantidad"] = item.num_cant_item.toMoney(2);
            dataItem["selUnidadMedida_val"] = _tipoMedida[item.cod_unidad_item.trim()];
            //dataItem["txtCodigo"] = item.cod_detalle_item;
            dataItem["txtDescripcion"] = item.des_detalle_item;
        }
        if (bandDet) {
            switch (item.cod_rubro) {
                case 111:
                    dataItem["txtValorUnitario"] = item.mto_rubro.toMoney(2);
                    break;
				case 310:
                    dataItem["txtCodigo"] = item.des_detalle_rubro;
                    break;
                case 119:
                    dataItem["txtImporte"] = item.mto_rubro.toMoney(2);
                    break;
                case 114:
                    dataItem["txtIGV"] = item.mto_rubro.toMoney(2);
                    break;
            }
        }
    })

    if (dataItem["txtIGV"] == undefined) {
        dataItem["txtIGV"] = "0.00";
    }
    _Items.push(dataItem);
}

function prepararDatosPreview(datos) {
    var cabComp = datos.cabComp;
    var detComp = datos.detComp;
    var detDocumentos = datos.detDocumentos;
    var detRubrosCab = datos.detRubrosCab;
    var detDirecciones = datos.detDirecciones;
    var detVehiculos = datos.detVehiculos;
    var direccionEmisor = "";
    var desUbigeoEmisor = "";
    var direccionVendedor = "";
    var direccionOperacion = "";
    var igvCredito = 0;
    var irRetencion = 0;
	var mtototalventa = 0;
    var subTotalVenta = 0;
    var fecEmision = cabComp.fechaemision.substring(8, 10) + "/" + cabComp.fechaemision.substring(5, 7) + "/" + cabComp.fechaemision.substring(0, 4);

    _.each(detDirecciones, function(direccion, k) {
        switch (direccion.cod_tipo_direccion) {
            case 20:
                direccionEmisor = direccion.des_direccion;
                desUbigeoEmisor = descripcionUbigeo(direccion.cod_ubigeo);
                break;
            case 21:
                direccionVendedor = direccion.des_direccion + " " + descripcionUbigeo(direccion.cod_ubigeo);
                break;
            case 22:
                direccionOperacion = direccion.des_direccion + " " + descripcionUbigeo(direccion.cod_ubigeo);
                break;
        }
    });

    _.each(detRubrosCab, function(cab, k) {
        switch (cab.cod_rubro) {
            case 101:
                subTotalVenta = cab.mto_rubro;
                break;
            case 170:
                mtototalventa = cab.mto_rubro;
                break;				
            case 171:
                igvCredito = cab.mto_rubro;
                break;
            case 172:
                irRetencion = cab.mto_rubro;
                break;
        }
    });

    formatearItems(detComp);
    formatearDocumentos(detDocumentos);
    formatearVehiculos(detVehiculos);

    $serie.val(cabComp.numseriegre);
    $nro.val(cabComp.numgre);
    $fecEmision.val(fecEmision);
    $senior.val(cabComp.nombredestinatario);
    $dni.val(cabComp.numdociderecep);
    $domicilioVendedor.val(direccionVendedor);
    $lugarVenta.val(direccionOperacion);
    $tipoMoneda.val(_monedaDescripcion[cabComp.codmoneda]);
	
	$tipocpe = cabComp.codtipocpe;
	
	var serieNumeroReporte = cabComp.nrogre;
	if(cabComp.numseriegre!="E001"){
		var res = serieNumeroReporte.split("-");		
		res[1] = pad(res[1].trim(), 8, "0"); 
		serieNumeroReporte = res[0]+" - "+res[1];
	}
	
	var tituloVistaPreliminar="";
	if(cabComp.numseriegre!="E001"){//Eletronico		
		tituloVistaPreliminar = "Liquidaci&oacute;n de Compra F&iacute;sica";		
	}else{//fisico	
		tituloVistaPreliminar = "Liquidaci&oacute;n de Compra Electr&oacute;nica";
	}	
	
     var $tipoDocumento = "DNI";
	 var cod_docide_recep = $.trim(cabComp.cod_docide_recep);
	 
	 //console.log("cod_docide_recep:"+cod_docide_recep+":");
	 if(cod_docide_recep=="1"){
		 $tipoDocumento = "DNI";		 
	 }else if(cod_docide_recep=="4"){
		 $tipoDocumento = "Carnet de Extranjeria";		 
	 }else if(cod_docide_recep=="7"){
		 $tipoDocumento = "Pasaporte";		 
	 } 	
	 
	 //console.log("$tipoDocumento:"+$tipoDocumento);
	

    var retObj = {
        preview: {
            titulo: tituloVistaPreliminar
        },
        emisor: {
            ruc: $hiddenRucEmisor.val(),
            tipoDoc: "RUC",
            direccion: direccionEmisor,
            razon_social: $hiddenRazonSocialEmisor.val(),
            nombre_comercial: $hiddenNombreComercialEmisor.val(),
            departamento: desUbigeoEmisor,
            nrogre: serieNumeroReporte
        },
        liquidacion: {
            fecha_emision: fecEmision,
            razon_social: cabComp.nombredestinatario,
			tipo_documento : $tipoDocumento,	
            dni: cabComp.numdociderecep,
            direccion_vendedor: direccionVendedor,
            direccion_operacion: direccionOperacion,
            moneda: cabComp.codmoneda,
            observaciones: cabComp.desobservacion
        },
        resumen: {
            monedaSimbolo: "S/.",
            subTotalVentas: subTotalVenta.toMoney(2),
            anticipos: "0.00",
            valorVenta: subTotalVenta.toMoney(2),
            totalIGV: cabComp.mtototaligv.toMoney(2),
            totalVenta: mtototalventa.toMoney(2),
            totalIGVCredito: igvCredito.toMoney(2),
            totalRetencion: irRetencion.toMoney(2),
            importeNeto: cabComp.mtoimportetotal.toMoney(2)

        },
        documentos_relacionados: _DocumentosRelacionados,
        items: _Items,
        Vehiculos: _Vehiculos
    };

    retObj.liquidacion.moneda_simbolo = encodeURIComponent(_moneda[retObj.liquidacion.moneda]);
    retObj.liquidacion.moneda = _monedaDescripcion[retObj.liquidacion.moneda];
    return retObj;
}

function showPreview() {
    var numSerieCpe = $txtSerie.val();
    var numCpe = $txtNumero.val();
    var url = pagina+"?action=buscarComprobanteLiq";
    var data = {
        numSerieCpe: numSerieCpe,
        numCpe: numCpe
    };
    var datos;
    var codE;
    var codError;
    var msjError;
    var datosFormateados;
    $modalPreloader.modal('show');
    $.post(url, data).done(function(response) {
        datos = response.retorno.datosLiq;
        codError = response.retorno.codError;
        msjError = response.retorno.msj;
        codE = datos.codError;
        if (codError == "1") {
            if (codE == "0") {
                datosFormateados = prepararDatosPreview(datos);
                $.get('liquidacion-xhr.html').done(function(rtext) {
                    
                    $("#serienumero").html("");
                    
                    $('#root-panels').addClass('hidden');
                    $("#panel-preview").removeClass('hidden');
                    $('#btnEnviarCorreo').addClass('hidden');
                    $('#btnNuevaBaja').addClass('hidden');
                    $('#btnLiquidacionBaja').removeClass('hidden');
                    $('#btnVolverFactura').removeClass('hidden');
					var tpl = _.template(rtext);
                    var parsed = tpl(datosFormateados);
					$("#preview-factura").html(parsed).find('table').footable();
                    $modalPreloader.modal('hide');
                });
            }
            if (codE == "1") {
                $modalPreloader.modal('hide');
                //alert('La liquidaci\u00F3n de compra electr\u00F3nica ' + numSerieCpe + '-' + numCpe + ' no encontrado o no existe.');
                bootbox.alert('La liquidaci\u00F3n de compra electr\u00F3nica ' + numSerieCpe + '-' + numCpe + ' no encontrado o no existe.');
				$txtNumero.val("");

            }
            if (codE == "2") {
                $modalPreloader.modal('hide');
                //alert('La liquidaci\u00F3n de compra electr\u00F3nica ' + numSerieCpe + '-' + numCpe + ' ya se encuentra en estado REVERTIDO.');
                bootbox.alert('La liquidaci\u00F3n de compra electr\u00F3nica ' + numSerieCpe + '-' + numCpe + ' ya se encuentra en estado REVERTIDO.');
				$txtNumero.val("");
            }
            if (codE == "3") {
                $modalPreloader.modal('hide');
                //alert('No se puede revertir la liquidaci\u00F3n de compra electr\u00F3nica ' + numSerieCpe + '-' + numCpe + ', el plazo m\u00E1ximo es hasta el noveno d\u00EDa h\u00E1bil del mes siguiente de la fecha de emisi\u00F3n.');
               //alert('No se puede revertir la liquidaci\u00F3n de compra ' + numSerieCpe + '-' + numCpe + ', el plazo m\u00E1ximo es hasta el noveno d\u00EDa h\u00E1bil del mes siguiente de la fecha de emisi\u00F3n.');
			     bootbox.alert('No se puede revertir la liquidaci\u00F3n de compra electr\u00F3nica ' + numSerieCpe + '-' + numCpe + ', Recuerde que el registro se podr\u00E1 realizar como plazo m\u00E1ximo hasta el s\u00E9timo d\u00EDa calendario siguiente de la fecha de emisi\u00F3n.');
				 $txtNumero.val("");
            }
            if (codE == "4") {
                $modalPreloader.modal('hide');
                //alert('La liquidaci\u00F3n de compra electr\u00F3nica ' + numSerieCpe + '-' + numCpe + ' ya se encuentra en estado REVERTIDO.');
                bootbox.alert('No se puede revertir la liquidaci\u00F3n de compra electr\u00F3nica ' + numSerieCpe + '-' + numCpe + ', tiene pagos asociados');
				$txtNumero.val("");
            }
            if (codE == "5") {
                $modalPreloader.modal('hide');
                //alert('La liquidaci\u00F3n de compra electr\u00F3nica ' + numSerieCpe + '-' + numCpe + ' ya se encuentra en estado REVERTIDO.');
                bootbox.alert('No se puede revertir la liquidaci\u00F3n de compra electr\u00F3nica ' + numSerieCpe + '-' + numCpe + ', tiene pagos asociados');
				$txtNumero.val("");
            }if (codE == "6") {
                $modalPreloader.modal('hide');
                //alert('No se puede revertir la liquidaci\u00F3n de compra electr\u00F3nica ' + numSerieCpe + '-' + numCpe + ', el plazo m\u00E1ximo es hasta el noveno d\u00EDa h\u00E1bil del mes siguiente de la fecha de emisi\u00F3n.');
                bootbox.alert('No se puede revertir la liquidaci\u00F3n de compra electr\u00F3nica ' + numSerieCpe + '-' + numCpe + ', Recuerde que la reversi\u00F3nn se podr\u00E1 realizar como plazo m\u00E1ximo hasta el noveno d\u00EDa h\u00E1bil del mes siguiente de la fecha de emisi\u00F3n.');			     
				$txtNumero.val("");
            }if (codE == "7") {
                $modalPreloader.modal('hide');
                //alert('No se puede revertir la liquidaci\u00F3n de compra electr\u00F3nica ' + numSerieCpe + '-' + numCpe + ', el plazo m\u00E1ximo es hasta el noveno d\u00EDa h\u00E1bil del mes siguiente de la fecha de emisi\u00F3n.');
                bootbox.alert('No se puede dar de baja la liquidaci\u00F3n de compra f\u00EDsica ' + numSerieCpe + '-' + numCpe + ', Recuerde que la baja se podr\u00E1 realizar como plazo m\u00E1ximo hasta el noveno d\u00EDa h\u00E1bil del mes siguiente de la fecha de emisi\u00F3n');			     
				$txtNumero.val("");
            }			
			
			
        } else {
            bootbox.alert(msjError);
        }

    }).fail(function(reason) {
        $modalPreloader.modal('hide');
        bootbox.alert('Disculpe, su comprobante no ha podido ser revertido, intentelo nuevamente.');
    });
}

$formBaja.validate(_.extend(window._validatorWallSettings, {
    debug: true,
    rules: {
        txtNumero: {
            required: true,
            maxlength: 8,
            number: true
        }
    },
    messages: {
        txtNumero: {
            required: 'Se debe ingresar el Nro. de documento a revertir',
            maxlength: 'El n&uacute;mero de documento debe ser num&eacute;rico hasta 8 d&iacute;gitos mayor que cero',
            number: "El n&uacute;mero de documento debe ser num&eacute;rico hasta 8 d&iacute;gitos mayor que cero",
        }
    },
    submitHandler: function(form) {
        showPreview();
    }
}));

$formModalBaja.validate(_.extend(window._validatorWallSettings, {
    rules: {
        txtFechaBaja: {
            required: true
        },
        selMotivoBaja: {
            required: true
        }
    },
    messages: {
        txtFechaBaja: {
            required: "Puede ingresar la fecha de emisi&oacute;n hasta 2 d&iacute;as anteriores a la fecha actual"
        },
        selMotivoBaja: {
            required: "Debe ingresar el motivo de la Reversi&oacute;n"
        }
    },
    submitHandler: function(form) {
        //if (!confirm('\u00BFEsta seguro que desea revertir la liquidaci\u00F3n de compra electr\u00F3nica?')) {		
        //if (!confirm('\u00BFEsta seguro que desea revertir la liquidaci\u00F3n de compra?')) {
            //return;
        //}
		
		      bootbox.setLocale("es");  
			  bootbox.confirm({
				message: '\u00BFEsta seguro que desea revertir la liquidaci\u00F3n de compra?',
				closeButton: false,
				buttons: {
				  confirm: {
					label: 'Aceptar',
				  },
				  cancel: {
					label: 'Cancelar',
				  },
				},
				callback: function (result) {
				  if(result){
					$motivoBaja.val(_tipoBaja[$selMotivoBaja.val()]);
					var url = pagina+"?action=bajaComprobanteLiquidacion";
					var data = {
						numSerieCPE: $txtSerie.val(),
						numCPE: $txtNumero.val(),
						fechaBaja: $txtFechaBaja.val(),
						codMotivoBaja: $selMotivoBaja.val(),
						desMotivoBaja: $motivoBaja.val(),
						tipocpe: $tipocpe,
						fechaEmision: $fecEmision.val()
					};

					$.post(url, data).done(function(data) {
						var datos = data.retorno;
						if (datos.codError == "0") {
							bootbox.alert(datos.msj);
						} else {
							var serieNumero = $txtSerie.val() + " - " + $txtNumero.val();
							//alert("Se ha Revertido correctamente la liquidaci\u00F3n de compra electr\u00F3nica " + serieNumero);
							bootbox.alert("Se ha Revertido correctamente la liquidaci\u00F3n de compra electr\u00F3nica " + serieNumero);				
							$modalBaja.modal('hide');
							$('#btnLiquidacionBaja').addClass('hidden');
							$('#btnEnviarCorreo').removeClass('hidden');
							$('#btnNuevaBaja').removeClass('hidden');
							$('#btnVolverFactura').addClass('hidden');
						}
					}).fail(function(reason) {
						bootbox.alert('Disculpe, su comprobante no ha podido ser revertido, intentelo nuevamente.');
					});
				  
				  
				  }
				},
			  });

    }
}));

$formModalCorreo.validate(_.extend(window._validatorWallSettings, {
    debug: false,
    rules: {
        txtEmail: {
            required: true,
            validaEmail: true
        }
    },
    messages: {
        txtEmail: {
            required: 'Verifique su email',
            validaEmail: 'Verifique su email'
        }
    },
    submitHandler: function(form) {
        //alert("Enviando......");
		$modalPreloader.modal('show');
        $modalCorreo.modal('hide');
        var formData = $(form).serializeObject();
        var url = pagina+'?action=enviarCorreoBaja';
        $.ajax({
            method: 'post',
            data: formData,
            url: url,
            success: function(data) {
                bootbox.alert('Envio Satisfactorio');
				$modalPreloader.modal('hide');
            },
            error: function() {
                bootbox.alert('Ocurri\u00F3 un error intentelo en unos minutos');
            }
        });
    }
}));

function descripcionUbigeo(ubigeo) {
    var departamento = "";
    var provincia = "";
    var distrito = "";
    if (ubigeo.length > 0) {
        departamento = buscarGlosa(ubigeo.substring(0, 2), jsonDepartamentos, 0);
        provincia = buscarGlosa(ubigeo.substring(0, 4), jsonProvincias, 0);
        distrito = buscarGlosa(ubigeo.substring(0, 6), jsonDistritos, 0);
    }
    return (departamento + "-" + provincia + "-" + distrito);;
}

function buscarGlosa(id, lstJson, esHTML) {
    var nombre = "";
    $.each(lstJson, function(index, value) {
        if ($.trim(id) == $.trim(value.id)) {
            nombre = $.trim(value.nombre);
            if (esHTML == 0) {
                nombre = nombre.replace('&Ntilde;', '\u00D1');
            }
            return true;
        }
    });
    return nombre;
}

var f = new Date();
var dia = f.getDate();
var mes = f.getMonth() + 1;
var anio = f.getFullYear();
if (dia < 10) dia = "0" + dia;
if (mes < 10) mes = "0" + mes;
var fecha = dia + "/" + mes + "/" + anio;
$txtFechaBaja.val(fecha);






///**********************************************************************************************//
///**********************************************************************************************//
///***********************TERCERA FASE DE LA LIQUIDACI�N ELETR�NIOCA ASOCIAR LIQUIDACION DE PAGO CON ANTICIPO*****************************//
///**********************************************************************************************//
///**********************************************************************************************//
///**********************************************************************************************//


//Emision Electr�nica = 1
//Registro de pagos Fisica  = 2

var $tipoComprobante = $("#tipoComprobante");	
var $labelTituloEmision = $("#labelTituloEmision");

//console.log("tipoEmision:"+$tipoComprobante.val());	

if($tipoComprobante.val()==1){//Eletronico		
	//$labelTituloEmision.text("Reversi\u00F3n/Baja de Liquidaci\u00F3n de Compra");
	$labelTituloEmision.text("Reversi\u00F3n de Liquidaci\u00F3n de Compra electr\u00F3nica");
}else{//fisico	
	//$labelTituloEmision.text("Reversi\u00F3n/Baja de Liquidaci\u00F3n de Compra");
	$labelTituloEmision.text("Reversi\u00F3n de Liquidaci\u00F3n de Compra electr\u00F3nica");
	//$labelTituloEmision.text("Eliminaci\u00F3n de Liquidaci\u00F3n de Compra F\u00EDsica");
}


function pad(input, length, padding) { 
  var str = input + "";
  return (length <= str.length) ? str : pad(padding+str, length, padding);
}


//(((((((((///////////////////////////)))))))))
//(((((((((///////////////////////////)))))))))
//(((((((((///////////////////////////)))))))))
//var f = new Date();

var arrayfechaSimulacion = $fechaSimulacion.split("-");
/*

var dia = f.getDate();
if(dia<10) dia = "0"+dia;
var mes = (f.getMonth() +1);
if(mes<10) mes = "0"+mes;
*/

var fechaActual = arrayfechaSimulacion[0]+""+arrayfechaSimulacion[1]+""+arrayfechaSimulacion[2];
var fechaActual = parseInt(fechaActual);
var fechaInicio = 20200313;
var habilitarFisico = 0;

//console.log("fechaActual:"+fechaActual);
//console.log("fechaInicio:"+fechaInicio);
//console.log("habilitarFisico:"+habilitarFisico);

if(fechaActual<fechaInicio)
{
	habilitarFisico = 1;	
}

if(habilitarFisico==0){
	$txtSerie.attr("readonly","readonly");
	$txtSerie.val("E001");				
}