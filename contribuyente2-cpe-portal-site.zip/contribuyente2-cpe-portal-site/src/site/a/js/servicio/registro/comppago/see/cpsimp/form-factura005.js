/**
* Inicio : Codigo JS para el RUM de www.site24x7.com
*/
var rumMOKey='474534d5c56f1e1ad9cae34f0d4934d7';
(function(){
if(window.performance && window.performance.timing && window.performance.navigation) {
        var site24x7_rum_beacon=document.createElement('script');
        site24x7_rum_beacon.async=true;
        site24x7_rum_beacon.setAttribute('src','//static.site24x7rum.com/beacon/site24x7rum-min.js?appKey='+rumMOKey);
        document.getElementsByTagName('head')[0].appendChild(site24x7_rum_beacon);
}
})(window)
/**
* Fin : Codigo JS para el RUM de www.site24x7.com
*/

 


// (function(window, $, _) {
// <!-- 30/10/2015 04:33 -->

    /*
     * :::: CONTAINERS :::: START
     */
    var $formCatalogo = $("#form-catalogo");
    var $txtRazonSocial = $("#txtRazonSocial");
    var $selTipoDoc = $("#selTipoDocumento");
    var $txtLugarEntrega = $("#txtLugarEntrega");
    var $txtFechaVencimiento = $("#txtFechaVencimiento");
	var $txtFechaEmision = $("#txtFechaEmision");

	var $txtIndicador = $("#txtIndicador");

    var $modalDirecciones = $("#modal-direcciones");
    var $tablaDireccionesReceptor = $modalDirecciones.find("#tabla-direcciones-receptor");
    // PAS20201U210100151
    //tabla-direcciones-emisor
    var $tablaDireccionesEmisor = $modalDirecciones.find("#tabla-direcciones-emisor");

    var $tablaDocumento = $("#tabla-documento-relacionado");
    var $tablaItem = $("#tabla-item");
    var $modalListaDocumentoRelacionado = $("#modal-mostrar-documento-relacionado")
    var $modalListaItems = $("#modal-mostrar-items")
    var $modalDocumentoRelacionado = $("#modal-documento-relacionado")
    var $formModalDocumentoRelacionado = $modalDocumentoRelacionado.find('#form-modal-documento-relacionado');
    var $selTipoDocumentoRelacionado = $formModalDocumentoRelacionado.find('#selTipoDocumentoRelacionado');
    var $txtSerie = $formModalDocumentoRelacionado.find('#txtSerie');

    var $modalItem = $("#modal-item")
    var $formModalItem = $modalItem.find('#form-modal-item');
    var $txtCodigo = $formModalItem.find('#txtCodigo');
    var $txtDescripcion = $formModalItem.find('#txtDescripcion');
    var $selUnidadMedida = $formModalItem.find('#selUnidadMedida');
    var $selTipo = $formModalItem.find('#selTipo');
	var $selTipoIgv = $formModalItem.find('#selTipoIgv');
	var $tasaIGV = $formModalItem.find('#tasaIGV');
    var $txtImporte = $formModalItem.find('#txtImporte');
    var $txtValorUnitario = $formModalItem.find('#txtValorUnitario');
	//var $rdgTipoIgv = $("input:radio[name=rdgTipoIgv]:checked");
	//var $rdgTipoIgv = $formModalItem.find('input[name=rdgTipoIgv]:checked');


    var $btnOpenModalDR = $('#open-modal-documento-relacionado');
    var $btnOpenModalItem = $('#open-modal-item');
    var $btnOpenModalSearch = $('#open-modal-search');
    var $modalSearch = $("#modal-search");
    var $tablaProducto = $modalSearch.find("#tabla-producto");
    var $formSearch = $modalSearch.find('#form-modal-search');
    var $txtProductQuery = $formSearch.find('#product-query');
    var $lblTotalVentaGravado = $('#total-valor-venta-gravado');
    var $lblTotalValorDescuentos = $('#total-valor-descuentos');
    var $lblTotalTotalIGV = $('#total-igv');
    var $lblTotalImporteICBPER= $('#importe-icbper');
    var $lblTotalImporteTotal = $('#importe-total');
    var $modalDatepicker = $('#modal-datepicker');
    var $datepicker = $modalDatepicker.find("#datepicker-placeholder");
    var $datepickerHidden = $modalDatepicker.find("#datepicker-value");
    var $btnCloseDatepicker = $modalDatepicker.find('#modal-datepicker-close');

	var $modalDatepickerEmision = $('#modal-datepicker-emision');
    var $datepickeremision = $modalDatepickerEmision.find("#datepicker-placeholder");
    var $datepickerHiddenEmision = $modalDatepickerEmision.find("#datepicker-value");
    var $btnCloseDatepickerEmision = $modalDatepickerEmision.find('#modal-datepicker-close');

    var $formFacturaDatosReceptor = $('#form-factura-datos-receptor');
    var $formBoletaDatosReceptor = $('#form-boleta-datos-receptor');
    var $RUCField = $('#txtRuc, #txtDocumento');
    var $razonSocial = $('#txtRazonSocial');
    var $btnValidarDatosReceptor = $('#btnValidarDatosReceptor');
    var $btnContinuar = $('#btnContinuarPaso');
    var $modalPreloader = $('#modalPreloader');
    var $direccionFiscal = $('#txtDireccionFiscal');

    var $panelFacturaDatosReceptor = $('#panel-factura-datos-receptor');
    var $panelDatosComprobante = $('#panel-datos-comprobante');
    var $panelDocumentosRelacionados = $('#panel-documentos-relacionados');
    var $panelItems = $('#panel-items');
    var $panelResumen = $('#panel-resumen');

    var $btnMostrarModalDR =  $panelDocumentosRelacionados.find('#btnMostrarModalDR');
    var $btnMostrarModalItems = $panelItems.find('#btnMostrarModalItems');
    var $selMoneda = $panelDatosComprobante.find('#selMoneda');

	var $cambiosFactoringHabilitados =$('#globalcambiosFactoringHabilitados').val();

    //INI-ALB: PAS20201U210100231
    var $panelFormaPago = $('#panel-forma-pago');
    var $panelCredito = $('#panel-credito');
    var $panelRetencion = $('#panel-retencion');
    var $modalDireccionFiscal = $('#modal-direccion-fiscal');
    var $formModalDireccionFiscal = $modalDireccionFiscal.find('#form-modal-direccion-fiscal');
    var $selFormaPago = $panelFormaPago.find('#selFormaPago');
    var $btnMostrarModalRegistrarDireccion = $panelFacturaDatosReceptor.find('#btnMostrarModalRegistrarDireccion');
    //FIN-ALB: PAS20201U210100231

    //INICIO-PAS20201U210100231


    var $formretencion = $("#form-retencion")
    var $txtBaseImponible =$('#txtBaseImponible');
    var $txtPorcentaje =$('#txtPorcentaje');
    var $txtMontoRetencion =$('#txtMontoRetencion');
    var $puedeEmitirRetencion=$('#puedeEmitirRetencion');

    //FIN-PAS20201U210100231



	//INI-OPV: PAS20201U210100231 Variables InfCredito y Cuotas
	//Variables relacionadas a InfCredito PRINCIPAL
	var $modalInfCredito = $("#modal-InfCredito");
	var $btnMostrarModalCredito = $("#btnMostrarModalInfCredito");
	var $formInfCredito = $('#form-credito');
	var $SumaMontoInfCredito=0;
	var $PasoValidacionAntes=true;
	var $ValidacionBtnAgregarCuotas=false;
	//Variables relacionadas a InfCredito MODAL
	var $tablaInfCredito = $("#tabla-InfCredito");
	$tablaInfCredito.footable();
	var _itemEditandoInfCredito=false;
	var _ItemsInfCredito = [];
	//Variable estatica sirve para Saber que columnas van a ser identificadas al momento de renderizar tabla inf CREDITO
	var	_itemSchemaInfCredito = {
		modificar:"Modificar",
		eliminar:"Eliminar",
		numeroCuota:"Numero Cuota",
		montoCuota:"Monto Cuota",
		fechaVencimiento:"Fecha Vencimiento"
	};

	//Variables relacionadas a InfCuotas
	var $modalInfCuotas = $("#modal-InfCuotas");
	var $btnMostrarModalInfCuotas = $("#btnMostrarModalInfCuotas");
	var $formModalInfCuotas = $modalInfCuotas.find('#form-modal-InfCuotas');
	var	$CantidadEditada=0;
	var $ImporteTotal=0;
	//FIN-OPV: PAS20201U210100231-OPV Variables InfCredito y Cuotas

    var $btnPreview = $('#btnPreview');
    var $btnVolverFactura = $('#btnVolverFactura');

    var $hiddenRucEmisor = $("#rucEmisor");
    var $hiddenDireccionEmisor = $("#direccionEmisor");
    var $hiddenRazonSocialEmisor = $("#razonSocialEmisor");


    var $hiddenNombreComercialEmisor = $("#nombreComercialEmisor");
    var $hiddenDepartamentoEmisor = $("#departamentoEmisor");
    var $hiddenNrus = $("#tributoNrus");
    var $formItem = $("#form-item")
    var $hiddenHelperItem = $formItem.find("#hiddenHelperItem");
    var $formDR = $("#form-modal-documento-relacionado")
    var $hiddenHelperDR = $formDR.find("#hiddenHelperDR");
    var $formComprobante = $("#form-datos-comprobante")



    var $btnEmitirFactura = $("#btnEmitirFactura");


	var LstFechaVencimiento_ = [];
	var _ListaCreditos = [];//PAS20201U210100231-OPV
	var $hiddenDomicilioFiscalRecep = $("#domicilioFiscalRecep");
	var $hiddenMontoNetoPendiente = $("#montoNetoPendiente");

	//[PAS20211U210700145][anunez][2021.11.08]
	var $vistaPreliminar = false;
    /*
     *  :::: CONTAINERS :::: END
     */
    /*
     *  :::: HELPERS :::: START
     */
	var _tipoDocumentoReceptor = {
        "1": "DNI",
        "4": "RUC",
		"6": "RUC",
		"0": "RUC"
    }
    var _tipoDocumentoIdentidad = {
        "1": "DNI",
        "2": "PASAPORTE",
        "3": "CARNET DE EXTRANJERIA",
        "4": "RUC",		
    }

    var _tipoDocumentoRelacionado = {
        '09': 'Guia de Remisi&oacute;n Remitente',
        '31': 'Guia de Remisi&oacute;n de Transportista',
        'G9': 'Guia de Remisi&oacute;n por Eventos',
        '00': 'Otros',
    }

	// PAS20201U210100020
	var _tipoMedida = {
		'NIU': 'UNIDAD',
		'KGM': 'KILOGRAMO',
		'BX': 'CAJA',
		'PK': 'PAQUETE',
		'TNE': 'TONELADAS',
		'BJ': 'BALDE',
		'BLL': 'BARRILES',
		'4A': 'BOBINAS',
		'BG': 'BOLSA',
        'BO': 'BOTELLAS',
		'CT': 'CARTONES',
		'CMK': 'CENTIMETRO CUADRADO',
		'CMQ': 'CENTIMETRO CUBICO',
		'CMT': 'CENTIMETRO LINEAL',
		'CEN': 'CIENTO DE UNIDADES',
		'CY': 'CILINDRO',
		'CJ': 'CONOS',
		'DZN': 'DOCENA',
		'DZP': 'DOCENA POR 10**6',
		'BE': 'FARDO',
		'GLI': 'GALON INGLES (4,545956L)',
		'GRM': 'GRAMO',
		'GRO': 'GRUESA',
		'HLT': 'HECTOLITRO',
		'LEF': 'HOJA',
		'SET': 'JUEGO',
		'KTM': 'KILOMETRO',
		'KWH': 'KILOVATIO HORA',
		'KT': 'KIT',
		'CA': 'LATAS',
		'LBR': 'LIBRAS',
		'LTR': 'LITRO',
		'MWH': 'MEGAWATT HORA',
		'MTR': 'METRO',
		'MTK': 'METRO CUADRADO',
		'MTQ': 'METRO CUBICO',
		'MGM': 'MILIGRAMOS',
		'MLT': 'MILILITRO',
		'MMT': 'MILIMETRO',
		'MMK': 'MILIMETRO CUADRADO',
		'MMQ': 'MILIMETRO CUBICO',
		'MLL': 'MILLARES',
		'UM': 'MILLON DE UNIDADES',
		'ONZ': 'ONZAS',
		'PF': 'PALETAS',
		'PR': 'PAR',
		'FOT': 'PIES',
		'FTK': 'PIES CUADRADOS',
		'FTQ': 'PIES CUBICOS',
		'C62': 'PIEZAS',
		'PG': 'PLACAS',
		'ST': 'PLIEGO',
		'INH': 'PULGADAS',
		'RM': 'RESMA',
		'DR': 'TAMBOR',
		'STN': 'TONELADA CORTA',
		'LTN': 'TONELADA LARGA',
		'TU': 'TUBOS',
		'ZZ': 'UNIDAD',
		'GLL': 'US GALON (3,7843 L)',
        'YRD': 'YARDA',
		'YDK': 'YARDA CUADRADA'
    }

	/*
    var _tipoMedida = {
        '4A':'BOBINAS',
        'BE':'FARDO',
        'BG':'BOLSA',
        'BJ':'BALDE',
        'BLL':'BARRILES',
        'BO':'BOTELLAS',
        'BX':'CAJA',
        'C62':'PIEZAS',
        'CA':'LATAS',
        'CEN':'CIENTO DE UNIDADES',
        'CJ':'CONOS',
        'CMK':'CENTIMETRO CUADRADO',
        'CMQ':'CENTIMETRO CUBICO',
        'CMT':'CENTIMETRO LINEAL',
        'CT':'CARTONES',
        'CY':'CILINDRO',
        'DR':'TAMBOR',
        'DZN':'DOCENA',
        'DZP':'DOCENA POR 0**6 ',
        'FOT':'PIES',
        'FTK':'PIES CUADRADOS',
        'FTQ':'PIES CUBICOS',
        'GLI':'GALON INGLES (4,545956L)',
        'GLL':'US GALON (3,7843 L)',
        'GRM':'GRAMO',
        'GRO':'GRUESA',
        'HLT':'HECTOLITRO',
        'INH':'PULGADAS',
        'KGM':'KILOGRAMO',
        'KT':'KIT',
        'KTM':'KILOMETRO',
        'KWH':'KILOVATIO HORA',
        'LBR':'LIBRAS',
        'LEF':'HOJA',
        'LTN':'TONELADA LARGA',
        'LTR':'LITRO',
        'MGM':'MILIGRAMOS',
        'MLL':'MILLARES',
        'MLT':'MILILITRO',
        'MMK':'MILIMETRO CUADRADO',
        'MMQ':'MILIMETRO CUBICO',
        'MMT':'MILIMETRO ',
        'MTK':'METRO CUADRADO',
        'MTQ':'METRO CUBICO',
        'MTR':'METRO',
        'MWH':'MEGAWATT HORA',
        'NIU':'UNIDAD',
        'ONZ':'ONZAS',
        'PF':'PALETAS',
        'PG':'PLACAS ',
        'PK':'PAQUETE',
        'PR':'PAR',
        'RM':'RESMA',
        'SET':'JUEGO',
        'ST':'PLIEGO',
        'STN':'TONELADA CORTA',
        'TNE':'TONELADAS',
        'TU':'TUBOS',
        'UM':'MILLON DE UNIDADES',
        'YDK':'YARDA CUADRADA',
        'YRD':'YARDA',
        'ZZ':'UNIDAD'
    }
	*/
    var _moneda = {
        'USD': '&dollar;',
        'PEN': 'S/',
        'EUR': '&euro;',
        'GBP': '&pound;',
        'JPY': '&yen;',
        'SEK': 'kr',
        'CHF': 'CHF',
        'CAD': 'C&dollar;',
    }

    var _monedaDescripcion = {
        'PEN': 'SOLES',
        'EUR': 'EUROS',
        'USD': 'DOLAR AMERICANO',
        'GBP': 'LIBRA ESTERLINA',
        'JPY': 'YEN',
        'SEK': 'CORONA SUECA',
        'CHF': 'FRANCO SUIZO',
        'CAD': 'DOLAR CANADIENSE'
    }

    var _tipoProducto = {
        'TI01': 'Bien',
        'TI02': 'Servicio'
    }

	var _tipoBeneficio = {
		'TB00': 'Gravado',
        'TB01': 'Exonerado'
    }

    var _impuestoICBPER={
        '2019' : '0.10',
        '2020' : '0.20',
        '2021' : '0.30',
        '2022' : '0.40',
        '2023' : '0.50'
    }
    //INI-ALB: PAS20201U210100231
    var _formaPago = {
        '1': 'Al Contado',
        '2': 'Al Cr&eacute;dito',
    }
    //FIN-ALB: PAS20201U210100231

	var validatorForm = null;

    var _itemEditando = false;
    var _DocumentosRelacionadosSchema = {
        selTipoDocumentoRelacionado: "Tipo de Documento",
        txtSerie: "Serie",
        txtNumero: "N&uacute;mero",
        //txtDescripcion: "Descripci&oacute;n"
    }
    var _DocumentosRelacionados = [];
    var _Items = [];
    var _DireccionesReceptor = [];
    var _DireccionesReceptorSchema = {
        "tipo": "Tipo de Domicilio",
        "domicilio": "Domicilio",
    };
    //INI-ALB: PAS20201U210100231
    var _direccionDepartamento = null;
    var _direccionProvincia = null;
    var _direccionDistrito= null;
    var _txtDetalleDireccion= null;
    var _txtUbigeo=null;

    //FIN-ALB: PAS20201U210100231
    // PAS20201U210100151
    var _DireccionesEmisor = [];
    var _DireccionesEmisorSchema = {
        "tipo": "Tipo de Domicilio",
        "domicilio": "Domicilio",
    };

    var _direccionSeleccionada = -1;
    var _itemSchema = {};

    // Bolsas
    var nrusvalue = $("#tributoNrus").val();

    if( nrusvalue != "1"){
        _itemSchema = {
            selTipo: "Tipo",
            selTipoIgv: "Tipo Igv",//GRAVADO O EXONERADO
            txtCantidad: "Cantidad",
            selUnidadMedida: "Unidad de Medida",
            txtCodigo: "C&oacute;digo",
            txtDescripcion: "Descripci&oacute;n",
            txtValorUnitario: "Valor Unitario",
            txtDescuento: "Descuento",
            tasaIGV: "tasaIGV",
            txtIGV: "IGV",
            txtImpICBPER : "ICBPER",
            txtImporte: "Importe",            
        }
    }else{
        _itemSchema = {
            selTipo: "Tipo",
            selTipoIgv: "Tipo Igv",//GRAVADO O EXONERADO
            txtCantidad: "Cantidad",
            selUnidadMedida: "Unidad de Medida",
            txtCodigo: "C&oacute;digo",
            txtDescripcion: "Descripci&oacute;n",
            txtValorUnitario: "Valor Unitario",
            txtDescuento: "Descuento",
            tasaIGV: "tasaIGV",
            txtIGV: "IGV",
            txtImporte: "Importe",            
        }
    }

    var _Productos = [];
    var _ProductoSchema = {
            txtCodigo: "C&oacute;digo",
            txtDescripcion: "Descripci&oacute;n",
            selTipo: "Tipo",
            selUnidadMedida: "Unidad de Medida",
            selMoneda: "Moneda",
            txtValorUnitario: "Precio de Venta",
        }
    var _datosCompletos = {}
	var _datosEnvio = {}

	var _datosItems = {}

    var _datosDocumentos = {}

    var _datosFactura = {}
    /*
     *  :::: HELPERS :::: END
     */
    /*
     *  :::: FUNCTION :::: START
     */
    function renderDocumentoRelacionado() {
        var tbody = $tablaDocumento.find('tbody');
        tbody.empty();
        for (var i in _DocumentosRelacionados) {
            var doc = _DocumentosRelacionados[i];
            var $row = $('<tr/>', {
                'data-row-id': doc.rowId
            });
            for (var k in _DocumentosRelacionadosSchema) {
                var text = doc[k];
                if (k == 'selTipoDocumentoRelacionado') {
                    text = _tipoDocumentoRelacionado[text];
                }
                $('<td/>').html(text).appendTo($row);
            }
            $('<td/>').append($('<button/>').addClass('btn btn-danger btn-sm remover').append($('<i/>').addClass('glyphicon glyphicon-remove'))).appendTo($row);
            $row.appendTo(tbody);
        }
        $("#documentos-relacionados-counter").text(_DocumentosRelacionados.length)
        $hiddenHelperDR.val(_DocumentosRelacionados.length);
        $tablaDocumento.trigger('footable_initialize');
    }

    function agregarDocumentoRelacionado(data) {
        _DocumentosRelacionados.push(data);
        renderDocumentoRelacionado();
    }

    function eliminarDocumentoRelacionado(criteria) {
        _DocumentosRelacionados = _.reject(_DocumentosRelacionados, criteria)
        renderDocumentoRelacionado();
    }

    function editarDocumentoRelacionado(criteria, data) {
        var doc = _.find(_DocumentosRelacionados, criteria)
        doc = _.extend(doc, data);
        renderDocumentoRelacionado();
    }
    //INI-ALB: PAS20201U210100231
    function renderModalDireccionFiscal() {
		if($cambiosFactoringHabilitados=="1"){
			document.getElementById("txtDireccionFiscal").value ="";
			$("#btnMostrarModalRegistrarDireccion").prop('disabled', true);
			$("#direccionDepartamento").val('');
			$("#direccionProvincia").val('');
			$("#direccionDistrito").val('');
			$("#txtDetalleDireccion").val('');
			renderDireccionFiscal();
		}
    }
    function renderDireccionFiscal() {
        _direccionDepartamento = null;
        _direccionProvincia = null;
        _direccionDistrito = null;
        _txtDetalleDireccion = null;
        _txtUbigeo = null;
    }
    //FIN-ALB: PAS20201U210100231
    function renderItem() {//frank
        var tbody = $tablaItem.find('tbody');
        tbody.empty();
        for (var i in _Items) {
            var doc = _Items[i];
            var $row = $('<tr/>', {
                'data-item-id': doc.itemId
            });
            for (var k in _itemSchema) {
                var text = doc[k];
				if (k == 'selTipoIgv'){
					text = _tipoBeneficio[text];
				}
				if (k == 'selTipo'){
					text = _tipoProducto[text];
				}
                if (k == 'selUnidadMedida') {
					// INICIO PAS20201U210100161
					sessionStorage.clear();
					sessionStorage.setItem("uMedida",text);
					// FIN PAS20201U210100161

                    text = _tipoMedida[text];
                }

                //if (k == 'selTipo') continue;
                $('<td/>').html(text).appendTo($row);
            }
            $('<td/>').append($('<button/>').addClass('btn btn-danger btn-sm remover').append($('<i/>').addClass('glyphicon glyphicon-remove'))).appendTo($row);
           $row.appendTo(tbody);
        }
        $("#items-counter").text(_Items.length)
        $modalItem.find('.lista-errores').empty();
        $panelItems.find('.lista-errores').empty();
        $hiddenHelperItem.val(_Items.length);
        $tablaItem.trigger('footable_initialize');
    }

    function agregarItem(data) {
        _Items.push(data);
        renderItem();
    }

    function eliminarItem(criteria) {
        _Items = _.reject(_Items, criteria)
        renderItem();
    }

    function buscarItem(criteria) {
        return _.find(_Items, criteria);
    }

    function editarItem(criteria, data) {
        var doc = buscarItem(criteria);
        doc = _.extend(doc, data);
        renderItem();
    }

    function popularModalItem(data, triggerChange, ignoreCodigo) {
        for (var i in _itemSchema) {
            if (!data.hasOwnProperty(i) || ignoreCodigo && i == 'txtCodigo') continue;
            var el = $formModalItem.find('#' + i);
            el.val(data[i]);
            if (triggerChange) el.trigger('keyup').trigger('change');
        }
        if(data.hasOwnProperty('selMoneda')){
            var totales = data.selMoneda;
            var divisa = $selMoneda.val()
            if(totales.hasOwnProperty(divisa)){
              $formModalItem.find('#txtValorUnitario').val(totales[divisa]);
              if (triggerChange)
                $formModalItem.find('#txtValorUnitario').trigger('keyup').trigger('change');
            }
        }
    }

    // fix 18-10-2015
    function prefetchProductos() {
       $.getJSON('emitirfesimp.do?action=getCatalogoProductos', function(data) {
            _Productos = data;
            $selMoneda.trigger('focus').trigger('change')
        })
    }
    // end - fix 18-10-2015

    function filtarProductos(descripcion) {
        var regex = new RegExp(descripcion, "ig");
        return _.filter(_Productos, function(curr) {
            return curr.txtDescripcion.match(regex) !== null;
        });
    }

    function renderProductos(productos) {
        productos = productos || _Productos;
        var tbody = $tablaProducto.find('tbody');
        tbody.empty();
        for (var i in productos) {
            var doc = productos[i];
            var $row = $('<tr/>', {
                'data-p-id': doc.pId
            });
            for (var k in _ProductoSchema) {
                var text = doc[k];
                if (k == 'selUnidadMedida') {
                    text = _tipoMedida[text];



                }
                if (k == 'selTipo') {
                    text = _tipoProducto[text];
                }
                if (k == 'selMoneda') {
                    text = _moneda[text];
                }
                $('<td/>').html(text).appendTo($row);
            }
            $('<td/>').append($('<button/>', {
                type: 'button'
            }).addClass('btn btn-primary btn-sm seleccionar').append($('<i/>').addClass('glyphicon glyphicon-ok'))).append(' ').appendTo($row);
            $row.appendTo(tbody);
        }
        $tablaProducto.trigger('footable_initialize');
    }

    function refrescarResumen() {
        var totalValorGravado = 0;
        var totalValorDescuentos = 0;
        var totalIGV = 0;
        var totalimporteICBPER = 0;
        var totalImporte = 0;
        console.log(_Items);
        _.each(_Items, function (e) {
            totalValorGravado += parseFloat(e.txtValorUnitario.replace(/,/g, '')) * parseFloat(e.txtCantidad.replace(/,/g, '')) || 0;
            totalValorDescuentos += parseFloat(e.txtDescuento.replace(/,/g, '')) || 0;
            totalIGV += parseFloat(e.txtIGV.replace(/,/g, '')) || 0;
            totalimporteICBPER += parseFloat( e.txtImpICBPER != undefined ? e.txtImpICBPER.replace(/,/g, '') : 0) || 0;
            totalImporte += parseFloat(e.txtImporte.replace(/,/g, '')) || 0;
        });
        $lblTotalVentaGravado.text(totalValorGravado.toMoney(2));
        $lblTotalValorDescuentos.text(totalValorDescuentos.toMoney(2));
        $lblTotalTotalIGV.text(totalIGV.toMoney(2));
        $lblTotalImporteICBPER.text(totalimporteICBPER.toMoney(2));
        $lblTotalImporteTotal.text(totalImporte.toMoney(2));
		//INI-PAS20201U210100231
		$ImporteTotal=Math.round(totalImporte * 100) / 100;
		//$ImporteTotal=totalImporte;
		console.log("$ImporteTotal="+$ImporteTotal);
		//FIN-PAS20201U210100231
    }


	function showOpcionTipoDocumento(){
		var ind = $('select[name=tipoDocumento]').val();
		var ind1 = $('select[name=selFormaPago]').val();	//ALB: PAS20201U210100231
		if(ind==1){
			//$RUCField.val()
			$("#txtRuc").prop('disabled', false);
            $("#txtRuc").val('');
            document.getElementById("txtRuc").maxLength=8;
            $("#txtRazonSocial").val('');
            //PAS20211U210700145 - EABV CPE-99-P5 - INI
            document.getElementById("inicio.direccion.label").innerHTML="Direcci&oacute;n fiscal del receptor (Opcional)";
            document.getElementById("txtDireccionFiscal").placeholder="DIRECCION FISCAL DEL RECEPTOR (OPCIONAL)";
            //PAS20211U210700145 - EABV CPE-99-P5 - FIN
		}else if(ind==6){
			$("#txtRuc").prop('disabled', false);
			$("#txtRuc").val('');
            document.getElementById("txtRuc").maxLength=11;
            $("#txtRazonSocial").val('');
            //PAS20211U210700145 - EABV CPE-99-P5 - INI
            document.getElementById("inicio.direccion.label").innerHTML="Direcci&oacute;n fiscal del receptor";
            document.getElementById("txtDireccionFiscal").placeholder="DIRECCION FISCAL DEL RECEPTOR";
            //PAS20211U210700145 - EABV CPE-99-P5 - FIN
		}else if(ind==0){
			$("#txtRuc").prop('disabled', true);
            $("#txtRuc").val('');
            $("#txtRazonSocial").val('');
            //PAS20211U210700145 - EABV CPE-99-P5 - INI
            document.getElementById("inicio.direccion.label").innerHTML="Direcci&oacute;n fiscal del receptor";
            document.getElementById("txtDireccionFiscal").placeholder="DIRECCION FISCAL DEL RECEPTOR";
            //PAS20211U210700145 - EABV CPE-99-P5 - FIN
            $("#txtDireccionFiscal").prop('disabled', true);
        }
        //INI-ALB: PAS20201U210100231
        renderModalDireccionFiscal();
        //$("#direccionDepartamento").selectmenu("refresh");
        if(ind1==2){//AL CREDITO
            validarDomicilioFiscal();
        }
        //FIN-ALB: PAS20201U210100231
	}

	function showOpcionGastoDeduciblePPNN(valor) {
		if (valor == 1) {
			$('select[name=tipoDocumento]').val('0');
			$("#txtRuc").prop('disabled', true);
			document.getElementById("inicio.ruc.label").innerHTML="DOCUMENTO ";
			document.getElementById("txtRuc").placeholder =" INGRESE DOCUMENTO";
			document.getElementById("txtRuc").value ="";
			document.getElementById("inicio.tipoDocumento.show").style.display = 'block';

			$('select[name=selTipo]').empty();
			$('select[name=selTipo]').append('<option value="TI02" selected="selected">Servicio</option>');
			$('#txtCantidad').val(1).attr('readonly', 'readonly');

			if(document.getElementById("txtRazonSocial").value != ""){
				document.getElementById("txtRazonSocial").value ="";
				$('#btnValidarDatosReceptor').removeClass('hidden');
				$('#btnContinuarPaso').addClass('hidden');
            }

            renderModalDireccionFiscal();//ALB: PAS20201U210100231

		} else if (valor == 0) {
			$('select[name=tipoDocumento]').val('0');
			$("#txtRuc").prop('disabled', false);
			//PAS20211U210700145 - EABV CPE-99-P5 - INI
            document.getElementById("inicio.direccion.label").innerHTML="Direcci&oacute;n fiscal del receptor";
            document.getElementById("txtDireccionFiscal").placeholder="DIRECCION FISCAL DEL RECEPTOR";
            //PAS20211U210700145 - EABV CPE-99-P5 - FIN
			document.getElementById("txtRuc").maxLength=11;
			document.getElementById("inicio.ruc.label").innerHTML="RUC ";
			document.getElementById("txtRuc").placeholder =" INGRESE RUC";
			$("#txtRuc").val('');
			document.getElementById("inicio.tipoDocumento.show").style.display = 'none';

			$('select[name=selTipo]').empty();
			$('select[name=selTipo]').append('<option value="TI01" selected="selected">Bien</option>');
			$('select[name=selTipo]').append('<option value="TI02" >Servicio</option>');
			$('#txtCantidad').removeAttr('readonly');

			if(document.getElementById("txtRazonSocial").value != ""){
				document.getElementById("txtRazonSocial").value ="";
				$('#btnValidarDatosReceptor').removeClass('hidden');
				$formFacturaDatosReceptor.removeClass('has-error');
            }

            renderModalDireccionFiscal();//ALB: PAS20201U210100231

		}
		validatorForm.resetForm();
		$("#div-lista-errores").addClass('hidden');
		$("#div-ruc-label").removeClass('has-error');
		$btnValidarDatosReceptor.removeClass('hidden');
        $btnContinuar.addClass('hidden');
		document.getElementById("txtRuc").focus();
    }
    //INI-ALB: PAS20201U210100231
    function showOpcionFormaPago(){
		var ind = $('select[name=selFormaPago]').val();
        //PAS20211U210700145-EBV-FIX-INI
        if(ind==2){
            //AL CREDITO
            document.getElementById("inicio.direccionfiscal.show").style.display = 'block';
			$("#txtDireccionFiscal").prop('disabled', false);
            $("#txtDireccionFiscal").val('');
            renderModalDireccionFiscal();//ALB: PAS20201U210100231
            validarDomicilioFiscal();
			//INI PAS20201U210100231-opv
			if($btnContinuar.hasClass('hidden')&& $btnValidarDatosReceptor.hasClass('hidden')){
				$panelCredito.removeClass('hidden').find('.panel-collapse').collapse('show');
			}
			//FIN PAS20201U210100231-opv
        }else{
            //AL CONTADO
            document.getElementById("inicio.direccionfiscal.show").style.display = 'none';
            //$RUCField.val()
       	 	//$txtFechaVencimiento.prop('disabled', true);//PAS20201U210100231
           	//$txtFechaVencimiento.prop('disabled', false);//PAS20201U210100231
			$("#txtDireccionFiscal").prop('disabled', false);
            $("#txtDireccionFiscal").val('');
            $panelCredito.addClass('hidden').find('.panel-collapse').collapse('show');
            renderModalDireccionFiscal();
		}
        //PAS20211U210700145-EBV-FIX-FIN
	}
	//FIN-ALB: PAS20201U210100231
    function renderDireccionesReceptor() {
        var tbody = $tablaDireccionesReceptor.find('tbody');
        tbody.empty();
        var txtLugarEntrega = $txtLugarEntrega.val()
        for (var i in _DireccionesReceptor) {
            var direccion = _DireccionesReceptor[i];
            var domicilio = direccion.domicilio;
            var $row = $('<tr/>', {
                'data-row-id': direccion.codigo
            });
            if($.trim(txtLugarEntrega)==$.trim(domicilio)){

            	$('<td/>').append(
                        $('<button/>').addClass('btn btn-primary agregar-nuevo').append(
                          $('<i/>').addClass('glyphicon glyphicon-ok')
                        )
                      ).appendTo($row);

            }else{

            	 $('<td/>').append(
                         $('<button/>').addClass('btn btn-primary agregar-nuevo').append(
                           $('<i/>').addClass('glyphicon glyphicon-remove')
                         )
                       ).appendTo($row);
            }

            for (var k in _DireccionesReceptorSchema) {
                var text = direccion[k];
                $('<td/>').html(text).appendTo($row);
            }
            $row.appendTo(tbody);
        }
        $tablaDireccionesReceptor.trigger('footable_initialize');
    }
    //PAS20201U210100151
    function renderDireccionesEmisor() {
        var tbody = $tablaDireccionesEmisor.find('tbody');
        tbody.empty();
        var txtLugarEntrega = $txtLugarEntrega.val();
        for (var i in _DireccionesEmisor) {
            var direccion = _DireccionesEmisor[i];
            var domicilio = direccion.domicilio;
            var $row = $('<tr/>', {
                'data-row-id': direccion.codigo,
                'data-address':direccion.domicilio,
                'data-tipo':direccion.tipo
            });
            if($.trim(txtLugarEntrega)==$.trim(domicilio)){
            	$('<td/>').append(
                        $('<button/>').addClass('btn btn-primary agregar').append(
                          $('<i/>').addClass('glyphicon glyphicon-ok')
                        )
                      ).appendTo($row);
            }else{
            	$('<td/>').append(
                        $('<button/>').addClass('btn btn-primary agregar').append(
                          $('<i/>').addClass('glyphicon glyphicon-remove')
                        )
                      ).appendTo($row);
            }

            for (var k in _DireccionesEmisorSchema) {
                var text = direccion[k];
                $('<td/>').html(text).appendTo($row);
            }
            $row.appendTo(tbody);
        }
        $tablaDireccionesEmisor.trigger('footable_initialize');
    }
    // PAS20201U210100151
    function listaDireccionesEmisor(){

    	var url = 'emitirfesimp.do?action=listaDireccionesEmisor';
    	var formData = {	txtRUC: $RUCField.val()};

    	$.ajax({
            url: url,
            type: "POST",
            data: formData,
            dataType: 'json',
            success: function(data) {

    			//console.log("data.estadoXD"+data.estado);



              //llenar direcciones de emisor
              //var ListaEstablecimientosEmisor=[];
             // var ListaEstablecimientosEmisor = $("#ListaEstablecimientosEmisor").val();
              _DireccionesEmisor = data.items;


            },

            error: function () {
              alert('error');
              $RUCField.data('pivot-valid', '0');
              //$razonSocial.closest('.form-group').addClass('hidden');
              $btnValidarDatosReceptor.removeClass('hidden');
              $btnContinuar.addClass('hidden');
            },
            complete: function () {
              $modalPreloader.modal('hide');
              $formFacturaDatosReceptor.valid();
            }
          });
    }


    function validarExistenciaRUC(){
    	localStorage.removeItem('pGeneric'); //JBM PAS20221U210700303
        renderModalDireccionFiscal();

        var url = 'emitirfesimp.do?action=validarExistenciaRucCliente';
		var ind1 = $('input[name=opcDeductible]:checked').val();
		var ind2 = $('select[name=tipoDocumento]').val();

		if(ind1==1 && ind2==1){ tipo = "01";
		}else{ tipo = "06"; }

		var formData = {	txtRUC: $RUCField.val(), tipoDocumento: tipo, gastoDeducible: ind1};

      $.ajax({
        url: url,
        type: "POST",
        data: formData,
        dataType: 'json',
        success: function(data) {

			//console.log("data.estadoXD"+data.estado);

          if(data.estado == '0'){
            $RUCField.data('pivot-valid', '0');
            //$razonSocial.closest('.form-group').addClass('hidden');
            $btnValidarDatosReceptor.removeClass('hidden');
            $btnContinuar.addClass('hidden');
            alert('El ruc ingresado no existe');
            return;
          }

         if (data.estado == '2') {
            alert('El ruc ingresado no esta activo');
            return;
         }

         if (data.estado == '3') {
            alert('El ruc ingresado no esta habido');
            return;
         }

         if(data.estado == '4'){
				$RUCField.data('pivot-valid', '0');
				alert('El ruc ingresado es el mismo del emisor');
				//$razonSocial.closest('.form-group').addClass('hidden');
			    $btnValidarDatosReceptor.removeClass('hidden');
                $btnContinuar.addClass('hidden');
            return;
          }

		  if(data.estado == '5'){
				alert('Su Cliente no cuenta con clave SOL.'); // PAS20221U210600185
                alertMessageDanger('Su Cliente no cuenta con clave SOL.'); // PAS20221U210600185
				$btnValidarDatosReceptor.removeClass('hidden');
				$btnContinuar.addClass('hidden');
            return;
          }

		  if (typeof data.estado == 'undefined'){
				$RUCField.data('pivot-valid', '0');
				alert('El documento ingresado no fue encontrado.');
				//$razonSocial.closest('.form-group').addClass('hidden');
				$btnValidarDatosReceptor.removeClass('hidden');
				$btnContinuar.addClass('hidden');
            return;
          }

          $razonSocial.val(data.razon_social).closest('.form-group').removeClass('hidden');
          $RUCField.data('pivot-valid', '1');
          _DireccionesReceptor = data.items;
          // PAS20201U210100151
          //llenar direcciones de emisor
          //var ListaEstablecimientosEmisor=[];
          // var ListaEstablecimientosEmisor = $("#ListaEstablecimientosEmisor").val();
          // _DireccionesEmisor = $.parseJSON(ListaEstablecimientosEmisor);

          $btnContinuar.removeClass('hidden');
          $btnValidarDatosReceptor.addClass('hidden');

            //INI-ALB: PAS20201U210100231
            var ind = $('select[name=selFormaPago]').val();
            if(ind==2){//AL CREDITO
                validarDomicilioFiscal();
            }
            //FIN-ALB: PAS20201U210100231
        },

        error: function () {
          alert('error');
          $RUCField.data('pivot-valid', '0');
          //$razonSocial.closest('.form-group').addClass('hidden');
          $btnValidarDatosReceptor.removeClass('hidden');
          $btnContinuar.addClass('hidden');
        },
        complete: function () {
          $modalPreloader.modal('hide');
          $formFacturaDatosReceptor.valid();
        }
      });


    }
    //INI-ALB: PAS20201U210100231
    function validarDomicilioFiscal(){
        console.log("validarDomicilioFiscal");
        var url = 'emitirfesimp.do?action=validarDomicilioFiscal';
		var ind1 = $('input[name=opcDeductible]:checked').val();
		var ind2 = $('select[name=tipoDocumento]').val();

		if(ind1==1 && ind2==1){ tipo = "01";
        }else{ tipo = "06"; }

        renderDireccionFiscal();

            if(tipo == "06"){
				// TODO
				 $("#btnMostrarModalRegistrarDireccion").prop('disabled', true);
                 document.getElementById("btnMostrarModalRegistrarDireccion").style.display = 'none';//PAS20211U210700145-EBV-FIX
				// $("#btnMostrarModalRegistrarDireccion").prop('disabled', false);
                if(document.getElementById("txtRuc").value != ""){

                    var formData = {	txtRUC: $RUCField.val(), tipoDocumento: tipo};
                    $.ajax({
                        url: url,
                        type: "POST",
                        data: formData,
                        dataType: 'json',
                        success: function(data) {
                            $direccionFiscal.val(data.txtDetalleDireccion).closest('.form-group').removeClass('hidden');

							_direccionDepartamento =  data.direccionDepartamento;
							console.log("_direccionDepartamento="+_direccionDepartamento);
                            _direccionProvincia = data.direccionProvincia;
							console.log("_direccionProvincia="+_direccionProvincia);
                            _direccionDistrito = data.direccionDistrito;
							console.log("_direccionDistrito="+_direccionDistrito);
                            _txtDetalleDireccion = data.txtDetalleDireccion;
							console.log("_txtDetalleDireccion="+_txtDetalleDireccion);

                            _txtUbigeo = data.ubigeo;
							console.log("_txtUbigeo="+_txtUbigeo);
                        },
                        error: function () {
                            alert('error');
                            $RUCField.data('pivot-valid', '0');
                            $btnValidarDatosReceptor.removeClass('hidden');
                            $btnContinuar.addClass('hidden');
                        },
                        complete: function () {
                            $modalPreloader.modal('hide');
                            $formFacturaDatosReceptor.valid();
                        }
                    });
                }
            }else{
                $("#btnMostrarModalRegistrarDireccion").prop('disabled', false);
                document.getElementById("btnMostrarModalRegistrarDireccion").style.display = 'block';//PAS20211U210700145-EBV-FIX
            }



    }
    //FIN-ALB: PAS20201U210100231

    function validarExistenciaDNI(){
      var formData = {
        txtDocumento: $RUCField.val()
      };
      // var url = 'emisionrhe.do?action=validarDocumento';
      var url = ['a/js/json/cliente.json'].join('');
      $.ajax({
        url: url,
        type: "POST",
        data: formData,
        dataType: 'json',
        success: function(data) {


          if(data.estado == '0'){

            alert('El Ruc ingresado no existe');

            $RUCField.data('pivot-valid', '0');
            return;
          }
          if(data.estado == '2'){

            alert('El Ruc ingresado no esta activo');

             $RUCField.data('pivot-valid', '0');
            return;

          }
          if(data.estado == '3'){


            alert('El Ruc ingresado no esta activo');

             $RUCField.data('pivot-valid', '0');
            return;
          }

          $razonSocial
            .val(data.razon_social)
            .closest('.form-group')
            .removeClass('hidden');
          $RUCField.data('pivot-valid', '1');
          $btnContinuar.removeClass('hidden');
          $btnValidarDatosReceptor.addClass('hidden');
        },
        error: function () {
          $RUCField.data('pivot-valid', '0');
          $razonSocial
            .closest('.form-group')
            .addClass('hidden');
          $btnValidarDatosReceptor.removeClass('hidden');
          $btnContinuar.addClass('hidden');
        },
        complete: function () {
          $modalPreloader.modal('hide');
          $formBoletaDatosReceptor.valid();
        }
      });
    }



    function formatFecha (x) {
      if (!x instanceof Date)
        throw new Error('not-a-date')
      var day = x.getDate()
      day = day < 10 ? '0'+day : day;
      var month = x.getMonth()+1;
      month = month < 10 ? '0'+month : month;
      var year = x.getFullYear()
      return [day, month, year].join('/');
    }

     function prepararDatosPreview () {
      var d = new Date();

	  var retObj={};
		//INI-OPV: PAS20201U210100231 Cambios Factoring Habilitados  Si tiene valor 1 los cambios factoring estan habilitados

		//INI-OPV: PAS20201U210100231 -- ARRAY InfCredito
		_ListaCreditos=[];
		if($cambiosFactoringHabilitados=="1"){
			//OPV-INI-Compatibilidad Internet Explorer
			 // _ItemsInfCredito.forEach(element=>{
			for (i=0; i < _ItemsInfCredito.length; i++) {
				  var element=_ItemsInfCredito[i];
				  var Cuota={
					  numeroCuota:element.numeroCuota,
					  montoCuota:element.montoCuota,
					  fechaVencimiento:element.fechaVencimiento
				  }
				  _ListaCreditos.push(Cuota);

			  };
			//OPV-FIN-Compatibilidad Internet Explorer
		}
		//FIN-OPV: PAS20201U210100231

		var retObj = {


			preview: {
				titulo: (function(){
					return $selTipoDoc.length > 0 ? "Boleta de Venta Electr&oacute;nica" : "Factura Electr&oacute;nica"
				})()

			},

			emisor: {
			  ruc: $hiddenRucEmisor.val(),
			  tipoDoc: $selTipoDoc.length == 0 ? "4" : $selTipoDoc.val(),
			  direccion: $hiddenDireccionEmisor.val(),
			  razon_social: $hiddenRazonSocialEmisor.val(),
			  nombre_comercial: $hiddenNombreComercialEmisor.val(),
			  departamento: $hiddenDepartamentoEmisor.val(),
			  nrus:   $hiddenNrus.val()

			},
			factura: {
				//fecha_emision: formatFecha(new Date),
				fecha_emision: $txtFechaEmision.val(),
				fecha_vencimiento: $txtFechaVencimiento.val(),
				razon_social: $txtRazonSocial.val(),
				ruc: $RUCField.val(),
				tipoDocRecep: $('select[name=tipoDocumento]').val(),//FRANK
				moneda_iso: $selMoneda.val(),
				direccion_entrega: $txtLugarEntrega.val(),
				total_gravado: $('#total-valor-venta-gravado').text(),
				total_descuentos: $('#total-valor-descuentos').text(),
				total_igv: $('#total-igv').text(),
				total_importe: $('#importe-total').text(),
				importe_icbper: $('#importe-icbper').length > 0 ? $('#importe-icbper').text() : 0,
				txtIndicador: $('#txtIndicador').val(),
				//INI PAS20201U210100231
				forma_de_pago: $('select[name=selFormaPago]').val()=="1" ? "1" : "2",
				domicilio_fiscal: $direccionFiscal.val(),
				cantidad: parseInt(_ListaCreditos.length),//PAS20201U210100231-OPV  CANTIDAD CUOTAS INF CREDITO
				monto_neto_pendiente: $('#txtMontoNeto').val(),//PAS20201U210100231-OPV  PARA FACTORING BEAN
				ListaCreditos:	_ListaCreditos,  //PAS20201U210100231-OPV  PARA FACTORING BEAN
				base_imponible_retencion: $txtBaseImponible.val(),
				monto_retencion:  $txtMontoRetencion.val(),
				porcentaje_retencion: $txtPorcentaje.val(),
				puedeEmitirRetencion: $puedeEmitirRetencion.val()
				//INI-ALB: PAS20201U210100231
				, direccion_Departamento: _direccionDepartamento
				, direccion_Provincia: _direccionProvincia
				, direccion_Distrito: _direccionDistrito
				, txtDetalle_Direccion: _txtDetalleDireccion
				, txt_Ubigeo: _txtUbigeo
				,cambiosFactoringHabilitados:$cambiosFactoringHabilitados
				//FIN-ALB: PAS20201U210100231
			},
			documentos_relacionados: _DocumentosRelacionados,
			items: _Items

		};
       var retObj2 = {


        emisor: {
          ruc: $hiddenRucEmisor.val(),
          tipoDoc: $selTipoDoc.length == 0 ? "4" : $selTipoDoc.val(),
          direccion: $hiddenDireccionEmisor.val(),
          razon_social: $hiddenRazonSocialEmisor.val(),
          nombre_comercial: $hiddenNombreComercialEmisor.val(),
          departamento: $hiddenDepartamentoEmisor.val(),
          nrus:   $hiddenNrus.val()


        },
        factura: {
            //fecha_emision: formatFecha(new Date),
			fecha_emision: $txtFechaEmision.val(),
			formaPago : $("#selFormaPago").val(),
            razon_social: $txtRazonSocial.val(),
            ruc: $RUCField.val(),
			//tipoDocRecep: $('select[name=tipoDocumento]').val(),
            moneda_iso: $selMoneda.val(),
            direccion_entrega: $txtLugarEntrega.val(),

            fecha_vencimiento: $txtFechaVencimiento.val(),

            total_gravado: ($('#total-valor-venta-gravado').text()).replace(',',''),
            total_descuentos: ($('#total-valor-descuentos').text()).replace(',',''),
            total_igv: ($('#total-igv').text()).replace(',',''),
            importe_icbper: $('#importe-icbper').length > 0 ? ($('#importe-icbper').text()).replace(',','') : 0,
            total_importe: ($('#importe-total').text()).replace(',',''),
            txtIndicador: ($('#txtIndicador').val()).replace(',',''),
            //PAS20201U210100231
            base_imponible_retencion: $txtBaseImponible.val(),
			monto_retencion:  $txtMontoRetencion.val(),
            porcentaje_retencion: $txtPorcentaje.val(),
            puedeEmitirRetencion: $puedeEmitirRetencion.val()
            //PAS20201U210100231
			,ListaCreditos:	_ListaCreditos//PAS20201U210100231-OPV   LISTA DE CREDITOS
            ,monto_neto_pendiente: $('#txtMontoNeto').val()//PAS20201U210100231-OPV   LISTA DE CREDITOS
            //INI-ALB: PAS20201U210100231
            , direccion_Departamento: _direccionDepartamento
            , direccion_Provincia: _direccionProvincia
            , direccion_Distrito: _direccionDistrito
            , txtDetalle_Direccion: _txtDetalleDireccion
            , txt_Ubigeo: _txtUbigeo
			,cambiosFactoringHabilitados:$cambiosFactoringHabilitados
			//FIN-ALB: PAS20201U210100231
        },
        documentos_relacionados: _DocumentosRelacionados,
        items: _Items

      };


      var retObj3 = {

        items: _Items

      };


      var retObj4 = {

      factura: {
            //fecha_emision: formatFecha(new Date),
			fecha_emision: $txtFechaEmision.val(),

            razon_social: $txtRazonSocial.val(),
            ruc: $RUCField.val(),
            moneda_iso: $selMoneda.val(),
            direccion_entrega: $txtLugarEntrega.val(),
            total_gravado: $('#total-valor-venta-gravado').text(),
            total_descuentos: $('#total-valor-descuentos').text(),
            total_igv: $('#total-igv').text(),
            total_importe: $('#importe-total').text(),
            importe_icbper: $('#importe-icbper').length > 0 ? $('#importe-icbper').text() : 0,
            txtIndicador: $('#txtIndicador').val()
        }

      };

		console.log("retObj.factura.tipoDocRecep antes="+retObj.factura.tipoDocRecep);

		//console.log("retObj3.items_"+retObj3.items[1].itemId);

	  var retObj5 = {

         documentos_relacionados: _DocumentosRelacionados,

      };


	  retObj.factura.tipoDocRecep = _tipoDocumentoReceptor[retObj.factura.tipoDocRecep]
	  console.log("retObj.factura.tipoDocRecep despues="+retObj.factura.tipoDocRecep);

	  retObj.factura.valorIgv = Math.floor( $("#igvPorcentajeGlobal").val() );

      retObj.emisor.tipoDoc_val = _tipoDocumentoIdentidad[retObj.emisor.tipoDoc]
      retObj.documentos_relacionados = _.map(retObj.documentos_relacionados, function (doc) {
        doc.selTipoDocumentoRelacionado_val = _tipoDocumentoRelacionado[doc.selTipoDocumentoRelacionado]
        return doc;
      });

      retObj.items = _.map(retObj.items, function (i) {
        i.selUnidadMedida_val = _tipoMedida[i.selUnidadMedida]
        i.selTipo_val = _tipoProducto[i.selTipo]
		i.selTipoIgv_val = _tipoBeneficio[i.selTipoIgv] //
		//i.selTipoIgv_val = i.selTipoIgv //
        return i;
      });
      retObj.factura.moneda_simbolo = encodeURIComponent(_moneda[retObj.factura.moneda_iso]);
      retObj.factura.moneda = _monedaDescripcion[retObj.factura.moneda_iso];
      _datosCompletos = retObj;
      _datosEnvio=retObj2;


      _datosItems=retObj3;
      _datosFactura=retObj4;
      _datosDocumentos=retObj5;

      return retObj;

    } // fin preparar datos

    function showPreview () {

          $modalPreloader.modal('show');
        var data = prepararDatosPreview();
		console.log("data_"+data.selTipoIgv);//frank
		console.log("data"+data.selTipoIgv_val);
        $('#root-panels').addClass('hidden');
        $("#panel-preview").removeClass('hidden');
        $.get('factura-xhr.html').success(function (rtext) {
            var tpl = _.template(rtext)
            var parsed = tpl(data)
            $("#preview-factura").html(parsed).find('table').footable();
             $modalPreloader.modal('hide');
        })
    }

    /*
     *  :::: FUNCTION :::: END
     */
    /*
     *  :::: SETUP :::: START
     */
    $tablaDocumento.footable();
    $tablaItem.footable();
    $tablaProducto.footable();
    $tablaDireccionesReceptor.footable();
	// PAS20201U210100151
    $tablaDireccionesEmisor.footable();

    $('.modal').on('shown.bs.modal', function() {
        $(this).find('.footable').trigger('footable_initialize');
    })
    // PAS20201U210100151
    $('#modal-direcciones').on('show.bs.modal', function() {
        //$(this).find('.footable').trigger('footable_initialize');
    	renderDireccionesEmisor();
    })

    function verModalDirecciones(){
    	renderDireccionesEmisor();
    	renderDireccionesReceptor();
    	$('#modal-direcciones').modal('show');
    }

    $modalDirecciones.on('click', '.agregar', function(e) {
        // PAS20201U210100151
        var indicador = $(this).closest('tr').attr('data-tipo');
    	_direccionSeleccionada = $(this).closest('tr').attr('data-row-id');
        var direccion = _.find(_DireccionesEmisor, {codigo: _direccionSeleccionada})
        $txtLugarEntrega.val(direccion.domicilio);
        $txtIndicador.val(indicador);

        $modalDirecciones.modal('hide');
    });
    $modalDirecciones.on('click', '.agregar-nuevo', function(e) {
        _direccionSeleccionada = $(this).closest('tr').attr('data-row-id');
        var direccion = _.find(_DireccionesReceptor, {codigo: _direccionSeleccionada})
        $txtLugarEntrega.val(direccion.domicilio);
        $modalDirecciones.modal('hide');
    });
    $tablaDocumento.on('click', 'button.remover', function(e) {
        var rowId = $(e.target).closest('tr').attr('data-row-id');
        eliminarDocumentoRelacionado({
            rowId: rowId
        });
    })
    $tablaItem.on('click', 'button.remover', function(e) {
        var rowId = $(e.target).closest('tr').attr('data-item-id');
        eliminarItem({
            itemId: rowId
        });
        refrescarResumen();
    })
    $tablaItem.on('click', 'button.editar', function(e) {
        var rowId = $(e.target).closest('tr').attr('data-item-id');
        var currItem = buscarItem({
            itemId: rowId
        });
        _itemEditando = currItem.itemId;
        popularModalItem(currItem);
        $modalItem.modal('show');
    })
    $btnOpenModalDR.on('click', function() {
        $formModalDocumentoRelacionado.find('.alert').remove();
        $formModalDocumentoRelacionado.find('.has-error').removeClass('has-error');
        $formModalDocumentoRelacionado.find(':input').val('');
        $modalDocumentoRelacionado.modal('show');
    })
    $btnOpenModalItem.on('click', function() {
        if(_Items.length >= 10){
            alert('error-no-mas-10-items');
            return;
        }

        _itemEditando = false;
        $formModalItem.find('.alert').remove();
        $formModalItem.find('.has-error').removeClass('has-error');
        $formModalItem.find(':input').val('');
        $formModalItem.find('#txtCantidad').val((1).toMoney(2, ''));
        $formModalItem.find('#txtDescuento').val('0.00');
        $formModalItem.find('#rdgGravado').prop('checked', true);

		// INICIO PAS20201U210100161
		if(_Items.length == 0){
			$formModalItem.find('#selUnidadMedida').val('NIU');
		} else {
			$formModalItem.find('#selUnidadMedida').val(sessionStorage.getItem("uMedida"));
		}
		// FIN PAS20201U210100161


        initICBPER();

        $modalItem.modal('show');
    });
    $btnOpenModalSearch.on('click', function() {
        renderProductos();
        $modalSearch.modal('show');
    });
    $txtProductQuery.on('keyup', function(e) {
        var query = $txtProductQuery.val();
        var productos = filtarProductos(query);
        renderProductos(productos);
    });
    $tablaProducto.on('click', 'button.seleccionar', function(e) {
        var pid = $(e.target).closest('tr').attr('data-p-id');
        var producto = _.find(_Productos, {
            pId: pid
        });
        $formModalItem.find('#txtDescripcion').val(producto.txtDescripcion);
        $modalSearch.modal('hide');
    })

    // fix 20-10-2015
    $('[data-format-numeric]').on('change', function(e){
        var $self = $(this)//PAS20211U210100008 - jmendozas
        var num_decimals = 10 - removeValorUnitario(parseFloat($(this).numVal()).toFixed(10));//PAS20211U210100008 - jmendozas
        var places = $self.attr('data-decimal-places') || num_decimals;//PAS20211U210100008 - jmendozas
        var groupDelimiter = $self.attr('data-group-delimiter') || undefined;//PAS20211U210100008 - jmendozas
        console.log("DATA - MONEY => " , $(this).numVal() );
        e.target.value = $self.numVal().toMoney(places, groupDelimiter);
    });

    $('[data-format-numeric-2]').on('change', function(e){
        var places = 2;
        var groupDelimiter = e.target.getAttribute('data-group-delimiter') || undefined;
        e.target.value = $(this).numVal().toMoney(places, groupDelimiter);
    });


    // end - fix 20-10-2015

    //INICIO PAS20211U210100008 - jmendozas
    function remove(number_) {
        var allowDecimals = 10;
        if (isNaN(number_)){
            return;
        }
        number_= number_.toString();
        for (var i=-8; i<=-1; i++){
            var zerosString = "";
            for (var j=1; j<=Math.abs(i); j++){
                zerosString = zerosString + "0";
            }
            if (number_.substr(i) == zerosString){
                number_ = parseFloat(number_).toFixed(allowDecimals - Math.abs(i));
                return number_;
                break;
            }
        }
        number_ = parseFloat(number_).toFixed(10);
        return number_;
    }

    function removeValorUnitario(number_) {
        var allowDecimals = 10;
        if (isNaN(number_)){
            return;
        }
        number_= number_.toString();
        for (var i=-8; i<=-1; i++){
            var zerosString = "";
            for (var j=1; j<=Math.abs(i); j++){
                zerosString = zerosString + "0";
            }
            if (number_.substr(i) == zerosString){
                number_ = Math.abs(i);
                return number_;
                break;
            }
        }
        number_ = 0;
        return number_;
    }
    //FIN //PAS20211U210100008 - jmendozas

    function validaItems(){
    	recorreTablaItems();
    	renderItem();
    	
    };
    
    function recorreTablaItems() {
    	var count10=0;
    	var count18=0;
    	var countExo=0;
        var tbody = $tablaItem.find('tbody');
        tbody.empty();
        if(_Items.length<=1){
        	$modalListaItems.modal('hide');
        }else{
        	for (var i in _Items) {
        		var doc = _Items[i];
                for (var k in _itemSchema) {
                	var text = doc[k];
                	console.log("-->"+k+" - "+doc[k]);
                    if (k == 'tasaIGV'){
                    	if(text == '10.00'){
                    		count10++
                    	}
                    	if(text == '18.00'){
                    		count18++;
                    	}
                    	if(text == '0.00'){
                    		countExo++;
                    	}
                    }
                }
            }
        	if(count18>0 && count10>0){
        		alert("Todos los ítems deben tener la misma tasa de IGV: 10% o 18%")
        	}else{
        		if (countExo>0 && count10>0){
        			alert("Todos los ítems deben tener la misma tasa de IGV: 10% o 18%")
        		}else{
        			$modalListaItems.modal('hide');
        		}
        	}
        }
    };
  
    // ----------------------------------------------------------------------------------------------
    // INIT PAS20221U210600252 --> Se realiza una refactorización y corrección del impuesto del 10%
	$("input[name='rdgTipoIgv']").change(function () {
        calcularItem ();
    });

    $("input[name='rdgICBPER']").change(function () { // Radio button Impuestos de Bolsas Plasticas
        var $ICBPER = $formModalItem.find('#txtICBPER');
        var $impuestoICBPER = $formModalItem.find('#txtImpICBPER');

        if ($('#rdgICBPERsi').is(':checked')) {
            if (!$txtFechaEmision.val().length > 0) {
                alert("Ingresar la fecha de emisión para el impuesto de bolsas plásticas");
                $formModalItem.find("#rdgICBPERno").prop('checked', true);
                return;
            }

            var fecEmision = $formComprobante.find('#txtFechaEmision').val().split("/");
            var fecEmisionValue = new Date(fecEmision[2], fecEmision[1] - 1, fecEmision[0]);
            var fecVigencia = $formComprobante.find('#fecVigencia').val().split("/");
            var fecVigenciaValue = new Date(fecVigencia[2], fecVigencia[1] - 1, fecVigencia[0]);

            if (fecEmisionValue < fecVigenciaValue) {
                var fecmsg = fecVigencia[0] + "/" + fecVigencia[1] + "/" + fecVigencia[2];
                var msg = "ICBPER es invalido en comprobantes inferiores a la fecha " + fecmsg + ".";
                alert(msg);
                $formModalItem.find("#rdgICBPERno").prop('checked', true);
                return;
            } 
            if ($selMoneda.val() != 'PEN') {
                $impuestoICBPER.removeAttr('readonly');
                $impuestoICBPER.val("");
                return;
            } 
            calcularItem();

        } else { 
            $impuestoICBPER.val("0.00");
            $ICBPER.val("0.00");
            $impuestoICBPER.attr('readonly', 'readonly')
            calcularItem();
        }        
    });

    $('.calculate-total').bind('change keyup', function() {
        var idImput = $(this).attr('id');
        if(idImput==="txtValorUnitario") {
            setValorUnitarioOrImporteTotal("txtValorUnitario");
            calcularItem();
            return;
        }
        calcularItem();
    });

    $('.calculate-from-importe').on('keyup', function() {
        setValorUnitarioOrImporteTotal("txtImporte");
        calcularItem();
    })

    $("input[name='rdgTasaIGV']").change(function () {
        setIgvChangeNs();
    });

    function setValorUnitarioOrImporteTotal( id ) {
        $formModalItem.data("data", { id });
    }

    function getValorUnitarioOrImporteTotal () {
        return $formModalItem.data("data");
    }

    const setIgvChangeNs = () => {   //Cambio NS
        if ( $('#rdgTasaIGV10').is(':checked') ){
        	estaPadronGeneric(); //JBM PAS20221U210700303
            $('#rdgGravado').prop('checked', true);
            $('#rdgExonerado').prop('disabled', true);
            $tasaIGV.val("10.00");
            calcularItem();
        } else {
            $('#rdgGravado').prop('checked', true);
            $('#rdgExonerado').prop('disabled', false);
            $tasaIGV.val("18.00");
            calcularItem();
        }
    }
    
    // $("#txtValorUnitario").keyup(function() {
    // })

    const calcularItem = () => { 
        const data = getValorUnitarioOrImporteTotal();
        switch (data?.id) {
            case "txtValorUnitario":
                console.log("Calculando desde txtValorUnitario");
                calcularTotalIGV();
                break;
            case "txtImporte":
                console.log("Calculando desde txtImporte");
                calcularTotalIgvInversa();
                break;
        }
    }

    const calcularTotalIGV = () => {  // Realiza el calculo a partir del txtValorUnitario
        var cantidad = $formModalItem.find('#txtCantidad').numVal();
        var valorUnidad = $formModalItem.find('#txtValorUnitario').numVal();
        var descuento = $formModalItem.find('#txtDescuento').numVal();
        var $importe = $formModalItem.find('#txtImporte');
        var subtotal = (cantidad * valorUnidad) - descuento;
        var impuesto = getIgvTasaCurrentValue() * 0.01 * subtotal;
        const grabadoExonerado = validarGrabadoExonerado(impuesto , subtotal);
        const impuestoBolsasPlasticas = getImpuestoBolsasPlasticas();
        const total = parseFloat(grabadoExonerado + impuestoBolsasPlasticas).toFixed(10);
        $importe.val(remove(total));
    }

    const calcularTotalIgvInversa = () =>  { // Realiza el calculo a partir del txtImporte
        var cantidad = $formModalItem.find('#txtCantidad').numVal();
        var $valorUnitario = $formModalItem.find('#txtValorUnitario');
        var importe = $formModalItem.find('#txtImporte').numVal();
        var descuento = $formModalItem.find('#txtDescuento').numVal();
        const impuestoBolsasPlasticas = getImpuestoBolsasPlasticas();
        const igvTasa = getIgvTasaCurrentValue();
        
        importe = importe - impuestoBolsasPlasticas;
		var valorUnidad = ( ( importe / ( ( igvTasa * 0.01 ) +1 ) ) + descuento ) / cantidad;
        var subtotal = (cantidad * valorUnidad) - descuento;
        var impuesto = igvTasa * 0.01 * subtotal;
        validarGrabadoExonerado(impuesto , subtotal);

        if ( $('#rdgExonerado').is(':checked') ) {
            let valUnitario = importe / cantidad;
            $valorUnitario.val(Number.isFinite(valUnitario)? valUnitario: "");
            return;
		}
        $valorUnitario.val(remove(parseFloat(valorUnidad).toFixed(10)));
    }

    const getIgvTasaCurrentValue = () => {
        var $tasaIGV = $formModalItem.find('#tasaIGV');
    	var impuesto = 0;
        if ( $('#rdgTasaIGV10').is(':checked') ){
			impuesto = "10.00";
			$tasaIGV.val("10.00");
		}else{
			impuesto = $("#igvPorcentajeGlobal").val();
			$tasaIGV.val("18.00");
		}
        return impuesto;
    };

    const validarGrabadoExonerado = (impuesto, subtotal) => {
        var $txtIgv = $formModalItem.find('#txtIGV');
        var $tasaIGV = $formModalItem.find('#tasaIGV');
		var $selTipoIgv = $formModalItem.find('#selTipoIgv');

        if ( $('#rdgGravado').is(':checked') ) {
			$txtIgv.val(remove(parseFloat(impuesto).toFixed(10)));
			$selTipoIgv.val("TB00");
			return impuesto + subtotal;
		}
        if ( $('#rdgExonerado').is(':checked') ){
            $txtIgv.val("0.00");
            $tasaIGV.val("0.00");
			$selTipoIgv.val("TB01");
			return subtotal;
		}
    }

    function getImpuestoTotalICBPER() {
        var cantidad = $formModalItem.find('#txtCantidad').numVal();
        var ICBPER = $formModalItem.find('#txtICBPER').length > 0 ?   $formModalItem.find('#txtICBPER').numVal() : 0;
         return parseFloat(cantidad) * ICBPER;
    }
    
    const getImpuestoBolsasPlasticas = () => {
        var cantidad = $formModalItem.find('#txtCantidad').numVal();
        var $impuestoTotalICBPER = $formModalItem.find('#txtImpICBPER');
        var $ICBPER = $formModalItem.find('#txtICBPER');
        var impuesto = 0;
        if ($("#rdgICBPERsi").is(':checked')) {       
            if ($selMoneda.val() == 'PEN') {
                $ICBPER.val(impuestoICBPER());
                impuesto = getImpuestoTotalICBPER();
                $impuestoTotalICBPER.val(getImpuestoTotalICBPER().toFixed(2));
                $formModalItem.find('#txtCantidad').val(Math.trunc(cantidad));
                return impuesto;
            }
            if($impuestoTotalICBPER.val().length > 0){
                return $impuestoTotalICBPER.numVal();
            }
        } 
        return impuesto;
    }
    // END PAS20221U210600252
    // ----------------------------------------------------------------------------------------------
    

    $txtCodigo.add($txtDescripcion).on('typeahead:select', function(e, s) {
        var producto = _.find(_Productos, {
            txtCodigo: s.txtCodigo
        });
        if (producto) popularModalItem(producto, true, false);
    });

    $("#selTipo").on('change', function(e) {
        if (e.target.value == 'TI02') {
            $('#txtCantidad').val("1.00").attr('readonly', 'readonly');
        } else {
            $('#txtCantidad').removeAttr('readonly');
        }
    })

    var _CURR_DATE_PICKER = null;
    $('.datepicker').on('click', function(e) {
        _CURR_DATE_PICKER = $(e.target);
        $modalDatepicker.modal('show');
    });
    $datepicker.datepicker({
        // endDate: new Date(),
        startDate: new Date()
    }).on('changeDate', function(e) {
        $datepickerHidden.val(e.format());
    });
    $btnCloseDatepicker.on('click', function(e) {
        var selectedDate = $datepickerHidden.val();
        _CURR_DATE_PICKER.val(selectedDate).trigger('change');
        $datepickerHidden.val('');
        _CURR_DATE_PICKER = null;
        $modalDatepicker.modal('hide');

    });

	 $('.datepickeremision').on('click', function(e) {
         ImpuestoBolsasFecha(e);
    });
	$datepickeremision.datepicker({
        endDate: new Date(),
        //startDate: new Date()
		startDate: '-2d'
    }).on('changeDate', function(e) {
        $datepickerHiddenEmision.val(e.format());
    });
	$btnCloseDatepickerEmision.on('click', function(e) {
		localStorage.removeItem('pGeneric'); //JBM PAS20221U210700303
        var selectedDate = $datepickerHiddenEmision.val();
        _CURR_DATE_PICKER.val(selectedDate).trigger('change');
        $datepickerHiddenEmision.val('');
        _CURR_DATE_PICKER = null;
        $modalDatepickerEmision.modal('hide');
        // PAS20201U210100231
		console.log("validatePuedeEmitirRetencion");
		validatePuedeEmitirRetencion();
    });

    _.each(_tipoMedida, function(v, k) {
        $('<option/>', {
            value: k
        }).html(v).appendTo($selUnidadMedida);


    })
    _.each(_tipoProducto, function(v, k) {
            $('<option/>', {
                value: k,
                selected:(k=='TI01')
            }).html(v).appendTo($selTipo);
        })
	_.each(_tipoBeneficio, function(v, k) {
            $('<option/>', {
                value: k,
                selected:(k=='TB00')
            }).html(v).appendTo($selTipoIgv);
        })
    _.each(_monedaDescripcion, function (v, k) {
          $('<option/>', {
              value: k,
              selected:(k=='PEN')
          }).html(v).appendTo($selMoneda);
    })
    //INI-ALB: PAS20201U210100231
    _.each(_formaPago, function (v, k) {
        $('<option/>', {
            value: k,
            selected:(k=='1')
        }).html(v).appendTo($selFormaPago);
    })
    //FIN-ALB: PAS20201U210100231
    _.each(_tipoDocumentoRelacionado, function (v, k) {
          $('<option/>', {
              value: k
          }).html(v).appendTo($selTipoDocumentoRelacionado);
    })
    var ProductoCodigoBH = new Bloodhound({
        datumTokenizer: Bloodhound.tokenizers.obj.whitespace('txtCodigo', 'txtDescripcion'),
        queryTokenizer: Bloodhound.tokenizers.whitespace,
        local: [],
        identify: function(obj) {
            return obj.txtCodigo;
        },
    });
    $txtCodigo.typeahead({
            hint: true,
            highlight: true,
            minLength: 1
        }, {
          name: 'codigos',
          source: ProductoCodigoBH,
          templates: {
              suggestion: function(e) {
                  var par = $('<div/>')
                  $('<em/>').text(e.txtCodigo).appendTo(par);
                  par.append(' - ');
                  $('<span/>').text(e.txtDescripcion).appendTo(par);
                  return par;
              }
          },
        display: 'txtCodigo'
    });
    $txtDescripcion.typeahead({
        hint: true,
        highlight: true,
        minLength: 1
    }, {
        name: 'codigos',
        source: ProductoCodigoBH,
        templates: {
            suggestion: function(e) {
                var par = $('<div/>')
                $('<em/>').text(e.txtCodigo).appendTo(par);
                par.append(' - ');
                $('<span/>').text(e.txtDescripcion).appendTo(par);
                return par;
            }
        },
        display: 'txtDescripcion'
    });
    $('.tt-query').css('background-color', '#fff');

    $RUCField.on('change', function () {
      $btnContinuar.addClass('hidden');
      $btnValidarDatosReceptor.removeClass('hidden');
      $RUCField.data('pivot-valid','1');
      if($selTipoDoc.length > 0){
      if($selTipoDoc.val() == '1')
        $formBoletaDatosReceptor.valid();
      }
      else
		$formFacturaDatosReceptor.valid();
    });

    $btnContinuar.on('click', function () {

        if($("#selFormaPago").val()==""){//PAS20211U210700145-EBV-FIX
			alert("Seleccionar una Forma de Pago");
			return;
		}

		if($("#selFormaPago").val()=='2'){
			if($direccionFiscal.val() == ""){
				if($('select[name=tipoDocumento]').val() != '1'){//PAS20211U210700145 - EABV CPE-99-P5
					alert("Ingresar dirección del receptor");
					return;
				}
			}
		}

        $btnContinuar.addClass('hidden');
        $RUCField.attr('disabled', 'disabled')
        $razonSocial.attr('disabled', 'disabled')
        $selTipoDoc.attr('disabled', 'disabled')
        $RUCField.attr('disabled', 'disabled')
        $selFormaPago.attr('disabled', 'disabled')//ALB-PAS20201U210100231
        $panelFormaPago.find('.panel-collapse').collapse('hide');//ALB-PAS20201U210100231
        $panelFacturaDatosReceptor.find('.panel-collapse').collapse('hide');
        $panelDatosComprobante.removeClass('hidden').find('.panel-collapse').collapse('show');
        $panelDocumentosRelacionados.removeClass('hidden').find('.panel-collapse').collapse('show');
        $panelItems.removeClass('hidden').find('.panel-collapse').collapse('show');
        $panelRetencion.removeClass('hidden').find('.panel-collapse').collapse('show');//ALB-PAS20201U210100231
        $panelResumen.removeClass('hidden').find('.panel-collapse').collapse('show');

        $("#buttons").removeClass('hidden');
        //renderFormaPago();//ALB-PAS20201U210100231
        renderDireccionesReceptor();
		// PAS20201U210100151
        renderDireccionesEmisor();
        prefetchProductos();
        renderDocumentoRelacionado()
        renderItem();
        refrescarResumen();
        //INI-OPV: PAS20201U210100231
        renderInfCredito();
		if($("#selFormaPago").val()=='2')
		{
          var tipoDoc = $('select[name=tipoDocumento]').val();//AFT-PAS20211U210700145
          if(tipoDoc==6 || tipoDoc==0) {
              $panelCredito.removeClass('hidden').find('.panel-collapse').collapse('show');
          } else{
          	$panelCredito.addClass('hidden');
		  }
        }
		//FIN-OPV: PAS20201U210100231
		// PAS20201U210100231
		console.log("validatePuedeEmitirRetencion");
		validatePuedeEmitirRetencion();
    });

     // fix 18-10-2015
    $selMoneda.on('focus', function (e) {
        this.dataset.previous = this.value;
    });





    $selMoneda.on('change', function (evt) {
        var prev = $(this).attr('data-previous')
        if (_Items.length > 0 && this.value != prev) {
            alert('No puede cambiar de moneda, existen items agregados');
            this.value = prev;
            return;
        }
        else {

            $(".simbolo-moneda").html(_moneda[this.value])
            ProductoCodigoBH.clear();
            var filtered = _.filter(_Productos, function (e) {
                return _.has(e.selMoneda, evt.target.value)
            })
            ProductoCodigoBH.add(filtered);
        }
    })
    // end - fix 18-10-2015

    //INI-ALB: PAS20201U210100231
    $btnMostrarModalRegistrarDireccion.on('click', function (e) {
        $modalDireccionFiscal.modal('show');
    });
    //FIN-ALB: PAS2201U210100231

    $btnMostrarModalItems.on('click', function (e) {
    if(!$formComprobante.valid())
            return;
      if(!$selMoneda.val()){
        alert('Seleccione la Moneda');
        return;
      }
      $modalListaItems.modal('show');
      renderItem();
    });

    $btnMostrarModalDR.on('click', function (e) {
      $modalListaDocumentoRelacionado.modal('show');
    });

    $btnPreview.on('click', function (e) {
    	if(!$formComprobante.valid())
            return;

       if(!$formItem.valid()){
            return;
		}

		//INI-OPV: PAS20201U210100231 Cambios Factoring Habilitados
		if($cambiosFactoringHabilitados=="1"){

			if($txtBaseImponible.val().length>0){
				if(!$formretencion.valid())
				return;
			}
			//INI-OPV: PAS20201U210100231 Ini InfCredito
			$ValidacionBtnAgregarCuotas=false;
			//[PAS20211U210700145][anunez][2021.11.08]
			if($("#selFormaPago").val()=='2' && ( $('select[name=tipoDocumento]').val() == 6 || $('select[name=tipoDocumento]').val() == 0 ) ) {
				$vistaPreliminar = true;
				if(!$formInfCredito.valid()){
					$vistaPreliminar = false;
					console.log("no pasó formInfCredito");
					return;
				}
				$vistaPreliminar = false;
			}
			//FIN-OPV:PAS20201U210100231
		}
		//INI-OPV: PAS20201U210100231 Cambios Factoring Habilitados
        //validar monto
       var montototal=  $('#importe-total').text();
       var montobase = $txtBaseImponible.val();

       /*if($puedeEmitirRetencion.val()=='1'){
            if(Number(montobase)>Number(montototal)){
                alert("el monto base no puede ser mayor al importe total de la factura");
            }else{
                showPreview();
            }
       }else{
        showPreview();
       }
       */
       showPreview();

    });

    $btnVolverFactura.on('click', function (e) {
        $('#root-panels').removeClass('hidden')
        $("#panel-preview").addClass('hidden');
    })

    $btnEmitirFactura.on('click', function (e) {
        /// quickfix 15-10-2015
    	localStorage.removeItem('pGeneric');// PAS20221U210700303 JBM
        if (!confirm('\u00BFEsta seguro de emitir su comprobante?')) {
            return;
        }
        $btnEmitirFactura.prop('disabled', true);
        $modalPreloader.modal('show');
        /// end - quickfix 15-10-2015

        console.log("Data a enviar");
        console.log(_datosEnvio);

        var url = "emitirfesimp.do?action=grabarComprobante";

        $.ajax({
            data: {
                variable: JSON.stringify(_datosEnvio),
            },
            method: 'post',
            //contentType: "application/text; charset=UTF-8",
            dataType: 'json',
            url: url,
        }).done(function (data, textStatus, jqXHR) {
            if (console && console.log) {
                $modalPreloader.modal('hide');
                window.location.href = "emitirfesimp.do?action=mostrarFacturaGenerada";
            }
        }).fail(function (jqXHR, textStatus, errorThrown) {
            if (console && console.log) {
                console.log("La solicitud a fallado: " + textStatus);
            }
			$modalPreloader.modal('hide');
			$btnEmitirFactura.prop('disabled', false);
			alert('Se presentó un inconveniente al emitir el comprobante. Verifique las consultas. Inténtelo en unos minutos.');
            return;
        });
    })


    $selTipoDocumentoRelacionado.on('change', function (e) {
        $txtSerie.parent().toggleClass('hidden', e.target.value == '00')
    })

    $selTipoDoc.on('change', function (e) {
        $razonSocial.parent().toggleClass('hidden', e.target.value == '1')

        $RUCField.attr('maxlength', e.target.value == '1' ? 8 : 15)
        if(e.target.value == '1')
            $txtRazonSocial.attr('readonly', 'readonly')
        else
            $txtRazonSocial.removeAttr('readonly')
    })
    /*
     *  :::: SETUP :::: END
     */
    /*
     *  :::: Form Validate :::: START
     */
    $formCatalogo.validate(_.extend(window._validatorWallSettings, {
        debug: true,
        rules: {
            txtCodigo: {
                required: true,
                minlength: 11
            },
            txtDescripcion: {
                required: true
            }
        },
        // estos mensajes estan aqui porque son d&iacute;n&aacute;micos respecto al html
        messages: {
            txtCodigo: "Ingrese el codigo",
            txtDescripcion: "Ingrese la descripcion"
        },
        submitHandler: function(form) {
            form.submit();
            /*
            var url = '';
            $.ajax({
              method: 'post',
              dataType: 'json',
              complete: function () {
                window.location.href = "tabla-resultado.html"
              }
            })

            */
        }
    }));
    //INI-ALB: PAS20201U210100231
    $formModalDireccionFiscal.validate(_.extend(window._validatorWallSettings, {
        debug: true,
        rules: {
            direccionDepartamento: {
                required : true,
            },
            direccionProvincia: {
                required: true,
            },
            direccionDistrito: {
                required: true,
            },
            txtDetalleDireccion: {
                required: true,
                maxlength:200,
				minlength: 5,
                validStr: true,
            },
        },
        // estos mensajes estan aqui porque son d&iacute;n&aacute;micos respecto al html
        messages: {
            direccionDepartamento: {
                required: 'Seleccione el departamento'
            },
            direccionProvincia: {
                required: 'Seleccione la provincia'
            },
            direccionDistrito: {
                required: 'Seleccione el distrito'
            },
            txtDetalleDireccion: {
                required: 'Registre la direcci&oacute;n',
                maxlength: 'S&oacute;lo se permiten 200 caracteres de longitud',
				minlength: 'Debe registrar como m&iacute;nimo 5 caracteres'
            },
        },

       submitHandler: function(form) {
		    console.log("submitHandler $formModalDireccionFiscal");
            renderDireccionFiscal();
            var data = $(form).last().serializeObject();

            // _direccionDepartamento = data.direccionDepartamento;
			_direccionDepartamento = $('#direccionDepartamento').find('option[value=' + $('#direccionDepartamento').val() + ']').text();
            // _direccionProvincia = data.direccionProvincia;
			_direccionProvincia = $('#direccionProvincia').find('option[value=' + $('#direccionProvincia').val() + ']').text();
            // _direccionDistrito = data.direccionDistrito;
			_direccionDistrito = $('#direccionDistrito').find('option[value=' + $('#direccionDistrito').val() + ']').text();
            // _txtDetalleDireccion = data.txtDetalleDireccion.toUpperCase();
            _txtUbigeo = data.direccionDistrito;

            var direccionFiscal = data.txtDetalleDireccion.toUpperCase() +" "+
            $('#direccionDepartamento').find('option[value=' + $('#direccionDepartamento').val() + ']').text() +" "+
            $('#direccionProvincia').find('option[value=' + $('#direccionProvincia').val() + ']').text() +" "+
            $('#direccionDistrito').find('option[value=' + $('#direccionDistrito').val() + ']').text();
			console.log("direccionFiscal=" + direccionFiscal);

			_txtDetalleDireccion = direccionFiscal;
            $direccionFiscal.val(direccionFiscal);
            $modalDireccionFiscal.modal('hide');
        }
    }))
    //FIN-ALB: PAS20201U210100231

    $formModalDocumentoRelacionado.validate(_.extend(window._validatorWallSettings, {//frank
        debug: true,
        rules: {
            selTipoDocumentoRelacionado: {
                required: true,
            },
            txtSerie: {
				validSerieDocRel: { depends:
								function(element){
									if($selTipoDocumentoRelacionado.val() == "09"  ){
										return true;
									}else{
										return false;
									}
								}
				},
                //number:true,
				//PAS20221U210700300 JBM go
				validSerieDocRel31: { depends:
							function(element){
									if($selTipoDocumentoRelacionado.val() == "31"   ){
										return true;
									}else{
										return false;
									}
							}
				},
						
				validSerieDocRelG9: { depends:
							function(element){
									if($selTipoDocumentoRelacionado.val() == "G9"   ){
										return true;
									}else{
										return false;
									}
							}
				},						
				//PAS20221U210700300 JBM end	
                maxlength:4,
                required: function () {
                    return $selTipoDocumentoRelacionado.val() != '00'
                },
            },
            
            txtNumero: {
            	//PAS20221U210700300 JBM go
            	validNumber : { depends:
					function(element){
	            		if($selTipoDocumentoRelacionado.val() == "31" || $selTipoDocumentoRelacionado.val() == "09" || $selTipoDocumentoRelacionado.val() == "G9" ||  $selTipoDocumentoRelacionado.val() != "00" ){
							return true;
	//						required: true,
	            		}else{
								return false;
	//							required: false,
						}
					}
				},
				//PAS20221U210700300 JBM end
                maxlength:10
            },
            txtDescripcion: {
                required: true,
            },
        },
        // estos mensajes estan aqui porque son d&iacute;n&aacute;micos respecto al html
        messages: {
            selTipoDocumentoRelacionado: {
                required: 'Seleccione el tipo de documento'
            },
            txtSerie: {
                number:"Ingrese s&oacute;lo n&uacute;meros",
                required: 'Ingrese la Serie'
            },
            txtNumero: {
                required: 'Ingrese el n&uacute;mero',
                maxlength: 'S&oacute;lo se permiten 10 caracteres de longitu'
            },
            txtDescripcion: {
                required: 'Ingrese la Descripci&oacute;n'
            },
        },

       submitHandler: function(form) {
/// START eliminacion de duplicados //////
       var data = $(form).first().serializeObject();

       var criteria = {
            selTipoDocumentoRelacionado: data.selTipoDocumentoRelacionado,
            txtNumero: parseInt(data.txtNumero)
       };
     //PAS20221U210700300 JBM go
       var docRelac = _DocumentosRelacionados.map(item => {
        	let Numero = parseInt(item.txtNumero);
        	 return {...item, txtNumero: Numero };
       });
     //PAS20221U210700300 JBM end
       if(data.selTipoDocumentoRelacionado == '00'   ){
             criteria.txtSerie = data.txtSerie;
       }
           
       duplicated = !! _.findWhere(_DocumentosRelacionados, criteria);
       duplicated = !! _.findWhere(docRelac, criteria); //PAS20221U210700300 JBM
       if(duplicated){
    	   alert('El registro ya ha sido ingresado');
           return;
        }

/// END eliminacion de duplicados //////
            data.txtSerie = data.txtSerie.toUpperCase(); //
            data.rowId = _.uniqueId('dr-');
            agregarDocumentoRelacionado(data);
            $modalDocumentoRelacionado.modal('hide');
        }
    }))

    $formModalItem.validate(_.extend(window._validatorWallSettings, {
        debug: true,
		//PAS20201U210100231-OPV Se agrega Combo escondido hint
		ignore: ':hidden, .tt-hint',
        rules: {
            txtCantidad: {
                required: true,
                moreThan: 0 ,
                digits: {
                    depends: function() {
                        // if ($('#rdgICBPERsi').is(':checked')) {
                        //     var cantidad = $formModalItem.find('#txtCantidad').numVal();
                        //     console.log("cantidad=" ,cantidad);
                        //     var dato =cantidad.toString();
                        //     console.log("dato=" ,dato);
                        //     var arg =dato.split(".");
                        //     console.log("arg=" ,arg);
                        //     if(arg.length != 1 ){
                        //         return true;
                        //     }else{
                        //         return false;
                        //     }
                        // } else {
                        //     return false;
                        // }
                    }
                }
            },
            selUnidadMedida: {
                required: true,
            },
            txtCodigo: {
                required: true,
                maxlength: 15
            },
            txtDescripcion: {
                required: true,
                maxlength: 200,
            },
            txtValorUnitario: {
                required: true,
                moreThan: 0
            },
            txtImporte: {
                moreThan: 0
            },
            /*txtIGV: {
                moreThan: 0
            },*/
            txtDescuento: {
                required: false,

            },
            selTipo: {
                required: true,
            },
            txtImpICBPER: {
                required :{
                    depends : function(){
                        if ($selMoneda.val() != 'PEN') {
                                return true;
                        }else {
                            return false;
                        }
                    }
                },
                min:{
                    depends: function(){
                        if ($('#rdgICBPERsi').is(':checked')) {
                            console.log("checked4");
                            if ($selMoneda.val() != 'PEN') {
                                return 0;
                            }
                        }
                    }
                }
            }
        },
        // estos mensajes estan aqui porque son d&iacute;n&aacute;micos respecto al html
        messages: {
            txtCantidad: {
                required: 'Ingrese la Cantidad',
                moreThan: 'La cantidad debe ser mayor a 0',
                digits: 'La cantidad debe ser un valor entero'
            },
            selUnidadMedida: {
                required: 'Seleccione Unidad de Medida',
            },
            txtCodigo: {
                required: 'Ingrese el C&oacute;digo',
            },
            txtDescripcion: {
                required: 'Ingrese la Descripci&oacute;n',
            },
            txtValorUnitario: {
                required: 'Ingrese el Valor Unitario',
                moreThan: 'El valor del precio unitario no es  v&aacute;lido'
            },
            txtDescuento: {
                required: 'El descuento es requerido',
                moreThan: 'El valor del descuento no es  v&aacute;lido'
            },
            /*txtIGV: {
                required: 'El Igv es requerido',
                moreThan: 'El valor del igv no es  v&aacute;lido'
            },*/
            txtImporte: {
                required: 'El Importe es requerido',
                moreThan: 'El valor del importe no es  v&aacute;lido'
            },
            selTipo: {
                required: 'Seleccione el Tipo de Servicio',
            },
            txtImpICBPER: {
                required: 'El Importe ICBPER es requerido',
                min: 'El valor del importe ICBPER no es v&aacute;lido'
            }
        },
        submitHandler: function(form) {
            var data = $(form).last().serializeObject();
            if (_itemEditando) {
                console.log("edit");
                editarItem({
                    itemId: _itemEditando
                }, data);
            } else {
                console.log("add");
                data.itemId = _.uniqueId('');
                agregarItem(data);
            }
            $modalItem.modal('hide');
            _itemEditando = false;
            refrescarResumen();
            renderItem();
        }
    }));

    $formBoletaDatosReceptor.validate(_.extend(window._validatorWallSettings, {
        debug: true,
        /*
        onkeyup: false,
        onchange: false,
        onclick: false,
        onfocusout: false,
        */
        rules: {
            txtDocumento: {
                required: true,
                minlength: function () {
                    return $selTipoDoc.val() == '1' ? 8 : 2;
                },
                maxlength: function () {
                    return $selTipoDoc.val() == '1' ? 8 : 15;
                }
            },
            txtRazonSocial: {
                required: function ( ) {
                    return $selTipoDoc.length > 0 && $selTipoDoc.val() != '1'
                }
            }
        },
        // estos mensajes estan aqui porque son d&iacute;n&aacute;micos respecto al html
        messages: {},
        submitHandler: function(form) {
            if($selTipoDoc.val() == '1'){
                $modalPreloader.modal('show');
                validarExistenciaDNI();
            }else{
                $btnContinuar.removeClass('hidden');
                $btnValidarDatosReceptor.addClass('hidden');

            }

        }
    }));

    validatorForm = $formFacturaDatosReceptor.validate(_.extend(window._validatorWallSettings, {
        debug: true,
        /*onkeyup: false,
        onchange: false,
        onclick: false,
        onfocusout: false,*/
        rules: {
            txtRuc: {
                required: true,
				// comentar para habilitar el debug, no validar ruc
				minlength:  function(element){
								var ind1 = $('input[name=opcDeductible]:checked').val();
								var ind2 = $('select[name=tipoDocumento]').val();
								if(ind1==1 && ind2==1){ return 8;}
								else if(ind1==0){ return 11;}
							},
				//console.log("seleccionado"+seleccionado);
				maxlength:  function(element){
								var ind1 = $('input[name=opcDeductible]:checked').val();
								var ind2 = $('select[name=tipoDocumento]').val();
								if(ind1==1 && ind2==1){ return 8;}
								else if(ind1==0){ return 11;}
							},
				//validRUC: true,
				validRUC:   { depends:
								function(element){
									var ind1 = $('input[name=opcDeductible]:checked').val();
									var ind2 = $('select[name=tipoDocumento]').val();
									if(ind1==1 && ind2==1){
										return false;
									}else{
										return true;
									}
								}
							},
				validDOCRUC: { depends:
								function(element){
									var ind1 = $('input[name=opcDeductible]:checked').val();
									var ind2 = $('select[name=tipoDocumento]').val();
									//console.log("ind1"+ind1);
									//console.log("ind2"+ind2);
									if(ind1==1 && ind2==1){
										return false;
									}else if(ind1==0){
										return false;
									}else if(typeof ind1 == 'undefined'){
										//console.log("ind1 indefinido");
										return false;
									}else{
										return true;
									}
								}
							},
                validpivot: true
// FIN MODO DEBUG
            }
        },
        // estos mensajes estan aqui porque son d&iacute;n&aacute;micos respecto al html
        messages: {
			txtRuc: {
				minlength: function(element){
						     var seleccionado = $('input[name=opcDeductible]:checked').val();
							 if(seleccionado==1){ return "Ingresar DNI en el formato correcto";}
							 else if(seleccionado==0){ return "Ingresar RUC en el formato correcto";}
						    },
				maxlength: function(element){
						     var seleccionado = $('input[name=opcDeductible]:checked').val();
							 if(seleccionado==1){ return "Ingresar DNI en el formato correcto";}
							 else if(seleccionado==0){ return "Ingresar RUC en el formato correcto";}
						    }
			}
		},
        submitHandler: function(form) {

            $modalPreloader.modal('show');
            validarExistenciaRUC();
			// PAS20201U210100151
            listaDireccionesEmisor();

        }
    }));

    $formretencion.validate(_.extend(window._validatorWallSettings, {
        rules: {
            txtBaseImponible:{
                moreThan: 0,
                lessThan: function(element){
					if ($selMoneda.val() == 'PEN') {
                        if(Number($('#txtBaseImponible').numVal())>$ImporteTotal )
                        {
                            return true;
                        }else{
                            return false;
                        }
					}else{
						return false;
					}
                }
            }

        },
        messages: {

            txtBaseImponible:{
                moreThan: 'El monto base debe ser mayor a cero',
                lessThan: "El monto base no puede ser mayor al importe total de la factura"
            }
        }
    }))


    $formItem.validate(_.extend(window._validatorWallSettings, {
        rules: {
            hiddenHelperItem: {
                moreThan: 0,
                lessThan: 10
            }
        },
        ignore: '.ignored-field',
        messages: {
            hiddenHelperItem: {
                moreThan: function () {
                    if($selTipoDoc.length == 0)
                        return "Agregue un item a la factura"
                    else
                        return "Agregue un item a la boleta"
                },
                lessThan: function () {
                    if($selTipoDoc.length == 0)
                        return "Solo se permiten 10 items en la factura."
                    else
                        return "Solo se permiten 10 items en la boleta."
                }
            }
        }
    }))

    $formComprobante.validate(_.extend(window._validatorWallSettings, {
        rules: {
			txtFechaEmision: {
                required: true,
				validIgvVigente: { depends:
									function(element){
										var femision = $txtFechaEmision.val();
										var fminigv = $("#fechaMinIgvPorcentaje").val();
										var fmaxigv = $("#fechaMaxIgvPorcentaje").val();

										console.log("fechaMinIgvPorcentaje_"+fminigv);
										console.log("fechaMaxIgvPorcentaje_"+fmaxigv);
										console.log("femision_"+femision);

										if(femision > fminigv  && femision < fmaxigv){
											console.log("-");
											return false;
										}else{
											console.log("asignando otro igv diferente al actual");
											return true;
										}
									}
								 },
				validPresLibro: { depends:
									function(element){
										var femision = $txtFechaEmision.val();
										var factual = formatFecha(new Date);
										if(femision.substring(3,5) != factual.substring(3,5)){
											console.log("true");
											return true;
										}else{
											console.log("false");
											return false;
										}
									}
								}
            },
            selMoneda: {
                required: true
            },
            txtLugarEntrega: {
                required: function (argument) {
                    return $selTipoDoc.length == 0;
                }
            }

        },
        messages: {
			txtFechaEmision: {
                required: "Ingrese la Fecha de Emisi&oacute;n"
            },
            selMoneda: {
                required: "Seleccione la Moneda"
            },
            txtLugarEntrega: {
                required: "Ingrese el Lugar de entrega"
            }

        }
    }));


    function SoloNumeroDecimalTwo(e, field) {
        key = e.keyCode ? e.keyCode : e.which
        // backspace
        if (key == 8) return true
        // 0-9 a partir del .decimal
        if (field.value != "") {
            if ((field.value.indexOf(".")) > 0) {
                //si tiene un punto valida dos digitos en la parte decimal
                if (key > 47 && key < 58) {
                    if (field.value == "") return true
                    //regexp = /[0-9]{1,10}[\.][0-9]{1,10}$/
                    regexp = /[0-9]{2}$/;//PAS20211U210100008 - jmendozas
                    return !(regexp.test(field.value))
                }
            }
        }
        // 0-9
        if (key > 47 && key < 58) {
            if (field.value == "") return true
            regexp = /[0-9]{10}/
            return !(regexp.test(field.value))
        }
        // .
        if (key == 46) {
            if (field.value == "") return false
            regexp = /^[0-9]+$/
            //PAS20201U210100231- reemplazar coma -OPV
            var remplazo=field.value;
            remplazo=remplazo.replaceAll(/,/g, "");
            //return regexp.test(field.value)
            return regexp.test(remplazo);
            //PAS20201U210100231-OPV
        }
        // other key
        return false
    }

	function SoloNumeroDecimal(e, field) {
        key = e.keyCode ? e.keyCode : e.which
            // backspace
        if (key == 8) return true
            // 0-9 a partir del .decimal
        if (field.value != "") {
            if ((field.value.indexOf(".")) > 0) {
                //si tiene un punto valida dos digitos en la parte decimal
                if (key > 47 && key < 58) {
                    if (field.value == "") return true
                    //regexp = /[0-9]{1,10}[\.][0-9]{1,10}$/
                    regexp = /[0-9]{10}$/;//PAS20211U210100008 - jmendozas
                    return !(regexp.test(field.value))
                }
            }
        }
        // 0-9
        if (key > 47 && key < 58) {
            if (field.value == "") return true
            regexp = /[0-9]{10}/
            return !(regexp.test(field.value))
        }
        // .
        if (key == 46) {
            if (field.value == "") return false
            regexp = /^[0-9]+$/
			//PAS20201U210100231- reemplazar coma -OPV
			var remplazo=field.value;
			remplazo=remplazo.replaceAll(/,/g, "");
	        //return regexp.test(field.value)
			return regexp.test(remplazo);
			//PAS20201U210100231-OPV
        }
        // other key
        return false
    }

	$.validator.addMethod("validPresLibro", function(value, element, param) {
        var valid = validPresLibro(value);
		console.log("valid="+valid);
        $(element).data('validPresLibro', valid ? '1' : '0');
		return valid;
    }, "Ya se present&oacute; el libro en ese periodo.");

	function validPresLibro(valor){
		var retorno = true;
		var url = 'emitirfesimp.do?action=validarPresLibro';
		var formData = { txtRUC: $RUCField.val(), txtFechaEmision: valor};

      $.ajax({
        url: url,
        type: "POST",
        data: formData,
        dataType: 'json',
		async: false,
        success: function(data) {

			console.log("data.nlibro_"+data.nlibro);
			if(data.nlibro != 0){
				$txtFechaEmision.data('pivot-valid', '0');
				console.log("==>false");
				retorno = false;
			}else{
				console.log("==>true");
				retorno = true;
			}
        },
        error: function () {
          alert('error');
          $txtFechaEmision.data('pivot-valid', '0');
        },
        complete: function () {
          $modalPreloader.modal('hide');
        }

      });
	  return retorno;
    }


	$.validator.addMethod("validIgvVigente", function(value, element, param) {
        var valid = validIgvVigente(value);
        $(element).data('validIgvVigente', valid ? '1' : '0');
		return valid;
    }, "Ingresar nuevamente los items.");

	function validIgvVigente(valor){

		var retorno = true;
		var url = 'emitirfesimp.do?action=recuperarIgvConFecha';
		var formData = { fechaEmision: valor };

      $.ajax({
        url: url,
        type: "POST",
        data: formData,
        dataType: 'json',
		async: false,
        success: function(data) {

			console.log("data.fechaMinIgv_"+data.fechaMinIgv);
			console.log("data.fechaMaxIgv_"+data.fechaMaxIgv);

			console.log("data.tasaIgv="+data.tasaIgv);
			console.log("igvPorcentajeGlobal="+$("#igvPorcentajeGlobal").val() );

			console.log("_Items="+_Items.length);

			if ( ($('#igvPorcentajeGlobal').val() != data.tasaIgv)  &&  _Items.length > 0){
				var mensajeCambioIGV = "La fecha de emisi\u00f3n seleccionada tiene otro valor de IGV (" + Math.floor(data.tasaIgv) + "%), tendr\u00e1 que volver a ingresar los items \u00BFDesea Continuar?";

				if (confirm(mensajeCambioIGV)){
					console.log("borrando items");

					eliminarItemsAll();

					asignarIGVDiferente(data.tasaIgv, true, data.fechaMinIgv, data.fechaMaxIgv);
					retorno = false;
				}else {
					//this.setFechaEmisionPrevia();
					//response = false;
					//$txtFechaEmision.val(formatFecha(new Date));
					retorno = false;
				}
			} else {
				asignarIGVDiferente(data.tasaIgv, true, data.fechaMinIgv, data.fechaMaxIgv);
			}

			/*if(data.tasaIgv != 0){
				//$txtFechaEmision.data('pivot-valid', '0');
				console.log("==>false");
				retorno = false;
			}else{
				console.log("==>true");
				retorno = true;
			}*/
        },
        error: function () {
          alert('error');
          //$txtFechaEmision.data('pivot-valid', '0');
        },
        complete: function () {
          $modalPreloader.modal('hide');
        }

      });
	  return retorno;
    }


	function eliminarItemsAll(){

		for (var i in _Items) {
            var doc = _Items[i];
			eliminarItem({
            itemId: doc.itemId
			});
		}
		refrescarResumen();
	}

	function asignarIGVDiferente(tasaIgv, mostrarMensajes, fechaMinIgv, fechaMaxIgv){

		var retorno = true;
		var url = 'emitirfesimp.do?action=asignarIGVDiferente';
		var formData = { igvDiferente: tasaIgv };

		$.ajax({
			url: url,
			type: "POST",
			data: formData,
			dataType: 'json',
			async: true,
			success: function(data) {
				document.getElementById("lblIgvPorcentaje").innerHTML = "Total IGV";
				//document.getElementById("lblIgvPorcentaje").innerHTML = "Total IGV (" + Math.floor(tasaIgv) + "%)";
				$("#igvPorcentajeGlobal").val(tasaIgv);
				$("#fechaMinIgvPorcentaje").val(fechaMinIgv);//
				$("#fechaMaxIgvPorcentaje").val(fechaMaxIgv);//
			},
        error: function () {
          alert('error');
          //$txtFechaEmision.data('pivot-valid', '0');
        },
        complete: function () {
          $modalPreloader.modal('hide');
        }

      });
	  return retorno;
    }


    /*
     *  :::: Form Validate :::: END
     */
// })(window, jQuery, _);

/*********** BOLSAS PLASTICAS ********/

function initICBPER() {
    var $ICBPER = $formModalItem.find('#txtICBPER');
    var $impuestoICBPER = $formModalItem.find('#txtImpICBPER');

    if ($selMoneda.val() == 'PEN') {
        $ICBPER.val("0.00");
        $impuestoICBPER.val("0.00");
        $impuestoICBPER.attr('readonly', 'readonly')
    } else {
        $impuestoICBPER.attr('readonly', 'readonly')
        $impuestoICBPER.val("0.00");
        $ICBPER.val("0.00");
    }
    $formModalItem.find("#rdgICBPERno").prop('checked', true);
}

function impuestoICBPER() {
    var fecEmision = $formComprobante.find('#txtFechaEmision').val().split("/");
    var currentyear = new Date(fecEmision[2], fecEmision[1] - 1, fecEmision[0]).getFullYear();
    var valorICBPER = currentyear > 2023 ? _impuestoICBPER[2023] : _impuestoICBPER[currentyear];
    return valorICBPER;
}


function ImpuestoBolsasFecha(e) {
    var mostrar = $formComprobante.find('#tributoNrus').val();
    var condicion = true;
    if (_Items.length > 0 && mostrar != "1") {
        for (var i = 0; i < _Items.length; i++) {
            if (!(_Items[i].txtICBPER === "0.00")) {
                condicion = false;
                break;
            }
        }
    }
    if (!condicion) {
        var msg = "No puede cambiar la fecha de emisión, existen ítems agregados con ICBPER";
        alert(msg);
        return;
    } else {
        _CURR_DATE_PICKER = $(e.target);
        $modalDatepickerEmision.modal('show');
    }
}

function validatePuedeEmitirRetencion(){

    var fechaEmision =$txtFechaEmision.val();
	//var tipoDocumento = $("#globaltipoDocumento").val(); ;
	var tipoDocumento = $("#globaltipoDocumento").val();
    var numeroDocumento =  $RUCField.val();
    //peticion de validacion
    var url = 'emitirfesimp.do?action=validarEsAgenteRetencion';
	var tipoDocumento = $("#globaltipoDocumento").val(); ;
	var formData = { tipoDocumento:tipoDocumento,numeroDocumento: numeroDocumento, fecEmision: fechaEmision};

      $.ajax({
        url: url,
        type: "POST",
        data: formData,
        dataType: 'json',
		async: false,
        success: function(response) {

            //console.log(data);
            if(response.codeError == 0) {
                if(response.data=="1"){
                    $panelRetencion.removeClass('hidden').find('.panel-collapse').collapse('show');
                    $puedeEmitirRetencion.val(response.data);
                }else{
                    $puedeEmitirRetencion.val(response.data);
					$panelRetencion.addClass('hidden');

                }

			} else {
                $puedeEmitirRetencion.val("0");
				$panelRetencion.find('.panel-collapse').collapse('hide');
            }

        },
        error: function () {
          alert('error');
          $txtFechaEmision.data('pivot-valid', '0');
        },
        complete: function () {

        }

      });


}

function calculaRetencion(){

        //var $txtMontoRetencion =$('#txtMontoRetencion');
        var baseRetencion = $txtBaseImponible.numVal();
		var porcentajeRetencion = $txtPorcentaje.numVal();
		var montoRetencion = 0;

        montoRetencion = baseRetencion*porcentajeRetencion/100.00;

		try {
        $txtMontoRetencion.val(Number.parseFloat(Math.round(montoRetencion*100))/100);
		} catch (error) {
			// problema con ie
			console.log(error);
			$txtMontoRetencion.val(Math.round(montoRetencion*100)/100);
		}
}



	//--------------Formulario y metodos Inf-CREDITO-----------------------

	//METODO btnMostrarModalCredito

	//Evento Boton para Abrir Modal InfCredito desde Factura pantalla principal
	$btnMostrarModalCredito.on('click', function (e) {
	  //Cargar Datos del Modal Monto Pendiente de Pago
	  $('#txtModalMontoPendientePago').val($('#txtMontoNeto').val());
	  if($("#selFormaPago").val()=='2'){
		$ValidacionBtnAgregarCuotas=true;
		if(!$formInfCredito.valid()){
			return false;
		}
    	$modalInfCredito.modal('show');
	  }else{
		  showMensajeConfirmacion('Debe seleccionar forma de pago Cr&eacute;dito');
	  }

    });




	//INI-OPV:PAS20201U210100231-Validaciones para Inf-CREDITO

	//PAS20201U210100231-OPV
	function validarFormInfCreditoFormaPagoCreditoObligatoria(){
		if($("#selFormaPago").val()=='2')
		{
			pasoValidacionFormaPago	= false	;
			return true;
		}
		$PasoValidacionAntes= true;
		return false ;
	}
	//PAS20201U210100231-OPV
	function validarFormInfCreditoFechaObligatoria(){
		var fechaString=$('#txtFechaEmision').val();
		if(fechaString=='')
		{
			$PasoValidacionAntes= false	;
			return true;
		}
		$PasoValidacionAntes= true;
		return false ;
	}
	//PAS20201U210100231-OPV
	function validarFormInfCreditoAlmenosUnItemEnTablaItems(){
		if(_Items.length==0)
		{
			$PasoValidacionAntes= false	;
			return true;
		}
		$PasoValidacionAntes= true;
		return false ;
	}

	//PAS20201U210100231-OPV
	function validarFormInfCreditoDespuesMinimoCuotas(){
		if($PasoValidacionAntes && $ValidacionBtnAgregarCuotas==false){
    		if(_ItemsInfCredito.length==0 )
			{
				return true;
			}
		}
		return false;
	}
	//PAS20201U210100231-OPV fecha de Emision mayor a fecha de vencimiento
	function validarFormInfCreditoDespuesMinimoFechaVencimiento(){
		var existeError=false;
		if($PasoValidacionAntes && $ValidacionBtnAgregarCuotas==false){
    		if(_ItemsInfCredito.length>0 )
			{
				 var fechaEmision= stringToDate($('#txtFechaEmision').val(),"dd/MM/yyyy","/");
				//VALIDAR SI EXISTEN CUOTAS CON FECHA DE VENCIMIENTO MENOR
				//OPV-INI-Compatibilidad Internet Explorer
				//_ItemsInfCredito.forEach(element=>{
				for (i=0; i < _ItemsInfCredito.length; i++) {
					var element=_ItemsInfCredito[i];
					if(fechaEmision>element.fechaVencimientoDate){
						existeError= true;
					}

				};
				//OPV-FIN-Compatibilidad Internet Explorer
			}
		}
		return existeError;
	}
	//PAS20201U210100231-OPV
	function validarFormInfCreditoSumaCuotas(){
		if($PasoValidacionAntes){
			if($ImporteTotal==0)
			{
				return true;
			}

			if($SumaMontoInfCredito>$ImporteTotal && $ValidacionBtnAgregarCuotas==false)
			{
				return true;
			}
		}
		return false;
	}
	//INI-OPV:PAS20201U210100231
	function validarFormInfCreditoMontoNeto(){
		if($PasoValidacionAntes){
			if($ImporteTotal==0) {
				return true;
			}
			if(Number($('#txtMontoNeto').numVal())>$ImporteTotal ) {
				return true;
			}
		}
		return false;
	}

	//FIN-OPV:PAS20201U210100231-Validaciones para InfCredito
	$formInfCredito.validate(_.extend(window._validatorWallSettings, {
        debug: true,
        rules: {
			hiddenHelperInfCreditoAntes:{
				required: function (argument) {
					return validarFormInfCreditoFechaObligatoria()
				},
				lessThan: function (argument) {
					return validarFormInfCreditoAlmenosUnItemEnTablaItems()
				},
				moreThan: function (argument) {
					return validarFormInfCreditoSumaCuotas()
				},
			},
			hiddenHelperInfCreditoDespues:{
				required: function (argument) {
					return validarFormInfCreditoDespuesMinimoCuotas()
				},
				lessThan: function (argument) {
					return validarFormInfCreditoDespuesMinimoFechaVencimiento()
				},
				//[PAS20211U210700145][anunez][2021.11.08] se agrega la validación en la caja de texto txtMontoNeto
				equal: function (argument) {
					return validarFormInfCuotaSumaCuotasMontoNeto()
				},
			},
            txtMontoNeto: {
                required: true,
				moreThan: 0,
				lessThan: function (argument) {
					return validarFormInfCreditoMontoNeto()
				},
            }

        },
        // estos mensajes estan aqui porque son dinamicos respecto al html
        //PAS20211U210700145-EBV-FIX-Mensaje [equal]:La suma de cuotas debe ser igual al monto neto pendiente de pago
        messages: {
			hiddenHelperInfCreditoAntes: {
				required: 'Ingrese Fecha Emisi&oacute;n',
				lessThan: 'Agregue un item a la factura',
				moreThan: 'La suma de las cuotas no pueden ser mayor al importe total de la factura'
            },
            hiddenHelperInfCreditoDespues: {
				required: 'Agregue como mínimo una cuota a la Factura',
				lessThan: 'La fecha de la cuota debe ser mayor a la fecha de emisión',
				equal: 	  'La suma de cuotas debe ser igual al monto neto pendiente de pago'
            },
            txtMontoNeto: {
                required: 'Debe registrar el Monto neto pendiente de pago',
				moreThan: 'El monto debe ser mayor a 0',
				lessThan: 'El monto no puede ser mayor al importe total de la factura.'
            }
        }
    }));

	//[PAS20211U210700145][anunez][2021.11.08] se implementó método que valida el monto neto pendiente
	//de pago sea igual a la suma de cuotas al intentar mostrar la vista previa
	function validarFormInfCuotaSumaCuotasMontoNeto(){
		if ((Number($SumaMontoInfCredito) != Number($('#txtMontoNeto').numVal())) && $vistaPreliminar) {
			return true;
		}
		return false;
	}

	//PAS20201U210100231-OPV
	function evalNull(object) {
		var result = false;
		if (object != null && typeof object != "undefined") {
			if (object instanceof Array) {
				if (object.length > 0)
					result = true;
			} else {
				result = true;
			}
		}
		return result;
	}
	//PAS20201U210100231-OPV
	function isNoEmpty(object) {
		var result = false;
		if (object != null && object != "" && typeof object != "undefined") {
			if (object instanceof Array) {
				if (object.length > 0)
					result = true;
			} else {
				result = true;
			}
		}
		return result;
	}
	//PAS20201U210100231-OPV
	function showMensajeConfirmacion(mensaje, fn, titulo, fnHiddenModal) {
		titulo = $.trim(titulo) || 'Mensaje';
		var idRamdon = Math.round(Math.random() * 10009874621);
		var $m = $('<div class="modal fade" id="m' + idRamdon
				+ '" tabindex="-1" role="dialog" aria-labelledby="' + titulo
				+ '" aria-hidden="true"/>');
		var $mDialog = $('<div class="modal-dialog">');
		var $mContent = $('<div class="modal-content">');
		if (evalNull(titulo)) {
			$mContent.append('<div class="modal-header"><h3 class="modal-title">'
					+ titulo + '</h3></div>');
		}
		var mBody = $('<div class="modal-body">');
		mBody
				.append('<div class="row">'
						+ '<div class="col-md-12 col-xs-12 text-center ">'
						+ '<button type="button" class="btn si-modal btn-primary">Aceptar</button>'
						+ '</div>' + '</div>');
		mBody.prepend('<p class="text-justify">' + mensaje + '</p>');
		var btnSI = $(mBody.find('.si-modal').get(0));
		btnSI.click(function() {
			if ($.isFunction(fn))
				fn();
			$m.modal('hide');
		});
		$m.on('hidden.bs.modal', function(e) {
			$m.remove();
			if ($.isFunction(fnHiddenModal))
				fnHiddenModal($m);
		})
		$m.append($mDialog);
		$mDialog.append($mContent);
		$mContent.append(mBody);
		$m.modal({
			show : true,
			backdrop : "static"
		});
	}


//--------------Formulario y metodos Inf-CUOTAS-----------------------

	//INI-OPV: PAS20201U210100231
	$btnMostrarModalInfCuotas.on('click', function (e) {
	  _itemEditandoInfCredito=false;
	  $CantidadEditada=0;
	  $('#txtInfCuotasMonto').val(0);
	  $('#txtInfCuotasFechaVencimiento').val(null);
      $modalInfCuotas.modal('show');
    });

	//PAS20201U210100231-OPV EN CASO SE NECESITE MANEJAR EL DATEPICKER DE INFCUOTAS
/* 	var $datepickerInfCuotas = $('#txtInfCuotasFechaVencimiento');
	$datepickerInfCuotas.datepicker({
        endDate: new Date(),
		startDate: '-2d'
    }).on('changeDate', function(e) {
        $datepickerHidden.val(e.format());
    }); */

	//PAS20201U210100231-OPV Funcion Generica para transformar string a date
	function stringToDate(_date,_format,_delimiter)
	{
		var formatLowerCase=_format.toLowerCase();
		var formatItems=formatLowerCase.split(_delimiter);
		var dateItems=_date.split(_delimiter);
		var monthIndex=formatItems.indexOf("mm");
		var dayIndex=formatItems.indexOf("dd");
		var yearIndex=formatItems.indexOf("yyyy");
		var month=parseInt(dateItems[monthIndex]);
		month-=1;
		var formatedDate = new Date(dateItems[yearIndex],month,dateItems[dayIndex]);
		return formatedDate;
	};
	//INI-OPV: PAS20201U210100231-Validaciones para infCuotas
	function validarFormInfCuotaFecha(){
		var fechaString=$('#txtInfCuotasFechaVencimiento').val();
		if(fechaString!=''){
			var fechaDate=stringToDate(fechaString,"dd/MM/yyyy","/");
			var fechaEmision= stringToDate($('#txtFechaEmision').val(),"dd/MM/yyyy","/");
			//[PAS20211U210700145][anunez][2021.11.08] se cambio validación para la fecha de vencimiento
			if(fechaDate<=fechaEmision){
				return true;
			}
		}
		return false ;
	}
	//PAS20201U210100231-OPV
	function validarFormInfCuotaMaximoNumeroCuotas(){
		var maximoNumeroCuotaHidden= Number($('#globalcreditoCuotasMaximo').val());
		if($CantidadEditada!=0){
			return false;
		}
		else if(_ItemsInfCredito.length==maximoNumeroCuotaHidden ){
			return true;
		}
		return false;
	}
	//PAS20201U210100231-OPV
	function validarFormInfCuotaSumaCuotas(){
		var temporal=0;
		if($CantidadEditada==0){

			temporal=Number($SumaMontoInfCredito);
		}else{
			temporal=Number($SumaMontoInfCredito)-$CantidadEditada;
		}
		var sumaProvisional= (Number($('#txtInfCuotasMonto').numVal())+temporal);
		if(sumaProvisional>$ImporteTotal)
		{
			return true;
		}
		return false;
	}

	//FIN-OPV: PAS20201U210100231 -Validaciones para infCuotas

	//INI-OPV: PAS20201U210100231 Ejecucion Validaciones de InfCuotas
	$formModalInfCuotas.validate(_.extend(window._validatorWallSettings, {
        debug: true,
        rules: {
			hiddenHelperInfCuotas:{
				required: function (argument) {
					return validarFormInfCuotaMaximoNumeroCuotas()
				},
			},
            txtInfCuotasMonto: {
                required: true,
				moreThan: 0,
				lessThan: function (argument) {
					return validarFormInfCuotaSumaCuotas()
				},
            },
            txtInfCuotasFechaVencimiento: {
                required: true,
				moreThan: function (argument) {
					return validarFormInfCuotaFecha()
				},
            }

        },
        // estos mensajes estan aqui porque son d&iacute;n&aacute;micos respecto al html
        messages: {
			hiddenHelperInfCuotas: {
				required: 'Su comprobante electrónico puede tener máximo 12 cuotas',
            },
            txtInfCuotasMonto: {
				required: 'Ingrese monto de la cuota',
				moreThan: 'El monto de cuota debe ser mayor a cero',
				lessThan: 'La suma de las cuotas no pueden ser mayor al importe total de la factura'
            },
            txtInfCuotasFechaVencimiento: {
                required: 'Ingrese una fecha de vencimiento',
				moreThan: 'La fecha de la cuota debe ser mayor a la fecha de emisión'
            }
        },
        submitHandler: function(form) {
            var data = $(form).last().serializeObject();

			var dataCuota={
				modificar:"Modificar",
				eliminar:"Eliminar",
				numeroCuota: 0,
				montoCuota: data.txtInfCuotasMonto,
				fechaVencimiento: data.txtInfCuotasFechaVencimiento,
				fechaVencimientoDate: stringToDate(data.txtInfCuotasFechaVencimiento,"dd/MM/yyyy","/")
			};
            if (_itemEditandoInfCredito) {
                console.log("edit InfCuotas");
                editarInfCuotas({
                    itemId: _itemEditandoInfCredito
                }, dataCuota);
            } else {
                console.log("add InfCuotas");
                dataCuota.itemId = _.uniqueId('');
                agregarInfCuotas(dataCuota);
            }
            $modalInfCuotas.modal('hide');
            _itemEditandoInfCredito = false;
			//Recalcular y Renderizar -opv
            infCreditoOrdenarPorFecha();
			renderInfCredito();
        }
    }));



	//PAS20201U210100231-OPV
	function agregarInfCuotas(data) {
        _ItemsInfCredito.push(data);
    }
	//PAS20201U210100231-OPV
    function eliminarInfCuotas(criteria) {
        _ItemsInfCredito = _.reject(_ItemsInfCredito, criteria);
    }
	//PAS20201U210100231-OPV
    function buscarInfCuotas(criteria) {
        return _.find(_ItemsInfCredito, criteria);
    }
	//PAS20201U210100231-OPV
    function editarInfCuotas(criteria, data) {
        var doc = buscarInfCuotas(criteria);
        doc = _.extend(doc, data);
    }


	//PAS20201U210100231-OPV Renderizar Data a la tabla InfCredito
	function renderInfCredito() {
        var tbody = $tablaInfCredito.find('tbody');
        tbody.empty();
		$SumaMontoInfCredito=0;
        for (var i in _ItemsInfCredito) {
            var doc = _ItemsInfCredito[i];
            var $row = $('<tr/>', {
                'data-item-id': doc.itemId
            });
            for (var k in _itemSchemaInfCredito) {
                var text = doc[k];
				if (k == 'modificar'){
					text = $('<td/>').append($('<button/>').addClass('btn btn-warning btn-sm editar').append($('<i/>').addClass('glyphicon glyphicon-edit')));
				}
				if (k == 'eliminar'){
					text =  $('<td/>').append($('<button/>').addClass('btn btn-danger btn-sm remover').append($('<i/>').addClass('glyphicon glyphicon-remove')));
				}
				if(k == 'montoCuota'){
					$SumaMontoInfCredito=$SumaMontoInfCredito+ Number(text.replace(/,/g, ""));
					var numero=Number(text.replace(/,/g, ""));
					text=numero.toMoney(2);
				}
                $('<td/>').html(text).appendTo($row);
            }
			$row.appendTo(tbody);
        }
        $("#credito-counter").text(_ItemsInfCredito.length)
        $modalInfCuotas.find('.lista-errores').empty();
/*      $panelItems.find('.lista-errores').empty();
        $hiddenHelperItem.val(_ItemsInfCredito.length); */
        $tablaInfCredito.trigger('footable_initialize');
    }
	//PAS20201U210100231-OPV Evento Eliminar Grilla InfCredito
	$tablaInfCredito.on('click', 'button.remover', function(e) {
        var rowId = $(e.target).closest('tr').attr('data-item-id');
        eliminarInfCuotas({
            itemId: rowId
        });
		//Recalcular y Renderizar -opv
		infCreditoOrdenarPorFecha();
        renderInfCredito();
    })
	//PAS20201U210100231-OPV Evento Editar Grilla InfCredito
    $tablaInfCredito.on('click', 'button.editar', function(e) {
        var rowId = $(e.target).closest('tr').attr('data-item-id');
        var currItem = buscarInfCuotas({
            itemId: rowId
        });
		//Preparar Modal con valores y mostrarlo
        _itemEditandoInfCredito = currItem.itemId;
        popularModalInfCuotas(currItem);
        $modalInfCuotas.modal('show');
    })
	//PAS20201U210100231-OPV Actualizar Valores del Modal
	function popularModalInfCuotas(data, triggerChange, ignoreCodigo) {
		$('#txtInfCuotasMonto').val(data.montoCuota);
		$('#txtInfCuotasFechaVencimiento').val(data.fechaVencimiento);
		$CantidadEditada=Number(data.montoCuota);
    }
	//PAS20201U210100231-OPV Ordenar Data por fecha de vencimiento
	function infCreditoOrdenarPorFecha() {
		if(_ItemsInfCredito.length >0){
			//ORDENAR ELEMENTOS
			_ItemsInfCredito.sort(function (x, y) {
				let a = x.fechaVencimientoDate,
					b = y.fechaVencimientoDate;
				return a - b;
			});
			for(i=0;i< _ItemsInfCredito.length;i++){
				_ItemsInfCredito[i].numeroCuota=i+1;
			}
		}
    }

//FIN-OPV:PAS20201U210100231

	
// JBM PAS20221U210700303
	function estaPadronGeneric() {
		const pGeneric = JSON.parse(localStorage.getItem('pGeneric'));

		if(pGeneric != null){
			if (pGeneric.codeError == 0 ) {
				if( pGeneric.data =='0' ){
					alert('El contribuyente no se encontraría comprendido en los requisitos de la Ley N° 31556');
		  		}
		  	}
		}else{
				this.buscarPadronGeneric();
		}
	}
	
	function buscarPadronGeneric(){

	    var fechaEmision =$txtFechaEmision.val();
	    var url = 'emitirfesimp.do?action=validaPadronGeneric';
	    var dato="";
		var formData = { fecEmision: fechaEmision, dato : dato};

	      $.ajax({
	        url: url,
	        type: "POST",
	        data: formData,
	        dataType: 'json',
			async: false,
	        success: function(response) {
	        localStorage.setItem('pGeneric', JSON.stringify(response));

	            if(response.codeError == 0) {
	                if(response.data=="0"){
	                	alert('El contribuyente no se encontraría comprendido en los requisitos de la Ley N° 31556');
	                }
				} else {
	                $puedeEmitirRetencion.val("0");
					$panelRetencion.find('.panel-collapse').collapse('hide');
	            }
	        },
	        error: function () {
	          alert('error');
	          $txtFechaEmision.data('pivot-valid', '0');
	        },
	        complete: function () {
	        }
	      });
	}

// JBM FIN	
// Utilities
function alertMessageDanger(message) { // PAS20221U210600185
    $("#dinamic-error").remove();
    $("#collapse-factura-datos-receptor .panel-body").prepend('<div id="dinamic-error" class="alert alert-danger"><li> <span class="error">'+message+'</span></li></div>');
}

$RUCField.change(function() { // PAS20221U210600185
    if(!$RUCField.isValid) { //Borrar mensage del DOM
        $("#dinamic-error").remove();
    }
});