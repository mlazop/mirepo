// Para prevenir 'ReferenceError console is not defined'.
(function(window, _, $) {
	/**
     * Number.prototype.format(n, s, c)
     * 
     * @param integer n: length of decimal
     * @param mixed   s: sections delimiter
     * @param mixed   c: decimal delimiter
     */
    window.Number.prototype.toMoney = function(n, s, c) {
        n = _.isUndefined(n) ? 0 : n
        s = _.isUndefined(s) ? ',' : s
        c = _.isUndefined(c) ? '.' : c
        var re = '\\d(?=(\\d{3})+' + (n > 0 ? '\\D' : '$') + ')',
            num = this.toFixed(Math.max(0, ~~n));
        return (c ? num.replace('.', c) : num).replace(new RegExp(re, 'g'), '$&' + (s));
    };
    /// quickfix 15-10-2015
	$.fn.numVal = function(){
		var places = places || 0;
		var val = this.val().replace(/,/g, '');
        /// quickfix 14-10-2015
        var r = parseFloat(val);
		return _.isNaN(r) ? val : r;
	}
    /// end - quickfix 15-10-2015
    var metodo;
    var noop = function () {};
    // noop -> no-op -> una función vacía para mantener funcionalidad.
    var metodos = [
        'assert', 'clear', 'count', 'debug', 'dir', 'dirxml', 'error',
        'exception', 'group', 'groupCollapsed', 'groupEnd', 'info', 'log',
        'markTimeline', 'profile', 'profileEnd', 'table', 'time', 'timeEnd',
        'timeStamp', 'trace', 'warn'
    ];
    var total_metodos = metodos.length;
    var console = (window.console = window.console || {});

    while (total_metodos--) {
        metodo = metodos[total_metodos];
        // Solo estandarizar metodos inexistentes.
        if (!console[metodo]) {
            console[metodo] = noop;
        }
    }

    if(_){
        _.templateSettings = {
            evaluate    : /\<\%([\s\S]+?)\%\>/g,
            interpolate : /\{\{([\s\S]+?)\}\}/g,
            escape      : /\{\{\-([\s\S]+?)\}\}/g
        };
    }

    $.fn.serializeObject = function () {
        var array = this.serializeArray();
        var obj = {};
		
/*		console.log("forEach");
        array.forEach(function(e){
			console.log("forEach.name:"+e.name);
			console.log("forEach.value:"+e.value);			
            obj[e.name] = e.value;
        })*/
		
		//obj = {};
		//console.log("each");		
	   $.each(array, function(i, item) {
			//console.log("item.name:"+item.name);
			//console.log("item.value:"+item.value);			
            obj[item.name] = item.value;
		});		
		
		
		
        return obj;
    }

  
    String.prototype.format = function() {
        var args = arguments;
        return this.replace(/{(\d+)}/g, function(match, number) { 
            return typeof args[number] != 'undefined' ? args[number] : match;
        });
    };


	function validSerieDocRel(tipoDocumento, serie){
		var valor_ = serie.toUpperCase();
		var documento = $(tipoDocumento).val();
		
		//console.log("tipoDocumento:"+documento);
		//console.log("serie:"+valor_);
		

		
		
		if(documento=="09"){//guia remitente
			var expreg = new RegExp("^[E,e][G,g]01|[E,e][G,g]02|[E,e][G,g]07|[0-9]{4}|[T,t][A-Za-z0-9]{3}$");	// PAS20221U210700224 JBM 
			if(expreg.test(valor_)){	
				return true
			}else{
				return false
			}

		}
		if(documento=="31"){//guia transportista
			var expreg = new RegExp("^[E,e][G,g]01|[E,e][G,g]03|[E,e][G,g]04|[0-9]{4}|[V,v][A-Za-z0-9]{3}$"); 	// PAS20221U210700224 JBM 
			if(expreg.test(valor_)){	
				return true
			}else{
				return false
			}
		
		}
		
		if(documento=="G9"){//guia por eventos
			var expreg = new RegExp("^[E,e][G,g]05|[E,e][G,g]06$"); 	// PAS20221U210700224 JBM 
			if(expreg.test(valor_)){	
				return true
			}else{
				return false
			}
		
		}

	
		

	}
	
	function validDOCRUC(valor){
		var ruc_ = valor;
		//console.log("ruc_:"+ruc_.substring(0,2));
		if( ruc_.substring(0,2)==15 ){
			return true
		}else{
			return false
		}
	}
	
	
    $.validator.addMethod("validaNumerico", function(value, element, param) {        
		var valid = validaNumerico(value);
		return valid;		
    }, "Debe ingresar solo valores numéricos");
	
	function validaNumerico(valor) {
		  if (!/^([0-9])*$/.test(valor)){
		      return false;
		  }
		return true;
	}
	
    $.validator.addMethod("alfaOespacio", function(value, element) {
        return /^[ a-zA-Záéíóúüñ.,ÁÉÍÓÚÑ]*$/i.test(value);
    }, "Debe Ingresar sólo letras.");

    $.validator.addMethod("validaDecimal", function(value, element, param) {       
		//console.log("validaDecimal");													
		var valid = validaDecimal(value);
		return valid;		
    }, "Debe ingresar valores decimales");

	function validaDecimal(monto){
		//var patron=/^\d+(\,\.\d{1,2})?$/;
		var patron=/^(\d{1,3},)*\d{1,3}(\.\d+)?$/
		if(!patron.test(monto)){
			return false;
		}else{
			return true;
		}	
	}
	
	function validaPlaca(valor){	
		
		var patron=/^([A-Za-z0-9]{2,3}-[A-Za-z0-9]{3,4})$/;
		
		//var patron=/[A-Za-z0-9.-]{5,8}$/;
		
		if(!patron.test(valor)){
			return false;
		}else{
			return true;
		}			
		
	}
	
	
	function validaEmail(valor){	
		
		var patron=/^([a-zA-Z0-9_.+-])+\@(([a-zA-Z0-9-])+\.)+([a-zA-Z0-9]{2,4})+$/;
		if(!patron.test(valor)){
			return false;
		}else{
			return true;
		}			
		
	}	
	
    $.validator.addMethod("validaEmail", function(value, element, param) {        
		var valid = validaEmail(value);
		return valid;		
    }, "El correo ingresado no es correcto");	
	
	
    function validRUC(valor) {
        var valor = valor.trim();
        if (/^(\d+)$/g.test(valor)) {
            if (valor.length == 8) {
                suma = 0
                for (i = 0; i < valor.length - 1; i++) {
                    digito = valor.charAt(i) - '0';
                    if (i == 0) suma += (digito * 2)
                    else suma += (digito * (valor.length - i))
                }
                resto = suma % 11;
                if (resto == 1) resto = 11;
                if (resto + (valor.charAt(valor.length - 1) - '0') == 11) {
                    return true
                }
            } else if (valor.length == 11) {
                suma = 0
                x = 6
                for (i = 0; i < valor.length - 1; i++) {
                    if (i == 4) x = 8
                    digito = valor.charAt(i) - '0';
                    x--
                    if (i == 0) suma += (digito * x)
                    else suma += (digito * x)
                }
                resto = suma % 11;
                resto = 11 - resto
                if (resto >= 10) resto = resto - 10;
                if (resto == valor.charAt(valor.length - 1) - '0') {
                    return true
                }
            }
        }
        return false
    }

    window.numberVal = function ( value ) {
        value = parseFloat(value);
        if(value != +value || value == +Infinity || value == -Infinity)
            return 0;
        else
            return value;
    }

    function ValidaCadena(sCadena, sCampo){
        var i =0 ;
        var sCaracteres ="/|{}$%/=?[]^~!#¿¬°¨¡`";
        while ( i < sCadena.length ) {                    
            caracter = sCadena.charAt(i);    
            if ( caracter=="&"  && (i ==0 || i==sCadena.length-1 ))
            {
                return 2;
                return false;
            }
           
            if (caracter=="\\" || caracter=="\"" ){
                return 3;
                return false;
            }else{
                if ( sCaracteres.indexOf( caracter ) != -1 ) {     
                    return 4;
                }   
            }
            i++;                                        
        }
        return 1;
    }

    var datepickerConfig = {
      format: 'dd/mm/yyyy',
      todayBtn: false,
      language: "es",
      autoclose: true,
      todayHighlight: true
    };
    
    if($.fn.datepicker)    
        $.fn.datepicker.defaults = $.extend($.fn.datepicker.defaults, datepickerConfig);
    
    if(!$.validator)
        return;
    
    window._validatorWallSettings = {
        errorClass: 'error',
        errorElement: 'span',
        wrapper: 'li',
        errorWall: '.lista-errores',
        showErrors: function (errorMap, errorList) {
            var wall = $(this.currentForm).find(this.settings.errorWall);
            if(wall.length == 0){
                wall = $('<div/>').addClass(this.settings.errorWall.substr(1)).prependTo(this.currentForm);
            }
            if(this.numberOfInvalids() == 0)
                wall.addClass('hidden');
            else
                wall.removeClass('hidden');

            this.defaultShowErrors();
        },
        errorPlacement: function(error, element) {
            var wall = $(this.currentForm).find(this.settings.errorWall);
            if(wall.length == 0){
                wall = $('<div/>').addClass(this.settings.errorWall.substr(1)).prependTo(this.currentForm);
            }
            var alert = wall.find('.alert');
            if(alert.length == 0){
                alert = $('<div/>').addClass('alert alert-danger');
                alert.appendTo(wall);
            }
            error.appendTo(alert);
        }
    };

    $.validator.setDefaults({
        highlight: function(element, errorClass) {
            $(element).closest('.form-group').addClass('has-error');
        },
        unhighlight: function(element, errorClass) {
            $(element).closest('.form-group').removeClass('has-error');
        },
        errorClass: 'help-block',
        errorElement: 'span',
        showErrors: function () {
            //$(this.currentForm).find('.has-error').removeClass('has-error');
            this.defaultShowErrors();
        },
        
        onkeyup: false,
        onchange: false,
        onclick: false,
        onfocusout: false,
        
        ignore: '[type="hidden"]',
        errorPlacement: function(error, element) {
            if(element.parent('.input-group').length) {
                error.insertAfter(element.parent());
            } else {
                error.insertAfter(element);
            }
        },
        startOnInit: true
    });

    $.validator.addMethod("notEqual", function(value, element, param) {
      return value != param;
    }, "Please specify a different (non-default) value");

    $.validator.addMethod("equal", function(value, element, param) {
        
      return value == param;
    }, "not-equals");


    $.validator.addMethod("validaSiCatalogo", function(value, element, param) {
        /// quickfix 14-10-2015
/*		console.log("value:"+value);							  
		console.log("element:"+element.name);	
		console.log("param:"+param);	*/
		
        return validaSiCatalogo(param,_Productos,value);
        
    }, "El producto no se encuentra en el catálogo");


function validaSiCatalogo(campo,productos,valor){
	
   valor = $.trim(valor);
   var encontro = false;	
		//console.log("valor:"+valor);							  
		//console.log("campo:"+campo);							  
		
   $.each(productos, function(i, item) {

		//console.log("txtCodigo:"+item.txtCodigo);
		//console.log("txtDescripcion:"+item.txtDescripcion);
							  
		if(campo=="txtCodigo"){			
			if(valor==$.trim(item.txtCodigo)){				
				encontro =  true;
				return true;	
			} 
		}						  
							  
		if(campo=="txtDescripcion"){			
			if(valor==$.trim(item.txtDescripcion)){ 
				encontro =  true;
				return true;	
			}
		}								  

	});		
   
   return encontro;

}


    $.validator.addMethod("lessThan2", function(value, element, param) {
        /// quickfix 14-10-2015
		
		//console.log("lessThan value:"+value);
		//console.log("lessThan param:"+param);
		//console.log("lessThan param[0]:"+param[0]);		
		var parametro =param[0];		
		
		var parametro = $(param).val();
		//console.log("lessThan parametro:"+parametro);				
		
        if(parametro === false)
            return true;
        var i = parseFloat(value);
        var j = parseFloat(parametro);
        return i <= j;

        //console.log("less-than", value, i, j);
        
    }, "The value must be less than {0}");
	
	
	

    $.validator.addMethod("lessThan", function(value, element, param) {
        /// quickfix 14-10-2015
		
		//console.log("lessThan value:"+value);
		//console.log("lessThan param:"+param);				
		
        if(param === false)
            return true;
        var i = parseFloat(value);
        var j = parseFloat(param);
        return i <= j;

        //console.log("less-than", value, i, j);
        
    }, "The value must be less than {0}");


    /// quickfix 15-10-2015
    $.validator.addMethod("moreThan", function(value, element, param) {
        if(param === false)
            return true;
        var i = parseFloat(value);
        // var j = parseFloat(param);
        var j = parseFloat(param)+Number.MIN_VALUE;
        return i >= j;
    }, "The value must be more than {0}");
    /// end - quickfix 15-10-2015
    
	$.validator.addMethod("validSerieDocRel", function (value, element, param){		
														
														
		var valid = validSerieDocRel(param[0],value);
		return valid;
		
		
		//var valid = validSerieDocRel(value);
		//$(element).data('validSerieDocRel', valid ? '1' : '0');
		//return valid;
	}, "La Serie no es valida");
	
	$.validator.addMethod("validDOCRUC", function (value, element, param){		
		var valid = validDOCRUC(value);
		$(element).data('validDOCRUC', valid ? '1' : '0');
		return valid;
	}, "El numero de RUC debe iniciar con 15");	
	
	

	
	
	$.validator.addMethod("restaFechas", function (value, element, param){	
		var valid = restaFechas(param[0], param[1]);
		return valid;
	}, "");			
	
	function restaFechas(f1,f2) {
		var momentFechaIniAddMes =  moment($(f1).val(), "DD/MM/YYYY").add(6, 'month');
		var momentFechaFin = moment($(f2).val(), "DD/MM/YYYY");
		var difDias = momentFechaFin.diff(momentFechaIniAddMes,"days");

		var flag = true;
		if(difDias > 0) {
			//console.log("mayor a 6 meses:");
			flag = false;
		} else {
			//console.log("entre los 6 meses");
		}
		return flag;
	}	
	
	$.validator.addMethod("comparaSiFechaInicioMenorIgualFechaFin", function (value, element, param){	
																			  
		//console.log("value:"+value);
		//console.log("param[0]:"+param[0]);																			  
		var valid = comparaSiFechaInicioMenorIgualFechaFin(param[0],param[1]);
		return valid;
	}, "La fecha de inicio no puede ser mayor que la fecha de fin");			
	
	$.validator.addMethod("comparaSiFechaInicioMenorIgualFechaFin2", function (value, element, param){	
																			  
		//console.log("value:"+value);
		//console.log("param[0]:"+param[0]);																			  
		var valid = comparaSiFechaInicioMenorIgualFechaFin(param[0],param[1]);
		return valid;
	}, "La fecha de inicio no puede ser mayor que la fecha de fin");		
	
	function comparaSiFechaInicioMenorIgualFechaFin(fechaInicial,fechaFinal)
	{
	/*	console.log("fechaInicial:"+fechaInicial);
		console.log("fechaFinal:"+fechaFinal);

		console.log("fechaInicial:"+$(fechaInicial).val());
		console.log("fechaFinal:"+$(fechaInicial).val());
*/
		if($(fechaInicial).val()=="" && $(fechaInicial).val()==""){
			return true;	
		}
		
		
	var valuesStart=$(fechaInicial).val().split("/");
	var valuesEnd=$(fechaFinal).val().split("/");
	
	
	//var valuesStart=fechaInicial.split("/");
	//var valuesEnd=$(fechaFinal).val().split("/");
	
		//console.log("valuesStart:"+valuesStart);
		//console.log("valuesEnd:"+valuesEnd);	
	
		// Verificamos que la fecha no sea posterior a la actual
		var dateStart=new Date(valuesStart[2],(valuesStart[1]-1),valuesStart[0]);
		var dateEnd=new Date(valuesEnd[2],(valuesEnd[1]-1),valuesEnd[0]);
		
		if(dateStart<=dateEnd)
		{
				return true;	
		}
		
		return false;
	}	
	
    $.validator.addMethod("validaPlaca", function(value, element, param) {
        var valid = validaPlaca(value);
		return valid;
    }, "El numero de placa no es v&aacute;lido");
	
	
    $.validator.addMethod("validRUC", function(value, element, param) {
        var valid = validRUC(value);
        $(element).data('validRUC', valid ? '1' : '0');
		return valid;
    }, "El numero de RUC no es valido");

    /// ESTA REGLA DE VALIDACION (que no es una regla per se)
    /// ROMPE CON TODO EL PATRON DE TRABAJO DEL PLUGIN
    /// MANIPULAR CON CUIDADO TODO ESTA HARDCODED

    $.validator.addMethod("validStr", function(value, element, param) {
        return /^([a-z0-9\s\xe1\xe9\xed\xf3\xfa\xf1\xfc\-\+\.\&\,\;]+)?$/ig.test(value);
    },"Los caracteres ingresados no son v&aacute;lidos. ");

    $.validator.addMethod("serie_doc", function(value, element, params) {
        return /^(E001)?$/ig.test(value);
    }, "El numero de serie del recibo electr&oacute;nico o de los otros ingresos de cuarta debe iniciar con la letra E");

    $.validator.addMethod("num_serie_doc", function(value, element, params) {
        return /^((E001)|(\d+))?$/ig.test(value);
    }, "El numero de serie debe iniciar con la letra E y/o solo contener dígitos");

     $.validator.addMethod("validpivot", function(value, element, params) {
        return $(element).data('pivot-valid') == '1';
    }, "pivot-wrong!");
    
    $.validator.addMethod("non_repeated", function(value, element, params) {
        var d = {};
        [].forEach.call(value, function (e) {
            d[e] = d[e]+1 || 1;
        });
        return _.size(d) > 1;
    }, "El n&uacute;mero de serie no es v&aacute;lido");

    $.validator.addMethod("minimo", function(value, element, params) {
        var val = parseFloat(value.replace(',' ,''));
        return !isNaN(val) && val > params;
    }, "Indique un valor mayor a {0}");
	


}(window, _, jQuery));