/**
 * ImportacionCPFisicosRVI.js - JavaScript de RVI.
 * Author: Patricia Chacaliaza
 * Since: 19-08-2013
 * ResponseBean : codeError; messageError; data;
 */
if (!dojo._hasResource["servicio.registro.comppago.see.ImportacionCPFisicosRVI"]) {
dojo._hasResource["servicio.registro.comppago.see.ImportacionCPFisicosRVI"] = true;
dojo.provide("servicio.registro.comppago.see.ImportacionCPFisicosRVI");

  dojo.require("dojox.grid.DataGrid");
  dojo.require("dojox.grid.cells.dijit");
dojo.require("dojo.data.ItemFileWriteStore");
dojo.require("dojo.data.ItemFileReadStore");
dojo.require("dojo.io.iframe");
    dojo.require("dijit.Dialog");

dojo.require("dijit.form.DateTextBox");
			dojo.require("dojox.widget.Standby");
dojo.declare("servicio.registro.comppago.see.ImportacionCPFisicosRVI", null, {

	
	store: null,
	beanDatosCP: null,
	controller: "impcpfisicosrvi.do",

	otherDocStore: null,
	ptoemiStore: null,	
	
	constructor: function() {},

	initialize: function() {
		this.content = dijit.byId("content");
		this.setContentPaneLoading(this.content);
		this.dialogHistorial =  dijit.byId("dialogHistorial");
		this.dialogError =  dijit.byId("dialogErrores");
		this.waitMessage = dijit.byId("waitMessage");

		var size = dojo.marginBox(this.content.domNode);
		x = Math.floor((size.w - 102)/2);
		y = Math.floor((size.h - 34)/2);

		this.content.loadingMessage = 
		'<div class="ext-el-mask-msg x-mask-loading" style="left: ' + x + 'px; top: ' + y + 'px;"><div>Cargando...</div></div>';		
	},

		
	initContent: function() {
	    this.initialize();
       
		 // dijit.focus(dojo.byId("inicio.periodo"));
		
	},
	
		mandar: function(form) {
	    //dojo.byId("criterios").submit();
      // this.content.setHref(this.controller + "?action=generaPreliminarRegComprasConMovim" );	
		 // dijit.focus(dojo.byId("inicio.periodo"));
		 
		 
		 var periodo =  dijit.byId("inicio.periodoRegistroVentas" ).getValue().substring(3,7) + dijit.byId("inicio.periodoRegistroVentas" ).getValue().substring(0,2);
			var periodoRVI = dijit.byId("inicio.periodoRegistroVentas" ).getValue();
  		    if (periodoRVI.length != 7){
                this.iconTooltipMessage("inicio.periodoRegistroVentas", "icon-ok-tooltip", "El periodo debe tener el formato MM/YYYY.");
                return;
          }
          if (periodoRVI.substring(0,2) != "01" && periodoRVI.substring(0,2) != "02" && periodoRVI.substring(0,2) != "03" &&
              periodoRVI.substring(0,2) != "04" && periodoRVI.substring(0,2) != "05" && periodoRVI.substring(0,2) != "06" &&
              periodoRVI.substring(0,2) != "07" && periodoRVI.substring(0,2) != "08" && periodoRVI.substring(0,2) != "09" &&
              periodoRVI.substring(0,2) != "10" && periodoRVI.substring(0,2) != "11" && periodoRVI.substring(0,2) != "12" ){
                this.iconTooltipMessage("inicio.periodoRegistroVentas", "icon-ok-tooltip", "El mes del periodo es inv�lido.");
                return;
          } 
      var periodoActual  = dojo.date.locale.format(new Date(), {datePattern: "yyyyMM", selector: "date"});
      if (periodo > periodoActual){
          this.iconTooltipMessage("inicio.periodoRegistroVentas", "icon-ok-tooltip", "Periodo no puede ser mayor al actual.");
          return;
      }	
      var cargar =0;
		var handler = dojo.xhrGet({
        url: this.controller + "?action=validaExisteRVIGenerados&perIni=" + periodo+ "&perFin=" + periodo,
        handleAs: "json",
       	preventCache: true,
        sync: true,
        timeout: 20000
      }); 

			handler.addCallback(dojo.hitch(this, function(res){
				this.waitMessage.hide();
				if(res.codeError == 0) {
		        cargar = 1;
 
    		} else {
    					alert(res.messageError);
    					return;
    		}
    		}));
    		handler.addErrback(dojo.hitch(this, function(res) {
        			this.waitMessage.hide();
    				alert("Ocurrio un error al momento de ejecutar la consulta.");
    				return;
    			}));  
          
          if (cargar == 1){
              if (dojo.byId("archivo").value ==""){
          		      alert("Debe consignar el archivo a importar");
          		      return;
               }
      		 
      		    var handler2 = dojo.io.iframe.send({
          			url: this.controller,
          			handleAs: "json",
          			sync: true,
          			timeout: 9000000,
          			preventCache: true,
          			form: "criterios"
          		});
          		
        			handler2.addCallback(dojo.hitch(this, function(res2){
        
        				if(res2.codeError == 0) {
        				  this.content.setHref(this.controller + "?action=mostrarPreliminarImportacion" );	
        				} else {
            				if(res2.codeError == 1) {
            					this.content.setHref(this.controller + "?action=mostrarErroresImportacion" );	
            				}else{
            				    alert(res2.messageError);
                    }
        				}
        			}));
        			handler2.addErrback(dojo.hitch(this, function(res2) {
            			this.waitMessage.hide();
        				alert("Ocurrio un error al momento de ejecutar la consulta.");
        			}));   
        }     			
	},

	//funciones para eventos
    startup: function(){
    	  dojo.parser.parse(dojo.byId('container'));
    	  setTimeout(dojo.hitch(this, function(){
		   this.initialize();
    	  }), 250);

    },    

    validateAcceptTerminos: function(){
          var acepta = dijit.byId("condiciones.cbTerminos");
          if (!acepta.getValue()) {
              alert("Debe aceptar las condiciones.");
              //this.messageBoxError("Debe aceptar las condiciones.","icon-alert-warn");
              return;
          }
                  this.content.setHref(this.controller + "?action=mostrarInicial2");
      },
      
    generarRvi: function(){
    
        if(dojo.byId("inicio.periodoRegistroVentas").value == "") {
    			alert("Debe seleccionar un periodo.");
    			return;
    		}
        var periodoSeleccionado = dojo.byId("inicio.periodoRegistroVentas").value;
        this.content.setHref(this.controller + "?action=mostrarInicial2" + "&preventCache=" + this.preventCache() + "&periodoSeleccionado=" + periodoSeleccionado);	
    },


    cargarArchivo:function(){
        var periodo= dojo.byId("inicioRegComp.periodoRegistroComprasConMovim").value;
         this.content.setHref(this.controller + "?action=generaPreliminarRegComprasConMovim&periodo=" + periodo);
    },
    
    
            sendMail: function(){
            var correo = dijit.byId("generada.correoUser");
            if (correo.getValue() == "") {
                alert("Debe consignar el Correo Electronico.");
                return;
            }
 
            var handler = dojo.xhrGet({
                url: this.controller + "?action=enviarCorreo&correoUser=" + correo.getValue(),
                handleAs: "json",
                preventCache: true,
                sync: true,
                timeout: 10000
            });
            handler.addCallback(dojo.hitch(this, function(res){
                if (res.codeError == 0) {
                    //this.messageBoxError("Se envio constancia al buz�n electr�nico.", "icon-alert-warn");
                    alert("Se envio correo electronico.");
                    return;
                }
                else {
                    alert(res.messageError);
                }
            }));
        },
    
   
    
  	showDialogHistorial: function(rowIndex) {
    		
    		//this.wait("Consultando", "110px");
    		
        var handler = dojo.xhrGet({
              url: this.controller + "?action=getHistorial",
              handleAs: "json",
		         	preventCache: true,
              sync: true,
              timeout: 18000
        }); 
        
           		
  		
			handler.addCallback(dojo.hitch(this, function(res){
				this.waitMessage.hide();
				if(res.codeError == 0) {
      						var data = eval("(" + res.data + ")");			
      						var newStore = new dojo.data.ItemFileWriteStore({data: {identifier: 'id', items: data}});
      			    	var grid = dijit.byId("historialArchivosImportados");
      						grid.setStore(newStore);
      						grid.startup();
      					this.dialogHistorial.show();	
				} else {
					alert(res.messageError);
				}
			}));
			handler.addErrback(dojo.hitch(this, function(res) {
    			this.waitMessage.hide();
				alert("Ocurrio un error al momento de ejecutar la consulta del historial de presentaciones.");
			}));
			
  	      
  	},
  	
  	salirHistorico:function(){
  	   this.dialogHistorial.hide();
    },

		formatFecNacOblig: function(value, rowindex) {
		//dd/MM/yyyy
		  if (value!= null){
            return dojo.date.locale.format(new Date(value), {datePattern: "dd/MM/yyyy", selector: "date"});
          }
		},
		

    grabarCPFisicos : function(periodo){

            var fecHoy = new Date();

            var periodoActual = dojo.date.locale.format(fecHoy, {datePattern: "yyyyMM", selector: "date"});
            /*if(periodo >= periodoActual){
              alert("No puede generarse aun el Registro de Compras Electronico")
              return;
            } */
 
              if (confirm("Confirme que desea grabar los comprobantes de pago importados.")){
                   //this.wait(" Grabando comprobantes de pago ", "500px");
                   var handler = dojo.xhrGet({
                        url: this.controller + "?action=grabarCPFisicos",
                        handleAs: "json",
                        sync: true,
                        timeout: 3990000
                    });        
                    handler.addCallback(dojo.hitch(this, function(res){
                       this.waitMessage.hide();
                  			if (res.codeError == 0) {
                            this.content.setHref(this.controller + "?action=finalImportacionCPFisicos&preventCache=" + this.preventCache());
                   			}
                  			else {
                  				alert("Problemas al grabar comprobantes de pago:" + res.messageError);
                  			}
                    }));
              			handler.addErrback(dojo.hitch(this, function(res) {
                  			this.waitMessage.hide();
              				alert("Ocurrio un error al momento de grabar los comprobantes de pago f�sicos.");
              			}));
              }
            
        
    },
    
    
    descargarErrores : function(){
      window.open(this.controller + "?action=descargarErrores" );
    
    },
    
    imprimirConstancia : function(periodo){
       window.open(this.controller + "?action=imprimirConstancia" );
        
     },
        
    salirErrores : function(){
        this.content.setHref(this.controller + "?action=mostrarInicial" + "&preventCache=" + this.preventCache() );	
    
    },
    
        salirPrelimRegCompConMovim : function(){
        this.content.setHref(this.controller + "?action=mostrarInicial" + "&preventCache=" + this.preventCache() );	
    
    },
    
    salir : function(){
        this.content.setHref(this.controller + "?action=mostrarInicial" + "&preventCache=" + this.preventCache() );	
    
    },
    
    descargaZip: function(){
      window.open(this.controller + "?action=descargaZip" );
    },
    
    salirInicial: function(){
              this.content.setHref(this.controller + "?action=mostrarInicial" + "&preventCache=" + this.preventCache() );	
    },
    
    pause: function(milisec){
    var d = new Date();
    var begin = d.getTime();
    
    while ((d.getTime() - begin ) > milisec){
    // nothing... 
    } 
 } ,
  	preventCache: function() {
  		return new Date().valueOf();
  	},
	
  	wait: function(message, width) {
		dojo.byId("waitMessage").innerHTML="<div class='dijitInline box-message'></div><div class='dijitInline'>&nbsp;" + message + "...</div>";
	    dojo.byId("waitMessage").style.width = width;
	    this.waitMessage.show();
	},
	

	
	
	  iconTooltipMessage: function(node, iconClass, message) {
  		if(dojo.isString(node)) node = dojo.byId(node);
  		dijit.focus(node);
  		node.focus();
  		dijit.showTooltip('<div class="' + iconClass + '"><div>' + message + '</div></div>', node, []);
  		//node._refreshState();
  		var blur = dojo.connect(node, "onBlur", function() {
  			dijit.hideTooltip(node);
  			//node._refreshState();
  			dojo.disconnect(blur);
  		});
	  },   
  
	  warnTooltipMessage: function(node, message) {
		  this.iconTooltipMessage(node, "icon-warn-tooltip", message);
	  },
	
	  noSort: function(index){ 
		   return false;
	  },
	
	onFocus: function(id){
    var dato = dojo.byId(id).value;
     dijit.byId(id).attr('value',"");	
     dijit.byId(id).attr('value',dojo.trim(dato));	
  },

      roundNumber: function(number, digits) {
                   var multiple = Math.pow(10, digits);
                   var rndedNum = Math.round(number * multiple) / multiple;

                   return rndedNum;
     } ,
  
  	setContentPaneLoading: function(content) {
		this.setContentPaneLoadingBg(content, "ext-el-mask");
	},
	
	setContentPaneLoadingBg: function(content, bg) {
		var size = dojo.marginBox(content.domNode);
		x = Math.floor((size.w - 102)/2);
		y = Math.floor((size.h - 34)/2);
		content.loadingMessage = 
		'<div class="' + bg + '"></div>' +
		'<div class="ext-el-mask-msg x-mask-loading" style="left: ' + x + 'px; top: ' + y + 'px;"><div>Cargando...</div></div>';
	},
     showHiddenDiv: function(node,show) {
     	if (show == true) { //Mostrar
	       node.style.display = "";
      } else { //Ocultar
        	node.style.display = "none";
     	}
    }
          
});
}
