$(document).ready(function() {
	
	var editor;						   
						   
    $('#example').DataTable( {
        "processing": false,
        "serverSide": true,
        "ajax": {
			"url": '/a/js/servicio/registro/comppago/see/liquidacioncompra/json/data.json',
			"dataType":'JSON',
        },
        "columns": [
            { "data": "first_name" },
            { "data": "last_name" },
            { "data": "position" },
            { "data": "office" },
            { "data": "start_date" },
            { "data": "salary" }
        ],
        select: {
            style:    'os',
            selector: 'td:first-child'
        },
        buttons: [
            { extend: "create", editor: editor },
            { extend: "edit",   editor: editor },
            { extend: "remove", editor: editor }
        ]
		
		
    } );
	

  $('#example').on( 'click', 'tbody td:not(:first-child)', function (e) {
        editor.inline( this );
    } );
	
	
} );