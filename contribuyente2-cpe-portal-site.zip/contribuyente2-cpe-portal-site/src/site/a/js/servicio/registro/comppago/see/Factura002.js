function mostrarMensaje(msj, tipo = 1 )  {

		if ( dijit.byId('dlgMensaje') != undefined ) {
				require(["dojo/dom-construct"], function(domConstruct){
				  dijit.byId('dlgBtnAceptar').destroy();
				  dijit.byId('dlgMensaje').destroy();
				});
		}

		var aceptarDialog = new dijit.Dialog({ id: 'dlgMensaje', title: "Mensaje" });
		var respCallback = function(mouseEvent) {
				aceptarDialog.hide();
		};

		dojo.connect(aceptarDialog,"onCancel",function(){
				aceptarDialog.hide();
		});

		switch (tipo) {
				case 0: // OK
						questionDiv = dojo.create("div", {innerHTML:"<table><tr style='height:70px'><td><img src='/a/imagenes/pase_embarque.gif' border='0' alt=''></td><td style='padding-left: 5px;'>" + msj + "</td></tr></table>"});
						break;
				case 1: // INFO
						questionDiv = dojo.create("div", {innerHTML:"<table><tr style='height:70px'><td><img src='/a/imagenes/sigad/acciones/advertencia.gif' border='0' alt=''></td><td style='padding-left: 5px;'>" + msj + "</td></tr></table>"});
						break;
				case 2: // WARNING
						questionDiv = dojo.create("div", {innerHTML:"<table><tr style='height:70px'><td><img src='/a/imagenes/sigad/acciones/advertencia.gif' border='0' alt=''></td><td style='padding-left: 5px;'>" + msj + "</td></tr></table>"});
						break;
				case 3: // ERROR
						questionDiv = dojo.create("div", {innerHTML:"<table><tr style='height:70px'><td><img src='/a/imagenes/pase_no_embarque.gif' border='0' alt=''></td><td style='padding-left: 5px;'>" + msj + "</td></tr></table>"});
						break;
		}

		var aceptarButton = new dijit.form.Button( { label: 'Aceptar', id: 'dlgBtnAceptar', onClick: respCallback });
		var centroDiv = dojo.create('div', { style: { margin: "auto", textAlign: "center"} } );

		aceptarDialog.containerNode.appendChild(questionDiv);
		aceptarDialog.containerNode.appendChild(centroDiv);
		centroDiv.appendChild(aceptarButton.domNode);
		aceptarDialog.show();
}

//csanchezpe: se acrega accion cancelar para el caso de los else
function mostrarMensajeConfirmacion ( msj, accionBtnAceptar, accionBtnCancelar = function() {} )  {

		if ( dijit.byId('dlgMensajeConfirmacion') != undefined ) {
				require(["dojo/dom-construct"], function(domConstruct){
				  dijit.byId('dlgBtnAceptarConfirm').destroy();
				  dijit.byId('dlgBtnCancelarConfirm').destroy();
				  dijit.byId('dlgMensajeConfirmacion').destroy();
				});
		}

		var dlgConfirmacion = new dijit.Dialog({ id: 'dlgMensajeConfirmacion', title: "Confirmar" });

		var respCallAceptar = function() {
			accionBtnAceptar();
			dlgConfirmacion.hide();
		};

		var respCallCancelar = function() {
			accionBtnCancelar();
			dlgConfirmacion.hide();
		};

		dojo.connect(dlgConfirmacion, "onCancel", function() {
			dlgConfirmacion.hide();
		});

		questionDiv = dojo.create("div", {innerHTML:"<table><tr style='height:70px'><td><img src='/a/imagenes/icons/questionMark32px.png' border='0' alt=''></td><td style='padding-left: 5px;'>" + msj + "</td></tr></table>"});

		var aceptarButton = new dijit.form.Button( { label: 'Aceptar', id: 'dlgBtnAceptarConfirm', onClick: respCallAceptar });
		var cancelarButton = new dijit.form.Button( { label: 'Cancelar', id: 'dlgBtnCancelarConfirm', onClick: respCallCancelar });

		var centroDiv = dojo.create('div', { style: { margin: "auto", textAlign: "center"} } );

		dlgConfirmacion.containerNode.appendChild(questionDiv);
		dlgConfirmacion.containerNode.appendChild(centroDiv);
		centroDiv.appendChild(aceptarButton.domNode);
		centroDiv.appendChild(cancelarButton.domNode);
		dlgConfirmacion.show();
}

/**
* Inicio : Codigo JS para el RUM de www.site24x7.com
*/
var rumMOKey='0445702bc68ea5ded867a2fbaa5b4f46';
(function(){
if(window.performance && window.performance.timing && window.performance.navigation) {
        var site24x7_rum_beacon=document.createElement('script');
        site24x7_rum_beacon.async=true;
        site24x7_rum_beacon.setAttribute('src','//static.site24x7rum.com/beacon/site24x7rum-min.js?appKey='+rumMOKey);
        document.getElementsByTagName('head')[0].appendChild(site24x7_rum_beacon);
}
})(window)

/**
* Fin : Codigo JS para el RUM de www.site24x7.com
*/

/**
 * Factura.js - JavaScript de la Factura Electronica.
 * Author: Carlos Enrique Quispe Salazar
 * Since: 05-05-2008
 * ResponseBean : codeError; messageError; data;
 */

if (!dojo._hasResource["servicio.registro.comppago.see.Factura"]) {
	dojo._hasResource["servicio.registro.comppago.see.Factura"] = true;
  	dojo.provide("servicio.registro.comppago.see.Factura");

	dojo.require("dojo.data.ItemFileWriteStore");
  	dojo.require("dojo.data.ItemFileReadStore");
  	dojo.require("dojo.io.iframe");
  	dojo.require("dojox.validate.regexp");
  	dojo.declare("servicio.registro.comppago.see.Factura", null, {

    k :null,
  	p : null,

	store: null,
	beanDatosCP: null,
	controller: "emitir.do",
	indRegitroGR: null,
	self:null,
	nContLicencia: null,
	otherDocStore: null,
	// INI PAS20201U210100097 APDEX
	infAdicionalStore: null,
	// FIN PAS20201U210100097 APDEX
	licenciaStore:null,
	ptoemiStore: null,
	nrus:null,//PAS20191U210100075
	//PAS20201U210100230 -oINICIO
	//variables utilizadas para calculos
	indRegitroInfCredito: 0,
	storeInfCredito: null,
	storeInfCuota: null,
	listaElementosInfCredito:[],
	storeInfCreditoGuardadoComplementaria:[],//[PAS20211U210700145][anunez][2021.11.05]
	montoTotalCuotas:0,
	//variables que se guardan para compararse.
	montoNetoPendienteGuardado:null,
	storeInfCreditoGuardado: [],
	montoTotalCuotasGuardado:null,

	montoNetoRetencion: null,
	montoBaseRetencion: null,
	//PAS20201U210100230 -oFIN
	constructor: function() {},

	initialize : function () {
		this.content = dijit.byId("content");

		this.dialogItem = dijit.byId("dialogItem");
		this.dialogDocsLinked = dijit.byId("dialogDocsLinked");
		this.dialogInfAdicional = dijit.byId("dialogInfAdicional");
		this.dialogInfTrasladoBienes = dijit.byId("dialogInfTrasladoBienes");
		this.dialogPuntoPartida = dijit.byId("dialogPuntoPartida");
		this.dialogPuntoLlegada = dijit.byId("dialogPuntoLlegada");
		this.dialogEstablecimientoEmisor = dijit.byId("dialogEstablecimientoEmisor");
		this.dialogDireccionCliente = dijit.byId("dialogDireccionCliente");
		this.dialogComercializacionOro = dijit.byId("dialogComercializacionOro");
		this.dialogRecursosHidrobiologicos=dijit.byId("dialogRecursosHidrobiologicos");
		this.dialogCalculoValorRef= dijit.byId("dialogCalculoValorRef");
		//PAS20201U210100230
		if(dojo.byId("global.cambiosFactoringHabilitados")!=null){
		this.globalCambiosFactoringHabilitados = dojo.byId("global.cambiosFactoringHabilitados").value;
		console.log(this.globalCambiosFactoringHabilitados);
		}
		this.dialogDireccionContribuyente = dijit.byId("dialogDireccionContribuyente");//PAS20201U210100230
		this.dialogRetencion = dijit.byId("dialogRetencion");//PAS20201U210100230
		//PAS20201U210100230 -o
		this.dialogInfCredito = dijit.byId("dialogInfCredito");
		this.dialogInfCuota = dijit.byId("dialogInfCuota");
		//PAS20201U210100230 -o
		this.waitMessage = dijit.byId("waitMessage");
		this.indRegitroGR = 0;
		this.nContLicencia =0;

		// PAS20201U210100097 APDEX
		this.divFacturaDocRelItem = "divFacturaDocRelItem";
		this.inicializarFacturaDocRelItem();

		// PAS20201U210100097 APDEX
		this.divFacturaInformacionRelSP = "divFacturaInformacionRelSP";
		this.inicializarFacturaInformacionRelSP();

		// PAS20201U210100097 APDEX
		this.divFacturaItem = "divFacturaItem";
		this.inicializarFacturaItem();

		//PAS20201U210100097 APDEX
		this.divFacturaEstablecimientoEmisor = "divFacturaEstablecimientoEmisor";
		this.inicializarFacturaEstablecimientoEmisor();

		//PAS20201U210100097 APDEX
		this.divFacturaDireccionCliente = "divFacturaDireccionCliente";
		this.inicializarFacturaDireccionCliente();

		//PAS20201U210100230
		if (dojo.byId("global.opcionTipoTransaccion")!=null){
			this.divFacturaFactoringDireccionReceptor = "divFacturaFactoringDireccionReceptor";
			this.inicializarFacturaFactoringDireccionReceptor();

			//PAS20201U210100230
			this.divFacturaFactoringRetencion = "divFacturaFactoringRetencion";
			this.inicializarFacturaFactoringRetencion();

			//PAS20201U210100230 -o
			this.divFacturaInformacionCreditoItem = "divFacturaInformacionCreditoItem";
			this.inicializarFacturaFactoringCreditoItem();

			this.divFacturaInformacionCuota = "divFacturaInformacionCuota";
			this.inicializarFacturaFactoringCuota();
			//PAS20201U210100230 -o
		}
	},

	//PAS20201U210100230
	inicializarFacturaFactoringRetencion: function(){

		require(["dojo/dom","dojo/dom-construct","dojo/html"], function(dom,domConstruct,html){
  			domConstruct.empty(dojo.byId(this.divFacturaFactoringRetencion));
			var controller="emitir.do";
			var handler = dojo.xhrGet({
				preventCache:  false,
				url: controller + "?action=cargarFacturaFactoringRetencion",
				handleAs: "text",
				sync: false,
				timeout: 10000
			});
			handler.addCallback(dojo.hitch(this, function(response){

			  html.set(dom.byId("divFacturaFactoringRetencion"),response, {
              parseContent: true
			  });
			}));
		});

	},

	//PAS20201U210100230
	inicializarFacturaFactoringDireccionReceptor: function(){

		require(["dojo/dom","dojo/dom-construct","dojo/html"], function(dom,domConstruct,html){
  			domConstruct.empty(dojo.byId(this.divFacturaFactoringDireccionReceptor));
			var controller="emitir.do";
			var handler = dojo.xhrGet({
				preventCache:  false,
				url: controller + "?action=cargarFacturaFactoringDireccionReceptor",
				handleAs: "text",
				sync: false,
				timeout: 10000
			});
			handler.addCallback(dojo.hitch(this, function(response){

			  html.set(dom.byId("divFacturaFactoringDireccionReceptor"),response, {
              parseContent: true
			  });
			}));
		});

	},

    // PAS20201U210100097 APDEX
	inicializarFacturaDireccionCliente: function(){

		require(["dojo/dom","dojo/dom-construct","dojo/html"], function(dom,domConstruct,html){
  			domConstruct.empty(dojo.byId(this.divFacturaDireccionCliente));
			var controller="emitir.do";
			var handler = dojo.xhrGet({
				preventCache:  false,
				url: controller + "?action=cargarFacturaDireccionCliente",
				handleAs: "text",
				sync: false,
				timeout: 10000
			});
			handler.addCallback(dojo.hitch(this, function(response){

			  html.set(dom.byId("divFacturaDireccionCliente"),response, {
              parseContent: true
			  });
			}));
		});

	},

	// PAS20201U210100097 APDEX
	inicializarFacturaEstablecimientoEmisor: function(){

		require(["dojo/dom","dojo/dom-construct","dojo/html"], function(dom,domConstruct,html){
  			domConstruct.empty(dojo.byId(this.divFacturaEstablecimientoEmisor));
			var controller="emitir.do";
			var handler = dojo.xhrGet({
				preventCache:  false,
				url: controller + "?action=cargarEstablecimientoEmisor",
				handleAs: "text",
				sync: false,
				timeout: 10000
			});
			handler.addCallback(dojo.hitch(this, function(response){

			  html.set(dom.byId("divFacturaEstablecimientoEmisor"),response, {
              parseContent: true
			  });
			}));
		});

	},

	// PAS20201U210100097 APDEX
	inicializarFacturaDocRelItem: function(){
		require(["dojo/dom","dojo/dom-construct","dojo/html"], function(dom,domConstruct,html){
  			domConstruct.empty(dojo.byId(this.divFacturaDocRelItem));
			var controller="emitir.do";
			var handler = dojo.xhrGet({
				preventCache:  false,
				url: controller + "?action=cargarFacturaDocRelItem",
				handleAs: "text",
				sync: false,
				timeout: 10000
			});
			handler.addCallback(dojo.hitch(this, function(response){

			  html.set(dom.byId("divFacturaDocRelItem"),response, {
              parseContent: true
			  });
			}));
		});
	},


	// PAS20201U210100097 APDEX
	inicializarFacturaInformacionRelSP: function(){
		require(["dojo/dom","dojo/dom-construct","dojo/html"], function(dom,domConstruct,html){
  			domConstruct.empty(dojo.byId(this.divFacturaInformacionRelSP));
			var controller="emitir.do";
			var handler = dojo.xhrGet({
				preventCache:  false,
				url: controller + "?action=cargarFacturaInformacionRelSP",
				handleAs: "text",
				sync: false,
				timeout: 10000
			});
			handler.addCallback(dojo.hitch(this, function(response){
			  html.set(dom.byId("divFacturaInformacionRelSP"),response, {
              parseContent: true
			  });
			}));
		});
	},

	// PAS20201U210100097 APDEX
	inicializarFacturaItem: function(){
		require(["dojo/dom","dojo/dom-construct","dojo/html"], function(dom,domConstruct,html){
  			domConstruct.empty(dojo.byId(this.divFacturaItem));
			var controller="emitir.do";
			var handler = dojo.xhrGet({
				preventCache:  false,
				url: controller + "?action=cargarFacturaItem",
				handleAs: "text",
				sync: false,
				timeout: 10000
			});

			handler.addCallback(dojo.hitch(this, function(response){
			  html.set(dom.byId("divFacturaItem"),response, {
              parseContent: true
			  });
			}));
		});
	},
	//PAS20201U210100230 -o INICIO
	inicializarFacturaFactoringCreditoItem: function(){

		if(this.globalCambiosFactoringHabilitados=="1"){
			require(["dojo/dom","dojo/dom-construct","dojo/html"], function(dom,domConstruct,html){
				domConstruct.empty(dojo.byId(this.divFacturaInformacionCreditoItem));
				var controller="emitir.do";
				var handler = dojo.xhrGet({
					preventCache:  false,
					url: controller + "?action=cargarFacturaFactoringCreditoItem",
					handleAs: "text",
					sync: false,
					timeout: 10000
				});
				handler.addCallback(dojo.hitch(this, function(response){
				html.set(dom.byId("divFacturaInformacionCreditoItem"),response, {
				parseContent: true
				});
				}));
			});
		}
	},
	inicializarFacturaFactoringCuota: function(){
		if(this.globalCambiosFactoringHabilitados=="1"){
			require(["dojo/dom","dojo/dom-construct","dojo/html"], function(dom,domConstruct,html){
				domConstruct.empty(dojo.byId(this.divFacturaInformacionCuota));
				var controller="emitir.do";
				var handler = dojo.xhrGet({
					preventCache:  false,
					url: controller + "?action=cargarFacturaFactoringCuota",
					handleAs: "text",
					sync: false,
					timeout: 10000
				});
				handler.addCallback(dojo.hitch(this, function(response){
				html.set(dom.byId("divFacturaInformacionCuota"),response, {
				parseContent: true
				});
				}));
			});
		}
	},
	//PAS20201U210100230 -o FIN

	initContent: function(param) {
		this.initialize();
		self = this;
		dijit.focus(dojo.byId("factura.numeroDocumento"));

		dijit.byId("inicio.facturaFactoring.subTipoTT01").setChecked("checked"); //PAS20201U210100230
		dijit.byId("inicio.facturaFactoring.subTipoTT01").setValue("1"); //PAS20201U210100230
		dijit.byId("inicio.subTipoEE00").setChecked("checked");
		dijit.byId("inicio.subTipoEE00").setValue("0");
		dijit.byId("inicio.subTipoND00").setChecked("checked");
		dijit.byId("inicio.subTipoND00").setValue("0");
		dijit.byId("inicio.subTipoIM00").setChecked("checked");
		dijit.byId("inicio.subTipoIM00").setValue("IM00");
		dijit.byId("inicio.subTipoDE00").setChecked("checked");
		dijit.byId("inicio.subTipoDE00").setValue("DE00");
		dijit.byId("inicio.subTipoEstEmi01").setChecked("checked");
		dijit.byId("inicio.subTipoEstEmi01").setValue("1");
		dijit.byId("inicio.subTipoDPPNN00").setChecked("checked");

		this.showOpcionesExportacion(0);
		this.showOpcionesTransaccion(1); //PAS20201U210100230
	},

	isValidRuc: function(ruc) {
		ruc = dojo.trim(ruc);
		if(!isNaN(ruc)) {
			if(ruc.length == 8) {
				suma = 0;
				for(i=0; i < ruc.length-1; i++) {
					digito = ruc.charAt(i) - '0';
					if(i == 0) suma += (digito * 2);
					else suma += (digito * (ruc.length - i));
				}
				resto = suma % 11;
				if(resto == 1) resto = 11;
				if(resto + (ruc.charAt(ruc.length - 1) - '0') == 11) {
					return true;
				}
			}
			else if(ruc.length == 11){
				suma = 0;
				x = 6;
				for(i=0; i < ruc.length - 1; i++) {
					if(i == 4) x = 8;
					digito = ruc.charAt(i) - '0';
					x--;
					if(i == 0) suma += (digito * x);
					else suma += (digito * x);
				}
				resto = suma % 11;
				resto = 11 - resto;
				if(resto >= 10) resto = resto - 10;
				if(resto == ruc.charAt(ruc.length - 1) - '0') {
					return true;
				}
			}
		}
		return false;
	},

	//PAS20175E210300029
	asignarIGVDiferente: function(igvPorcentaje, mostrarMensajes, fechaMinIgvPorcentaje, fechaMaxIgvPorcentaje){
		this.wait("Asignando", "110px", 200);
		var handler = dojo.xhrGet({
			preventCache:  false,
			url: this.controller + "?action=asignarIGVDiferente&igvDiferente=" + igvPorcentaje,
			handleAs: "json",
			sync: true,
			timeout: 10000
		});
		handler.addCallback(dojo.hitch(this, function(response){
			if(response.codeError == 0) {
				igvPorcentaje = response.data;
			} else {
				mostrarMensaje(response.messageError);
			}
		}));
		handler.addErrback(function(response){
			mostrarMensaje("Ocurrio un error al recuperar la validaci\u00F3n del periodo de emisi\u00F3n del comprobante.");
		});

		dojo.byId("global.fechaMinIgvPorcentaje").value = fechaMinIgvPorcentaje;
		dojo.byId("global.fechaMaxIgvPorcentaje").value = fechaMaxIgvPorcentaje;

		dojo.byId("global.igvPorcentajeInicial").value = igvPorcentaje / 100;
		dojo.byId("global.igvPorcentaje").value = igvPorcentaje / 100;
		document.getElementById("tablaIngreso.labelIgvPorcentaje").innerHTML = "IGV (" + igvPorcentaje + "%)";

		if (mostrarMensajes){
			this.iconTooltipMessage("factura.fechaEmision", "icon-ok-tooltip", "La fecha de emisi\u00F3n seleccionada tiene otro valor de IGV (" + igvPorcentaje + ").");
		}
	},

	//PAS20175E210300029
	setFechaEmisionHoy: function(){
		//dijit.byId("factura.fechaEmision").setValue(new Date());
		var parts = dojo.byId("factura.fechaActual").value.split('-');
		var fechaActualRecuperado = new Date(parts[0],parts[1]-1,parts[2]);
		dijit.byId("factura.fechaEmision").setValue(fechaActualRecuperado);
	},

	//PAS20175E210300029
	setFechaEmisionPrevia: function(){
		dojo.byId("global.fecEmisionChange").value = "0";

		if (dojo.byId("global.fecEmisionPrevia").value == ""){
			this.setFechaEmisionHoy();
		} else {
			var fechaActualRecuperado = new Date(new Date(dojo.byId("global.fecEmisionPrevia").value));
			dijit.byId("factura.fechaEmision").setValue(fechaActualRecuperado);
		}
	},

	//PAS20175E210300029
	validarFechaEmision: function(validarFechaIgvVigente){
		response = true;
		if (dojo.byId("global.fecEmisionChange").value == "1"){
			if (dijit.byId("factura.fechaEmision").getValue() !=null && dijit.byId("factura.fechaEmision").getValue() !=""){
				var fechaEmision = dojo.date.locale.format(dijit.byId("factura.fechaEmision").getValue(), {datePattern: "yyyyMMdd", selector: "date"});
				//var fechaEmision = "20161201";
				dojo.byId("global.fecEmision").value = dojo.date.locale.format(dijit.byId("factura.fechaEmision").getValue(), {datePattern: "MM/dd/yyyy", selector: "date"});

				var diasAnticipadosEmisionComprobante = dojo.number.parse(dojo.byId("factura.diasAnticipadosEmisionComprobante").value);
				var parts =dojo.byId("factura.fechaActual").value.split('-');
				var fechaActualRecuperado = new Date(parts[0],parts[1]-1,parts[2]);

				//var fechaActual  = dojo.date.locale.format(new Date(), {datePattern: "yyyyMMdd", selector: "date"});
				//var fechaAnterior = dojo.date.locale.format(dojo.date.add(new Date(),"day",-2), {datePattern: "yyyyMMdd", selector: "date"});
				var fechaActual  = dojo.date.locale.format(fechaActualRecuperado, {datePattern: "yyyyMMdd", selector: "date"});
				var fechaAnterior = dojo.date.locale.format(dojo.date.add(fechaActualRecuperado,"day",diasAnticipadosEmisionComprobante), {datePattern: "yyyyMMdd", selector: "date"});

				if (fechaEmision < fechaAnterior || fechaEmision > fechaActual){
					this.iconTooltipMessage("factura.fechaEmision", "icon-ok-tooltip", "Fecha de Emisi\u00F3n solo puede ser entre dos d\u00EDas antes y el d\u00EDa de hoy.");
					response = false;
				} else if (fechaActual.substring(4,6) > fechaEmision.substring(4,6)){
					var noPresentaLibrosPeriodo = 0;

					this.wait("Consultando", "110px", 200);
					var handler = dojo.xhrGet({
						preventCache:  false,
						url: this.controller + "?action=recuperarNoPresentaLibrosPeriodo&anio=" + fechaEmision.substring(0,4) + "&mes=" + fechaEmision.substring(4,6),
						handleAs: "json",
						sync: true,
						timeout: 10000
					});
					handler.addCallback(dojo.hitch(this, function(response){
						if(response.codeError == 0) {
							noPresentaLibrosPeriodo = response.data;
						} else {
							mostrarMensaje(response.messageError);
						}
					}));
					handler.addErrback(function(response){
						mostrarMensaje("Ocurrio un error al recuperar la validaci\u00F3n del periodo de emisi\u00F3n del comprobante.");
					});

					this.waitMessage.hide();
					if (noPresentaLibrosPeriodo != "1"){
						response = false;
					}
				}

				if ((response) && (validarFechaIgvVigente !=null) && (validarFechaIgvVigente)){
					parts = dojo.byId("global.fechaMinIgvPorcentaje").value.split('/');
					var fechaMinIgv = parts[2] + parts[1] + parts[0];

					if (fechaEmision < fechaMinIgv){
						this.wait("Consultando", "110px", 200);

						var handler = dojo.xhrGet({
							preventCache:  false,
							url: this.controller + "?action=recuperarIgvConFecha&anio=" + fechaEmision.substring(0,4) + "&mes=" + fechaEmision.substring(4,6) + "&dia=" + fechaEmision.substring(6,8),
							handleAs: "json",
							sync: true,
							timeout: 10000
						});
						handler.addCallback(dojo.hitch(this, function(response){
							if(response.codeError == 0) {
								var row = eval("(" + response.data + ")");
								var igvPorcentajeGlobalAnterior = row.igvVigente;
								var fechaMinIgvPorcentaje = row.fechaMinIgvPorcentaje;
								var fechaMaxIgvPorcentaje = row.fechaMaxIgvPorcentaje;

								var grilla = dijit.byId("factura.ingreso-grid");
								var filas = grilla.rowCount;

								if (filas > 0){
									var mensajeCambioIGV = "La fecha de emisi\u00F3n seleccionada tiene otro valor de IGV (" + igvPorcentajeGlobalAnterior + "), tendr\u00E1 que volver a ingresar los items \u00BFDesea Continuar?";
									mostrarMensajeConfirmacion(mensajeCambioIGV,
										dojo.hitch(this, function(){
											this.eliminarItemsAll();
											this.asignarIGVDiferente(igvPorcentajeGlobalAnterior, true, fechaMinIgvPorcentaje, fechaMaxIgvPorcentaje);
										}), dojo.hitch(this, function(){
											this.setFechaEmisionPrevia();
											response = false;
										}));
									//if (confirm(mensajeCambioIGV)){
									//	this.eliminarItemsAll();
									//	this.asignarIGVDiferente(igvPorcentajeGlobalAnterior, true, fechaMinIgvPorcentaje, fechaMaxIgvPorcentaje);
									//} else {
									//	this.setFechaEmisionPrevia();
									//	response = false;
									//}
								} else {
									this.asignarIGVDiferente(igvPorcentajeGlobalAnterior, true, fechaMinIgvPorcentaje, fechaMaxIgvPorcentaje);
								}
							} else {
								mostrarMensaje(response.messageError);
							}
						}));
						handler.addErrback(function(response){
							mostrarMensaje("Ocurrio un error al recuperar la validaci\u00F3n del periodo de emisi\u00F3n del comprobante.");
						});

						this.waitMessage.hide();
					} else if (dojo.byId("global.fechaMaxIgvPorcentaje").value != "") {
						parts = dojo.byId("global.fechaMaxIgvPorcentaje").value.split('/');
						var fechaMaxIgv = parts[2] + parts[1] + parts[0];

						if (fechaEmision > fechaMaxIgv){
							this.wait("Consultando", "110px", 200);

							var handler = dojo.xhrGet({
								preventCache:  false,
								url: this.controller + "?action=recuperarIgvConFecha&anio=" + fechaEmision.substring(0,4) + "&mes=" + fechaEmision.substring(4,6) + "&dia=" + fechaEmision.substring(6,8),
								handleAs: "json",
								sync: true,
								timeout: 10000
							});
							handler.addCallback(dojo.hitch(this, function(response){
								if(response.codeError == 0) {
									var row = eval("(" + response.data + ")");
									var igvPorcentajeGlobalAnterior = row.igvVigente;
									dojo.byId("global.fechaMinIgvPorcentaje").value = row.fechaMinIgvPorcentaje;
									dojo.byId("global.fechaMaxIgvPorcentaje").value = row.fechaMaxIgvPorcentaje;

									this.iconTooltipMessage("factura.fechaEmision", "icon-ok-tooltip", "La fecha de emisi\u00F3n seleccionada tiene otro valor de IGV (" + igvPorcentajeGlobalAnterior + ").");
									var grilla = dijit.byId("factura.ingreso-grid");
									var filas = grilla.rowCount;

									if (filas > 0){
										var mensajeCambioIGV = "La fecha de emisi\u00F3n seleccionada tiene otro valor de IGV (" + igvPorcentajeGlobalAnterior + "), tendr\u00E1 que volver a ingresar los items \u00BFDesea Continuar?";
										mostrarMensajeConfirmacion(mensajeCambioIGV, dojo.hitch(this, function(){
											this.asignarIGVDiferente(igvPorcentajeGlobalAnterior);
											this.eliminarItemsAll();
										}), dojo.hitch(this, function(){
											this.setFechaEmisionPrevia();
											response = false;
										}));
										//if (confirm(mensajeCambioIGV)){
										//	this.asignarIGVDiferente(igvPorcentajeGlobalAnterior);
										//	this.eliminarItemsAll();
										//} else {
										//	this.setFechaEmisionPrevia();
										//	response = false;
										//}
									} else {
										this.asignarIGVDiferente(igvPorcentajeGlobalAnterior);
									}
								} else {
									mostrarMensaje(response.messageError);
								}
							}));
							handler.addErrback(function(response){
								mostrarMensaje("Ocurrio un error al recuperar la validaci\u00F3n del periodo de emisi\u00F3n del comprobante.");
							});

							this.waitMessage.hide();
						}
					}
				}

				if (response){
					dojo.byId("global.fecEmisionPrevia").value = dojo.date.locale.format(dijit.byId("factura.fechaEmision").getValue(), {datePattern: "MM/dd/yyyy", selector: "date"});
				}
			} else {
				this.iconTooltipMessage("factura.fechaEmision", "icon-ok-tooltip", "Debe registrar la Fecha de Emisi\u00F3n.");
				response = false;
			}
		} else {
			dojo.byId("global.fecEmisionChange").value = "1";
		}
		return response;
	},


	validarFechaEmisionContin: function(validarFechaIgvVigente){
		response = true;
		if (dojo.byId("global.fecEmisionChange").value == "1"){
			if (dijit.byId("factura.fechaEmision").getValue() !=null && dijit.byId("factura.fechaEmision").getValue() !=""){
				var fechaEmision = dojo.date.locale.format(dijit.byId("factura.fechaEmision").getValue(), {datePattern: "yyyyMMdd", selector: "date"});
				//var fechaEmision = "20161201";
				dojo.byId("global.fecEmision").value = dojo.date.locale.format(dijit.byId("factura.fechaEmision").getValue(), {datePattern: "MM/dd/yyyy", selector: "date"});

				var diasAnticipadosEmisionComprobante = dojo.number.parse(dojo.byId("factura.diasAnticipadosEmisionComprobante").value);
				var parts =dojo.byId("factura.fechaActual").value.split('-');
				var fechaActualRecuperado = new Date(parts[0],parts[1]-1,parts[2]);

				//var fechaActual  = dojo.date.locale.format(new Date(), {datePattern: "yyyyMMdd", selector: "date"});
				//var fechaAnterior = dojo.date.locale.format(dojo.date.add(new Date(),"day",-2), {datePattern: "yyyyMMdd", selector: "date"});
				var fechaActual  = dojo.date.locale.format(fechaActualRecuperado, {datePattern: "yyyyMMdd", selector: "date"});
				var fechaAnterior = dojo.date.locale.format(dojo.date.add(fechaActualRecuperado,"day",diasAnticipadosEmisionComprobante), {datePattern: "yyyyMMdd", selector: "date"});
				var fechaActualAdd2  = dojo.date.locale.format(dojo.date.add(new Date(),"day",2), {datePattern: "yyyyMMdd", selector: "date"});
				if (fechaEmision > fechaActualAdd2){
					this.iconTooltipMessage("factura.fechaEmision", "icon-ok-tooltip", "Fecha de Emisi\u00F3n solo puede ser dos d\u00EDas despues del d\u00EDa de hoy.");
					response = false;
				}
				/* PAS20181U210300223 - contingencia no valida si el libro fue presentado
				else if (fechaActual.substring(4,6) > fechaEmision.substring(4,6)){
					var noPresentaLibrosPeriodo = 0;

					this.wait("Consultando", "110px", 200);
					var handler = dojo.xhrGet({
						preventCache:  false,
						url: this.controller + "?action=recuperarNoPresentaLibrosPeriodo&anio=" + fechaEmision.substring(0,4) + "&mes=" + fechaEmision.substring(4,6),
						handleAs: "json",
						sync: true,
						timeout: 10000
					});
					handler.addCallback(dojo.hitch(this, function(response){
						if(response.codeError == 0) {
							noPresentaLibrosPeriodo = response.data;
						} else {
							mostrarMensaje(response.messageError);
						}
					}));
					handler.addErrback(function(response){
						mostrarMensaje("Ocurrio un error al recuperar la validaci\u00F3n del periodo de emisi\u00F3n del comprobante.");
					});

					this.waitMessage.hide();
					if (noPresentaLibrosPeriodo != "1"){
						response = false;
					}
				}*/


				if ((response) && (validarFechaIgvVigente !=null) && (validarFechaIgvVigente)){
					parts = dojo.byId("global.fechaMinIgvPorcentaje").value.split('/');
					var fechaMinIgv = parts[2] + parts[1] + parts[0];

					if (fechaEmision < fechaMinIgv){
						this.wait("Consultando", "110px", 200);

						var handler = dojo.xhrGet({
							preventCache:  false,
							url: this.controller + "?action=recuperarIgvConFecha&anio=" + fechaEmision.substring(0,4) + "&mes=" + fechaEmision.substring(4,6) + "&dia=" + fechaEmision.substring(6,8),
							handleAs: "json",
							sync: true,
							timeout: 10000
						});
						handler.addCallback(dojo.hitch(this, function(response){
							if(response.codeError == 0) {
								var row = eval("(" + response.data + ")");
								var igvPorcentajeGlobalAnterior = row.igvVigente;
								var fechaMinIgvPorcentaje = row.fechaMinIgvPorcentaje;
								var fechaMaxIgvPorcentaje = row.fechaMaxIgvPorcentaje;

								var grilla = dijit.byId("factura.ingreso-grid");
								var filas = grilla.rowCount;

								if (filas > 0){
									var mensajeCambioIGV = "La fecha de emisi\u00F3n seleccionada tiene otro valor de IGV (" + igvPorcentajeGlobalAnterior + "), tendr\u00E1 que volver a ingresar los items \u00BFDesea Continuar?";
									mostrarMensajeConfirmacion(mensajeCambioIGV,
									dojo.hitch(this, function(){
										this.eliminarItemsAll();
										this.asignarIGVDiferente(igvPorcentajeGlobalAnterior, true, fechaMinIgvPorcentaje, fechaMaxIgvPorcentaje);
									}), dojo.hitch(this, function(){
										this.setFechaEmisionPrevia();
										response = false;
									}))
									//if (confirm(mensajeCambioIGV)){
									//	this.eliminarItemsAll();
									//	this.asignarIGVDiferente(igvPorcentajeGlobalAnterior, true, fechaMinIgvPorcentaje, fechaMaxIgvPorcentaje);
									//} else {
									//	this.setFechaEmisionPrevia();
									//	response = false;
									//}
								} else {
									this.asignarIGVDiferente(igvPorcentajeGlobalAnterior, true, fechaMinIgvPorcentaje, fechaMaxIgvPorcentaje);
								}
							} else {
								mostrarMensaje(response.messageError);
							}
						}));
						handler.addErrback(function(response){
							mostrarMensaje("Ocurrio un error al recuperar la validaci\u00F3n del periodo de emisi\u00F3n del comprobante.");
						});

						this.waitMessage.hide();
					} else if (dojo.byId("global.fechaMaxIgvPorcentaje").value != "") {
						parts = dojo.byId("global.fechaMaxIgvPorcentaje").value.split('/');
						var fechaMaxIgv = parts[2] + parts[1] + parts[0];

						if (fechaEmision > fechaMaxIgv){
							this.wait("Consultando", "110px", 200);

							var handler = dojo.xhrGet({
								preventCache:  false,
								url: this.controller + "?action=recuperarIgvConFecha&anio=" + fechaEmision.substring(0,4) + "&mes=" + fechaEmision.substring(4,6) + "&dia=" + fechaEmision.substring(6,8),
								handleAs: "json",
								sync: true,
								timeout: 10000
							});
							handler.addCallback(dojo.hitch(this, function(response){
								if(response.codeError == 0) {
									var row = eval("(" + response.data + ")");
									var igvPorcentajeGlobalAnterior = row.igvVigente;
									dojo.byId("global.fechaMinIgvPorcentaje").value = row.fechaMinIgvPorcentaje;
									dojo.byId("global.fechaMaxIgvPorcentaje").value = row.fechaMaxIgvPorcentaje;

									this.iconTooltipMessage("factura.fechaEmision", "icon-ok-tooltip", "La fecha de emisi\u00F3n seleccionada tiene otro valor de IGV (" + igvPorcentajeGlobalAnterior + ").");
									var grilla = dijit.byId("factura.ingreso-grid");
									var filas = grilla.rowCount;

									if (filas > 0){
										var mensajeCambioIGV = "La fecha de emisi\u00F3n seleccionada tiene otro valor de IGV (" + igvPorcentajeGlobalAnterior + "), tendr\u00E1 que volver a ingresar los items \u00BFDesea Continuar?";
										mostrarMensajeConfirmacion(mensajeCambioIGV, dojo.hitch(this, function(){
											this.asignarIGVDiferente(igvPorcentajeGlobalAnterior);
											this.eliminarItemsAll();
										}), dojo.hitch(this, function(){
											this.setFechaEmisionPrevia();
											response = false;
										}));
										//if (confirm(mensajeCambioIGV)){
										//	this.asignarIGVDiferente(igvPorcentajeGlobalAnterior);
										//	this.eliminarItemsAll();
										//} else {
										//	this.setFechaEmisionPrevia();
										//	response = false;
										//}
									} else {
										this.asignarIGVDiferente(igvPorcentajeGlobalAnterior);
									}
								} else {
									mostrarMensaje(response.messageError);
								}
							}));
							handler.addErrback(function(response){
								mostrarMensaje("Ocurrio un error al recuperar la validaci\u00F3n del periodo de emisi\u00F3n del comprobante.");
							});

							this.waitMessage.hide();
						}
					}
				}

				if (response){
					dojo.byId("global.fecEmisionPrevia").value = dojo.date.locale.format(dijit.byId("factura.fechaEmision").getValue(), {datePattern: "MM/dd/yyyy", selector: "date"});
				}
			} else {
				this.iconTooltipMessage("factura.fechaEmision", "icon-ok-tooltip", "Debe registrar la Fecha de Emisi\u00F3n.");
				response = false;
			}
		} else {
			dojo.byId("global.fecEmisionChange").value = "1";
		}
		return response;
	},

	validarFechaVencimiento: function() {
		response = true;

		if (dijit.byId("factura.fechaVencimiento").getValue() !=null && dijit.byId("factura.fechaVencimiento").getValue() !=""){
			dojo.byId("global.fecVencimiento").value = dojo.date.locale.format(dijit.byId("factura.fechaVencimiento").getValue(), {datePattern: "MM/dd/yyyy", selector: "date"}) ;

		    var fechaActual  = dojo.date.locale.format(new Date(), {datePattern: "yyyyMMdd", selector: "date"});
		    var fechaVencimiento = dojo.date.locale.format(dijit.byId("factura.fechaVencimiento").getValue(), {datePattern: "yyyyMMdd", selector: "date"});

		    if (fechaVencimiento <= fechaActual){
			    this.iconTooltipMessage("factura.fechaVencimiento", "icon-ok-tooltip", "Fecha de Vencimiento debe ser mayor al d\u00EDa de hoy.");
			    response = false;
			}
		}

		return response;
	},

	docRelDocument: function() {
		if(!dijit.byId("factura.form").validate()) return;

		var totalItems = this.getTotalItemsEnGrid();

		if(totalItems < 1) {
			var node = dijit.byId("factura.addItemButton");
			node.focusNode;
			mostrarMensaje("Por favor ingrese por lo menos un ítem.");
			return;
		}

		/* Inicio PAS20201U210100285 - jmendozas */
		if(dojo.byId("factura.montoRedondeo") != null){ /* PAS20201U210100285 - Factura Contingencia */
			var totalRedondeo = dijit.byId("factura.montoRedondeo").getValue(); /* PAS20201U210100285 - jmendozas */
			if (totalItems < 1 && totalRedondeo != ""){
				var node = dijit.byId("factura.addItemButton");
				node.focusNode;
				mostrarMensaje("Por favor ingrese por lo menos un &iacute;tem.");
				return;
			}
			if (totalRedondeo > 0.09 || totalRedondeo < -0.09){
				var node = dijit.byId("factura.montoRedondeo");
				this.warnTooltipMessage(node.focusNode, "El monto m&iacute;nimo es -0.09 y el m&aacute;ximo +0.09");
				return;
			}

			/* Validación Monto de Redondeo - Operaciones Gratuitas */
			if (dojo.byId("global.opcionOperacionesGratuitas").value == "1") {
				var array = dijit.byId("factura.ingreso-grid").store._arrayOfTopLevelItems;
				var cant_op_gratuitas = 0;
				for (var i = 0; i < array.length; i++){
					if (array[i].tipoBonificacion == "BO01"){
						cant_op_gratuitas++;
					}
				}
				if (cant_op_gratuitas == array.length && totalRedondeo != 0){
					mostrarMensaje("En caso de haber ingresado todos los ítems como Operaciones Gratuitas, no se debe ingresar el monto de redondeo del comprobante.")
					return;
				}
			}
			/* Fin PAS20201U210100285 - Sandra Medrano Parado */

			/* Inicio PAS20201U210100285 - Giancarlo Nepo López */
			/* Inicio Validación Monto de Redondeo - Boleta de Venta tiene Descuentos o Deduce Anticipos */
			if (dojo.byId("global.opcionPagoDeduccionAnticipado").value == "DE01") {
				var importeTotal = dojo.byId("factura.totalGeneral").value;
				var importeRedondeo = dojo.byId("factura.montoRedondeo").value;
				if (totalRedondeo != 0){
					if (importeTotal == importeRedondeo){
						mostrarMensaje("El monto de redondeo no debe ser igual al importe total del comprobante.");
						return;
					}
				}
			}
			/* Fin Validación Monto de Redondeo - Boleta de Venta tiene Descuentos o Deduce Anticipos */
			/* Fin PAS20201U210100285 - Giancarlo Nepo López */
		}

		/*Inicio INC 2015-023392*/
		//if(totalItems > 19) {
		if(totalItems > 20 ) {
			mostrarMensaje("El máximo número de ítems a ingresar no debe exceder de 20.");
			return;
		}
		/*Fin INC 2015-023392*/

		var varTotalCT = this.getTotalItemsEnGridQueSonCargoTributo();
		if (totalItems == varTotalCT){
			mostrarMensaje("Debe registrar por lo menos un item que no sea cargo o tributo.");
			return;
		}

		var varTotalItemsGravados = this.getTotalItemsEnGridQueSonGravados();
		var varTotalItemsExonerados = this.getTotalItemsEnGridQueSonExonerados();
		var varTotalItemsInafectos = this.getTotalItemsEnGridQueSonInafectos();
		var varTotalItemsConISC = this.getTotalItemsEnGridQueTienenISC();
		var varTotalItemsBienes= this.getTotalItemsEnGridQueSonBienes();

		if (dojo.byId("global.opcionPagoAnticipado").value =="1"){
			if (totalItems == varTotalItemsGravados || totalItems == varTotalItemsExonerados || totalItems == varTotalItemsInafectos){

			}else{
					mostrarMensaje("Todos los ítems deben tener el mismo tipo de afectación: Gravados, Exonerados o Inafectos.");
					  return;
			}

			if (totalItems == varTotalItemsConISC || varTotalItemsConISC == 0 ){

			}else{
				mostrarMensaje("Si usa ISC, todos los ítems deben estar afectos.");
				return;
			}
		  }else{
			  var varTotalAnticipos = this.getTotalItemsEnGridQueSonAnticipos();
			if (totalItems == varTotalAnticipos){
				mostrarMensaje("Debe registrar por lo menos un ítem que no sea anticipo.");
				return;
			}
		}

		if (dojo.byId("global.opcionPagoDeduccionAnticipado").value =="DE01"){
			var itemsIncorrectosFechaAnticipo = this.getItemsCompararFechaAnticipado();
			if (itemsIncorrectosFechaAnticipo != ""){
				mostrarMensaje("En el ítem " + itemsIncorrectosFechaAnticipo + ", la fecha de emisión de la factura de Anticipo no puede ser mayor a la fecha de emisión del comprobante.");
				return;
			}
		}
		//PAS20201U210100230  ini opv
		//dojo.byId("global.importeTotal").value = dijit.byId("factura.totalGeneral").getValue();
		//PAS20201U210100230  fin opv
		// INICIO PAS20211U210700145 - AVN
		/*if (dojo.byId("global.opcionTipoTransaccion").value =="1"){
					dojo.byId("global.fecVencimiento").value  = "";
			if (!this.validarFechaVencimiento()){
				return;
			}
		}*/
		// FIN PAS20211U210700145 - AVN

		dojo.byId("global.fecEmision").value  = "";
		if (!this.validarFechaEmision(false)){
			return;
		}

		if (dojo.byId("global.opcionDomicilioCliente").value == "1" &&
      		dijit.byId("factura.direccionCliente").value == ""){
			mostrarMensaje("Debe registrar la dirección del cliente.");
			return;
		}

		if (dojo.byId("global.opcionEstablecimientoEmisor").value == "1" &&	dijit.byId("factura.establecimientoEmisor").value == ""){
			mostrarMensaje("Debe registrar la dirección del Emisor.");
			return;
		}

		//Si indico que sustenta traslado de bienes
		if (dojo.byId("global.opcionSustentoTrasladoBienes").value == "1") {
	  		if (varTotalItemsBienes == 0 ){
	  			//if (!confirm("No se ha especificado bienes en la factura para el traslado. ¿Desea continuar con la emisión de la Factura?")){
	  			//	return;
	  			//}
				mostrarMensajeConfirmacion("No se ha especificado bienes en la factura para el traslado. ¿Desea continuar con la emisión de la Factura?", dojo.hitch(this, function() { }) );
	  		}
		}

		//INI PAS20191U210100075
		var array = dijit.byId("factura.ingreso-grid").store._arrayOfTopLevelItems;
		var contImpuestoBolsas = 0;
		for (var i = 0; i < array.length; i++) {
			if (array[i].esImpuestoBolsaPlastico == "IBP00" ) {
				contImpuestoBolsas += 1;
			}
		}

		var parts = dojo.byId("factura.fechaEmision").value.split('/');
		var fechaEmision = new Date(parts[2],parts[1]-1,parts[0]);

		//fecha properties
		var parts2 = dojo.byId("item.FechaProperties").value.split('/');
		var fechaproperties = new Date(parts2[2],parts2[1]-1,parts2[0]);

		console.log("items con icbper :" + contImpuestoBolsas);
		console.log(dojo.byId("factura.fechaEmision").value);
		console.log(dojo.byId("item.FechaProperties").value);

		if((fechaEmision < fechaproperties) && contImpuestoBolsas > 0){
			mostrarMensaje("No puede cambiar la fecha de emisión, existen ítems agregados con ICBPER.");
			return false;
		}
		//FIN PAS20191U210100075

		//INICIO PAS20201U210100285 - jmendozas

		if(dojo.byId("factura.montoRedondeo") != null){ /* PAS20201U210100285 - Factura Contingencia */
			dojo.byId("global.montoRedondeo").value = 0.00;
			if(dijit.byId("factura.montoRedondeo")!=undefined && (dijit.byId("factura.montoRedondeo").getValue()<=0.09 && dijit.byId("factura.montoRedondeo").getValue()>=-0.09)){
				var montoRedondeo = dijit.byId("factura.montoRedondeo").getValue();
				dojo.byId("global.montoRedondeo").value=montoRedondeo;
			}
		}
		//FIN PAS20201U210100285
		//Verifica si existe algun item con exonerado o inafecto
		dojo.byId("global.flagExoInafecto").value = this.checkExoneradoInafecto();

	  var accionBtn01 = dojo.hitch(this, function() {
		var nbControl = dijit.byId("factura.botonGrabarDocumento");
		nbControl.setAttribute('disabled', true);
		this.wait("Procesando", "110px", 200);
		var nodeButton = nbControl.focusNode;

		this.validatePuedeEmitirRetencion(nbControl);//PAS20201U210100230

		var handler = dojo.io.iframe.send({
			url: this.controller,
			handleAs: "json",
			sync: true,
			timeout: 10000,
			preventCache: true,
			form: "factura.form"
		});

		handler.addCallback(dojo.hitch(this, function(res){
			this.waitMessage.hide();
			if(res.codeError == 0) {
				this.content.onLoad = dojo.hitch(this, function(){
					var moneda = dojo.byId("global.tipoMoneda").value;

				});
				this.content.setHref(this.controller + "?action=showDocRelComprobante&preventCache=" + this.preventCache());

				this.content.onLoad = dojo.hitch(this, function(){

  					dijit.byId("docsrel.observacion").setValue(dojo.byId("global.docsrel.observacion").value);


					if (dojo.byId("global.opcionFESectorPublico").value == "1") {
						this.showHiddenDiv(document.getElementById("docsrel.informacionFESectorPublico.show"),true);
					}else{
						this.showHiddenDiv(document.getElementById("docsrel.informacionFESectorPublico.show"),false);
					}
						if (dojo.byId("global.opcionSustentoTrasladoBienes").value == "1") {
							this.showHiddenDiv(document.getElementById("docsrel.informacionTrasladoBienes.show"),true);
					}else{
						this.showHiddenDiv(document.getElementById("docsrel.informacionTrasladoBienes.show"),false);
					}

					if (dojo.byId("global.opcionSPOT").value == "1") {
							this.showHiddenDiv(document.getElementById("docsrel.informacionRecursosHidrobiologicos.show"),true);
					}else{
						this.showHiddenDiv(document.getElementById("docsrel.informacionRecursosHidrobiologicos.show"),false);
					}

						if (dojo.byId("global.opcionPlacaVehiculo").value == "1") {
							this.showHiddenDiv(document.getElementById("docsrel.informacionPlacaVentaCombustible.show"),true);
							dijit.byId("docsrel.placaVentaCombustible").setValue(dojo.byId("global.docsrel.placaVentaCombustible").value);
					}else{
						this.showHiddenDiv(document.getElementById("docsrel.informacionPlacaVentaCombustible.show"),false);
					}
					if (dojo.byId("global.opcionSustentoTrasladoBienes").value == "1") {
							//this.iconTooltipMessage("docsrel.botonInformacionTrasladoBienes", "icon-ok-tooltip", "Debe registrar punto de partida y punto de llegada.");
					}
					//PAS20201U210100230   INI MOSTRAR OCULTAR INF CREDITO OPV
					if (dojo.byId("global.opcionTipoTransaccion")!=null){
						console.log("opcion TipoTransaccion: "+dojo.byId("global.opcionTipoTransaccion").value);
						if (dojo.byId("global.opcionTipoTransaccion").value == "2") {// INI - PAS20211U210700145 - AFT
							console.log("tipoDocumento : "+dojo.byId("global.tipoDocumento").value);
							var td = dojo.byId("global.tipoDocumento").value;
							if (td == "6"){
								this.showHiddenDiv(document.getElementById("docsrel.informacionCredito.show"),true);
								this.showHiddenDiv(document.getElementById("docsrel.informacionCreditoAnuncio.show"),true);
							}else{
								this.showHiddenDiv(document.getElementById("docsrel.informacionCredito.show"),false);
								this.showHiddenDiv(document.getElementById("docsrel.informacionCreditoAnuncio.show"),false);
							}// FIN - PAS20211U210700145 - AFT
						}else{
							console.log("opcion informacionCredito");
							this.showHiddenDiv(document.getElementById("docsrel.informacionCredito.show"),false);
							this.showHiddenDiv(document.getElementById("docsrel.informacionCreditoAnuncio.show"),false);
						}


						if (dojo.byId("global.puedeEmitirRetencion").value == "1") { //VISIBLE
							this.showHiddenDiv(document.getElementById("docsrel.informacionRetencion.show"),true);
							this.showHiddenDiv(document.getElementById("docsrel.informacionRetencionAnuncio.show"),true);
						}else{
							this.showHiddenDiv(document.getElementById("docsrel.informacionRetencion.show"),false);
							this.showHiddenDiv(document.getElementById("docsrel.informacionRetencionAnuncio.show"),false);
						}
					}
                    //PAS20201U210100230   FIN OPV
				});

			} else {
				nbControl.setAttribute('disabled', false);
				this.waitMessage.hide();
				mostrarMensaje(res.messageError);
			}
		}));

		handler.addErrback(function(res){
			nbControl.setAttribute('disabled', false);
			this.waitMessage.hide();
			mostrarMensaje("Problemas al conectarse con el servidor");
		});
	  });

		// PAS20191U210100204
		if (this.getExisteDuplicados() > 0){
			//// !confirm("Antes de continuar\nExisten ítems con información duplicada ¿Desea continuar?")){
			//return;
			mostrarMensajeConfirmacion("Antes de continuar\nExisten ítems con información duplicada ¿Desea continuar?", accionBtn01 );
		}else{
			accionBtn01();
		}

	},

	docRelDocumentContin: function() {
		//Gimy, validacion de numero de serie
		var numero = document.getElementById("numero").value;
		if(numero!=""){

		if(!dijit.byId("factura.form").validate()) return;

		var totalItems = this.getTotalItemsEnGrid();
		if(totalItems < 1) {
			var node = dijit.byId("factura.addItemButton");
			node.focusNode;
			mostrarMensaje("Por favor ingrese por lo menos un item.");
			return;
		}
		/*Inicio INC 2015-023392*/
		//if(totalItems > 19) {
		if(totalItems > 20) {
			mostrarMensaje("El maximo numero de items a ingresar no debe exceder de 20.");
			return;
		}
		/*Fin INC 2015-023392*/

		var varTotalCT = this.getTotalItemsEnGridQueSonCargoTributo();
		if (totalItems == varTotalCT){
			mostrarMensaje("Debe registrar por lo menos un item que no sea cargo o tributo.");
			return;
		}

		var varTotalItemsGravados = this.getTotalItemsEnGridQueSonGravados();
		var varTotalItemsExonerados = this.getTotalItemsEnGridQueSonExonerados();
		var varTotalItemsInafectos = this.getTotalItemsEnGridQueSonInafectos();
		var varTotalItemsConISC = this.getTotalItemsEnGridQueTienenISC();
		var varTotalItemsBienes= this.getTotalItemsEnGridQueSonBienes();

		if (dojo.byId("global.opcionPagoAnticipado").value =="1"){
			if (totalItems == varTotalItemsGravados || totalItems == varTotalItemsExonerados || totalItems == varTotalItemsInafectos){

			}else{
					mostrarMensaje("Todos los items deben tener el mismo tipo de afectaci\u00F3n: Gravados, Exonerados o Inafectos.");
					  return;
			}

			if (totalItems == varTotalItemsConISC || varTotalItemsConISC == 0 ){

			}else{
				mostrarMensaje("Si usa ISC, todos los items deben estar afectos.");
				return;
			}
		  }else{
			  var varTotalAnticipos = this.getTotalItemsEnGridQueSonAnticipos();
			if (totalItems == varTotalAnticipos){
				mostrarMensaje("Debe registrar por lo menos un item que no sea anticipo.");
				return;
			}
		}

		if (dojo.byId("global.opcionPagoDeduccionAnticipado").value =="DE01"){
			var itemsIncorrectosFechaAnticipo = this.getItemsCompararFechaAnticipado();
			if (itemsIncorrectosFechaAnticipo != ""){
				mostrarMensaje("En el item " + itemsIncorrectosFechaAnticipo + ", la fecha de emisi\u00F3n de la factura de Anticipo no puede ser mayor a la fecha de emisi\u00F3n del comprobante.");
				return;
			}
		}

		dojo.byId("global.importeTotal").value = dijit.byId("factura.totalGeneral").getValue();

		// INICIO PAS20211U210700145 - AVN
		/*
		dojo.byId("global.fecVencimiento").value  = "";
		if (!this.validarFechaVencimiento()){
			return;
		}*/
		// FIN PAS20211U210700145 - AVN
		dojo.byId("global.fecEmision").value  = "";
		if (!this.validarFechaEmisionContin(false)){
			return;
		}

		if (dojo.byId("global.opcionDomicilioCliente").value == "1" &&
      		dijit.byId("factura.direccionCliente").value == ""){
			mostrarMensaje("Debe registrar la direcci\u00F3n del cliente.");
			return;
		}

		if (dojo.byId("global.opcionEstablecimientoEmisor").value == "1" &&	dijit.byId("factura.establecimientoEmisor").value == ""){
			mostrarMensaje("Debe registrar la direcci\u00F3n del Emisor.");
			return;
		}

		//Si indico que sustenta traslado de bienes
		if (dojo.byId("global.opcionSustentoTrasladoBienes").value == "1") {
	  		if (varTotalItemsBienes == 0 ){
	  			//if (!confirm("No se ha especificado bienes en la factura para el traslado. Desea continuar con la emisi\u00F3n de la Factura?")){
	  			//	return;
	  			//}
				mostrarMensajeConfirmacion("No se ha especificado bienes en la factura para el traslado. Desea continuar con la emisi\u00F3n de la Factura?", dojo.hitch(this, function() { }) );
	  		}
		}

		//INI PAS20191U210100075
		var array = dijit.byId("factura.ingreso-grid").store._arrayOfTopLevelItems;
		var contImpuestoBolsas = 0;
		for (var i = 0; i < array.length; i++) {
			if (array[i].esImpuestoBolsaPlastico == "IBP00" ) {
				contImpuestoBolsas += 1;
			}
		}

		var parts = dojo.byId("factura.fechaEmision").value.split('/');
		var fechaEmision = new Date(parts[2],parts[1]-1,parts[0]);

		//fecha properties
		var parts2 = dojo.byId("item.FechaProperties").value.split('/');
		var fechaproperties = new Date(parts2[2],parts2[1]-1,parts2[0]);

		console.log("items con icbper :" + contImpuestoBolsas);
		console.log(dojo.byId("factura.fechaEmision").value);
		console.log(dojo.byId("item.FechaProperties").value);

		if((fechaEmision < fechaproperties) && contImpuestoBolsas > 0){
			mostrarMensaje("No puede cambiar la fecha de emisi\u00F3n, existen ítems agregados con ICBPER.");
			return false;
		}
		//FIN PAS20191U210100075

		//Verifica si existe algun item con exonerado o inafecto
		dojo.byId("global.flagExoInafecto").value = this.checkExoneradoInafecto();

	  var accionBtn01Contin  = dojo.hitch(this, function() {
		var nbControl = dijit.byId("factura.botonGrabarDocumento");
		nbControl.setAttribute('disabled', true);
		this.wait("Procesando", "110px", 200);
		var nodeButton = nbControl.focusNode;

		var handler = dojo.io.iframe.send({
			url: this.controller,
			handleAs: "json",
			sync: true,
			timeout: 10000,
			preventCache: true,
			form: "factura.form"
		});

		handler.addCallback(dojo.hitch(this, function(res){
			this.waitMessage.hide();
			if(res.codeError == 0) {
				this.content.onLoad = dojo.hitch(this, function(){
					var moneda = dojo.byId("global.tipoMoneda").value;

				});
				this.content.setHref(this.controller + "?action=showDocRelComprobante&preventCache=" + this.preventCache());
				this.content.onLoad = dojo.hitch(this, function(){
  					dijit.byId("docsrel.observacion").setValue(dojo.byId("global.docsrel.observacion").value);

        		if (dojo.byId("global.opcionFESectorPublico").value == "1") {
        		    this.showHiddenDiv(document.getElementById("docsrel.informacionFESectorPublico.show"),true);
            }else{
                this.showHiddenDiv(document.getElementById("docsrel.informacionFESectorPublico.show"),false);
            }
        		if (dojo.byId("global.opcionSustentoTrasladoBienes").value == "1") {
        		    this.showHiddenDiv(document.getElementById("docsrel.informacionTrasladoBienes.show"),true);
            }else{
                this.showHiddenDiv(document.getElementById("docsrel.informacionTrasladoBienes.show"),false);
            }

        		if (dojo.byId("global.opcionSPOT").value == "1") {
        		    this.showHiddenDiv(document.getElementById("docsrel.informacionRecursosHidrobiologicos.show"),true);
            }else{
                this.showHiddenDiv(document.getElementById("docsrel.informacionRecursosHidrobiologicos.show"),false);
            }

        		if (dojo.byId("global.opcionPlacaVehiculo").value == "1") {
        		    this.showHiddenDiv(document.getElementById("docsrel.informacionPlacaVentaCombustible.show"),true);
        		    dijit.byId("docsrel.placaVentaCombustible").setValue(dojo.byId("global.docsrel.placaVentaCombustible").value);
            }else{
                this.showHiddenDiv(document.getElementById("docsrel.informacionPlacaVentaCombustible.show"),false);
            }
            if (dojo.byId("global.opcionSustentoTrasladoBienes").value == "1") {
        		    //this.iconTooltipMessage("docsrel.botonInformacionTrasladoBienes", "icon-ok-tooltip", "Debe registrar punto de partida y punto de llegada.");
            }

        });

			} else {
				nbControl.setAttribute('disabled', false);
				this.waitMessage.hide();
				mostrarMensaje(res.messageError);
			}
		}));

		handler.addErrback(function(res){
			nbControl.setAttribute('disabled', false);
			this.waitMessage.hide();
			mostrarMensaje("Problemas al conectarse con el servidor");
		});
	  });

		// PAS20191U210100204
		if (this.getExisteDuplicados() > 0){
			////!confirm("Antes de continuar\nExisten ítems con información duplicada  ¿Desea continuar?")){
			////return;
			mostrarMensajeConfirmacion("Antes de continuar\nExisten ítems con información duplicada ¿Desea continuar?", accionBtn01Contin );
		} else {
			accionBtn01Contin();
		}

	}else{
		mostrarMensaje("Ingrese el numero de serie");
		document.getElementById("numero").focus();
	}
	},


	setDefaultMontosDocRel: function() {

	},

	validateAcceptTerminos: function(){
		var acepta = dijit.byId("condicionesSEE.cbTerminos");
		console.log("acepta?" + acepta);
		if (!acepta.getValue()) {
			mostrarMensaje("Debe aceptar las condiciones.");
			//this.messageBoxError("Debe aceptar las condiciones.","icon-alert-warn");
			return;
		}
		//se agrega para contingencia - ALB
		this.store = null;
		this.otherDocStore = null;
		this.licenciaStore = null;
		// INI PAS20201U210100097 APDEX
		this.infAdicionalStore=null;
		// FIN PAS20201U210100097 APDEX
		this.resetValoresGlobales(false);
		// PAS20211U210700069
		this.inicializarFacturaDocRelItem();
		this.inicializarFacturaInformacionRelSP();
		this.inicializarFacturaItem();
		this.inicializarFacturaEstablecimientoEmisor();
		this.inicializarFacturaDireccionCliente();

		//PAS20201U210100230
		if (dojo.byId("global.opcionTipoTransaccion")!=null){
			this.inicializarFacturaFactoringDireccionReceptor();
			this.inicializarFacturaFactoringRetencion();
			this.inicializarFacturaFactoringCreditoItem();
			this.inicializarFacturaFactoringCuota();
		}

		//se agrega para contingencia - ALB
		this.content.setHref(this.controller + "?action=mostrarPrimeraFE");
	},

	checkExoneradoInafecto: function() {
		var flagExoInaf=0;
		var array = dijit.byId("factura.ingreso-grid").store._arrayOfTopLevelItems;
		for(var i = 0; i < array.length; i++){
			if (array[i].tipoBeneficio == "TB01" || array[i].tipoBeneficio == "TB02") {
				flagExoInaf = 1;
			}
		}
		return flagExoInaf;
	},

	previewDocument: function() {
		if(!dijit.byId("docsrel.form").validate()) return;

		dojo.byId("global.docsrel.observacion").value = dijit.byId("docsrel.observacion").getValue();
		dojo.byId("global.docsrel.placaVentaCombustible").value = dijit.byId("docsrel.placaVentaCombustible").getValue();
		// INI PAS20201U210100097 APDEX
		if(this.infAdicionalStore!=null){
			dojo.byId("global.numeroExpediente").value = this.infAdicionalStore.numeroExpediente;
			dojo.byId("global.ordenCompra").value = this.infAdicionalStore.ordenCompra;
			dojo.byId("global.numeroProcesoSeleccion").value = this.infAdicionalStore.numeroProcesoSeleccion;
			dojo.byId("global.codigoUnidadEjecutora").value = this.infAdicionalStore.codigoUnidadEjecutora;
			dojo.byId("global.numeroContrato").value = this.infAdicionalStore.numeroContrato;
		}
		// FIN PAS20201U210100097 APDEX
		if (dojo.byId("global.opcionSustentoTrasladoBienes").value == "1") {
	  		if (dojo.byId("global.opcionPuntoPartidaDireccion").value  =="" || dojo.byId("global.opcionPuntoLlegadaDireccion").value  =="" ){
	  			mostrarMensaje("Debe registrar el punto de partida y punto de llegada");
	  			return;
	  		}
	    }
		//PAS20201U210100230  INI opv
		var nodeButton;
	if(dojo.byId("global.opcionTipoTransaccion")!=null){
		if(dojo.byId("global.opcionTipoTransaccion").value == "2"){
			var td=	dojo.byId("global.tipoDocumento").value;
			if (td == "6"){ // INI - PAS20211U210700145 - AFT
				//VALIDACION DE AL MENOS UNA CUOTA
				if (this.storeInfCreditoGuardado.length==0 ) {
						console.log("global.opcionTipoTransaccion 1111 - LINEA 1473" );
					nodeButton= dijit.byId("docsrel.botonInformacionCredito").focusNode
					this.iconTooltipMessage(nodeButton, "icon-error-tooltip", "Debe registrar al menos 1 cuota");
					this.waitMessage.hide();
					return;
				}
				//VALIDACION DE MONTO NETO.
				var montoTotalFactura= dojo.byId("global.importeTotal").value;
				if(this.storeInfCreditoGuardado.length!=0){
					if (this.montoNetoPendienteGuardado > Number(montoTotalFactura)  && dojo.byId("global.tipoMoneda").value=="PEN" ) {
						nodeButton= dijit.byId("docsrel.botonInformacionCredito").focusNode
						this.iconTooltipMessage(nodeButton, "icon-error-tooltip", "El monto no puede ser mayor al importe total de la factura.");
						this.waitMessage.hide();
						return;
					}
				}

				//VALIDACION DE SUMA DE CUOTAS.
				if(this.storeInfCreditoGuardado.length!=0){
				console.log("montoTotalCuotasGuardado--> " + this.montoTotalCuotasGuardado);
				console.log("montoTotalCuotasGuardado--> " + this.montoTotalCuotasGuardado.toFixed(2));
				console.log("montoTotalFactura--> " + montoTotalFactura);
					if (this.montoTotalCuotasGuardado.toFixed(2)> Number(montoTotalFactura) ) {
						nodeButton= dijit.byId("docsrel.botonInformacionCredito").focusNode
						this.iconTooltipMessage(nodeButton, "icon-error-tooltip", "La suma de las cuotas no pueden ser mayor al importe total de la factura.");
						this.waitMessage.hide();
						return;
					}
				}
				/*
				var var1=this.montoTotalCuotas;
				var var2=montoTotalFactura;
				console.log("var2.montoTotalFactura.toFixed(2)--> " + Number.parseFloat(var2).toFixed(2));
				if (Number.parseFloat(var1).toFixed(2)> Number.parseFloat(var2).toFixed(2) ) {
					nodeButton= dijit.byId("docrelInfCred.botonAceptar").focusNode
					this.iconTooltipMessage(nodeButton, "icon-error-tooltip", "La suma de las cuotas no pueden ser mayor al importe total de la factura.");
					this.waitMessage.hide();
					return;
				}*/
				//Inicio [PAS20211U210700145][anunez][2021.11.05] se agrega la validacion que la suma de cuotas no debe ser diferente al monto neto pendiente de pago
				if(this.storeInfCreditoGuardado.length!=0){
					if (this.montoTotalCuotasGuardado.toFixed(2) != this.montoNetoPendienteGuardado) {
						nodeButton= dijit.byId("docsrel.botonInformacionCredito").focusNode
						this.waitMessage.hide();
						mostrarMensaje("La suma de las cuotas no puede ser diferente del monto neto pendiente de pago.");
						return;
					}
				}
				//Fin [PAS20211U210700145]
			}else{ //FIN - PAS20211U210700145 - AFT
				console.log("Tipo documento diferente de RUC" );
			}
		}
	}

		if(this.montoBaseRetencion!=null){
			if (this.montoBaseRetencion > Number(montoTotalFactura) ) {
				nodeButton= dijit.byId("docsrel.botonInformacionRetencion").focusNode
				this.iconTooltipMessage(nodeButton, "icon-error-tooltip", "El monto no puede ser mayor al importe total de la factura.");
				this.waitMessage.hide();
				return;
			}
		}
		//PAS20201U210100230  FIN opv
		/*if ( dojo.byId("global.opcionEstablecimientoEmisorIdentifica").value == 2 && this.indRegitroGR == 0){
	      	mostrarMensaje("Debe tener ingresada al menos una Gu\u00EDa de Remisi\u00F3n Remitente");
	      	return;
    	}
		 */

		if ( dojo.byId("global.opcionVentaItinerante").value == "1" && this.indRegitroGR == 0){
			mostrarMensaje("Debe tener ingresada al menos una Gu\u00EDa de Remisi\u00F3n Remitente");
			return;
		}

		if (dojo.byId("global.opcionPlacaVehiculo").value == "1" && dijit.byId("docsrel.placaVentaCombustible").getValue()=="" ) {
			mostrarMensaje("Debe registrar la placa del vehiculo.");
			return;
		}

		var nbControl = dijit.byId("docsrel.botonGrabarDocumento");
		nbControl.setAttribute('disabled', true);
		this.wait("Procesando", "110px", 200);

		var handler = dojo.io.iframe.send({
			url: this.controller,
			handleAs: "json",
			sync: true,
			timeout: 10000,
			preventCache: true,
			form: "docsrel.form"
		});

		handler.addCallback(dojo.hitch(this, function(res){
			this.waitMessage.hide();
			if (res.codeError == 0) {
				this.content.onLoad = dojo.hitch(this, function(){
					var grid = dijit.byId("factura.preview-grid");
					var datos = eval("(" + res.data + ")");
					var newStore  = new dojo.data.ItemFileWriteStore({data: {identifier: 'identificador', items: datos,preventCache: true}});
					grid.setStore(newStore);
					grid.startup();
					grid.update();
				});
				this.content.setHref(this.controller + "?action=previewComprobante&preventCache=" + this.preventCache());
			} else {
				nbControl.setAttribute('disabled', false);
				mostrarMensaje(res.messageError);
			}
		}));

		handler.addErrback(function(res){
			nbControl.setAttribute('disabled', false);
			this.waitMessage.hide();
			mostrarMensaje("Problemas al conectarse con el servidor");
		});
	},

	saveDocument: function() {
		if(!dijit.byId("factura-preliminar.form").validate()) return;

		var accionBtnAceptarQ2 = dojo.hitch(this, function () {
			var nbBack = dijit.byId("factura-preliminar.botonBackDocumento");
			var nbSave = dijit.byId("factura-preliminar.botonGrabarDocumento");
			var nbClose = dijit.byId("factura-preliminar.botonCloseDocumento");

			nbBack.setAttribute('disabled', true);
			nbSave.setAttribute('disabled', true);
			nbClose.setAttribute('disabled', true);

			this.wait("Grabando", "95px", 800);

			  var handler = dojo.xhrGet({
				  url: this.controller + "?action=grabarComprobante",
				  handleAs: "json",
				  preventCache: true,
				  sync: true,
				  timeout: 30000//whr validacion_duplicado
			  });

			  handler.addCallback(dojo.hitch(this, function(res){
				  this.waitMessage.hide();
				  if (res.codeError == 0) {
					this.content.onLoad = dojo.hitch(this, function(){
						this.iconTooltipMessage("numeroComprobante", "icon-ok-tooltip", "La factura se emitio correctamente <br>Ha generado este n&uacute;mero.");
						var grid = dijit.byId("factura.generada-grid");
						var datos = eval("(" + res.data + ")");
						var newStore  = new dojo.data.ItemFileWriteStore({data: {identifier: 'identificador', items: datos,preventCache: true}});
						grid.setStore(newStore);
						grid.startup();
						grid.update();
					});
					this.content.setHref(this.controller + "?action=mostrarComprobante&preventCache=" + this.preventCache());
				  } else {
					nbBack.setAttribute('disabled', false);
					nbSave.setAttribute('disabled', false);
					nbClose.setAttribute('disabled', false);

					  alert(res.messageError);
				  }
			  }));

			  handler.addErrback(dojo.hitch(this, function(res){
				nbBack.setAttribute('disabled', false);
				nbSave.setAttribute('disabled', false);
				nbClose.setAttribute('disabled', false);

				// PAS20201U210100046
				  this.waitMessage.hide();
				  alert("Se produjo un error al intentar emitir el comprobante. Por favor volver a intentar.");
				console.log("error saveDocument " + res.message);
				console.log("error saveDocument " + res.messageError);
			  }));
		});

		var accionBtnAceptarQ1 = function () {
			console.log("Aceptar1_Click()");
			mostrarMensajeConfirmacion("¿Está Ud. seguro de emitir una Factura Electrónica?", accionBtnAceptarQ2 );
		};

		// PAS20191U210100204
		if (this.getExisteDuplicados() > 0 ){
			console.log("FlujoDuplicados()");
			mostrarMensajeConfirmacion("Antes de continuar\nExisten ítems con información duplicada ¿Desea continuar?", accionBtnAceptarQ1 );
		} else {
			console.log("Alternativo()");
			mostrarMensajeConfirmacion("¿Está Ud. seguro de emitir una Factura Electrónica?", accionBtnAceptarQ2 );
		}
	},

	//Antonio
	saveDocumentContin: function() {
		if(!dijit.byId("factura-preliminar.form").validate()) return;

		var accionBtnAceptarQ2Cont = dojo.hitch(this, function () {
				var nbBack = dijit.byId("factura-preliminar.botonBackDocumento");
				var nbSave = dijit.byId("factura-preliminar.botonGrabarDocumento");
				var nbClose = dijit.byId("factura-preliminar.botonCloseDocumento");

				nbBack.setAttribute('disabled', true);
				nbSave.setAttribute('disabled', true);
				nbClose.setAttribute('disabled', true);
				this.wait("Grabando", "95px", 800);
				var handler = dojo.xhrGet({
					url: this.controller + "?action=grabarComprobanteContin",
					handleAs: "json",
					preventCache: true,
					sync: true,
					timeout: 30000//whr validacion_duplicado
				});
				handler.addCallback(dojo.hitch(this, function(res){
					this.waitMessage.hide();
					if (res.codeError == 0) {
						this.content.onLoad = dojo.hitch(this, function(){
							this.iconTooltipMessage("numeroComprobante", "icon-ok-tooltip", "El registro de la presente informacion constituye una declaracion jurada, acorde con la RS 113-2018/SUNAT. <br>Ha generado este n&uacute;mero.");
							var grid = dijit.byId("factura.generada-grid");
							var datos = eval("(" + res.data + ")");
							var newStore  = new dojo.data.ItemFileWriteStore({data: {identifier: 'identificador', items: datos,preventCache: true}});
							grid.setStore(newStore);
							grid.startup();
							grid.update();
						});
						this.content.setHref(this.controller + "?action=mostrarComprobante&preventCache=" + this.preventCache());
					} else {
						nbBack.setAttribute('disabled', false);
						nbSave.setAttribute('disabled', false);
						nbClose.setAttribute('disabled', false);

						mostrarMensaje(res.messageError);
					}
				}));
				handler.addErrback(dojo.hitch(this, function(res){
					nbBack.setAttribute('disabled', false);
					nbSave.setAttribute('disabled', false);
					nbClose.setAttribute('disabled', false);

					this.waitMessage.hide();
					mostrarMensaje("Problemas al emitir la Factura Electronica.");
				}));
		});

		var accionBtnAceptarQ1Cont = function () {
			mostrarMensajeConfirmacion("¿Está Ud. seguro de emitir una Factura Electrónica?", accionBtnAceptarQ2Cont );
		};

		// PAS20191U210100204
		if (this.getExisteDuplicados() > 0 ){
			console.log("Validacion1_1");
			mostrarMensajeConfirmacion("Antes de continuar\nExisten ítems con información duplicada ¿Desea continuar?", accionBtnAceptarQ1Cont );
		} else {
			console.log("Alternativo_Validacion1_1");
			mostrarMensajeConfirmacion("¿Esta Ud. seguro de emitir una Factura Electrónica?", accionBtnAceptarQ2Cont );
		}

	},

	closeDocument: function() {
			this.store = null;
			this.otherDocStore = null;
			this.licenciaStore = null;
			// INI PAS20201U210100097 APDEX
			this.infAdicionalStore=null;
			// FIN PAS20201U210100097 APDEX
			this.resetValoresGlobales(true);
			//this.inicializarFacturaItem();
			this.content.onLoad = dojo.hitch(this, function(){
				this.initContent();
			});
			this.content.setHref(this.controller + "?action=mostrarInicial&mode=hidden");
	},

	closeDocumentGenerado: function() {
    	if (dojo.byId("global.opcionSustentoTrasladoBienes").value == "1") {
    	   mostrarMensaje("Este documento sustenta traslado de bienes. Debe asegurarse de imprimirlo.")
    	}
  		//if (confirm("¿Desea emitir otra factura?")) {
		mostrarMensajeConfirmacion("¿Desea emitir otra factura?", dojo.hitch(this, function() {
  			this.closeDocument();
		}));
  		//}
	},

	closeDocumentInicial: function() {
		mostrarMensajeConfirmacion("¿Desea salir del aplicativo?", dojo.hitch(this, function(){
			this.closeDocument();
		}));
	},

	closeDocumentInicio: function() {
		mostrarMensajeConfirmacion("¿Desea cancelar la emisión de la Factura Electrónica?", dojo.hitch(this, function(){
			this.closeDocument();
		}));
	},

	closeDocumentDocRel: function() {
		this.closeDocumentInicio();
	},

	closeDocumentIngreso: function() {
		this.closeDocumentInicio();
	},

	newDocument: function() {
		this.store = null;
		this.otherDocStore = null;
		this.licenciaStore = null;
		this.content.onLoad = dojo.hitch(this, function(){
			this.initContent();
		});
		this.content.setHref(this.controller + "?action=showIngresoFactura&mode=hidden");
	},

	showDialogItem: function(mode) {
		/* Inicio PAS20201U210100285 - Pago Anticipado */
		if (dojo.byId("global.opcionPagoDeduccionAnticipado").value == "DE01") {
			require(["dijit/registry"], function(registry){
				var formItems = registry.byId("item.form");
				formItems.reset();
			});
		}
		/* Fin PAS20201U210100285 - Pago Anticipado */
		if(mode == 1) {
			dojo.byId("global.origenInvocacionItem").value = "01";
			dijit.byId("item.botonAceptar").setAttribute('disabled', false);
			this.nuevoItem();
		} else if (mode == 2) {
			dojo.byId("global.origenInvocacionItem").value = "01";
			this.editItem();
		}
	},

	closeDialogItem: function() {
		//if (confirm("¿Desea cancelar la captura del item?")) {
		mostrarMensajeConfirmacion("¿Desea cancelar la captura del ítem?", dojo.hitch(this, function() {
			 this.dialogItem.hide();
		//}
		}));
	},

	acceptDialogItem: function() {
	    if(!dijit.byId("item.cantidad").validate())
	    {
	        return;
	    }

	    if(!dijit.byId("item.codigoItem").validate())
	    {
	        return;
	    }

	    if(!dijit.byId("item.precioUnitario").validate())
	    {
	       return;
	    }
	    if(!dijit.byId("item.precioDescuento").validate())
	    {
	        return;
	    }
	    if(!dijit.byId("item.sistemaIsc").validate())
	    {
	        return;
	    }
	    if(!dijit.byId("item.iscPorcentaje").validate())
	    {
	       return;
	    }

	    if(!dijit.byId("item.iscMonto").validate())
	    {
	        return;
	    }
	    if(!dijit.byId("item.precioConIGV").validate())
	    {
	        return;
	    }
	    if(!dijit.byId("item.importeVenta").validate())
	    {
	        return;
	    }
	    if(!dijit.byId("item.tasaBolsa").validate())
	    {
	        return;
	    }
		//INI PAS20191U210100075	01.08
	    if(!dijit.byId("item.unidadMedida").validate())
	    {
	        return;
	    }
		//FIN PAS20191U210100075	01.08

		//INI PAS20191U210100075
		monedades = dojo.byId("global.tipoMonedaDesc").value;
		var valOpcionImpuestoBolsaPlastica = this.getValorOpcionImpuestoBolsaPlastica();
		console.log(dijit.byId("item.impuestoICBPER").getValue());
		if(monedades != "SOLES"){
			if((dijit.byId("item.impuestoICBPER").getValue() <= 0 || isNaN(dijit.byId("item.impuestoICBPER").getValue()) ||dijit.byId("item.impuestoICBPER").getValue() == "") &&  valOpcionImpuestoBolsaPlastica == "IBP00")
			{
					mostrarMensaje("Impuesto ICBPER Invalido.")
						return;
			}
		}

		if(monedades == "SOLES"){
			var valOpcionImpuestoBolsaPlastica = this.getValorOpcionImpuestoBolsaPlastica();

			if (valOpcionImpuestoBolsaPlastica == "IBP00"){

				//var anio = new Date().getFullYear();
				var parts = dojo.byId("factura.fechaEmision").value.split('/');

				var fechaEmision = new Date(parts[2],parts[1]-1,parts[0]);


				var anio2 = dijit.byId("item.periodoBolsa").get('displayedValue');

				if(anio2 <  fechaEmision.getFullYear().toString()){


					var r = confirm("“La tasa del ICBPER corresponde a un periodo anterior” Esta seguro de marcar Si o No.");
					if (r == true) {

					} else {
					  return;
					}
				}
			}
		}

		//FIN PAS20191U210100075

		//if(!dijit.byId("item.form").validate()) return;
		var mode = dojo.byId("item.action").value;
		//PAS20175E210300024
		var anticipo = this.getValorOpcionAnticipo();
		if (anticipo =="1"){
			if (this.obtenerFacturaAnticipo(false) == false){
				return;
			}
		}

		if ((dojo.byId("item.valOpcTipoCTItem").value!="1" && dojo.byId("item.valOpcTipoCTItem").value!="2") && dojo.byId("item.valOpcTipoBS").value==""){
			mostrarMensaje( "Debe seleccionar si el Item es Cargo/Tributo o Bien/Servicio.");
			return;
		}

		var moneda = dojo.byId("global.tipoMoneda").value;
		var anticipo= this.getValorOpcionAnticipo();
		var tipoItem = this.getValorOpcionTipoItem();
		if (tipoItem == "TI01" || tipoItem == "TI02"){
			if (anticipo !="1"){
    			if (!dijit.byId("item.cantidad").getValue()) {
    				this.warnTooltipMessage("item.cantidad", "Por favor ingrese una cantidad.");
    				return;
    			}
			}else{
				if(mode == "adicionarItem") {
      		       var serie = dijit.byId("item.facturaAnticipoSerie").getValue();
      		       var numero = dijit.byId("item.facturaAnticipoNumero").getValue();
      		       if (this.verSiFacturasDeAnticipoExisteEnGrid(serie, numero)=="1"){
      		          this.warnTooltipMessage("item.facturaAnticipoNumero", "Este pago anticipado ya fue utilizado en esta factura.");
      		          return;
      		       }
				}

				if (dojo.byId("item.facturaAnticipoMonto").value ==""){
					this.warnTooltipMessage("item.facturaAnticipoMonto", "Debe registrar el monto total de la factura de anticipo.");
					return;
				}

				if (dojo.byId("item.facturaAnticipoFechaEmision").value ==""){
					this.warnTooltipMessage("item.facturaAnticipoFechaEmision", "Debe registrar la fecha de emisi\u00F3n de la factura de anticipo.");
					return;
				}

				var fechaHoy = new Date();
				var fechaEmisionAnticipo = new Date(dojo.byId("item.facturaAnticipoFechaEmision").value.substring(3,6) +  dojo.byId("item.facturaAnticipoFechaEmision").value.substring(0,3)  +dojo.byId("item.facturaAnticipoFechaEmision").value.substring(6,10));

				if (fechaEmisionAnticipo > fechaHoy){
					this.iconTooltipMessage("item.facturaAnticipoFechaEmision", "icon-ok-tooltip", "La fecha de emisi\u00F3n de la factura de anticipo no puede ser mayor a la fecha actual.");
					return;
				}

				//PAS20175E210300029
				var fechaEmisionComprobante = new Date();
				if (dojo.byId("global.fecEmision").value != ""){
					fechaEmisionComprobante = new Date(dojo.byId("global.fecEmision").value);
				}

				if (fechaEmisionAnticipo > fechaEmisionComprobante){
					this.iconTooltipMessage("item.facturaAnticipoFechaEmision", "icon-ok-tooltip", "La fecha de emisi\u00F3n de la factura de Anticipo no puede ser mayor a la fecha de emisi\u00F3n del comprobante.");
					return;
				}
			}
		}

		var descripcion = dojo.trim(dijit.byId("item.descripcion").getValue());
		if(descripcion.length < 1) {
			this.warnTooltipMessage("item.descripcion", "Por favor ingrese una descripci&oacute;n");
			return;
		}

		//PAS20181U210300144
		if(/\"/.test(descripcion)){//Verifica que la descripción no tenga "
			this.warnTooltipMessage("item.descripcion", 'Car&aacute;cter no permitido (")');
			return;
		}
		//PAS20211U210600248 -Ini - LAQ
		this.isQuitarCharacterSpecial();
		//PAS20211U210600248 -Fin - LAQ
		var precioUnitario = dijit.byId("item.precioUnitario").getValue();
		// PAS20191U210000003
		//if (precioUnitario > 99999999.99 ) {
		if (precioUnitario > 99999999999.99 ) {
			mostrarMensaje("Precio unitario sobrepasa el limite permitido.")
			return;
		}
		//if (dojo.byId("global.situacionEspecial").value != "SE01" ){    //MPCR 20110913   PAS201120500000026 - Para que se exija precio unitario aun en la FE de Venta gratuita
			//if (this.getValorOpcionTipoBonif() == ""){
		var precioUnitario = dijit.byId("item.precioUnitario").getValue();
		if(precioUnitario <= 0) {
			this.warnTooltipMessage("item.precioUnitario", "El valor unitario debe ser mayor a cero.");
			return;
		}

		if (dojo.byId("global.opcionNodomic").value == "1") {
			if(precioUnitario < 42) {
				this.warnTooltipMessage("item.precioUnitario", "Precio de venta del bien es menor a lo establecido en el Art\u00EDculo 11-G del DS 161-2012-EF");
				return;
			}
		}

		var descuento = dijit.byId("item.precioDescuento").getValue();
		if(descuento < 0) {
			this.warnTooltipMessage("item.precioDescuento", "El descuento no debe ser negativo.");
			return;
		}

			//}
		//}

		var tipoItem = this.getValorOpcionTipoItem();
		if (tipoItem == "TI01"){
			var unidadMedida = dijit.byId("item.unidadMedida").getValue();
			if (anticipo !="1"){
	  			if (dojo.trim(unidadMedida) == "000") {
	  				this.warnTooltipMessage("item.unidadMedida", "Por favor ingrese una unidad de medida.");
	  				return;
	  			}
			}
		}

		if (!dijit.byId("item.cantidad").getValue()) {
			dijit.byId("item.cantidad").setValue(1);
		}

		var cantidadXPrecioUnitario = dijit.byId("item.cantidad").getValue() * dijit.byId("item.precioUnitario").getValue();
		// PAS20191U210000003
		//if ((dijit.byId("item.cantidad").getValue() * dijit.byId("item.precioUnitario").getValue()) > 99999999.99 ) {
		if ((dijit.byId("item.cantidad").getValue() * dijit.byId("item.precioUnitario").getValue()) > 99999999999.99 ) {
			mostrarMensaje("Valores numericos calculados sobrepasan el limite permitido.")
			return;
		}

		var descuento = dijit.byId("item.precioDescuento").getValue();
		if ( descuento >= cantidadXPrecioUnitario) {
			var node = dijit.byId("item.precioDescuento");
			this.warnTooltipMessage(node.focusNode, "Descuento debe ser menor que Cantidad * Valor Unitario.");

			node.constraints = {currency:moneda, places:2};
			node.setValue(0, false);
			return;
		}

		// PAS20191U210000003
		//if (dojo.byId("item.importeVenta").value > 99999999.99 ) {
		if (dojo.byId("item.importeVenta").value > 99999999999.99 ) {
			mostrarMensaje("Valores numericos calculados sobrepasan el limite permitido.")
			return;
		}

		if (dojo.byId("global.opcionISC").value == "IM01") {
			if (dijit.byId("item.sistemaIsc").getValue() > 0 ) {
				if (dijit.byId("item.iscPorcentaje").getValue() <= 0 ) {
					var node = dijit.byId("item.iscPorcentaje");
					this.warnTooltipMessage(node.focusNode, "Debe ingresar un valor mayor a cero.");
					node.setValue(0, false);
					return;
				}
				if (dijit.byId("item.iscMonto").getValue() <= 0 ) {
					var node = dijit.byId("item.iscMonto");
					this.warnTooltipMessage(node.focusNode, "Debe ingresar un monto mayor a cero.");

					node.constraints = {currency:moneda, places:2};
					node.setValue(0, false);
					return;
				}
			}

			if (dijit.byId("item.iscPorcentaje").getValue() < 0 ) {
				var node = dijit.byId("item.iscPorcentaje");
				this.warnTooltipMessage(node.focusNode, "Debe ingresar un valor mayor a cero.");
				node.setValue(0, false);
				return;
			} else {
				if (dijit.byId("item.iscPorcentaje").getValue() > 0 ){
					if (dijit.byId("item.sistemaIsc").getValue() <= 0 ) {
						var node = dijit.byId("item.sistemaIsc");
						this.warnTooltipMessage(node.focusNode, "Debe ingresar un tipo de ISC.");
						node.setValue(0, false);
						return;
					}
					if (dijit.byId("item.iscMonto").getValue() <= 0 ) {
						var node = dijit.byId("item.iscMonto");
						this.warnTooltipMessage(node.focusNode, "Debe ingresar un monto mayor a cero.");

						node.constraints = {currency:moneda, places:2};
						node.setValue(0, false);
						return;
					}
				}
			}

			if (dijit.byId("item.iscMonto").getValue() < 0 ) {
				var node = dijit.byId("item.iscMonto");
				this.warnTooltipMessage(node.focusNode, "Debe ingresar un monto mayor a cero.");

				node.constraints = {currency:moneda, places:2};
				node.setValue(0, false);
				return;
			} else {
				if (dijit.byId("item.iscMonto").getValue() > 0) {
					if (dijit.byId("item.sistemaIsc").getValue() <= 0 ) {
						var node = dijit.byId("item.sistemaIsc");
						this.warnTooltipMessage(node.focusNode, "Debe ingresar un tipo de ISC.");
						node.setValue(0, false);
						return;
					}
					if (dijit.byId("item.iscPorcentaje").getValue() <= 0 ) {
						var node = dijit.byId("item.iscPorcentaje");
						this.warnTooltipMessage(node.focusNode, "Debe ingresar un valor mayor a cero.");
						node.setValue(0, false);
						return;
					}
				}
			}

    		var cantidadXPrecioUnitario = dijit.byId("item.cantidad").getValue() * dijit.byId("item.precioUnitario").getValue();
			cantidadXPrecioUnitario.toFixed();
    		var descuento = dijit.byId("item.precioDescuento").getValue();

    		//if ( dijit.byId("item.iscMonto").getValue() > (this.roundNumber(cantidadXPrecioUnitario - descuento,2))) {//PAS20211U210100007
			if ( dijit.byId("item.iscMonto").getValue() > (cantidadXPrecioUnitario - descuento)) {//PAS20211U210100007
    			var node = dijit.byId("item.iscMonto");
    			this.warnTooltipMessage(node.focusNode, "Monto de ISC no debe ser mayor que (Cantidad * Valor Unitario) - Descuento.");

    			node.constraints = {currency:moneda, places:2};
    			node.setValue(0, false);
    			return;
    		}
		}

		var valTipoBonif = this.getValorOpcionTipoBonif();

		if (valTipoBonif == "BO01") {
		    if (dojo.style(dojo.byId("item.divOperacionGratuitaCombo1.show"), "display") == "block"){   //none
		    	if (dijit.byId("item.operacionGratuita1").getValue() == "00" ) {
		    		var node = dijit.byId("item.operacionGratuita1");
		    		this.warnTooltipMessage(node.focusNode, "Debe seleccionar el tipo de Operaci\u00F3n Gratuita.");
		    		node.setValue(0, false);
		    		return;
		    	}
		    }
		    if (dojo.style(dojo.byId("item.divOperacionGratuitaCombo2.show"), "display") == "block"){
		    }
		}

		dojo.byId("item.valOpcTipoBS").value = this.getValorOpcionTipoItem();
		dojo.byId("item.valOpcTipoBenef").value = this.getValorOpcionTipoBenef();
		dojo.byId("item.valOpcTipoBonif").value = this.getValorOpcionTipoBonif();
		dojo.byId("item.valOpcExportacion").value = dojo.byId("global.opcionExportacion").value;
		dojo.byId("item.valOpcNodomic").value = dojo.byId("global.opcionNodomic").value;
		dojo.byId("item.valOpcPagoAnticipado").value = this.getValorOpcionAnticipo();

		dojo.byId("item.facturaAnticipoFechaEmisionAux").value = dojo.byId("item.facturaAnticipoFechaEmision").value ;
		var nbControl = dijit.byId("item.botonAceptar");
		nbControl.setAttribute('disabled', true);

		//var mode = dojo.byId("item.action").value;
		if(mode == "adicionarItem") {
	        this.wait("Adicionando", "110px", 100);
		} else {
	        this.wait("Editando", "95px", 200);
		}

		//INI PAS20191U210100075
		dijit.byId("item.impuestoICBPER").attr('disabled',false);

		/*if (dojo.byId("global.opcionPagoAnticipado").value == "1") {

			dijit.byId("check.impuestoBolsasPlastica00").attr('disabled',false);
			dijit.byId("check.impuestoBolsasPlastica01").attr('disabled',false);
			dijit.byId("item.periodoBolsa").attr('disabled',false);
			dijit.byId("item.impuestoICBPER").constraints = {currency:moneda, places:2};
			dijit.byId("item.impuestoICBPER").attr('value',0);

		}*/

		if (dojo.byId("global.opcionOtrosCargosTributos").value == "1") {
			dijit.byId("check.impuestoBolsasPlastica00").setAttribute('disabled', false);
			dijit.byId("check.impuestoBolsasPlastica01").setAttribute('disabled', false);
			dijit.byId("item.periodoBolsa").setAttribute('disabled', false);
		}

        if (dojo.byId("global.opcionPagoDeduccionAnticipado").value =="DE01"){
    			dijit.byId("check.impuestoBolsasPlastica00").setAttribute('disabled', false);
    			dijit.byId("check.impuestoBolsasPlastica01").setAttribute('disabled', false);
    			dijit.byId("item.periodoBolsa").setAttribute('disabled', false);
		}

		var handlerItem = dojo.io.iframe.send({
			url: this.controller,
			handleAs: "json",
			sync: true,
			timeout: 10000,
			preventCache: true,
			form: "item.form"
		});

		handlerItem.addCallback(dojo.hitch(this, function(res){
			this.waitMessage.hide();
			if(res.codeError == 0) {
				var row = eval("(" + res.data + ")");
				console.log(row);
				if(mode == "adicionarItem") {
					this.addItemAction(row);
				} else {
					this.editItemAction(row);
				}
				this.dialogItem.hide();

				var grid = dijit.byId("factura.ingreso-grid");
				grid.setStore(this.store);

				grid.update();

				this.updateTotalAmount();
			} else {
				nbControl.setAttribute('disabled', false);
				this.iconTooltipMessage(nodeButton, "icon-error-tooltip", res.messageError);
			}
		}));

		handlerItem.addErrback(dojo.hitch(this, function(res) {
			nbControl.setAttribute('disabled', false);
			this.waitMessage.hide();

			// PAS20201U210100046
            mostrarMensaje("Se produjo un error al intentar agregar / editar el comprobante. Por favor volver a intentar.");
			console.log("error acceptDialogItem " + res.message);
			console.log("error acceptDialogItem " + res.messageError);

		}));

		nbControl.setAttribute('disabled', false);
		//PAS20191U210100075
		dijit.byId("item.impuestoICBPER").attr('disabled',true);
		/*if (dojo.byId("global.opcionPagoAnticipado").value == "1") {

			dijit.byId("check.impuestoBolsasPlastica00").attr('disabled',true);
			dijit.byId("check.impuestoBolsasPlastica01").attr('disabled',true);
			dijit.byId("item.periodoBolsa").attr('disabled',true);
		}*/
		if (dojo.byId("global.opcionOtrosCargosTributos").value == "1") {
			dijit.byId("check.impuestoBolsasPlastica00").setAttribute('disabled', true);
			dijit.byId("check.impuestoBolsasPlastica01").setAttribute('disabled', true);
			dijit.byId("item.periodoBolsa").setAttribute('disabled', true);
		}

        if (dojo.byId("global.opcionPagoDeduccionAnticipado").value =="DE01"){
    			dijit.byId("check.impuestoBolsasPlastica00").setAttribute('disabled', true);
    			dijit.byId("check.impuestoBolsasPlastica01").setAttribute('disabled', true);
    			dijit.byId("item.periodoBolsa").setAttribute('disabled', true);

		}

		//PAS20191U210100075
		this.updateTotalAmount();
	},

	addItemAction: function(row) {
		row.elimina = row.identificador;
		row.editar = row.identificador;

		if(this.store == null) this.store = new dojo.data.ItemFileWriteStore({data: {identifier: 'identificador', items: [row],preventCache: true}});
		else this.store.newItem(row);
	},

	editItemAction: function(row) {
		console.log(row);
		this.store.fetchItemByIdentity({
			identity: row.identificador,
			onItem: dojo.hitch(this, function(item){
			this.store.setValue(item, "tipoItem", row.tipoItem);

			this.store.setValue(item, "tipoItemDesc", row.tipoItemDesc);
			this.store.setValue(item, "tipoBeneficio", row.tipoBeneficio);
			this.store.setValue(item, "tipoBeneficioDesc", row.tipoBeneficioDesc);

			this.store.setValue(item, "unidadMedida", row.unidadMedida);
			this.store.setValue(item, "unidadMedidaDesc", row.unidadMedidaDesc);
			//       mostrarMensaje(-2);
			//this.store.setValue(item, "cantidad", dojo.number._formatAbsolute(row.cantidad,"########.##########"));
			this.store.setValue(item, "cantidad", row.cantidad);//PAS20211U210100007
			//this.store.setValue(item, "cantidad", row.cantidad);
			this.store.setValue(item, "codigoItem", row.codigoItem);
			this.store.setValue(item, "descripcion", row.descripcion);
			this.store.setValue(item, "descripcionHidden", row.descripcionHidden);
			//mostrarMensaje(-1);
			this.store.setValue(item, "descripcionFinal", row.descripcionFinal);
			this.store.setValue(item, "codigoBonificacion", row.codigoBonificacion);
			this.store.setValue(item, "codigoBonificacionDesc", row.codigoBonificacionDesc);
			//mostrarMensaje(0);
			this.store.setValue(item, "tipoOtrosCargosTributos",row.tipoOtrosCargosTributos);
			this.store.setValue(item, "tipoBonificacion",row.tipoBonificacion);
			this.store.setValue(item, "otrosCargosTributos",row.otrosCargosTributos);
			//mostrarMensaje(1);
			this.store.setValue(item, "precioUnitario", dojo.number._formatAbsolute(row.precioUnitario,"########.##########"));
			this.store.setValue(item, "precioUnitarioAux", row.precioUnitarioAux);
			this.store.setValue(item, "descuentoMonto", row.descuentoMonto);
			this.store.setValue(item, "igvMonto", row.igvMonto);
			this.store.setValue(item, "igvPorcentaje", row.igvPorcentaje);
			this.store.setValue(item, "iscSistema", row.iscSistema);
			this.store.setValue(item, "iscPorcentaje", row.iscPorcentaje);
			//mostrarMensaje(2);
			this.store.setValue(item, "iscMonto", row.iscMonto);
			this.store.setValue(item, "otrosCargos", row.otrosCargos);
			this.store.setValue(item, "otrosTributos", row.otrosTributos);
			this.store.setValue(item, "importeVenta", row.importeVenta);
			this.store.setValue(item, "valorVenta", row.valorVenta);
			this.store.setValue(item, "precioUnitario", row.precioUnitario);

			this.store.setValue(item, "icbPerPorcentaje", row.icbPerPorcentaje); //PAS20191U210100075
			this.store.setValue(item, "icbperMonto", row.icbperMonto); //PAS20191U210100075
			this.store.setValue(item, "esImpuestoBolsaPlastico", row.esImpuestoBolsaPlastico); //PAS20191U210100075

			if (row.serieFacturaAnticipo !=null){
  				this.store.setValue(item, "facturaAnticipoSerie", row.serieFacturaAnticipo);
  				this.store.setValue(item, "facturaAnticipoNumero", row.numeroFacturaAnticipo);
  				this.store.setValue(item, "facturaAnticipoFechaEmision", row.fechaEmisionFacturaAnticipo);
  				this.store.setValue(item, "facturaAnticipoMonto", row.importeTotalFacturaAnticipo);
			}
				//mostrarMensaje(3);
		}),

		onError: function(){}
		});
	},

	//PAS20175E210300029
	eliminarItemsAll: function(){
		var grilla = dijit.byId("factura.ingreso-grid");
		var filas = grilla.rowCount;
		for (i=0; i< filas;i++){
			var fila = grilla.getItem(0);
			var identificador = grilla.store.getValue(fila, "identificador");
			this.deleteItemDirecto(identificador);
		}
	},

	//PAS20175E210300029
	deleteItemDirecto: function(identificador) {
		if(identificador) {
			//Ubicamos el item
			var row;
			this.store.fetchItemByIdentity({
			    identity: identificador,
			    onItem : function(item, request) {
			    	row = item;
			    },
			    onError : function(item, request) {
					mostrarMensaje("Ocurrio un error al ubicar el item.");
					return;
			    }
			});

			//if (!confirm("Desea eliminar el item " + row.descripcion + "?.")) {
			//	return;
			//}
		}

		this.store.fetchItemByIdentity({
			identity: identificador,
			onItem: dojo.hitch(this, function(item){
				this.wait("Eliminando", "102px", 100);
				var handler = dojo.xhrGet({
					url: this.controller + "?action=eliminarItem&idItem=" + identificador,
					handleAs: "json",
					sync: true,
					preventCache: true,
					timeout: 10000
				});
				handler.addCallback(dojo.hitch(this, function(res){
					this.waitMessage.hide();
					if (res.codeError == 0) {
						this.store.deleteItem(item);
						var grid = dijit.byId("factura.ingreso-grid");
						grid.setStore(this.store);
						grid.update();

						this.updateTotalAmount();
					} else {
						mostrarMensaje(res.messageError);
					}
				}));
				handler.addErrback(dojo.hitch(this, function(res){
					this.waitMessage.hide();

					// PAS20201U210100046
					mostrarMensaje("Se produjo un error al intentar eliminar el comprobante. Por favor volver a intentar.");
					console.log("error deleteItemDirecto " + res.message);
					console.log("error deleteItemDirecto " + res.messageError);
				}));

			}),
			onError: function(){
				mostrarMensaje("Se produjo un error al intentar eliminar el comprobante.");
			}
		});
	},

	deleteItem: function(identificador) {
		if(identificador) {
			//Ubicamos el item
			var row;
			this.store.fetchItemByIdentity({
			    identity: identificador,
			    onItem : function(item, request) {
			    	row = item;
			    },
			    onError : function(item, request) {
					// debugger
					mostrarMensaje("Ocurrio un error al ubicar el item.");
					return;
			    }
			});

			//if (!confirm("Desea eliminar el item " + row.descripcion + "?.")) {
			//	return;
			//}
			mostrarMensajeConfirmacion("¿Desea eliminar el ítem " + row.descripcion + "?.", dojo.hitch(this, function(){
				this.store.fetchItemByIdentity({
					identity: identificador,
					onItem: dojo.hitch(this, function(item){
						this.wait("Eliminando", "102px", 100);
						var handler = dojo.xhrGet({
							url: this.controller + "?action=eliminarItem&idItem=" + identificador,
							handleAs: "json",
							sync: true,
							preventCache: true,
							timeout: 10000
						});
						handler.addCallback(dojo.hitch(this, function(res){
							this.waitMessage.hide();
							if (res.codeError == 0) {
								this.store.deleteItem(item);
								var grid = dijit.byId("factura.ingreso-grid");
								grid.setStore(this.store);
								grid.update();

								this.updateTotalAmount();
							} else {
								mostrarMensaje(res.messageError);
							}
						}));
						handler.addErrback(dojo.hitch(this, function(res){
							this.waitMessage.hide();
							mostrarMensaje("Problemas al conectarse al servidor.");
						}));

					}),
					onError: function(){
						mostrarMensaje("Ocurrio un error al ubicar el documento.");
					}
				});

			}));
		}
	},

	availableIsc: function() {
		var sistema = dijit.byId("item.sistemaIsc").getValue();
		var iscPorcentCtrl = dijit.byId("item.iscPorcentaje");
		var iscMontoCtrl = dijit.byId("item.iscMonto");

		if(sistema == '0') {
			iscPorcentCtrl.setValue(0);
			iscMontoCtrl.setValue(0);
			iscPorcentCtrl.setAttribute('disabled', true);
			iscMontoCtrl.setAttribute('disabled', true);
		}
		else if(sistema == '1' || sistema == '3') {
			iscMontoCtrl.setAttribute('disabled', true);
			iscPorcentCtrl.setAttribute('disabled', false);
			iscPorcentCtrl.focus();
		}
		else {
			iscPorcentCtrl.setValue(0);
			iscPorcentCtrl.setAttribute('disabled', true);
			iscMontoCtrl.setAttribute('disabled', false);
			iscMontoCtrl.setValue(0);
			iscMontoCtrl.focus();
		}
	},

	valoresNumDocRecepFENoDomic: function(){

		var tipoDocSel = dijit.byId("inicio.tipoDocRecepFENodomic").getValue().substring(0,1);
    	if (tipoDocSel == "4") {
    		dijit.byId("inicio.numeroDocRecepFENodomic").attr('regExp','[A-Za-z0-9]+[-]{0,1}[A-Za-z0-9]+');
    	}else{
           dijit.byId("inicio.numeroDocRecepFENodomic").attr('regExp','[^|\~°¬¨"]+');
    	}
	},

	valoresTipoCondicionRECPO:function(){
		if ( dijit.byId("comercializaOro.condicionRECPO").getValue() == "04"){
			this.showHiddenDiv(document.getElementById("comercializaOro.divCVOroOperacion.show"),true);
		} else {
			dijit.byId("comercializaOro.CVOroOperacion").setValue("01");
			this.showHiddenDiv(document.getElementById("comercializaOro.divCVOroOperacion.show"),false);
			this.showHiddenDiv(document.getElementById("comercializaOro.divCPOro.show"),false);
		}

		if ( dijit.byId("comercializaOro.condicionRECPO").getValue() == "03"  || dijit.byId("comercializaOro.CVOroOperacion").getValue() == "03"){
			this.showHiddenDiv(document.getElementById("comercializaOro.divCPOro.show"),true);
		}else{
			this.showHiddenDiv(document.getElementById("comercializaOro.divCPOro.show"),false);
		}

		if ( dijit.byId("comercializaOro.condicionRECPO").getValue() == "01"  || dijit.byId("comercializaOro.CVOroOperacion").getValue() == "02"){
			this.showHiddenDiv(document.getElementById("comercializaOro.divCodigosConcesionMinera.show"),true);
		} else {
			this.showHiddenDiv(document.getElementById("comercializaOro.divCodigosConcesionMinera.show"),false);
		}
	},

	valoresTipoOperacionRECPO:function(){
		if ( dijit.byId("comercializaOro.condicionRECPO").getValue() == "03"  || dijit.byId("comercializaOro.CVOroOperacion").getValue() == "03"){
			this.showHiddenDiv(document.getElementById("comercializaOro.divCPOro.show"),true);
		} else {
			this.showHiddenDiv(document.getElementById("comercializaOro.divCPOro.show"),false);
		}

		if ( dijit.byId("comercializaOro.condicionRECPO").getValue() == "01"  || dijit.byId("comercializaOro.CVOroOperacion").getValue() == "02"){
			this.showHiddenDiv(document.getElementById("comercializaOro.divCodigosConcesionMinera.show"),true);
		} else {
			this.showHiddenDiv(document.getElementById("comercializaOro.divCodigosConcesionMinera.show"),false);
		}
	},

	validateType: function (){
		var td = dijit.byId("inicio.tipoDocumento").getValue();

		ndControl = dijit.byId("inicio.numeroDocumento");
		rzControl = dijit.byId("inicio.razonSocial");

		dijit.byId("inicio.numeroDocumento").attr('value', '');
		dijit.byId("inicio.razonSocial").attr('value', '');
		this.showOpcionesTransaccion(this.getValorOpcionInicialTransaccion());//PAS20201U210100230

		if (td == "-"){
			ndControl.attr('disabled',true);
			//rzControl.attr('disabled',true);
			ndControl.attr('regExp','[^|\~°¬¨"]+');
			ndControl.attr('maxLength','100');
			rzControl.attr('disabled',false);
			rzControl.focus();

			//PAS20181U210300095
			if (this.getValorOpcionInicialExportacion() == 1){
				this.showHiddenDiv(document.getElementById("inicio.ruc.show"),false);
				this.showHiddenDiv(document.getElementById("inicio.razonSocial.show"),true);
				var exprsControl = dijit.byId("inicio.exportacion.razonSocial");
				exprsControl.attr('value', '');
				exprsControl.focus();
			}
		}else if (td == "1"){ //DNI
			ndControl.attr('disabled',false);
			ndControl.attr('regExp','[0-9]+');
			ndControl.attr('maxLength','8');
			rzControl.attr('disabled',true);
			ndControl.focus();
			//PAS20211U210700145-EBV
			dojo.byId("inicio.ruc.label").innerHTML="Consigne el Documento de Identidad del Contribuyente ";
		}else if (td == "6"){ //RUC
			//PAS20181U210300095
			if (this.getValorOpcionInicialExportacion() == 1){
				this.showHiddenDiv(document.getElementById("inicio.ruc.show"),true);
				this.showHiddenDiv(document.getElementById("inicio.razonSocial.show"),false);
				var exprsControl = dijit.byId("inicio.exportacion.razonSocial");
				exprsControl.attr('value', '');
			}

			dojo.byId("inicio.ruc.label").innerHTML="Consigne el RUC del Contribuyente Receptor de la Factura"; // PAS20211U210100010
			ndControl.attr('disabled',false);
			ndControl.attr('regExp','[0-9]+');
			ndControl.attr('maxLength','11');
			rzControl.attr('disabled',true);
			ndControl.focus();
		}else if (td == "4"){
			ndControl.attr('disabled',false);
			ndControl.attr('regExp','[A-Za-z0-9]+[-]{0,1}[A-Za-z0-9]+');
				ndControl.attr('maxLength','15');
				rzControl.attr('disabled',false);
				ndControl.focus();
		}else if (td == "7"){
			ndControl.attr('disabled',false);
			ndControl.attr('regExp','[A-Za-z0-9]+[-]{0,1}[A-Za-z0-9]+');
				ndControl.attr('maxLength','15');
				rzControl.attr('disabled',false);
				ndControl.focus();
		}else if (td == "A"){
			ndControl.attr('disabled',false);
			ndControl.attr('regExp','[A-Za-z0-9]+[-]{0,1}[A-Za-z0-9]+');
				ndControl.attr('maxLength','15');
				rzControl.attr('disabled',false);
				ndControl.focus();
		}else{
				// Anterior Bloque
				// 4, 7 o A
				//ndControl.attr('disabled',false);
				//ndControl.attr('regExp','[A-Za-z0-9]+[-]{0,1}[A-Za-z0-9]+');
				//ndControl.attr('maxLength','15');
				//rzControl.attr('disabled',false);
				//ndControl.focus();

			// PAS20211U210100010
			// 0, B, C y D

			if (this.getValorOpcionInicialExportacion() == 1){
				this.showHiddenDiv(document.getElementById("inicio.ruc.show"),true);
				this.showHiddenDiv(document.getElementById("inicio.razonSocial.show"),false);
				var exprsControl = dijit.byId("inicio.exportacion.razonSocial");
				exprsControl.attr('value', '');
				dojo.byId("inicio.raznsoc.label").innerHTML="Consigne Apellidos y Nombres del Cliente, o Denominaci&oacute;n o Raz&oacute;n Social cuando corresponda";
			}

			dojo.byId("inicio.ruc.label").innerHTML="Consigne el N&uacute;mero de Documento del Receptor de la Factura";
			ndControl.attr('disabled',false);
			ndControl.attr('regExp','[A-Za-z0-9]+[-]{0,1}[A-Za-z0-9]+');
				ndControl.attr('maxLength','15');
				rzControl.attr('disabled',false);
				ndControl.focus();
		}
	},

	validateDocument: function(){
		/** Via xhr valida el ruc en el servidor y devuelve los datos */
		var razonSocial = dijit.byId("inicio.razonSocial");
		razonSocial.attr('value', "");
		if(this.globalCambiosFactoringHabilitados=="1"){
			var domicilioFiscal = dijit.byId("inicio.facturaFactoring.domicilioFiscal");
			domicilioFiscal.attr('value', "");
		}
		var td = dijit.byId("inicio.tipoDocumento").getValue();
		var ndControl = dijit.byId("inicio.numeroDocumento");
		var ndLength = dojo.trim(ndControl.getValue()).length;

		if (td == "-" || ndLength == 0){
			return;
		} else if (td == "6") {
			this.self = this;
			if(!this.isValidRuc(dojo.trim(ndControl.getValue()))) {
				mostrarMensaje("Número de RUC incorrecto.");
				ndControl.attr('value', "");
				ndControl.focus();
				return;
			}

			if ((dojo.byId("global.gastoDeduciblePPNN").value == 1) &&
			(ndControl.getValue().substring(0, 2) != "15")){
				mostrarMensaje("En caso de Gastos Deducibles para personas naturales, el RUC debe empezar con 15.");
				ndControl.attr('value', "");
				ndControl.focus();
				return;
			}
		} else if (td == "1") {
			if (ndLength != 8){
				mostrarMensaje("N\u00FAmero de documento de identidad inconsistente.");
				ndControl.attr('value', "");
				ndControl.focus();
				return;
			}
		} else if (td == "0" || td == "B" || td == "C" || td == "D"){ // PAS20211U210100010
			if (ndLength < 3){
				// mostrarMensaje("DOC.TRIB.NO.DOM.SIN.RUC debe tener m\u00EDnimo 3 car\u00E1cteres");
				mostrarMensaje("Debe ingresar m\u00EDnimo 3 y m\u00E1ximo 15 caracteres para el n\u00FAmero de documento del receptor de la factura");
				ndControl.attr('value', "");
				ndControl.focus();
				return;
			}
		}

		dojo.byId("global.opcionDomicilioClienteIdentifica").value = "";
		dojo.byId("global.opcionDomicilioClienteDireccion").value = "";
		if (td == "1" || td == "6") {

			this.wait("Consultando", "110px", 200);
			var handler = dojo.xhrGet({
				preventCache:  false,
				url: this.controller + "?action=validarAdquiriente&tipoDocumento=" + td + "&numeroDocumento=" + dojo.trim(ndControl.getValue()),
				handleAs: "json",
				sync: true,
				timeout: 10000
			});

			handler.addCallback(dojo.hitch(this, function(response){
				this.waitMessage.hide();
				if(response.codeError == 0) {
					dijit.byId("inicio.razonSocial").attr('value',response.data);
				} else {
					ndControl.attr('value', "");
					ndControl.focus();
					mostrarMensaje(response.messageError);
				}
			}));

			handler.addErrback(function(response){
				this.waitMessage.hide();
				mostrarMensaje("Ocurrio un error al validar el adquiriente");
			});
			//ALB
			this.obtenerDomicilio();
		}


	},

	//PAS20201U210100230 INI //	alb1
	validatePuedeEmitirRetencion: function(nbControl) {
		if(dojo.byId("global.puedeEmitirRetencion")!=null){

			var valPuedeEmitirRetencion = dojo.byId("global.puedeEmitirRetencion").value;
			var fechaEmision = dojo.byId("global.fecEmision").value;
			var tipoDocumento = dojo.byId("global.tipoDocumento").value;
			var numeroDocumento = dojo.byId("global.numeroDocumento").value;

			var handler = dojo.xhrGet({
				preventCache:  false,
				url: this.controller + "?action=validarEsAgenteRetencion&tipoDocumento=" + tipoDocumento + "&numeroDocumento=" + numeroDocumento + "&fecEmision=" + fechaEmision,
				handleAs: "json",
				sync: true,
				timeout: 10000
			});

			handler.addCallback(dojo.hitch(this, function(response){
				this.waitMessage.hide();
				if(response.codeError == 0) {
					dojo.byId("global.puedeEmitirRetencion").value =  response.data;
				} else {
					nbControl.setAttribute('disabled', false);
					this.waitMessage.hide();
					mostrarMensaje(res.messageError);
				}
			}));

			handler.addErrback(function(response){
				nbControl.setAttribute('disabled', false);
				this.waitMessage.hide();
				mostrarMensaje("Ocurrio un error al validar el Agente Retencion");
			});
		}
	},

	obtenerDomicilio: function(){

		var modoTransaccion="";
		if(dojo.byId("inicio.tipoTransaccion")!= null){
			modoTransaccion = dojo.byId("inicio.tipoTransaccion").value;
		}

		var ndControl = dijit.byId("inicio.numeroDocumento");
		var td = dijit.byId("inicio.tipoDocumento").getValue();
		var ndLength = dojo.trim(ndControl.getValue()).length;

		if(dijit.byId("inicio.facturaFactoring.domicilioFiscal")!=null){


			if (td == "-" || ndLength == 0){
				dijit.byId("inicio.facturaFactoring.domicilioFiscal").setValue("");
				return;
			} else
				if (td == "6") {

				if(modoTransaccion==2){
					var handlerDomicilio = dojo.xhrGet({
						preventCache:  false,
						url: this.controller + "?action=obtenerDomicilioFiscal&tipoDocumento=" + td + "&numeroDocumento=" + dojo.trim(ndControl.getValue()),
						handleAs: "json",
						sync: false,
						timeout: 10000
					});

					handlerDomicilio.addCallback(dojo.hitch(this, function(response){
						this.waitMessage.hide();
						if(response.codeError == 0) {
							dijit.byId("inicio.facturaFactoring.domicilioFiscal").attr('value',response.data);
						}else{
							ndControl.attr('value', "");
							ndControl.focus();
							mostrarMensaje(response.messageError);
						}
					}));

					handlerDomicilio.addErrback(function(response){
						this.waitMessage.hide();
						mostrarMensaje("Ocurrio un error al validar el adquiriente");
					});

				}else{
					dijit.byId("inicio.facturaFactoring.domicilioFiscal").setValue("");
				}
			}
		}

	},
	//PAS20201U210100230 FIN


	//Antonio
	validateSerie: function(){
		var serie1 = document.getElementById("serie").value;
		var numero1 = document.getElementById("numero").value;
		var regexSerie1=false;
		var regexNumero1=false;
		var digitoSerie1="";
		var digitoNumero1="";
		var regex1 = /[0-9]|\./;
		for (i=0; i< serie1.length;i++){
		digitoSerie1= serie1.charAt(i);
			if(!regex1.test(digitoSerie1)) {//la serie debe ser numerica incluyendo 0
			regexSerie1=true;
			}
      	 }

		for (i=0; i< numero1.length;i++){
		digitoNumero1= numero1.charAt(i);
			if(!regex1.test(digitoNumero1)) {//el numero debe ser de tipo numerico incluyendo 0
			regexNumero1=true;
			}
      	 }

					if(serie1!==""){//la serie debe ser diferente de vacio
						if(serie1.length==4){//el numero debe ser de 9 digitos como maximo
							if(!regexSerie1) {//el numero debe ser de tipo numerico incluyendo 0
							document.getElementById("numero").value="";
							document.getElementById("numero").focus();
							}else{mostrarMensaje("La serie debe ser numérica");
							document.getElementById("serie").value="";
							document.getElementById("numero").value="";
							document.getElementById("serie").focus();}
						}else{mostrarMensaje("la serie debe tener 4 caracteres");
						document.getElementById("serie").value="";
						document.getElementById("numero").value="";
						document.getElementById("serie").focus();}
					}

	},

	//Antonio
	validateNumero: function(){
		var serie = document.getElementById("serie").value;
		var numero = document.getElementById("numero").value;
		var establecimiento = document.getElementById("establecimiento").value;
		if(establecimiento!==""){
		var regexSerie=false;
		var regexNumero=false;
		var digitoSerie="";
		var digitoNumero="";
		var regex = /[0-9]|\./;
		for (i=0; i< serie.length;i++){
		digitoSerie= serie.charAt(i);
			if(!regex.test(digitoSerie)) {//la serie debe ser numerica incluyendo 0
			regexSerie=true;
			}
      	 }

		for (i=0; i< numero.length;i++){
		digitoNumero= numero.charAt(i);
			if(!regex.test(digitoNumero)) {//el numero debe ser de tipo numerico incluyendo 0
			regexNumero=true;
			}
      	 }

		 if(numero!==""){//la serie debe ser diferente de vacio
			if(numero.length<=9){//el numero debe ser de 9 digitos como maximo
				if(!regexNumero) {//el numero debe ser de tipo numerico incluyendo 0
					if(serie!==""){//la serie debe ser diferente de vacio
						if(serie.length<=4){//el numero debe ser de 9 digitos como maximo
							if(!regexSerie) {//el numero debe ser de tipo numerico incluyendo 0
								var handler = dojo.xhrGet({
									preventCache:  false,
									url: this.controller + "?action=validadComprobante&serie=" + serie + "&numero=" + numero+"&establecimiento="+establecimiento,
									handleAs: "json",
									sync: true,
									timeout: 10000
								});
								handler.addCallback(dojo.hitch(this, function(response){
									this.waitMessage.hide();
										if(response.codeError==1){

										}else if(response.codeError==7){
											mostrarMensaje(""+response.data);
										}else {
										mostrarMensaje(""+response.data);
										document.getElementById("numero").value="";
										document.getElementById("numero").focus();
										}
								}));
								handler.addErrback(function(response){
									this.waitMessage.hide();
									mostrarMensaje("Ocurrio un error al validar datos del comprobante");
								});
							}else{mostrarMensaje("La serie debe ser numérica");
							document.getElementById("serie").value="";
							document.getElementById("numero").value="";
							document.getElementById("serie").focus();}
						}else{mostrarMensaje("la serie debe tener 4 caracteres");
						document.getElementById("serie").value="";
						document.getElementById("numero").value="";
						document.getElementById("serie").focus();}
					}else{mostrarMensaje("ingrese la serie");
					document.getElementById("serie").value="";
					 document.getElementById("numero").value="";
					 document.getElementById("serie").focus();}
				}else{ mostrarMensaje("El número debe ser de tipo numérico");
				document.getElementById("numero").value="";
				document.getElementById("numero").focus();}
			}else{	mostrarMensaje("El numero maximo de caracteres es de 9 digitos");
			document.getElementById("numero").value="";
			document.getElementById("numero").focus();}
		 }
		}else{
			mostrarMensaje("Seleccione el establecimiento");
			document.getElementById("numero").value="";
		}

	},

	validateRUCTraslado: function(){
		/** Via xhr valida el ruc en el servidor y devuelve los datos */
		var razonSocial = dijit.byId("trasladoBienes.razonSocial");
		razonSocial.attr('value', "");

		var ndControl = dijit.byId("trasladoBienes.rucTransportista");

		var ndLength = dojo.trim(ndControl.getValue()).length;
		if(ndLength != 11 ) {
			return;
		}

		//self = this;
		if(!this.isValidRuc(dojo.trim(ndControl.getValue()))) {
			mostrarMensaje("Número de RUC incorrecto.");
			ndControl.attr('value', "");
			ndControl.focus();
			return;
		}

		this.wait("Consultando", "110px", 200);
		var handler = dojo.xhrGet({
			preventCache:  false,
			url: this.controller + "?action=validarRUC&numeroDocumento=" + dojo.trim(ndControl.getValue()),
			handleAs: "json",
			sync: true,
			timeout: 10000
		});

		handler.addCallback(dojo.hitch(this, function(response){
			this.waitMessage.hide();
			if(response.codeError == 0) {
				dijit.byId("trasladoBienes.razonSocial").attr('value',response.data);
				dojo.byId("trasladoBienes.razonSocialSel").value = response.data;
			} else {
				var nroDoc = dijit.byId("trasladoBienes.rucTransportista");

				nroDoc.attr('value', "");
				nroDoc.focus();
				dojo.byId("trasladoBienes.razonSocialSel").value = "";
				mostrarMensaje(response.messageError);
			}
		}));

		handler.addErrback(function(response){
			this.waitMessage.hide();
			mostrarMensaje("Ocurrio un error al validar el adquiriente");
		});
	},

	showCalcValorRefSPOT: function() {
		this.dialogCalculoValorRef.show();
	},

	acceptCalcValorRefSPOT: function() {
		this.dialogCalculoValorRef.hide();
	},

	showRECPO: function() {
		this.showHiddenDiv(document.getElementById("comercializaOro.divCPOro.show"),false);
		this.showHiddenDiv(document.getElementById("comercializaOro.divCodigosConcesionMinera.show"),false);
		dijit.byId("comercializaOro.condicionRECPO").setValue("01");
		if ( dijit.byId("comercializaOro.condicionRECPO").getValue() == "04"){
			this.showHiddenDiv(document.getElementById("comercializaOro.divCVOroOperacion.show"),true);
		}else{
			this.showHiddenDiv(document.getElementById("comercializaOro.divCVOroOperacion.show"),false);
		}

		if ( dijit.byId("comercializaOro.condicionRECPO").getValue() == "03"  || dijit.byId("comercializaOro.CVOroOperacion").getValue() == "03"){
			this.showHiddenDiv(document.getElementById("comercializaOro.divCPOro.show"),true);
		}else{
			this.showHiddenDiv(document.getElementById("comercializaOro.divCPOro.show"),false);
		}

		if ( dijit.byId("comercializaOro.condicionRECPO").getValue() == "01"  || dijit.byId("comercializaOro.CVOroOperacion").getValue() == "02"){
			this.showHiddenDiv(document.getElementById("comercializaOro.divCodigosConcesionMinera.show"),true);
		} else {
			this.showHiddenDiv(document.getElementById("comercializaOro.divCodigosConcesionMinera.show"),false);
		}

		this.dialogComercializacionOro.show();
	},

	acceptComercioOro: function() {
		this.dialogComercializacionOro.hide();
	},

	//-----------------------------PAS20201U210100230 -OPV Inicio Formulario Informacion de Credito Cuotas------------------------------
		//PAS20201U210100230
		showInfCredito: function() {
			// SI HA GUARDADO RECUPERA LO GUARDADO
			if(this.storeInfCreditoGuardado.length!=0){
			     dijit.byId("docrelInfCred.montoNetoPendiente").setValue(this.montoNetoPendienteGuardado);
				// GUARDO LA NUEVA LISTA
				this.listaElementosInfCredito=[];
				// CREO LISTA QUE REEMPLAZARA
			    var ListaOrdenada=[];
				// ABRO EL FORMULARIO PRIMERO, si no se abre la grilla se vera mal luego de hacer update.
				this.dialogInfCredito.show();
				this.montoTotalCuotas=0;
				this.indRegitroInfCredito=0;
				//RECORRO NUEVAMENTE LA GRILLA
				this.storeInfCredito = new dojo.data.ItemFileWriteStore({data: {identifier: 'identificador', items: [], preventCache: true}});//OPV-INI-Compatibilidad Internet Explorer
			   	//this.storeInfCreditoGuardado.forEach(element=>{

				//Inicio [PAS20211U210700145][anunez][2021.11.05] restaura los datos respaldados al editar en storeInfCreditoGuardado
				if (this.storeInfCreditoGuardadoComplementaria.length != 0){
					for (i=0; i < this.storeInfCreditoGuardadoComplementaria.length; i++) {
						for (e=0; e < this.storeInfCreditoGuardado.length; e++) {
							if (this.storeInfCreditoGuardadoComplementaria[i][0] == this.storeInfCreditoGuardado[e].identificador){
								if (this.storeInfCreditoGuardadoComplementaria[i][1] != this.storeInfCreditoGuardado[e].montoCuota ||
									this.storeInfCreditoGuardadoComplementaria[i][2] != this.storeInfCreditoGuardado[e].fechaVencimiento ||
									this.storeInfCreditoGuardadoComplementaria[i][3] != this.storeInfCreditoGuardado[e].fechaVencimientoDate){

									this.storeInfCreditoGuardado[e].montoCuota = this.storeInfCreditoGuardadoComplementaria[i][1];
									this.storeInfCreditoGuardado[e].fechaVencimiento = this.storeInfCreditoGuardadoComplementaria[i][2];
									this.storeInfCreditoGuardado[e].fechaVencimientoDate = this.storeInfCreditoGuardadoComplementaria[i][3];
								}
							}
						}
					};
				}
				this.storeInfCreditoGuardadoComplementaria = [];
				//Fin [PAS20211U210700145]

				for (i=0; i < this.storeInfCreditoGuardado.length; i++) {
					var element=this.storeInfCreditoGuardado[i];

						this.listaElementosInfCredito.push(element);
						var row={
		     				identificador: this.indRegitroInfCredito,
							modifica: this.indRegitroInfCredito,
							elimina: this.indRegitroInfCredito,
							numeroCuota: element.numeroCuota,
							fechaVencimiento: element.fechaVencimiento,
							fechaVencimientoDate: element.fechaVencimientoDate,
							montoCuota: element.montoCuota
						};
						this.indRegitroInfCredito++;
						// Agrego a lista ordenada.
						ListaOrdenada.push(row);
						//SUMAR EL TOTAL DE LAS CUOTAS
						this.storeInfCredito.newItem(row);
						this.montoTotalCuotas=Number(this.montoTotalCuotas)+Number(row.montoCuota);
						//dojo.byId("docrelInfCred.TotalCuotas").innerHTML =this.montoTotalCuotas;
				};
				//OPV-FIN-Compatibilidad Internet Explorer
			   //REALIZAS EL REEMPLAZO
			    var grid = dijit.byId("docrelInfCred-grid");
				grid.setStore(this.storeInfCredito);
				if(dijit.byId("docrelInfCred-grid").store.save) {
					dijit.byId("docrelInfCred-grid").store.save();
				}
				grid.startup();
				grid.update();

			   //QUITAR ELEMENT
			} else{
				// SINO NO GUARDO RECUPERA LO QUE HAY ACTUALMENTE.
				//RECUPERAR DATOS
			    //dijit.byId("docrelInfCred.montoNetoPendiente").setValue(this.montoTotalCuotas);
				//Inicio [PAS20211U210700145][anunez][2021.11.05] limpia el formulario de lista de cuotas si no se realizó guardado alguno
				this.limpiarInfCreditoYCuota();
			    dijit.byId("docrelInfCred.montoNetoPendiente").setValue(0.00);
				this.dialogInfCredito.show();
			    var grid = dijit.byId("docrelInfCred-grid");
				//grid.setStore(this.storeInfCredito);
				this.storeInfCredito = null;
				//Fin [PAS20211U210700145]
				grid.setStore(this.storeInfCredito);
				grid.startup();
				grid.update();
			}

		},
		//PAS20201U210100230
		//SIRVE PARA LIMPIAR FORMULARIO DE CUOTAS
		limpiarInfCuota: function() {
			dijit.byId("docrelInfCuota.FechaVencimiento").setValue(null);
			dijit.byId("docrelInfCuota.MontoCuota").setValue(0);
		},
		//PAS20201U210100230
		//SIRVE PARA ABRIR EL FORMULARIO DE CUOTAS
		showInfCuota: function(Tipo,Datos) {
			var btnAceptarCuota = dijit.byId("docrelInfCuota.botonAceptar");
			btnAceptarCuota.attr('disabled', false);
			require(["dijit/registry"], function(registry){
				var formInfCuota = registry.byId("docrelInfCuota.form");
				formInfCuota.reset();
			});

			if(Tipo!=undefined && Datos!=undefined){
				if(this.storeInfCuota!=null){
					var split=this.storeInfCuota.fechaVencimiento.split("/");
					var fechaConFormatoCombo =split[2] +'-'+ split[1] +'-'+ split[0];
					dijit.byId("docrelInfCuota.FechaVencimiento").setValue(fechaConFormatoCombo);
					dijit.byId("docrelInfCuota.MontoCuota").setValue(this.storeInfCuota.montoCuota);
				}
			    this.dialogInfCuota.show();
			}else{
				this.storeInfCuota=null	;
				this.limpiarInfCuota();
				this.dialogInfCuota.show();
			}
		},
		//PAS20201U210100230
		//SIRVE PARA BORRAR
		delInfCredito: function(identificador) {
			var grid = dijit.byId("docrelInfCred-grid");
			this.storeInfCredito.fetchItemByIdentity({
				identity: identificador,
				onItem: dojo.hitch(this, function(item){
				   this.storeInfCredito.deleteItem(item);
				   grid.setStore(this.storeInfCredito);
				   grid.update();
				   //QUITAR ELEMENTOS DE LA LISTA

				   var removeIndex = this.listaElementosInfCredito.map(function(item) { return item.identificador; }).indexOf(identificador);
					// remove object
					this.listaElementosInfCredito.splice(removeIndex, 1);
				}),
				onError: function(){
					mostrarMensaje("Ocurrio un error al ubicar el documento");
				}
			});
			//LLAMAR AL METODO ORDENAR POR FECHA
			this.infCreditoOrdenarPorFecha();
			console.log("docrelInfCred-grid_rowCount delete--> " + dijit.byId("docrelInfCred-grid").rowCount);
		},
		//PAS20201U210100230
		//SIRVE PARA EDITAR
		editInfCredito: function(identificador) {
			//var nodeButton = dijit.byId("docrel.botonDelDoc").focusNode;
			var grid = dijit.byId("docrelInfCred-grid");
			// NECESARIO PARA DETECTAR QUE ITEM ESTAS EDITANDO
			this.storeInfCredito.fetchItemByIdentity({
				identity: identificador,
				onItem: dojo.hitch(this, function(item){
					//CREAR VARIABLE STORE-CUOTA
					//OPV-INI-Compatibilidad Internet Explorer
					//var itemCuota=this.listaElementosInfCredito.findIndex((obj => obj.identificador == item.identificador));
					var itemCuota;
					for (var i = 0; i < this.listaElementosInfCredito.length; ++i) {
						if (this.listaElementosInfCredito[i].identificador == item.identificador) {
							itemCuota = i;
							break;
						}
					};
					//OPV-FIN-Compatibilidad Internet Explorer
					this.storeInfCuota=this.listaElementosInfCredito[itemCuota];
				}),
				onError: function(){
					mostrarMensaje("Ocurrio un error al ubicar el documento");
				}
			});
			// PARA EDITAR
			this.limpiarInfCuota();
		    this.showInfCuota("Editar",this.storeInfCuota);
		},

		//ORDENA POR FECHAS Y ACTUALIZA EL TOTAL DE DE LA SUMA DE CUOTAS, TAMBIEN CAMBIA LOS VALORES ACTUALES DE LOS IDENTIFICADORES Y NUMEROS DE CUOTAS.
		infCreditoOrdenarPorFecha: function() {
			var ListaOrdenada=[];
			var grid = dijit.byId("docrelInfCred-grid");
			this.indRegitroInfCredito=0;
			if(this.listaElementosInfCredito.length >0){
				//ORDENAR ELEMENTOS
				this.listaElementosInfCredito.sort(function (x, y) {
					let a = x.fechaVencimientoDate,
						b = y.fechaVencimientoDate;
					return a - b;
				});
				this.montoTotalCuotas=0;
				// RECORRO PARA EVITAR QUE EL ITEM FILE SOBREESCRIBA.
				for(i=0;i< this.listaElementosInfCredito.length;i++){
					this.listaElementosInfCredito[i].identificador=i;
					this.listaElementosInfCredito[i].modifica=i;
					this.listaElementosInfCredito[i].elimina=i;
					this.listaElementosInfCredito[i].numeroCuota=i+1;
				}

				//REEMPLAZAR  EN OTRA LISTA PARA EVITAR ITEM FILE SOBREESCRIBA.
				//OPV-INI-Compatibilidad Internet Explorer
				//this.listaElementosInfCredito.forEach(element=>{
				for (i=0; i < this.listaElementosInfCredito.length; i++) {
					var element=this.listaElementosInfCredito[i];

						var row={
		     				identificador: this.indRegitroInfCredito,
							modifica: this.indRegitroInfCredito,
							elimina: this.indRegitroInfCredito,
							numeroCuota: element.numeroCuota,
							fechaVencimiento: element.fechaVencimiento,
							fechaVencimientoDate: element.fechaVencimientoDate,
							montoCuota: element.montoCuota
						};
						this.indRegitroInfCredito++;
						ListaOrdenada.push(row);
						//SUMAR EL TOTAL DE LAS CUOTAS
						this.montoTotalCuotas=Number(this.montoTotalCuotas)+Number(row.montoCuota);
						//dojo.byId("docrelInfCred.TotalCuotas").innerHTML =this.montoTotalCuotas;
				};
				//OPV-FIN-Compatibilidad Internet Explorer
				//CREAR NUEVO STORE PARA TABLA	ESTE METODO SOBREESCRIBE ListaOrdenada	pero no	this.listaElementosInfCredito
				this.storeInfCredito = new dojo.data.ItemFileWriteStore({data: {identifier: 'identificador', items: ListaOrdenada, preventCache: true}});
				grid.setStore(this.storeInfCredito);
				grid.startup();
				grid.update();
			}
		}
		,
		//PAS20201U210100230
		//SIRVE PARA GUARDAR
		infCreditoRegistrar: function() {
			//validacion de minimo y maximo
			var montoTotalFactura= dojo.byId("global.importeTotal").value;
			var maximoCuotas= dojo.byId("global.creditoCuotasMaximo").value;
			var nodeButton;
			if (dijit.byId("docrelInfCred-grid").rowCount == 0 ) {
				nodeButton= dijit.byId("docrelInfCred.botonAceptar").focusNode
				this.iconTooltipMessage(nodeButton, "icon-error-tooltip", "Debe registrar al menos 1 cuota");
				this.waitMessage.hide();
				return;
			}
			if (dijit.byId("docrelInfCred-grid").rowCount >Number(maximoCuotas)  ) {
				nodeButton= dijit.byId("docrelInfCred.botonAceptar").focusNode
				this.iconTooltipMessage(nodeButton, "icon-error-tooltip", "Mínimo 1, máximo 60 cuotas");
				this.waitMessage.hide();
				return;
			}
			// VALIDACIONES PARA  MONTO NETO PENDIENTE
			if(!dijit.byId("docrelInfCred.montoNetoPendiente").validate()){
			console.log("tiene mas de 2 decimales");
			return;
			}else if (isNaN(dijit.byId("docrelInfCred.montoNetoPendiente").value)==true  ) {
				/*nodeButton= dijit.byId("docrelInfCred.montoNetoPendiente").focusNode
				this.iconTooltipMessage(nodeButton, "icon-error-tooltip", "Debe registrar el Monto neto pendiente de pago.");
				this.waitMessage.hide();
				return;*/
				mostrarMensaje("Debe registrar el Monto neto pendiente de pago.");
				return;
			}
			if (dijit.byId("docrelInfCred.montoNetoPendiente").value <= 0 || dijit.byId("docrelInfCred.montoNetoPendiente").value== '') {
				nodeButton= dijit.byId("docrelInfCred.montoNetoPendiente").focusNode
				this.iconTooltipMessage(nodeButton, "icon-error-tooltip", "El monto debe ser mayor a 0");
				this.waitMessage.hide();
				return;
			}
			if (dijit.byId("docrelInfCred.montoNetoPendiente").value > Number(montoTotalFactura) ) {
				nodeButton= dijit.byId("docrelInfCred.montoNetoPendiente").focusNode
				this.iconTooltipMessage(nodeButton, "icon-error-tooltip", "El monto no puede ser mayor al importe total de la factura.");
				this.waitMessage.hide();
				return;
			}
			//VALIDACION DE SUMA DE CUOTAS.
			console.log("montoTotalCuotas--> " + this.montoTotalCuotas);
			console.log("montoTotalCuotas--> " + this.montoTotalCuotas.toFixed(2));
			console.log("montoTotalFactura--> " + montoTotalFactura);
			if (this.montoTotalCuotas.toFixed(2)> Number(montoTotalFactura) ) {
				nodeButton= dijit.byId("docrelInfCred.botonAceptar").focusNode
				this.iconTooltipMessage(nodeButton, "icon-error-tooltip", "La suma de las cuotas no pueden ser mayor al importe total de la factura.");
				this.waitMessage.hide();
				return;
			}
			//Inicio [PAS20211U210700145][anunez][2021.11.05] Se agrega la validación de la suma de cuotas no puede ser diferente del monto neto pendiente de pago
			if (this.montoTotalCuotas.toFixed(2) != dijit.byId("docrelInfCred.montoNetoPendiente").value) {
				nodeButton= dijit.byId("docrelInfCred.botonAceptar").focusNode
				this.waitMessage.hide();
				mostrarMensaje("La suma de las cuotas no puede ser diferente del monto neto pendiente de pago.");
				return;
			}
			//Fin [PAS20211U210700145]
			//GUARDAMOS EN SESION LOS ULTIMOS DATOS
			//this.storeInfCreditoGuardado=this.listaElementosInfCredito.slice();	// Se sobreescribe
			this.storeInfCreditoGuardado=[];
			//OPV-INI-Compatibilidad Internet Explorer
			//this.listaElementosInfCredito.forEach(element=>{
			for (i=0; i < this.listaElementosInfCredito.length; i++) {
					var element=this.listaElementosInfCredito[i];

				this.storeInfCreditoGuardado.push(element);
			};
			//OPV-FIN-Compatibilidad Internet Explorer
			this.montoNetoPendienteGuardado= dijit.byId("docrelInfCred.montoNetoPendiente").value;
			this.montoTotalCuotasGuardado=this.montoTotalCuotas;

			this.storeInfCreditoGuardadoComplementaria = [];//[PAS20211U210700145][anunez][2021.11.05] limpio lista complementaria para evitar que haga restauraciones no previstas
			// FIN VALIDACIONES PARA  MONTO NETO PENDIENTE
			var parametros={
				ListaCreditos:dojo.toJson(this.listaElementosInfCredito),
				MontoNetoPendiente:Number(this.montoNetoPendienteGuardado)
			};
			var jsonString;
			require(["dojo/json"], function(JSON){
			 jsonString = JSON.stringify(parametros);
			});
			var controller="emitir.do";
			//INTENTO
			this.waitMessage.show();
			var handler = dojo.xhrPost({
				url: this.controller + "?action=crearInfCredito",
				postData: parametros,
				handleAs: "json",
				sync: true,
				timeout: 10000
			});
			handler.addCallback(dojo.hitch(this, function(response){
				if(response.codeError == 0) {
					this.waitMessage.hide();
					this.dialogInfCredito.hide();
				}else{
					this.waitMessage.hide();
					mostrarMensaje(""+response.data);
				}
			}));
			handler.addErrback(dojo.hitch(this, function(res) {
				this.waitMessage.hide();
				this.iconTooltipMessage(nodeButton, "icon-error-tooltip", "Problemas al conectarse al servidor");
			}));

		},
		//PAS20201U210100230
		// ICONOS DE LA TABLA
		iconEditInfCredito: function(rowindex) {
			return "<a href=\"#\" title=\"Editar\" onclick=\"factura.editInfCredito(" + rowindex + ")\"><img class=\"icon-by-edit16\" src=\"/a/imagenes/s.gif\"/></a>";
		},
		//PAS20201U210100230
		iconDelInfCredito: function(rowindex) {
			return "<a href=\"#\" title=\"Eliminar\" onclick=\"factura.delInfCredito(" + rowindex + ")\"><img class=\"icon-by-del16\" src=\"/a/imagenes/s.gif\"/></a>";
		},

		//-------------------------PAS20201U210100230  FIN DEL FORMULARIO INF CREDITO----------------------------------------------
		// Inicio PAS20201U210100230
		 truncateTwoDecimal:function(x, n) {
		  //x es el numero
		  //n es el numero de decimales
		  if(isNaN(x)){
			return;
		  }
		  var v = (typeof x === 'string' ? x : x.toString()).split('.');
		  if (n <= 0) return v[0];
		  var f = v[1] || '';
		  //if (f.length > n) return `${v[0]}.${f.substr(0,n)}`;
		  if (f.length > n) return  v[0]+"."+f.substr(0,n);
		  while (f.length < n) f += '0';
		  //return `${v[0]}.${f}`
		  return v[0]+"."+f;
		},
		roundTwoDecimalCuota:function (){
			var montoCuotaTwoDecimal=this.truncateTwoDecimal(dojo.byId("docrelInfCuota.MontoCuota").value,2);
			if(isNaN(montoCuotaTwoDecimal)){
				return;
			}
			dijit.byId("docrelInfCuota.MontoCuota").value=montoCuotaTwoDecimal;
			dojo.byId("docrelInfCuota.MontoCuota").value=montoCuotaTwoDecimal;
			dijit.byId("docrelInfCuota.MontoCuota")._set("state","");
		}, // Fin PAS20201U210100230

		roundTwoMontoNetoPendiente:function (){
			var montoNetoPendienteTwoDecimal=this.truncateTwoDecimal(dojo.byId("docrelInfCred.montoNetoPendiente").value,2);
			if(isNaN(montoNetoPendienteTwoDecimal)){
				return;
			}
			dijit.byId("docrelInfCred.montoNetoPendiente").value=montoNetoPendienteTwoDecimal;
			dojo.byId("docrelInfCred.montoNetoPendiente").value=montoNetoPendienteTwoDecimal;
			dijit.byId("docrelInfCred.montoNetoPendiente")._set("state","");
		}, // Fin PAS20201U210100230

		//FormularioAgregarCuotas INICIO
		//PAS20201U210100230 TIENE 3 LOGICAS 1 para crear el store, otra para Insertar nuevo item y  otra para editar.
		infCuotaAceptar:function() {
			var fechaEmision = new Date(dojo.byId("global.fecEmision").value);
			var nodeButton;
			var oDoc;
			var row;
			var btnAceptarCuota = dijit.byId("docrelInfCuota.botonAceptar");
			//INICIO VALIDACIONES
			//CAMPO FECHA VACIO
			if (dojo.byId("docrelInfCuota.FechaVencimiento").value=="" ) {
				nodeButton= dijit.byId("docrelInfCuota.FechaVencimiento").focusNode
				this.iconTooltipMessage(nodeButton, "icon-error-tooltip", "Ingrese una fecha de vencimiento.");
				this.waitMessage.hide();
				return;
			}
			//FECHA INVALIDA
			if (dijit.byId("docrelInfCuota.FechaVencimiento").value==null ) {
				nodeButton= dijit.byId("docrelInfCuota.FechaVencimiento").focusNode
				this.iconTooltipMessage(nodeButton, "icon-error-tooltip", "Fecha inválida. Ingresar en formato dd/mm/yyyy.");
				this.waitMessage.hide();
				return;
			}
			//FECHA EMISION mayor a fecha de vencimiento
			//Inicio [PAS20211U210700145][anunez][2021.11.05] se cambia la validacion a menor o igual
			if (dijit.byId("docrelInfCuota.FechaVencimiento").value <=  fechaEmision ) {
				nodeButton= dijit.byId("docrelInfCuota.FechaVencimiento").focusNode
				this.iconTooltipMessage(nodeButton, "icon-error-tooltip", "La fecha de vencimiento no puede ser menor o igual a la fecha de emisión.");
				this.waitMessage.hide();
				return;
			}
			// Fin [PAS20211U210700145]
			//Validaciones para el monto de cuota
			//MONTO NO VALIDO
			if(!dijit.byId("docrelInfCuota.MontoCuota").validate()){
			console.log("tiene mas de 2 decimales");
			return;
			}else if (isNaN(dijit.byId("docrelInfCuota.MontoCuota").value)==true) {
				/*nodeButton= dijit.byId("docrelInfCuota.MontoCuota").focusNode
				this.iconTooltipMessage(nodeButton, "icon-error-tooltip", "Ingrese monto de la cuota.");
				this.waitMessage.hide();
				return;*/
				mostrarMensaje("Ingrese monto de la cuota.");
				return;
			}
			//MONTO MENOR O IGUAL A 0
			if (dijit.byId("docrelInfCuota.MontoCuota").value <= 0 || dijit.byId("docrelInfCuota.MontoCuota").value== '' ) {
				nodeButton= dijit.byId("docrelInfCuota.MontoCuota").focusNode
				this.iconTooltipMessage(nodeButton, "icon-error-tooltip", "La cuota debe ser mayor a 0");
				this.waitMessage.hide();
				return;
			}




			btnAceptarCuota.attr('disabled', true);
			// INICIO DE LOGICA
			//Inicio [PAS20211U210700145][anunez][2021.11.05]
			var montoComparar = 0.00;
			var fechaComparar = null;
			var fechaCompararDate = null;
			// Fin [PAS20211U210700145]
			if(this.storeInfCuota==null){
				oDoc={
					identificador:this.indRegitroInfCredito,
					numeroCuota:this.indRegitroInfCredito,
					fechaVencimiento: dijit.byId("docrelInfCuota.FechaVencimiento").getValue(),
					montoCuota: dijit.byId("docrelInfCuota.MontoCuota").getValue()
				};
				row = {
					identificador: oDoc.identificador,
					modifica: oDoc.identificador,
					elimina: oDoc.identificador,
					numeroCuota: oDoc.numeroCuota,
					fechaVencimiento: dojo.date.locale.format(oDoc.fechaVencimiento, {datePattern: "dd/MM/yyy", selector: "date"}),
					fechaVencimientoDate: oDoc.fechaVencimiento,
					montoCuota: oDoc.montoCuota
					};
				this.indRegitroInfCredito++;
				//Agregar a lista
				//Agregar Valor de total
				this.listaElementosInfCredito.push(row);
				this.montoTotalCuotas= row.montoCuota;
				const Objeto= row;
				//  LOGICA	MULTIPLE	PRIMER INGRESO CREA LUEGO AGREGA
				this.AgregarOActualizar(Objeto);

			}else
			{
				oDoc={
					identificador:this.storeInfCuota.identificador,
					numeroCuota:this.storeInfCuota.identificador,
					fechaVencimiento:dijit.byId("docrelInfCuota.FechaVencimiento").getValue(),
					montoCuota:dijit.byId("docrelInfCuota.MontoCuota").getValue()
				};
				row = {
					identificador: oDoc.identificador,
					modifica: oDoc.identificador,
					elimina: oDoc.identificador,
					numeroCuota: oDoc.numeroCuota,
					fechaVencimiento: dojo.date.locale.format(oDoc.fechaVencimiento, {datePattern: "dd/MM/yyy", selector: "date"}),
					fechaVencimientoDate: oDoc.fechaVencimiento,
					montoCuota: oDoc.montoCuota
					};
				//Reemplazar valor de la lista actual.
				//OPV-INI-Compatibilidad Internet Explorer
				//var objIndex = this.listaElementosInfCredito.findIndex((obj => obj.identificador == row.identificador));
				var objIndex;
				for (var i = 0; i < this.listaElementosInfCredito.length; ++i) {
					if (this.listaElementosInfCredito[i].identificador == row.identificador) {
						objIndex = i;
						break;
					}
				};
				//Inicio [PAS20211U210700145][anunez][2021.11.05] Se extraen los campos de la cuota que
				//son modificables para respaldarlos y evitar que sean cambiados en el storeInfCreditoGuardado
				for (i=0; i < this.storeInfCreditoGuardado.length; i++) {
					if (this.storeInfCreditoGuardado[i].identificador == row.identificador){
						montoComparar = this.storeInfCreditoGuardado[i].montoCuota;
						fechaComparar = this.storeInfCreditoGuardado[i].fechaVencimiento;
						fechaCompararDate = this.storeInfCreditoGuardado[i].fechaVencimientoDate;
						break;
					}
				};
				//Fin [PAS20211U210700145]

				//OPV-FIN-Compatibilidad Internet Explorer
				this.listaElementosInfCredito[objIndex].fechaVencimiento= row.fechaVencimiento;
				this.listaElementosInfCredito[objIndex].montoCuota=row.montoCuota;
				this.listaElementosInfCredito[objIndex].fechaVencimientoDate=row.fechaVencimientoDate;

			}
			this.dialogInfCuota.hide();
			//LLAMAR AL METODO ORDENAR POR FECHA
			this.infCreditoOrdenarPorFecha();
			//Inicio [PAS20211U210700145][anunez][2021.11.05] Los campos respaldados en la accion anterior son almacenados
			//en un array complementario que se usará para restaurar los valores en el storeInfCreditoGuardado al cargar
			//la pantalla despues de cerrada-esto es solo por la funcion de editar cuota
			var elementosCambiados = [];

			for (i=0; i < this.storeInfCreditoGuardado.length; i++) {
				if (this.storeInfCreditoGuardado[i].identificador == row.identificador){
					if (this.storeInfCreditoGuardado[i].montoCuota != montoComparar ||
						this.storeInfCreditoGuardado[i].fechaVencimiento != fechaComparar ||
						this.storeInfCreditoGuardado[i].fechaVencimientoDate != fechaCompararDate){

						elementosCambiados.push(row.identificador);
						elementosCambiados.push(montoComparar);
						elementosCambiados.push(fechaComparar);
						elementosCambiados.push(fechaCompararDate);
					}
					break;
				}
			};
			this.storeInfCreditoGuardadoComplementaria.push(elementosCambiados);
			//Fin [PAS20211U210700145]
		},
		//PAS20201U210100230 TIENE 3 LOGICAS CREA STORE INFO, AGREGA ITEMS ACTUALIZA GRILLA DEPENDIENDO DE LO QUE TIENE LLENO.
		AgregarOActualizar:function(valor) {
			const row=valor;
			if(row!=null && row!=undefined){
				console.log("storeInfCredito--> " + this.storeInfCredito );
				console.log("docrelInfCred-grid_rowCount agrega--> " + dijit.byId("docrelInfCred-grid").rowCount);
				if(dijit.byId("docrelInfCred-grid").rowCount==0){
					console.log("docrelInfCred-grid_rowCount==0");
					this.storeInfCredito = null;
					console.log("storeInfCredito seteo null--> " + this.storeInfCredito );
				}
				if(this.storeInfCredito == null){
					console.log("storeInfCredito null--> " + this.storeInfCredito );
					//Agregar a tabla
					this.storeInfCredito = new dojo.data.ItemFileWriteStore({data: {identifier: 'identificador', items: [], preventCache: true}});
					this.storeInfCredito.newItem(row);
				}else{
					console.log("storeInfCredito not null--> " + this.storeInfCredito );
					this.storeInfCredito.newItem(row);
				}
			}
		    //SINO ENVIAS NADA SOLO ACTUALIZA
			var grid = dijit.byId("docrelInfCred-grid");
			grid.setStore(this.storeInfCredito);
			if(dijit.byId("docrelInfCred-grid").store.save) {
			   dijit.byId("docrelInfCred-grid").store.save();
			}
			grid.startup();
			grid.update();

		},
		//FormularioAgregarCuotas FIN

	//-----------------------------------PAS20201U210100230 -OPV Fin Formulario Informacion de Credito Cuotas--------------------------------------------

	showDocsLinked: function() {
		// APDEX
		dijit.byId("docrel.serieDocumento").setValue("");
		 dijit.byId("docrel.tipoDocumento").reset();
		 dijit.byId("docrel.serieDocumento").setValue("");
		 dijit.byId("docrel.numeroDocumentoInicial").setValue("");
		 dijit.byId("docrel.numeroDocumentoFinal").setValue("");
		 var grid = dijit.byId("docrel-grid");
		 if(grid.rowCount > 0 && this.otherDocStore == null) {
			 grid.setStore(this.otherDocStore);
			 grid.update();
		 }
		this.dialogDocsLinked.show();
	},

	acceptDocsLinked: function() {
		this.dialogDocsLinked.hide();
	},

	showInformacionFESectorPublico: function() {
		//INI PAS20201U210100097 APDEX
		if(this.infAdicionalStore!=null){
			dijit.byId("infAdic.numeroExpediente").setValue(this.infAdicionalStore.numeroExpediente);
			dijit.byId("infAdic.ordenCompra").setValue(this.infAdicionalStore.ordenCompra);
			dijit.byId("infAdic.numeroProcesoSeleccion").setValue(this.infAdicionalStore.numeroProcesoSeleccion);
			dijit.byId("infAdic.codigoUnidadEjecutora").setValue(this.infAdicionalStore.codigoUnidadEjecutora);
			dijit.byId("infAdic.numeroContrato").setValue(this.infAdicionalStore.numeroContrato);
		}
		//FIN PAS20201U210100097 APDEX
		this.dialogInfAdicional.show();
	},

	showInformacionRecursosHidrobiologicos: function() {
	   this.dialogRecursosHidrobiologicos.show();
	},

	acceptRecursosHidrobiologicos: function() {
		this.dialogRecursosHidrobiologicos.hide();
	},

	showInformacionTrasladoBienes: function() {
		var grid = dijit.byId("licencias-grid");
		if(grid.rowCount > 0 && this.licenciaStore == null) {
			grid.setStore(this.licenciaStore);
			grid.update();
		}

		this.dialogInfTrasladoBienes.show();
	},

	showPuntoPartida: function() {
		this.dialogPuntoPartida.show();
		if (dojo.byId("global.opcionPuntoPartidaIdentifica").value == ""){
	  		dijit.byId("puntoPartida.subTipoEestabEmisor01").setChecked("checked");
	  		this.showEstabPropPP();
		}
	},

	showPuntoLlegada: function() {
		this.dialogPuntoLlegada.show();
		if (dojo.byId("global.opcionPuntoLlegadaIdentifica").value == ""){
	  		dijit.byId("puntoLlegada.subTipoEestabEmisor01").setChecked("checked");
	  		this.showEstabPropPLL();
	  	}
	},

	acceptInfAdicional: function() {
		if(!dijit.byId("infAdic.form").validate()) return;
		dojo.byId("global.numeroExpediente").value = dijit.byId("infAdic.numeroExpediente").getValue();
	    dojo.byId("global.ordenCompra").value = dijit.byId("infAdic.ordenCompra").getValue();
	    dojo.byId("global.numeroProcesoSeleccion").value = dijit.byId("infAdic.numeroProcesoSeleccion").getValue();
	    dojo.byId("global.codigoUnidadEjecutora").value = dijit.byId("infAdic.codigoUnidadEjecutora").getValue();
	    dojo.byId("global.numeroContrato").value = dijit.byId("infAdic.numeroContrato").getValue();

		var infAdicional = {
			numeroExpediente: dojo.byId("infAdic.numeroExpediente").value,
			ordenCompra: dojo.byId("infAdic.ordenCompra").value,
			codigoUnidadEjecutora: dojo.byId("infAdic.codigoUnidadEjecutora").value,
			numeroProcesoSeleccion: dojo.byId("infAdic.numeroProcesoSeleccion").value,
			numeroContrato: dojo.byId("infAdic.numeroContrato").value
		};
		this.infAdicionalStore=infAdicional;
		this.dialogInfAdicional.hide();
	},

	acceptPuntoPartida: function() {
		//if(!dijit.byId("puntoPartida.form").validate()) return;

    	var tipoDireccion = this.getValorOpcionTipoDireccPP ();
    	dojo.byId("global.opcionPuntoPartidaIdentifica").value = tipoDireccion;
    	if (tipoDireccion == null || tipoDireccion=="" ){
    		mostrarMensaje("Debe seleccionar el tipo de direcci\u00F3n del punto de partida.");
    		return;
    	}
    	dojo.byId("puntoPartida.num_ruc_domicilio").value = dojo.byId("global.numRucEmisor").value;

    	if (tipoDireccion ==1 || tipoDireccion ==2){
    		if (tipoDireccion == 1){
    			dojo.byId("puntoPartida.num_ruc_domicilio").value = dojo.byId("global.numeroDocumento").value;
  		  	} else {
  		  		if (tipoDireccion ==2) {
  		  			var ruc3ro =dijit.byId("puntoPartida.txt_ruc_tercero").getValue();
  		  			if (ruc3ro==""){
  		  				mostrarMensaje("Debe ingresar un n\u00FAmero de RUC v\u00E1lido.");
  		  				return;
  		  			}
  		  			if (ruc3ro.length != 11){
  		  				mostrarMensaje("Numero de RUC inv\u00E1lido");
                        return;
  		  			}

  		  			if (!this.isValidRuc(ruc3ro)){
  		  				mostrarMensaje("Numero de RUC inv\u00E1lido");
  		  				return;
  		  			}
  		  			dojo.byId("puntoPartida.num_ruc_domicilio").value = ruc3ro;
  		  		}
  		  	}
      	  	var grilla =dijit.byId("puntoPartida.domiciliosGrid");
      	  	var datos =grilla.store._arrayOfAllItems;
      	  	var filas = grilla.store._arrayOfAllItems.length;
      	  	var datoSel="";
      	  	var numSeleccionados=0;
      	  	for (i=0; i< filas;i++){
      	  		if (dojo.byId("puntoPartida.selDomicilioGrid" + i).checked == true){
      	  			numSeleccionados ++;
      	  			var fila = grilla.getItem(i);
      	  			var codigo = grilla.store.getValue(fila, "codigo");
      	  			var ubigeo = grilla.store.getValue(fila, "ubigeo");
      	  			var domicilio = grilla.store.getValue(fila, "domicilio");
      	  			var cod_estab = grilla.store.getValue(fila, "cod_estab");
      	  			dojo.byId("global.opcionPuntoPartidaDireccion").value = domicilio;
      	  			dojo.byId("puntoPartida.domicilio").value = domicilio;
      	  			dojo.byId("puntoPartida.codigo").value = codigo;
      	  			dojo.byId("puntoPartida.coddist").value = ubigeo;
      	  			dojo.byId("puntoPartida.cod_estab").value = cod_estab;
      	  			break;
      	  		}
      	  	}
      	  	if (numSeleccionados==0){
      	  		mostrarMensaje( "Debe seleccionar un establecimiento.");
      	  		return;
      	  	}
    	}else if (tipoDireccion ==3 ){
          	if (dojo.byId("puntoPartida.coddist").value =="" ||  dojo.byId("puntoPartida.coddist").value =="000000"){
          		mostrarMensaje("Debe seleccionar departamento, provincia y distrito.");
          		return;
            } else if (dijit.byId("puntoPartida.nomvia").getValue()=="" && dijit.byId("puntoPartida.nomzon").getValue()=="" ){
                mostrarMensaje("Debe ingresar al menos uno de los campos marcados con asterisco (*).");
                return;
            } else if (dijit.byId("puntoPartida.nomvia").getValue()!="" && (dijit.byId("puntoPartida.tipvia").getValue()==""  || dijit.byId("puntoPartida.tipvia").getValue()=="11") ){
                mostrarMensaje("Debe ingresar el tipo de via.");
                return;
            } else if (dijit.byId("puntoPartida.nomzon").getValue()!="" && (dijit.byId("puntoPartida.tipzon").getValue()==""  || dijit.byId("puntoPartida.tipzon").getValue()=="11") ){
                mostrarMensaje("Debe ingresar al tipo de zona.");
                return;
            } else if (dijit.byId("puntoPartida.km").getValue()=="" && dijit.byId("puntoPartida.mz").getValue()=="" && dijit.byId("puntoPartida.lote").getValue()=="" && dijit.byId("puntoPartida.dep").getValue()=="" && dijit.byId("puntoPartida.int").getValue()==""){
            	mostrarMensaje("Debe ingresar al menos el kil\u00F3metro, manzana, lote, departamento o interior.");
            	return;
          	}
        	var domicilio="";
            if (dijit.byId("puntoPartida.nomvia").getValue()!="" ) {
                domicilio=dijit.byId("puntoPartida.tipvia").getDisplayedValue().substring(0,4) + " " + dijit.byId("puntoPartida.nomvia").getValue() + " " + dijit.byId("puntoPartida.num").getValue();
            }
            if (dijit.byId("puntoPartida.nomzon").getValue()!="" ) {
                domicilio= domicilio + " " + dijit.byId("puntoPartida.tipzon").getDisplayedValue().substring(0,4) + " " + dijit.byId("puntoPartida.nomzon").getValue() ;
            }
            if (dijit.byId("puntoPartida.mz").getValue()!="" ) {
                domicilio= domicilio + " MZA. " + dijit.byId("puntoPartida.mz").getValue() ;
            }
            if (dijit.byId("puntoPartida.lote").getValue()!="" ) {
                domicilio= domicilio + " LOTE. " + dijit.byId("puntoPartida.lote").getValue() ;
            }
            if (dijit.byId("puntoPartida.dep").getValue()!="" ) {
                domicilio= domicilio + " DPTO. " + dijit.byId("puntoPartida.dep").getValue() ;
            }
            if (dijit.byId("puntoPartida.int").getValue()!="" ) {
                domicilio= domicilio + " INT. " + dijit.byId("puntoPartida.int").getValue() ;
            }
            if (dijit.byId("puntoPartida.km").getValue()!="" ) {
                domicilio= domicilio + " KM. " + dijit.byId("puntoPartida.km").getValue() ;
            }
            if (dijit.byId("puntoPartida.refer").getValue()!="" ) {
                domicilio= domicilio + " " + dijit.byId("puntoPartida.refer").getValue() ;
            }
            domicilio=domicilio + (" ") + dijit.byId("puntoPartida.emisorDpto").getDisplayedValue() + "-" +
            dijit.byId("puntoPartida.emisorProv").getDisplayedValue() + "-" +
            dijit.byId("puntoPartida.emisorDist").getDisplayedValue();

          	dojo.byId("global.opcionPuntoPartidaDireccion").value = domicilio;
          	dojo.byId("puntoPartida.domicilio").value = domicilio;
          	dojo.byId("puntoPartida.cod_estab").value = "0";
    	}

		this.wait("Procesando", "95px", 200);

		var handler = dojo.io.iframe.send({
			url: this.controller + "?action=datosPuntoPartida&subTipoEpuntoPartida=" + dojo.byId("puntoPartida.subTipoEpuntoPartida").value + "&codigo=" + dojo.byId("puntoPartida.codigo").value + "&coddist=" + dojo.byId("puntoPartida.coddist").value + "&domicilio=" + dojo.byId("puntoPartida.domicilio").value + "&cod_estab=" + dojo.byId("puntoPartida.cod_estab").value + "&num_ruc_domicilio=" + dojo.byId("puntoPartida.num_ruc_domicilio").value + "&refer=" + dojo.byId("puntoPartida.refer").value + "&tipvia=" + dijit.byId("puntoPartida.tipvia").get('value') + "&tipzon=" + dijit.byId('puntoPartida.tipzon').get('value') + "&num=" + dojo.byId("puntoPartida.num").value + "&mz=" + dojo.byId("puntoPartida.mz").value + "&lote=" + dojo.byId("puntoPartida.lote").value + "&dep=" + dojo.byId("puntoPartida.dep").value + "&int=" + dojo.byId("puntoPartida.int").value + "&km=" + dojo.byId("puntoPartida.km").value + "&nomzon=" + dojo.byId("puntoPartida.nomzon").value + "&nomvia=" + dojo.byId("puntoPartida.nomvia").value,
			handleAs: "json",
			sync: true,
			timeout: 10000,
			preventCache: true
		});

		handler.addCallback(dojo.hitch(this, function(res){
			this.waitMessage.hide();
			if(res.codeError == 0) {
				dijit.byId("trasladoBienes.puntoPartidaDesc").set("value",dojo.byId("global.opcionPuntoPartidaDireccion").value);
				this.dialogPuntoPartida.hide();
			} else {
				mostrarMensaje(res.messageError);
				nbControl.attr('disabled', false);
			}
		}));

		handler.addErrback(function(res){
			nbControl.attr('disabled', false);
			this.waitMessage.hide();
			mostrarMensaje("Problemas al conectarse con el servidor");
		});
	},

	acceptPuntoLlegada: function() {
		//if(!dijit.byId("puntoLlegada.form").validate()) return;

    	var tipoDireccion = this.getValorOpcionTipoDireccPLL ();
    	dojo.byId("global.opcionPuntoLlegadaIdentifica").value = tipoDireccion;
    	if (tipoDireccion == null || tipoDireccion=="" ){
    		mostrarMensaje("Debe seleccionar el tipo de direcci\u00F3n del punto de llegada.");
    		return;
    	}

    	dojo.byId("puntoLlegada.num_ruc_domicilio").value = dojo.byId("global.numRucEmisor").value;
    	if (tipoDireccion ==1 || tipoDireccion ==2){
    		if (tipoDireccion == 1){
    			dojo.byId("puntoLlegada.num_ruc_domicilio").value = dojo.byId("global.numeroDocumento").value;
    		}else{
    			if (tipoDireccion ==2){
    				var ruc3ro =dijit.byId("puntoLlegada.txt_ruc_tercero").getValue();
    				if (ruc3ro==""){
    					mostrarMensaje("Debe ingresar un n\u00FAmero de RUC v\u00E1lido.");
              	      	return;
    				}
    				if (ruc3ro.length != 11){
    					mostrarMensaje("Numero de RUC inv\u00E1lido");
                        return;
    				}

    				if (!this.isValidRuc(ruc3ro)){
    					mostrarMensaje("Numero de RUC inv\u00E1lido");
                        return;
    				}

    				dojo.byId("puntoLlegada.num_ruc_domicilio").value = ruc3ro;
    			}
            }
      	  	var grilla =dijit.byId("puntoLlegada.domiciliosGrid");
      	  	var datos =grilla.store._arrayOfAllItems;
      	  	var filas = grilla.store._arrayOfAllItems.length;
      	  	var datoSel="";
      	  	var numSeleccionados=0;
      	  	for (i=0; i< filas;i++){
      	  		if (dojo.byId("puntoLlegada.selDomicilioGrid" + i).checked == true){
      	  			numSeleccionados ++;
      	  			var fila = grilla.getItem(i);
      	  			var codigo = grilla.store.getValue(fila, "codigo");
      	  			var ubigeo = grilla.store.getValue(fila, "ubigeo");
      	  			var domicilio = grilla.store.getValue(fila, "domicilio");
      	  			var cod_estab = grilla.store.getValue(fila, "cod_estab");
      	  			dojo.byId("global.opcionPuntoLlegadaDireccion").value = domicilio;
      	  			dojo.byId("puntoLlegada.domicilio").value = domicilio;
      	  			dojo.byId("puntoLlegada.codigo").value = codigo;
      	  			dojo.byId("puntoLlegada.coddist").value = ubigeo;
      	  			dojo.byId("puntoLlegada.cod_estab").value = cod_estab;
      	  			break;
      	  		}
      	  	}
      	  	if (numSeleccionados==0){
      	  		mostrarMensaje( "Debe seleccionar un establecimiento.");
      	  		return;
      	  	}
    		} else if (tipoDireccion ==3 ){
    			if (dojo.byId("puntoLlegada.coddist").value ==""){
    			mostrarMensaje("Debe seleccionar departamento, provincia y distrito.");
          	   	return;
            } else if (dijit.byId("puntoLlegada.nomvia").getValue()=="" && dijit.byId("puntoLlegada.nomzon").getValue()=="" ){
                mostrarMensaje("Debe ingresar al menos uno de los campos marcados con asterisco (*).");
                return;
            } else if (dijit.byId("puntoLlegada.nomvia").getValue()!="" && (dijit.byId("puntoLlegada.tipvia").getValue()==""  || dijit.byId("puntoLlegada.tipvia").getValue()=="11") ){
                mostrarMensaje("Debe ingresar el tipo de via.");
                return;
            } else if (dijit.byId("puntoLlegada.nomzon").getValue()!="" && (dijit.byId("puntoLlegada.tipzon").getValue()==""  || dijit.byId("puntoLlegada.tipzon").getValue()=="11") ){
                mostrarMensaje("Debe ingresar al tipo de zona.");
                return;
            } else if (dijit.byId("puntoLlegada.km").getValue()=="" && dijit.byId("puntoLlegada.mz").getValue()=="" && dijit.byId("puntoLlegada.lote").getValue()=="" && dijit.byId("puntoLlegada.dep").getValue()=="" && dijit.byId("puntoLlegada.int").getValue()==""){
            	mostrarMensaje("Debe ingresar al menos el kil\u00F3metro, manzana, lote, departamento o interior.");
            	return;
          	}
        	var domicilio="";
            if (dijit.byId("puntoLlegada.nomvia").getValue()!="" ) {
                domicilio=dijit.byId("puntoLlegada.tipvia").getDisplayedValue().substring(0,4) + " " + dijit.byId("puntoLlegada.nomvia").getValue() + " " + dijit.byId("puntoLlegada.num").getValue();
            }
            if (dijit.byId("puntoLlegada.nomzon").getValue()!="" ) {
                domicilio= domicilio + " " + dijit.byId("puntoLlegada.tipzon").getDisplayedValue().substring(0,4) + " " + dijit.byId("puntoLlegada.nomzon").getValue() ;
            }
            if (dijit.byId("puntoLlegada.mz").getValue()!="" ) {
                domicilio= domicilio + " MZA. " + dijit.byId("puntoLlegada.mz").getValue() ;
            }
            if (dijit.byId("puntoLlegada.lote").getValue()!="" ) {
                domicilio= domicilio + " LOTE. " + dijit.byId("puntoLlegada.lote").getValue() ;
            }
            if (dijit.byId("puntoLlegada.dep").getValue()!="" ) {
                domicilio= domicilio + " DPTO. " + dijit.byId("puntoLlegada.dep").getValue() ;
            }
            if (dijit.byId("puntoLlegada.int").getValue()!="" ) {
                domicilio= domicilio + " INT. " + dijit.byId("puntoLlegada.int").getValue() ;
            }
            if (dijit.byId("puntoLlegada.km").getValue()!="" ) {
                domicilio= domicilio + " KM. " + dijit.byId("puntoLlegada.km").getValue() ;
            }
            if (dijit.byId("puntoLlegada.refer").getValue()!="" ) {
                domicilio= domicilio + " " + dijit.byId("puntoLlegada.refer").getValue() ;
            }

            domicilio=domicilio + (" ") + dijit.byId("puntoLlegada.emisorDpto").getDisplayedValue() + "-" +
            dijit.byId("puntoLlegada.emisorProv").getDisplayedValue() + "-" +
            dijit.byId("puntoLlegada.emisorDist").getDisplayedValue();

          	dojo.byId("global.opcionPuntoLlegadaDireccion").value = domicilio;
          	dojo.byId("puntoLlegada.domicilio").value = domicilio;
          	dojo.byId("puntoLlegada.cod_estab").value = "0";
    	}

		this.wait("Procesando", "95px", 200);

		var handler = dojo.io.iframe.send({
			url: this.controller + "?action=datosPuntoLlegada&subTipoEpuntoLlegada=" + dojo.byId("puntoLlegada.subTipoEpuntoLlegada").value + "&codigo=" + dojo.byId("puntoLlegada.codigo").value + "&coddist=" + dojo.byId("puntoLlegada.coddist").value + "&domicilio=" + dojo.byId("puntoLlegada.domicilio").value + "&cod_estab=" + dojo.byId("puntoLlegada.cod_estab").value + "&num_ruc_domicilio=" + dojo.byId("puntoLlegada.num_ruc_domicilio").value + "&refer=" + dojo.byId("puntoLlegada.refer").value + "&tipvia=" + dijit.byId("puntoLlegada.tipvia").get('value') + "&tipzon=" + dijit.byId('puntoLlegada.tipzon').get('value') + "&num=" + dojo.byId("puntoLlegada.num").value + "&mz=" + dojo.byId("puntoPartida.mz").value + "&lote=" + dojo.byId("puntoLlegada.lote").value + "&dep=" + dojo.byId("puntoLlegada.dep").value + "&int=" + dojo.byId("puntoLlegada.int").value + "&km=" + dojo.byId("puntoLlegada.km").value + "&nomzon=" + dojo.byId("puntoLlegada.nomzon").value + "&nomvia=" + dojo.byId("puntoLlegada.nomvia").value,
			handleAs: "json",
			sync: true,
			timeout: 10000,
			preventCache: true
		});

		handler.addCallback(dojo.hitch(this, function(res){
			this.waitMessage.hide();
			if(res.codeError == 0) {
				dijit.byId("trasladoBienes.puntoLlegadaDesc").set("value",dojo.byId("global.opcionPuntoLlegadaDireccion").value);
				this.dialogPuntoLlegada.hide();
			}
			else {
				mostrarMensaje(res.messageError);
				nbControl.attr('disabled', false);
			}
		}));

		handler.addErrback(function(res){
			nbControl.attr('disabled', false);
			this.waitMessage.hide();
			mostrarMensaje("Problemas al conectarse con el servidor");
		});
	},

	closePuntoPartida: function() {
		this.dialogPuntoPartida.hide();
	},

	closePuntoLlegada: function() {
		this.dialogPuntoLlegada.hide();
	},

	closeTrasladoBienes	: function() {
		if (this.getValorOpcionSujetoRealizaTraslado() ==""){
			mostrarMensaje("Debe seleccionar el sujeto que realizar\u00E1 el traslado.")
	        return;
		}

        if(dijit.byId("trasladoBienes.puntoPartidaDesc").getValue()=="" ){
        	mostrarMensaje("Debe registrar el Punto de Partida.");
        	return;
        }

        if(dijit.byId("trasladoBienes.puntoLlegadaDesc").getValue()=="" ){
        	mostrarMensaje("Debe registrar el Punto de Llegada.");
        	return;
        }

	    if (this.getValorOpcionModalidadTraslado() ==""){
	    	mostrarMensaje("Debe seleccionar la modalidad del traslado.")
	    	return;
	    }

	    if (this.getValorOpcionSujetoRealizaTraslado() =="1"){
	    	if (this.getValorOpcionModalidadTraslado() =="1"){
	    		if(dijit.byId("trasladoBienes.placaVehiculo").getValue()==""){
	    			mostrarMensaje("Debe registrar la placa del Vehiculo");
	    			return;
	    		}

	    		if(dijit.byId("trasladoBienes.marcaVehiculo").getValue()==""){
	    			mostrarMensaje("Debe registrar la marca del Vehiculo");
	    			return;
	    		}

	    		/*
              	if(dijit.byId("trasladoBienes.nroLicenciaConducir").getValue()==""){
                  	mostrarMensaje("Debe registrar el numero de licencia de conducir del conductor.");
                  	return;
              	}
	    		*/
	    		if(this.licenciaStore == null || dijit.byId("licencias-grid").rowCount== 0 )  {
	    			mostrarMensaje("Debe registrar el numero de licencia de conducir del conductor.");
	    			return;
	    		}
	    	}else{
	    		if(dijit.byId("trasladoBienes.rucTransportista").getValue()=="" || dijit.byId("trasladoBienes.razonSocial").getValue()=="" ){
	    			mostrarMensaje("Debe registrar el numero de RUC del transportista.");
	    			return;
	    		}
	    	}
	    }

		var nbControl = dijit.byId("trasladoBienes.botonAceptar");
		nbControl.setAttribute('disabled', true);
		this.wait("Procesando", "110px", 200);

		var handler = dojo.io.iframe.send({
			url: this.controller,
			handleAs: "json",
			sync: true,
			timeout: 10000,
			preventCache: true,
			form: "trasladoBienes.form"
		});

		handler.addCallback(dojo.hitch(this, function(res){
			nbControl.setAttribute('disabled', false);
			this.waitMessage.hide();
			if (res.codeError == 0) {
				this.dialogInfTrasladoBienes.hide();
			} else {
				mostrarMensaje(res.messageError);
			}
		}));

		handler.addErrback(function(res){
			nbControl.setAttribute('disabled', false);
			this.waitMessage.hide();
			mostrarMensaje("Problemas al conectarse con el servidor");
		});
	},

/*	showMoreInfo: function() {
		var ndControl = dijit.byId("factura.numeroDocumento");
		if(!this.isValidRuc(ndControl.getValue())) {
			ndControl.warnTooltipMessage("N&uacute;mero de RUC incorrecto");
			ndControl.setValue("");
			ndControl.focus();
			return;
		}

		this.wait("Consultando", "110px", 100);
		var handler = dojo.xhrGet({
			url: this.controller + "?action=consultaPorRuc&ruc=" + ndControl.getValue(),
			handleAs: "json",
			sync: true,
			timeout: 10000
		});
		handler.addCallback(dojo.hitch(this, function(res){
			this.waitMessage.hide();
			if(res.codeError == 0) {
				var row = eval("(" + res.data + ")");
				dojo.byId("vermas.ddp_numruc").innerHTML = row.ddp_numruc;
				dojo.byId("vermas.ddp_nombre").innerHTML = row.ddp_nombre;
				dojo.byId("vermas.ddp_comercial").innerHTML = row.ddp_nombre;
				dojo.byId("vermas.ddp_tpoemp_desc").innerHTML = row.ddp_tpoemp_desc;
				dojo.byId("vermas.ddp_fecalt").innerHTML = row.ddp_fecalt;
				dojo.byId("vermas.ddp_fecact").innerHTML = row.ddp_fecact;
				dojo.byId("vermas.ddp_estado_desc").innerHTML = row.ddp_estado_desc;
				dojo.byId("vermas.ddp_flag22_desc").innerHTML = row.ddp_flag22_desc;
				dojo.byId("vermas.direccion_desc").innerHTML = row.direccion_desc;
				this.dialogMoreInfo.show();
			}
			else this.messageBox(res.messageError);
		}));
		handler.addErrback(dojo.hitch(this, function(res) {
			this.waitMessage.hide();
			this.messageBox("Problemas al conectarse al servidor");
		}));
	},*/

	closeMoreInfo: function() {
		this.dialogMoreInfo.hide();
	},

	printDocument: function() {
		window.open(this.controller + "?action=imprimirComprobante&preventCache=" + this.preventCache(), "imprimeCP" , "toolbar=0,location=0,directories=0,status=no,menubar=0,scrollbars=yes,resizable=yes,width=820,height=580,titlebar=no");
	},

	mostrarTaxFree: function(id) {
		mostrarMensaje("La constancia de TAX FREE tambi\u00E9n puede ser descargada desde la opci\u00F3n Consultas/FE Emitidas desde SOL");
		var formPDF = dojo.byId("formPDF");
		formPDF.submit();
		//window.open(this.controller + "?action=mostrarTaxFree&preventCache=" + this.preventCache(), "imprimeTaxFree" , "toolbar=0,location=0,directories=0,status=no,menubar=0,scrollbars=yes,resizable=yes,width=820,height=580,titlebar=no");
		//window.open("http://192.168.46.20:8080/cl-at-framework-unloadfile/descargaArchivoAlias?data0_sis_id=1000&data0_num_id=" + id, "imprimeTaxFree" , "toolbar=0,location=0,directories=0,status=no,menubar=0,scrollbars=yes,resizable=yes,width=820,height=580,titlebar=no");
	},

	downloadDocument: function() {
		var formArchivo = dojo.byId("formArchivo");
		formArchivo.submit();
	},

	// PAS20211U210100010  --- Inicio
	downloadPDF: function() {
		var formPdf = dojo.byId("formDownloadpdf");
		formPdf.submit();
	},
	// PAS20211U210100010  --- Fin

	evalTypeDocument: function() {
		var ndControl = dijit.byId("factura.numeroDocumento");
		ndControl.invalidateCancel();
		var td = dijit.byId("factura.tipoDocumento").getValue();
		if(td == '06' || td == '6' || td == '1') {
			ndControl.attr('disabled', false);
			this.setReadOnly("factura.razonSocial", true);
			ndControl.focus();
		}
		else {
			var rsControl = dijit.byId("factura.razonSocial");
			this.setReadOnly(rsControl, false);
			if(td == '-') {
				ndControl.attr('disabled', true);
				ndControl.setValue("");
				rsControl.focus();
			} else {
				ndControl.attr('disabled', false);
				ndControl.focus();
			}
		}
		this.validateDocument();
	},

	updateUnFormat: function() {
		var moneda = dojo.byId("global.tipoMoneda").value;
		var valor = dijit.byId("item.cantidad").getValue();
		//
		dijit.byId("item.cantidad").setValue(dojo.currency.format(valor, {currency: moneda, places: '2,10'}));
	},

	checkValorXDcto: function() {
		var cantidadXPrecio = 0;
		var precioDescuento = 0;
		var totalConDescuento = 0;

		cantidadXPrecio = dijit.byId("item.cantidad").getValue() * dijit.byId("item.precioUnitario").getValue();
		precioDescuento = dijit.byId("item.precioDescuento").getValue();
		totalConDescuento = cantidadXPrecio - precioDescuento;

		if (totalConDescuento < 0 ){
			mostrarMensaje("Descuento no puede ser mayor a la Cantidad por el Valor Unitario.")
			dijit.byId("item.precioDescuento").setValue(0);
			dijit.byId("item.precioDescuento").focus();
			return;
		} else {
			this.updateItemAmount();
		}
	},
	updateItemAmount: function() {
		var cantidad=0;
		var igvPorcentaje = 0;
		var cantidadXPrecio = 0;
		var precioDescuento = 0;
		var totalConDescuento = 0;
		var iscMonto = 0;
		var igvMonto = 0;
		var otroMonto = 0;
		var otroTributo = 0;
		var totalItem = 0;
		var impuestoICBPER = 0;
		var tasaBolsa = 0;

		// Inicio PAS20211U210100007-jmendozas
		// if(isNaN(dijit.byId("item.precioUnitario").getValue()) || dijit.byId("item.precioUnitario").getValue()===undefined){
		// 	var precioUnitario = dijit.byId("item.precioUnitario").getDisplayedValue();
		// 	console.log(dijit.byId("item.precioUnitario"));
		// 	console.log("precio unitario x:",precioUnitario);
		// 	if(isNaN(precioUnitario) || precioUnitario.trim() == ""){
		// 		console.warn("1..............",precioUnitario);
		// 		precioUnitario =0.00;
		// 	}else if(precioUnitario){
		// 		console.warn("2..............",precioUnitario);
		// 		precioUnitario = parseFloat(precioUnitario).toFixed(2);
		// 	}
		// 	console.warn("3..............",precioUnitario);
		// 	dijit.byId("item.precioUnitario").validate();
		// 	dijit.byId("item.precioUnitario").set("displayedValue", precioUnitario);
		// }
        // Fin PAS20211U210100007

		igvPorcentaje = dojo.byId("item.igvPorcentaje").value;

		var moneda = dojo.byId("global.tipoMoneda").value;
		var tipoItem = this.getValorOpcionTipoItem();

		//PAS20191U210100075
		var valOpcionImpuestoBolsaPlastica = this.getValorOpcionImpuestoBolsaPlastica();
		if (valOpcionImpuestoBolsaPlastica != "IBP00"){ //NO > IMPUESTO BOLSAS;
			dijit.byId("item.cantidad").constraints = {min:0.0000000001, places:'2,10',pattern:'########.00########'};
			dijit.byId("item.cantidad").attr('value',dijit.byId("item.cantidad").getValue());
            // Fin PAS20211U210100007
		}else{ // SI IMPUESTO BOLSAS
			dijit.byId("item.cantidad").attr('value',dojo.number.format(Math.floor(dijit.byId("item.cantidad").getValue()),{places:0} ));
		}
		//PAS20191U210100075
		if (dojo.byId("item.valOpcTipoCTItem").value!="0" && dojo.byId("item.valOpcTipoCTItem").value!=""){
			cantidad=1.00;
		} else {
			if (this.getValorOpcionAnticipo()=="1"){
				cantidad=1.00;
			}else{
				cantidad=dijit.byId("item.cantidad").getValue();
			}
		}


        // Inicio PAS20211U210100007-jmendozas
		console.log("1.cantidad:" , cantidad);
		console.log("2.precioUnitario:" , dijit.byId("item.precioUnitario").getValue());
		//PAS20211U210100007-JMENDOZAS
		cantidadXPrecio = (cantidad * dijit.byId("item.precioUnitario").getValue());///.toFixed(10);
		//cantidadXPrecio = this.round(cantidadXPrecio, 10);//PAS20211U210100007
		console.log("3.cantidadXPrecio:",cantidadXPrecio);
		precioDescuento = dijit.byId("item.precioDescuento").getValue();
		console.log("4.precioDescuento:" , precioDescuento);
        // Fin PAS20211U210100007
		if(!isNaN(precioDescuento)){
			totalConDescuento = cantidadXPrecio - precioDescuento;
            // Inicio PAS20211U210100007-jmendozas
			console.log("5.totalConDescuento:" , totalConDescuento);
			console.log("5.1.precioDescuento:" , precioDescuento , typeof  precioDescuento);
            // Fin PAS20211U210100007
		} else {
			precioDescuento=0;
		}
        // Inicio PAS20211U210100007-jmendozas
		iscMonto = dijit.byId("item.iscMonto").getValue();
		// Fin PAS20211U210100007

		/* Inicio PAS20211U210100007 */
		igvMonto = ((totalConDescuento + iscMonto) * igvPorcentaje);
		igvMonto = (this.round(igvMonto * 100, 10)/100);
		igvMonto = parseFloat(igvMonto).toFixed(10);
		console.log("igvMonto ---> " + igvMonto);
        /* Fin PAS20211U210100007 */

        /*Inicio WHR – INC 2015-037104*/
		//igvMonto = Math.round(igvMonto * 100) / 100;//PAS20211U210100007
		//igvMonto = this.round(igvMonto, 10);//PAS20211U210100007
		console.log('6.igvMonto:',igvMonto , typeof igvMonto);
		/*Fin WHR – INC 2015-037104*/
		//IMPORTE DE VENTA=((VALOR UNITARIO)*CANTIDAD)-(DESCUENTOS)+(IGV)+(ISC MONTO)+(OTROS CARGOS)

		console.log('7.iscMonto:',iscMonto , typeof iscMonto);
		console.log('8.igvPorcentaje:',igvPorcentaje , typeof igvPorcentaje );

		console.log('9.0.totalItem:',((totalConDescuento + iscMonto)+dojo.number.parse(igvMonto)).toFixed(10));
		totalItem = ((totalConDescuento + iscMonto) + dojo.number.parse(igvMonto)).toFixed(10); // + otroMonto + otroTributo;
		console.log('9.1.totalItem:',totalItem , typeof totalItem);//PAS20211U210100007-JMENDOZAS
		//totalItem = this.round(totalItem, 10);//PAS20211U210100007
		//console.log('9.1.totalItem round 10:',totalItem);
		dijit.byId("item.precioUnitario").attr('value',dojo.currency.format(dijit.byId("item.precioUnitario").getValue(), {currency: moneda, places: '2,10'}));

		dijit.byId("item.precioDescuento").attr('value',dojo.currency.format(precioDescuento, {currency: moneda, places: 2}));
		//dijit.byId("item.precioConIGV").attr('value',dojo.currency.format(igvMonto, {currency: moneda, places: 2}));PAS20211U210100007
		// dijit.byId("item.precioConIGV").attr('value',dojo.currency.format(igvMonto, {currency: moneda, places: '2,10'}));//PAS20211U210100007
		this.roundTenDecimalAux("item.precioConIGV",this.removeZeros(igvMonto),moneda);// Inicio PAS20211U210100007-jmendozas

		dijit.byId("item.iscMonto").attr('value',dojo.currency.format(iscMonto, {currency: moneda, places: 2}), false);

		// Impuesto Bolsas Plasticas - INI: PAS20191U210100075
		monedades = dojo.byId("global.tipoMonedaDesc").value;
		if(monedades != "SOLES"){
			impuestoICBPER = dijit.byId("item.impuestoICBPER").getValue();
			//dijit.byId("item.tasaBolsa").attr('value',dojo.currency.format(0, {currency: moneda, places: 2}), false);
			dijit.byId("item.impuestoICBPER").constraints = {currency:moneda, places:2};
			dijit.byId("item.impuestoICBPER").attr('value',impuestoICBPER);
			dijit.byId("item.tasaBolsa").attr('value',dojo.currency.format("0", {currency: moneda, places: 2}));
			dojo.byId("item.tasaBolsaGlobal").value="0";
		}else{
			dijit.byId("item.impuestoICBPER").attr('disabled',true);
			tasaBolsa = dojo.byId("item.tasaBolsaGlobal").value;//document.getElementById("item.tasaBolsaGlobal").value;
			dijit.byId("item.tasaBolsa").attr('value',dojo.currency.format(tasaBolsa, {currency: moneda, places: 2}));
			impuestoICBPER = cantidad * tasaBolsa;
			impuestoICBPER = this.round(impuestoICBPER, 2);
			//dijit.byId("item.impuestoICBPER").attr('value',dojo.currency.format(impuestoICBPER, {currency: moneda, places: 2}));
			dijit.byId("item.impuestoICBPER").constraints = {currency:moneda, places:2};
			dijit.byId("item.impuestoICBPER").attr('value',impuestoICBPER);
		}

		//console.log('10.impuestoICBPER:',impuestoICBPER);// Inicio PAS20211U210100007-jmendozas
		//console.log('9.2.totalItem round 10:',totalItem);// Inicio PAS20211U210100007-jmendozas
		//totalItem  = (dojo.number.parse(totalItem) + impuestoICBPER).toFixed(10);// Inicio PAS20211U210100007-jmendozas
		//console.log('9.3.totalItem round 10:',totalItem , typeof totalItem);// Inicio PAS20211U210100007-jmendozas


		// INICIO PAS20201U210100285 - jmendozas
		var valorMontoRedondeo = 0.00;
		if(dojo.byId("item.montoRedondeoAux") != null){ /* PAS20201U210100285 - Factura Contingencia */
			if(dojo.byId("item.montoRedondeoAux") != undefined){
				/* PAS20201U210100285 - Inicio Validación de Anticipos */
				if (dijit.byId("item.facturaAnticipoSerie").getValue() != "" && dijit.byId("item.facturaAnticipoSerie").getValue() != ""){
					valorMontoRedondeo = dojo.number.parse(dojo.byId("item.montoRedondeoAux").value);
				}
				/* PAS20201U210100285 - Fin Validación de Anticipos */
			}
		}
		// FIN PAS20201U210100285
		console.log("9.2.valorMontoRedondeo :" , valorMontoRedondeo , typeof valorMontoRedondeo);//PAS20211U210100007-JMENDOZAS
		console.log("9.3.impuestoICBPER :" , impuestoICBPER , typeof impuestoICBPER);//PAS20211U210100007-JMENDOZAS
		totalItem  = dojo.number.parse(totalItem) + valorMontoRedondeo +impuestoICBPER ;

		// Impuesto Bolsas Plasticas - FIN: PAS20191U210100075
		var valTipoBonif = this.getValorOpcionTipoBonif();
		console.log('10.valTipoBonif:',valTipoBonif);// Inicio PAS20211U210100007-jmendozas
		if (valTipoBonif == "BO01" ) { //dojo.byId("global.opcionExportacion").value == "1" ||
			//dijit.byId("item.importeVenta").attr('value',dojo.currency.format(totalItem, {currency: moneda, places: 2}));PAS20211U210100007
			console.log("11.item.importeVenta = " , totalItem   );
			dijit.byId("item.importeVenta").attr('value',dojo.currency.format(totalItem, {currency: moneda, places: '2,10'}));//PAS20211U210100007
			//this.roundTenDecimalAux("item.importeVenta",totalItem,moneda);
			//this.roundTenDecimalAux("item.importeVenta",this.removeZeros(totalItem),moneda);// Inicio PAS20211U210100007-jmendozas
		} else {
			//this.roundTenDecimalAux("item.importeVenta",totalItem,moneda);
			console.log("11.item.importeVenta = " , totalItem   );
			dijit.byId("item.importeVenta").attr('value',dojo.currency.format(totalItem, {currency: moneda, places: '2,10'}));
			//dijit.byId("item.importeVenta").attr('value',dojo.currency.format(0, {currency: moneda, places: '2,10'}));//PAS20211U210100007
			//this.roundTenDecimalAux("item.importeVenta",this.removeZeros(totalItem),moneda);// Inicio PAS20211U210100007-jmendozas
		}
	},
        // Inicio PAS20211U210100007-jmendozas
		removeZeros:function(number){
			if(isNaN(number)){
				return;
			}
			var allowDecimals = 10;
			for(var i=-8;i<=-1;i++){
				var zerosString = "";
				for(var j=1;j<=Math.abs(i);j++){
					zerosString=zerosString+"0";
				}
				if (number.substr(i) == zerosString){
					number = parseFloat(number).toFixed(allowDecimals-Math.abs(i));
					return number;
					break;
				}
			}
			number = parseFloat(number).toFixed(10);
			return number;
		},
		roundTenDecimalAux:function (id,value,tipoMoneda){
			var moneyAux = 	dojo.currency.format(0.00, {currency: tipoMoneda});
			moneyAux = moneyAux.replace("0.00",value) ;
			dijit.byId(id).setValue(moneyAux);
		}, // Fin PAS20211U210100007
	round : function(num, decimals) {
		var n = Math.pow(10, decimals);
        return Math.round( (n * num).toFixed(decimals) )  / n;
	},

	updateTotalAmount: function() {
		var totalDescuentos = 0;
		var totalAnticipos = 0;
		var totalISC = 0;
		var totalIGV = 0;
		var totalOtrosCargos = 0;
		var totalOtrosTributos = 0;
		var subTotalVenta = 0;
		var totalGeneral = 0;
		var valorVenta = 0;
		var totalCBPER=0;
		var totalItems = this.getTotalItemsEnGrid();
		var itemMontoRedondeo = 0;// PAS20201U210100285 - jmendozas
		if (totalItems > 0) {
			var array = dijit.byId("factura.ingreso-grid").store._arrayOfTopLevelItems;
			console.log("--------------------");
			console.log(array);
			for(var i = 0; i < array.length; i++){
				//BO00 = Operacion No gratuita
				//BO01 = Operacion Gratuita

				if (array[i].tipoBonificacion == "BO01"){   // Es Operacion gratuita
    				/*if (array[i].tipoOtrosCargosTributos == "1") {
    			     	totalGeneral += dojo.number.parse(array[i].otrosCargos);
            }
    				if (array[i].tipoOtrosCargosTributos == "2") {
    			     	totalGeneral +=  dojo.number.parse(array[i].otrosTributos);
            }  	*/
				}

				if (array[i].tipoBonificacion == "BO00"){   //No es operacion Gratuita
					if (array[i].tipoOtrosCargosTributos == "1") {
						totalOtrosCargos += dojo.number.parse(array[i].otrosCargos);
					}
    				if (array[i].tipoOtrosCargosTributos == "2") {
    					totalOtrosTributos += dojo.number.parse(array[i].otrosTributos);
    				}

  				  	if(array[i].tipoOtrosCargosTributos == "0") {
  				  		if (array[i].anticipo == "1"){
  				  			totalAnticipos+= dojo.number.parse(array[i].valorVenta);
  				  		}else{
  				  			subTotalVenta += dojo.number.parse(array[i].valorVenta);
  				  		}
  				  		totalDescuentos += dojo.number.parse(array[i].descuentoMonto);
  				  	}
  				  	totalISC += dojo.number.parse(array[i].iscMonto);
    				totalIGV += dojo.number.parse(array[i].igvMonto);

    				if (array[i].tipoOtrosCargosTributos == "1") {
    					totalGeneral += dojo.number.parse(array[i].otrosCargos);
    				}
    				if (array[i].tipoOtrosCargosTributos == "2") {
    					totalGeneral +=  dojo.number.parse(array[i].otrosTributos);
    				}
    				if (array[i].tipoOtrosCargosTributos == "0") {
    					totalGeneral += dojo.number.parse(array[i].importeVenta);
    				}
				}
				// INICIO PAS20201U210100285 - jmendozas
				if(array[i].montoRedondeo!=undefined){
					itemMontoRedondeo += dojo.number.parse(array[i].montoRedondeo);
				}
				// FIN PAS20201U210100285 - jmendozas

				//PAS20191U210100075
				totalCBPER += dojo.number.parse(array[i].icbperMonto);
				//PAS20191U210100075

			}

			totalAnticipos =  dojo.number._formatAbsolute(totalAnticipos,"########.##########");
			//if (subTotalVenta<>0){ 	subTotalVenta = subTotalVenta + totalAnticipos;}
			valorVenta =  subTotalVenta - totalDescuentos - totalAnticipos;
			//totalGeneral = (valorVenta - totalDescuentos) + totalISC + totalIGV + totalOtrosCargos + totalOtrosTributos;
		}

		var moneda = dojo.byId("global.tipoMoneda").value;
		//PAS20201U210100285 - jmendozas
		var montoRedondeado = 0.00;
		if((dojo.byId("factura.montoRedondeo") != null)){ /* PAS20201U210100285 - Factura Contingencia */
			montoRedondeado = dijit.byId("factura.montoRedondeo").getValue();
		}
		//var montoRedondeado = dijit.byId("factura.montoRedondeo").getValue();
		//fin PAS20201U210100285
		totalGeneral = (valorVenta) + totalISC + totalIGV + totalOtrosCargos + totalOtrosTributos + totalCBPER;//WHR INC-xxxxxx
		//PAS20201U210100285 - jmendozas
		totalGeneral = totalGeneral + montoRedondeado;
		// if(totalGeneral<0){
		// 	totalGeneral = Math.abs(totalGeneral) + itemMontoRedondeo;
		// 	totalGeneral = totalGeneral*-1
		// }
		//fin PAS20201U210100285
		totalGeneral = Math.round(totalGeneral * 100) / 100; //WHR INC-xxxxxx
		dijit.byId("factura.subTotalVenta").setValue(dojo.currency.format(subTotalVenta, {currency: moneda, places: 2,pattern:"\u00A4 #,##0.00;\u00A4 -#,##0.00"}));
		dijit.byId("factura.totalAnticipos").setValue(dojo.currency.format(totalAnticipos, {currency: moneda,places: 2,pattern:"\u00A4 #,##0.00;\u00A4 -#,##0.00"}));
		dijit.byId("factura.totalDescuentos").setValue(dojo.currency.format(totalDescuentos, {currency: moneda,places: 2,pattern:"\u00A4 #,##0.00;\u00A4 -#,##0.00"}));
		dijit.byId("factura.totalValorVenta").setValue(dojo.currency.format(valorVenta, {currency: moneda, places: 2,pattern:"\u00A4 #,##0.00;\u00A4 -#,##0.00"}));
		dijit.byId("factura.totalISC").setValue(dojo.currency.format(totalISC, {currency: moneda, places: 2,pattern:"\u00A4 #,##0.00;\u00A4 -#,##0.00"}));
		dijit.byId("factura.totalIGV").setValue(dojo.currency.format(totalIGV, {currency: moneda, places: 2,pattern:"\u00A4 #,##0.00;\u00A4 -#,##0.00"}));
		dijit.byId("factura.totalOtrosCargos").setValue(dojo.currency.format(totalOtrosCargos, {currency: moneda, places: 2,pattern:"\u00A4 #,##0.00;\u00A4 -#,##0.00"}));
		dijit.byId("factura.totalOtrosTributos").setValue(dojo.currency.format(totalOtrosTributos, {currency: moneda, places: 2,pattern:"\u00A4 #,##0.00;\u00A4 -#,##0.00"}));

		//PAS20191U210100075
		//nrus = this.esNrus();
		//console.log(nrus);
		var totalICBPERinput = dijit.byId("factura.totalICBPERConting");


		if (totalICBPERinput != undefined){

			dijit.byId("factura.totalICBPERConting").setValue(dojo.currency.format(totalCBPER, {currency: moneda, places: 2,pattern:"\u00A4 #,##0.00;\u00A4 -#,##0.00"}));

		}
		//PAS20191U210100075
		dijit.byId("factura.totalGeneral").setValue(dojo.currency.format(totalGeneral, {currency: moneda, places: 2,pattern:"\u00A4 #,##0.00;\u00A4 -#,##0.00"}));
		//PAS20201U210100230  ini opv
		dojo.byId("global.importeTotal").value	=totalGeneral;
		//PAS20201U210100230  fin opv

	},
		// PAS20201U210100285 - jmendozas
	updateAmountRound: function() {
		console.log("...............................");
		var moneda = dojo.byId("global.tipoMoneda").value;
		if(dojo.byId("factura.montoRedondeo") != null){ /* PAS20201U210100285 - Factura Contingencia */
			var node = dijit.byId("factura.montoRedondeo");
			dijit.byId("factura.montoRedondeo").validate();
			if((!(isNaN(node.getValue()))) && (node.getValue() <= 0.09 && node.getValue() >= -0.09)){
				this.updateTotalAmount();
			} else if (isNaN(node.getValue())){
				var _node = "factura.montoRedondeo";
				var message = "El monto m&iacute;nimo es -0.09 y el m&aacute;ximo +0.09";
				var iconClass = "icon-warn-tooltip";
				if(dojo.isString(_node)) _node = dojo.byId(_node);
				dijit.showTooltip('<div class="' + iconClass + '"><div>' + message + '</div></div>', _node, []);
				dijit.byId("factura.montoRedondeo").validate();
				dijit.byId("factura.montoRedondeo").set("displayedValue", 0.00);
				this.updateTotalAmount();
				dijit.hideTooltip(_node);
			} else {
				dijit.byId("factura.montoRedondeo").set("displayedValue", 0.00);
				this.updateTotalAmount();
				dijit.byId("factura.montoRedondeo").validate();
			}
		}
	},

	updateAmountRoundKeyup: function(){
		if(dojo.byId("factura.montoRedondeo") != null){ /* PAS20201U210100285 - Factura Contingencia */
			var node = dijit.byId("factura.montoRedondeo");
			//dijit.byId("factura.montoRedondeo").validate();
			if(node.getValue() > 0.09 || node.getValue() < -0.09){
				this.warnTooltipMessage(node.focusNode, "El monto m&iacute;nimo es -0.09 y el m&aacute;ximo +0.09");
			} else if (isNaN(node.getValue())){
				this.warnTooltipMessage(node.focusNode, "El monto m&iacute;nimo es -0.09 y el m&aacute;ximo +0.09");
			} else {
				dijit.hideTooltip(node.focusNode);
			}
		}
	},
	/* Fin PAS20201U210100285 - Jose Mendoza S. */
	/*****WHR Inicio INC-xxxxxx  validacion caracteres y deshabilitaCtrlV*****/
	validaRazonSocial: function() {
		var valRazonSocial = dijit.byId("inicio.exportacion.razonSocial"); //dijit.byId("docrel.exportacionRazonSocial");
		var val = valRazonSocial.getValue();
	    if(val != null){
	    	valRazonSocial.attr('regExp','[A-Za-z0-9-_.\\s()ñ\u00E1\u00E9\u00ED\u00F3\u00FAÑ\u00E1\u00E9\u00ED\u00F3\u00FA#&]+');
	    	//valRazonSocial.attr('regExp','[^|¬#$&"{}\[\]+'); //no permite los caracteres mostrados
		}else{
			mostrarMensaje("ingresar valor correcto");
		}
	},

	deshabilitaCtrlV: function() {
		var pressedKey = String.fromCharCode(event.keyCode).toLowerCase();
		if (event.ctrlKey && (pressedKey == "c" || pressedKey == "v")) {
			event.returnValue = false;
		}
	},
	/*****WHR Fin INC-xxxxxx  *****/

	updateCurrency: function(moneda) {
		//subTotalVentas
		var subTotalVentas = dijit.byId("factura.subTotalVenta");
		subTotalVentas.setValue(dojo.currency.format(subTotalVentas.getValue(), {currency: moneda, places: 2}));

		//totalAnticipos
		var totalAnticipos = dijit.byId("factura.totalAnticipos");
		totalAnticipos.setValue(dojo.currency.format(totalAnticipos.getValue(), {currency: moneda, places: 2}));
		//totalDescuentos
		var totalDescuentos = dijit.byId("factura.totalDescuentos");
		totalDescuentos.setValue(dojo.currency.format(totalDescuentos.getValue(), {currency: moneda, places: 2}));

		//totalValorVenta
		var totalValorVenta = dijit.byId("factura.totalValorVenta");
		totalValorVenta.setValue(dojo.currency.format(totalValorVenta.getValue(), {currency: moneda, places: 2}));

		//totalISC
		var totalISC = dijit.byId("factura.totalISC");
		totalISC.setValue(dojo.currency.format(totalISC.getValue(), {currency: moneda, places: 2}));

		//totalIGV
		var totalIGV = dijit.byId("factura.totalIGV");
		totalIGV.setValue(dojo.currency.format(totalIGV.getValue(), {currency: moneda, places: 2}));

		//totalOtrosCargos
		var totalOtrosCargos = dijit.byId("factura.totalOtrosCargos");
		totalOtrosCargos.setValue(dojo.currency.format(totalOtrosCargos.getValue(), {currency: moneda, places: 2}));

		//totalOtrosTributos
		var totalOtrosTributos = dijit.byId("factura.totalOtrosTributos");
		totalOtrosTributos.setValue(dojo.currency.format(totalOtrosTributos.getValue(), {currency: moneda, places: 2}));

		//totalGeneral
		var totalGeneral = dijit.byId("factura.totalGeneral");
		totalGeneral.setValue(dojo.currency.format(totalGeneral.getValue(), {currency: moneda, places: 2}));


		//PAS20191U210100075
		//nrus = this.esNrus();

		var totalICBPERinput = dijit.byId("factura.totalICBPERConting");


		if (totalICBPERinput != undefined){

			//totalICBPER
			var totalICBPER = dijit.byId("factura.totalICBPERConting");
			totalICBPER.setValue(dojo.currency.format(totalICBPER.getValue(), {currency: moneda, places: 2}));

		}

		//PAS20191U210100075




	},

	addOtherDocument: function() {
		if(!dijit.byId("docrel.form").validate()) return;

		var ndTipDoc = dijit.byId("docrel.tipoDocumento");
		var val = ndTipDoc.getValue();

		if (val == "-"){
				ndTipDoc.attr('invalidMessage', "Tiene que seleccionar el tipo de documento.");
				ndTipDoc.focus();
				return;
		}
		var ndSerie = dijit.byId("docrel.serieDocumento");
		//if (val == "01" || val == "02"){   Antes del cambio para GEM
		if (val == "09" || val == "31" || val == "09R" || val == "31R" || val == "60" || val == "62" || val == "60R" || val == "62R"){
			var ndSerie2 = dojo.byId("docrel.serieDocumento");
			if(dojo.trim(ndSerie.value).length == 0) {
				mostrarMensaje("Tiene que ingresar n\u00FAmero de serie");
				ndSerie.focus();
				return;
			}

			if(dojo.trim(ndSerie.value).length != 4) {
				mostrarMensaje( "El n\u00FAmero de serie debe ser a 4 posiciones.");
				ndSerie.focus();
				return;
			}

			if (val == "60" || val == "62" || val == "60R" || val == "62R"){
				if (ndSerie.value!= "G001"){
			   		mostrarMensaje( "El n&uacute;mero de serie debe ser G001.");
					ndSerie.focus();
					return;
				}
			}
		}

		var ndNumero = dijit.byId("docrel.numeroDocumentoInicial");
		var ndNroDocFinal = dijit.byId("docrel.numeroDocumentoFinal");
		if(dojo.trim(ndNumero.getValue()).length == 0) {
			mostrarMensaje("Tiene que ingresar un número de documento");
			ndNumero.focus();
			return;
		}

		if (val == "09R" || val == "31R" || val == "60R" || val == "62R"){
    		if(dojo.trim(ndNroDocFinal.getValue()).length == 0) {
    			mostrarMensaje("Tiene que ingresar un número de documento");
    			ndNroDocFinal.focus();
    			return;
    		}

			if (parseFloat(ndNumero.getValue()) >= parseFloat(ndNroDocFinal.getValue())){
				mostrarMensaje("Numero inicial debe ser menor al numero final");
				//	ndNroDocFinal.attr('invalidMessage', "N&uacute;mero de documento debe ser mayor al inicial");
				ndNroDocFinal.focus();
				return;
			}
		}

		if (val == "09R" || val == "09" ){ //|| val == "60R" || val == "60"
			this.indRegitroGR ++;
		}
		this.wait("Adicionando", "110px", 100);
		var nodeButton = dijit.byId("docrel.botonAddDoc").focusNode;

		if (dijit.byId("docrel-grid").rowCount > 9 ) {
			this.iconTooltipMessage(nodeButton, "icon-error-tooltip", "Solo puede agregar un maximo de 10 documentos relacionados.");
			this.waitMessage.hide();
			return;
		}

		var handler = dojo.xhrGet({
			url: this.controller,
			handleAs: "json",
			sync: true,
			timeout: 10000,
			preventCache: true,
			form: "docrel.form"
		});

		handler.addCallback(dojo.hitch(this, function(res){
			this.waitMessage.hide();
			if(res.codeError == 0) {
				var oDoc = eval("(" + res.data + ")");
				var row = {
					identificador: oDoc.identificador,
//					elimina: "<a href=\"#\" title=\"Eliminar\" onclick=\"factura.delOtherDocument(" + rowindex + ")\"><img class=\"icon-by-del16\" src=\"/a/imagenes/s.gif\"/></a>",
					elimina: oDoc.identificador,
					tipo: oDoc.desTipoDocuRela,
					tipoCod: oDoc.tipoDocumentoRelacionado,
					serie: (oDoc.serieDocumentoRelacionado == "-" ? "":oDoc.serieDocumentoRelacionado),
					numeroInicial: oDoc.numeroDocumentoRelacionadoInicial,
					numeroFinal: oDoc.numeroDocumentoRelacionadoFinal
				};
				if(this.otherDocStore == null) this.otherDocStore = new dojo.data.ItemFileWriteStore({data: {identifier: 'identificador', items: [row], preventCache: true}});
				else this.otherDocStore.newItem(row);
				var grid = dijit.byId("docrel-grid");
				grid.setStore(this.otherDocStore);
				grid.update();

				ndSerie.attr("readOnly", false);
				//if (val == "01" || val == "02"){   Antes del cambio para GEM
				if (val == "09" || val == "31" || val == "09R" || val == "31R"){
					ndSerie.setValue("");
					ndNumero.setValue("");
					ndNroDocFinal.setValue("");
					ndSerie.focus();
				} else if(val == "60" || val == "62" || val == "60R" || val == "62R"){
					ndSerie.setValue("G001");
					ndSerie.attr("readOnly", true);
					ndNumero.setValue("");
					ndNroDocFinal.setValue("");
					ndNumero.focus();
				}
				else{
					ndNumero.setValue("");
					ndNumero.focus();
				}
			}
			else this.iconTooltipMessage(nodeButton, "icon-error-tooltip", res.messageError);
		}));

		handler.addErrback(dojo.hitch(this, function(res) {
			this.waitMessage.hide();
			this.iconTooltipMessage(nodeButton, "icon-error-tooltip", "Problemas al conectarse al servidor");
		}));
	},

	delOtherDocument: function(identificador) {
		//var nodeButton = dijit.byId("docrel.botonDelDoc").focusNode;
		var grid = dijit.byId("docrel-grid");

		if(!identificador) {
			var index = grid.getRowIndex();
			if(index > -1) {
				var row = grid.getRow(index);
				identificador = row.identificador;
			} else {
				mostrarMensaje("Seleccione un documento de la lista");
				return;
			}
		}

		this.otherDocStore.fetchItemByIdentity({
			identity: identificador,
			onItem: dojo.hitch(this, function(item){
				this.wait("Eliminando", "102px", 100);
				var handler = dojo.xhrGet({
					url: this.controller + "?action=delOtroDocumento&idItem=" + identificador,
					handleAs: "json",
					sync: true,
					timeout: 10000
				});
				handler.addCallback(dojo.hitch(this, function(res){
					this.waitMessage.hide();
					if (res.codeError == 0) {
					   if (item.tipoCod =="09" || item.tipoCod  == "09" ){ //|| item.tipoCod  == "60R" || item.tipoCod  == "60"
					       this.indRegitroGR--;
					   }
					   this.otherDocStore.deleteItem(item);
					   grid.setStore(this.otherDocStore);
					   grid.update();
					} else {
						mostrarMensaje(res.messageError);
					}
				}));

				handler.addErrback(dojo.hitch(this, function(res){
					this.waitMessage.hide();
					mostrarMensaje("Problemas al conectarse al servidor");
				}));
			}),
			onError: function(){
				mostrarMensaje("Ocurrio un error al ubicar el documento");
			}
		});
	},

	disableRUC: function(modo) {
		var ndRUC = dijit.byId("factura.numeroDocumento");
		var ndDescRUC = dijit.byId("factura.razonSocial");

		dojo.byId("factura.situacionEspecial").value = this.getValorSituacionEspecial();
		if (modo == 0){
			if ( dojo.trim(ndRUC.getValue()) == "" && dojo.trim(ndDescRUC.getValue())==""){
				ndRUC.attr('disabled',false);
				ndRUC.setValue("");
				ndRUC.focus();

				ndDescRUC.attr('disabled', true);
				ndDescRUC.setValue("");
			}
			//dojo.byId("factura.tipoDocumento").value = "06";
			dojo.byId("factura.tipoDocumento").value = "6";
		} else {
			ndRUC.attr('disabled',true);
			ndRUC.setValue("");

			ndDescRUC.attr('disabled', false);
			ndDescRUC.setValue("");
			ndDescRUC.focus();
			dojo.byId("factura.tipoDocumento").value = "-";
		}
	},

	disableNroSerieEnDocRel: function() {
		var ndTipDoc = dijit.byId("docrel.tipoDocumento");
		var ndNroSerie = dijit.byId("docrel.serieDocumento");
		var ndNroDocInicial = dijit.byId("docrel.numeroDocumentoInicial");
		var ndNroDocFinal = dijit.byId("docrel.numeroDocumentoFinal");
		var val = ndTipDoc.getValue();
		ndNroSerie.attr("readOnly", false);
		this.showHiddenDiv(document.getElementById("docrel.numDocFinal.show"),false);
		dojo.byId("docrel.numeroIni").innerHTML="N&uacute;mero Documento:"
		//if (val == "01" || val == "02"){   Antes del cambio para GEM
		if (val == "09" || val == "31" || val == "09R" || val == "31R" || val == "60" || val == "62" || val == "60R" || val == "62R"){
			ndNroSerie.attr('disabled',false);
			ndNroSerie.setValue("");

			ndNroDocInicial.setValue("");
			ndNroDocFinal.setValue("");
			dijit.byId("docrel.numeroDocumentoInicial").attr('regExp','[0-9]+');
			dijit.byId("docrel.numeroDocumentoFinal").attr('regExp','[0-9]+');
			dijit.byId("docrel.numeroDocumentoInicial").attr('maxLength','10');
			dijit.byId("docrel.numeroDocumentoFinal").attr('maxLength','10');
			if (val == "09R" || val == "31R" || val == "60R" || val == "62R"){
			   dojo.byId("docrel.numeroIni").innerHTML="N&uacute;mero Documento Inicial:"
			   this.showHiddenDiv(document.getElementById("docrel.numDocFinal.show"),true);
			}
			if (val == "09" || val == "31" || val == "09R" || val == "31R" ){
				/*
				// WHR – INC 2015-032970
				if(val == "09" || val == "31"){
					//ndNroSerie.attr('regExp','[G,g]001|[0-9]{4}|[T,t][A-Za-z0-9]{3}'); //WHR anterior INC-xxxxxx filtro documentos relacionados
					ndNroSerie.attr('regExp','[E,e][G,g]01|[0-9]{4}|[T,t][A-Za-z0-9]{3}');//WHR  INC-xxxxxx se quito G001 y se agrego EG01
				}else{
					ndNroSerie.attr('regExp','[0-9]+');
				}
				*/

				// PAS20201U210100081
				// ndNroSerie.attr('regExp', '[0-9]+');
				ndNroSerie.attr('regExp','[E,e][G,g]01|[0-9]{4}|[T,t][A-Za-z0-9]{3}');
			}else{
			    ndNroSerie.attr('regExp','[Gg0-9]+');
			}
				if (val == "60" || val == "62" || val == "60R" || val == "62R"){
				   ndNroSerie.setValue("G001");
				   //ndNroSerie.readOnly = true;
				   ndNroSerie.attr("readOnly", true);
				   //ndNroSerie.attr('disabled',true);
				   ndNroDocInicial.focus();
				}else{
				   ndNroSerie.focus();
			}

		} else {
			ndNroSerie.attr('disabled',true);
			ndNroDocInicial.setValue("");
			ndNroDocFinal.setValue("");
			dijit.byId("docrel.numeroDocumentoInicial").attr('regExp','[A-Za-z0-9]+');
			dijit.byId("docrel.numeroDocumentoFinal").attr('regExp','[A-Za-z0-9]+');
			dijit.byId("docrel.numeroDocumentoInicial").attr('maxLength','10');
			dijit.byId("docrel.numeroDocumentoFinal").attr('maxLength','10');
			this.showHiddenDiv(document.getElementById("docrel.numDocFinal.show"),false);
			ndNroDocInicial.focus();
		}
	},

	obtenerFacturaAnticipo: function(cambiarDatos) {
		console.log("OP.obtenerFacturaAnticipo");
		var serie = dijit.byId("item.facturaAnticipoSerie").getValue();
		var numero = dijit.byId("item.facturaAnticipoNumero").getValue();

		if (serie=="" || numero==""){
			return false;
		}

		if (serie == "EB01" || serie.substring(0,1)=="B") {
			mostrarMensaje("N\u00FAmero de serie no v\u00E1lida.");
			return false;
		}

		if (serie.substring(0,1)!="E" && serie.substring(0,1)!="F"){
			dijit.byId("item.facturaAnticipoMonto").attr('disabled', false);
			var handler2 = dojo.xhrGet({
				url: this.controller + "?action=validarRangosCPAutorizados&tipoCP=" + "01" +"&nroSerieCP=" + serie + "&nroInicial=" +numero + "&nroFinal=" +numero ,
                handleAs: "json",
                sync: true,
                timeout: 10000
			});

			handler2.addCallback(dojo.hitch(this, function(res){
				if (res.codeError == 0) {
					if (cambiarDatos){
						dijit.byId("item.descripcion").setValue("ANTICIPO: FACTURA NRO. "  + serie + "-" + numero);
					}
                    return true;
          		} else {
          			mostrarMensaje(res.messageError);
          			return false;
          		}
          	}));

			handler2.addErrback(function(res){
				this.waitMessage.hide();
              	mostrarMensaje("Problemas al conectarse con el servidor");
              	return false;
            });
			dijit.byId("item.facturaAnticipoMonto").attr('readOnly', false);
			return true;
		} else {
		}
        var handler = dojo.xhrGet({
            url: this.controller + "?action=obtenerFacturaAnticipo&serie=" + serie +"&numero=" + numero ,
            handleAs: "json",
            sync: true,
            timeout: 10000
        });

        handler.addCallback(dojo.hitch(this, function(res){
			if (res.codeError == 0) {
        		if (res.data != null &&  res.data  != ""){
        			this.beanDatosCP = eval("(" + res.data + ")");
        			if (this.beanDatosCP.subTipoComprobante != null){
						//PAS20191U210300015
						if (dojo.byId("global.tipoMoneda").value != this.beanDatosCP.codigoMoneda){
							//mostrarMensaje(this.beanDatosCP.codigoMoneda);
							this.disableMontosItem();
							dijit.byId("item.facturaAnticipoMonto").setValue("");
							dijit.byId("item.precioUnitario").setValue(0);
							dojo.byId("item.facturaAnticipoFechaEmision").value = "";
							dojo.byId("item.facturaAnticipoFechaEmisionAux").value = "";
							dijit.byId("item.descripcion").setValue("");
							mostrarMensaje("El comprobante ingresado no puede tener otra moneda diferente al comprobante de referencia de anticipo.");
							return false;
						}

        				if (cambiarDatos){
							if (serie =="E001"){
	        					dijit.byId("item.facturaAnticipoMonto").attr('readOnly', true);
	        					dijit.byId("item.iscMonto").attr('disabled', true);
	        					console.log("beans = " , this.beanDatosCP );
	        					dijit.byId("item.facturaAnticipoMonto").setValue(dojo.number.format(this.beanDatosCP.montoTotalGeneral,{places:2} ));
	        					dijit.byId("item.precioUnitario").setValue(dojo.number.format(this.beanDatosCP.totalValorVenta,{places: '2,10'}));
	        					console.log("OP.PRECIOUNITARIO == " , this.beanDatosCP.totalValorVenta);
	        					dijit.byId("item.iscMonto").setValue(dojo.number.format(this.beanDatosCP.totalISC,{places:2} ));
								if (dojo.byId("item.montoRedondeoAux") != null){ /* PAS20201U210100285 - Factura Contingencia */
									dojo.byId("item.montoRedondeoAux").value = this.beanDatosCP.montoRedondeo;// PAS20201U210100285 - jmendozas
								}
	        					dijit.byId("item.iscMonto").attr('disabled', true);
	        					if (this.beanDatosCP.totalISC != null && this.beanDatosCP.totalISC!="" && this.beanDatosCP.totalISC!="0"){
	        						dijit.byId("item.sistemaIsc").setValue("02");
	        						dijit.byId("item.iscPorcentaje").setValue("1");
	        					}else{
	        						dijit.byId("item.sistemaIsc").setValue("0");
	        						dijit.byId("item.iscPorcentaje").setValue("0");
	        					}

	        					dijit.byId("item.sistemaIsc").attr('disabled', true);
	        					dijit.byId("item.iscPorcentaje").attr('disabled', true);
	        					if (this.beanDatosCP.fechaEmision != "") {
	        						dojo.byId("item.facturaAnticipoFechaEmision").value = this.beanDatosCP.fechaEmision;
	        						dojo.byId("item.facturaAnticipoFechaEmisionAux").value = this.beanDatosCP.fechaEmision;

	        					}
	        					dijit.byId("item.descripcion").setValue("ANTICIPO: FACTURA NRO. "  + serie + "-" + numero);
	        					if (this.beanDatosCP.detalleComprobanteBean[0].tipoBeneficio !=null ){

	        						if (this.beanDatosCP.detalleComprobanteBean[0].tipoBeneficio =="TB00")
	        						{
	        							dijit.byId("item.subTipoTB00").setChecked("checked");
	        							dijit.byId("item.subTipoTB00").attr("disabled",true);
	        							dijit.byId("item.subTipoTB01").attr("disabled",true);
	        							dijit.byId("item.subTipoTB02").attr("disabled",true);
	        						}
	        						if (this.beanDatosCP.detalleComprobanteBean[0].tipoBeneficio =="TB01")
	        						{
	        							dijit.byId("item.subTipoTB01").setChecked("checked");
	        							dojo.byId("item.igvPorcentaje").value="0";
	        							dijit.byId("item.precioConIGV").setValue(0, false);
	        							dijit.byId("item.subTipoTB00").attr("disabled",true);
	        							dijit.byId("item.subTipoTB01").attr("disabled",true);
	        							dijit.byId("item.subTipoTB02").attr("disabled",true);
	        						}
	        						if (this.beanDatosCP.detalleComprobanteBean[0].tipoBeneficio =="TB02")
	        						{
	        							dijit.byId("item.subTipoTB02").setChecked("checked");
	        							dojo.byId("item.igvPorcentaje").value="0";
	        							dijit.byId("item.precioConIGV").setValue(0, false);
	        							dijit.byId("item.subTipoTB00").attr("disabled",true);
	        							dijit.byId("item.subTipoTB01").attr("disabled",true);
	        							dijit.byId("item.subTipoTB02").attr("disabled",true);
	        						}
	        					}
								console.log("OP.obtenerFacturaAnticipo2");
								this.updateItemAmount(); /* PAS20201U210100285 - Pago Anticipado */
	        					//return true;
	        				}else{
	        					dijit.byId("item.facturaAnticipoMonto").attr('readOnly', true);
	        					dijit.byId("item.facturaAnticipoMonto").setValue(dojo.number.format(this.beanDatosCP.montoTotalGeneral,{places:2} ));

	        					if (this.beanDatosCP.fechaEmision != "") {
	        						dojo.byId("item.facturaAnticipoFechaEmision").value = this.beanDatosCP.fechaEmision;
	        						dojo.byId("item.facturaAnticipoFechaEmisionAux").value = this.beanDatosCP.fechaEmision;
	        					}
	        					dijit.byId("item.descripcion").setValue("ANTICIPO: FACTURA NRO. "  + serie + "-" + numero);
								//return true;
	        				}
        				}
        				return true;
        			}else{
        				this.disableMontosItem();
						dijit.byId("item.facturaAnticipoMonto").setValue("");
        				dijit.byId("item.precioUnitario").setValue(0);
        				dojo.byId("item.facturaAnticipoFechaEmision").value = "";
        				dojo.byId("item.facturaAnticipoFechaEmisionAux").value = "";
        				dijit.byId("item.descripcion").setValue("");
        				mostrarMensaje(res.messageError);
        				return false;
        			}

        		}
        	} else {
				this.disableMontosItem();
        		dijit.byId("item.facturaAnticipoMonto").setValue("");
        		//dijit.byId("item.precioUnitario").setValue(dojo.number.format(0,{places:2,10} ));
        		dijit.byId("item.precioUnitario").setValue(0);
        		dojo.byId("item.facturaAnticipoFechaEmision").value = "";
        		dojo.byId("item.facturaAnticipoFechaEmisionAux").value = "";
        		dijit.byId("item.descripcion").setValue("");
        		mostrarMensaje(res.messageError);
        		return false;
        	}
        }));

        handler.addErrback(function(res){
        	this.waitMessage.hide();
        	mostrarMensaje("Problemas al conectarse con el servidor. " + res.messageError);
        	return false;
        });
	},

	disableMontosItem: function() {
		var moneda = dojo.byId("global.tipoMoneda").value;
		var otrosCargosTrib = dojo.byId("item.valOpcTipoCTItem").value;
		var anticipo = this.getValorOpcionAnticipo();
		if (dojo.byId("global.opcionDscto").value == "DE00") {
			dijit.byId("item.precioDescuento").setValue(0, false);
			dijit.byId("item.precioDescuento").attr("disabled",true);
		} else {
  			if (otrosCargosTrib == "0" || otrosCargosTrib == "" ){
  				dijit.byId("item.precioDescuento").attr("disabled",false);
  			}else{
  				dijit.byId("item.precioDescuento").setValue(0, false);
  				dijit.byId("item.precioDescuento").attr('disabled', true);
  				dijit.byId("item.precioDescuento").constraints = {currency: moneda,places: 2};
    		}
		}

		valTipoBonif = this.getValorOpcionTipoBonif();
		if (valTipoBonif=="BO01") {
			this.showHiddenDiv(document.getElementById("item.divOperacionGratuitaCombo.show"),true);

  			if (otrosCargosTrib == "" || otrosCargosTrib == "0" ){
  				this.showHiddenDiv(document.getElementById("item.divOperacionGratuitaCombo2.show"),false);
  				this.showHiddenDiv(document.getElementById("item.divOperacionGratuitaCombo1.show"),true);
  			}else{
  				this.showHiddenDiv(document.getElementById("item.divOperacionGratuitaCombo2.show"),true);
  				this.showHiddenDiv(document.getElementById("item.divOperacionGratuitaCombo1.show"),false);
  			}
  			dijit.byId("item.precioDescuento").setValue(0, false);
  			dijit.byId("item.precioDescuento").attr("disabled",true);
		} else {
			this.showHiddenDiv(document.getElementById("item.divOperacionGratuitaCombo.show"),false);
			if (dojo.byId("global.opcionDscto").value == "DE00") {
				dijit.byId("item.precioDescuento").setValue(0, false);
				dijit.byId("item.precioDescuento").attr("disabled",true);
			} else {
				if (otrosCargosTrib == "0" || otrosCargosTrib == "" ){
	          		dijit.byId("item.precioDescuento").attr("disabled",false);
				}else{
					dijit.byId("item.precioDescuento").setValue(0, false);
					dijit.byId("item.precioDescuento").attr('disabled', true);
					dijit.byId("item.precioDescuento").constraints = {currency: moneda,places: 2};
				}
			}
		}

		if (otrosCargosTrib == "0" || otrosCargosTrib == "" ){
			dijit.byId("item.cantidad").attr('disabled',false);
			if (!dijit.byId("item.cantidad").getValue()) {
				dijit.byId("item.cantidad").setValue(1);
			}

			dijit.byId("item.unidadMedida").attr('disabled',false);
			//PAS20181U210300095
			//dijit.byId("item.unidadMedida").setValue("NIU");
			dijit.byId("item.unidadMedida").focus();
		} else {
			dijit.byId("item.cantidad").setValue("");
			dijit.byId("item.cantidad").attr('disabled',true);

			dijit.byId("item.unidadMedida").setValue("000");
			dijit.byId("item.unidadMedida").attr('disabled',true);
		}

		if (dojo.byId("global.opcionExportacion").value == "1" ||
        dojo.byId("global.opcionISC").value == "IM00"      ||
        (otrosCargosTrib != "0" && otrosCargosTrib != "")  ){
  			dijit.byId("item.sistemaIsc").setValue("0");
  			dijit.byId("item.sistemaIsc").attr('disabled', true);

  			dijit.byId("item.iscPorcentaje").setValue(0, false);
  			dijit.byId("item.iscPorcentaje").attr('disabled', true);

  			dijit.byId("item.iscMonto").setValue(0, false);
  			dijit.byId("item.iscMonto").constraints = {currency:moneda, places:2};
  			dijit.byId("item.iscMonto").attr('disabled', true);
		} else {
  			dijit.byId("item.sistemaIsc").attr('disabled', false);
  			dijit.byId("item.iscPorcentaje").attr('disabled', false);

  			dijit.byId("item.iscMonto").constraints = {currency:moneda, places:2};
  			dijit.byId("item.iscMonto").attr('disabled', false);
		}

		if (dojo.byId("global.opcionExportacion").value == "1" || (otrosCargosTrib != "0" && otrosCargosTrib != "")) {
			this.showTipoBeneficio(0);
		} else{
			this.showTipoBeneficio(1);  //Mostramos igv
		}

		if (anticipo =="1"){
			dijit.byId("item.precioDescuento").setValue(0, false);
			dijit.byId("item.precioDescuento").attr('disabled', true);
			dijit.byId("item.precioDescuento").constraints = {currency: moneda,places: 2};
			dijit.byId("item.cantidad").setValue("1");
			dijit.byId("item.cantidad").attr('disabled',true);

			dijit.byId("item.unidadMedida").setValue("000");
			dijit.byId("item.unidadMedida").attr('disabled',true);
        }
		dijit.byId("item.importeVenta").constraints = {currency:moneda, places:2};
		dijit.byId("item.importeVenta").attr('disabled', true);

	},

	getValorOpcionSujetoRealizaTraslado: function() {
		var valOpcionSujetoRealizaTraslado="";
		for(i = 1; i < 3; i++) {
			if(dijit.byId("trasladoBienes.idSujetoRealizaTraslado0" + i).getValue() != false) {
				valOpcionSujetoRealizaTraslado = dijit.byId("trasladoBienes.idSujetoRealizaTraslado0" + i).getValue()
			}
		}
		return valOpcionSujetoRealizaTraslado;
	},

	getValorOpcionModalidadTraslado: function() {
		var valOpcionModalidadTraslado="";
		for(i = 1; i < 3; i++) {
			if(dijit.byId("trasladoBienes.idModalidadTraslado0" + i).getValue() != false) {
				valOpcionModalidadTraslado = dijit.byId("trasladoBienes.idModalidadTraslado0" + i).getValue()
			}
		}
		return valOpcionModalidadTraslado;
	},

	getValorOpcionISC: function() {
		var valOpcionISC;
		for(i = 0; i < 2; i++) {
			if(dijit.byId("inicio.subTipoIM0" + i).getValue() != false) {
				valOpcionISC = dijit.byId("inicio.subTipoIM0" + i).getValue()
			}
		}
		return valOpcionISC;
	},

	getValorOpcionTipoDireccPP: function() {
		var valOpcionTipoDireccPP;
		for(i = 1; i < 4; i++) {
			if(dijit.byId("puntoPartida.subTipoEestabEmisor0" + i).getValue() != false) {
				valOpcionTipoDireccPP = dijit.byId("puntoPartida.subTipoEestabEmisor0" + i).getValue()
			}
		}
		return valOpcionTipoDireccPP;
	},

	getValorOpcionTipoDireccPLL: function() {
		var valOpcionTipoDireccPLL;
		for(i = 1; i < 4; i++) {
			if(dijit.byId("puntoLlegada.subTipoEestabEmisor0" + i).getValue() != false) {
				valOpcionTipoDireccPLL = dijit.byId("puntoLlegada.subTipoEestabEmisor0" + i).getValue()
			}
		}
		return valOpcionTipoDireccPLL;
	},

	getValorOpcionTipoDireccCliente: function() {
		var valOpcionTipoDireccCliente;
		for(i = 1; i < 4; i++) {
			if(dijit.byId("direccCliente.subTipoEdireccCliente0" + i).getValue() != false) {
				valOpcionTipoDireccCliente = dijit.byId("direccCliente.subTipoEdireccCliente0" + i).getValue()
			}
		}
		return valOpcionTipoDireccCliente;
	},

	getValorOpcionDscto: function() {
		var valOpcionDscto;
		for(i = 0; i < 2; i++) {
			if(dijit.byId("inicio.subTipoDE0" + i).getValue() != false) {
				valOpcionDscto = dijit.byId("inicio.subTipoDE0" + i).getValue()
			}
		}
		return valOpcionDscto;
	},

	getValorSituacionEspecial: function() {
		var valSituacionEspecial;
		for(i = 1; i < 2; i++) {
			if(dijit.byId("factura.subTipoSE0" + i).getValue() != false) {
				valSituacionEspecial = dijit.byId("factura.subTipoSE0" + i).getValue()
			}
		}
		return valSituacionEspecial;
	},

	getTotalItemsEnGrid: function() {
		var grid = dijit.byId("factura.ingreso-grid");
		return (grid.store == null ? 0 : grid.rowCount);
	},

	getTotalItemsEnGridQueSonCargoTributo: function() {
		varTotalCT=0;
		var grilla = dijit.byId("factura.ingreso-grid");
		var filas = grilla.rowCount;
		for (i=0; i< filas;i++){
			var fila = grilla.getItem(i);
        	var valorCT = grilla.store.getValue(fila, "otrosCargosTributos");
        	if (valorCT !="0.00" && valorCT != "" && valorCT != "0") {
        		varTotalCT++;
        	}
		}

		return varTotalCT;
	},

	verSiFacturasDeAnticipoExisteEnGrid: function(serie, numero) {
		existeFacturaAnticipo=0;
		var grilla = dijit.byId("factura.ingreso-grid");
		var filas = grilla.rowCount;
		for (i=0; i< filas;i++){
			var fila = grilla.getItem(i);
            var anticipo = grilla.store.getValue(fila, "anticipo");
            if (anticipo =="1") {
                if (grilla.store.getValue(fila, "serieFacturaAnticipo") == serie && grilla.store.getValue(fila, "numeroFacturaAnticipo") == numero){
                    existeFacturaAnticipo=1;
                }
            }
		}
		return existeFacturaAnticipo;
	 },

	//PAS20175E210300029
	getItemsCompararFechaAnticipado: function() {
		var existeFacturaAnticipo="";
		var fechaEmisionDate = new Date();
		if (dojo.byId("global.fecEmision").value != ""){
			fechaEmisionDate = new Date(dojo.byId("global.fecEmision").value);
		}

		var grilla = dijit.byId("factura.ingreso-grid");
		var filas = grilla.rowCount;
		for (i = 0; i < filas; i++){
			var fila = grilla.getItem(i);
            var fechaAnticipo = grilla.store.getValue(fila, "fechaEmisionFacturaAnticipo");

            if (fechaAnticipo != null){
	            parts = fechaAnticipo.split('/');
	            fechaAnticipoDate = new Date(parts[2],parts[1]-1,parts[0]);

	            if (fechaAnticipoDate > fechaEmisionDate){
	            	j = i + 1;
	            	if (existeFacturaAnticipo == ""){
	            		existeFacturaAnticipo = "" + j;
	            	}else{
	            		existeFacturaAnticipo = existeFacturaAnticipo + ", " + j;
	            	}
	            }
            }
		}
		return existeFacturaAnticipo;
	 },

	 getTotalItemsEnGridQueSonGravados: function() {
		 varTotalIG=0;
		 var grilla = dijit.byId("factura.ingreso-grid");
		 var filas = grilla.rowCount;
		 for (i=0; i< filas;i++){
			 var fila = grilla.getItem(i);
			 var valorIG = grilla.store.getValue(fila, "tipoBeneficio");
			 if (valorIG =="TB00" ) {
				 varTotalIG++;
			 }
		 }
		 return varTotalIG;
	},

	getTotalItemsEnGridQueSonAnticipos: function() {
		varTotalIG=0;
		var grilla = dijit.byId("factura.ingreso-grid");
		var filas = grilla.rowCount;
		for (i=0; i< filas;i++){
	        var fila = grilla.getItem(i);
	        var valorIG = grilla.store.getValue(fila, "tipoPagoAnticipado");
	        if (valorIG =="1" ) {
	            varTotalIG++;
	        }
		}
		return varTotalIG;
	},

	getTotalItemsEnGridQueSonExonerados: function() {
		varTotalIG=0;
		var grilla = dijit.byId("factura.ingreso-grid");
		var filas = grilla.rowCount;
		for (i=0; i< filas;i++){
	        var fila = grilla.getItem(i);
	        var valorIG = grilla.store.getValue(fila, "tipoBeneficio");
	        if (valorIG =="TB01" ) {
	            varTotalIG++;
	        }
		}
		return varTotalIG;
	},

	getTotalItemsEnGridQueSonInafectos: function() {
		varTotalIG=0;
		var grilla = dijit.byId("factura.ingreso-grid");
		var filas = grilla.rowCount;
		for (i=0; i< filas;i++){
			var fila = grilla.getItem(i);
			var valorIG = grilla.store.getValue(fila, "tipoBeneficio");
			if (valorIG =="TB02" ) {
				varTotalIG++;
			}
		}
		return varTotalIG;
	},

	getTotalItemsEnGridQueTienenISC: function() {
		varTotalIG=0;
		var grilla = dijit.byId("factura.ingreso-grid");
		var filas = grilla.rowCount;
		for (i=0; i< filas;i++){
			var fila = grilla.getItem(i);
			var valorIG = grilla.store.getValue(fila, "iscSistema");
			if (valorIG !="0" ) {
				varTotalIG++;
			}
		}
		return varTotalIG;
	},

	getTotalItemsEnGridQueSonBienes: function() {
		varTotalIG=0;
		var grilla = dijit.byId("factura.ingreso-grid");
		var filas = grilla.rowCount;
		for (i=0; i< filas;i++){
			var fila = grilla.getItem(i);
			var valorIG = grilla.store.getValue(fila, "tipoItem");
			if (valorIG =="TI01" ) {
				varTotalIG++;
			}
		}
		return varTotalIG;
	},

	// PAS20191U210100204
	getExisteDuplicados: function(){
		existeduplicados = 0;
		var grilla;
		if (dijit.byId("factura.ingreso-grid") != null){
			grilla = dijit.byId("factura.ingreso-grid");
		}
		else if (dijit.byId("factura.preview-grid") != null){
			grilla = dijit.byId("factura.preview-grid");
		}
		else{
			return existeduplicados;
		}

		var filas = grilla.rowCount;
		if (filas > 1){
			for (i = 0; i < filas; i++){
				var fila = grilla.getItem(i);
				var cantidad = Math.abs(grilla.store.getValue(fila, "cantidad"));
				var unidadMedida = grilla.store.getValue(fila, "unidadMedida");
				var codigoItem = grilla.store.getValue(fila, "codigoItem").trim();
				var descripcion = grilla.store.getValue(fila, "descripcion").trim();
				var precioUnitario = Math.abs(grilla.store.getValue(fila, "precioUnitario"));
				var contenidoItem = cantidad + "-" + unidadMedida + "-" + codigoItem + "-" + descripcion + "-" + precioUnitario;

				for (j = 0; j < filas ; j++){
					if (i == j){ continue; }
					var filaComp = grilla.getItem(j);
					var cantidadComp = Math.abs(grilla.store.getValue(filaComp, "cantidad"));
					var unidadMedidaComp = grilla.store.getValue(filaComp, "unidadMedida");
					var codigoItemComp = grilla.store.getValue(filaComp, "codigoItem").trim();
					var descripcionComp = grilla.store.getValue(filaComp, "descripcion").trim();
					var precioUnitarioComp = Math.abs(grilla.store.getValue(filaComp, "precioUnitario"));
					var contenidoItemComp = cantidadComp + "-" + unidadMedidaComp + "-" + codigoItemComp + "-" + descripcionComp + "-" + precioUnitarioComp;

					if (contenidoItem.trim() == contenidoItemComp.trim()){
						existeduplicados++;
						break;
					}
				}

				if (existeduplicados > 0){ break;}
			}
		}
		return existeduplicados;
	},

	enabledSituacionEspecial: function(valor) {
		dijit.byId("factura.subTipoSE00").attr("disabled",valor);
		dijit.byId("factura.subTipoSE01").attr("disabled",valor);
		dijit.byId("factura.subTipoSE02").attr("disabled",valor);
	},

	updateLocalAsociado: function(valor) {
		dijit.byId("factura.localAsociado").setValue(valor);
	},

	getValorOpcionTipoItem: function() {
		var valTipoItem="";
		for(i = 1; i < 3; i++) {
			//if(dijit.byId("item.subTipoTI0" + i).getValue() != false) {
			if(dojo.byId("item.subTipoTI0" + i).checked == true){
				valTipoItem = dijit.byId("item.subTipoTI0" + i).getValue()
			}
		}
		return valTipoItem;
	},

	getValorOpcionOtrosCargosTrib: function() {
		var valOtrosCargosTrib="";
		for(i = 1; i < 3; i++) {
			//if(dijit.byId("item.subCT0" + i).getValue() != false) {
			if(dojo.byId("item.subCT0" + i).checked == true){
				valOtrosCargosTrib = dijit.byId("item.subCT0" + i).getValue()
			}
		}
		return valOtrosCargosTrib;
	},

	getValorOpcionBienServicio: function() {
		var valBienServicio="";
		for(i = 1; i < 3; i++) {
			//if(dijit.byId("item.subTipoTI0" + i).getValue() != false) {
			if(dojo.byId("item.subTipoTI0" + i).checked == true) {
				valBienServicio = dijit.byId("item.subTipoTI0" + i).getValue()
			}
		}
		return valBienServicio;
	},
	getValorOpcionImpuestoBolsaPlastica: function() {
		var valOpcionImpuestoBolsaPlastica="";
		for(i = 0; i < 2; i++) {
			//if(dijit.byId("item.subTipoTB0" + i).getValue() != false) {
			if(document.getElementById("check.impuestoBolsasPlastica0"+i).checked == true) {
				valOpcionImpuestoBolsaPlastica = document.getElementById("check.impuestoBolsasPlastica0"+i).value;
			}
		}
		return valOpcionImpuestoBolsaPlastica;
	},
	getValorOpcionTipoBenef: function() {
		var valTipoBeneficio="";
		for(i = 0; i < 3; i++) {
			//if(dijit.byId("item.subTipoTB0" + i).getValue() != false) {
			if(dojo.byId("item.subTipoTB0" + i).checked == true) {
				valTipoBeneficio = dijit.byId("item.subTipoTB0" + i).getValue()
			}
		}
		return valTipoBeneficio;
	},

	getValorOpcionTipoBonif: function() {
		var valTipoBonif="";
		//if(dijit.byId("item.subTipoBO00").getValue() != false) {
		if(dojo.byId("item.subTipoBO00").checked == true) {
			valTipoBonif = dijit.byId("item.subTipoBO00").getValue();
		}
		return valTipoBonif;
	},

	getValorOpcionAnticipo: function() {
		var valTipoBonif="1";
		var subTipoPagoAnticipado = dijit.byId("item.subTipoPagoAnticipado0");
		if(subTipoPagoAnticipado.getValue() == false) {
			valTipoBonif = "0";
		}
		return valTipoBonif;
	},

	getValorOpcionInicialExportacion: function() {
		var valTipoExportacion="";
		for(i = 0; i < 2; i++) {
			if(dojo.byId("inicio.subTipoEE0" + i).checked == true) {
				valTipoExportacion = dojo.byId("inicio.subTipoEE0" + i).value;
			}
		}
		return valTipoExportacion;
	},
//PAS20201U210100230 INI
	getValorOpcionInicialTransaccion: function() {
		//validacion si existen
		var valTipoTransaccion="";
		if(dojo.byId("inicio.facturaFactoring.subTipoTT01")!= null && dojo.byId("inicio.facturaFactoring.subTipoTT02")!= null){
			for(i = 1; i < 3; i++) {
				if(dojo.byId("inicio.facturaFactoring.subTipoTT0" + i).checked == true) {
					valTipoTransaccion = dojo.byId("inicio.facturaFactoring.subTipoTT0" + i).value;
				}
			}
		}

		return valTipoTransaccion;
	},
	//PAS20201U210100230 fin

	getValorOpcionInicialNoDomic: function() {
		var valNodomic= "";
		for(i = 0; i < 2; i++) {
			if(dojo.byId("inicio.subTipoND0" + i).checked == true) {
				valNodomic = dojo.byId("inicio.subTipoND0" + i).value;
			}
		}
		return valNodomic;
	},

	getValorOpcionInicialCargosTrib: function() {
		var valTipoExportacion="";
		for(i = 0; i < 2; i++) {
			if(dojo.byId("inicio.subTipoCargosTribNoBaseImp0" + i).checked == true) {
				valTipoExportacion = dojo.byId("inicio.subTipoCargosTribNoBaseImp0" + i).value;
			}
		}
		return valTipoExportacion;
	},

	getValorOpcionFESectorPublico: function() {
		var valOpcionFESectorPublico="";
		for(i = 0; i < 2; i++) {

			if(dojo.byId("inicio.subTipoFSP0" + i).checked == true) {
				valOpcionFESectorPublico = dojo.byId("inicio.subTipoFSP0" + i).value;
			}
		}
		return valOpcionFESectorPublico;
	},

	getValorOpcionPagoAnticipado: function() {
		var valOpcionPagoAnticipado="";
		for(i = 0; i < 2; i++) {
			if(dojo.byId("inicio.subTipoFEPagoActicipado0" + i).checked == true) {
				valOpcionPagoAnticipado = dojo.byId("inicio.subTipoFEPagoActicipado0" + i).value;
			}
		}
		return valOpcionPagoAnticipado;
	},

	getValorOpcionPagoDeduccionAnticipado: function() {
		var valOpcionPagoDeduccionAnticipado= "";
		for(i = 0; i < 2; i++) {
			if(dojo.byId("inicio.subTipoDE0" + i).checked == true) {
				valOpcionPagoDeduccionAnticipado = dojo.byId("inicio.subTipoDE0" + i).value;
			}
		}
		return valOpcionPagoDeduccionAnticipado;
	},

	getValorOpcionInicialOperacionesGratuitas: function() {
		var valor="";
		for(i = 0; i < 2; i++) {
			if(dojo.byId("inicio.subTipoOpeGratuita0" + i).checked == true) {
				valor = dojo.byId("inicio.subTipoOpeGratuita0" + i).value;
			}
		}
		return valor;
	},

	getValorOpcionVentaItinerante: function() {
		var valOpcionVentaItinerante="";
		for(i = 0; i < 2; i++) {
			if(dojo.byId("inicio.subTipoEmiItinerante0" + i).checked == true) {
				valOpcionVentaItinerante = dojo.byId("inicio.subTipoEmiItinerante0" + i).value;
			}
		}
		return valOpcionVentaItinerante;
	},

	getValorEstablecimientoEmisor: function() {
		var valOpcionEstablecimientoEmisor="";
		for(i = 0; i < 2; i++) {
			if(dojo.byId("inicio.subTipoEstEmi0" + i).checked == true) {
				valOpcionEstablecimientoEmisor = dojo.byId("inicio.subTipoEstEmi0" + i).value;
			}
		}

		if (valOpcionEstablecimientoEmisor == 0){
			dojo.byId("global.opcionEstablecimientoEmisorDireccion").value = "";
		}

		return valOpcionEstablecimientoEmisor;
	},

	getValorOpcionDomicilioCliente: function() {
		var valOpcionDomicilioCliente="";
		for(i = 0; i < 2; i++) {

			if(dojo.byId("inicio.subTipoDC0" + i).checked == true) {
				valOpcionDomicilioCliente = dojo.byId("inicio.subTipoDC0" + i).value;
			}
		}
		return valOpcionDomicilioCliente;
	},

	getValorOpcionSPOT: function() {
		var valOpcionSpot="";
		for(i = 0; i < 2; i++) {

			if(dojo.byId("inicio.subTipoOperacionSPOT0" + i).checked == true) {
				valOpcionSpot = dojo.byId("inicio.subTipoOperacionSPOT0" + i).value;
			}
		}
		return valOpcionSpot;
	},

	getValorOpcionSustentoTrasladoBienes: function() {
		var valOpcionSustentoTrasladoBienes="";
		for(i = 0; i < 2; i++) {

			if(dojo.byId("inicio.subTipoTrasladoB0" + i).checked == true) {
				valOpcionSustentoTrasladoBienes = dojo.byId("inicio.subTipoTrasladoB0" + i).value;
			}
		}
		return valOpcionSustentoTrasladoBienes;
	},

	getValorOpcionVentaCombustible: function() {
		var valOpcionVentaCombustible="";
		for(i = 0; i < 2; i++) {
			if(dojo.byId("inicio.subTipoVentaCombustibleB0" + i).checked == true) {
				valOpcionVentaCombustible = dojo.byId("inicio.subTipoVentaCombustibleB0" + i).value;
			}
		}
		return valOpcionVentaCombustible;
	},
	//PAS20191U210100075
	viewCheckedImpuestoBolsaPlastica: function() {
		var valOpcionImpuestoBolsaPlastica = this.getValorOpcionImpuestoBolsaPlastica();
		var moneda = dojo.byId("global.tipoMoneda").value;
		monedades = dojo.byId("global.tipoMonedaDesc").value;
		if(monedades != "SOLES"){

			if (valOpcionImpuestoBolsaPlastica != "IBP00"){ //NO > IMPUESTO BOLSAS
				dijit.byId("item.impuestoICBPER").attr('disabled',true);
				dijit.byId("item.impuestoICBPER").constraints = {currency:moneda, places:2};
				dijit.byId("item.impuestoICBPER").attr('value',0);
				//dijit.byId("item.cantidad").attr('value',dojo.number.format(dijit.byId("item.cantidad").getValue(),{places:2} ));

				//dijit.byId("item.cantidad").constraints = {min:0,max:20000,places:2};




			}else{ // SI IMPUESTO BOLSAS

				dijit.byId("item.impuestoICBPER").attr('disabled',false);
				dijit.byId("item.impuestoICBPER").constraints = {currency:moneda, places:2};
				dijit.byId("item.impuestoICBPER").attr('value',dijit.byId("item.impuestoICBPER").getValue());
				//dijit.byId("item.cantidad").attr('value',dojo.number.format(dijit.byId("item.cantidad").getValue(),{places:0} ));
				//dijit.byId("item.cantidad").constraints = {min:0,max:20000,places:0};
			}

		}


		if (valOpcionImpuestoBolsaPlastica != "IBP00"){
			dojo.byId("item.impuestoICBPER").value="0";
			dojo.byId("item.tasaBolsaGlobal").value="0";
			dijit.byId("item.periodoBolsa").set("displayedValue", "");
			dijit.byId("item.periodoBolsa").attr('disabled',true);
			dojo.byId("item.tasaBolsa").value = "0";
			dojo.byId("item.PeriodoBolsaGlobal").value = "";
			//dijit.byId("item.cantidad").attr('value',dojo.number.format(dijit.byId("item.cantidad").getValue(),{places:2} ));
			//dijit.byId("item.cantidad").constraints = {min:0,max:20000,places:2};
		} else { //SI

			rsp = this.loadImpuestoBolsa();

			if(rsp){

				var anio = "";
				var parts = dojo.byId("factura.fechaEmision").value.split('/');

				var fechaEmision = new Date(parts[2],parts[1]-1,parts[0]);

				console.log(dijit.byId('item.periodoBolsa').getValue());
				console.log(dijit.byId('item.periodoBolsa').value);


				if(dojo.byId("item.PeriodoBolsaGlobal").value != ""){
					anio = dojo.byId("item.PeriodoBolsaGlobal").value
				}else{
					anio = fechaEmision.getFullYear();

				}
				console.log(dojo.byId("item.PeriodoBolsaGlobal").value);

				dojo.byId("item.tasaBolsaGlobal").value = dijit.byId('item.periodoBolsa').getValue();


				if(monedades != "SOLES"){
					dijit.byId("item.periodoBolsa").set("displayedValue","");
					dijit.byId("item.periodoBolsa").attr('disabled',true);
				}else{
					dijit.byId("item.periodoBolsa").set("displayedValue",anio.toString() );
					dijit.byId("item.periodoBolsa").attr('disabled',false);
				}

				this.selectperiodoBolsaChange(dijit.byId("item.periodoBolsa").getValue());
				//dijit.byId("item.cantidad").attr('value',dojo.number.format(dijit.byId("item.cantidad").getValue(),{places:0} ));
				//dijit.byId("item.cantidad").constraints = {min:0,max:20000,places:0};
			}else{

				dijit.byId("check.impuestoBolsasPlastica01").setChecked("checked");
			}



		}


		this.resetValIGV();
	},
	//PAS20191U210100075

	viewCheckedTipoBenef: function() {
		var valTipoBenef = this.getValorOpcionTipoBenef();

		if (valTipoBenef != "TB00"){
			dojo.byId("item.igvPorcentaje").value="0";
		} else {
			dojo.byId("item.igvPorcentaje").value = dojo.byId("global.igvPorcentaje").value;

		}
		this.resetValIGV();
	},

	viewCheckedOtrosCargosTrib: function() {
		//Desactivamos Bien / servicio
		dijit.byId("item.subTipoTI01").setChecked("");
		dijit.byId("item.subTipoTI02").setChecked("");
		dojo.byId("item.valOpcTipoBS").value="";

		var valFlag = dojo.byId("item.valOpcTipoCTItem").value;
		var valTipoItem = this.getValorOpcionOtrosCargosTrib();

		if (valFlag == valTipoItem) {
			dijit.byId("item.subCT0" + valTipoItem).setChecked("");
			dojo.byId("item.valOpcTipoCTItem").value="0";
			this.showHiddenDiv(document.getElementById("item.divFEPagoAnticipado.show"),true);
		} else {
			dojo.byId("item.valOpcTipoCTItem").value=valTipoItem;
			this.showTipoBeneficio(0);
			dojo.byId("item.valOpcPagoAnticipado").value="0";
  			//dijit.byId("item.subTipoPagoAnticipado0").setValue("0");
  			dijit.byId("item.subTipoPagoAnticipado0").attr('checked', false) ;
  			this.showHiddenDiv(document.getElementById("item.divFEPagoAnticipado.show"),false);
		}

		//PAS20191U210100075 - jsantivanez

		if (dojo.byId("global.opcionOtrosCargosTributos").value == "1") {
			dijit.byId("check.impuestoBolsasPlastica00").setAttribute('disabled', true);
			dijit.byId("check.impuestoBolsasPlastica01").setAttribute('disabled', true);
			dijit.byId("item.periodoBolsa").setAttribute('disabled', true);
			dijit.byId("check.impuestoBolsasPlastica01").setChecked("checked");
			this.viewCheckedImpuestoBolsaPlastica();

		}
		//PAS20191U210100075 - jsantivanez


		this.disableMontosItem();
	},

	viewCheckedBienServicio: function() {
		var valFlag = dojo.byId("item.valOpcTipoBS").value;
		var valTipoItem = this.getValorOpcionBienServicio();

		if (valFlag == valTipoItem) {
			if (dojo.byId("global.opcionNodomic").value != "1") {
				dijit.byId("item.subTipo" + valTipoItem).setChecked("");
				dojo.byId("item.valOpcTipoBS").value="";
			}
		} else {
			dojo.byId("item.valOpcTipoBS").value=valTipoItem;
		}

		//Desactivamos Cargo /tributo
		dijit.byId("item.subCT01").setChecked("");
		dijit.byId("item.subCT02").setChecked("");
		dojo.byId("item.valOpcTipoCTItem").value="0";

		if (dojo.byId("global.opcionExportacion").value == "1") {
			this.showTipoBeneficio(0);
		}	else{
		   this.showTipoBeneficio(1);  //Mostramos igv
		}

		//PAS20191U210100075 - jsantivanez

		if (dojo.byId("global.opcionOtrosCargosTributos").value == "1") {
			dijit.byId("check.impuestoBolsasPlastica00").setAttribute('disabled', false);
			dijit.byId("check.impuestoBolsasPlastica01").setAttribute('disabled', false);
			dijit.byId("item.periodoBolsa").setAttribute('disabled', false);

		}

		this.viewCheckedImpuestoBolsaPlastica();
		//PAS20191U210100075 - jsantivanez


		this.disableMontosItem();
	},

	viewCheckedOperacionGratuita: function() {
		var moneda = dojo.byId("global.tipoMoneda").value;
		var valTipoBonif = this.getValorOpcionTipoBonif();

		if (dojo.byId("global.opcionDscto").value == "DE01" && valTipoBonif == "BO01") {
  			dojo.byId("item.valOpcTipoBonif").value="BO00";
  			dijit.byId("item.subTipoBO00").setValue("BO00");
  			dijit.byId("item.subTipoBO00").setChecked("");
  			this.showHiddenDiv(document.getElementById("item.divOperacionGratuitaCombo.show"),false);
  			//this.showHiddenDiv(document.getElementById("item.divFEPagoAnticipado.show"),true);
		} else {
  			dojo.byId("item.valOpcTipoBonif").value="BO01";
  			dijit.byId("item.subTipoBO00").setValue("BO01");
  			dijit.byId("item.subTipoBO00").setChecked("checked");

  			this.showHiddenDiv(document.getElementById("item.divOperacionGratuitaCombo.show"),true);
  			dojo.byId("item.valOpcPagoAnticipado").value="0";
  			//dijit.byId("item.subTipoPagoAnticipado0").setValue("0");
  			dijit.byId("item.subTipoPagoAnticipado0").attr('checked', false) ;
  			this.showHiddenDiv(document.getElementById("item.divFEPagoAnticipado.show"),false);
		}

		this.showTipoBeneficio(1);
		this.disableMontosItem();
	},

	viewCheckedAnticipo: function() {
		var valTipoBonif = this.getValorOpcionAnticipo();

		if (valTipoBonif == "1") {
			dojo.byId("item.valOpcPagoAnticipado").value="1";
			//dijit.byId("item.subTipoPagoAnticipado0").attr('checked', true) ;
			this.showHiddenDiv(document.getElementById("item.divFEPagoAnticipado.show"),true);

			//Desactivamos Cargo /tributo
			dijit.byId("item.subCT01").setChecked("");
			dijit.byId("item.subCT02").setChecked("");
    		dojo.byId("item.valOpcTipoCTItem").value="0";

  			dojo.byId("item.valOpcTipoBonif").value="BO00";
  			dijit.byId("item.subTipoBO00").setValue("BO00");
  			dijit.byId("item.subTipoBO00").setChecked("");
  			this.showHiddenDiv(document.getElementById("item.divOperacionGratuitaCombo.show"),false);

  			dijit.byId("item.cantidad").setValue("1");
  			dijit.byId("item.cantidad").attr('disabled',true);
  			this.showHiddenDiv(document.getElementById("item.divFENoPagoAnticipado.show"),false);
  			dojo.byId("rotuloValorUnitario").innerHTML="Anticipo a Valor de Venta"
            dojo.byId("rotuloTotalItem").innerHTML="Importe Total"
            this.showHiddenDiv(document.getElementById("item.divDescuentos.show"),false);
        //INI: PAS20191U210100075
        if (dojo.byId("global.opcionPagoDeduccionAnticipado").value =="DE01"){
    			dijit.byId("check.impuestoBolsasPlastica00").setAttribute('disabled', true);
    			dijit.byId("check.impuestoBolsasPlastica01").setAttribute('disabled', true);
    			dijit.byId("item.periodoBolsa").setAttribute('disabled', true);
    			dijit.byId("check.impuestoBolsasPlastica01").setChecked("checked");
    			this.viewCheckedImpuestoBolsaPlastica();
    		}
    		//FIN: PAS20191U210100075
		} else {
			dojo.byId("item.valOpcPagoAnticipado").value="0";
			//	dijit.byId("item.subTipoPagoAnticipado0").attr('checked', false) ;
			this.showHiddenDiv(document.getElementById("item.divFEPagoAnticipado.show"),false);
			dijit.byId("item.cantidad").attr('disabled',false);
			dijit.byId("item.facturaAnticipoSerie").setValue("");
			dijit.byId("item.facturaAnticipoNumero").setValue("");
			dijit.byId("item.facturaAnticipoFechaEmision").setValue("");
			dojo.byId("item.facturaAnticipoFechaEmisionAux").value="";
			this.showHiddenDiv(document.getElementById("item.divFENoPagoAnticipado.show"),true);
			dojo.byId("rotuloValorUnitario").innerHTML="Valor Unitario ";
			dojo.byId("rotuloTotalItem").innerHTML="Importe Total del Item ";
			this.showHiddenDiv(document.getElementById("item.divDescuentos.show"),true);

		  //INI: PAS20191U210100075
		  if (dojo.byId("global.opcionPagoDeduccionAnticipado").value =="DE01"){
			dijit.byId("check.impuestoBolsasPlastica00").setAttribute('disabled', false);
				dijit.byId("check.impuestoBolsasPlastica01").setAttribute('disabled', false);
				dijit.byId("item.periodoBolsa").setAttribute('disabled', false);
		  }
		  //FIN: PAS20191U210100075

		}
		this.disableMontosItem();
	},

	showOpcionesVentaItinerante:function(valor){
		if (valor == 1) {
            dijit.byId("inicio.subTipoDC01").setChecked("checked");
            dijit.byId("inicio.subTipoDC01").setValue("1");
            this.showOpcionesDireccionCliente(1);
            dijit.byId("inicio.subTipoDC01").setAttribute('disabled', true);
            dijit.byId("inicio.subTipoDC00").setAttribute('disabled', true);
            dijit.byId("inicio.subTipoEstEmi01").setAttribute('disabled', true);
            dijit.byId("inicio.subTipoEstEmi00").setAttribute('disabled', true);

            dijit.byId("inicio.subTipoFEPagoActicipado00").setChecked("checked");
            dijit.byId("inicio.subTipoFEPagoActicipado00").setValue("0");
            dijit.byId("inicio.subTipoFEPagoActicipado01").setAttribute('disabled', true);
            dijit.byId("inicio.subTipoFEPagoActicipado00").setAttribute('disabled', true);

            dijit.byId("inicio.subTipoTrasladoB00").setChecked("checked");
            dijit.byId("inicio.subTipoTrasladoB00").setValue("0");
            dijit.byId("inicio.subTipoTrasladoB01").setAttribute('disabled', true);
            dijit.byId("inicio.subTipoTrasladoB00").setAttribute('disabled', true);

		}else{
			dijit.byId("inicio.subTipoDC00").setChecked("checked");
			dijit.byId("inicio.subTipoDC00").setValue("0");
            dijit.byId("inicio.subTipoDC01").setAttribute('disabled', false);
            dijit.byId("inicio.subTipoDC00").setAttribute('disabled', false);
            dijit.byId("inicio.subTipoEstEmi01").setChecked("checked");
            dijit.byId("inicio.subTipoEstEmi01").setValue("1");
            dijit.byId("inicio.subTipoEstEmi01").setAttribute('disabled', false);
            dijit.byId("inicio.subTipoEstEmi00").setAttribute('disabled', false);
            dijit.byId("inicio.subTipoFEPagoActicipado01").setAttribute('disabled', false);
            dijit.byId("inicio.subTipoFEPagoActicipado00").setAttribute('disabled', false);
            dijit.byId("inicio.subTipoTrasladoB01").setAttribute('disabled', false);
            dijit.byId("inicio.subTipoTrasladoB00").setAttribute('disabled', false);
		}
    },

	showOpcionesDireccionCliente:function(valor){
    	if (valor == 1) {
    		dijit.byId("inicio.subTipoEstEmi00").setChecked("checked");
    		dijit.byId("inicio.subTipoEstEmi00").setValue("0");
          	//dijit.byId("inicio.subTipoEmiItinerante01").setChecked("checked");
    		//dijit.byId("inicio.subTipoEmiItinerante01").setValue("1");
    	}else{
    		dijit.byId("inicio.subTipoEstEmi01").setChecked("checked");
    		dijit.byId("inicio.subTipoEstEmi01").setValue("1");
    		dijit.byId("inicio.subTipoEmiItinerante00").setChecked("checked");
    		dijit.byId("inicio.subTipoEmiItinerante00").setValue("0");
    	}
    },

    showOpcionesEstablecimientoEmisor:function(valor){
    	if (valor == 1) {
    		dijit.byId("inicio.subTipoDC00").setChecked("checked");
    		dijit.byId("inicio.subTipoDC00").setValue("0");
    	}else{
    		dijit.byId("inicio.subTipoDC01").setChecked("checked");
    		dijit.byId("inicio.subTipoDC01").setValue("1");
    	}
    },

	//PAS20181U210300235 libros ya presentados y domicilio del cliente
	showOpcionesVentaItineranteContin:function(valor){
		if (valor == 1) {
            dijit.byId("inicio.subTipoDC01").setChecked("checked");
            dijit.byId("inicio.subTipoDC01").setValue("1");
            this.showOpcionesDireccionClienteContin(1);
            /*dijit.byId("inicio.subTipoDC01").setAttribute('disabled', true);
            dijit.byId("inicio.subTipoDC00").setAttribute('disabled', true);
            dijit.byId("inicio.subTipoEstEmi01").setAttribute('disabled', true);
            dijit.byId("inicio.subTipoEstEmi00").setAttribute('disabled', true); */

            dijit.byId("inicio.subTipoFEPagoActicipado00").setChecked("checked");
            dijit.byId("inicio.subTipoFEPagoActicipado00").setValue("0");
            dijit.byId("inicio.subTipoFEPagoActicipado01").setAttribute('disabled', true);
            dijit.byId("inicio.subTipoFEPagoActicipado00").setAttribute('disabled', true);

            dijit.byId("inicio.subTipoTrasladoB00").setChecked("checked");
            dijit.byId("inicio.subTipoTrasladoB00").setValue("0");
            dijit.byId("inicio.subTipoTrasladoB01").setAttribute('disabled', true);
            dijit.byId("inicio.subTipoTrasladoB00").setAttribute('disabled', true);

		}else{
			dijit.byId("inicio.subTipoDC00").setChecked("checked");
			dijit.byId("inicio.subTipoDC00").setValue("0");
            dijit.byId("inicio.subTipoDC01").setAttribute('disabled', false);
            dijit.byId("inicio.subTipoDC00").setAttribute('disabled', false);
            /*dijit.byId("inicio.subTipoEstEmi01").setChecked("checked");
            dijit.byId("inicio.subTipoEstEmi01").setValue("1");*/
            dijit.byId("inicio.subTipoEstEmi01").setAttribute('disabled', false);
            dijit.byId("inicio.subTipoEstEmi00").setAttribute('disabled', false);
            dijit.byId("inicio.subTipoFEPagoActicipado01").setAttribute('disabled', false);
            dijit.byId("inicio.subTipoFEPagoActicipado00").setAttribute('disabled', false);
            dijit.byId("inicio.subTipoTrasladoB01").setAttribute('disabled', false);
            dijit.byId("inicio.subTipoTrasladoB00").setAttribute('disabled', false);
		}
    },

	showOpcionesDireccionClienteContin:function(valor){
    	if (valor == 1) {
    		/*dijit.byId("inicio.subTipoEstEmi00").setChecked("checked");
    		dijit.byId("inicio.subTipoEstEmi00").setValue("0");*/
          	//dijit.byId("inicio.subTipoEmiItinerante01").setChecked("checked");
    		//dijit.byId("inicio.subTipoEmiItinerante01").setValue("1");
    	}else{
    		dijit.byId("inicio.subTipoEstEmi01").setChecked("checked");
    		dijit.byId("inicio.subTipoEstEmi01").setValue("1");
    		dijit.byId("inicio.subTipoEmiItinerante00").setChecked("checked");
    		dijit.byId("inicio.subTipoEmiItinerante00").setValue("0");
    	}
    },

    showOpcionesEstablecimientoEmisorContin:function(valor){
    	if (valor == 1) {
    		/*dijit.byId("inicio.subTipoDC00").setChecked("checked");
    		dijit.byId("inicio.subTipoDC00").setValue("0");*/
    	}else{
    		dijit.byId("inicio.subTipoDC01").setChecked("checked");
    		dijit.byId("inicio.subTipoDC01").setValue("1");
    	}
    },

	// fin de pase PAS20181U210300235 libros ya presentados y domicilio del cliente

    showOpcionesTrasladoBienes:function(valor){
        if (valor == 1) {
        	dijit.byId("inicio.subTipoEmiItinerante00").setChecked("checked");
        	dijit.byId("inicio.subTipoEmiItinerante00").setValue("0");
            dijit.byId("inicio.subTipoEmiItinerante01").setAttribute('disabled', true);
            dijit.byId("inicio.subTipoEmiItinerante00").setAttribute('disabled', true);

            dijit.byId("inicio.subTipoFEPagoActicipado00").setChecked("checked");
            dijit.byId("inicio.subTipoFEPagoActicipado00").setValue("0");
            dijit.byId("inicio.subTipoFEPagoActicipado01").setAttribute('disabled', true);
            dijit.byId("inicio.subTipoFEPagoActicipado00").setAttribute('disabled', true);

            dijit.byId("inicio.subTipoEstEmi00").setChecked("checked");
            dijit.byId("inicio.subTipoEstEmi00").setValue("0");
            dijit.byId("inicio.subTipoEstEmi01").setAttribute('disabled', true);
            dijit.byId("inicio.subTipoEstEmi00").setAttribute('disabled', true);

            dijit.byId("inicio.subTipoDC00").setChecked("checked");
            dijit.byId("inicio.subTipoDC00").setValue("0");
            dijit.byId("inicio.subTipoDC01").setAttribute('disabled', true);
            dijit.byId("inicio.subTipoDC00").setAttribute('disabled', true);
        }else{
        	dijit.byId("inicio.subTipoEmiItinerante01").setAttribute('disabled', false);
            dijit.byId("inicio.subTipoEmiItinerante00").setAttribute('disabled', false);
            dijit.byId("inicio.subTipoFEPagoActicipado01").setAttribute('disabled', false);
            dijit.byId("inicio.subTipoFEPagoActicipado00").setAttribute('disabled', false);

            dijit.byId("inicio.subTipoEstEmi01").setAttribute('disabled', false);
            dijit.byId("inicio.subTipoEstEmi00").setAttribute('disabled', false);
            dijit.byId("inicio.subTipoDC01").setAttribute('disabled', false);
            dijit.byId("inicio.subTipoDC00").setAttribute('disabled', false);

            dijit.byId("inicio.subTipoEstEmi01").setChecked("checked");
            dijit.byId("inicio.subTipoEstEmi01").setValue("1");
        }
    },

    showOpcionesSujetoRealizaTraslado: function(valor) {
    	if (valor == 1) {  //1 Emisor - vendedor
    		this.showHiddenDiv(document.getElementById("trasladoBienes.sujetoTraslado.show"),true);
    		dijit.byId("trasladoBienes.idModalidadTraslado01").setAttribute('disabled', false);
    		dijit.byId("trasladoBienes.idModalidadTraslado02").setAttribute('disabled', false);
        }else{  // 2 Comprador
        	this.showHiddenDiv(document.getElementById("trasladoBienes.sujetoTraslado.show"),false);
        	this.showHiddenDiv(document.getElementById("trasladoBienes.sujetoTrasladoRUC.show"),false);
      		dijit.byId("trasladoBienes.idModalidadTraslado01").setChecked("checked");  //Transporte Privado
      		dijit.byId("trasladoBienes.idModalidadTraslado01").setValue("1");
      		dijit.byId("trasladoBienes.idModalidadTraslado01").setAttribute('disabled', true);
      		dijit.byId("trasladoBienes.idModalidadTraslado02").setAttribute('disabled', true);
      		dijit.byId("trasladoBienes.placaVehiculo").setValue("");
      		dijit.byId("trasladoBienes.marcaVehiculo").setValue("");
      		dijit.byId("trasladoBienes.nroLicenciaConducir").setValue("");
      		dijit.byId("trasladoBienes.rucTransportista").setValue("");
      		dijit.byId("trasladoBienes.razonSocial").setValue("")
      		dojo.byId("trasladoBienes.razonSocialSel").value = "";
        }
    },

    showOpcionesModalidadTraslado: function(valor) {
    	dojo.byId("trasladoBienes.idModalidadTrasladoSel").value = valor;
        if (valor == 1) {  //1 Privado
        	this.showHiddenDiv(document.getElementById("trasladoBienes.sujetoTrasladoRUC.show"),false);
        	dijit.byId("trasladoBienes.rucTransportista").setValue("");
        	dijit.byId("trasladoBienes.razonSocial").setValue("");
        }else{  // 2 Publico
        	this.showHiddenDiv(document.getElementById("trasladoBienes.sujetoTrasladoRUC.show"),true);
        }
    },

	showExportacion: function(valor) {
		this.showOpcionesExportacion(0);
		if (valor == 1) {
			this.showHiddenDiv(document.getElementById("inicio.exportacion.show"),true);
		} else {
			this.showHiddenDiv(document.getElementById("inicio.exportacion.show"),false);
		}
	},

	showOpcionesExportacion: function(valor) {
		dijit.byId("inicio.subTipoIM00").setChecked("checked");
		dijit.byId("inicio.subTipoIM00").setValue("IM00");
		dijit.byId("inicio.subTipoCargosTribNoBaseImp00").setChecked("checked");
		dijit.byId("inicio.subTipoCargosTribNoBaseImp00").setValue("0");
    	console.log("showOpcionesExportacion="+valor);

		if (valor == 1) {
			/** Oculta:
			 *  gatos deducibles ppnn
			 *  ruc
			 *  isc
			 *  otros tributos y cargos
			 */
			if (dojo.byId("inicio.puedeGastoDeduciblePPNN").value == "1"){
			//if (dijit.byId("inicio.numeroDocumento").getValue() == "1"){
				this.showHiddenDiv(document.getElementById("inicio.deduciblePPNN.show"),false);
  			}

		  	dijit.byId("inicio.subTipoND00").setChecked("checked");
		    dijit.byId("inicio.subTipoND00").setValue("0");
		    dijit.byId("inicio.subTipoND00").setAttribute('disabled', true);
  			dijit.byId("inicio.subTipoND01").setAttribute('disabled', true);
  			this.showHiddenDiv(document.getElementById("inicio.isc.show"),false);
			// PAS20211U210700069
			if (this.getValorOpcionPagoAnticipado()==0){
				this.showHiddenDiv(document.getElementById("inicio.descuentos.show"),true);
			}

			//PAS20181U210300095
			this.showHiddenDiv(document.getElementById("inicio.tipoDocumento.show"),true);

			var tdControl = dijit.byId("inicio.tipoDocumento");
			tdControl.get('store').remove("-");
			tdControl.get('store').remove("1");
			tdControl.get('store').remove("6");
			tdControl.get('store').add({ name: "SIN DOCUMENTO", id: "-"});
			tdControl.get('store').add({ name: "REG. UNICO DE CONTRIBUYENTES", id: "6"});

			//PAS20211U210100010 ---Inicio
			tdControl.get('store').remove("0");
			tdControl.get('store').remove("B");
			tdControl.get('store').remove("C");
			tdControl.get('store').remove("D");
			tdControl.get('store').add({ name: "DOC.TRIB.NO.DOM.SIN.RUC", id: "0"});
			tdControl.get('store').add({ name: "DOC.IDENTIF.PERS.NAT.NO DOM.", id: "B"});
			tdControl.get('store').add({ name: "TAX IDENTIFICATION NUMBER - TIN – DOC TRIB PP.NN", id: "C"});
			tdControl.get('store').add({ name: "IDENTIFICATION NUMBER - IN – DOC TRIB PP. JJ", id: "D"});
			//PAS20211U210100010 ---Fin

			tdControl.setValue("-"); //SIN DOCUMENTO

			this.validateType();
			/*
			this.showHiddenDiv(document.getElementById("inicio.ruc.show"),false);
			this.showHiddenDiv(document.getElementById("inicio.razonSocial.show"),true);
			this.showHiddenDiv(document.getElementById("inicio.cargosTribNoBaseImp.show"),false);
  			*/
			//PAS20181U210300095

  			//this.showHiddenDiv(document.getElementById("inicio.domicilioCliente.show"),false);
  			dojo.byId("inicio.subTipoDC01").checked = false;
  			dojo.byId("inicio.subTipoDC00").checked = true;
  			dojo.byId("global.opcionDomicilioCliente").value = "0";
  			dojo.byId("global.opcionDomicilioClienteDireccion").value = "";

  			dijit.byId("inicio.exportacion.razonSocial").setValue(dojo.byId("global.numeroDocumentoExpDesc").value);
  			dijit.byId("inicio.exportacion.razonSocial").focus();

		} else {
			/** Muestra:
			 *  gatos deducible ppnn
			 *  ruc
			 *  venta gratuita
			 *  isc
			 *  otros tributos y cargos
			 */
			//if (dijit.byId("inicio.numeroDocumento").getValue() == "1"){
			if (dojo.byId("inicio.puedeGastoDeduciblePPNN").value == "1"){
				this.showHiddenDiv(document.getElementById("inicio.deduciblePPNN.show"),true);
				dijit.byId("inicio.subTipoDPPNN00").setChecked("checked");
				//this.showOpcionGastoDeduciblePPNN(0);
			}

		    dijit.byId("inicio.subTipoND00").setAttribute('disabled', false);
			dijit.byId("inicio.subTipoND01").setAttribute('disabled', false);
			//this.showHiddenDiv(document.getElementById("inicio.ventaGratuita.show"),false);   //true);
			this.showHiddenDiv(document.getElementById("inicio.isc.show"),true);
			// PAS20211U210700069
			if (this.getValorOpcionPagoAnticipado()==0){
				this.showHiddenDiv(document.getElementById("inicio.descuentos.show"),true);
			}

			//PAS20181U210300095
			this.showHiddenDiv(document.getElementById("inicio.tipoDocumento.show"),false);
			this.showHiddenDiv(document.getElementById("inicio.ruc.show"),true);
			this.showHiddenDiv(document.getElementById("inicio.razonSocial.show"),false);

			var tdControl = dijit.byId("inicio.tipoDocumento");
			tdControl.get('store').remove("-");
			tdControl.get('store').remove("1");
			tdControl.get('store').remove("6");
			// PAS20211U210700069
			tdControl.get('store').remove("0");
			tdControl.get('store').remove("B");
			tdControl.get('store').remove("C");
			tdControl.get('store').remove("D");

			tdControl.get('store').add({ name: "SIN DOCUMENTO", id: "-"});
			tdControl.get('store').add({ name: "DOC. NACIONAL DE IDENTIDAD", id: "1"});
			tdControl.get('store').add({ name: "REG. UNICO DE CONTRIBUYENTES", id: "6"});
			tdControl.setValue("6"); //SIN DOCUMENTO

			this.validateType();
			/*
			this.showHiddenDiv(document.getElementById("inicio.cargosTribNoBaseImp.show"),true);

			if (this.getValorOpcionPagoAnticipado() == 1){
				this.showHiddenDiv(document.getElementById("inicio.cargosTribNoBaseImp.show"),false);
			}
			*/
			//PAS20181U210300095

			//this.showHiddenDiv(document.getElementById("inicio.domicilioCliente.show"),true);
			//dojo.byId("inicio.tipoDocumento").value="6";
			dijit.byId("inicio.tipoDocumento").setValue(6);
			dijit.byId("inicio.numeroDocumento").attr('maxLength','11');
			var expRazonSocial = dijit.byId("inicio.exportacion.razonSocial");
			expRazonSocial.setValue("");

			dijit.byId("inicio.numeroDocumento").focus();
		}

		document.getElementById("innerContent").style.height = "auto";
		document.getElementById("inicio.form").style.height = "auto";
	},
//PAS20201U210100230 inicio
showOpcionesTransaccion: function(valor) {
	if(this.globalCambiosFactoringHabilitados=="1"){
		console.log("showOpcionesTransaccion="+valor);
		dijit.byId("inicio.facturaFactoring.domicilioFiscal").setValue("");
		if(dojo.byId("inicio.tipoTransaccion")!=null){
			if (valor == 1) {
				this.showHiddenDiv(document.getElementById("inicio.domicilioContribuyente.show"),false);
				dojo.byId("inicio.tipoTransaccion").value = 1;
			}else{//AL CREDITO: 2
				this.showHiddenDiv(document.getElementById("inicio.domicilioContribuyente.show"),true);
				dojo.byId("inicio.direccion.label").innerHTML="Direcci&oacute;n del Contribuyente receptor de la Factura";//PAS20211U210700145-EBV
				//var subTipoEE00 = dijit.byId("inicio.subTipoEE00").getValue();
				dojo.byId("inicio.tipoTransaccion").value = 2;

				if (this.getValorOpcionInicialExportacion() == "0"){
					console.log("showOpcionesTransaccion-exportacion no="+this.getValorOpcionInicialExportacion());//Jrgs
					dijit.byId("inicio.bntdomicilioFiscal").setAttribute('disabled', true);
					var td = dijit.byId("inicio.tipoDocumento").getValue();//Jrgs
					if (td == "1"){ //DNI
						dijit.byId("inicio.bntdomicilioFiscal").setAttribute('disabled', false);
						dojo.byId("inicio.direccion.label").innerHTML="Direcci&oacute;n del Contribuyente receptor de la Factura (Opcional)";//PAS20211U210700145-EBV
					}
					/* INICIO PAS20211U210700145_AVN*/
					else if (td == "6"){ //RUC
						dijit.byId("inicio.bntdomicilioFiscal").setAttribute('disabled', true);
					}else{
						//dijit.byId("inicio.bntdomicilioFiscal").setAttribute('disabled', false);
						this.showHiddenDiv(document.getElementById("inicio.domicilioContribuyente.show"),false);
					}
					/* FIN PAS20211U210700145_AVN*/
				}else if (this.getValorOpcionInicialExportacion() == "1"){
					console.log("showOpcionesTransaccion-exportacion si="+this.getValorOpcionInicialExportacion());//Jrgs
					var td = dijit.byId("inicio.tipoDocumento").getValue();
				/* INICIO PAS20211U210700145_AVN*/
					 if (td == "1"){ //DNI
						dijit.byId("inicio.bntdomicilioFiscal").setAttribute('disabled', false);
					}else if (td == "6"){ //RUC
						dijit.byId("inicio.bntdomicilioFiscal").setAttribute('disabled', true);
					}else{
						//dijit.byId("inicio.bntdomicilioFiscal").setAttribute('disabled', false);
						this.showHiddenDiv(document.getElementById("inicio.domicilioContribuyente.show"),false);
					}
				/* FIN PAS20211U210700145_AVN*/
				}
				this.obtenerDomicilio();
			}
		}
	}
}, //PAS20201U210100230 fin

	showOpcionesNoDomic: function(valor) {
  		if (valor == 1) {
  			this.showOpcionesExportacion(0);
  			this.showHiddenDiv(document.getElementById("inicio.noDomicReceptor.show"),true);
		  	dijit.byId("inicio.subTipoEE00").setChecked("checked");
		    dijit.byId("inicio.subTipoEE00").setValue("0");
		    dijit.byId("inicio.subTipoEE00").setAttribute('disabled', true);
		    dijit.byId("inicio.subTipoEE01").setAttribute('disabled', true);
  			this.showHiddenDiv(document.getElementById("inicio.ruc.show"),false);
  			//this.showHiddenDiv(document.getElementById("inicio.razonSocial.show"),false);

  			//dojo.byId("inicio.tipoDocumento").value="0";
  			dijit.byId("inicio.tipoDocumento").setValue(0);
  			dijit.byId("inicio.numeroDocumento").attr('maxLength','11');
  			var nroDocumento = dijit.byId("inicio.numeroDocumento");
  			nroDocumento.setValue("");

  			var razonSocial = dijit.byId("inicio.razonSocial");
  			razonSocial.setValue("");

  			dijit.byId("inicio.tipoDocRecepFENodomic").focus();
  		} else {
  			this.showOpcionesExportacion(this.getValorOpcionInicialExportacion());
  			this.showHiddenDiv(document.getElementById("inicio.noDomicReceptor.show"),false);
		    dijit.byId("inicio.subTipoEE00").setAttribute('disabled', false);
		    dijit.byId("inicio.subTipoEE01").setAttribute('disabled', false);
		    dijit.byId("inicio.subTipoND00").setAttribute('disabled', false);
		    dijit.byId("inicio.subTipoND01").setAttribute('disabled', false);
  			this.showHiddenDiv(document.getElementById("inicio.ruc.show"),true);
  			//this.showHiddenDiv(document.getElementById("inicio.razonSocial.show"),true);

  			var expRazonSocial = dijit.byId("inicio.exportacion.razonSocial");
  			expRazonSocial.setValue("");

  			dijit.byId("inicio.tipoDocRecepFENodomic").focus();
  		}
	},

	fnOperacionesPorDefecto: function(){
		this.showOpcionesNoDomic(0);
		//this.showOpcionesExportacion(0);
		this.showOpcionesPagoAnticipado(0);
		this.showOpcionesVentaItinerante(0);
		this.showOpcionesEstablecimientoEmisor(1);
		this.showOpcionesDireccionCliente(0);
	},

	fnDisabledAllPorDefecto: function(isDisabled){
		dijit.byId("inicio.subTipoND01").setAttribute('disabled', isDisabled);
		dijit.byId("inicio.subTipoND00").setAttribute('disabled', isDisabled);

		dijit.byId("inicio.subTipoEE01").setAttribute('disabled', isDisabled);
		dijit.byId("inicio.subTipoEE00").setAttribute('disabled', isDisabled);

		dijit.byId("inicio.subTipoFEPagoActicipado01").setAttribute('disabled', isDisabled);
		dijit.byId("inicio.subTipoFEPagoActicipado00").setAttribute('disabled', isDisabled);

		dijit.byId("inicio.subTipoEmiItinerante01").setAttribute('disabled', isDisabled);
		dijit.byId("inicio.subTipoEmiItinerante00").setAttribute('disabled', isDisabled);

		dijit.byId("inicio.subTipoEstEmi01").setAttribute('disabled', isDisabled);
		dijit.byId("inicio.subTipoEstEmi00").setAttribute('disabled', isDisabled);

		dijit.byId("inicio.subTipoDC01").setAttribute('disabled', isDisabled);
		dijit.byId("inicio.subTipoDC00").setAttribute('disabled', isDisabled);

		dijit.byId("inicio.subTipoVentaCombustibleB01").setAttribute('disabled', isDisabled);
		dijit.byId("inicio.subTipoVentaCombustibleB00").setAttribute('disabled', isDisabled);

		dijit.byId("inicio.subTipoDE01").setAttribute('disabled', isDisabled);
		dijit.byId("inicio.subTipoDE00").setAttribute('disabled', isDisabled);

		dijit.byId("inicio.subTipoIM01").setAttribute('disabled', isDisabled);
		dijit.byId("inicio.subTipoIM00").setAttribute('disabled', isDisabled);

		dijit.byId("inicio.subTipoOpeGratuita01").setAttribute('disabled', isDisabled);
		dijit.byId("inicio.subTipoOpeGratuita00").setAttribute('disabled', isDisabled);

		//dijit.byId("inicio.subTipoCargosTribNoBaseImp01").setAttribute('disabled', isDisabled);
		//dijit.byId("inicio.subTipoCargosTribNoBaseImp00").setAttribute('disabled', isDisabled);

		if (isDisabled){
			dijit.byId("inicio.subTipoND00").setChecked("checked");
			dijit.byId("inicio.subTipoEE00").setChecked("checked");
			dijit.byId("inicio.subTipoFEPagoActicipado00").setChecked("checked");
			dijit.byId("inicio.subTipoEmiItinerante00").setChecked("checked");
			dijit.byId("inicio.subTipoEstEmi01").setChecked("checked");
			dijit.byId("inicio.subTipoDC00").setChecked("checked");
			dijit.byId("inicio.subTipoVentaCombustibleB00").setChecked("checked");
			dijit.byId("inicio.subTipoDE00").setChecked("checked");
			dijit.byId("inicio.subTipoIM00").setChecked("checked");
			dijit.byId("inicio.subTipoOpeGratuita00").setChecked("checked");
			//dijit.byId("inicio.subTipoCargosTribNoBaseImp00").setChecked("checked");
		}
	},

	showOpcionGastoDeduciblePPNN: function(valor) {
		dijit.byId("inicio.numeroDocumento").setValue("");

		if (valor == 1) {
			this.fnOperacionesPorDefecto();
			this.fnDisabledAllPorDefecto(true);

			if (dojo.byId("inicio.subTipoDPPNN01").checked == false){
				dijit.byId("inicio.subTipoDPPNN01").setChecked("checked");
			}
			dojo.byId("inicio.ruc.label").innerHTML="Consigne el Documento de Identidad del Contribuyente ";
			this.showHiddenDiv(document.getElementById("inicio.tipoDocumento.show"),true);
			dijit.byId("inicio.tipoDocumento").setValue(1); // DNI
			this.validateType();

			dojo.byId("global.gastoDeduciblePPNN").value = 1;

			//PAS20181U210300095
			this.showHiddenDiv(document.getElementById("inicio.razonSocial.show"),false);
			dijit.byId("inicio.tipoDocumento").get('store').remove("-"); //Remover SIN DOCUMENTO
		} else {
			this.fnDisabledAllPorDefecto(false);

			if (dojo.byId("inicio.subTipoDPPNN00").checked == false){
				dijit.byId("inicio.subTipoDPPNN00").setChecked("checked");
			}
			dojo.byId("inicio.ruc.label").innerHTML="Consigne el RUC del Contribuyente Receptor de la Factura ";
			this.showHiddenDiv(document.getElementById("inicio.tipoDocumento.show"),false);
			dijit.byId("inicio.tipoDocumento").setValue(6); //RUC
			this.validateType();

			dojo.byId("global.gastoDeduciblePPNN").value = 0;
		}

		document.getElementById("innerContent").style.height = "auto";
		document.getElementById("inicio.form").style.height = "auto";
		dijit.byId("inicio.numeroDocumento").focus();
	},

	showOpcionesPagoAnticipado: function(valor) {
	   if (valor == 1) {
	   		this.showOpcionesExportacion(this.getValorOpcionInicialExportacion());
		    dijit.byId("inicio.subTipoCargosTribNoBaseImp00").setChecked("checked");
		    dijit.byId("inicio.subTipoCargosTribNoBaseImp00").setValue("0");
		    dijit.byId("inicio.subTipoDE00").setChecked("checked");
		    dijit.byId("inicio.subTipoDE00").setValue("DE00");
		    dijit.byId("inicio.subTipoOpeGratuita00").setChecked("checked");
		    dijit.byId("inicio.subTipoOpeGratuita00").setValue("0");

		    this.showHiddenDiv(document.getElementById("inicio.descuentos.show"),false);
			this.showHiddenDiv(document.getElementById("inicio.cargosTribNoBaseImp.show"),false);
			this.showHiddenDiv(document.getElementById("inicio.operacionesGratuitas.show"),false);

        	dijit.byId("inicio.subTipoEmiItinerante00").setChecked("checked");
        	dijit.byId("inicio.subTipoEmiItinerante00").setValue("0");
            dijit.byId("inicio.subTipoEmiItinerante01").setAttribute('disabled', true);
            dijit.byId("inicio.subTipoEmiItinerante00").setAttribute('disabled', true);
        	dijit.byId("inicio.subTipoTrasladoB00").setChecked("checked");
        	dijit.byId("inicio.subTipoTrasladoB00").setValue("0");
            dijit.byId("inicio.subTipoTrasladoB01").setAttribute('disabled', true);
            dijit.byId("inicio.subTipoTrasladoB00").setAttribute('disabled', true);
	   }else{
		   this.showHiddenDiv(document.getElementById("inicio.descuentos.show"),true);
		   this.showHiddenDiv(document.getElementById("inicio.cargosTribNoBaseImp.show"),true);
		   this.showHiddenDiv(document.getElementById("inicio.operacionesGratuitas.show"),true);
		   this.showOpcionesExportacion(this.getValorOpcionInicialExportacion());
		   // PAS20211U210700069
		   //if (this.getValorOpcionInicialExportacion() == 1){
           //   this.showHiddenDiv(document.getElementById("inicio.cargosTribNoBaseImp.show"),false);
		   //}
		   dijit.byId("inicio.subTipoEmiItinerante01").setAttribute('disabled', false);
		   dijit.byId("inicio.subTipoEmiItinerante00").setAttribute('disabled', false);
		   dijit.byId("inicio.subTipoTrasladoB01").setAttribute('disabled', false );
		   dijit.byId("inicio.subTipoTrasladoB00").setAttribute('disabled', false);
	   }
	},

	showHiddenDiv: function(node,show) {
		if(node!=null){
			if (show == true) { //Mostrar
				node.style.display = "";
			} else { //Ocultar
				node.style.display = "none";
			}
		}
	},

	showTipoBeneficio: function(valor) {   //Afectacion al IGV
		var valOpcionAnticipio = parseInt(this.getValorOpcionAnticipo());
		if (valor == 1){
			if (valOpcionAnticipio == 1){
			}else{
        		dijit.byId("item.subTipoTB00").setChecked("");
        		dijit.byId("item.subTipoTB01").setChecked("");
        		dijit.byId("item.subTipoTB02").setChecked("");

        		this.showHiddenDiv(document.getElementById("item.divTipoBeneficio.show"),true);
  		     	dojo.byId("item.igvPorcentaje").value = dojo.byId("global.igvPorcentaje").value;
    			dijit.byId("item.subTipoTB00").setChecked("checked");
    			dijit.byId("item.subTipoTB00").attr("disabled",false);
    			dijit.byId("item.subTipoTB01").attr("disabled",false);
    			dijit.byId("item.subTipoTB02").attr("disabled",false);
			}
			if (dojo.byId("item.valOpcTipoBS").value == "TI02"){    //Si es servicio
				var valTipoBonif = this.getValorOpcionTipoBonif();
				if (valTipoBonif == "BO01") {
					dijit.byId("item.subTipoTB02").setChecked("checked");
					dojo.byId("item.igvPorcentaje").value="0";
					dijit.byId("item.precioConIGV").setValue(0, false);
					dijit.byId("item.subTipoTB00").attr("disabled",true);
					dijit.byId("item.subTipoTB01").attr("disabled",true);
					dijit.byId("item.subTipoTB02").attr("disabled",true);
				}
			}
		} else {
			dijit.byId("item.subTipoTB00").setChecked("");
			dijit.byId("item.subTipoTB01").setChecked("");
			dijit.byId("item.subTipoTB02").setChecked("");
			this.showHiddenDiv(document.getElementById("item.divTipoBeneficio.show"),false);
			dojo.byId("item.igvPorcentaje").value="0";
			dijit.byId("item.subTipoTB00").attr("disabled",true);
			dijit.byId("item.subTipoTB01").attr("disabled",true);
			dijit.byId("item.subTipoTB02").attr("disabled",true);
		}
		this.resetValIGV();
	},

	validarMontoIGV: function() {
		var igvPorcentaje =dojo.byId("item.igvPorcentaje").value;
		var moneda = dijit.byId("inicio.tipoMoneda").getValue();
		var cantidadXPrecio = dijit.byId("item.cantidad").getValue() * dijit.byId("item.precioUnitario").getValue();
		var precioDescuento = dijit.byId("item.precioDescuento").getValue();
		var totalConDescuento = cantidadXPrecio - precioDescuento;
		var igvMonto =  ((totalConDescuento * igvPorcentaje) / 100);

		var valMontoIGV = dijit.byId("item.precioConIGV").getValue();
		if (valMontoIGV == igvMonto) {
			dijit.byId("item.precioConIGV").setValue(dojo.currency.format(igvMonto, {currency: moneda, places: '2,10'}));//PAS20211U210100007
		} else {
			dijit.byId("item.precioConIGV").setValue("");
			this.attr('invalidMessage', "item.precioConIGV", "Monto ingresado del IGV es incorrecto.");
			dijit.byId("item.precioConIGV").focus();
			return;
		}
	},

	cargarValoresGlobales: function() {
		//dojo.byId("global.origenInvocacionItem").value = "";
		dojo.byId("global.numeroDocumento").value = dijit.byId("inicio.numeroDocumento").getValue();
		dojo.byId("global.numeroDocumentoDesc").value = dijit.byId("inicio.razonSocial").getValue();
		dojo.byId("global.numeroDocumentoExpDesc").value = dijit.byId("inicio.exportacion.razonSocial").getValue();
		dojo.byId("global.tipoMoneda").value = dojo.trim(dijit.byId("inicio.tipoMoneda").getValue().substring(0,3));
		/*Inicio SAU20156R120400552*/
	    if(dojo.byId("global.tipoMoneda").value=="XEU"){
			  dojo.byId("global.tipoMoneda").value = "EUR"
	    }
	    /*Fin SAU20156R120400552*/

		dojo.byId("global.tipoMonedaDesc").value = dojo.trim(dijit.byId("inicio.tipoMoneda").getValue().substring(6,25));
		dojo.byId("global.tipoMonedaDescLarge").value = dojo.trim(dijit.byId("inicio.tipoMoneda").getValue());
		dojo.byId("global.opcionDscto").value = this.getValorOpcionDscto();
		dojo.byId("global.opcionExportacion").value = this.getValorOpcionInicialExportacion();
		if(dojo.byId("global.opcionTipoTransaccion")!=null){
			dojo.byId("global.opcionTipoTransaccion").value = this.getValorOpcionInicialTransaccion();//PAS20201U210100230
		}


		dojo.byId("global.opcionNodomic").value = this.getValorOpcionInicialNoDomic();
		dojo.byId("global.opcionISC").value = this.getValorOpcionISC();
		dojo.byId("global.opcionOperacionesGratuitas").value = this.getValorOpcionInicialOperacionesGratuitas();
		dojo.byId("global.opcionOtrosCargosTributos").value = this.getValorOpcionInicialCargosTrib();
		dojo.byId("global.opcionFESectorPublico").value = this.getValorOpcionFESectorPublico();
		dojo.byId("global.opcionPagoAnticipado").value = this.getValorOpcionPagoAnticipado();
		dojo.byId("global.opcionPagoDeduccionAnticipado").value = this.getValorOpcionPagoDeduccionAnticipado();
		dojo.byId("global.opcionVentaItinerante").value = this.getValorOpcionVentaItinerante();
		dojo.byId("global.opcionEstablecimientoEmisor").value = this.getValorEstablecimientoEmisor();
		dojo.byId("global.opcionDomicilioCliente").value = this.getValorOpcionDomicilioCliente();
		dojo.byId("global.opcionSustentoTrasladoBienes").value = this.getValorOpcionSustentoTrasladoBienes();
		dojo.byId("global.opcionPlacaVehiculo").value = this.getValorOpcionVentaCombustible();

		dojo.byId("global.opcionSPOT").value = this.getValorOpcionSPOT();
		dijit.byId("inicio.numeroDocumento").attr('maxLength','11');

		//PAS20181U210300095
		dojo.byId("global.tipoDocumento").value = dijit.byId("inicio.tipoDocumento").getValue();

		if (dojo.byId("global.opcionExportacion").value == "1") {
			dojo.byId("global.igvPorcentaje").value = "0.00";
		} else {
			dojo.byId("global.igvPorcentaje").value = dojo.byId("global.igvPorcentajeInicial").value /100;
		}

		dojo.byId("global.tipoDocumentoNodomic").value = dojo.trim(dijit.byId("inicio.tipoDocRecepFENodomic").getValue().substring(4,55));
		dojo.byId("global.numeroDocumentonoDomic").value = dojo.trim( dijit.byId("inicio.numeroDocRecepFENodomic").getValue());
		dojo.byId("global.razonSocialNoDomic").value = dojo.trim( dijit.byId("inicio.nombreRazonRecepFENodomic").getValue());
		if (dojo.byId("global.opcionNodomic").value == "1") {
			dojo.byId("global.numeroDocumentoExpDesc").value =dojo.trim( dijit.byId("inicio.nombreRazonRecepFENodomic").getValue());
			dojo.byId("global.tipoDocumento").value = dojo.trim(dijit.byId("inicio.tipoDocRecepFENodomic").getValue().substring(0,1));
			dojo.byId("global.numeroDocumento").value = dojo.trim( dijit.byId("inicio.numeroDocRecepFENodomic").getValue());

			dojo.byId("global.nacionalidadNoDomic").value = dojo.trim(dijit.byId("inicio.nacionalidadRecepFENodomic").getValue().substring(0,4));
			dojo.byId("global.nacionalidadNoDomicDesc").value = dojo.trim(dijit.byId("inicio.nacionalidadRecepFENodomic").getValue().substring(6,65));
			dojo.byId("global.tamNoDomic").value = dojo.trim(dijit.byId("inicio.tamRecepFENoDomic").getValue());
			dojo.byId("global.fecIngresoPaisNoDomic").value = dojo.date.locale.format(dijit.byId('inicio.fecIngresoPaisRecepFENoDomic').getValue(), {datePattern: "MM/dd/yyyy", selector: "date"});
			dojo.byId("global.tipoTarjetaNoDomic").value = dojo.trim(dijit.byId("inicio.tipoTarjetaRecepFENodomic").getValue().substring(0,1));
			dojo.byId("global.numeroTarjetaNoDomic").value = dijit.byId("inicio.numeroTarjetaRecepFENodomic").getValue();
			dojo.byId("global.bancoTarjetaNoDomic").value = dojo.trim(dijit.byId("inicio.bancoEmisorTarjetaRecepFENodomic").getValue());
		}
	},

	resetValoresGlobales: function(flagAllowResetDisplay) {
		dojo.byId("global.modo").value = "00";
		dojo.byId("global.numeroDocumento").value = "";
		dojo.byId("global.numeroDocumentoDesc").value = "";
		dojo.byId("global.numeroDocumentoExpDesc").value = "";
		dojo.byId("global.tipoMoneda").value = "";
		dojo.byId("global.tipoMonedaDesc").value = "";

		dojo.byId("global.tipoMonedaDescLarge").value = "";

		dojo.byId("global.opcionDscto").value = "";
		dojo.byId("global.opcionExportacion").value = "0";
		if(dojo.byId("global.opcionTipoTransaccion")!=null){
			dojo.byId("global.opcionTipoTransaccion").value = "1";//PAS20201U210100230
		}
		if(dojo.byId("global.puedeEmitirRetencion")!=null){
		dojo.byId("global.puedeEmitirRetencion").value = "1";//PAS20201U210100230
		}
		dojo.byId("global.opcionNodomic").value = "0";
		dojo.byId("global.opcionISC").value = "";
		dojo.byId("global.opcionOro").value = "";
		dojo.byId("global.opcionSPOT").value = "";
		dojo.byId("global.opcionOperacionesGratuitas").value = "0";
		dojo.byId("global.opcionFESectorPublico").value = "0";
		dojo.byId("global.opcionPagoAnticipado").value = "0";
		dojo.byId("global.opcionPagoDeduccionAnticipado").value = "DE00";
		dojo.byId("global.opcionVentaItinerante").value ="0";
		dojo.byId("global.opcionEstablecimientoEmisor").value = "0";
		dojo.byId("global.opcionEstablecimientoEmisorIdentifica").value = "";
		dojo.byId("global.opcionEstablecimientoEmisorDireccion").value = "";
		dojo.byId("global.opcionEstablecimientoEmisorSeleccionado").value = "";
		dojo.byId("global.opcionDomicilioCliente").value =  "0";
		dojo.byId("global.opcionDomicilioClienteIdentifica").value = "";
		dojo.byId("global.opcionDomicilioClienteDireccion").value =  "";
		dojo.byId("global.opcionDomicilioClienteSeleccionado").value =  "";
		dojo.byId("global.opcionPuntoLlegadaSeleccionado").value =  "";
		dojo.byId("global.opcionPuntoPartidaSeleccionado").value =  "";
		dojo.byId("global.opcionSustentoTrasladoBienes").value =  "0";
		dojo.byId("global.gastoDeduciblePPNN").value = "0";

		dojo.byId("global.fecVencimiento").value = "";
		dojo.byId("global.fecEmision").value = "";
		if(dojo.byId("global.opcionTipoTransaccion")!=null){
			dojo.byId("global.montoRedondeo").value = "0.00"; //PAS20201U210100285 - jmendozas
		}
		dojo.byId("global.opcionOro").value = "";
		dojo.byId("global.opcionSPOT").value = "";
		dojo.byId("global.opcionPlacaVehiculo").value =  "0";

		dojo.byId("global.tipoDocumento").value = "6";
		//dojo.byId("global.tipoVenta").value="";

		dojo.byId("global.igvPorcentaje").value = dojo.byId("global.igvPorcentajeInicial").value /100; //"0.19";

		dojo.byId("global.docsrel.localAsoc").value = "0000";
		dojo.byId("global.docsrel.observacion").value = "";
		dojo.byId("global.docsrel.placaVentaCombustible").value = "";

		// Ini PAS20201U210100097 APDEX
		if(dojo.byId("global.numeroExpediente") != null) dojo.byId("global.numeroExpediente").value = "";
		if(dojo.byId("global.ordenCompra") != null) dojo.byId("global.ordenCompra").value = "";
		if(dojo.byId("global.numeroProcesoSeleccion") != null) dojo.byId("global.numeroProcesoSeleccion").value = "";
		if(dojo.byId("global.codigoUnidadEjecutora") != null) dojo.byId("global.codigoUnidadEjecutora").value = "";
		if(dojo.byId("global.numeroContrato") != null) dojo.byId("global.numeroContrato").value = "";
		// Fin PAS20201U210100097 APDEX
		dojo.byId("global.opcionEstablecimientoEmisorSeleccionado").value ="";
		dojo.byId("global.opcionEstablecimientoEmisorIdentifica").value ="";
		// Ini PAS20201U210100097 APDEX
		//dojo.byId("trasladoBienes.puntoPartidaDesc").value ="";
		//dojo.byId("trasladoBienes.puntoLlegadaDesc").value ="";
		// Fin PAS20201U210100097 APDEX

		//dojo.byId("infAdic.numeroExpediente").value="";
		if(dojo.byId("infAdic.numeroExpediente") != null) dojo.byId("infAdic.numeroExpediente").value = "";
	    //dojo.byId("infAdic.ordenCompra").value="";
		if(dojo.byId("infAdic.ordenCompra") != null) dojo.byId("infAdic.ordenCompra").value = "";
		//dojo.byId("infAdic.codigoUnidadEjecutora").value="";
		if(dojo.byId("infAdic.codigoUnidadEjecutora") != null) dojo.byId("infAdic.codigoUnidadEjecutora").value = "";
		//dojo.byId("infAdic.numeroProcesoSeleccion").value="";
		if(dojo.byId("infAdic.numeroProcesoSeleccion") != null) dojo.byId("infAdic.numeroProcesoSeleccion").value = "";
		//dojo.byId("infAdic.numeroContrato").value="";
		if(dojo.byId("infAdic.numeroContrato") != null) dojo.byId("infAdic.numeroContrato").value = "";


		//this.limpiarFormulariosAsincronos("infAdic.form");

		// Ini PAS20201U210100097 APDEX
/* 		dojo.byId("trasladoBienes.rucTransportista").value="";
		dojo.byId("trasladoBienes.razonSocial").value="";
		dojo.byId("trasladoBienes.placaVehiculo").value="";
		dojo.byId("trasladoBienes.marcaVehiculo").value="";
		dojo.byId("trasladoBienes.nroLicenciaConducir").value=""; */
		// Fin PAS20201U210100097 APDEX

		/*
		dojo.byId("trasladoBienes.idSujetoRealizaTraslado01").value="";
		dojo.byId("trasladoBienes.idSujetoRealizaTraslado02").value="";
		dojo.byId("trasladoBienes.idModalidadTraslado01").value="";
		dojo.byId("trasladoBienes.idModalidadTraslado02").value="";
		*/


		this.limpiarFormulariosAsincronos("divFacturaDocRelItem");
		this.limpiarFormulariosAsincronos("divFacturaInformacionRelSP");

		//if(flagAllowResetDisplay) {
			this.limpiarFormulariosAsincronos("divFacturaItem");
			//this.inicializarFacturaItem();
		//}

		this.limpiarFormulariosAsincronos("divFacturaEstablecimientoEmisor");
		this.limpiarFormulariosAsincronos("divFacturaDireccionCliente");

		if (dojo.byId("global.opcionTipoTransaccion")!=null){
			this.limpiarFormulariosAsincronos("divFacturaFactoringDireccionReceptor"); //PAS20201U210100230
			this.limpiarFormulariosAsincronos("divFacturaFactoringRetencion"); //PAS20201U210100230

			this.limpiarInformacionRetencion(); //PAS20201U210100230
			//PAS20201U210100230   INI 	LIMPIEZA DE INFCREDITO y INF CUOTA	OPV
			this.limpiarInfCreditoYCuota();
			this.limpiarFormulariosAsincronos("divFacturaInformacionCreditoItem");
			this.limpiarFormulariosAsincronos("divFacturaInformacionCuota");
			//PAS20201U210100230	FIN  OPV
		}
	},

	// PAS20201U210100097 APDEX Se necesita limpiar formularios de esta manera ya que volveran a ser llenados.
	limpiarFormulariosAsincronos: function(formulariosAsincronos) {
		//Recorre los elementos del div, que le pasas y los quita del registro.
		dojo.forEach(dijit.findWidgets(dojo.byId(formulariosAsincronos)), function(w) {
		w.destroyRecursive();
		});
	},
	// PAS20201U210100097 APDEX

	nuevoItem: function() {
		console.log("-----------");

		/* Inicio PAS20201U210100285 - Pago Anticipado */
		if (dojo.byId("global.opcionPagoDeduccionAnticipado").value == "DE01") {
			require(["dijit/registry"], function(registry){
				var formItems = registry.byId("item.form");
				formItems.reset();
			});
		}
		/* Fin PAS20201U210100285 - Pago Anticipado */

		var moneda = dojo.byId("global.tipoMoneda").value;
		var totalItems = this.getTotalItemsEnGrid();

		//PAS20191U210100075
		monedades = dojo.byId("global.tipoMonedaDesc").value;

		dijit.byId("check.impuestoBolsasPlastica00").attr('disabled',false);
		dijit.byId("check.impuestoBolsasPlastica01").attr('disabled',false);
		dijit.byId("item.cantidad").attr('disabled',false);

		if(monedades != "SOLES"){
			dijit.byId("item.impuestoICBPER").constraints = {currency:moneda, places:2};
			dijit.byId("item.impuestoICBPER").attr('value',dijit.byId("item.impuestoICBPER").getValue());

			var valOpcionImpuestoBolsaPlastica = this.getValorOpcionImpuestoBolsaPlastica();

			console.log(valOpcionImpuestoBolsaPlastica);

			if (valOpcionImpuestoBolsaPlastica != "IBP00"){
				dijit.byId("item.impuestoICBPER").attr('disabled',true);

			}else{
				dijit.byId("item.impuestoICBPER").attr('disabled',false);
			}
		}

		dijit.byId("check.impuestoBolsasPlastica01").setChecked("checked");

		var valueIcbper = document.getElementById('factura.totalICBPERConting');

		console.log(valueIcbper);

		if (valueIcbper != undefined){
			this.viewCheckedImpuestoBolsaPlastica();
			this.showHiddenDiv(document.getElementById("item.ICBPER1.show"),true);
			this.showHiddenDiv(document.getElementById("item.ICBPER2.show"),true);
		}else{
			this.viewCheckedImpuestoBolsaPlastica();
			this.showHiddenDiv(document.getElementById("item.ICBPER1.show"),false);
			this.showHiddenDiv(document.getElementById("item.ICBPER2.show"),false);
		}

		//PAS20191U210100075
		if(totalItems == 20) {
			var node = dijit.byId("item.botonAceptar").focusNode;
			mostrarMensaje("El máximo número de ítems a ingresar no debe exceder de 20.");
			return;
		}

		dojo.byId("item.igvPorcentaje").value = dojo.byId("global.igvPorcentaje").value;
		var labeIgvPorcentaje = dojo.byId("global.igvPorcentaje").value;
		if (labeIgvPorcentaje < 1){
			labeIgvPorcentaje = labeIgvPorcentaje * 100;
		}
		document.getElementById("item.labelIgvPorcentaje").innerHTML = "IGV (" + labeIgvPorcentaje + "%)";

		this.dialogItem.attr('title', "Nuevo Item");
		dojo.byId("item.idItem").value = "0";
		dojo.byId("item.action").value = "adicionarItem";

		dijit.byId("item.subTipoTI01").setChecked("");
		dijit.byId("item.subTipoTI02").setChecked("");
		dijit.byId("item.subTipoBO00").setChecked("");
		dijit.byId("item.subCT01").setChecked("");
		dijit.byId("item.subCT02").setChecked("");
		//PAS20181U210300095
		//dijit.byId("item.subCT02").attr('disabled', false);
		this.showHiddenDiv(document.getElementById("item.divOtrosTributos1.show"),true);
		this.showHiddenDiv(document.getElementById("item.divOtrosTributos2.show"),true);

		dojo.byId("item.valOpcTipoBS").value="";
		dojo.byId("item.valOpcPagoAnticipado").value="0";
		dijit.byId("item.subTipoPagoAnticipado0").attr('checked', false) ;
		this.showHiddenDiv(document.getElementById("item.divFEPagoAnticipado.show"),false);
		dijit.byId("item.facturaAnticipoSerie").attr('value',"");
		dijit.byId("item.facturaAnticipoNumero").attr('value',"");
		dijit.byId("item.facturaAnticipoMonto").attr('value',"");
		if (dojo.byId("item.montoRedondeoAux") != null){ /* PAS20201U210100285 - Factura Contingencia */
			dojo.byId("item.montoRedondeoAux").value="0";// PAS20201U210100285 - jmendozas
		}

		// INICIO PAS20201U210100161
		sessionStorage.clear();
        if(totalItems == 0) {
			dijit.byId("item.unidadMedida").attr("value", "NIU");
			dijit.byId("item.unidadMedida").attr('disabled',false);
			sessionStorage.setItem("undMedida",dijit.byId("item.unidadMedida").getValue());
        } else {
			dijit.byId("item.unidadMedida").value=JSON.parse(sessionStorage.getItem("undMedida"));
			dijit.byId("item.unidadMedida").attr("value", "NIU"); /* PAS20201U210100285 - Pago Anticipado */
			dijit.byId("item.unidadMedida").attr('disabled',false);
        }
		// FIN PAS20201U210100161

		dijit.byId("item.cantidad").attr('value',1);
		dijit.byId("item.codigoItem").attr('value',"");
		dijit.byId("item.descripcion").attr('value',"");
		dijit.byId("item.precioUnitario").constraints = {currency:moneda, places: '2,10'};
		dijit.byId("item.precioUnitario").attr('value',0);
		dijit.byId("item.precioDescuento").constraints = {currency:moneda, places:2};
		dijit.byId("item.precioDescuento").attr('value',0);
		dijit.byId("item.sistemaIsc").attr('value',"0");
		dijit.byId("item.iscPorcentaje").attr('disabled', true);
		dijit.byId("item.iscPorcentaje").attr('value',0);
		dijit.byId("item.iscMonto").constraints = {currency:moneda, places:2};
		dijit.byId("item.iscMonto").attr('value',0);
		dijit.byId("item.precioConIGV").constraints = {currency:moneda, places:'2,10'};///PAS20211U210100007
		dijit.byId("item.precioConIGV").attr('value',0);
		dijit.byId("item.importeVenta").constraints = {currency:moneda, places:2};
		dijit.byId("item.importeVenta").attr('value',0);

		if (dojo.byId("global.opcionExportacion").value == "1") {
			this.showTipoBeneficio(0);
		} else{
			this.showTipoBeneficio(1);  //Mostramos igv
		}

		if (dojo.byId("global.opcionISC").value == "IM00") {
			dijit.byId("item.sistemaIsc").attr("disabled",true);
			dijit.byId("item.iscPorcentaje").attr("disabled",true);
			dijit.byId("item.iscMonto").attr("disabled",true);
		} else {
			dijit.byId("item.sistemaIsc").attr("disabled",false);
			dijit.byId("item.iscPorcentaje").attr("disabled",false);
			dijit.byId("item.iscMonto").attr("disabled",false);
		}

		if (dojo.byId("global.opcionDscto").value == "DE00") {
			dijit.byId("item.precioDescuento").attr("disabled",true);
		} else {
			dijit.byId("item.precioDescuento").attr("disabled",false);
		}

		if (dojo.byId("global.opcionExportacion").value == "1") {
  			dijit.byId("item.subTipoBO00").setValue("BO00");
  			dijit.byId("item.subTipoBO00").setChecked("");
		}

		if (dojo.byId("global.opcionNodomic").value == "1") {
			dijit.byId("item.subTipoTI01").setChecked("checked");
			dijit.byId("item.subTipoTI02").setChecked("");
			dijit.byId("item.subTipoTI02").setAttribute('disabled', true);
			dojo.byId("item.valOpcTipoBS").value="TI01";
		}else{
			dijit.byId("item.subTipoTI02").setAttribute('disabled', false);
		}

		if (dojo.byId("global.gastoDeduciblePPNN").value == "1") {
			dijit.byId("item.subTipoTI01").setChecked("");
			dijit.byId("item.subTipoTI01").setAttribute('disabled', true);
		}

		dojo.byId("item.valOpcTipoCTItem").value="0";

		if (dojo.byId("global.opcionOtrosCargosTributos").value == "1") {
         	this.showHiddenDiv(document.getElementById("item.divOtrosCargosTributos.show"),true);

			//PAS20181U210300095
			if (dojo.byId("global.opcionExportacion").value == "1"){
				//dijit.byId("item.subCT02").attr('disabled', true);
				this.showHiddenDiv(document.getElementById("item.divOtrosTributos1.show"),false);
				this.showHiddenDiv(document.getElementById("item.divOtrosTributos2.show"),false);
			}
		}else{
			this.showHiddenDiv(document.getElementById("item.divOtrosCargosTributos.show"),false);
		}

		if (dojo.byId("global.opcionNodomic").value == "1") {
			this.showHiddenDiv(document.getElementById("item.divOtrosCargosTributos.show"),false);
		}

		dijit.byId("item.operacionGratuita1").setValue("00");
		if (dojo.byId("global.opcionOperacionesGratuitas").value == "1") {
			this.showHiddenDiv(document.getElementById("item.divOperacionGratuita.show"),true);
			//this.showHiddenDiv(document.getElementById("item.divOperacionGratuitaCombo.show"),true);
		}else{
				this.showHiddenDiv(document.getElementById("item.divOperacionGratuita.show"),false);
				this.showHiddenDiv(document.getElementById("item.divOperacionGratuitaCombo.show"),false);
		}
		if (dojo.byId("global.opcionPagoAnticipado").value == "1") {
			this.showHiddenDiv(document.getElementById("item.divPagoAnticipado.show"),false);
			dijit.byId("item.subTipoPagoAnticipado0").attr('checked', false ) ;
		}else{
			if (dojo.byId("global.opcionDscto").value == "DE00") {
				this.showHiddenDiv(document.getElementById("item.divPagoAnticipado.show"),false);
				dijit.byId("item.subTipoPagoAnticipado0").attr('checked', false ) ;
   			} else {
   				this.showHiddenDiv(document.getElementById("item.divPagoAnticipado.show"),true);
   				dijit.byId("item.subTipoPagoAnticipado0").attr('checked', false ) ;
   				this.viewCheckedAnticipo();
   			}
		}

		if (dojo.byId("global.opcionOro").value == "1") {
			this.showHiddenDiv(document.getElementById("item.divFEComercioOro.show"),true);
		} else {
			this.showHiddenDiv(document.getElementById("item.divFEComercioOro.show"),false);
		}

		if (dojo.byId("global.opcionSPOT").value == "1") {
			this.showHiddenDiv(document.getElementById("item.divFESPOT.show"),true);
		} else {
			this.showHiddenDiv(document.getElementById("item.divFESPOT.show"),false);
		}

		this.updateItemAmount();
		//this.showHiddenDiv(document.getElementById("dialogItem"),true);
		this.dialogItem.show();
	},

	editItem: function(identificador) {
		this.editItemRegular(identificador);
	},

	editItemRegular: function(identificador) {
		var row;

		/* Inicio PAS20201U210100285 - Pago Anticipado */
		if (dojo.byId("global.opcionPagoDeduccionAnticipado").value == "DE01") {
			require(["dijit/registry"], function(registry){
				var formItems = registry.byId("item.form");
				formItems.reset();
			});
		}
		/* Fin PAS20201U210100285 - Pago Anticipado */

		this.store.fetchItemByIdentity({
		    identity: identificador,
		    onItem : function(item, request) {
		        row = item;
		    },
		    onError : function(item, request) {
				mostrarMensaje("Ocurrio un error al ubicar el documento");
				return;
		    }
		});

		dijit.byId("item.botonAceptar").attr('disabled', false);
		var moneda = dojo.byId("global.tipoMoneda").value;

		this.dialogItem.attr('title', "Editando Item");
		dojo.byId("item.action").value = "editarItem";
		dojo.byId("item.idItem").value = this.store.getValue(row, "identificador");
		dijit.byId("item.subTipoTB00").attr("disabled",false);
		dijit.byId("item.subTipoTB01").attr("disabled",false);
		dijit.byId("item.subTipoTB02").attr("disabled",false);

		if (this.store.getValue(row, "tipoItem") != "TI00") {
			dojo.byId("item.valOpcTipoBS").value=dijit.byId("item.subTipo" + this.store.getValue(row, "tipoItem")).getValue();
			dijit.byId("item.subTipo" + this.store.getValue(row, "tipoItem")).setChecked("checked");
			dijit.byId("item.subTipo" + this.store.getValue(row, "tipoItem")).setValue(this.store.getValue(row, "tipoItem"));

		}else{
			dijit.byId("item.subTipoTI01").setChecked("");
			dijit.byId("item.subTipoTI02").setChecked("");
			dojo.byId("item.valOpcTipoBS").value="";
		}

		if (dojo.byId("global.gastoDeduciblePPNN").value == "1") {
			dijit.byId("item.subTipoTI01").setChecked("");
			dijit.byId("item.subTipoTI01").setAttribute('disabled', true);
		}

		if (this.store.getValue(row, "tipoOtrosCargosTributos") == "1" || this.store.getValue(row, "tipoOtrosCargosTributos") == "2" ) {
			dojo.byId("item.valOpcTipoCTItem").value= this.store.getValue(row, "tipoOtrosCargosTributos");//dijit.byId("item.subCT0" + this.store.getValue(row, "tipoOtrosCargosTributos")).getValue();
			dijit.byId("item.subCT0" + this.store.getValue(row, "tipoOtrosCargosTributos")).setChecked("checked");
			dijit.byId("item.subCT0" + this.store.getValue(row, "tipoOtrosCargosTributos")).setValue(this.store.getValue(row, "tipoOtrosCargosTributos"));
		}else{
			dijit.byId("item.subCT01").setChecked("");
			dijit.byId("item.subCT02").setChecked("");
			dojo.byId("item.valOpcTipoCTItem").value="";
		}

		if (this.store.getValue(row, "tipoBonificacion") == "BO01") {
			dijit.byId("item.subTipoBO00").setChecked("checked");
			dijit.byId("item.subTipoBO00").setValue(this.store.getValue(row, "tipoBonificacion"));

			if (this.store.getValue(row, "tipoBeneficio") != "") {
				dijit.byId("item.subTipo" + this.store.getValue(row, "tipoBeneficio")).setChecked("");
				dijit.byId("item.subTipo" + this.store.getValue(row, "tipoBeneficio")).setValue(this.store.getValue(row, "tipoBeneficio"));
				this.showHiddenDiv(document.getElementById("item.divTipoBeneficio.show"),false);
			}
		} else {
			dijit.byId("item.subTipoBO00").setValue("BO00");
			dijit.byId("item.subTipoBO00").setChecked("");

			if (this.store.getValue(row, "tipoBeneficio") != "") {
				dijit.byId("item.subTipo" + this.store.getValue(row, "tipoBeneficio")).setChecked("checked");
				dijit.byId("item.subTipo" + this.store.getValue(row, "tipoBeneficio")).setValue(this.store.getValue(row, "tipoBeneficio"));
				this.showHiddenDiv(document.getElementById("item.divTipoBeneficio.show"),true);
			}
		}

		if (this.store.getValue(row, "unidadMedida") == "-") {
			dijit.byId("item.unidadMedida").setValue("000");
		} else {
			dijit.byId("item.unidadMedida").setValue(this.store.getValue(row, "unidadMedida"));
		}

		if (this.store.getValue(row, "tipoBonificacion") == "BO01") {
			dojo.byId("item.igvPorcentaje").value = 0;
			dijit.byId("item.subTipoBO00").setValue(this.store.getValue(row, "tipoBonificacion"));
			dijit.byId("item.subTipoBO00").setChecked("checked");
			dijit.byId("item.operacionGratuita1").setValue(this.store.getValue(row, "codigoBonificacion"));
		} else {
			dojo.byId("item.igvPorcentaje").value = dojo.byId("global.igvPorcentaje").value;
			dijit.byId("item.subTipoBO00").setValue(this.store.getValue(row, "tipoBonificacion"));
			dijit.byId("item.subTipoBO00").setChecked("");
		}

		if (this.store.getValue(row, "tipoBeneficio") != "TB00") {
			dojo.byId("item.igvPorcentaje").value = 0;
		} else {
			dojo.byId("item.igvPorcentaje").value = dojo.byId("global.igvPorcentaje").value;
		}

		if (this.store.getValue(row, "tipoBeneficio") == "TB00") {dijit.byId("item.subTipoTB00").setChecked("checked");}
		if (this.store.getValue(row, "tipoBeneficio") == "TB01") {dijit.byId("item.subTipoTB01").setChecked("checked");}
		if (this.store.getValue(row, "tipoBeneficio") == "TB02") {dijit.byId("item.subTipoTB02").setChecked("checked");}
		this.disableMontosItem();

		dijit.byId("item.cantidad").setValue(this.store.getValue(row, "cantidad"), false);
		dijit.byId("item.codigoItem").setValue(this.store.getValue(row, "codigoItem"));
		dijit.byId("item.descripcion").setValue(this.store.getValue(row, "descripcionHidden"));

		dijit.byId("item.precioUnitario").constraints = { currency: moneda,places: '2,10'};
		dijit.byId("item.precioUnitario").setValue(Math.abs(this.store.getValue(row, "precioUnitario").replace(/,/,"")), false);
		//var preUnitValorAbs = Math.abs(dojo.byId("item.precioUnitario"));
		dijit.byId("item.importeVenta").setValue(this.store.getValue(row, "importeVenta"), false);

		dijit.byId("item.precioDescuento").setValue(this.store.getValue(row, "descuentoMonto"), false);

		//
		if (dojo.byId("global.opcionISC").value != "IM00") {
			dijit.byId("item.sistemaIsc").setValue(this.store.getValue(row, "iscSistema"), false);
			dijit.byId("item.iscPorcentaje").setValue(this.store.getValue(row, "iscPorcentaje"), false);
			dijit.byId("item.iscMonto").setValue(Math.abs(this.store.getValue(row, "iscMonto").replace(/,/,"")), false);
		}
		//

		if (dojo.byId("global.opcionPagoAnticipado").value == "1") {
			this.showHiddenDiv(document.getElementById("item.divPagoAnticipado.show"),false);
			dijit.byId("item.subTipoPagoAnticipado0").attr('checked', false ) ;
		}else{
			if (dojo.byId("global.opcionDscto").value == "DE00") {
				this.showHiddenDiv(document.getElementById("item.divPagoAnticipado.show"),false);
				dijit.byId("item.subTipoPagoAnticipado0").attr('checked', false ) ;
    		} else {
    			this.showHiddenDiv(document.getElementById("item.divPagoAnticipado.show"),true);
    			if (this.store.getValue(row, "anticipo") != "1") {
    				dijit.byId("item.subTipoPagoAnticipado0").attr('checked', false) ;
    			} else {
    				dijit.byId("item.subTipoPagoAnticipado0").attr('checked', true) ;
    				if (dijit.byId("item.facturaAnticipoSerie").getValue() =="E001"){
    					dijit.byId("item.subTipoTB00").attr("disabled",true);
    					dijit.byId("item.subTipoTB01").attr("disabled",true);
    					dijit.byId("item.subTipoTB02").attr("disabled",true);
    				}
    				dojo.byId("item.facturaAnticipoSerie").value= this.store.getValue(row, "serieFacturaAnticipo",false);
    				dojo.byId("item.facturaAnticipoNumero").value= this.store.getValue(row, "numeroFacturaAnticipo",false);
    				dojo.byId("item.facturaAnticipoFechaEmision").value= this.store.getValue(row, "fechaEmisionFacturaAnticipo",false);
    				dojo.byId("item.facturaAnticipoMonto").value= this.store.getValue(row, "importeTotalFacturaAnticipo",false);
					this.obtenerFacturaAnticipo(true); /* PAS20201U210100285 */
    			}
    			this.viewCheckedAnticipo();
    		}
		}

		if (this.store.getValue(row, "tipoBeneficio") != "TB00") {
			dojo.byId("item.igvPorcentaje").value = 0;
		} else {
			dojo.byId("item.igvPorcentaje").value = dojo.byId("global.igvPorcentaje").value;
		}
		if (this.store.getValue(row, "tipoBeneficio") == "TB00") {dijit.byId("item.subTipoTB00").setChecked("checked");}
		if (this.store.getValue(row, "tipoBeneficio") == "TB01") {dijit.byId("item.subTipoTB01").setChecked("checked");}
		if (this.store.getValue(row, "tipoBeneficio") == "TB02") {dijit.byId("item.subTipoTB02").setChecked("checked");}
		this.updateItemAmount();

		if (this.store.getValue(row, "tipoBeneficio") != "TB00") {
			dojo.byId("item.igvPorcentaje").value = 0;
		} else {
			dojo.byId("item.igvPorcentaje").value = dojo.byId("global.igvPorcentaje").value;
		}
		if (this.store.getValue(row, "tipoBeneficio") == "TB00") {dijit.byId("item.subTipoTB00").setChecked("checked");}
		if (this.store.getValue(row, "tipoBeneficio") == "TB01") {dijit.byId("item.subTipoTB01").setChecked("checked");}
		if (this.store.getValue(row, "tipoBeneficio") == "TB02") {dijit.byId("item.subTipoTB02").setChecked("checked");}

		if (dojo.byId("global.opcionOro").value == "1") {
			this.showHiddenDiv(document.getElementById("item.divFEComercioOro.show"),true);
		} else {
			this.showHiddenDiv(document.getElementById("item.divFEComercioOro.show"),false);
		}

		if (dojo.byId("global.opcionSPOT").value == "1") {
			this.showHiddenDiv(document.getElementById("item.divFESPOT.show"),true);
		} else {
			this.showHiddenDiv(document.getElementById("item.divFESPOT.show"),false);
		}

		//INI PAS20191U210100075
		console.log(row);

		console.log(this.store.getValue(row, "icbperMonto"));
		monedades = dojo.byId("global.tipoMonedaDesc").value;
		if(monedades != "SOLES"){
			dijit.byId("item.impuestoICBPER").constraints = {currency:moneda, places:2};
			dijit.byId("item.impuestoICBPER").attr('value',this.store.getValue(row, "icbperMonto"));
		} else {
			var tasabolsaPorcentaje =  this.store.getValue(row, "icbPerPorcentaje");

			//dijit.byId("item.tasaBolsa").setValue(tasabolsaPorcentaje, false);

			var handler = dojo.xhrGet({
				preventCache:  false,
				url: this.controller + "?action=loadImpuestoBolsa",
				handleAs: "json",
				sync: true,
				timeout: 10000
			});

			handler.addCallback(dojo.hitch(this, function(res){
				//this.waitMessage.hide();
				this.unidadMedidaStore = null;
				var data = null;
				var values = [];
				var values2 = [];
				if(res.codeError == 0) {
					if(res.data.length > 0 && res.data != "[]") {
						data = eval("(" + res.data + ")");
						//values.push({name:"", abbreviation:"000"});
						for (var x = 0 ; x < data.length ; x++) {

							console.log("1>>>>>" + data[x].tasaTributo);
							console.log("2>>>>>" + tasabolsaPorcentaje);
							if (this.round(data[x].tasaTributo, 2)== this.round(tasabolsaPorcentaje, 2)){
								console.log(">>>>>" + data[x].periodoTributo);
								//mostrarMensaje(data[x].periodoTributo + " - " + data[x].tasaTributo);
								var parts = dojo.byId("factura.fechaEmision").value.split('/');
								var fechaEmision = new Date(parts[2],parts[1]-1,parts[0]);
								if (fechaEmision.getFullYear() > 2023){
									dojo.byId("item.PeriodoBolsaGlobal").value = fechaEmision.getFullYear();
									dojo.byId("item.periodoBolsa").value = fechaEmision.getFullYear();
								}else{
									dojo.byId("item.PeriodoBolsaGlobal").value = data[x].periodoTributo;
									dojo.byId("item.periodoBolsa").value = data[x].periodoTributo;
								}

								dojo.byId("item.tasaBolsaGlobal").value = tasabolsaPorcentaje;
								console.log(document.getElementById("item.tasaBolsaGlobal").value + " <--- ghlobal" );

								dojo.byId("item.tasaBolsa").value = tasabolsaPorcentaje;

								//dijit.byId("item.periodoBolsa").set("displayedValue", data[x].periodoTributo);
								//dijit.byId("item.tasaBolsa").setValue(tasabolsaPorcentaje, false);
							}
						}
					}else {
						 this.unidadMedidaStore = null;
					}
				} else {
					this.iconTooltipMessage(nodeButton, "icon-error-tooltip", res.messageError);
				}
			}));

			handler.addErrback(function(res){
				this.messageBox("Problemas al conectarse con el servidor");
			});
		}

		console.log("----->" + this.store.getValue(row, "esImpuestoBolsaPlastico"));
		if(this.store.getValue(row, "esImpuestoBolsaPlastico") == "IBP00"){
			//this.showHiddenDiv(document.getElementById("item.ICBPER1.show"),true);
			//this.showHiddenDiv(document.getElementById("item.ICBPER2.show"),true);
			dijit.byId("check.impuestoBolsasPlastica00").setChecked("checked");

			dijit.byId("item.cantidad").constraints = {min:0,places:0}; // PAS20191U210100075 01.08
			dijit.byId("item.cantidad").attr('value',this.round(this.store.getValue(row, "cantidad"), 0));
		}else{
			dijit.byId("check.impuestoBolsasPlastica01").setChecked("checked");
			//this.showHiddenDiv(document.getElementById("item.ICBPER1.show"),false);
			//this.showHiddenDiv(document.getElementById("item.ICBPER2.show"),false);
			dijit.byId("item.cantidad").constraints = {min:0.0000000001, places:'2,10',pattern:'########.00########'}
			dijit.byId("item.cantidad").attr('value',this.store.getValue(row, "cantidad"), 0);
		}

		var valueIcbper = document.getElementById('factura.totalICBPERConting');
		console.log(valueIcbper);
		if (valueIcbper != undefined){
			this.showHiddenDiv(document.getElementById("item.ICBPER1.show"),true);
			this.showHiddenDiv(document.getElementById("item.ICBPER2.show"),true);
		}else{
			this.viewCheckedImpuestoBolsaPlastica();
			this.showHiddenDiv(document.getElementById("item.ICBPER1.show"),false);
			this.showHiddenDiv(document.getElementById("item.ICBPER2.show"),false);
		}


		this.viewCheckedImpuestoBolsaPlastica();
		console.log("------>" + this.store.getValue(row, "tipoItem"));
		if (this.store.getValue(row, "tipoItem") == "TI01" || this.store.getValue(row, "tipoItem") == "TI02") {
			dijit.byId("item.subTipo" + this.store.getValue(row, "tipoItem")).setChecked("checked");
			dijit.byId("item.subTipo" + this.store.getValue(row, "tipoItem")).setValue(this.store.getValue(row, "tipoItem"));
		}

		if (this.store.getValue(row, "tipoItem") == "TI00" ) {

			if (this.store.getValue(row, "tipoOtrosCargosTributos") == "1" || this.store.getValue(row, "tipoOtrosCargosTributos") == "2" ) {
				dijit.byId("check.impuestoBolsasPlastica00").setAttribute('disabled', true);
				dijit.byId("check.impuestoBolsasPlastica01").setAttribute('disabled', true);
				dijit.byId("item.periodoBolsa").setAttribute('disabled', true);
				dijit.byId("check.impuestoBolsasPlastica01").setChecked("checked");
			}
		}

		//FIN PAS20191U210100075

		this.dialogItem.show();
	},

	sendDocument: function() {
		//if(!dijit.byId("generada.form").validate()) return;
		if (dojo.trim(dijit.byId("generada.correoUser").getValue()) == "" ) {
			mostrarMensaje("Por favor ingrese una direccion de correo.");
			return;
		}

		this.wait("Enviando", "110px", 100);
		var handler = dojo.xhrGet({
			preventCache:  false,
			url: this.controller + "?action=enviarCorreo&correoUser=" + dojo.trim(dijit.byId("generada.correoUser").getValue()),
			handleAs: "json",
			sync: true,
			timeout: 10000
		});
		handler.addCallback(dojo.hitch(this, function(response){
			this.waitMessage.hide();
			if(response.codeError == 0) {
				mostrarMensaje("Se envió correo a la siguiente dirección: " + dijit.byId("generada.correoUser").getValue());
				//dijit.byId("generada.correoUser").setValue("");
				dijit.byId("generada.correoUser").focus();
			}
			else {
				this.messageBox(res.messageError);
			}
		}));

		handler.addErrback(function(response){
			this.waitMessage.hide();
			this.messageBox("Problemas al conectarse con el servidor");
		});
	},


	sendDocumentContin: function() {
		//if(!dijit.byId("generada.form").validate()) return;
		if (dojo.trim(dijit.byId("generada.correoUser").getValue()) == "" ) {
			mostrarMensaje("Por favor ingrese una direccion de correo.");
			return;
		}

		this.wait("Enviando", "110px", 100);
		var handler = dojo.xhrGet({
			preventCache:  false,
			url: this.controller + "?action=enviarCorreoContin&correoUser=" + dojo.trim(dijit.byId("generada.correoUser").getValue()),
			handleAs: "json",
			sync: true,
			timeout: 10000
		});
		handler.addCallback(dojo.hitch(this, function(response){
			this.waitMessage.hide();
			if(response.codeError == 0) {
				mostrarMensaje("Se envió correo a la siguiente dirección: " + dijit.byId("generada.correoUser").getValue());
				//dijit.byId("generada.correoUser").setValue("");
				dijit.byId("generada.correoUser").focus();
			}
			else {
				this.messageBox(res.messageError);
			}
		}));

		handler.addErrback(function(response){
			this.waitMessage.hide();
			this.messageBox("Problemas al conectarse con el servidor");
		});
	},


	// INI PAS20201U210100097 APDEX Creación de metodo Limpiar
	limpiarDocRel: function() {
		this.indRegitroGR = 0;
		this.otherDocStore=null;
		this.infAdicionalStore=null;
		dojo.byId("global.docsrel.observacion").value = "";
		dojo.byId("infAdic.numeroExpediente").value="";
		dojo.byId("infAdic.ordenCompra").value="";
		dojo.byId("infAdic.codigoUnidadEjecutora").value="";
		dojo.byId("infAdic.numeroProcesoSeleccion").value="";
		dojo.byId("infAdic.numeroContrato").value="";
		var grid = dijit.byId("docrel-grid");
		var row = {
			identificador: "",
			elimina: "",
			tipo: "",
			tipoCod: "",
			serie: "",
			numeroInicial: "",
			numeroFinal: ""
		};
		var emptyStore = new dojo.data.ItemFileWriteStore({data: {identifier: 'identificador', items: [row], preventCache: true}});
		grid.setStore(emptyStore) ;
		grid.update();
	},
	//PAS20201U210100230  INI   OPV Limpia valores de formulario de credito y cuotas.
	limpiarInfCreditoYCuota: function() {
		this.indRegitroInfCredito= 0;
		this.storeInfCredito= null;
		this.storeInfCuota= null;
		this.listaElementosInfCredito=[];
		this.montoTotalCuotas=0;
		this.montoNetoPendienteGuardado=null;
		this.storeInfCreditoGuardado=[];
		this.montoTotalCuotasGuardado=null;
	},

	limpiarInformacionRetencion: function() {
		this.montoBaseRetencion= null;
		this.montoNetoRetencion= null;
	},
	//PAS20201U210100230	FIN 	OPV
	// FIN PAS20201U210100097 APDEX Creación de metodo Limpiar
	backInicial: function() {
		var accionBtnAceptar = dojo.hitch(this, function(res){
		//if (confirm("Sr. Contribuyente, al regresar al seteo del CP, tendr\u00E1 que volver a ingresar la informaci\u00F3n. \u00BFDesea continuar?")) {
			this.store = null;
			dojo.byId("global.modo").value="01"; //edicion

			this.wait("Enviando", "110px", 100);
			var handler = dojo.xhrGet({
				preventCache:  false,
				url: this.controller + "?action=backDatosInicial",
				handleAs: "json",
				sync: true,
				timeout: 10000
			});

			handler.addCallback(dojo.hitch(this, function(response){
				this.waitMessage.hide();
				if(response.codeError == 0) {
					this.content.onLoad = dojo.hitch(this, function(){
						// INI PAS20201U210100097 APDEX Metodo Limpiar Relacionados
						this.limpiarDocRel();
						// FIN PAS20201U210100097 APDEX

						//PAS20201U210100230  INI   OPV
						this.limpiarInfCreditoYCuota();
						this.limpiarInformacionRetencion();
						//PAS20201U210100230	FIN 	OPV
						var valExportacion = dojo.byId("global.opcionExportacion").value;
						dijit.byId("inicio.subTipoEE0" + valExportacion).setChecked("checked");
						dijit.byId("inicio.subTipoEE0" + valExportacion).setValue(valExportacion);

						var valNoDomic = dojo.byId("global.opcionNodomic").value;
						dijit.byId("inicio.subTipoND0" + valNoDomic).setChecked("checked");
						dijit.byId("inicio.subTipoND0" + valNoDomic).setValue(valNoDomic);

						var valOperacionesGratuitas = dojo.byId("global.opcionOperacionesGratuitas").value;
						dijit.byId("inicio.subTipoOpeGratuita0" + valOperacionesGratuitas).setChecked("checked");
						dijit.byId("inicio.subTipoOpeGratuita0" + valOperacionesGratuitas).setValue(valOperacionesGratuitas);

						var valDescuentos = dojo.byId("global.opcionDscto").value;
						dijit.byId("inicio.subTipo" + valDescuentos).setChecked("checked");
						dijit.byId("inicio.subTipo" + valDescuentos).setValue(valDescuentos);

						dijit.byId("inicio.tipoMoneda").setValue(dojo.byId("global.tipoMonedaDescLarge").value);

						var valPagoAnticipado = dojo.byId("global.opcionPagoAnticipado").value;
						dijit.byId("inicio.subTipoFEPagoActicipado0" + valPagoAnticipado).setChecked("checked");
						dijit.byId("inicio.subTipoFEPagoActicipado0" + valPagoAnticipado).setValue(valPagoAnticipado);
						this.showOpcionesPagoAnticipado(valPagoAnticipado) ;

						var valEmisorItinerante = dojo.byId("global.opcionVentaItinerante").value;
						dijit.byId("inicio.subTipoEmiItinerante0" + valEmisorItinerante).setChecked("checked");
						dijit.byId("inicio.subTipoEmiItinerante0" + valEmisorItinerante).setValue(valEmisorItinerante);
						this.showOpcionesVentaItinerante(valEmisorItinerante);

						if (valEmisorItinerante != "1"){
							var valTrasladoBienes= dojo.byId("global.opcionSustentoTrasladoBienes").value;
							dijit.byId("inicio.subTipoTrasladoB0" + valTrasladoBienes).setChecked("checked");
							dijit.byId("inicio.subTipoTrasladoB0" + valTrasladoBienes).setValue(valTrasladoBienes);
							this.showOpcionesTrasladoBienes(valTrasladoBienes);

							var valEstablecimientoEmisor = dojo.byId("global.opcionEstablecimientoEmisor").value;
							dijit.byId("inicio.subTipoEstEmi0" + valEstablecimientoEmisor).setChecked("checked");
							dijit.byId("inicio.subTipoEstEmi0" + valEstablecimientoEmisor).setValue(valEstablecimientoEmisor);
							this.showOpcionesEstablecimientoEmisor(valEstablecimientoEmisor);

							var valDomicilioCliente = dojo.byId("global.opcionDomicilioCliente").value;
							dijit.byId("inicio.subTipoDC0" + valDomicilioCliente).setChecked("checked");
							dijit.byId("inicio.subTipoDC0" + valDomicilioCliente).setValue(valDomicilioCliente);
							this.showOpcionesDireccionCliente(valDomicilioCliente);

							this.showOpcionesTrasladoBienes(valTrasladoBienes);
							if (valEstablecimientoEmisor=="0"){
								dijit.byId("inicio.subTipoEstEmi00").setChecked("checked");
	        		            dijit.byId("inicio.subTipoEstEmi00").setValue("0");
							}
						}

						var valVentaCombustible= dojo.byId("global.opcionPlacaVehiculo").value;
						dijit.byId("inicio.subTipoVentaCombustibleB0" + valVentaCombustible).setChecked("checked");
						dijit.byId("inicio.subTipoVentaCombustibleB0" + valVentaCombustible).setValue(valVentaCombustible);

						if (valNoDomic == "1") {
							this.showOpcionesNoDomic(1);
							dijit.byId("inicio.tipoDocRecepFENodomic").setValue(dojo.byId("global.tipoDocumento").value + " - " + dojo.byId("global.tipoDocumentoNodomic").value);
							dijit.byId("inicio.numeroDocRecepFENodomic").setValue(dojo.byId("global.numeroDocumento").value);
							dijit.byId("inicio.nombreRazonRecepFENodomic").setValue(dojo.byId("global.razonSocialNoDomic").value);
							dijit.byId("inicio.nacionalidadRecepFENodomic").setValue(dojo.byId("global.nacionalidadNoDomic").value + " - " + dojo.byId("global.nacionalidadNoDomicDesc").value);
							dijit.byId("inicio.tamRecepFENoDomic").setValue(dojo.byId("global.tamNoDomic").value);
							dijit.byId("inicio.fecIngresoPaisRecepFENoDomic").setValue(new Date(dojo.byId("global.fecIngresoPaisNoDomic").value));
							dijit.byId("inicio.tipoTarjetaRecepFENodomic").setValue(dojo.byId("global.tipoTarjetaNoDomic").value);
							dijit.byId("inicio.numeroTarjetaRecepFENodomic").setValue(dojo.byId("global.numeroTarjetaNoDomic").value);
							dijit.byId("inicio.bancoEmisorTarjetaRecepFENodomic").setValue(dojo.byId("global.bancoTarjetaNoDomic").value);
						} else {
							this.showOpcionesNoDomic(0);
							if (valExportacion == "0" ) {
								this.showOpcionesExportacion(0);

								dijit.byId("inicio.numeroDocumento").setValue(dojo.byId("global.numeroDocumento").value);
								dijit.byId("inicio.razonSocial").setValue(dojo.byId("global.numeroDocumentoDesc").value);

								var opcionISC = dojo.byId("global.opcionISC").value;
								dijit.byId("inicio.subTipo" + opcionISC).setChecked("checked");
								dijit.byId("inicio.subTipo" + opcionISC).setValue(opcionISC);

								var opcionDscto = dojo.byId("global.opcionDscto").value;
								dijit.byId("inicio.subTipo" + opcionDscto).setChecked("checked");
								dijit.byId("inicio.subTipo" + opcionDscto).setValue(opcionDscto);
							} else {
	    						this.showOpcionesExportacion(1);
	    						dijit.byId("inicio.exportacion.razonSocial").setValue(dojo.byId("global.numeroDocumentoExpDesc").value);

	    						var opcionISC = dojo.byId("global.opcionISC").value;
	    						dijit.byId("inicio.subTipo" + opcionISC).setChecked("checked");
	    						dijit.byId("inicio.subTipo" + opcionISC).setValue(opcionISC);
	    					}
						}

						var valSPOT= dojo.byId("global.opcionSPOT").value;
						dijit.byId("inicio.subTipoOperacionSPOT0" + valSPOT).setChecked("checked");
						dijit.byId("inicio.subTipoOperacionSPOT0" + valSPOT).setValue(valSPOT);

						var valOtrosCargosTrib = dojo.byId("global.opcionOtrosCargosTributos").value;
						dijit.byId("inicio.subTipoCargosTribNoBaseImp0" + valOtrosCargosTrib).setChecked("checked");
						dijit.byId("inicio.subTipoCargosTribNoBaseImp0" + valOtrosCargosTrib).setValue(valOtrosCargosTrib);

						//var valTrasladoBienes = dojo.byId("global.opcionSustentoTrasladoBienes").value;
						//this.showOpcionesTrasladoBienes(valTrasladoBienes);
					});
					this.content.setHref(this.controller + "?action=backInicial&preventCache=" + this.preventCache());
				} else {
					this.messageBox(res.messageError);
				}
			}));

			handler.addErrback(function(response){
				this.waitMessage.hide();
				this.messageBox("Problemas al conectarse con el servidor");
			});
		//}
		});

		mostrarMensajeConfirmacion("Sr. Contribuyente, al regresar al seteo del CP, tendr\u00E1 que volver a ingresar la informaci\u00F3n. \u00BFDesea continuar?", accionBtnAceptar );
	},

	backIngreso: function() {
		this.wait("Enviando", "110px", 100);

		dojo.byId("global.modo").value="01"; //edicion

		var handler = dojo.xhrGet({
			preventCache:  false,
			url: this.controller + "?action=backDatosIngreso",
			handleAs: "json",
			sync: true,
			timeout: 10000
		});

		handler.addCallback(dojo.hitch(this, function(res){
			this.waitMessage.hide();
			if(res.codeError == 0) {
				this.content.onLoad = dojo.hitch(this, function(){

					if (dojo.byId("global.tipoDocumento").value == "6"
						|| dojo.byId("global.tipoDocumento").value == "1") {
						this.showHiddenDiv(document.getElementById("factura.ruc.show"),true);
						this.showHiddenDiv(document.getElementById("factura.razonSocial.show"),false);
						this.showHiddenDiv(document.getElementById("factura.docsNoDomic.show"),false);

  						dijit.byId("factura.numeroDocumento").setValue(dojo.byId("global.numeroDocumento").value);
  						dijit.byId("factura.razonSocial").setValue(dojo.byId("global.numeroDocumentoDesc").value);
					} else {
						dijit.byId("factura.exportacion.razonSocial").setValue(dojo.byId("global.numeroDocumentoExpDesc").value);

						this.showHiddenDiv(document.getElementById("factura.ruc.show"),false);
						this.showHiddenDiv(document.getElementById("factura.razonSocial.show"),true);
						this.showHiddenDiv(document.getElementById("factura.docsNoDomic.show"),false);
					}

					if (dojo.byId("global.opcionNodomic").value == "1") {
						dijit.byId("factura.tipoDocumentoNoDomic").setValue(dojo.byId("global.tipoDocumentoNodomic").value);
						dijit.byId("factura.numeroDocumentoNoDomic").setValue(dojo.byId("global.numeroDocumentonoDomic").value);
						dijit.byId("factura.razonSocialNoDomic").setValue(dojo.byId("global.razonSocialNoDomic").value);
						this.showHiddenDiv(document.getElementById("factura.ruc.show"),false);
						this.showHiddenDiv(document.getElementById("factura.razonSocial.show"),false);
						this.showHiddenDiv(document.getElementById("factura.docsNoDomic.show"),true);
					}

					if (dojo.byId("global.opcionExportacion").value == "1" || dojo.byId("global.opcionOperacionesGratuitas").value == "1") {
						this.showHiddenDiv(document.getElementById("factura.situacionEspecial.show"),true);
					} else {
						this.showHiddenDiv(document.getElementById("factura.situacionEspecial.show"),false);
					}

 					if (dojo.byId("global.opcionOro").value == "1") {
						this.showHiddenDiv(document.getElementById("factura.registroRECPO.show"),true);
					} else {
						this.showHiddenDiv(document.getElementById("factura.registroRECPO.show"),false);
					}

					dijit.byId("factura.tipoMonedaDesc").setValue(dojo.byId("global.tipoMonedaDesc").value);

  					if (dojo.byId("global.opcionEstablecimientoEmisor").value =="1"){
  					     this.showHiddenDiv(document.getElementById("factura.estabEmisor.show"),true);
  					     dijit.byId("factura.establecimientoEmisor").set("value",dojo.byId("global.opcionEstablecimientoEmisorDireccion").value);
  					}else{
  						this.showHiddenDiv(document.getElementById("factura.estabEmisor.show"),false);
  						dijit.byId("factura.establecimientoEmisor").set("value","");
  					}

  					if (dojo.byId("global.opcionDomicilioCliente").value =="1"){
						this.showHiddenDiv(document.getElementById("factura.direccCliente.show"),true);
  					   	dijit.byId("factura.direccionCliente").set("value",dojo.byId("global.opcionDomicilioClienteDireccion").value);
  					}else{
  					     this.showHiddenDiv(document.getElementById("factura.direccCliente.show"),false);
  					     dijit.byId("factura.direccionCliente").set("value","");
  					}

					var grid = dijit.byId("factura.ingreso-grid");
					grid.setStore(this.store);
					grid.update();
					//grid.refresh();
					//PAS20201U210100285 - jmendozas
					var moneda = dojo.byId("global.tipoMoneda").value;
					if(dojo.byId("factura.montoRedondeo") != null){ /* PAS20201U210100285 - Factura Contingencia */
						document.getElementById("factura.montoRedondeo").style.textAlign = "right";
						if (dojo.byId("global.montoRedondeo").value!= ""){
							var redondeo = dojo.byId("global.montoRedondeo").value;
							dijit.byId("factura.montoRedondeo").constraints = {min:-0.09,max:0.09,currency:moneda, places: '2,2',pattern:"\u00A4 #,##0.##;\u00A4 -#,##0.##"};
							if(redondeo<0){
								dijit.byId("factura.montoRedondeo").set("displayedValue", redondeo);
							}else{
								dijit.byId("factura.montoRedondeo").setValue(dojo.currency.format(redondeo,{currency:moneda}));
							}
						}
					}
					//FIN PAS20201U210100285
					this.updateTotalAmount();

					//PAS20201U210100230 ini
					if(dojo.byId("global.opcionTipoTransaccion")!=null){
						if (dojo.byId("global.opcionTipoTransaccion").value == "2"){
							dijit.byId("factura.fechaVencimiento").setAttribute('disabled', true);
						}else{
							dijit.byId("factura.fechaVencimiento").setAttribute('disabled', false);
						}
					}
					//PAS20201U210100230 FIN

					if (dojo.byId("global.fecVencimiento").value!= ""){
					    dijit.byId("factura.fechaVencimiento").setValue(new Date(dojo.byId("global.fecVencimiento").value));
					}

					if (dojo.byId("global.fecEmision").value!= ""){
					    dijit.byId("factura.fechaEmision").setValue(new Date(dojo.byId("global.fecEmision").value));
					}
				});
				this.content.setHref(this.controller + "?action=backIngreso&preventCache=" + this.preventCache());
			}
			else {
				nbControl.attr('disabled', false);
				this.iconTooltipMessage(nodeButton, "icon-error-tooltip", res.messageError);
			}
		}));

		handler.addErrback(function(response){
			this.waitMessage.hide();
			this.messageBox("Problemas al conectarse con el servidor");
		});
	},


	 backIngresoContin: function() {
		this.wait("Enviando", "110px", 100);

		dojo.byId("global.modo").value="01"; //edicion

		var handler = dojo.xhrGet({
			preventCache:  false,
			url: this.controller + "?action=backDatosIngresoContin",
			handleAs: "json",
			sync: true,
			timeout: 10000
		});

		handler.addCallback(dojo.hitch(this, function(res){
			this.waitMessage.hide();
			if(res.codeError == 0) {
				var obj = JSON.parse(res.data);
				var ser=obj.serie;
				var num=obj.numero;
				var estab=obj.establecimiento;
				this.content.onLoad = dojo.hitch(this, function(){
					document.getElementById("serie").value=ser;
					document.getElementById("numero").value=num;
					document.getElementById("establecimiento").value=estab;
					this.showHiddenDiv(document.getElementById("serie"),true);
					this.showHiddenDiv(document.getElementById("numero"),true);
					this.showHiddenDiv(document.getElementById("establecimiento"),true);
					if (dojo.byId("global.tipoDocumento").value == "6"
						|| dojo.byId("global.tipoDocumento").value == "1") {
						this.showHiddenDiv(document.getElementById("factura.ruc.show"),true);
						this.showHiddenDiv(document.getElementById("factura.razonSocial.show"),false);
						this.showHiddenDiv(document.getElementById("factura.docsNoDomic.show"),false);

  						dijit.byId("factura.numeroDocumento").setValue(dojo.byId("global.numeroDocumento").value);
  						dijit.byId("factura.razonSocial").setValue(dojo.byId("global.numeroDocumentoDesc").value);
					} else {
						dijit.byId("factura.exportacion.razonSocial").setValue(dojo.byId("global.numeroDocumentoExpDesc").value);

						this.showHiddenDiv(document.getElementById("factura.ruc.show"),false);
						this.showHiddenDiv(document.getElementById("factura.razonSocial.show"),true);
						this.showHiddenDiv(document.getElementById("factura.docsNoDomic.show"),false);
					}

					if (dojo.byId("global.opcionNodomic").value == "1") {
						dijit.byId("factura.tipoDocumentoNoDomic").setValue(dojo.byId("global.tipoDocumentoNodomic").value);
						dijit.byId("factura.numeroDocumentoNoDomic").setValue(dojo.byId("global.numeroDocumentonoDomic").value);
						dijit.byId("factura.razonSocialNoDomic").setValue(dojo.byId("global.razonSocialNoDomic").value);
						this.showHiddenDiv(document.getElementById("factura.ruc.show"),false);
						this.showHiddenDiv(document.getElementById("factura.razonSocial.show"),false);
						this.showHiddenDiv(document.getElementById("factura.docsNoDomic.show"),true);
					}

					if (dojo.byId("global.opcionExportacion").value == "1" || dojo.byId("global.opcionOperacionesGratuitas").value == "1") {
						this.showHiddenDiv(document.getElementById("factura.situacionEspecial.show"),true);
					} else {
						this.showHiddenDiv(document.getElementById("factura.situacionEspecial.show"),false);
					}

 					if (dojo.byId("global.opcionOro").value == "1") {
						this.showHiddenDiv(document.getElementById("factura.registroRECPO.show"),true);
					} else {
						this.showHiddenDiv(document.getElementById("factura.registroRECPO.show"),false);
					}

					dijit.byId("factura.tipoMonedaDesc").setValue(dojo.byId("global.tipoMonedaDesc").value);

  					if (dojo.byId("global.opcionEstablecimientoEmisor").value =="1"){
  					     this.showHiddenDiv(document.getElementById("factura.estabEmisor.show"),true);
  					     dijit.byId("factura.establecimientoEmisor").set("value",dojo.byId("global.opcionEstablecimientoEmisorDireccion").value);
  					}else{
  						this.showHiddenDiv(document.getElementById("factura.estabEmisor.show"),false);
  						dijit.byId("factura.establecimientoEmisor").set("value","");
  					}

  					if (dojo.byId("global.opcionDomicilioCliente").value =="1"){
						this.showHiddenDiv(document.getElementById("factura.direccCliente.show"),true);
  					   	dijit.byId("factura.direccionCliente").set("value",dojo.byId("global.opcionDomicilioClienteDireccion").value);
  					}else{
  					     this.showHiddenDiv(document.getElementById("factura.direccCliente.show"),false);
  					     dijit.byId("factura.direccionCliente").set("value","");
  					}

					var grid = dijit.byId("factura.ingreso-grid");
					grid.setStore(this.store);
					grid.update();
					//grid.refresh();
					this.updateTotalAmount();

					if (dojo.byId("global.fecVencimiento").value!= ""){
					    dijit.byId("factura.fechaVencimiento").setValue(new Date(dojo.byId("global.fecVencimiento").value));
					}

					if (dojo.byId("global.fecEmision").value!= ""){
					    dijit.byId("factura.fechaEmision").setValue(new Date(dojo.byId("global.fecEmision").value));
					}
				});
				this.content.setHref(this.controller + "?action=backIngreso&preventCache=" + this.preventCache());
			}
			else {
				nbControl.attr('disabled', false);
				this.iconTooltipMessage(nodeButton, "icon-error-tooltip", res.messageError);
			}
		}));

		handler.addErrback(function(response){
			this.waitMessage.hide();
			this.messageBox("Problemas al conectarse con el servidor");
		});
	},


	backDocRel: function() {
		dojo.byId("global.modo").value="01"; //edicion

		this.wait("Enviando", "110px", 100);
		var handler = dojo.xhrGet({
			preventCache:  false,
			url: this.controller + "?action=backDatosDocRel",
			handleAs: "json",
			sync: true,
			timeout: 10000
		});

		handler.addCallback(dojo.hitch(this, function(res){
			this.waitMessage.hide();
			if(res.codeError == 0) {
				this.content.onLoad = dojo.hitch(this, function(){
					dijit.byId("docsrel.observacion").setValue(dojo.byId("global.docsrel.observacion").value );
					if (dojo.byId("global.opcionFESectorPublico").value == "1") {
						this.showHiddenDiv(document.getElementById("docsrel.informacionFESectorPublico.show"),true);
					} else {
						this.showHiddenDiv(document.getElementById("docsrel.informacionFESectorPublico.show"),false);
					}
					if (dojo.byId("global.opcionSustentoTrasladoBienes").value == "1") {
						this.showHiddenDiv(document.getElementById("docsrel.informacionTrasladoBienes.show"),true);
					} else {
						this.showHiddenDiv(document.getElementById("docsrel.informacionTrasladoBienes.show"),false);
					}
					if (dojo.byId("global.opcionSPOT").value == "1") {
						this.showHiddenDiv(document.getElementById("docsrel.informacionRecursosHidrobiologicos.show"),true);
					} else {
						this.showHiddenDiv(document.getElementById("docsrel.informacionRecursosHidrobiologicos.show"),false);
					}
					if (dojo.byId("global.opcionPlacaVehiculo").value == "1") {
						this.showHiddenDiv(document.getElementById("docsrel.informacionPlacaVentaCombustible.show"),true);
						dijit.byId("docsrel.placaVentaCombustible").setValue(dojo.byId("global.docsrel.placaVentaCombustible").value );
					} else {
						this.showHiddenDiv(document.getElementById("docsrel.informacionPlacaVentaCombustible.show"),false);
					}
					//PAS20201U210100230   INI MOSTRAR OCULTAR INF CREDITO OPV
					if (dojo.byId("global.opcionTipoTransaccion")!=null){
						console.log("backDocRel opcion TipoTransaccion: "+dojo.byId("global.opcionTipoTransaccion").value);
						if (dojo.byId("global.opcionTipoTransaccion").value == "2") {
							console.log("backDocRel - tipoDocumento : "+dojo.byId("global.tipoDocumento").value);//INI - PAS20211U210700145
							var td = dojo.byId("global.tipoDocumento").value;
							if (td=="6"){
								this.showHiddenDiv(document.getElementById("docsrel.informacionCredito.show"),true);
								this.showHiddenDiv(document.getElementById("docsrel.informacionCreditoAnuncio.show"),true);
							}else{
								this.showHiddenDiv(document.getElementById("docsrel.informacionCredito.show"),false);
								this.showHiddenDiv(document.getElementById("docsrel.informacionCreditoAnuncio.show"),false);
							}//FIN - PAS20211U210700145
						}else{
							this.showHiddenDiv(document.getElementById("docsrel.informacionCredito.show"),false);
							this.showHiddenDiv(document.getElementById("docsrel.informacionCreditoAnuncio.show"),false);
						}


						if (dojo.byId("global.puedeEmitirRetencion").value == "1") { //VISIBLE
							this.showHiddenDiv(document.getElementById("docsrel.informacionRetencion.show"),true);
							this.showHiddenDiv(document.getElementById("docsrel.informacionRetencionAnuncio.show"),true);
						}else{
							this.showHiddenDiv(document.getElementById("docsrel.informacionRetencion.show"),false);
							this.showHiddenDiv(document.getElementById("docsrel.informacionRetencionAnuncio.show"),false);
						}
					}
                    //PAS20201U210100230   FIN OPV
					var moneda = dojo.byId("global.tipoMoneda").value;

				});
				this.content.setHref(this.controller + "?action=backDocRel&preventCache=" + this.preventCache());
			}
			else {
				nbControl.attr('disabled', false);
				this.iconTooltipMessage(nodeButton, "icon-error-tooltip", res.messageError);
			}
		}));

		handler.addErrback(function(response){
			this.waitMessage.hide();
			this.messageBox("Problemas al conectarse con el servidor");
		});
	},

	/*
	getValorOpcionIdEstabEmisor: function() {
		var valOpcionIdEstabEmisor;
		for(i = 1; i < 3; i++) {
			if(dijit.byId("estabEmisor.idEstab0" + i).getValue() != false) {
				valOpcionIdEstabEmisor = dijit.byId("estabEmisor.idEstab0" + i).getValue()
			}
		}
		return valOpcionIdEstabEmisor;
	},*/
//PAS20201U210100230 INI
	showNextDireccionReceptor: function(){

		if (dojo.byId("domicilioContribuyente.coddist").value =="" ||  dojo.byId("domicilioContribuyente.coddist").value =="000000"){
			mostrarMensaje("Debe seleccionar departamento, provincia y distrito.");
			return;
	   } else if (dijit.byId("domicilioContribuyente.refer").getValue()=="" ){
			mostrarMensaje("Debe ingresar referencia de su domicilio");
			return;
		}else if(!dijit.byId("domicilioContribuyente.refer").validate()){
			console.log("tiene caracteres especiales");
			return;
		}

		this.wait("Procesando", "95px", 200);
		var handler = dojo.io.iframe.send({
			url: this.controller + "?action=datosDireccReceptor&coddist=" + dojo.byId("domicilioContribuyente.coddist").value + "&refer=" + dojo.byId("domicilioContribuyente.refer").value,
			handleAs: "json",
			sync: true,
			timeout: 10000,
			preventCache: true
		});

		var direccionReceptor = dijit.byId("domicilioContribuyente.refer").getValue();
		direccionReceptor=direccionReceptor + (" ") + dijit.byId("domicilioContribuyente.emisorDpto").getDisplayedValue() + "-" +
            dijit.byId("domicilioContribuyente.emisorProv").getDisplayedValue() + "-" +
			dijit.byId("domicilioContribuyente.emisorDist").getDisplayedValue();

		dojo.byId("global.opcionFacturaFactoringDireccionReceptor").value = direccionReceptor;
		dojo.byId("domicilioContribuyente.domicilio").value = direccionReceptor;
		dojo.byId("domicilioContribuyente.cod_estab").value = "0";

		handler.addCallback(dojo.hitch(this, function(res){
			this.waitMessage.hide();
			if(res.codeError == 0) {
				dijit.byId("inicio.facturaFactoring.domicilioFiscal").set("value",dojo.byId("global.opcionFacturaFactoringDireccionReceptor").value);
				this.dialogDireccionContribuyente.hide();
			} else {
				mostrarMensaje(res.messageError);
				nbControl.attr('disabled', false);
			}
		}));

		handler.addErrback(function(res){
			nbControl.attr('disabled', false);
			this.waitMessage.hide();
			mostrarMensaje("Problemas al conectarse con el servidor");
		});


	},
//ALB
	showInformacionRetencion: function(){
		if (isNaN(dijit.byId("informacion.baseRetencion").getValue())){
			nodeButton= dijit.byId("informacion.baseRetencion").focusNode
			this.iconTooltipMessage(nodeButton, "icon-error-tooltip", "Debe registrar la Base imponible de retención.");
			this.waitMessage.hide();
			return;
		}

		if (dijit.byId("informacion.baseRetencion").getValue() <= 0 ){
			nodeButton= dijit.byId("informacion.baseRetencion").focusNode
			this.iconTooltipMessage(nodeButton, "icon-error-tooltip", "El monto debe ser mayor a cero.");
			this.waitMessage.hide();
			return;
		}

		if (dijit.byId("informacion.baseRetencion").getValue() > dojo.byId("global.importeTotal").value  &&
			dojo.byId("global.tipoMoneda").value=="PEN" ){
			nodeButton= dijit.byId("informacion.baseRetencion").focusNode
			this.iconTooltipMessage(nodeButton, "icon-error-tooltip", "El monto no puede ser mayor al importe total de la factura.");
			this.waitMessage.hide();
			return;
		}

		this.wait("Procesando", "95px", 200);
		var handler = dojo.io.iframe.send({
			url: this.controller + "?action=datosRetencion&baseretencion=" + dijit.byId("informacion.baseRetencion").getValue() + "&porcentajeretencion=" + dojo.byId("global.porcentajeRetencion").value + "&montoretencion=" + dijit.byId("informacion.montoRetencion").getValue(),
			handleAs: "json",
			sync: true,
			timeout: 10000,
			preventCache: true
		});

		handler.addCallback(dojo.hitch(this, function(res){
			this.waitMessage.hide();
			if(res.codeError == 0) {
				//dijit.byId("inicio.facturaFactoring.domicilioFiscal").set("value",dojo.byId("global.opcionFacturaFactoringDireccionReceptor").value);
				this.dialogRetencion.hide();
			} else {
				mostrarMensaje(res.messageError);
				nbControl.attr('disabled', false);
			}
		}));

		handler.addErrback(function(res){
			nbControl.attr('disabled', false);
			this.waitMessage.hide();
			mostrarMensaje("Problemas al conectarse con el servidor");
		});

	},
	//PAS20201U210100230 FIN

	showNextDireccionCliente: function(){
		var tipoDireccion = this.getValorOpcionTipoDireccCliente ();
		dojo.byId("global.opcionDomicilioClienteIdentifica").value = tipoDireccion;

		if (tipoDireccion == null || tipoDireccion=="" ){
			mostrarMensaje("Debe seleccionar el tipo de direcci\u00F3n del cliente.");
			return;
		}

		dojo.byId("direccCliente.num_ruc_domicilio").value = dojo.byId("global.numRucEmisor").value;

		if (tipoDireccion ==1 || tipoDireccion ==2){
			if (tipoDireccion == 1){
				dojo.byId("direccCliente.num_ruc_domicilio").value = dojo.byId("global.numeroDocumento").value;
  		  	}else{
  		  		if (tipoDireccion == 2){
  		  			var ruc3ro =dijit.byId("direccCliente.txt_ruc_tercero").getValue();
  		  			if (ruc3ro==""){
  		  				mostrarMensaje("Debe de ingresar RUC.");
  		  				return;
  		  			}
  		  			if (ruc3ro.length != 11){
  		  				mostrarMensaje("RUC no válido.");
  						return;
  		  			}

  		  			if (!this.isValidRuc(ruc3ro)){
  		  				mostrarMensaje("RUC no válido.");
  		  				return;
  		  			}

  		  			dojo.byId("direccCliente.num_ruc_domicilio").value = ruc3ro;
  		  		}
  		  	}

			var grilla =dijit.byId("direccCliente.domiciliosGrid");
			var datos =grilla.store._arrayOfAllItems;
			var filas = grilla.store._arrayOfAllItems.length;
			var datoSel="";
			var numSeleccionados=0;
			for (i=0; i< filas;i++){
				if (dojo.byId("direccCliente.selDomicilioGrid" + i).checked == true){
					numSeleccionados ++;
					dojo.byId("global.opcionDomicilioClienteSeleccionado").value = i;
					var fila = grilla.getItem(i);
					var codigo = grilla.store.getValue(fila, "codigo");
					var ubigeo = grilla.store.getValue(fila, "ubigeo");
					var domicilio = grilla.store.getValue(fila, "domicilio");
					var cod_estab = grilla.store.getValue(fila, "cod_estab");
					dojo.byId("global.opcionDomicilioClienteDireccion").value = domicilio;
					dojo.byId("direccCliente.domicilio").value = domicilio;
					dojo.byId("direccCliente.codigo").value = codigo;
					dojo.byId("direccCliente.coddist").value = ubigeo;
					dojo.byId("direccCliente.cod_estab").value = cod_estab;
					break;
				}
			}
			if (numSeleccionados==0){
				mostrarMensaje( "Debe seleccionar un establecimiento.");
				return;
			}
		}else if (tipoDireccion ==3 ){
			if (dojo.byId("direccCliente.coddist").value =="" ||  dojo.byId("direccCliente.coddist").value =="000000"){
          	   mostrarMensaje("Debe seleccionar departamento, provincia y distrito.");
          	   return;
            } else if (dijit.byId("direccCliente.nomvia").getValue()=="" && dijit.byId("direccCliente.nomzon").getValue()=="" ){
                mostrarMensaje("Debe ingresar al menos uno de los campos marcados con asterisco (*).");
                 return;
            } else if (dijit.byId("direccCliente.nomvia").getValue()!="" && (dijit.byId("direccCliente.tipvia").getValue()==""  || dijit.byId("direccCliente.tipvia").getValue()=="11") ){
                mostrarMensaje("Debe ingresar el tipo de via.");
                return;
            } else if (dijit.byId("direccCliente.nomzon").getValue()!="" && (dijit.byId("direccCliente.tipzon").getValue()==""  || dijit.byId("direccCliente.tipzon").getValue()=="11") ){
                mostrarMensaje("Debe ingresar al tipo de zona.");
                return;
            } else if (dijit.byId("direccCliente.km").getValue()=="" && dijit.byId("direccCliente.mz").getValue()=="" && dijit.byId("direccCliente.lote").getValue()=="" && dijit.byId("direccCliente.dep").getValue()=="" && dijit.byId("direccCliente.int").getValue()==""){
          				mostrarMensaje("Debe ingresar al menos el kil\u00F3metro, manzana, lote, departamento o interior.");
          				return;
          	}

          	var domicilio="";
            if (dijit.byId("direccCliente.nomvia").getValue()!="" ) {
                domicilio=dijit.byId("direccCliente.tipvia").getDisplayedValue().substring(0,4) + " " + dijit.byId("direccCliente.nomvia").getValue() + " " + dijit.byId("direccCliente.num").getValue();
            }
            if (dijit.byId("direccCliente.nomzon").getValue()!="" ) {
                domicilio= domicilio + " " + dijit.byId("direccCliente.tipzon").getDisplayedValue().substring(0,4) + " " + dijit.byId("direccCliente.nomzon").getValue() ;
            }
            if (dijit.byId("direccCliente.mz").getValue()!="" ) {
                domicilio= domicilio + " MZA. " + dijit.byId("direccCliente.mz").getValue() ;
            }
            if (dijit.byId("direccCliente.lote").getValue()!="" ) {
                domicilio= domicilio + " LOTE. " + dijit.byId("direccCliente.lote").getValue() ;
            }
            if (dijit.byId("direccCliente.dep").getValue()!="" ) {
                domicilio= domicilio + " DPTO. " + dijit.byId("direccCliente.dep").getValue() ;
            }
            if (dijit.byId("direccCliente.int").getValue()!="" ) {
                domicilio= domicilio + " INT. " + dijit.byId("direccCliente.int").getValue() ;
            }
            if (dijit.byId("direccCliente.km").getValue()!="" ) {
                domicilio= domicilio + " KM. " + dijit.byId("direccCliente.km").getValue() ;
            }
            if (dijit.byId("direccCliente.refer").getValue()!="" ) {
                domicilio= domicilio + " " + dijit.byId("direccCliente.refer").getValue() ;
            }

            domicilio=domicilio + (" ") + dijit.byId("direccCliente.emisorDpto").getDisplayedValue() + "-" +
            dijit.byId("direccCliente.emisorProv").getDisplayedValue() + "-" +
            dijit.byId("direccCliente.emisorDist").getDisplayedValue();

          	dojo.byId("global.opcionDomicilioClienteDireccion").value = domicilio;
          	dojo.byId("direccCliente.domicilio").value = domicilio;
			dojo.byId("direccCliente.cod_estab").value = "0";
		}

		this.wait("Procesando", "95px", 200);
		var handler = dojo.io.iframe.send({
			/*Inicio SAU20156R120400647*/
			//url: this.controller + "?action=datosDireccCliente&subTipoEdireccCliente=" + dojo.byId("direccCliente.subTipoEdireccCliente").value + "&codigo=" + dojo.byId("direccCliente.codigo").value + "&coddist=" + dojo.byId("direccCliente.coddist").value + "&domicilio=" + dojo.byId("direccCliente.domicilio").value + "&cod_estab=" + dojo.byId("direccCliente.cod_estab").value + "&num_ruc_domicilio=" + dojo.byId("direccCliente.num_ruc_domicilio").value + "&refer=" + dojo.byId("direccCliente.refer").value + "&tipvia=" + dijit.byId("direccCliente.tipvia").get('value') + "&tipzon=" + dijit.byId('direccCliente.tipzon').get('value') + "&num=" + dojo.byId("direccCliente.num").value + "&mz=" + dojo.byId("direccCliente.mz").value + "&lote=" + dojo.byId("direccCliente.lote").value + "&dep=" + dojo.byId("direccCliente.dep").value + "&int=" + dojo.byId("direccCliente.int").value + "&km=" + dojo.byId("direccCliente.km").value + "&nomzon=" + dojo.byId("direccCliente.nomzon").value + "&nomvia=" + dojo.byId("direccCliente.nomvia").value, --> L\u00EDnea a Comentar
			url: this.controller + "?action=datosDireccCliente&subTipoEdireccCliente=" + dojo.byId("direccCliente.subTipoEdireccCliente").value + "&codigo=" + dojo.byId("direccCliente.codigo").value + "&coddist=" + dojo.byId("direccCliente.coddist").value + "&domicilio=" + encodeURIComponent(dojo.byId("direccCliente.domicilio").value) + "&cod_estab=" + dojo.byId("direccCliente.cod_estab").value + "&num_ruc_domicilio=" + dojo.byId("direccCliente.num_ruc_domicilio").value + "&refer=" + dojo.byId("direccCliente.refer").value + "&tipvia=" + dijit.byId("direccCliente.tipvia").get('value') + "&tipzon=" + dijit.byId('direccCliente.tipzon').get('value') + "&num=" + dojo.byId("direccCliente.num").value + "&mz=" + dojo.byId("direccCliente.mz").value + "&lote=" + dojo.byId("direccCliente.lote").value + "&dep=" + dojo.byId("direccCliente.dep").value + "&int=" + dojo.byId("direccCliente.int").value + "&km=" + dojo.byId("direccCliente.km").value + "&nomzon=" + dojo.byId("direccCliente.nomzon").value + "&nomvia=" + dojo.byId("direccCliente.nomvia").value, //--> Nueva L\u00EDnea
			/*Fin SAU20156R120400647*/
			handleAs: "json",
			sync: true,
			timeout: 10000,
			preventCache: true
		});

		handler.addCallback(dojo.hitch(this, function(res){
			this.waitMessage.hide();
			if(res.codeError == 0) {
				dijit.byId("factura.direccionCliente").set("value",dojo.byId("global.opcionDomicilioClienteDireccion").value);
				this.dialogDireccionCliente.hide();
			} else {
				mostrarMensaje(res.messageError);
				nbControl.attr('disabled', false);
			}
		}));

		handler.addErrback(function(res){
			nbControl.attr('disabled', false);
			this.waitMessage.hide();
			mostrarMensaje("Problemas al conectarse con el servidor");
		});
	},

	showNextEstabEmisor: function(){
		/*
		if (this.getValorOpcionIdEstabEmisor() != null && this.getValorOpcionIdEstabEmisor() != ""){
			dojo.byId("global.opcionEstablecimientoEmisorIdentifica").value =this.getValorOpcionIdEstabEmisor();
		}  else{
			mostrarMensaje( "Debe seleccionar el tipo del establecimiento.");
			return;
		}
		*/
		var grilla =dijit.byId('estabEmisor.domiciliosGrid');
		var datos =grilla.store._arrayOfAllItems;
		var filas = grilla.store._arrayOfAllItems.length;
		var datoSel="";
		var numSeleccionados=0;
		for (i=0; i< filas;i++){
			if (dojo.byId("estabEmisor.selDomicilioGrid" + i).checked == true){
				numSeleccionados ++;
				var fila = grilla.getItem(i);
				var codigo = grilla.store.getValue(fila, "codigo");
				var ubigeo = grilla.store.getValue(fila, "ubigeo");
				var domicilio = grilla.store.getValue(fila, "domicilio");
				var cod_estab = grilla.store.getValue(fila, "cod_estab");
				dojo.byId("global.opcionEstablecimientoEmisorDireccion").value = domicilio;
				//datoSel = dijit.byId("estabEmisor.selDomicilioGrid"+valorCheck).getValue();
				dojo.byId("global.opcionEstablecimientoEmisorSeleccionado").value = i;
				dojo.byId("estabEmisor.cod_estab").value = cod_estab;
			}
		}
		if (numSeleccionados==0){
			mostrarMensaje( "Debe seleccionar un establecimiento.");
			return;
		}
		dojo.byId("estabEmisor.num_ruc_domicilio").value = dojo.byId("global.numRucEmisor").value;

		this.wait("Procesando", "95px", 200);
		var handler = dojo.io.iframe.send({
		/*Inicio SAU20156R120400647*/
    	//url: this.controller + "?action=datosEstabEmisor&id=" + dojo.byId("global.opcionEstablecimientoEmisorIdentifica").value + "&codigo=" + codigo + "&ubigeo=" + ubigeo + "&domicilio=" + domicilio + "&num_ruc_domicilio=" + dojo.byId("estabEmisor.num_ruc_domicilio").value + "&cod_estab=" +  dojo.byId("estabEmisor.cod_estab").value,
		//encodeURIComponent
		url: this.controller + "?action=datosEstabEmisor&id=" + dojo.byId("global.opcionEstablecimientoEmisorIdentifica").value + "&codigo=" + codigo + "&ubigeo=" + ubigeo + "&domicilio=" + encodeURIComponent(domicilio) + "&num_ruc_domicilio=" + encodeURIComponent(dojo.byId("estabEmisor.num_ruc_domicilio").value) + "&cod_estab=" +  dojo.byId("estabEmisor.cod_estab").value,
		/*Fin SAU20156R120400647*/
		handleAs: "json",
			sync: true,
			timeout: 10000,
			preventCache: true
		});

		handler.addCallback(dojo.hitch(this, function(res){
			this.waitMessage.hide();
			if(res.codeError == 0) {
			    dijit.byId("factura.establecimientoEmisor").set("value",dojo.byId("global.opcionEstablecimientoEmisorDireccion").value);
				this.dialogEstablecimientoEmisor.hide();
			}
			else {
				mostrarMensaje(res.messageError);
				nbControl.attr('disabled', false);
			}
		}));

		handler.addErrback(function(res){
			nbControl.attr('disabled', false);
			this.waitMessage.hide();

			// PAS20201U210100046
			mostrarMensaje("Se produjo un error al intentar recuperar los datos del establecimiento del emisor. Por favor volver a intentar.");
			console.log("error showNextEstabEmisor " + res.message);
			console.log("error showNextEstabEmisor " + res.messageError);
		});
    },

	showNextEstabEmisorContin: function(){
		/*
		if (this.getValorOpcionIdEstabEmisor() != null && this.getValorOpcionIdEstabEmisor() != ""){
			dojo.byId("global.opcionEstablecimientoEmisorIdentifica").value =this.getValorOpcionIdEstabEmisor();
		}  else{
			mostrarMensaje( "Debe seleccionar el tipo del establecimiento.");
			return;
		}
		*/
		var grilla =dijit.byId('estabEmisor.domiciliosGrid');
		var datos =grilla.store._arrayOfAllItems;
		var filas = grilla.store._arrayOfAllItems.length;
		var datoSel="";
		var numSeleccionados=0;
		for (i=0; i< filas;i++){
			if (dojo.byId("estabEmisor.selDomicilioGrid" + i).checked == true){
				numSeleccionados ++;
				var fila = grilla.getItem(i);
				var codigo = grilla.store.getValue(fila, "codigo");
				var ubigeo = grilla.store.getValue(fila, "ubigeo");
				var domicilio = grilla.store.getValue(fila, "domicilio");
				var cod_estab = grilla.store.getValue(fila, "cod_estab");
				dojo.byId("global.opcionEstablecimientoEmisorDireccion").value = domicilio;
				//datoSel = dijit.byId("estabEmisor.selDomicilioGrid"+valorCheck).getValue();
				dojo.byId("global.opcionEstablecimientoEmisorSeleccionado").value = i;
				dojo.byId("estabEmisor.cod_estab").value = cod_estab;
			}
		}
		if (numSeleccionados==0){
			mostrarMensaje( "Debe seleccionar un establecimiento.");
			return;
		}
		dojo.byId("estabEmisor.num_ruc_domicilio").value = dojo.byId("global.numRucEmisor").value;

		this.wait("Procesando", "95px", 200);
		var handler = dojo.io.iframe.send({
		/*Inicio SAU20156R120400647*/
    	//url: this.controller + "?action=datosEstabEmisor&id=" + dojo.byId("global.opcionEstablecimientoEmisorIdentifica").value + "&codigo=" + codigo + "&ubigeo=" + ubigeo + "&domicilio=" + domicilio + "&num_ruc_domicilio=" + dojo.byId("estabEmisor.num_ruc_domicilio").value + "&cod_estab=" +  dojo.byId("estabEmisor.cod_estab").value,
		//encodeURIComponent
		url: this.controller + "?action=datosEstabEmisor&id=" + dojo.byId("global.opcionEstablecimientoEmisorIdentifica").value + "&codigo=" + codigo + "&ubigeo=" + ubigeo + "&domicilio=" + encodeURIComponent(domicilio) + "&num_ruc_domicilio=" + encodeURIComponent(dojo.byId("estabEmisor.num_ruc_domicilio").value) + "&cod_estab=" +  dojo.byId("estabEmisor.cod_estab").value,
		/*Fin SAU20156R120400647*/
		handleAs: "json",
			sync: true,
			timeout: 10000,
			preventCache: true
		});

		handler.addCallback(dojo.hitch(this, function(res){
			this.waitMessage.hide();
			if(res.codeError == 0) {
			     dijit.byId("factura.establecimientoEmisor").set("value",dojo.byId("global.opcionEstablecimientoEmisorDireccion").value);
				 document.getElementById("establecimiento").value=(res.data);
				 document.getElementById("numero").value="";
            this.dialogEstablecimientoEmisor.hide();
			}
			else {
				mostrarMensaje(res.messageError);
				nbControl.attr('disabled', false);
			}
		}));

		handler.addErrback(function(res){
			nbControl.attr('disabled', false);
			this.waitMessage.hide();
			mostrarMensaje("Problemas al conectarse con el servidor");
		});
    },


    showFacturaIngreso: function() {
		console.log("showFacturaIngreso ");
		if(this.globalCambiosFactoringHabilitados=="1"){
			console.log("showFacturaIngreso-globalCambiosFactoringHabilitados " + this.globalCambiosFactoringHabilitados);
			if(dojo.byId("inicio.facturaFactoring.subTipoTT02").checked == true && dojo.byId("inicio.facturaFactoring.domicilioFiscal").value==""){
				console.log("showFacturaIngreso-credito-domFisc vacio ");

				//Jrgs pase 230-231
				var td = dijit.byId("inicio.tipoDocumento").getValue();
				var ndControl = dijit.byId("inicio.numeroDocumento");
				var ndLength = dojo.trim(ndControl.getValue()).length;
				console.log("showFacturaIngreso-td " + td);
				console.log("showFacturaIngreso-ndControl " + ndControl);
				console.log("showFacturaIngreso-ndLength " + ndLength);
				if(td != '-' && ndLength == 0){
					mostrarMensaje("Tiene que ingresar un número de documento.");
					ndControl.focus();
					return;
				} else {
					if (td == "-"){ //SIN DOCUMENTO
						if (expRSLength == 0){
							mostrarMensaje("Tiene que ingresar Razon Social.");
							expRSControl.attr('value', "");
							expRSControl.focus();
							return;
						}
					} else if (td == "6") { //RUC
						this.self = this;
						if(!this.isValidRuc(dojo.trim(ndControl.getValue()))) {
							mostrarMensaje("N\u00FAmero de RUC incorrecto.");
							ndControl.attr('value', "");
							ndControl.focus();
							return;
						}
					} else if (td == "0" || td == "B" || td == "C" || td == "D") { // DOC.TRIB.NO.DOM.SIN.RUC, DOC.IDENTIF.PERS.NAT.NO DOM., TAX IDENTIFICATION NUMBER - TIN – DOC TRIB PP.NN, IDENTIFICATION NUMBER - IN – DOC TRIB PP. JJ
						// PAS20211U210100010
						if (expRazonSocLength < 3){
							// mostrarMensaje("Tiene que ingresar el DOC.TRIB.NO.DOM.SIN.RUC.");
							mostrarMensaje("Debe ingresar mínimo 3 y máximo 200 caracteres para los apellidos y nombres del cliente");
							expRazonSocControl.attr('value', "");
							expRazonSocControl.focus();
							return;
						}
					}
				}
				//Jrgs pase 230-231
				var df = dijit.byId("inicio.facturaFactoring.domicilioFiscal").getValue();
				var dfControl = dijit.byId("inicio.facturaFactoring.domicilioFiscal");
				var dfLength = dojo.trim(dfControl.getValue()).length;
				console.log("showFacturaIngreso-df " + df);
				console.log("showFacturaIngreso-dfControl " + dfControl);
				console.log("showFacturaIngreso-dfLength " + dfLength);
				//INICIO PAS20211U210700145_EBV - PAS20211U210700145_AVN
				/*if(df != '-' && dfLength == 0 && td!= 1){
					mostrarMensaje("Tiene que ingresar dirección del receptor.");
					ndControl.focus();
					return;
				}*/
				//FIN PAS20211U210700145_EBV - PAS20211U210700145_AVN
				//Jrgs pase 230-231
				//return false;
			}

		}
		console.log("showFacturaIngreso-globalCambiosFactoringHabilitados " + this.globalCambiosFactoringHabilitados);
    	//if(!dijit.byId("inicio.form").validate()) return;
		console.log("ok..1");
		this.cargarValoresGlobales();
		console.log("ok..2");
		dijit.byId("inicio.botonGrabarDocumento").attr('disabled', false);

		var valExportacion = dojo.byId("global.opcionExportacion").value;
		var valNodomic = dojo.byId("global.opcionNodomic").value;

    	if (valExportacion == "1") { //Exportacion
		    //PAS20181U210300095
			var td = dijit.byId("inicio.tipoDocumento").getValue();
    		var ndControl = dijit.byId("inicio.numeroDocumento");
    		var ndLength = dojo.trim(ndControl.getValue()).length;

			var expRSControl = dijit.byId("inicio.exportacion.razonSocial");
			var expRSLength = dojo.trim(expRSControl.getValue()).length;

			var expRazonSocControl = dijit.byId("inicio.razonSocial");
			var expRazonSocLength = dojo.trim(expRazonSocControl.getValue()).length;

    		if(td != '-' && ndLength == 0){
				mostrarMensaje("Tiene que ingresar un número de documento.");
				ndControl.focus();
				return;
    		} else {
				if (td == "-"){ //SIN DOCUMENTO
					if (expRSLength == 0){
						mostrarMensaje("Tiene que ingresar Razon Social.");
						expRSControl.attr('value', "");
						expRSControl.focus();
						return;
					}
				} else if (td == "6") { //RUC
					this.self = this;
					if(!this.isValidRuc(dojo.trim(ndControl.getValue()))) {
						mostrarMensaje("N\u00FAmero de RUC incorrecto.");
						ndControl.attr('value', "");
						ndControl.focus();
						return;
					}
				} else if (td == "0" || td == "B" || td == "C" || td == "D") { // DOC.TRIB.NO.DOM.SIN.RUC, DOC.IDENTIF.PERS.NAT.NO DOM., TAX IDENTIFICATION NUMBER - TIN – DOC TRIB PP.NN, IDENTIFICATION NUMBER - IN – DOC TRIB PP. JJ
					// PAS20211U210100010
					if (expRazonSocLength < 3){
						// mostrarMensaje("Tiene que ingresar el DOC.TRIB.NO.DOM.SIN.RUC.");
						mostrarMensaje("Debe ingresar mínimo 3 y máximo 200 caracteres para los apellidos y nombres del cliente");
						expRazonSocControl.attr('value', "");
						expRazonSocControl.focus();
						return;
					}
				}
    		}

    		this.showTipoBeneficio(0);
   		} else  {
			if(!dijit.byId("inicio.numeroDocumento").validate())
			{
				return;
			}

			/*if(!dijit.byId("inicio.razonSocial").validate())
			{
				return;
			}*/

    		if (valNodomic =="1"){   //No domiciliado
    			var tipoDocNodomic  = dijit.byId("inicio.tipoDocRecepFENodomic").getValue().substring(0,1);
          	  	if (tipoDocNodomic =="-"){
          	  		this.iconTooltipMessage("inicio.tipoDocRecepFENodomic", "icon-ok-tooltip", "Debe seleccionar el tipo de documento.");
          	  		return;
          	  	}
          	  	var numeroDocNodomic  =dojo.trim( dijit.byId("inicio.numeroDocRecepFENodomic").getValue());
          	  	if (numeroDocNodomic ==""){
          	  		this.iconTooltipMessage("inicio.numeroDocRecepFENodomic", "icon-ok-tooltip", "Debe registrar el numero de documento.");
          	  		return;
          	  	}
      		  	var nombreDocNodomic  =dojo.trim( dijit.byId("inicio.nombreRazonRecepFENodomic").getValue());
      		  	if (nombreDocNodomic ==""){
      		  		this.iconTooltipMessage("inicio.nombreRazonRecepFENodomic", "icon-ok-tooltip", "Debe registrar el nombre o razon social.");
      		  		return;
      		  	}
      		  	var paisNoDomic  = dijit.byId("inicio.nacionalidadRecepFENodomic").getValue().substring(0,1);
      		  	if (paisNoDomic =="-"){
      		  		this.iconTooltipMessage("inicio.nacionalidadRecepFENodomic", "icon-ok-tooltip", "Debe seleccionar el pa\u00EDs de origen.");
      		  		return;
      		  	}

      		  	////////////
      		  	var fechaIngreso = dojo.byId("inicio.fecIngresoPaisRecepFENoDomic").value;
      		  	if(fechaIngreso == ""){
      		  		this.iconTooltipMessage("inicio.fecIngresoPaisRecepFENoDomic", "icon-ok-tooltip", "Debe registrar la fecha de ingreso al pais.");
      		  		return;
      		  	}
      		  	fechaIngreso = dijit.byId("inicio.fecIngresoPaisRecepFENoDomic").getValue();
      		  	var fechaHoy  = new Date();
      		  	var fechaIngresoDate  = new Date(fechaIngreso);

      		  	if (fechaIngresoDate > fechaHoy){
      		  		this.iconTooltipMessage("inicio.fecIngresoPaisRecepFENoDomic", "icon-ok-tooltip", "Fecha de ingreso al pais no puede ser mayor a la fecha de hoy");
      		  		return;
      		  	}

      		  	//////////
    		  	var tipoTarjeta  = dijit.byId("inicio.tipoTarjetaRecepFENodomic").getValue().substring(0,1);
    		  	if (tipoTarjeta =="-"){
    		  		this.iconTooltipMessage("inicio.tipoTarjetaRecepFENodomic", "icon-ok-tooltip", "Debe seleccionar el tipo de tarjeta.");
    		  		return;
    		  	}

       		  	var numeroTarjeta  =dojo.byId("inicio.numeroTarjetaRecepFENodomic").value;
       		  	if (numeroTarjeta ==""){
       		  		this.iconTooltipMessage("inicio.numeroTarjetaRecepFENodomic", "icon-ok-tooltip", "Debe registrar el numero de tarjeta.");
       		  		return;
       		  	}

           		var bancoTarjeta  =dojo.trim( dijit.byId("inicio.bancoEmisorTarjetaRecepFENodomic").getValue());
           		if (bancoTarjeta ==""){
           			//this.iconTooltipMessage("inicio.bancoEmisorTarjetaRecepFENodomic", "icon-ok-tooltip", "Debe registrar el banco emisor de la tarjeta.");
           			//return;
           		}

           		mostrarMensaje("La Factura Electronica de Venta Nacional a No Domiciliados es solo para venta de bienes.");
    		} else {
				console.log("showFacturaIngreso-contado ");
    			var td = dijit.byId("inicio.tipoDocumento").getValue();
    			var ndControl = dijit.byId("inicio.numeroDocumento");
    			var ndLength = dojo.trim(ndControl.getValue()).length;
    			console.log("showFacturaIngreso-td " + td);
				console.log("showFacturaIngreso-ndControl " + ndControl);
				console.log("showFacturaIngreso-ndLength " + ndLength);
    			if(td != '-' && ndLength == 0){
					console.log("sin documento " + ndLength);
					mostrarMensaje("Tiene que ingresar un número de documento.");
					ndControl.focus();
					return;
    			} else if (td != "-"){
    				if (td == "1"){ //DNI
						if (ndLength != 8){
							mostrarMensaje("N\u00FAmero de documento de identidad inconsistente.");
							ndControl.attr('value', "");
							ndControl.focus();
							return;
						}
					} else if (td == "6") { //RUC
						this.self = this;
						if(!this.isValidRuc(dojo.trim(ndControl.getValue()))) {
							mostrarMensaje("N\u00FAmero de RUC incorrecto.");
							ndControl.attr('value', "");
							ndControl.focus();
							return;
						}
					}
    			}

        		this.showTipoBeneficio(1);
    		}
    	}

		var nbControl = dijit.byId("inicio.botonGrabarDocumento");
		nbControl.attr('disabled', true);
		this.wait("Procesando", "95px", 200);
		dojo.byId("action").value = "datosInicial";
		//var self = this;
		var opcionTipoTransaccionGlobal="";
		if(dojo.byId("global.opcionTipoTransaccion")!=null){
			opcionTipoTransaccionGlobal=dojo.byId("global.opcionTipoTransaccion").value;
		}

		var handler = dojo.io.iframe.send({
			url: this.controller  + "?opcionTipoTransaccionGlobal=" + opcionTipoTransaccionGlobal,
			handleAs: "json",
			sync: true,
			timeout: 10000,
			preventCache: true,
			form: "global.form"
		});
		var moneda = dojo.byId("global.tipoMoneda").value; //PAS20201U210100285 - jmendozas
		handler.addCallback(dojo.hitch(this, function(res){
			this.waitMessage.hide();
			if(res.codeError == 0) {
				this.content.onLoad = dojo.hitch(this, function(){
					document.getElementById("factura.form").style.height = "auto";

					if (dojo.byId("global.opcionEstablecimientoEmisor").value =="1"){
						this.showHiddenDiv(document.getElementById("factura.estabEmisor.show"),true);
						// dijit.byId("factura.establecimientoEmisor").set("value",dojo.byId("global.opcionEstablecimientoEmisorDireccion").value);
						dijit.byId("factura.establecimientoEmisor").set("value","");

						//PAS20201U210100151
						var newStore =[];

						var URL = "emitir.do?action=getDomiciliosEmisor&opcionTipoTransaccionGlobal=" +  opcionTipoTransaccionGlobal;
						var kw = {
		           				url:URL,
		           				handleAs: "json",
		           				load: function(response, ioArgs) {
		           				       console.log(response);
		           				       newStore= response.items;
		           						},
		           				preventCache: false,
		           				timeout: 35000,
		           				sync:true,
		           				error: function(error,ioArgs){
		           						mostrarMensaje("Ha ocurrido el siguiente error:" + error.message + " " +  ioArgs.xhr.status);
		       				}};
						dojo.xhrGet(kw);

						var filas=newStore.length;

						for (i=0; i< filas;i++){
							if(i==0 && newStore[i].tipo=='DOMICILIO FISCAL'){
								dojo.byId("global.opcionEstablecimientoEmisorDireccion").value = newStore[i].domicilio;
								dojo.byId("global.opcionEstablecimientoEmisorSeleccionado").value = i;

								var handler = dojo.io.iframe.send({
								url: this.controller + "?action=datosEstabEmisor&id=" + dojo.byId("global.opcionEstablecimientoEmisorIdentifica").value + "&codigo=" + newStore[i].codigo + "&ubigeo=" + newStore[i].ubigeo + "&domicilio=" + encodeURIComponent(newStore[i].domicilio) + "&num_ruc_domicilio=" + encodeURIComponent(dojo.byId("global.numRucEmisor").value) + "&cod_estab=" +  newStore[i].cod_estab,
								// url: this.controller + "?action=datosEstabEmisor&id=" + dojo.byId("global.opcionEstablecimientoEmisorIdentifica").value + "&codigo=" + newStore[i].codigo + "&ubigeo=" + newStore[i].ubigeo + "&domicilio=" + encodeURIComponent(newStore[i].domicilio) + "&num_ruc_domicilio=" + encodeURIComponent(dojo.byId("global.numRucEmisor").value) + "&cod_estab=" +  newStore[i].cod_estab + "&opcionTipoTransaccionGlobal=" +  opcionTipoTransaccionGlobal, //PAS20201U210100230
								handleAs: "json",
									sync: true,
									timeout: 10000,
									preventCache: true
								});

								handler.addCallback(dojo.hitch(this, function(res){
									if(res.codeError == 0) {
										dijit.byId("factura.establecimientoEmisor").set("value",dojo.byId("global.opcionEstablecimientoEmisorDireccion").value);

										if (document.getElementById("establecimiento")){
											document.getElementById("establecimiento").value=(res.data);
										}
									}
								}));

								break;
							}
						}
						//PAS20201U210100151

      				} else {
      					this.showHiddenDiv(document.getElementById("factura.estabEmisor.show"),false);
      					dijit.byId("factura.establecimientoEmisor").set("value","");
					}

            		if (dojo.byId("global.opcionDomicilioCliente").value =="1"){
						console.log("valExportacion --> " + valExportacion);//PAS20211U210700060
						this.showHiddenDiv(document.getElementById("factura.direccCliente.show"),true);
						dijit.byId("factura.direccionCliente").set("value",dojo.byId("global.opcionDomicilioClienteDireccion").value);
						//PAS20211U210700060
						if (valExportacion == "0" || (valExportacion == "1" && dojo.byId("global.tipoDocumento").value == "6")) {
							//PAS20201U210100151
							var newStore =[];

							var URL = "emitir.do?action=getDomiciliosCliente";
							var kw = {
									url:URL,
									handleAs: "json",
									load: function(response, ioArgs) {

										   newStore= response.items;
											},
									preventCache: false,
									timeout: 35000,
									sync:true,
									error: function(error,ioArgs){
											mostrarMensaje("Ha ocurrido el siguiente error:" + error.message + " " +  ioArgs.xhr.status);
								}};
							dojo.xhrGet(kw);

							var filas=newStore.length;

							for (i=0; i< filas;i++){
								if(i==0 && newStore[i].tipo=='DOMICILIO FISCAL'){
									dojo.byId("global.opcionDomicilioClienteDireccion").value = newStore[i].domicilio;
									dojo.byId("global.opcionDomicilioClienteSeleccionado").value = i;

									var handler = dojo.io.iframe.send({
										url: this.controller + "?action=datosDireccCliente&subTipoEdireccCliente=1&codigo=" + newStore[i].codigo + "&coddist=" + newStore[i].ubigeo + "&domicilio=" + encodeURIComponent(newStore[i].domicilio) + "&cod_estab=" + newStore[i].cod_estab + "&num_ruc_domicilio=" + dojo.byId("global.numRucEmisor").value + "&refer=&tipvia=&tipzon=&num=&mz=&lote=&dep=&int=&km=&nomzon=&nomvia=",
										//url: this.controller + "?action=datosDireccCliente&subTipoEdireccCliente=1&codigo=" + newStore[i].codigo + "&coddist=" + newStore[i].ubigeo + "&domicilio=" + encodeURIComponent(newStore[i].domicilio) + "&cod_estab=" + newStore[i].cod_estab + "&num_ruc_domicilio=" + dojo.byId("global.numRucEmisor").value + "&refer=&tipvia=&tipzon=&num=&mz=&lote=&dep=&int=&km=&nomzon=&nomvia=" + "&opcionTipoTransaccionGlobal=" +  dojo.byId("global.opcionTipoTransaccion").value, //PAS20201U210100230,
										handleAs: "json",
										sync: true,
										timeout: 10000,
										preventCache: true
									});

									handler.addCallback(dojo.hitch(this, function(res){
										this.waitMessage.hide();
										if(res.codeError == 0) {
											dijit.byId("factura.direccionCliente").set("value",dojo.byId("global.opcionDomicilioClienteDireccion").value);
										} else {
											mostrarMensaje(res.messageError);
											nbControl.attr('disabled', false);
										}
									}));

									break;
								}
							}
							//PAS20201U210100151
						}
            		} else {
              		     this.showHiddenDiv(document.getElementById("factura.direccCliente.show"),false);
              			 dijit.byId("factura.direccionCliente").set("value","");
					}

            		if (dojo.byId("global.tipoDocumento").value == "6"
            			|| dojo.byId("global.tipoDocumento").value == "1") {
            			this.showHiddenDiv(document.getElementById("factura.ruc.show"),true);
            			this.showHiddenDiv(document.getElementById("factura.razonSocial.show"),false);

            			dijit.byId("factura.numeroDocumento").setValue(dojo.byId("global.numeroDocumento").value);
            			dijit.byId("factura.razonSocial").setValue(dojo.byId("global.numeroDocumentoDesc").value);
            		} else {
            			dijit.byId("factura.exportacion.razonSocial").setValue(dojo.byId("global.numeroDocumentoExpDesc").value);
            			this.showHiddenDiv(document.getElementById("factura.ruc.show"),false);
            			this.showHiddenDiv(document.getElementById("factura.razonSocial.show"),true);

            			// PAS20211U210100010

            			if (dojo.byId("global.tipoDocumento").value == "0" || dojo.byId("global.tipoDocumento").value == "B" ||
            			    dojo.byId("global.tipoDocumento").value == "C" || dojo.byId("global.tipoDocumento").value == "D") {

            				dijit.byId("factura.exportacion.razonSocial").setValue(dojo.byId("global.numeroDocumentoDesc").value);

            			}

            		}

            		if (dojo.byId("global.opcionExportacion").value == "1") {
            			dijit.byId("factura.chkExportacion").attr('checked', true) ;
            		}

            		if (dojo.byId("global.opcionOperacionesGratuitas").value == "1"){
            			dijit.byId("factura.chkOperGratuitas").attr('checked', true) ;
            		}

            		if (dojo.byId("global.opcionNodomic").value == "1") {
            			dijit.byId("factura.tipoDocumentoNoDomic").setValue(dojo.byId("global.tipoDocumentoNodomic").value);
            			dijit.byId("factura.numeroDocumentoNoDomic").setValue(dojo.byId("global.numeroDocumentonoDomic").value);
            			dijit.byId("factura.razonSocialNoDomic").setValue(dojo.byId("global.razonSocialNoDomic").value);
            			this.showHiddenDiv(document.getElementById("factura.ruc.show"),false);
            			this.showHiddenDiv(document.getElementById("factura.razonSocial.show"),false);
                        this.showHiddenDiv(document.getElementById("factura.docsNoDomic.show"),true);
            		}

            		if (dojo.byId("global.opcionExportacion").value == "1" || dojo.byId("global.opcionOperacionesGratuitas").value == "1") {
            			this.showHiddenDiv(document.getElementById("factura.situacionEspecial.show"),true);
            		} else {
            			this.showHiddenDiv(document.getElementById("factura.situacionEspecial.show"),false);
            		}

            		if (dojo.byId("global.opcionOro").value == "1") {
            			this.showHiddenDiv(document.getElementById("factura.registroRECPO.show"),true);

            			if ( dijit.byId("comercializaOro.condicionRECPO").getValue() == "03"  || dijit.byId("comercializaOro.CVOroOperacion").getValue() == "03"){
            				this.showHiddenDiv(document.getElementById("listadoCPDisp"),true);
            			}else{
            				this.showHiddenDiv(document.getElementById("listadoCPDisp"),false);
            			}

            			if ( dijit.byId("comercializaOro.condicionRECPO").getValue() == "01"  || dijit.byId("comercializaOro.CVOroOperacion").getValue() == "02"){
            				this.showHiddenDiv(document.getElementById("listadoCCDisp"),true);

            			}else{
            				this.showHiddenDiv(document.getElementById("listadoCCDisp"),false);
            			}
            		} else {
            			this.showHiddenDiv(document.getElementById("factura.registroRECPO.show"),false);
            		}

            		dijit.byId("factura.tipoMonedaDesc").setValue(dojo.byId("global.tipoMonedaDesc").value);
            		/////////////////////

            		if (dojo.byId("global.opcionEstablecimientoEmisor").value =="1"){
            			this.iconTooltipMessage("factura.bntestablecimientoEmisor", "icon-ok-tooltip", "Registrar Direcci\u00F3n.");
					}

            		if (dojo.byId("global.opcionDomicilioCliente").value =="1"){
            			this.iconTooltipMessage("factura.bntdireccionCliente", "icon-ok-tooltip", "Registrar Direcci\u00F3n.");
            		}
					this.iconTooltipMessage("factura.addItemButtonToolTip", "icon-ok-tooltip", "Adicionar items a la factura.");

					if (dojo.byId("global.fecVencimiento").value == ""){
						dijit.byId("factura.fechaVencimiento").setValue(null);
					}

					//PAS20201U210100230 ini
					if(dojo.byId("global.opcionTipoTransaccion")!=null){
						// INICIO PAS20211U210700145 - AVN
						this.showHiddenDiv(document.getElementById("factura.fechaVencimiento"),false);
						// FIN PAS20211U210700145 - AVN
						if (dojo.byId("global.opcionTipoTransaccion").value == "2"){
							dijit.byId("factura.fechaVencimiento").setAttribute('disabled', true);
						}else{
							dijit.byId("factura.fechaVencimiento").setAttribute('disabled', false);
						}
					}
					//PAS20201U210100230 FIN
					//PAS20201U210100285 - jmendozas
					if(dojo.byId("factura.montoRedondeo") != null){ /* PAS20201U210100285 - Factura Contingencia */
						document.getElementById("factura.montoRedondeo").style.textAlign = "right";
						dijit.byId("factura.montoRedondeo").constraints = {min:-0.09,max:0.09,currency:moneda, places: '2,2',pattern:"\u00A4 #,##0.##;\u00A4 -#,##0.##"};

						dijit.byId("factura.montoRedondeo").attr('value',0.00);

					}

					//FIN PAS20201U210100285

            		/////////////////////
            		this.updateTotalAmount();
					this.loadUnidadMedida();

					//PAS20191U210100075 - jsantivanez

					/*if (dojo.byId("global.opcionPagoAnticipado").value == "1") {

						dijit.byId("check.impuestoBolsasPlastica00").setAttribute('disabled', true);
						dijit.byId("check.impuestoBolsasPlastica01").setAttribute('disabled', true);
						dijit.byId("item.periodoBolsa").setAttribute('disabled', true);

					}*/
					//PAS20191U210100075 - jsantivanez
        		});
                this.content.setHref(this.controller + "?action=showIngresoFactura&preventCache=" + this.preventCache());
			}
			else {
				mostrarMensaje(res.messageError);
				nbControl.attr('disabled', false);
			}
		}));

		handler.addErrback(function(res){
		nbControl.attr('disabled', false);
		this.waitMessage.hide();
		mostrarMensaje("Problemas al conectarse con el servidor");
		});
	},

	validateRUCTercero: function(){
    	var emisor = dojo.byId("global.numRucEmisor").value;
    	var ndControl = dojo.byId("direccCliente.txt_ruc_tercero");

    	var ndLength = dojo.trim(ndControl.value).length;
    	if (ndLength != 11){
    		return;
    	}
    	if(ndLength == 0) {
    		mostrarMensaje("Tiene que ingresar un número de RUC.");
    		ndControl.attr('value', "");
    		ndControl.focus();
    		return;
		}

    	if (dojo.trim(ndControl.value)==emisor){
    		mostrarMensaje("No debe ingresar su propio n\u00FAmero de RUC como el de un tercero.");
		    ndControl.attr('value', "");
			ndControl.focus();
			return;
    	}

    	if (!this.isValidRuc(dojo.trim(ndControl.value))){
    		mostrarMensaje("N\u00FAmero de RUC inv\u00E1lido.");
		    ndControl.attr('value', "");
			ndControl.focus();
			return;
    	}

		var handler = dojo.xhrGet({
			preventCache:  false,
			url:  this.controller + "?action=buscarEstabTercero&rucTercero=" + dojo.trim(ndControl.value),
			handleAs: "json",
			sync: true,
			timeout: 10000
		});

		handler.addCallback(dojo.hitch(this, function(res){
			if(res.codeError == 0) {
				var newStore = new dojo.data.ItemFileWriteStore({url: 'emitir.do?action=getDomicilios'});
				var grid = dijit.byId("direccCliente.domiciliosGrid");
				grid.setStore(null);
				grid.setStore(newStore);
				this.showHiddenDiv(document.getElementById("direccCliente.div_domin_terc"),true);
			} else {
				mostrarMensaje(res.messageError);
			}
		}));

		handler.addErrback(function(res){
			// PAS20201U210100046
			mostrarMensaje("Se produjo un error al intentar recuperar los domicilios del tercero. Por favor volver a intentar.");
			console.log("error validateRUCTercero " + res.message);
			console.log("error validateRUCTercero " + res.messageError);
		});
	},

	validateRUCTerceroPP: function(){
    	var emisor = dojo.byId("global.numRucEmisor").value;
		var ndControl = dojo.byId("puntoPartida.txt_ruc_tercero");

		var ndLength = dojo.trim(ndControl.value).length;
		if (ndLength != 11){
			return;
		}
		if(ndLength == 0) {
			mostrarMensaje("Tiene que ingresar un número de RUC.");
			ndControl.attr('value', "");
			ndControl.focus();
			return;
		}

		if (dojo.trim(ndControl.value)==emisor){
			mostrarMensaje("No debe ingresar su propio n\u00FAmero de RUC como el de un tercero.");
		    ndControl.attr('value', "");
		    ndControl.focus();
		    return;
		}
		//

		ruc=dojo.trim(ndControl.value);
		suma = 0;
		x = 6;
		for(i=0; i < ruc.length - 1; i++) {
			if(i == 4) x = 8;
			digito = ruc.charAt(i) - '0';
			x--;
			if(i == 0) suma += (digito * x);
			else suma += (digito * x);
		}
		resto = suma % 11;
		resto = 11 - resto;
		if(resto >= 10) resto = resto - 10;
		if(resto == ruc.charAt(ruc.length - 1) - '0') {
		} else {
			mostrarMensaje("N\u00FAmero de RUC inv\u00E1lido.");
			ndControl.attr('value', "");
			ndControl.focus();
			return;
        }
		//
		/*
    	if (!self.isValidRuc(dojo.trim(ndControl.value))){
    		mostrarMensaje("N\u00FAmero de RUC inv\u00E1lido.");
		    ndControl.attr('value', "");
			ndControl.focus();
			return;
    	}
		*/
		var handler = dojo.xhrGet({
			preventCache:  false,
			url:  "emitir.do?action=buscarEstabTercero&rucTercero=" + dojo.trim(ndControl.value),
			handleAs: "json",
			sync: true,
			timeout: 10000
		});

		handler.addCallback(dojo.hitch(self, function(res){
			if(res.codeError == 0) {
				var newStore = new dojo.data.ItemFileWriteStore({url: 'emitir.do?action=getDomicilios'});
				var grid = dijit.byId("puntoPartida.domiciliosGrid");
				grid.setStore(newStore);
				document.getElementById("puntoPartida.div_domin_terc").style.display = ""
			} else {
				mostrarMensaje(res.messageError);
			}
		}));

		handler.addErrback(function(res){
			mostrarMensaje("Ocurrio un error al obtener los domicilios del tercero: " + res.message);
		});
	},

	validateRUCTerceroPLL: function(){
    	var emisor = dojo.byId("global.numRucEmisor").value;
		var ndControl = dojo.byId("puntoLlegada.txt_ruc_tercero");
		var ndLength = dojo.trim(ndControl.value).length;

		if (ndLength != 11){
		   return;
		}

		if(ndLength == 0) {
			mostrarMensaje("Tiene que ingresar un número de RUC.");
			ndControl.attr('value', "");
			ndControl.focus();
			return;
		}

	    if (dojo.trim(ndControl.value)==emisor){
	    	mostrarMensaje("No debe ingresar su propio n\u00FAmero de RUC como el de un tercero.");
		    ndControl.attr('value', "");
		    ndControl.focus();
		    return;
	    }
	    //

	    ruc=dojo.trim(ndControl.value);
	    suma = 0;
	    x = 6;
	    for(i=0; i < ruc.length - 1; i++) {
	    	if(i == 4) x = 8;
	    	digito = ruc.charAt(i) - '0';
	    	x--;
	    	if(i == 0) suma += (digito * x);
	    	else suma += (digito * x);
	    }
	    resto = suma % 11;
	    resto = 11 - resto;
	    if(resto >= 10) resto = resto - 10;
	    if(resto == ruc.charAt(ruc.length - 1) - '0') {

	    }  else{
	    	mostrarMensaje("N\u00FAmero de RUC inv\u00E1lido.");
	    	ndControl.attr('value', "");
	    	ndControl.focus();
	    	return;
        }
	    //
	    /*
    	if (! self.isValidRuc(dojo.trim(ndControl.value))){
    		mostrarMensaje("N\u00FAmero de RUC inv\u00E1lido.");
		    ndControl.attr('value', "");
			ndControl.focus();
			return;
    	}*/

		var handler = dojo.xhrGet({
			preventCache:  false,
			url:  "emitir.do?action=buscarEstabTercero&rucTercero=" + dojo.trim(ndControl.value),
			handleAs: "json",
			sync: true,
			timeout: 10000
		});

		handler.addCallback(dojo.hitch(self, function(res){
			if(res.codeError == 0) {
				var newStore = new dojo.data.ItemFileWriteStore({url: 'emitir.do?action=getDomicilios'});
				var grid = dijit.byId("puntoLlegada.domiciliosGrid");
				grid.setStore(newStore);

				document.getElementById("puntoLlegada.div_domin_terc").style.display = ""
			} else {
				mostrarMensaje(res.messageError);
			}
		}));

		handler.addErrback(function(res){
			mostrarMensaje("Ocurrio un error al obtener los domicilios del tercero: " + res.message);
		});
	},

	loadUnidadMedida: function() {



		var handler = dojo.xhrGet({
			preventCache:  false,
			url: this.controller + "?action=loadUnidadMedida",
			handleAs: "json",
			sync: true,
			timeout: 10000
		});

		handler.addCallback(dojo.hitch(this, function(res){
			//this.waitMessage.hide();
    		this.unidadMedidaStore = null;
    		var data = null;
    		var values = [];
    		if(res.codeError == 0) {
      			if(res.data.length > 0 && res.data != "[]") {
        			data = eval("(" + res.data + ")");
        			values.push({name:"", abbreviation:"000"});
        			for (var x = 0 ; x < data.length ; x++) {
        				//mostrarMensaje(data[x].unidadMedida + " - " + data[x].descripcionMedida);
        				values.push({name:data[x].descripcionMedida, abbreviation:data[x].unidadMedida});
        			}
      			} else {
      				 this.unidadMedidaStore = null;
      			}
    		} else {
    			this.iconTooltipMessage(nodeButton, "icon-error-tooltip", res.messageError);
    		}
		    var dataItems = { identifier: 'abbreviation', items: values, handleAs: "json" ,preventCache: true};
	        var store = new dojo.store.Memory({data:dataItems});
	        dijit.byId("item.unidadMedida").store = store;
		}));

		handler.addErrback(function(res){
			//this.waitMessage.hide();
			this.messageBox("Problemas al conectarse con el servidor");
		});
	},

	//INI: PAS20191U210100075 jsantivanez
	loadImpuestoBolsa: function() {
		//console.log(dojo.byId("factura.fechaEmision").value);
		//console.log(dijit.byId("factura.fechaEmision").getValue());
		var parts = dojo.byId("factura.fechaEmision").value.split('/');

		var fechaEmision = new Date(parts[2],parts[1]-1,parts[0]);

		//fecha properties
		var parts2 = dojo.byId("item.FechaProperties").value.split('/');
		var fechaproperties = new Date(parts2[2],parts2[1]-1,parts2[0]);

		console.log(dojo.byId("factura.fechaEmision").value);
		console.log(dojo.byId("item.FechaProperties").value);


		if(fechaEmision < fechaproperties){

			mostrarMensaje("ICBPER es invalido en comprobantes inferiores a la fecha " + dojo.byId("item.FechaProperties").value);

			return false;

		}else{

			var moneda = dojo.byId("global.tipoMoneda").value;
			var handler = dojo.xhrGet({
				preventCache:  false,
				url: this.controller + "?action=loadImpuestoBolsa",
				handleAs: "json",
				sync: true,
				timeout: 10000
			});

			handler.addCallback(dojo.hitch(this, function(res){
				//this.waitMessage.hide();
				this.unidadMedidaStore = null;
				var data = null;
				var values = [];
			var values2 = [];
				if(res.codeError == 0) {
					if(res.data.length > 0 && res.data != "[]") {
						data = eval("(" + res.data + ")");
						values.push({name:"", abbreviation:"000"});
						for (var x = 0 ; x < data.length ; x++) {


							if (data[x].periodoTributo==fechaEmision.getFullYear() || (data[x].periodoTributo==fechaEmision.getFullYear() -1 && fechaEmision.getMonth() == 0)){
								values.push({name:data[x].periodoTributo, abbreviation:data[x].tasaTributo});
							  //mostrarMensaje(data[x].periodoTributo + " - " + data[x].tasaTributo);
							}else if (fechaEmision.getFullYear() > 2023){

								/*if(fechaEmision.getMonth() == 0){

									values.push({name:(fechaEmision.getFullYear() - 1).toString() , abbreviation:"0.50"} );
								}*/

								values.push({name:fechaEmision.getFullYear().toString(), abbreviation:"0.50"} );
								break;
							}

						}
					}else {
						 this.unidadMedidaStore = null;
					}
				} else {
					this.iconTooltipMessage(nodeButton, "icon-error-tooltip", res.messageError);
				}

				var dataItems = { identifier: 'abbreviation', items: values, handleAs: "json" ,preventCache: true};


				var store = new dojo.store.Memory({data:dataItems});



				dijit.byId("item.periodoBolsa").store = store;


				var selectperiodoBolsa = dijit.byId('item.periodoBolsa');




				/*selectperiodoBolsa.on('change', function(evt) {
					console.log("tasa bolsaaaaa" + evt);
					dijit.byId("item.tasaBolsa").attr('value',dojo.currency.format(evt, {currency: moneda, places: 2}));
					//dijit.byId("item.tasaBolsa").setValue(evt);
					document.getElementById("item.tasaBolsaGlobal").value = evt;
					document.getElementById("item.PeriodoBolsaGlobal").value = dijit.byId("item.periodoBolsa").get('displayedValue');
				});*/

				var anio = fechaEmision.getFullYear();
				if (anio > 2023){
					anio = "2023";
				}
				//dijit.byId("item.periodoBolsa").set("displayedValue", anio.toString());

			}));

			handler.addErrback(function(res){
				//this.waitMessage.hide();
				this.messageBox("Problemas al conectarse con el servidor");
			});

			return true;
		}



	},

	selectperiodoBolsaChange: function(evt) {

		console.log("tasa bolsaaaaa1 " + evt);
		if(evt == "000"){

			console.log(dojo.byId("item.PeriodoBolsaGlobal").value);

			dijit.byId("item.periodoBolsa").set("displayedValue", dojo.byId("item.PeriodoBolsaGlobal").value);

		}else{

		console.log(dojo.byId("item.PeriodoBolsaGlobal").value);
		console.log(dojo.byId("item.tasaBolsaGlobal").value);

		var moneda = dojo.byId("global.tipoMoneda").value;
		var evt = dijit.byId('item.periodoBolsa').getValue();
		console.log("tasa bolsaaaaa2 " + evt);

		dijit.byId("item.tasaBolsa").attr('value',dojo.currency.format(evt, {currency: moneda, places: 2}));
		//dijit.byId("item.tasaBolsa").setValue(evt);
		document.getElementById("item.tasaBolsaGlobal").value = evt;
		document.getElementById("item.PeriodoBolsaGlobal").value = dijit.byId("item.periodoBolsa").get('displayedValue');
		this.updateItemAmount();

		}
	},

	esNrus: function() {

		var handler = dojo.xhrGet({
			preventCache:  false,
			url: this.controller + "?action=validadNRus",
			handleAs: "json",
			sync: true,
			timeout: 10000
		});

		handler.addCallback(dojo.hitch(this, function(res){
			//this.waitMessage.hide();
    		this.unidadMedidaStore = null;
    		var data = null;
    		var values = [];
			var values2 = [];
    		if(res.codeError == 0) {
      			if(res.data.length > 0 && res.data != "[]") {
        			data = eval("(" + res.data + ")");
        			console.log(data);
        			for (var x = 0 ; x < data.length ; x++) {

						console.log(data[x].fechavalida);
						console.log(data[x].indice);

						if (data[x].fechavalida=="true"){
							console.log("fecha valida");
							if (data[x].indice==0){
								console.log("indice 0 ");
								//No es NRUS
								//return false;
								this.nrus = "false";

							}else{
								console.log("indice 1 ");
								//Es NRUS
								//return true;
								this.nrus = "true";
							}

						}else {
							//ocultar
							//return true;
							this.nrus = "true";
						}

        			}
      			}else {
      				 this.unidadMedidaStore = null;
      			}
    		} else {
    			this.iconTooltipMessage(nodeButton, "icon-error-tooltip", res.messageError);
    		}

		}));

		handler.addErrback(function(res){
			//this.waitMessage.hide();
			this.messageBox("Problemas al conectarse con el servidor");
		});

	},
    //FIN: PAS20191U210100075

	resetValIGV: function() {
		var moneda = dojo.byId("global.tipoMoneda").value;

		dijit.byId("item.precioConIGV").constraints = {currency:moneda, places:'2,10'};//PAS20211U210100007
		dijit.byId("item.precioConIGV").setValue(0, false);
		this.updateItemAmount();
	},

	iconDel: function(rowindex) {
		return "<a href=\"#\" title=\"Eliminar\" onclick=\"factura.deleteItem('" + rowindex + "')\"><img class=\"icon-by-del16\" src=\"/a/imagenes/s.gif\"/></a>";
	},

    iconEdit: function(rowindex) {
		return "<a href=\"#\" title=\"Editar\" onclick=\"factura.editItem(" + rowindex + ")\"><img class=\"icon-by-edit16\" src=\"/a/imagenes/s.gif\"/></a>";
	},

	iconDelDocRel: function(rowindex) {
		return "<a href=\"#\" title=\"Eliminar\" onclick=\"factura.delOtherDocument(" + rowindex + ")\"><img class=\"icon-by-del16\" src=\"/a/imagenes/s.gif\"/></a>";
	},

  	iconDelLicencia: function(rowindex) {
		return "<a href=\"#\" title=\"Eliminar\" onclick=\"factura.delLicencia(" + rowindex+ ")\"><img class=\"icon-by-del16\" src=\"/a/imagenes/s.gif\"/></a>";
	},

	addLicencia: function() {
  		var ndSerie = dijit.byId("trasladoBienes.nroLicenciaConducir");
  		if(dojo.trim(ndSerie.value).length == 0) {
  			ndSerie.attr('invalidMessage', "Tiene que ingresar n&uacute;mero de licencia");
  			ndSerie.focus();
  			return;
  		}

		this.wait("Adicionando", "110px", 100);
		var nodeButton = dijit.byId("trasladoBienes.botonAddLicencia").focusNode;

		var handler = dojo.xhrGet({
			url: this.controller + "?action=addLicencia&licencia=" + ndSerie.value,
			handleAs: "json",
			sync: true,
			timeout: 10000,
			preventCache: true

		});

		handler.addCallback(dojo.hitch(this, function(res){
			this.waitMessage.hide();
			if(res.codeError == 0) {
				var oDoc = eval("(" + res.data + ")");

				var row = {
					identificador: this.nContLicencia ,  //
					elimina: this.nContLicencia ,
					licencia: (oDoc.numeroRuc == "-" ? "":oDoc.numeroRuc)
				};
				if(this.licenciaStore == null) this.licenciaStore = new dojo.data.ItemFileWriteStore({data: {identifier: 'identificador', items: [row], preventCache: true}});
				else this.licenciaStore.newItem(row);
				var grid = dijit.byId("licencias-grid");
				grid.setStore(this.licenciaStore);
				grid.update();
				this.nContLicencia++;
				ndSerie.setValue("");
			}
			else this.iconTooltipMessage(nodeButton, "icon-error-tooltip", res.messageError);
		}));

		handler.addErrback(dojo.hitch(this, function(res) {
			this.waitMessage.hide();
			this.iconTooltipMessage(nodeButton, "icon-error-tooltip", "Problemas al conectarse al servidor");
		}));
	},

	delLicencia: function(identificador) {
		//var nodeButton = dijit.byId("docrel.botonDelDoc").focusNode;
		var grid = dijit.byId("licencias-grid");

		/*
		if(!identificador) {
			var index = grid.getRowIndex();
			if(index > -1) {
				var row = grid.getRow(index);
				identificador = row.identificador;
			} else {
				mostrarMensaje("Seleccione un documento de la lista");
				return;
			}
		}
		*/
		this.licenciaStore.fetchItemByIdentity({
			identity: identificador,
			onItem: dojo.hitch(this, function(item){
				this.wait("Eliminando", "102px", 100);
				//if (identificador == 0){identificador=1;}
				var handler = dojo.xhrGet({
					url: this.controller + "?action=delLicencia&idItem=" + item._S._arrayOfAllItems[identificador].licencia[0],
					handleAs: "json",
					sync: true,
					timeout: 10000
				});
				handler.addCallback(dojo.hitch(this, function(res){
					this.waitMessage.hide();
					if (res.codeError == 0) {
						this.licenciaStore.deleteItem(item);
						grid.setStore(this.licenciaStore);
						grid.update();
					} else {
						mostrarMensaje(res.messageError);
					}
				}));
				handler.addErrback(dojo.hitch(this, function(res){
					this.waitMessage.hide();
					mostrarMensaje("Problemas al conectarse al servidor");
				}));

			}),
			onError: function(){
			mostrarMensaje("Ocurrio un error al ubicar la licencia");
			}
		});
	},

	valorUnitario: function(valor, rowindex) {
		var valor2 = valor.replace(',','');
	    if (valor2<0){
	    	return "";
	    }else{
	    	return valor;
	    }
	},
//PAS20201U210100230 -INI
	showDireccionReceptor:	function () {
		this.dialogDireccionContribuyente.show();
		this.showHiddenDiv(document.getElementById("domicilioContribuyente.domicilioFiscal"),true);

	},

	calculaRetencion: function (){

		var baseRetencion = dijit.byId("informacion.baseRetencion").getValue();
		var porcentajeRetencion = dojo.byId("global.porcentajeRetencion").value;
		var montoRetencion = 0;

		montoRetencion = baseRetencion*porcentajeRetencion/100.00;
		montoRetencion=Number.parseFloat(Math.round(montoRetencion*100))/100;
		dijit.byId("informacion.montoRetencion").setValue(montoRetencion);

		if (!isNaN(dijit.byId("informacion.baseRetencion").getValue()) && dijit.byId("informacion.baseRetencion").getValue() > 0 && dijit.byId("informacion.baseRetencion").getValue() < dojo.byId("global.importeTotal").value){

			this.montoBaseRetencion= dijit.byId("informacion.baseRetencion").getValue();
			this.montoNetoRetencion= montoRetencion;

		}


	},
//ALB
	showRetencion:	function () {
		this.dialogRetencion.show();
		this.showHiddenDiv(document.getElementById("informacion.retencion"),true);

		dijit.byId("informacion.baseRetencion").constraints = {places: '2,2'};//Jrgs
		/*dijit.byId("informacion.montoRetencion").constraints = {places: '2,10'};
		dijit.byId("informacion.porcentajeRetencion").constraints = {places: '2,10'};*/

		if((dijit.byId("informacion.baseRetencion").getValue() == 0 || isNaN(dijit.byId("informacion.baseRetencion").getValue())) && (this.montoBaseRetencion == 0 || this.montoBaseRetencion==null)){
			dijit.byId("informacion.baseRetencion").attr('value',0);
			dijit.byId("informacion.porcentajeRetencion").attr('value',dojo.byId("global.porcentajeRetencion").value +"%");
			dijit.byId("informacion.montoRetencion").attr('value',0);
		} else{
			dijit.byId("informacion.baseRetencion").attr('value',this.montoBaseRetencion);
			dijit.byId("informacion.porcentajeRetencion").attr('value',dojo.byId("global.porcentajeRetencion").value +"%");
			dijit.byId("informacion.montoRetencion").attr('value',this.montoNetoRetencion);

		}

	},
	//PAS20201U210100230 -FIN
	showEstabProp:	function () {
		var newStore = new dojo.data.ItemFileWriteStore({url: 'emitir.do?action=getDomiciliosCliente'});
	    var grid = dijit.byId("direccCliente.domiciliosGrid");
		grid.setStore(null);
	    grid.setStore(newStore);

		this.showHiddenDiv(document.getElementById("direccCliente.div_establecimiento"),true);
	    this.showHiddenDiv(document.getElementById("direccCliente.div_domin_terc"),true);
	    this.showHiddenDiv(document.getElementById("direccCliente.div_otro_local"),false);
	    this.showHiddenDiv(document.getElementById("direccCliente.div_ruc_tercero"),false);
	    dojo.byId("direccCliente.txt_ruc_tercero").value="";
	    dojo.byId("direccCliente.subTipoEdireccCliente").value="1";
	},

	showEstabTerc: function() {
		this.showHiddenDiv(document.getElementById("direccCliente.div_domin_terc"),false);
		this.showHiddenDiv(document.getElementById("direccCliente.div_establecimiento"), true);
	    this.showHiddenDiv(document.getElementById("direccCliente.div_ruc_tercero") , true);
	    this.showHiddenDiv(document.getElementById("direccCliente.div_otro_local"),false);
	    dojo.byId("direccCliente.subTipoEdireccCliente").value="2";
	},

	showEstabOtro: function () {
		this.showHiddenDiv(document.getElementById('direccCliente.div_establecimiento'),false);
	    this.showHiddenDiv(document.getElementById('direccCliente.div_ruc_tercero'),false);
	    document.getElementById('direccCliente.div_otro_local').style.display="block";
	    document.getElementById('direccCliente.txt_ruc_tercero').value="";
	    dojo.byId("direccCliente.subTipoEdireccCliente").value="3";
	},

	showEstablecimientoEmisor:	function () {
	    var newStore = new dojo.data.ItemFileWriteStore({url: 'emitir.do?action=getDomiciliosEmisor'});
	    var grid = dijit.byId("estabEmisor.domiciliosGrid");
		grid.setStore(null);
	    grid.setStore(newStore);
		this.dialogEstablecimientoEmisor.show();
	},

	showDireccionCliente:	function () {
		this.dialogDireccionCliente.show();
	   	if (dojo.byId("global.opcionDomicilioClienteIdentifica").value == ""){
			dijit.byId("direccCliente.subTipoEdireccCliente01").setChecked("checked");
			this.showEstabProp();
		}
	},

	showEstabPropPP:	function () {
	    var newStore = new dojo.data.ItemFileWriteStore({url: 'emitir.do?action=getDomiciliosEmisor'});
	    var grid = dijit.byId("puntoPartida.domiciliosGrid");
	  	grid.setStore(null);
	    grid.setStore(newStore);

		this.showHiddenDiv(document.getElementById("puntoPartida.div_establecimiento"), true);
	    this.showHiddenDiv(document.getElementById("puntoPartida.div_domin_terc"),true);
	    this.showHiddenDiv(document.getElementById("puntoPartida.div_otro_local"),false);
	    this.showHiddenDiv(document.getElementById("puntoPartida.div_ruc_tercero") , false);
	    dojo.byId("puntoPartida.txt_ruc_tercero").value="";
	    dojo.byId("puntoPartida.subTipoEpuntoPartida").value="1";
	},

	showEstabTercPP: function() {
		this.showHiddenDiv(document.getElementById("puntoPartida.div_domin_terc"),false);
		this.showHiddenDiv(document.getElementById("puntoPartida.div_establecimiento"), true);

		this.showHiddenDiv(document.getElementById("puntoPartida.div_ruc_tercero") , true);
		this.showHiddenDiv(document.getElementById("puntoPartida.div_otro_local"),false);
		dojo.byId("puntoPartida.subTipoEpuntoPartida").value="2";
	},

	showEstabOtroPP: function () {
		this.showHiddenDiv(document.getElementById('puntoPartida.div_establecimiento'),false);
	    this.showHiddenDiv(document.getElementById('puntoPartida.div_ruc_tercero'),false);
	    document.getElementById('puntoPartida.div_otro_local').style.display="block";
	    document.getElementById('puntoPartida.txt_ruc_tercero').value="";
	    dojo.byId("puntoPartida.subTipoEpuntoPartida").value="3";
	},

	showEstabPropPLL: function () {
	    var newStore = new dojo.data.ItemFileWriteStore({url: 'emitir.do?action=getDomiciliosCliente'});
	    var grid = dijit.byId("puntoLlegada.domiciliosGrid");
	    grid.setStore(null);
	    grid.setStore(newStore);
		this.showHiddenDiv(document.getElementById("puntoLlegada.div_establecimiento"), true);
	    this.showHiddenDiv(document.getElementById("puntoLlegada.div_domin_terc"),true);
	    this.showHiddenDiv(document.getElementById("puntoLlegada.div_otro_local"),false);
	    this.showHiddenDiv(document.getElementById("puntoLlegada.div_ruc_tercero") , false);
	    dojo.byId("puntoLlegada.txt_ruc_tercero").value="";
	    dojo.byId("puntoLlegada.subTipoEpuntoLlegada").value="1";
	},

	showEstabTercPLL: function() {
		this.showHiddenDiv(document.getElementById("puntoLlegada.div_domin_terc"),false);
		this.showHiddenDiv(document.getElementById("puntoLlegada.div_establecimiento"), true);
		this.showHiddenDiv(document.getElementById("puntoLlegada.div_ruc_tercero") , true);
		this.showHiddenDiv(document.getElementById("puntoLlegada.div_otro_local"),false);
		dojo.byId("puntoLlegada.subTipoEpuntoLlegada").value="2";
	},

	showEstabOtroPLL: function () {
		this.showHiddenDiv(document.getElementById('puntoLlegada.div_establecimiento'),false);
	    this.showHiddenDiv(document.getElementById('puntoLlegada.div_ruc_tercero'),false);
	    document.getElementById('puntoLlegada.div_otro_local').style.display="block";
	    document.getElementById('puntoLlegada.txt_ruc_tercero').value="";
	    dojo.byId("puntoLlegada.subTipoEpuntoLlegada").value="3";
	},

	daraltaadomicilio : function (coddist,tipodomic,tipvia,nomvia,tipzon,nomzon,local,km,mz,lote,dep,int) {
		//mostrarMensaje("tipodomic="+tipodomic+" tipvia="+tipvia+" nomvia="+nomvia+" tipzon="+tipzon+" nomzon="+nomzon+" local="+local);
		var seguir=0;
		var cod_tipodomic;
		var cod_local;

		if (tipodomic!=undefined) {
			cod_tipodomic=valorradiobutton(tipodomic);
			//mostrarMensaje("cod_tipodomic="+cod_tipodomic);
			if (cod_tipodomic==1 || cod_tipodomic==2) {
				if (local!=null) {
					cod_local=valorradiobutton(local);
					//mostrarMensaje("cod_local="+cod_local);
					if (cod_local==-1)
						mostrarMensaje("Debe escoger un local de la lista.");
					else {
						document.formaltadomicilio.accion.value="DaAltaADomicilioAdicional2";
						seguir=1;
					}
				}
				else
					mostrarMensaje("No hay ning\u00FAn local seleccionado. Realice una b\u00FAsqueda por RUC de un tercero si desea usar esta opci\u00F3n.");
			}
			else if (cod_tipodomic==3) {
				if (coddist.value.length<6)
					mostrarMensaje("Debe seleccionar departamento, provincia y distrito.");
				else if (trim(nomvia.value)=="" && trim(nomzon.value)=="")
					mostrarMensaje("Debe ingresar al menos uno de los campos marcados con asterisco (*).");
				else if (trim(nomvia.value)!="" && tipvia.selectedIndex==11)
					mostrarMensaje("Debe ingresar el tipo de via.");
				else if (trim(nomzon.value)!="" && tipzon.selectedIndex==11)
					mostrarMensaje("Debe ingresar al tipo de zona.");
				else if (km.value=="" && mz.value=="" && lote.value=="" && dep.value=="" && int.value=="")
					mostrarMensaje("Debe ingresar al menos el kil\u00F3metro, manzana, lote, departamento o interior.");
				else {
					document.formaltadomicilio.accion.value="DaAltaADomicilioAdicional2";
					seguir=1;
				}
			}
			else
				mostrarMensaje("Debe primero registrar un local, para ello seleccione una de las opciones.");
		}

		if (seguir==1){
			document.formaltadomicilio.btn_aceptar.disabled=true;
			document.formaltadomicilio.submit();
		}
	},


	limpiar: function(tipodomic) {
		var valtipodomic=valorradiobutton(tipodomic);

		if (valtipodomic=="2") {
			document.formaltadomicilio.numruc3.value="";
		}
		else if (valtipodomic=="3") {
			document.formaltadomicilio.dpto.selectedIndex=0;
			document.formaltadomicilio.prov.selectedIndex=0;
			document.formaltadomicilio.dist.selectedIndex=0;
			document.formaltadomicilio.coddpto.value="";
			document.formaltadomicilio.codprov.value="";
			document.formaltadomicilio.coddist.value="";
			document.formaltadomicilio.tipvia.selectedIndex=11;
			document.formaltadomicilio.nomvia.value="";
			document.formaltadomicilio.num.value="";
			document.formaltadomicilio.lote.value="";
			document.formaltadomicilio.km.value="";
			document.formaltadomicilio.dep.value="";
			document.formaltadomicilio.mz.value="";
			document.formaltadomicilio.int.value="";
			document.formaltadomicilio.tipzon.selectedIndex=11;
			document.formaltadomicilio.nomzon.value="";
			document.formaltadomicilio.refer.value="";
		}
	},

	//funciones para eventos
    startup: function(){
    	  dojo.parser.parse(dojo.byId('container'));
    	  setTimeout(dojo.hitch(this, function(){
		   this.initialize();
    	  }), 250);




    },

	preventCache: function() {
		return new Date().valueOf();
	},

  	wait: function(message, width) {
		dojo.byId("waitMessage").innerHTML="<div class='dijitInline box-message'></div><div class='dijitInline'>&nbsp;" + message + "...</div>";
	    dojo.byId("waitMessage").style.width = width;
	    this.waitMessage.show();
	},

	iconTooltipMessage: function(node, iconClass, message) {
		if(dojo.isString(node)) node = dojo.byId(node);
		dijit.focus(node);
		node.focus();
		dijit.showTooltip('<div class="' + iconClass + '"><div>' + message + '</div></div>', node, []);
		var blur = dojo.connect(node, "onblur", function() {
			dijit.hideTooltip(node);
			dojo.disconnect(blur);
		});
	},

	warnTooltipMessage: function(node, message) {
		this.iconTooltipMessage(node, "icon-warn-tooltip", message);
	},

    roundNumber: function(number, digits) {
    	var multiple = Math.pow(10, digits);
    	var rndedNum = Math.round(number * multiple) / multiple;
    	return rndedNum;
    },

    formatSelUbigeoEmisor: function(value, rowindex) {
		var valEstablecimientoEmisorSeleccionado = dojo.byId("global.opcionEstablecimientoEmisorSeleccionado").value;
		if (valEstablecimientoEmisorSeleccionado != null &&
			valEstablecimientoEmisorSeleccionado != "" &&
			valEstablecimientoEmisorSeleccionado == rowindex){
			return "<input id='estabEmisor.selDomicilioGrid" + rowindex + "' name='estabEmisor.selDomicilioGrid'  dojoType='dijit.form.RadioButton' type='radio' value='" + rowindex + "' checked ='checked' />"
		}else{
			//PAS20201U210100151
			if(rowindex==0){
				return "<input id='estabEmisor.selDomicilioGrid" + rowindex + "' name='estabEmisor.selDomicilioGrid'  dojoType='dijit.form.RadioButton' type='radio' value='" + rowindex + "' checked ='checked' />"
			}else{
				return "<input id='estabEmisor.selDomicilioGrid" + rowindex + "' name='estabEmisor.selDomicilioGrid'  dojoType='dijit.form.RadioButton' type='radio' value='" + rowindex + "' />"
				// "<a href=\"#\" onclick=\"descargaRVIPortal.descargarZip('" + rowindex +  "')\"> <img src=\"/a/imagenes/see/icons/download_16p.gif\" /></a>"
			}
			//PAS20201U210100151
		}
  	},

	formatSelUbigeoCliente: function(value,rowindex) {
		var valDomicilioClienteSeleccionado = dojo.byId("global.opcionDomicilioClienteSeleccionado").value;
		if (valDomicilioClienteSeleccionado != null &&
			valDomicilioClienteSeleccionado != "" &&
			valDomicilioClienteSeleccionado == rowindex){
			return "<input id='direccCliente.selDomicilioGrid" + rowindex + "' name='direccCliente.selDomicilioGrid'  dojoType='dijit.form.RadioButton' type='radio' value='" + rowindex + "' checked ='checked' />"
			// "<a href=\"#\" onclick=\"descargaRVIPortal.descargarZip('" + rowindex +  "')\"> <img src=\"/a/imagenes/see/icons/download_16p.gif\" /></a>"
		}
		else{
			//PAS20201U210100151
			if(rowindex==0){
				return "<input id='direccCliente.selDomicilioGrid" + rowindex + "' name='direccCliente.selDomicilioGrid'  dojoType='dijit.form.RadioButton' type='radio' value='" + rowindex + "' checked ='checked' />"
            }else{
            	return "<input id='direccCliente.selDomicilioGrid" + rowindex + "' name='direccCliente.selDomicilioGrid'  dojoType='dijit.form.RadioButton' type='radio' value='" + rowindex + "' />"
     			// "<a href=\"#\" onclick=\"descargaRVIPortal.descargarZip('" + rowindex +  "')\"> <img src=\"/a/imagenes/see/icons/download_16p.gif\" /></a>"
            }
			//PAS20201U210100151
		}
	},

    formatSelUbigeoPLL: function(value,rowindex) {
    	var valPuntoLlegadaSeleccionado= dojo.byId("global.opcionPuntoLlegadaSeleccionado").value;
  		if (valPuntoLlegadaSeleccionado != null &&
  			valPuntoLlegadaSeleccionado != "" &&
  			valPuntoLlegadaSeleccionado == rowindex){
  			return "<input id='puntoLlegada.selDomicilioGrid" + rowindex + "' name='puntoLlegada.selDomicilioGrid'  dojoType='dijit.form.RadioButton' type='radio' value='" + rowindex + "' checked ='checked' />"
  			// "<a href=\"#\" onclick=\"descargaRVIPortal.descargarZip('" + rowindex +  "')\"> <img src=\"/a/imagenes/see/icons/download_16p.gif\" /></a>"
  		}
  		else{
  			return "<input id='puntoLlegada.selDomicilioGrid" + rowindex + "' name='puntoLlegada.selDomicilioGrid'  dojoType='dijit.form.RadioButton' type='radio' value='" + rowindex + "' />"
  			// "<a href=\"#\" onclick=\"descargaRVIPortal.descargarZip('" + rowindex +  "')\"> <img src=\"/a/imagenes/see/icons/download_16p.gif\" /></a>"
  		}
  	},

    formatSelUbigeoPP: function(value,rowindex) {
    	var valPuntoPartidaSeleccionado = dojo.byId("global.opcionPuntoPartidaSeleccionado").value;
  		if (valPuntoPartidaSeleccionado != null &&
  			valPuntoPartidaSeleccionado != "" &&
  			valPuntoPartidaSeleccionado == rowindex){
  			return "<input id='puntoPartida.selDomicilioGrid" + rowindex + "' name='puntoPartida.selDomicilioGrid'  dojoType='dijit.form.RadioButton' type='radio' value='" + rowindex + "' checked ='checked' />"
  			// "<a href=\"#\" onclick=\"descargaRVIPortal.descargarZip('" + rowindex +  "')\"> <img src=\"/a/imagenes/see/icons/download_16p.gif\" /></a>"
  		}
  		else{
  			return "<input id='puntoPartida.selDomicilioGrid" + rowindex + "' name='puntoPartida.selDomicilioGrid'  dojoType='dijit.form.RadioButton' type='radio' value='" + rowindex + "' />"
  			// "<a href=\"#\" onclick=\"descargaRVIPortal.descargarZip('" + rowindex +  "')\"> <img src=\"/a/imagenes/see/icons/download_16p.gif\" /></a>"
  		}
 	},

	clearddlb: function (q,m){
		if ( q != null ) {
		    //longitud = q.length
		    //for (var x=0;x<=longitud;x++){
		    //  q.options[0]=null
		    //}
			//eval("dijit.byId('" + q + "').set(value,'')")
			eval("dijit.byId('" + q + "').set('displayedValue','')")
			var lista= eval("dijit.byId('" + q + "')");
			lista.store =  null;
		}
	},

	O : function(desc, val){
	  this.desc = desc;
	  this.val = val;
	},
	/*
	validaubigeo: function (ubigeo) {
		for (j=0;j<k.length;j++){
			if ( ubigeo == this.k[j].val )
			{return true}
		}
		return false
	},*/

	noSort: function(index){
		 return false;
	},
	//PAS20211U210600248-Ini-LAQ
	isQuitarCharacterSpecial: function() {

		dojo.require("dojox.string.sprintf");
		var descripcion = dojo.trim(dijit.byId("item.descripcion").getValue());
		var textofinal = "";
		var carac = "";
		if(descripcion.length >= 1) {

		var parts = descripcion.split("");
		    for(i=0; i < parts.length; i++) {
				carac= descripcion[i].split("");
				carac = carac.toString().toUpperCase();
				var arrch = ["☺","☻", "♥", "♦", "♣", "♠", "•", "◘","○","◙","♂","♀","♪","♫","☼","►","◄","↕","‼","¶","§","▬","↨","↑","↓","→","←","∟","↔","▲","▼","ֲ","","–"]
				var flag = 0
				for (var j = 0; j < arrch.length; j++) {
					var caray = arrch[j];
					if (carac == caray ){
						flag = 1
					}
				}
				if (flag==1){
					textofinal = textofinal + "";
				}
				else{
					textofinal = textofinal + carac;
				}
			}
			dijit.byId("item.descripcion").setValue(textofinal);
		}
	}
	//PAS20211U210600248-Fin-LAQ

});
}
