	function mostrarMensaje(msj, tipo = 1 )  {

			if ( dijit.byId('dlgMensaje') != undefined ) {
					require(["dojo/dom-construct"], function(domConstruct){
					  dijit.byId('dlgBtnAceptar').destroy();
					  dijit.byId('dlgMensaje').destroy();
					});
			}

			var aceptarDialog = new dijit.Dialog({ id: 'dlgMensaje', title: "Mensaje" });
			var respCallback = function(mouseEvent) {
					aceptarDialog.hide();
			};

			dojo.connect(aceptarDialog,"onCancel",function(){
					aceptarDialog.hide();
			});

			switch (tipo) {
					case 0: // OK
							questionDiv = dojo.create("div", {innerHTML:"<table><tr style='height:70px'><td><img src='/a/imagenes/pase_embarque.gif' border='0' alt=''></td><td style='padding-left: 5px;'>" + msj + "</td></tr></table>"});
							break;
					case 1: // INFO
							questionDiv = dojo.create("div", {innerHTML:"<table><tr style='height:70px'><td><img src='/a/imagenes/sigad/acciones/advertencia.gif' border='0' alt=''></td><td style='padding-left: 5px;'>" + msj + "</td></tr></table>"});
							break;
					case 2: // WARNING
							questionDiv = dojo.create("div", {innerHTML:"<table><tr style='height:70px'><td><img src='/a/imagenes/sigad/acciones/advertencia.gif' border='0' alt=''></td><td style='padding-left: 5px;'>" + msj + "</td></tr></table>"});
							break;
					case 3: // ERROR
							questionDiv = dojo.create("div", {innerHTML:"<table><tr style='height:70px'><td><img src='/a/imagenes/pase_no_embarque.gif' border='0' alt=''></td><td style='padding-left: 5px;'>" + msj + "</td></tr></table>"});
							break;
			}

			var aceptarButton = new dijit.form.Button( { label: 'Aceptar', id: 'dlgBtnAceptar', onClick: respCallback });
			var centroDiv = dojo.create('div', { style: { margin: "auto", textAlign: "center"} } );

			aceptarDialog.containerNode.appendChild(questionDiv);
			aceptarDialog.containerNode.appendChild(centroDiv);
			centroDiv.appendChild(aceptarButton.domNode);
			aceptarDialog.show();
	}

	//csanchezpe: se acrega accion cancelar para el caso de los else
	function mostrarMensajeConfirmacion ( msj, accionBtnAceptar, accionBtnCancelar = function() {} )  {

			if ( dijit.byId('dlgMensajeConfirmacion') != undefined ) {
					require(["dojo/dom-construct"], function(domConstruct){
					  dijit.byId('dlgBtnAceptarConfirm').destroy();
					  dijit.byId('dlgBtnCancelarConfirm').destroy();
					  dijit.byId('dlgMensajeConfirmacion').destroy();
					});
			}

			var dlgConfirmacion = new dijit.Dialog({ id: 'dlgMensajeConfirmacion', title: "Confirmar" });

			var respCallAceptar = function() {
				accionBtnAceptar();
				dlgConfirmacion.hide();
			};

			var respCallCancelar = function() {
				accionBtnCancelar();
				dlgConfirmacion.hide();
			};

			dojo.connect(dlgConfirmacion, "onCancel", function() {
				dlgConfirmacion.hide();
			});

			questionDiv = dojo.create("div", {innerHTML:"<table><tr style='height:70px'><td><img src='/a/imagenes/icons/questionMark32px.png' border='0' alt=''></td><td style='padding-left: 5px;'>" + msj + "</td></tr></table>"});

			var aceptarButton = new dijit.form.Button( { label: 'Aceptar', id: 'dlgBtnAceptarConfirm', onClick: respCallAceptar });
			var cancelarButton = new dijit.form.Button( { label: 'Cancelar', id: 'dlgBtnCancelarConfirm', onClick: respCallCancelar });

			var centroDiv = dojo.create('div', { style: { margin: "auto", textAlign: "center"} } );

			dlgConfirmacion.containerNode.appendChild(questionDiv);
			dlgConfirmacion.containerNode.appendChild(centroDiv);
			centroDiv.appendChild(aceptarButton.domNode);
			centroDiv.appendChild(cancelarButton.domNode);
			dlgConfirmacion.show();
	}
	
/**
 * NotaCreditoFE.js - JavaScript de la Emision de Notas de Cr\u00E9dito de Factura Electr\u00F3nica.
 * Author: Patricia Chacaliaza
 * Fecha: 15-11-2010
 * ResponseBean : codeError; messageError; data;
 */
/**
* Inicio : Codigo JS para el RUM de www.site24x7.com
*/
var rumMOKey='75e70a4e2c5429857d155a236316e78b';
(function(){
if(window.performance && window.performance.timing && window.performance.navigation) {
        var site24x7_rum_beacon=document.createElement('script');
        site24x7_rum_beacon.async=true;
        site24x7_rum_beacon.setAttribute('src','//static.site24x7rum.com/beacon/site24x7rum-min.js?appKey='+rumMOKey);
        document.getElementsByTagName('head')[0].appendChild(site24x7_rum_beacon);
}
})(window)

/**
* Fin : Codigo JS para el RUM de www.site24x7.com
*/ 
 
 
if (!dojo._hasResource["servicio.registro.comppago.see.NotaCreditoFE"]) {
    dojo._hasResource["servicio.registro.comppago.see.NotaCreditoFE"] = true;
    dojo.provide("servicio.registro.comppago.see.NotaCreditoFE");
    
    dojo.require("dojo.data.ItemFileWriteStore");
	dojo.require("dojo.data.ItemFileReadStore");
    dojo.require("dojo.io.iframe");
    
    dojo.declare("servicio.registro.comppago.see.NotaCreditoFE", null, {
       store: null,   
    	 facturaBean: null,
        igvFE:null,   
		//PAS20201U210100230 -oINICIO
			//variables utilizadas para calculos
			indRegitroInfCredito: 0,
			storeInfCredito: null,
			storeInfCuota: null,
			listaElementosInfCredito:[],
			montoTotalCuotas:0,
			//variables que se guardan para compararse.
			montoNetoPendienteGuardado:null,
			storeInfCreditoGuardado: [],
			montoTotalCuotasGuardado:null,
			montoNetoRetencion: null,
			montoBaseRetencion: null,
		//PAS20201U210100230 -oFIN     
        controller: "emitirNCFE.do",
        
        constructor: function(){ },
        
        initialize: function(){
    		this.content = dijit.byId("content");    		
            this.waitMessage = dijit.byId("waitMessage");
            this.dialogItem25 =  dijit.byId("dialogItem25");
            this.dialogItem26 =  dijit.byId("dialogItem26");
            this.dialogItem27 =  dijit.byId("dialogItem27");
			this.dialogItem28 =  dijit.byId("dialogItem28");
			this.dialogItem29 =  dijit.byId("dialogItem29");
        },
        
        startup: function(){
            dojo.parser.parse(dojo.byId('container'));
            setTimeout(dojo.hitch(this, function(){
                this.hideLoader();
            }), 250);
        },
        
        hideLoader: function(){
            this.initialize();
            var loader = dojo.byId('loader');
            var _this = this;
            dojo.fadeOut({
                node: loader,
                duration: 250,
                onEnd: function(){
                	dijit.byId('content').domNode.style.visibility = "visible";            	
                    loader.style.display = "none";
                }
            }).play();
        },
         
        initContent: function(){
            /*Nada al cargar el formulario*/
        	this.store = null;
        	//this.facturaBean = null;
        	dijit.hideTooltip(dojo.byId("numeroComprobante"));
        	dijit.focus(dojo.byId("pantallaInicial.tipoNotaCredito"));
        },  	
    	
         
      	preventCache: function() {
      		return new Date().valueOf();
      	} ,
       
	showOpcionesPorTipoNCFE: function() {
		valor = dijit.byId("pantallaInicial.tipoNotaCredito").value;
		
        if (valor == "21" || valor == "" ) {
			this.showHiddenDiv(document.getElementById("inicio.motivo.show"),true);
        	this.showHiddenDiv(document.getElementById("inicio.numeronuevaFE.show"),false);
        	this.showHiddenDiv(document.getElementById("inicio.descuentosFE.show"),false);
        	if (valor == "" ) {
				this.showHiddenDiv(document.getElementById("inicio.leyendaNota21"),false);
        		this.showHiddenDiv(document.getElementById("inicio.leyendaNota22"),false);
        		this.showHiddenDiv(document.getElementById("inicio.leyendaNota23"),false);
        		this.showHiddenDiv(document.getElementById("inicio.leyendaNota24"),false);
				this.showHiddenDiv(document.getElementById("inicio.leyendaNota28"),false);
				this.showHiddenDiv(document.getElementById("inicio.leyendaNota29"),false);
        	}
        	if (valor == "21" ) {
				this.showHiddenDiv(document.getElementById("inicio.leyendaNota21"),true);
        		this.showHiddenDiv(document.getElementById("inicio.leyendaNota22"),false);
        		this.showHiddenDiv(document.getElementById("inicio.leyendaNota23"),false);
        		this.showHiddenDiv(document.getElementById("inicio.leyendaNota24"),false);
				this.showHiddenDiv(document.getElementById("inicio.leyendaNota28"),false);
				this.showHiddenDiv(document.getElementById("inicio.leyendaNota29"),false);
        	}
        }
        
		if (valor == "22") {
			this.showHiddenDiv(document.getElementById("inicio.motivo.show"),false);
        	this.showHiddenDiv(document.getElementById("inicio.numeronuevaFE.show"),true);
        	this.showHiddenDiv(document.getElementById("inicio.descuentosFE.show"),false);
        	this.showHiddenDiv(document.getElementById("inicio.leyendaNota21"),false);
        	this.showHiddenDiv(document.getElementById("inicio.leyendaNota22"),true);
        	this.showHiddenDiv(document.getElementById("inicio.leyendaNota23"),false);
        	this.showHiddenDiv(document.getElementById("inicio.leyendaNota24"),false);
			this.showHiddenDiv(document.getElementById("inicio.leyendaNota28"),false);
			this.showHiddenDiv(document.getElementById("inicio.leyendaNota29"),false);
        }
        
		if (valor == "23") {
			this.showHiddenDiv(document.getElementById("inicio.motivo.show"),true);
        	this.showHiddenDiv(document.getElementById("inicio.numeronuevaFE.show"),false);
        	this.showHiddenDiv(document.getElementById("inicio.descuentosFE.show"),true);
        	this.showHiddenDiv(document.getElementById("inicio.leyendaNota21"),false);
        	this.showHiddenDiv(document.getElementById("inicio.leyendaNota22"),false);
        	this.showHiddenDiv(document.getElementById("inicio.leyendaNota23"),true);
        	this.showHiddenDiv(document.getElementById("inicio.leyendaNota24"),false);
			this.showHiddenDiv(document.getElementById("inicio.leyendaNota28"),false);
			this.showHiddenDiv(document.getElementById("inicio.leyendaNota29"),false);
        }	
        
		if (valor == "24") {
			this.showHiddenDiv(document.getElementById("inicio.motivo.show"),true);
        	this.showHiddenDiv(document.getElementById("inicio.numeronuevaFE.show"),false);
        	this.showHiddenDiv(document.getElementById("inicio.descuentosFE.show"),false);
        	this.showHiddenDiv(document.getElementById("inicio.leyendaNota21"),false);
        	this.showHiddenDiv(document.getElementById("inicio.leyendaNota22"),false);
        	this.showHiddenDiv(document.getElementById("inicio.leyendaNota23"),false);
        	this.showHiddenDiv(document.getElementById("inicio.leyendaNota24"),true);
			this.showHiddenDiv(document.getElementById("inicio.leyendaNota28"),false);
			this.showHiddenDiv(document.getElementById("inicio.leyendaNota29"),false);
        }	
		
        if (valor == "25" || valor == "26" || valor == "27" ) {
			this.showHiddenDiv(document.getElementById("inicio.motivo.show"),true);
        	this.showHiddenDiv(document.getElementById("inicio.numeronuevaFE.show"),false);
        	this.showHiddenDiv(document.getElementById("inicio.descuentosFE.show"),false);
        	this.showHiddenDiv(document.getElementById("inicio.leyendaNota21"),false);
        	this.showHiddenDiv(document.getElementById("inicio.leyendaNota22"),false);
        	this.showHiddenDiv(document.getElementById("inicio.leyendaNota23"),false);
        	this.showHiddenDiv(document.getElementById("inicio.leyendaNota24"),false);
			this.showHiddenDiv(document.getElementById("inicio.leyendaNota28"),false);  			
			this.showHiddenDiv(document.getElementById("inicio.leyendaNota29"),false); 			
        }
		
        if (valor == "28") {
			this.showHiddenDiv(document.getElementById("inicio.motivo.show"),true);
        	this.showHiddenDiv(document.getElementById("inicio.numeronuevaFE.show"),false);
        	this.showHiddenDiv(document.getElementById("inicio.descuentosFE.show"),false);
			this.showHiddenDiv(document.getElementById("inicio.leyendaNota21"),false);
        	this.showHiddenDiv(document.getElementById("inicio.leyendaNota22"),false);
        	this.showHiddenDiv(document.getElementById("inicio.leyendaNota23"),false);
        	this.showHiddenDiv(document.getElementById("inicio.leyendaNota24"),false);   
			this.showHiddenDiv(document.getElementById("inicio.leyendaNota28"),true);  			
			this.showHiddenDiv(document.getElementById("inicio.leyendaNota29"),false);  			
        }
         if (valor == "29") {
			this.showHiddenDiv(document.getElementById("inicio.motivo.show"),true);
        	this.showHiddenDiv(document.getElementById("inicio.numeronuevaFE.show"),false);
        	this.showHiddenDiv(document.getElementById("inicio.descuentosFE.show"),false);
			this.showHiddenDiv(document.getElementById("inicio.leyendaNota21"),false);
        	this.showHiddenDiv(document.getElementById("inicio.leyendaNota22"),false);
        	this.showHiddenDiv(document.getElementById("inicio.leyendaNota23"),false);
        	this.showHiddenDiv(document.getElementById("inicio.leyendaNota24"),false);   
			this.showHiddenDiv(document.getElementById("inicio.leyendaNota28"),false);  			
			this.showHiddenDiv(document.getElementById("inicio.leyendaNota29"),true);       		  
        }
 	
		//INICIO: PAS20201U210100188 
		if (valor != "23" ) {
			this.limpiaMontos();
		}		
		//FIN: PAS20201U210100188 
		dijit.hideTooltip(dojo.byId("pantallaInicial.numeroFE"));
		dijit.hideTooltip(dojo.byId("pantallaInicial.numeroNuevaFE"));
		
		if (valor == ""){
			dijit.byId("pantallaInicial.tipoNotaCredito").focus();
		} else {
			dijit.byId("pantallaInicial.numeroFE").focus();
		}
	},
	
	showOpcionesPorTipoNCFEContin: function() {
		valor = dijit.byId("pantallaInicial.tipoNotaCredito").value;
		
        if (valor == "21" || valor == "" ) {
			this.showHiddenDiv(document.getElementById("inicio.motivo.show"),true);
        	this.showHiddenDiv(document.getElementById("inicio.numeronuevaFE.show"),false);
        	this.showHiddenDiv(document.getElementById("inicio.descuentosFE.show"),false);
        	if (valor == "" ) {
				this.showHiddenDiv(document.getElementById("inicio.leyendaNota21"),false);
        		this.showHiddenDiv(document.getElementById("inicio.leyendaNota22"),false);
        		this.showHiddenDiv(document.getElementById("inicio.leyendaNota23"),false);
        		this.showHiddenDiv(document.getElementById("inicio.leyendaNota24"),false);
        	}
        	if (valor == "21" ) {
				this.showHiddenDiv(document.getElementById("inicio.leyendaNota21"),true);
        		this.showHiddenDiv(document.getElementById("inicio.leyendaNota22"),false);
        		this.showHiddenDiv(document.getElementById("inicio.leyendaNota23"),false);
        		this.showHiddenDiv(document.getElementById("inicio.leyendaNota24"),false);       		  
        	}
        }
        
		if (valor == "22") {
			this.showHiddenDiv(document.getElementById("inicio.motivo.show"),false);
        	this.showHiddenDiv(document.getElementById("inicio.numeronuevaFE.show"),true);
        	this.showHiddenDiv(document.getElementById("inicio.descuentosFE.show"),false);
        	this.showHiddenDiv(document.getElementById("inicio.leyendaNota21"),false);
        	this.showHiddenDiv(document.getElementById("inicio.leyendaNota22"),true);
        	this.showHiddenDiv(document.getElementById("inicio.leyendaNota23"),false);
        	this.showHiddenDiv(document.getElementById("inicio.leyendaNota24"),false);
        }
        
		if (valor == "23") {
			this.showHiddenDiv(document.getElementById("inicio.motivo.show"),true);
        	this.showHiddenDiv(document.getElementById("inicio.numeronuevaFE.show"),false);
        	this.showHiddenDiv(document.getElementById("inicio.descuentosFE.show"),true);
        	this.showHiddenDiv(document.getElementById("inicio.leyendaNota21"),false);
        	this.showHiddenDiv(document.getElementById("inicio.leyendaNota22"),false);
        	this.showHiddenDiv(document.getElementById("inicio.leyendaNota23"),true);
        	this.showHiddenDiv(document.getElementById("inicio.leyendaNota24"),false);			
        }	
        
		if (valor == "24") {
			this.showHiddenDiv(document.getElementById("inicio.motivo.show"),true);
        	this.showHiddenDiv(document.getElementById("inicio.numeronuevaFE.show"),false);
        	this.showHiddenDiv(document.getElementById("inicio.descuentosFE.show"),false);
        	this.showHiddenDiv(document.getElementById("inicio.leyendaNota21"),false);
        	this.showHiddenDiv(document.getElementById("inicio.leyendaNota22"),false);
        	this.showHiddenDiv(document.getElementById("inicio.leyendaNota23"),false);
        	this.showHiddenDiv(document.getElementById("inicio.leyendaNota24"),true);
        }	
		
        if (valor == "25" || valor == "26" || valor == "27" ) {
			this.showHiddenDiv(document.getElementById("inicio.motivo.show"),true);
        	this.showHiddenDiv(document.getElementById("inicio.numeronuevaFE.show"),false);
        	this.showHiddenDiv(document.getElementById("inicio.descuentosFE.show"),false);
        	this.showHiddenDiv(document.getElementById("inicio.leyendaNota21"),false);
        	this.showHiddenDiv(document.getElementById("inicio.leyendaNota22"),false);
        	this.showHiddenDiv(document.getElementById("inicio.leyendaNota23"),false);
        	this.showHiddenDiv(document.getElementById("inicio.leyendaNota24"),false);
        }
        
		dijit.hideTooltip(dojo.byId("pantallaInicial.numeroFE"));
		dijit.hideTooltip(dojo.byId("pantallaInicial.numeroNuevaFE"));
		
		if (valor == ""){
			dijit.byId("pantallaInicial.tipoNotaCredito").focus();
		} else {
			//dijit.byId("pantallaInicial.numeroFE").focus();
			document.getElementById("serie").focus();
		}
	},
       
         verFacturaNC: function() {
           
           var numFactura = dijit.byId("pantallaInicial.numeroFE").value;
           if (numFactura == ""){
              mostrarMensaje("Debe registrar el n\xFAmero de la Factura Electr\xf3nica.");
              return;
           }

           var handler = dojo.xhrGet({
                    url: this.controller + "?action=obtenerXml&factura=" +numFactura,
                    handleAs: "json",
                    sync: true,
                    timeout: 10000
           });        
           handler.addCallback(dojo.hitch(this, function(res){
    		   if (res.codeError == 0) {
                 var xml=dijit.byId("facturaxml");
                 var dFactura = dijit.byId("dialogFactura");
    		         if(dFactura) {      
                 			dFactura.show();
                      xml.attr("href","FacturaGenerada.jsp");
    		         }                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                               
    			 } else {   
                         
    				  mostrarMensaje(res.messageError);
    				  return;
    			 }
    		}));
    		handler.addErrback(function(res){
    			this.waitMessage.hide();
    			mostrarMensaje("Problemas al conectarse con el servidor");
    		});
           
         },
		 
		 
		 verFacturaNCContin: function() {
			var idSerie = document.getElementById("idSerie").value;
           var numFactura = dijit.byId("pantallaInicial.numeroFE").value;
		   if (idSerie == ""){
              mostrarMensaje("Debe registrar el n\xFAmero de la Factura.");
              return;
           }
           if (numFactura == ""){
              mostrarMensaje("Debe registrar el n\xFAmero de la Factura.");
              return;
           }
           var handler = dojo.xhrGet({
                    url: this.controller + "?action=obtenerXmlContin&factura=" +numFactura+"&idSerie="+idSerie,
                    handleAs: "json",
                    sync: true,
                    timeout: 10000
           });        
           handler.addCallback(dojo.hitch(this, function(res){
    		   if (res.codeError == 0) {
                 var xml=dijit.byId("facturaxml");
                 var dFactura = dijit.byId("dialogFactura");
    		         if(dFactura) {      
                 			dFactura.show();
                      xml.attr("href","FacturaGenerada.jsp");
    		         }                                                                          
    			 } else {   
    				  mostrarMensaje(res.messageError);
    				  return;
    			 }
    		}));
    		handler.addErrback(function(res){
    			this.waitMessage.hide();
    			mostrarMensaje("Problemas al conectarse con el servidor");
    		});
         },
		 

         verFacturaNew: function() {
           var numFactura = dijit.byId("pantallaInicial.numeroNuevaFE").getValue();
           if (numFactura == ""){
              mostrarMensaje("Debe registrar el n\xFAmero de la Nueva Factura Electr\xf3nica.");
              return;
           }

           var handler = dojo.xhrGet({
                    url: this.controller + "?action=obtenerXml&factura=" +numFactura,
                    handleAs: "json",
                    sync: true,
                    timeout: 10000
           });        
           handler.addCallback(dojo.hitch(this, function(res){
    		   if (res.codeError == 0) {
                 var xml=dijit.byId("facturaxml");
                 var dFactura = dijit.byId("dialogFactura");
    		         if(dFactura) {      
                 			dFactura.show();
                      xml.attr("href","FacturaGenerada.jsp");
    		         }                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                
    			 } else {                                 
    				  mostrarMensaje(res.messageError);
    				  return;
    			 }
    		}));
    		handler.addErrback(function(res){
    			this.waitMessage.hide();
    			mostrarMensaje("Problemas al conectarse con el servidor");
    		});
         },
          
		  
		  verFacturaNewContin: function() {
			var idSerieNew = document.getElementById("idSerieNew").value;	  
           var factura2 = dijit.byId("pantallaInicial.numeroNuevaFE").getValue();
		   if (idSerieNew == ""){
              mostrarMensaje("Debe registrar la serie de la Nueva Factura.");
              return;
           }
           if (factura2 == ""){
              mostrarMensaje("Debe registrar el n\xFAmero de la Nueva Factura.");
              return;
           }

           var handler = dojo.xhrGet({
                    url: this.controller + "?action=obtenerXmlContin&factura=" +factura2+"&idSerie="+idSerieNew,
                    handleAs: "json",
                    sync: true,
                    timeout: 10000
           });        
           handler.addCallback(dojo.hitch(this, function(res){
    		   if (res.codeError == 0) {
                 var xml=dijit.byId("facturaxml");
                 var dFactura = dijit.byId("dialogFactura");
    		         if(dFactura) {      
                 			dFactura.show();
                      xml.attr("href","FacturaGenerada.jsp");
    		         }                                                                                               
    			 } else {                                 
    				  mostrarMensaje(res.messageError);
    				  return;
    			 }
    		}));
    		handler.addErrback(function(res){
    			this.waitMessage.hide();
    			mostrarMensaje("Problemas al conectarse con el servidor");
    		});
         },
		 
          
	verPreliminar: function() {
		// INI PAS20211U210100040  AHUISA
    if (!this.validarFechaEmision(false)){
      return;
    }
    // FIN PAS20211U210100040  AHUISA
		if(!dijit.byId("criterio.form").validate()) return;
		valor = dojo.byId("pantallaInicial.tipoNotaCredito").value;
        if (valor == ""){
			mostrarMensaje("Debe seleccionar el tipo de Nota de Cr\xE9dito a emitir.");
			return;
        }
        
		if (dojo.byId("pantallaInicial.numeroFE").value == ""){
			mostrarMensaje("Debe ingresar el n\xFAmero de Factura Electr\xf3nica respecto a la cual se emitir\xE1 la Nota de Cr\xE9dito.");
			return;                
        } 
        
		valor = dijit.byId("pantallaInicial.tipoNotaCredito").getValue();
		if (valor == "21" || valor == "25" || valor == "26" || valor == "27" || valor == "28" || valor == "29") {
			if (dojo.byId("pantallaInicial.motivoEmisionNC").value == ""){
				mostrarMensaje("Debe ingresar el motivo o sustento por el cu\u00E1l se emitir\xE1 la Nota de Cr\xE9dito.");
				return;                
			} 
        }
		
        /*if (valor == "22") {
			if (dijit.byId("pantallaInicial.numeroNuevaFE").value == ""){
				mostrarMensaje("Debe ingresar el n\xFAmero de la nueva Factura Electr\xf3nica.");
				return;                
			}
        }*/
		
        valor = dijit.byId("pantallaInicial.tipoNotaCredito").getValue();
        if (this.facturaBean!=null && valor == "23") {
			if (dojo.byId("pantallaInicial.motivoEmisionNC").value == ""){
				mostrarMensaje("Debe ingresar el motivo o sustento por el cu\u00E1l se emitir\xE1 la Nota de Cr\xE9dito.");
				return;                
			}
			if (dojo.byId("pantallaInicial.descuentoGlobalNC").value == "" ){
				mostrarMensaje("Debe consignarse el descuento global.");
				return;                
			}
			if (dijit.byId("pantallaInicial.descuentoGlobalNC").getValue()  == 0){
				mostrarMensaje("Descuento Global debe ser mayor que cero.");
				return;                
			}
			
			var totalValorVenta = this.facturaBean.montoTotalGeneral;				
			var desc = dijit.byId("pantallaInicial.descuentoGlobalNC").getValue();
			var isc = 0;
			var igv = 0;
			if (dijit.byId("pantallaInicial.descuentoGlobalNC").getValue() >= totalValorVenta){
				mostrarMensaje("Descuento Global debe ser menor que el Valor de Venta de la FE respecto de la cual se emitir\u00E1 la NC.");
				return;                
			} 
             
			if (dijit.byId("pantallaInicial.descuentoGlobalNC").getValue() == 0){
				mostrarMensaje("Descuento Global debe ser mayor que cero");
               	return;                
			}
                 
			//Validamos ISC
			if (dijit.byId("pantallaInicial.ISCNC").disabled == false){
				if (dojo.byId("pantallaInicial.ISCNC").value == "" ){
					mostrarMensaje("Debe consignarse el ISC.");
					return;                
				}
				if (dijit.byId("pantallaInicial.ISCNC").getValue() == 0){
					mostrarMensaje("ISC debe ser mayor que cero");
					return;                
				}                  
				if (dijit.byId("pantallaInicial.ISCNC").getValue() >= totalValorVenta){
					mostrarMensaje("ISC debe ser menor que el Valor de Venta de la FE respecto de la cual se emitir\u00E1 la NC");
					return;                
				}
				if (dijit.byId("pantallaInicial.ISCNC").getValue() >= dijit.byId("pantallaInicial.descuentoGlobalNC").getValue()){
					mostrarMensaje("ISC debe ser menor que el monto de Descuento Global Registrado");
					return;                
				}	
				var totalISC = this.facturaBean.totalISC;
				if (dijit.byId("pantallaInicial.ISCNC").getValue() >= totalISC){
					mostrarMensaje("ISC registrado debe ser menor al ISC de la FE respecto de la cual se emitir\u00E1 la NC");
					return;                
				}
				
				isc = dijit.byId("pantallaInicial.ISCNC").getValue() ;
			}
				
			igv = dijit.byId("pantallaInicial.IGVNC").getValue() ;
			if ((desc + igv + isc ) >= totalValorVenta){
				mostrarMensaje("La suma del Descuento Global + IGV + ISC debe ser menor que el Valor de Venta de la FE respecto de la cual se emitir\u00E1 la NC.");
				return;                
			}
        }	
        		
        valor = dijit.byId("pantallaInicial.tipoNotaCredito").getValue();
        if (valor == "24") {
			if (dojo.byId("pantallaInicial.motivoEmisionNC").value == ""){
				mostrarMensaje("Debe ingresar el motivo o sustento por el cu\u00E1l se emitir\xE1 la Nota de Cr\xE9dito.");
				return;                
			}
		}
		console.log("IGV==> " ,dijit.byId("pantallaInicial.IGVNC").value );//PAS20211U210100007-jmendozas


      	var handler = dojo.xhrGet({
			url: this.controller + "?action=validarComprobante&TipoNotaCred=" + dijit.byId("pantallaInicial.tipoNotaCredito").value + "&factura=" + dojo.byId("pantallaInicial.numeroFE").value + "&facturanew=" + dojo.byId("pantallaInicial.numeroNuevaFE").value
      // INI PAS20211U210100040  AHUISA
      + "&fecEmision=" + dojo.byId("pantallaInicial.fechaEmision").value
      // FIN PAS20211U210100040  AHUISA
      ,
				handleAs: "json",
				sync: true,
				preventCache: true,
				timeout: 10000
		});
		
		handler.addCallback(dojo.hitch(this, function(res){
			if (res.codeError == 0) {

				//PAS20201U210100230 INI -opv
				if (valor == "28") {	
					this.content.setHref(this.controller + "?action=cambiarDetallesFactoringNC&TipoNotaCred=" + dijit.byId("pantallaInicial.tipoNotaCredito").value + "&factura=" + dijit.byId("pantallaInicial.numeroFE").value + "&motivo=" + dijit.byId("pantallaInicial.motivoEmisionNC").value+ "&facturanew=" + dijit.byId("pantallaInicial.numeroNuevaFE").value+ "&descuento=" + dijit.byId("pantallaInicial.descuentoGlobalNC").value+ "&isc=" + dijit.byId("pantallaInicial.ISCNC").value+ "&igv=" + dijit.byId("pantallaInicial.IGVNC").value+ "&fecEmision=" + dojo.byId("pantallaInicial.fechaEmision").value);
				}	
				if (valor == "29"){	
					console.log("ingreso a cambiarDetallesFactoringNC 29");					
					this.facturaBean = eval("(" + res.data + ")");//whr  
					this.fechaEmisionOriginal = this.facturaBean.fechaEmisionOriginal;
					var dia = this.fechaEmisionOriginal.substring(0,2);
					var mes = this.fechaEmisionOriginal.substring(3,5);
					var anio = this.fechaEmisionOriginal.substring(6,10);
					console.log("fechaEmisionOriginal--> " + this.fechaEmisionOriginal);
					this.content.setHref(this.controller + "?action=cambiarDetallesFactoringNC&TipoNotaCred=" + dijit.byId("pantallaInicial.tipoNotaCredito").value + "&factura=" + dijit.byId("pantallaInicial.numeroFE").value + "&motivo=" + dijit.byId("pantallaInicial.motivoEmisionNC").value+ "&facturanew=" + dijit.byId("pantallaInicial.numeroNuevaFE").value+ "&descuento=" + dijit.byId("pantallaInicial.descuentoGlobalNC").value+ "&isc=" + dijit.byId("pantallaInicial.ISCNC").value+ "&igv=" + dijit.byId("pantallaInicial.IGVNC").value+ "&fecEmision=" + dojo.byId("pantallaInicial.fechaEmision").value + "&fechaEmisionOriginal=" +dia+mes+anio);//Jrgs					
					this.content.onLoad = dojo.hitch(this, function(){
						this.cargarDatosdeTabla29();
					});					
				}				
	    		//PAS20201U210100230 FIN -opv

				if (valor == "25" || valor == "26" ||valor == "27") {
          // INI PAS20211U210100040  AHUISA
          //this.content.setHref(this.controller + "?action=cambiarDetallesNC&TipoNotaCred=" + dijit.byId("pantallaInicial.tipoNotaCredito").value + "&factura=" + dijit.byId("pantallaInicial.numeroFE").value + "&motivo=" + dijit.byId("pantallaInicial.motivoEmisionNC").value+ "&facturanew=" + dijit.byId("pantallaInicial.numeroNuevaFE").value+ "&descuento=" + dijit.byId("pantallaInicial.descuentoGlobalNC").value+ "&isc=" + dijit.byId("pantallaInicial.ISCNC").value+ "&igv=" + dijit.byId("pantallaInicial.IGVNC").value);
          this.content.setHref(this.controller + "?action=cambiarDetallesNC&TipoNotaCred=" + dijit.byId("pantallaInicial.tipoNotaCredito").value + "&factura=" + dijit.byId("pantallaInicial.numeroFE").value + "&motivo=" + dijit.byId("pantallaInicial.motivoEmisionNC").value+ "&facturanew=" + dijit.byId("pantallaInicial.numeroNuevaFE").value+ "&descuento=" + dijit.byId("pantallaInicial.descuentoGlobalNC").value+ "&isc=" + dijit.byId("pantallaInicial.ISCNC").value+ "&igv=" + dijit.byId("pantallaInicial.IGVNC").value  + "&fecEmision=" + dojo.byId("pantallaInicial.fechaEmision").value);
          // FIN PAS20211U210100040  AHUISA
        }
				if (valor == "21" || valor == "22" ||valor == "23" ||valor == "24" ) {
					// INI PAS20211U210100040  AHUISA
          //this.content.setHref(this.controller + "?action=preliminarComprobante&TipoNotaCred=" + dijit.byId("pantallaInicial.tipoNotaCredito").value + "&factura=" + dijit.byId("pantallaInicial.numeroFE").value + "&motivo=" + dijit.byId("pantallaInicial.motivoEmisionNC").value+ "&facturanew=" + dijit.byId("pantallaInicial.numeroNuevaFE").value+ "&descuento=" + dijit.byId("pantallaInicial.descuentoGlobalNC").value+ "&isc=" + dijit.byId("pantallaInicial.ISCNC").value+ "&igv=" + dijit.byId("pantallaInicial.IGVNC").value);
          this.content.setHref(this.controller + "?action=preliminarComprobante&TipoNotaCred=" + dijit.byId("pantallaInicial.tipoNotaCredito").value + "&factura=" + dijit.byId("pantallaInicial.numeroFE").value + "&motivo=" + dijit.byId("pantallaInicial.motivoEmisionNC").value+ "&facturanew=" + dijit.byId("pantallaInicial.numeroNuevaFE").value+ "&descuento=" + dijit.byId("pantallaInicial.descuentoGlobalNC").value+ "&isc=" + dijit.byId("pantallaInicial.ISCNC").value+ "&igv=" + dijit.byId("pantallaInicial.IGVNC").value + "&fecEmision=" + dojo.byId("pantallaInicial.fechaEmision").value);
				  // FIN PAS20211U210100040  AHUISA
        }    		   
			} else {				
				if (res.codeError == 9) {
					//////if (!confirm(res.messageError + " \u00BFDesea continuar?. Puede revisar las notas de credito emitidas en la opci\u00F3n de consultas.")){
						//////return;
					mostrarMensajeConfirmacion(res.messageError + " \u00BFDesea continuar?. Puede revisar las notas de cr\xE9dito emitidas en la opci\u00F3n de consultas.", 
						dojo.hitch(this, function(){
					
						//PAS20201U210100230 INI -opv
						if (valor == "28") {	
							this.content.setHref(this.controller + "?action=cambiarDetallesFactoringNC&TipoNotaCred=" + dijit.byId("pantallaInicial.tipoNotaCredito").value + "&factura=" + dijit.byId("pantallaInicial.numeroFE").value + "&motivo=" + dijit.byId("pantallaInicial.motivoEmisionNC").value+ "&facturanew=" + dijit.byId("pantallaInicial.numeroNuevaFE").value+ "&descuento=" + dijit.byId("pantallaInicial.descuentoGlobalNC").value+ "&isc=" + dijit.byId("pantallaInicial.ISCNC").value+ "&igv=" + dijit.byId("pantallaInicial.IGVNC").value+ "&fecEmision=" + dojo.byId("pantallaInicial.fechaEmision").value);
						}	
						if (valor == "29"){	
							this.facturaBean = eval("(" + res.data + ")");//whr  
							this.fechaEmisionOriginal = this.facturaBean.fechaEmisionOriginal;
							var dia = this.fechaEmisionOriginal.substring(0,2);
							var mes = this.fechaEmisionOriginal.substring(3,5);
							var anio = this.fechaEmisionOriginal.substring(6,10);
							console.log("fechaEmisionOriginal--> " + this.fechaEmisionOriginal);
							this.content.setHref(this.controller + "?action=cambiarDetallesFactoringNC&TipoNotaCred=" + dijit.byId("pantallaInicial.tipoNotaCredito").value + "&factura=" + dijit.byId("pantallaInicial.numeroFE").value + "&motivo=" + dijit.byId("pantallaInicial.motivoEmisionNC").value+ "&facturanew=" + dijit.byId("pantallaInicial.numeroNuevaFE").value+ "&descuento=" + dijit.byId("pantallaInicial.descuentoGlobalNC").value+ "&isc=" + dijit.byId("pantallaInicial.ISCNC").value+ "&igv=" + dijit.byId("pantallaInicial.IGVNC").value+ "&fecEmision=" + dojo.byId("pantallaInicial.fechaEmision").value + "&fechaEmisionOriginal=" +dia+mes+anio);					
							this.content.onLoad = dojo.hitch(this, function(){
								this.cargarDatosdeTabla29();
							});     
						}				
						//PAS20201U210100230 FIN -opv
						if (valor == "25" || valor == "26" ||valor == "27") {
						  // INI PAS20211U210100040  AHUISA
										//this.content.setHref(this.controller + "?action=cambiarDetallesNC&TipoNotaCred=" + dijit.byId("pantallaInicial.tipoNotaCredito").value + "&factura=" + dijit.byId("pantallaInicial.numeroFE").value + "&motivo=" + dijit.byId("pantallaInicial.motivoEmisionNC").value+ "&facturanew=" + dijit.byId("pantallaInicial.numeroNuevaFE").value+ "&descuento=" + dijit.byId("pantallaInicial.descuentoGlobalNC").value+ "&isc=" + dijit.byId("pantallaInicial.ISCNC").value+ "&igv=" + dijit.byId("pantallaInicial.IGVNC").value);
						  this.content.setHref(this.controller + "?action=cambiarDetallesNC&TipoNotaCred=" + dijit.byId("pantallaInicial.tipoNotaCredito").value + "&factura=" + dijit.byId("pantallaInicial.numeroFE").value + "&motivo=" + dijit.byId("pantallaInicial.motivoEmisionNC").value+ "&facturanew=" + dijit.byId("pantallaInicial.numeroNuevaFE").value+ "&descuento=" + dijit.byId("pantallaInicial.descuentoGlobalNC").value+ "&isc=" + dijit.byId("pantallaInicial.ISCNC").value+ "&igv=" + dijit.byId("pantallaInicial.IGVNC").value+ "&fecEmision=" + dojo.byId("pantallaInicial.fechaEmision").value);
						  // FIN PAS20211U210100040  AHUISA
						}
						if (valor == "21" || valor == "22" ||valor == "23" ||valor == "24" ) {
						  // INI PAS20211U210100040  AHUISA
										//this.content.setHref(this.controller + "?action=preliminarComprobante&TipoNotaCred=" + dijit.byId("pantallaInicial.tipoNotaCredito").value + "&factura=" + dijit.byId("pantallaInicial.numeroFE").value + "&motivo=" + dijit.byId("pantallaInicial.motivoEmisionNC").value+ "&facturanew=" + dijit.byId("pantallaInicial.numeroNuevaFE").value+ "&descuento=" + dijit.byId("pantallaInicial.descuentoGlobalNC").value+ "&isc=" + dijit.byId("pantallaInicial.ISCNC").value+ "&igv=" + dijit.byId("pantallaInicial.IGVNC").value);

										this.content.setHref(this.controller + "?action=preliminarComprobante&TipoNotaCred=" + dijit.byId("pantallaInicial.tipoNotaCredito").value + "&factura=" + dijit.byId("pantallaInicial.numeroFE").value + "&motivo=" + dijit.byId("pantallaInicial.motivoEmisionNC").value+ "&facturanew=" + dijit.byId("pantallaInicial.numeroNuevaFE").value+ "&descuento=" + dijit.byId("pantallaInicial.descuentoGlobalNC").value+ "&isc=" + dijit.byId("pantallaInicial.ISCNC").value+ "&igv=" + dijit.byId("pantallaInicial.IGVNC").value + "&fecEmision=" + dojo.byId("pantallaInicial.fechaEmision").value);
						  // INI PAS20211U210100040  AHUISA
						}
					//////}
					}))
					//);
				}else{                       
					mostrarMensaje(res.messageError);
					return;
				}
			}
		}));
		
    	handler.addErrback(function(res){
    		this.waitMessage.hide();
    		mostrarMensaje("Problemas al conectarse con el servidor");
		});    			 
	},

	//--------------------PAS20201U210100230 INI FORMULARIO TIPO 28-opv--------------------------------	
	//PAS20201U210100230
	iconEdit28: function(rowindex) {
		return "<a href=\"#\" title=\"Editar\" onclick=\"notaCreditoFE.editItem28(" + rowindex + ")\"><img class=\"icon-by-edit16\" src=\"/a/imagenes/see/icons/edit.gif\"/></a>"; 
	},
	//PAS20201U210100230
    closeInfRetencion: function() {
		this.dialogItem28 =  dijit.byId("dialogItem28");
		this.dialogItem28.hide();
	},	  
	 //PAS20201U210100230 
	editItem28: function(identificador) {		
		store =dijit.byId('ncCambioDetalles.ingreso-grid').store;        
		store.fetchItemByIdentity({
			identity: identificador,
			onItem : function(item, request) {
				row = item;		
				currentLine = identificador 	;		
			},
			onError : function(item, request) {
				mostrarMensaje("Ocurrio un error al ubicar el documento");
				return;				
			}
		});
		bCargando= true;
		//MONTOS ORIGINALES
		dojo.byId("item28.baseRetencionOriginal").value =store.getValue(row, "baseRetencionOriginal");	
		dojo.byId("item28.porcentajeRetencionOriginal").value =store.getValue(row, "porcentajeRetencionOriginal");	
		dijit.byId("item28.porcentajeRetencionOriginal").attr('value',dojo.byId("item28.porcentajeRetencionOriginal").value +"%");	
		dojo.byId("item28.montoRetencionOriginal").value =store.getValue(row, "montoRetencionOriginal");	
		//MONTOS ACTUALES
		dojo.byId("item28.baseRetencion").value =store.getValue(row, "baseRetencion");						
		dojo.byId("item28.porcentajeRetencion").value =store.getValue(row, "porcentajeRetencion");	
		dijit.byId("item28.porcentajeRetencion").attr('value',dojo.byId("item28.porcentajeRetencion").value +"%");			
		dojo.byId("item28.montoRetencion").value =store.getValue(row, "montoRetencion");
		this.montoBaseRetencion= dijit.byId("item28.baseRetencion").getValue();
		this.montoNetoRetencion= dijit.byId("item28.montoRetencion").getValue();
		bCargando= false;		
	 	this.dialogItem28.show();		
	},
	//PAS20201U210100230 -opv
	formatPorcentaje: function(valor, rowindex) {
		var valorRetorno=valor+ '%';
		return valorRetorno;	
	}
	,
	//PAS20201U210100230 -opv
	calculaRetencion: function (){

		var baseRetencion = dijit.byId("item28.baseRetencion").getValue();
		var porcentajeRetencion = dojo.byId("porcentajeRetencion28").value;
		var montoRetencion = 0;
		var moneda = dojo.byId("tipoMoneda28").value;

		montoRetencion = baseRetencion*porcentajeRetencion/100.00;
		montoRetencion=Number.parseFloat(Math.round(montoRetencion*100))/100;
		dijit.byId("item28.montoRetencion").setValue(montoRetencion);
		//console.log("montoRetencion--> " + montoRetencion);		
		//console.log("this.montoNetoRetencion--> " + this.montoNetoRetencion);
		//console.log("dijit.byId-item28.baseRetencion--> " + dijit.byId("item28.baseRetencion").getValue());
		//console.log("dojo.byId-importeTotal28--> " + dojo.byId("importeTotal28").value);
		if(dojo.byId("tipoMoneda28").value=="PEN"){
			if (isNaN(dijit.byId("item28.baseRetencion").getValue()) || dijit.byId("item28.baseRetencion").getValue() <= 0 || dijit.byId("item28.baseRetencion").getValue() <= dojo.byId("importeTotal28").value){
				console.log("montoRetencion entro soles --> " + montoRetencion);
				this.montoBaseRetencion= dijit.byId("item28.baseRetencion").getValue();
				this.montoNetoRetencion= montoRetencion;

			}
		}else{
			if (isNaN(dijit.byId("item28.baseRetencion").getValue()) || dijit.byId("item28.baseRetencion").getValue() <= 0 || dijit.byId("item28.baseRetencion").getValue() <= dojo.byId("importeTotal28").value || dijit.byId("item28.baseRetencion").getValue() >= dojo.byId("importeTotal28").value){
				console.log("montoRetencion entro otra moneda--> " + montoRetencion);
				this.montoBaseRetencion= dijit.byId("item28.baseRetencion").getValue();
				this.montoNetoRetencion= montoRetencion;
			}		
		}
			
		
	},
	//PAS20201U210100230
	showInformacionRetencion: function(){
		if(!dijit.byId("item28.baseRetencion").validate()){
		console.log("entro");
			return;
		}
		if (isNaN(dijit.byId("item28.baseRetencion").getValue())){
			nodeButton= dijit.byId("item28.baseRetencion").focusNode
			this.iconTooltipMessageV2(nodeButton, "icon-error-tooltip", "Debe registrar la Base imponible de retencion.");
			this.waitMessage.hide();
			return;
		}

		if (dijit.byId("item28.baseRetencion").getValue() <= 0 ){
			nodeButton= dijit.byId("item28.baseRetencion").focusNode
			this.iconTooltipMessageV2(nodeButton, "icon-error-tooltip", "El monto debe ser mayor a cero.");
			this.waitMessage.hide();
			return;
		}
		
		//console.log("baseRetencion--> " + dijit.byId("item28.baseRetencion").getValue());
		//console.log("importeTotal28--> " + Number(dojo.byId("importeTotal28").value));
		//console.log("tipoMoneda28--> " + dojo.byId("tipoMoneda28").value);
		if (dijit.byId("item28.baseRetencion").getValue() > Number(dojo.byId("importeTotal28").value) && dojo.byId("tipoMoneda28").value=="PEN" ){		
			console.log("entro a error--> ");
			nodeButton= dijit.byId("item28.baseRetencion").focusNode
			this.iconTooltipMessageV2(nodeButton, "icon-error-tooltip", "El monto no puede ser mayor al importe total de la factura.");
			this.waitMessage.hide();
			return;
		}
		if (Number(dijit.byId("item28.baseRetencionOriginal").getValue()) ==Number(dijit.byId("item28.baseRetencion").getValue()) ){
			nodeButton= dijit.byId("item28.baseRetencion").focusNode
			this.iconTooltipMessageV2(nodeButton, "icon-error-tooltip", "Debe modificar al menos un campo del comprobante para continuar.");
			this.waitMessage.hide();
			return;
		}
		console.log("this.montoNetoRetencion--> " + this.montoNetoRetencion);
		this.wait("Procesando", "95px", 200);
		var handler = dojo.io.iframe.send({
			url: this.controller + "?action=datosRetencion&baseretencion=" + dijit.byId("item28.baseRetencion").getValue() + "&porcentajeretencion=" + dojo.byId("porcentajeRetencion28").value + "&montoretencion=" + this.montoNetoRetencion,
			handleAs: "json",
			sync: true,
			timeout: 10000,
			preventCache: true
		});	

		handler.addCallback(dojo.hitch(this, function(res){
			this.waitMessage.hide();
			if(res.codeError == 0) {
				//GUARDAR EN GRILLA.
				store.fetchItemByIdentity({
					identity: currentLine,
					onItem: dojo.hitch(this, function(item){
						store.setValue(item,'baseRetencion',dojo.byId("item28.baseRetencion").value );
						store.setValue(item,'porcentajeRetencion',dojo.byId("porcentajeRetencion28").value );
						store.setValue(item,'modificado',"1");
						store.setValue(item,'montoRetencion',this.montoNetoRetencion);        			
					}),
					onError: function(){}
				});
				this.closeInfRetencion();								
				var grid = dijit.byId('ncCambioDetalles.ingreso-grid');
				grid.setStore(store);
				grid.update();
			} else {
				mostrarMensaje(res.messageError);	
				nbControl.attr('disabled', false);				
			}
		}));
			
		handler.addErrback(function(res){
			nbControl.attr('disabled', false);
			this.waitMessage.hide();
			mostrarMensaje("Problemas al conectarse con el servidor");
		});	

	},
	
//--------------------PAS20201U210100230 FIN FORMULARIO TIPO 28-opv--------------------------------	
	
//--------------------PAS20201U210100230 INI FORMULARIO TIPO 29-opv--------------------------------
	 truncateTwoDecimal:function(x, n) {
	  //x es el numero
	  //n es el numero de decimales
	  if(isNaN(x)){
		return;
	  }
	  var v = (typeof x === 'string' ? x : x.toString()).split('.');
	  if (n <= 0) return v[0];
	  var f = v[1] || '';
	  //if (f.length > n) return `${v[0]}.${f.substr(0,n)}`;
	  if (f.length > n) return  v[0]+"."+f.substr(0,n);
	  while (f.length < n) f += '0';
	  //return `${v[0]}.${f}`
	  return v[0]+"."+f;
	},
	roundTwoDecimalCuota:function (){
		var montoCuotaTwoDecimal=this.truncateTwoDecimal(dojo.byId("item29.MontoCuota").value,2);
		if(isNaN(montoCuotaTwoDecimal)){
			return;
		}
		dijit.byId("item29.MontoCuota").value=montoCuotaTwoDecimal;
		dojo.byId("item29.MontoCuota").value=montoCuotaTwoDecimal;
		dijit.byId("item29.MontoCuota")._set("state","");
	}, // Fin PAS20201U210100230
	
	roundTwoMontoNetoPendiente:function (){
		var montoNetoPendienteTwoDecimal=this.truncateTwoDecimal(dojo.byId("infCred.montoNetoPendiente").value,2);
		if(isNaN(montoNetoPendienteTwoDecimal)){
			return;
		}
		dijit.byId("infCred.montoNetoPendiente").value=montoNetoPendienteTwoDecimal;
		dojo.byId("infCred.montoNetoPendiente").value=montoNetoPendienteTwoDecimal;
		dijit.byId("infCred.montoNetoPendiente")._set("state","");
	}, // Fin PAS20201U210100230

	//PAS20201U210100230
	iconEdit29: function(rowindex) {
		return "<a href=\"#\" title=\"Editar\" onclick=\"notaCreditoFE.editItem29(" + rowindex + ")\"><img class=\"icon-by-edit16\" src=\"/a/imagenes/see/icons/edit.gif\"/></a>"; 
   },
   //PAS20201U210100230
	iconDel29: function(rowindex) {
		return "<a href=\"#\" title=\"Editar\" onclick=\"notaCreditoFE.delInfCredito29(" + rowindex + ")\"><img class=\"icon-by-del16\" src=\"/a/imagenes/s.gif\"/></a>"; 
   },
   //PAS20201U210100230
	addItem29: function() {	
		var grid = dijit.byId("ncCambioDetalles.ingreso-grid");
		this.showInfCuota();			
	},
	//PAS20201U210100230
	//SIRVE PARA BORRAR
	delInfCredito29: function(identificador) {
		var grid = dijit.byId("ncCambioDetalles.ingreso-grid");
		this.storeInfCredito.fetchItemByIdentity({
			identity: identificador,
			onItem: dojo.hitch(this, function(item){
			   this.storeInfCredito.deleteItem(item);
			   grid.setStore(this.storeInfCredito);
			   grid.update();
			   //QUITAR ELEMENTOS DE LA LISTA
			   
			   var removeIndex = this.listaElementosInfCredito.map(function(item) { return item.identificador; }).indexOf(identificador);
				// remove object
				this.listaElementosInfCredito.splice(removeIndex, 1);
			}),
			onError: function(){
				mostrarMensaje("Ocurrio un error al ubicar el documento");
			}
		});
		//LLAMAR AL METODO ORDENAR POR FECHA
		this.infCreditoOrdenarPorFecha();
	},
	//PAS20201U210100230
	//SIRVE PARA EDITAR
	editItem29: function(identificador) {
			//var nodeButton = dijit.byId("docrel.botonDelDoc").focusNode;
			var grid = dijit.byId("ncCambioDetalles.ingreso-grid");
			// NECESARIO PARA DETECTAR QUE ITEM ESTAS EDITANDO
			this.storeInfCredito.fetchItemByIdentity({
				identity: identificador,
				onItem: dojo.hitch(this, function(item){
					//CREAR VARIABLE STORE-CUOTA
					//OPV-INI-Compatibilidad Internet Explorer
					//var itemCuota=this.listaElementosInfCredito.findIndex((obj => obj.identificador == item.identificador));
					var itemCuota;
					for (var i = 0; i < this.listaElementosInfCredito.length; ++i) {
						if (this.listaElementosInfCredito[i].identificador == item.identificador) {
							itemCuota = i;
							break;
						}
					};	
					//OPV-FIN-Compatibilidad Internet Explorer
					this.storeInfCuota=this.listaElementosInfCredito[itemCuota];
					// PARA EDITAR
					this.limpiarInfCuota();					   
					this.showInfCuota("Editar",this.storeInfCuota);
				}),
				onError: function(){
					mostrarMensaje("Ocurrio un error al ubicar el documento");
				}
			});				
		},
	
	//PAS20201U210100230
	cargarDatosdeTabla29:function(){
		var handler = dojo.xhrGet({
				url: this.controller + "?action=getJsonItemsNCFactoring", 
				handleAs: "json",
				sync: true,
				preventCache: true,
				timeout: 10000
		});
		handler.addCallback(dojo.hitch(this, function(res){							
			if(res.items.length>0) {
				var itemsGrilla =  res.items ;					
				this.factoringCargarInfCredito(itemsGrilla);								
			}
		}));		
	},	
	//PAS20201U210100230 -opv
	stringToDate:function (_date,_format,_delimiter)
	{
            var formatLowerCase=_format.toLowerCase();
            var formatItems=formatLowerCase.split(_delimiter);
            var dateItems=_date.split(_delimiter);
            var monthIndex=formatItems.indexOf("mm");
            var dayIndex=formatItems.indexOf("dd");
            var yearIndex=formatItems.indexOf("yyyy");
            var month=parseInt(dateItems[monthIndex]);
            month-=1;
            var formatedDate = new Date(dateItems[yearIndex],month,dateItems[dayIndex]);
            return formatedDate;
	},
	//PAS20201U210100230 -opv
	formatDosDecimales: function(valor, rowindex) {
		var valorCambiado=valor;
		require(["dojo/number", "dojo/dom", "dojo/on", "dojo/domReady!"],
		function(number, dom, on){
			var val = valorCambiado,
			locale = "es_PE";
			var out = number.format(val, {
			  places: 2,
			  locale: locale
			});
			valorCambiado=out;
		});
		return valorCambiado;	
	}
	,
	//PAS20201U210100230 -opv
	factoringCargarInfCredito: function(itemsGrilla) {	
		if(itemsGrilla.length!=0){
			// dijit.byId("docrelInfCred.montoNetoPendiente").setValue(this.montoNetoPendienteGuardado);
			// GUARDO LA NUEVA LISTA	
			this.listaElementosInfCredito=[];		
			this.storeInfCreditoGuardado=[];		
			// CREO LISTA QUE REEMPLAZARA
			var ListaOrdenada=[];		
			this.montoTotalCuotas=0;
			this.indRegitroInfCredito=0;
			//RECORRO NUEVAMENTE LA GRILLA
			this.storeInfCredito = new dojo.data.ItemFileWriteStore({data: {identifier: 'identificador', items: [], preventCache: true}});					
			//OPV-INI-Compatibilidad Internet Explorer					
			//itemsGrilla.forEach(element=>{
			for (i=0; i < itemsGrilla.length; i++) {
				var element=itemsGrilla[i];	
				var montoCuotaActual="";
				montoCuotaActual=element.montoCuota;
				var montoCuotaNumero=Number(montoCuotaActual.replace(/,/g,''));
				row={ 
					identificador: this.indRegitroInfCredito,
					modifica: this.indRegitroInfCredito,
					modificado: element.modificado,
					elimina: this.indRegitroInfCredito,
					numeroCuota: Number(element.numeroCuota),
					fechaVencimiento: element.fechaVencimiento, 
					fechaVencimientoDate: this.stringToDate(element.fechaVencimiento,"dd/MM/yyyy","/"), 						
					montoCuota: Number(montoCuotaNumero)						
				};
				this.indRegitroInfCredito++;
				this.listaElementosInfCredito.push(row);	
				this.storeInfCreditoGuardado.push(row);
				ListaOrdenada.push(row);
				//SUMAR EL TOTAL DE LAS CUOTAS
				this.storeInfCredito.newItem(row);
				this.montoTotalCuotas=Number(this.montoTotalCuotas)+Number(montoCuotaNumero);
				//dojo.byId("docrelInfCred.TotalCuotas").innerHTML =this.montoTotalCuotas;	
			};	
			//OPV-FIN-Compatibilidad Internet Explorer
			//REALIZAS EL REEMPLAZO
			var grid = dijit.byId("ncCambioDetalles.ingreso-grid");			
			grid.setStore(this.storeInfCredito);
/* 			if(dijit.byId("ncCambioDetalles.ingreso-grid").store.save) {
				dijit.byId("ncCambioDetalles.ingreso-grid").store.save();
			} */
			grid.store.save();
			grid.store.close();	
		    grid._refresh();			
			grid.startup();
			grid.update();
	
		}	
	}, 
	//PAS20201U210100230
	//SIRVE PARA LIMPIAR FORMULARIO DE CUOTAS
	limpiarInfCuota: function() {
		dijit.byId("item29.FechaVencimiento").setValue(null);
		dijit.byId("item29.MontoCuota").setValue(0);		
	},
	//PAS20201U210100230
	//SIRVE PARA ABRIR EL FORMULARIO DE CUOTAS	
	showInfCuota: function(Tipo,Datos) {
		this.dialogItem29 =  dijit.byId("dialogItem29");
		require(["dijit/registry"], function(registry){
			var formInfCuota = registry.byId("item29.form");
			formInfCuota.reset();
		});	
		if(Tipo!=undefined && Datos!=undefined){
			if(this.storeInfCuota!=null){
				var split=this.storeInfCuota.fechaVencimiento.split("/");
				var fechaConFormatoCombo =split[2] +'-'+ split[1] +'-'+ split[0];
				dijit.byId("item29.FechaVencimiento").setValue(fechaConFormatoCombo);
				dijit.byId("item29.MontoCuota").setValue(this.storeInfCuota.montoCuota);	
			}			
			this.dialogItem29.show();
		}else{		
			this.storeInfCuota=null	;
			this.limpiarInfCuota();			
			this.dialogItem29.show();
		}
	},		
	//PAS20201U210100230	-opv		  
	//ORDENA POR FECHAS Y ACTUALIZA EL TOTAL DE DE LA SUMA DE CUOTAS, TAMBIEN CAMBIA LOS VALORES ACTUALES DE LOS IDENTIFICADORES Y NUMEROS DE CUOTAS.
	infCreditoOrdenarPorFecha: function() {		
			var ListaOrdenada=[];
			var grid = dijit.byId("ncCambioDetalles.ingreso-grid");			
			if(this.listaElementosInfCredito.length >0){
				//ORDENAR ELEMENTOS
				this.listaElementosInfCredito.sort(function (x, y) {
					let a = x.fechaVencimientoDate,
						b = y.fechaVencimientoDate;
					return a - b;
				});
				this.montoTotalCuotas=0;
				// RECORRO PARA EVITAR QUE EL ITEM FILE SOBREESCRIBA.
				for(i=0;i< this.listaElementosInfCredito.length;i++){
					this.listaElementosInfCredito[i].identificador=i;
					this.listaElementosInfCredito[i].modifica=i;
					this.listaElementosInfCredito[i].elimina=i;
					this.listaElementosInfCredito[i].modificado="1";					
					this.listaElementosInfCredito[i].numeroCuota=i+1;					
				}				
				//REEMPLAZAR  EN OTRA LISTA PARA EVITAR ITEM FILE SOBREESCRIBA.
				//OPV-INI-Compatibilidad Internet Explorer
				//this.listaElementosInfCredito.forEach(element=>{
				for (i=0; i < this.listaElementosInfCredito.length; i++) {
					var element=this.listaElementosInfCredito[i];		
						var row={ 
		     				identificador: element.identificador,
							modifica: element.modifica,
							elimina: element.elimina,
							modificado:element.modificado,
							numeroCuota: element.numeroCuota,
							fechaVencimiento: element.fechaVencimiento, 
							fechaVencimientoDate: element.fechaVencimientoDate, 
							montoCuota: element.montoCuota					   
						};
						ListaOrdenada.push(row);
						//SUMAR EL TOTAL DE LAS CUOTAS
						this.montoTotalCuotas=Number(this.montoTotalCuotas)+Number(row.montoCuota);
						//dojo.byId("docrelInfCred.TotalCuotas").innerHTML =this.montoTotalCuotas;	
				};	
				//OPV-FIN-Compatibilidad Internet Explorer
				//CREAR NUEVO STORE PARA TABLA	ESTE METODO SOBREESCRIBE ListaOrdenada	pero no	this.listaElementosInfCredito
				this.storeInfCredito = new dojo.data.ItemFileWriteStore({data: {identifier: 'identificador', items: ListaOrdenada, preventCache: true}});
				grid.setStore(this.storeInfCredito);
				grid.startup();
				grid.update();
			}
		},
		//PAS20201U210100230
		infCuotaCerrar:function() {
			 this.dialogItem29 =  dijit.byId("dialogItem29");
			 this.dialogItem29.hide();
		},
		//PAS20201U210100230
		infCuotaAceptar:function() {
			var fechaEmision = this.stringToDate(dojo.byId("fechaEmisionOriginal").value,"dd/MM/yyyy","/"); 
			
			var nodeButton;
			var oDoc;
			var row;
			//INICIO VALIDACIONES
			//CAMPO FECHA VACIO
			if (dojo.byId("item29.FechaVencimiento").value=="") {
				/*nodeButton= dijit.byId("item29.FechaVencimiento").focusNode
				this.iconTooltipMessageV2(nodeButton, "icon-error-tooltip", "Ingrese una fecha de vencimiento.");*/
				mostrarMensaje("Ingrese una fecha de vencimiento.");
				return;
			}	
			//FECHA INVALIDA
			if (dijit.byId("item29.FechaVencimiento").value==null ) {
				/*nodeButton= dijit.byId("item29.FechaVencimiento").focusNode
				this.iconTooltipMessage(nodeButton, "icon-error-tooltip", "Fecha inválida. Ingresar en formato dd/mm/yyyy.");
				this.waitMessage.hide();*/
				mostrarMensaje("Fecha inválida. Ingresar en formato dd/mm/yyyy.");
				return;
			}	
			//FECHA EMISION mayor a fecha de vencimiento
			console.log("item29.FechaVencimiento--> " + dijit.byId("item29.FechaVencimiento").value);
			console.log("fechaEmision--> " + fechaEmision);
			if (dijit.byId("item29.FechaVencimiento").value <= fechaEmision ) {
				/*nodeButton= dijit.byId("item29.FechaVencimiento").focusNode
				this.iconTooltipMessageV2(nodeButton, "icon-error-tooltip", "La fecha de vencimiento no puede ser menor a la fecha de emisión.");
				return;*/
				mostrarMensaje("La fecha la cuota debe ser mayor a la fecha de emisión.");//20100238234 - EPY
				return;
			}
			//Validaciones para el monto de cuota.
			//MONTO NO VALIDO
			if (isNaN(dijit.byId("item29.MontoCuota").value)==true) {
				/*nodeButton= dijit.byId("item29.MontoCuota").focusNode
				this.iconTooltipMessageV2(nodeButton, "icon-error-tooltip", "Ingrese monto de la cuota.");*/
				mostrarMensaje("Ingrese monto de la cuota.");
				return;
			}
			//MONTO MENOR O IGUAL A 0
			if (dijit.byId("item29.MontoCuota").value<= 0 || dijit.byId("item29.MontoCuota").value== '' ) {
				/*nodeButton= dijit.byId("item29.MontoCuota").focusNode
				this.iconTooltipMessageV2(nodeButton, "icon-error-tooltip", "La cuota debe ser mayor a 0");*/
				mostrarMensaje("Ingrese monto de la cuota.");
				return;
			}
			
			// INICIO DE LOGICA
			if(this.storeInfCuota==null){				
				oDoc={
					identificador:this.indRegitroInfCredito,
					numeroCuota:this.indRegitroInfCredito,
					fechaVencimiento: dijit.byId("item29.FechaVencimiento").getValue(),
					montoCuota: dijit.byId("item29.MontoCuota").getValue()
				};		
				row = {
					identificador: oDoc.identificador,
					modifica: oDoc.identificador,
					elimina: oDoc.identificador,
					modificado:"1",
					numeroCuota: oDoc.numeroCuota,
					fechaVencimiento: dojo.date.locale.format(oDoc.fechaVencimiento, {datePattern: "dd/MM/yyy", selector: "date"}), 
					fechaVencimientoDate: oDoc.fechaVencimiento,
					montoCuota: oDoc.montoCuota
					};	
				this.indRegitroInfCredito++;					
				//Agregar a lista				
				//Agregar Valor de total
				this.listaElementosInfCredito.push(row);
				this.montoTotalCuotas= row.montoCuota;	
				const Objeto= row;	
				//  LOGICA	MULTIPLE	PRIMER INGRESO CREA LUEGO AGREGA		
				this.AgregarOActualizar(Objeto);

			}else
			{
				oDoc={
					identificador:this.storeInfCuota.identificador,
					numeroCuota:this.storeInfCuota.identificador,
					fechaVencimiento:dijit.byId("item29.FechaVencimiento").getValue(),
					montoCuota:dijit.byId("item29.MontoCuota").getValue()
				};				
				row = {
					identificador: oDoc.identificador,
					modifica: oDoc.identificador,
					elimina: oDoc.identificador,
					modificado:"1",
					numeroCuota: oDoc.numeroCuota,
					fechaVencimiento: dojo.date.locale.format(oDoc.fechaVencimiento, {datePattern: "dd/MM/yyy", selector: "date"}), 
					fechaVencimientoDate: oDoc.fechaVencimiento,
					montoCuota: oDoc.montoCuota
					};
				//Reemplazar valor de la lista actual.
				//OPV-INI-Compatibilidad Internet Explorer
				//var objIndex = this.listaElementosInfCredito.findIndex((obj => obj.identificador == row.identificador));
				var objIndex;
				for (var i = 0; i < this.listaElementosInfCredito.length; ++i) {
					if (this.listaElementosInfCredito[i].identificador == row.identificador) {
						objIndex = i;
						break;
					}
				};	
				//OPV-FIN-Compatibilidad Internet Explorer
				this.listaElementosInfCredito[objIndex].fechaVencimiento= row.fechaVencimiento;
				this.listaElementosInfCredito[objIndex].montoCuota=row.montoCuota;	
				this.listaElementosInfCredito[objIndex].fechaVencimientoDate=row.fechaVencimientoDate;					
				
			}	
			this.dialogItem29.hide();
			//LLAMAR AL METODO ORDENAR POR FECHA
			this.infCreditoOrdenarPorFecha();
		},
		//PAS20201U210100230
		//PAS20201U210100230 TIENE 3 LOGICAS CREA STORE INFO, AGREGA ITEMS ACTUALIZA GRILLA DEPENDIENDO DE LO QUE TIENE LLENO.
		AgregarOActualizar:function(valor) {
			const row=valor;
			if(row!=null && row!=undefined){
				if(this.storeInfCredito == null){
						//Agregar a tabla
						this.storeInfCredito = new dojo.data.ItemFileWriteStore({data: {identifier: 'identificador', items: [], preventCache: true}});
						this.storeInfCredito.newItem(row);	
				}else{
					this.storeInfCredito.newItem(row);								
				}
			}	
		    //SINO ENVIAS NADA SOLO ACTUALIZA
			var grid = dijit.byId("ncCambioDetalles.ingreso-grid");
			grid.setStore(this.storeInfCredito);
			if(dijit.byId("ncCambioDetalles.ingreso-grid").store.save) {
			   dijit.byId("ncCambioDetalles.ingreso-grid").store.save();
			}
			grid.startup();
			grid.update();
		
		},
		//FormularioAgregarCuotas FIN
		
		//SIRVE PARA GUARDAR
		infCreditoRegistrar: function() {	
			//validacion de minimo y maximo
			var montoTotalFactura=Number(dojo.byId("importeTotal29").value); 
			var maximoCuotas= Number(dojo.byId("creditoCuotasMaximo29").value);  
			this.montoNetoPendienteGuardado= dijit.byId("infCred.montoNetoPendiente").value;
			var nodeButton;
			if (dijit.byId("ncCambioDetalles.ingreso-grid").rowCount == 0 ) {
				/*nodeButton= dijit.byId("factura.botonGrabarDocumento").focusNode
				this.iconTooltipMessageV2(nodeButton, "icon-error-tooltip", "Debe registrar al menos 1 cuota");
				return;*/
				mostrarMensaje("Debe registrar al menos 1 cuota.");																													  
				return;
			}
			console.log("grid--> " + dijit.byId("ncCambioDetalles.ingreso-grid").rowCount );
			console.log("maximoCuotas--> " + Number(maximoCuotas));
			if (dijit.byId("ncCambioDetalles.ingreso-grid").rowCount >Number(maximoCuotas)  ) {
				/*nodeButton= dijit.byId("factura.botonGrabarDocumento").focusNode
				this.iconTooltipMessageV2(nodeButton, "icon-error-tooltip", "MÃ­nimo 1, mÃ¡ximo 60 cuotas");
				return;*/
				mostrarMensaje("Mínimo 1 cuota y máximo 60 cuotas.");																													  
				return;
			}
			// VALIDACIONES PARA  MONTO NETO PENDIENTE
			if (isNaN(dijit.byId("infCred.montoNetoPendiente").value)==true  ) {
				nodeButton= dijit.byId("infCred.montoNetoPendiente").focusNode
				this.iconTooltipMessageV2(nodeButton, "icon-error-tooltip", "Debe registrar el Monto neto pendiente de pago.");
				return;
			}
			if (dijit.byId("infCred.montoNetoPendiente").value <= 0 || dijit.byId("infCred.montoNetoPendiente").value== '') {
				nodeButton= dijit.byId("infCred.montoNetoPendiente").focusNode
				this.iconTooltipMessageV2(nodeButton, "icon-error-tooltip", "El monto debe ser mayor a 0");
				return;
			}
			
			//if (dijit.byId("infCred.montoNetoPendiente").value > Number(montoTotalFactura) && dojo.byId("tipoMoneda28").value=="PEN" ) {
			if (dijit.byId("infCred.montoNetoPendiente").value > Number(montoTotalFactura)) {
				nodeButton= dijit.byId("infCred.montoNetoPendiente").focusNode
				this.iconTooltipMessageV2(nodeButton, "icon-error-tooltip", "El monto no puede ser mayor al importe total de la factura.");
				return;
			}//PAS20211U210700145 - AFT
			//VALIDACION DE SUMA DE CUOTAS.			
			//if (this.montoTotalCuotas.toFixed(2)> Number(montoTotalFactura) ) {
				/*nodeButton= dijit.byId("factura.botonGrabarDocumento").focusNode				
				this.iconTooltipMessageV2(nodeButton, "icon-error-tooltip", "La suma de las cuotas no pueden ser mayor al importe total de la factura.");
				return;*/
			/*	mostrarMensaje("La suma de las cuotas no pueden ser mayor al importe total de la factura.");																													  
				return;				
			}*/
			//PAS20211U210700145 - AFT
			if (this.montoTotalCuotas.toFixed(2) != Number(this.montoNetoPendienteGuardado)) {
				mostrarMensaje("La suma de las cuotas debe ser igual al Monto neto pendiente de pago.");																														  
				return;				
			}
			//GUARDAMOS EN SESION LOS ULTIMOS DATOS
			//this.storeInfCreditoGuardado=this.listaElementosInfCredito.slice();	// Se sobreescribe
			this.storeInfCreditoGuardado=[];
			//OPV-INI-Compatibilidad Internet Explorer
			//this.listaElementosInfCredito.forEach(element=>{
			for (i=0; i < this.listaElementosInfCredito.length; i++) {
				var element=this.listaElementosInfCredito[i];
				this.storeInfCreditoGuardado.push(element);
			};
			//OPV-FIN-Compatibilidad Internet Explorer
			//this.montoNetoPendienteGuardado= dijit.byId("infCred.montoNetoPendiente").value;
			this.montoTotalCuotasGuardado=this.montoTotalCuotas;
			// FIN VALIDACIONES PARA  MONTO NETO PENDIENTE
			var parametros={
				ListaCreditos:dojo.toJson(this.listaElementosInfCredito),
				MontoNetoPendiente:Number(this.montoNetoPendienteGuardado)
			};
			var jsonString;
			require(["dojo/json"], function(JSON){
			 jsonString = JSON.stringify(parametros);
			});
			//INTENTO 
			this.waitMessage.show();
			var handler = dojo.xhrPost({
				url: this.controller + "?action=guardarDetallesFactoringNCSesion",
				postData: parametros,
				handleAs: "json",
				sync: true,
				timeout: 10000
			});
			handler.addCallback(dojo.hitch(this, function(response){
				if(response.codeError == 0) {
					this.waitMessage.hide();	
					var tipo="29";
					//-----------------Redirige a pantalla Preliminar	----------------				
					this.content.setHref(this.controller + "?action=preliminarComprobante&TipoNotaCred=" + tipo + "&factura=" + dijit.byId("pantallaInicial.numeroFE").value + "&motivo=" + dijit.byId("pantallaInicial.motivoEmisionNC").value);	
  
	
				 
				}else if(response.codeError == 1) {
					this.waitMessage.hide();	
					var tipo="29";
					// mostrarMensaje(""+response.data);
					// PAS20211U210700145 - EPY - INI
					if (response.messageError == undefined){
						mostrarMensaje(""+response.data);
					}else{
						mostrarMensaje(""+response.messageError);
					}
					// PAS20211U210700145 - EPY - FIN
				}
			}));			
   
			handler.addErrback(dojo.hitch(this, function(res) {
				this.waitMessage.hide();
				this.iconTooltipMessage(nodeButton, "icon-error-tooltip", "Problemas al conectarse al servidor");
			}));

		},
//--------------------PAS20201U210100230 FIN FORMULARIO TIPO 29-opv--------------------------------		

  
  verPreliminarContin: function() {	
		var serie = document.getElementById("serie").value;
		var numero = document.getElementById("numero").value;
		var idSerie = document.getElementById("idSerie").value;
		var idSerieNew = document.getElementById("idSerieNew").value;
		var factura= dijit.byId("pantallaInicial.numeroFE").value;
		var factura2= dijit.byId("pantallaInicial.numeroNuevaFE").value;
		if(numero==""){
			mostrarMensaje("Ingrese el n\xFAmero de serie");
			document.getElementById("numero").focus();
			return;
		}
		if(!dijit.byId("criterio.form").validate()) return;
		valor = dojo.byId("pantallaInicial.tipoNotaCredito").value;
        if (valor == ""){
			mostrarMensaje("Debe seleccionar el tipo de Nota de Cr\xE9dito a emitir.");
			return;
        }
        
		if (dojo.byId("pantallaInicial.numeroFE").value == ""){
			mostrarMensaje("Debe ingresar el n\xFAmero de Factura Contingencia respecto a la cual se emitir\xE1 la Nota de Cr\xE9dito.");
			return;                
        } 
        
		valor = dijit.byId("pantallaInicial.tipoNotaCredito").getValue();
		if (valor == "21" || valor == "25" || valor == "26" || valor == "27") {
			if (dojo.byId("pantallaInicial.motivoEmisionNC").value == ""){
				mostrarMensaje("Debe ingresar el motivo o sustento por el cu\u00E1l se emitir\xE1 la Nota de Cr\xE9dito.");
				return;                
			} 
        }
		
        /*if (valor == "22") {
			if (dijit.byId("pantallaInicial.numeroNuevaFE").value == ""){
				mostrarMensaje("Debe ingresar el n\xFAmero de la nueva Factura Electr\xf3nica.");
				return;                
			}
        }*/
		
        valor = dijit.byId("pantallaInicial.tipoNotaCredito").getValue();
        if (this.facturaBean!=null && valor == "23") {
			if (dojo.byId("pantallaInicial.motivoEmisionNC").value == ""){
				mostrarMensaje("Debe ingresar el motivo o sustento por el cu\u00E1l se emitir\xE1 la Nota de Cr\xE9dito.");
				return;                
			}
			if (dojo.byId("pantallaInicial.descuentoGlobalNC").value == "" ){
				mostrarMensaje("Debe consignarse el descuento global.");
				return;                
			}
			if (dijit.byId("pantallaInicial.descuentoGlobalNC").getValue()  == 0){
				mostrarMensaje("Descuento Global debe ser mayor que cero.");
				return;                
			}
			
			var totalValorVenta = this.facturaBean.montoTotalGeneral;				
			var desc = dijit.byId("pantallaInicial.descuentoGlobalNC").getValue();
			var isc = 0;
			var igv = 0;
			if (dijit.byId("pantallaInicial.descuentoGlobalNC").getValue() >= totalValorVenta){
				mostrarMensaje("Descuento Global debe ser menor que el Valor de Venta de la FE respecto de la cual se emitir\u00E1 la NC.");
				return;                
			} 
             
			if (dijit.byId("pantallaInicial.descuentoGlobalNC").getValue() == 0){
				mostrarMensaje("Descuento Global debe ser mayor que cero");
               	return;                
			}
                 
			//Validamos ISC
			if (dijit.byId("pantallaInicial.ISCNC").disabled == false){
				if (dojo.byId("pantallaInicial.ISCNC").value == "" ){
					mostrarMensaje("Debe consignarse el ISC.");
					return;                
				}
				if (dijit.byId("pantallaInicial.ISCNC").getValue() == 0){
					mostrarMensaje("ISC debe ser mayor que cero");
					return;                
				}                  
				if (dijit.byId("pantallaInicial.ISCNC").getValue() >= totalValorVenta){
					mostrarMensaje("ISC debe ser menor que el Valor de Venta de la FE respecto de la cual se emitir\u00E1 la NC");
					return;                
				}
				if (dijit.byId("pantallaInicial.ISCNC").getValue() >= dijit.byId("pantallaInicial.descuentoGlobalNC").getValue()){
					mostrarMensaje("ISC debe ser menor que el monto de Descuento Global Registrado");
					return;                
				}	
				var totalISC = this.facturaBean.totalISC;
				if (dijit.byId("pantallaInicial.ISCNC").getValue() >= totalISC){
					mostrarMensaje("ISC registrado debe ser menor al ISC de la FE respecto de la cual se emitir\u00E1 la NC");
					return;                
				}
				
				isc = dijit.byId("pantallaInicial.ISCNC").getValue() ;
			}
				
			igv = dijit.byId("pantallaInicial.IGVNC").getValue() ;
			if ((desc + igv + isc ) >= totalValorVenta){
				mostrarMensaje("La suma del Descuento Global + IGV + ISC debe ser menor que el Valor de Venta de la FE respecto de la cual se emitir\u00E1 la NC.");
				return;                
			}
        }	
        		
        valor = dijit.byId("pantallaInicial.tipoNotaCredito").getValue();
        if (valor == "24") {
			if (dojo.byId("pantallaInicial.motivoEmisionNC").value == ""){
				mostrarMensaje("Debe ingresar el motivo o sustento por el cu\u00E1l se emitir\xE1 la Nota de Cr\xE9dito.");
				return;                
			}
		}

      	var handler = dojo.xhrGet({
			url: this.controller + "?action=validarComprobanteContin&TipoNotaCred=" + dijit.byId("pantallaInicial.tipoNotaCredito").value + "&factura=" + factura  + "&facturanew=" + factura2+"&idSerie="+idSerie+"&idSerieNew="+idSerieNew,
				handleAs: "json",
				sync: true,
				preventCache: true,
				timeout: 10000
		});
		
		handler.addCallback(dojo.hitch(this, function(res){
		
		var serie = document.getElementById("serie").value;
		var numero = document.getElementById("numero").value;
		var idSerie = document.getElementById("idSerie").value;
		var idSerieNew = document.getElementById("idSerieNew").value;
		var factura= dijit.byId("pantallaInicial.numeroFE").value;
		var factura2= dijit.byId("pantallaInicial.numeroNuevaFE").value;

			
			if (res.codeError == 0) {
				if (valor == "25" || valor == "26" ||valor == "27") {
					this.content.setHref(this.controller + "?action=cambiarDetallesNCContin&TipoNotaCred=" + dijit.byId("pantallaInicial.tipoNotaCredito").value + "&factura=" + factura+ "&motivo=" + dijit.byId("pantallaInicial.motivoEmisionNC").value+ "&facturanew=" +factura2+ "&descuento=" + dijit.byId("pantallaInicial.descuentoGlobalNC").value+ "&isc=" + dijit.byId("pantallaInicial.ISCNC").value+ "&igv=" + dijit.byId("pantallaInicial.IGVNC").value+"&idSerie="+idSerie+"&serie="+serie+"&numero="+numero+"&idSerieNew="+idSerieNew); //PAS20191U210100075 26.07
				}
				if (valor == "21" || valor == "22" ||valor == "23" ||valor == "24" ) {
					this.content.setHref(this.controller + "?action=preliminarComprobanteContin&TipoNotaCred=" + dijit.byId("pantallaInicial.tipoNotaCredito").value + "&factura=" +factura+ "&motivo=" + dijit.byId("pantallaInicial.motivoEmisionNC").value+ "&facturanew=" + factura2+ "&descuento=" + dijit.byId("pantallaInicial.descuentoGlobalNC").value+ "&isc=" + dijit.byId("pantallaInicial.ISCNC").value+ "&igv=" + dijit.byId("pantallaInicial.IGVNC").value+"&serie="+serie+"&numero="+numero+"&idSerie="+idSerie+"&idSerieNew="+idSerieNew); //PAS20191U210100075 26.07
				}    		   
			} else {				
				if (res.codeError == 9) {
					//if (!confirm(res.messageError + " \u00BFDesea continuar?. Puede revisar las notas de credito emitidas en la opci\u00F3n de consultas.")){
						//return;
					mostrarMensajeConfirmacion(res.messageError + " \u00BFDesea continuar?. Puede revisar las notas de credito emitidas en la opci\u00F3n de consultas.", 
						dojo.hitch(this, function(){
					//}else{
					}), dojo.hitch(this, function(){
						if (valor == "25" || valor == "26" ||valor == "27") {
							this.content.setHref(this.controller + "?action=cambiarDetallesNCContin&TipoNotaCred=" + dijit.byId("pantallaInicial.tipoNotaCredito").value + "&factura=" +factura+ "&motivo=" + dijit.byId("pantallaInicial.motivoEmisionNC").value+ "&facturanew=" +factura2+ "&descuento=" + dijit.byId("pantallaInicial.descuentoGlobalNC").value+ "&isc=" + dijit.byId("pantallaInicial.ISCNC").value+ "&igv=" + dijit.byId("pantallaInicial.IGVNC").value+"&serie="+serie+"&numero="+numero+"&idSerie="+idSerie+"&idSerieNew="+idSerieNew); //PAS20191U210100075 26.07
						}
						if (valor == "21" || valor == "22" ||valor == "23" ||valor == "24" ) {
							this.content.setHref(this.controller + "?action=preliminarComprobanteContin&TipoNotaCred=" + dijit.byId("pantallaInicial.tipoNotaCredito").value + "&factura=" +factura+ "&motivo=" + dijit.byId("pantallaInicial.motivoEmisionNC").value+ "&facturanew=" +factura2+ "&descuento=" + dijit.byId("pantallaInicial.descuentoGlobalNC").value+ "&isc=" + dijit.byId("pantallaInicial.ISCNC").value+ "&igv=" + dijit.byId("pantallaInicial.IGVNC").value+"&serie="+serie+"&numero="+numero+"&idSerie="+idSerie+"&idSerieNew="+idSerieNew);
						}
					}
					))
				}else{                       
					mostrarMensaje(res.messageError);
					return;
				}
			}
		}));
		
    	handler.addErrback(function(res){
    		this.waitMessage.hide();
    		mostrarMensaje("Problemas al conectarse con el servidor");
		});    			 
	},
	
	saveDocument: function() {
		//if (!confirm("Esta Ud. seguro de emitir una Nota de Cr\xE9dito")){
			//return;
		//}
	  var accionBtnAceptarQ2 = dojo.hitch(this, function () {
		
		var nbBack = dijit.byId("notaCredito-preliminar.botonBackDocumento");
		var nbSave = dijit.byId("notaCredito-preliminar.botonGrabarDocumento");
		var nbClose = dijit.byId("notaCredito-preliminar.botonCloseDocumento");
		
		nbBack.setAttribute('disabled', true);
		nbSave.setAttribute('disabled', true);
		nbClose.setAttribute('disabled', true);
		
		this.wait("Grabando", "95px", 800);
		
        var handler = dojo.xhrGet({
            url: this.controller + "?action=grabarComprobante",
            handleAs: "json",
            preventCache: true,
            sync: true,
            timeout: 90000
        });			
			
        handler.addCallback(dojo.hitch(this, function(res){
            this.waitMessage.hide();
            if (res.codeError == 0) {
    				    this.content.onLoad = dojo.hitch(this, function(){
    				    this.iconTooltipMessage("numeroComprobante", "icon-ok-tooltip", "La nota de credito se emitio correctamente. <br>Ha generado este n&uacute;mero.");
    				    });            	
    				    this.content.setHref(this.controller + "?action=mostrarComprobante&preventCache=" + this.preventCache());
            } else {
        				nbBack.setAttribute('disabled', false);
        				nbSave.setAttribute('disabled', false);
        				nbClose.setAttribute('disabled', false);
    				
                mostrarMensaje(res.messageError);
            }
        }));
        handler.addErrback(dojo.hitch(this, function(res){
  			nbBack.setAttribute('disabled', false);
  			nbSave.setAttribute('disabled', false);
  			nbClose.setAttribute('disabled', false);
  			
            this.waitMessage.hide();
            mostrarMensaje("Problemas al emitir la Nota de Credito Electronica.");
        }));
	  });
		
		mostrarMensajeConfirmacion("\u00BFEst\u00E1 Ud. seguro de emitir una Nota de Cr\xE9dito?", accionBtnAceptarQ2 );
	},         
        
		
	saveDocumentContin: function() {
		//if (!confirm("Esta Ud. seguro de registrar una Nota de Cr\xE9dito Contingencia")){
		//	return;
		//}
	  var accionBtnAceptarQ2_ = dojo.hitch(this, function () {
		
		var nbBack = dijit.byId("notaCredito-preliminar.botonBackDocumento");
		var nbSave = dijit.byId("notaCredito-preliminar.botonGrabarDocumento");
		var nbClose = dijit.byId("notaCredito-preliminar.botonCloseDocumento");
		
		nbBack.setAttribute('disabled', true);
		nbSave.setAttribute('disabled', true);
		nbClose.setAttribute('disabled', true);
		
		this.wait("Grabando", "95px", 800);
		
        var handler = dojo.xhrGet({
            url: this.controller + "?action=grabarComprobanteContin",
            handleAs: "json",
            preventCache: true,
            sync: true,
            timeout: 90000
        });			
			
        handler.addCallback(dojo.hitch(this, function(res){
            this.waitMessage.hide();
            if (res.codeError == 0) {
    				    this.content.onLoad = dojo.hitch(this, function(){
    				    this.iconTooltipMessage("numeroComprobante", "icon-ok-tooltip", "El registro de la presente informacion constituye una declaracion jurada, acorde con la RS 113-2018/SUNAT.<br>Ha generado este n&uacute;mero.");
    				    });            	
    				    this.content.setHref(this.controller + "?action=mostrarComprobante&preventCache=" + this.preventCache());
            } else {
        				nbBack.setAttribute('disabled', false);
        				nbSave.setAttribute('disabled', false);
        				nbClose.setAttribute('disabled', false);
    				
                mostrarMensaje(res.messageError);
            }
        }));
        handler.addErrback(dojo.hitch(this, function(res){
  			nbBack.setAttribute('disabled', false);
  			nbSave.setAttribute('disabled', false);
  			nbClose.setAttribute('disabled', false);
  			
            this.waitMessage.hide();
            mostrarMensaje("Problemas al emitir la Nota de Credito Electronica de contingencia.");
        }));
		
	  });
		
		mostrarMensajeConfirmacion("\u00BFDEst\u00E1 Ud. seguro de registrar una Nota de Cr\xE9dito Contingencia?", accionBtnAceptarQ2_ );
	}, 
	
		
    validarFactura: function(id){		
	    var factura= dijit.byId(id).value;
		factura = factura.replace(/^0+/, '');
		dijit.byId(id).attr('value',factura);
		
	    dijit.hideTooltip(dojo.byId(id));
	    this.limpiaMontos();
	    if (factura=="") return;
		this.wait("Consultando", "110px", 200);
		var handler = dojo.xhrGet({
			url: this.controller + "?action=existeFactura&factura=" + factura ,
    		handleAs: "json",
    		preventCache:  true,
    		sync: true,
    		timeout: 10000
    	});
    	handler.addCallback(dojo.hitch(this, function(res){    		  	
			this.waitMessage.hide();
    		if(res.codeError == 0 ) {    				
				valor = dijit.byId("pantallaInicial.tipoNotaCredito").getValue();
                this.compararFacturas(id);
    		} else {
				dijit.byId(id).focus();
                this.iconTooltipMessage(id, "icon-ok-tooltip", res.messageError);
                return;
    		}
    	}));
    	handler.addErrback(function(res){
			this.waitMessage.hide();
    		mostrarMensaje("Ocurrio un error al validar la factura ingresada");
    	});	
	},
	
	//Antonio
	validateEstablecimiento: function(){
		var establecimiento = document.getElementById("establecimiento").value;
		var regexEstablecimiento=false;
		var digitoEstablecimiento="";
		var regex2 = /[0-9]|\./;
		for (i=0; i< establecimiento.length;i++){
		digitoEstablecimiento= establecimiento.charAt(i);
			if(!regex2.test(digitoEstablecimiento)) {//la serie debe ser numerica incluyendo 0
			regexEstablecimiento=true;
			}
      	 }
					if(establecimiento!==""){//el establecimiento debe ser diferente de vacio
						if(establecimiento.length<5){//el establecimiento debe ser de 4 digitos como maximo
							if(!regexEstablecimiento) {//el establecimiento debe ser de tipo numerico incluyendo 0

							}else{mostrarMensaje("El establecimiento debe ser num\xE9rico"); 
							document.getElementById("establecimiento").value="";
							document.getElementById("establecimiento").focus();
							}
						}else{mostrarMensaje("El establecimiento debe ser menor a 5 digitos"); 
						document.getElementById("establecimiento").value="";
						document.getElementById("establecimiento").focus();
						}
					}

	},	
	
	//Antonio
	validateSerie: function(){
		var serie1 = document.getElementById("serie").value;
		var numero1 = document.getElementById("numero").value;
		var regexSerie1=false;
		var regexNumero1=false;
		var digitoSerie1="";
		var digitoNumero1="";
		var regex1 = /[0-9]|\./;
		for (i=0; i< serie1.length;i++){
		digitoSerie1= serie1.charAt(i);
			if(!regex1.test(digitoSerie1)) {//la serie debe ser numerica incluyendo 0
			regexSerie1=true;
			}
      	 }
		
		for (i=0; i< numero1.length;i++){
		digitoNumero1= numero1.charAt(i);
			if(!regex1.test(digitoNumero1)) {//el numero debe ser de tipo numerico incluyendo 0
			regexNumero1=true;
			}
      	 }

					if(serie1!==""){//la serie debe ser diferente de vacio
						if(serie1.length==4){//el numero debe ser de 9 digitos como maximo
							if(!regexSerie1) {//el numero debe ser de tipo numerico incluyendo 0
							document.getElementById("numero").value="";
							document.getElementById("numero").focus();
							}else{mostrarMensaje("La serie debe ser numerica"); 
							document.getElementById("serie").value="";
							document.getElementById("numero").value="";
							document.getElementById("serie").focus();}
						}else{mostrarMensaje("la serie debe tener 4 caracteres"); 
						document.getElementById("serie").value="";
						document.getElementById("numero").value="";
						document.getElementById("serie").focus();}
					}

	},	
	
	//Antonio
	validateSerieId: function(){
		var serie2 = document.getElementById("idSerie").value;
		var regexSerie2=false;
		var digitoSerie2="";
		var regex2 = /(?=.*\b[eE]001\b)[eE]001|(?=.*\b[fF][A-Za-z0-9]{3}\b)[fF][A-Za-z0-9]{3}|(?=.*\b[0-9]{4}\b)[0-9]{3}/;
		//for (i=0; i< serie2.length;i++){
		//digitoSerie2= serie2.charAt(i);
			//if(!regex2.test(digitoSerie2)) {//la serie debe ser numerica incluyendo 0
			//regexSerie2=true;
			//}
      	 //}
      	 if(!regex2.test(serie2)) {//la serie debe ser numerica incluyendo 0
			regexSerie2=true;
			}
		
					if(serie2!==""){//la serie debe ser diferente de vacio
						if(serie2.length==4){//el numero debe ser de 9 digitos como maximo
							if(!regexSerie2) {//el numero debe ser de tipo numerico incluyendo 0
							}else{mostrarMensaje("La serie debe ser numerica o con el siguiente formato E001 o FXXX"); //mostrarMensaje("La serie debe ser numerica")
							document.getElementById("idSerie").value="";
							document.getElementById("idSerie").focus();}
						}else{mostrarMensaje("la serie debe tener 4 caracteres"); 
						document.getElementById("idSerie").value="";
						document.getElementById("idSerie").focus();}
					}

	},	
	

	
	//Antonio
	validateNumero: function(){		
		var serie = document.getElementById("serie").value;
		var numero = document.getElementById("numero").value;
		var establecimiento = document.getElementById("establecimiento").value;
		var fechaEmision = document.getElementById("fechaEmision").value;

		if(fechaEmision!==""){

		if(establecimiento!==""){
			
		var regexSerie=false;
		var regexNumero=false;
		var digitoSerie="";
		var digitoNumero="";
		var regex = /[0-9]|\./;
		for (i=0; i< serie.length;i++){
		digitoSerie= serie.charAt(i);
			if(!regex.test(digitoSerie)) {//la serie debe ser numerica incluyendo 0
			regexSerie=true;
			}
      	 }
		for (i=0; i< numero.length;i++){
		digitoNumero= numero.charAt(i);
			if(!regex.test(digitoNumero)) {//el numero debe ser de tipo numerico incluyendo 0
			regexNumero=true;
			}
      	 }
		 if(numero!==""){//la serie debe ser diferente de vacio
			if(numero.length<=9){//el numero debe ser de 9 digitos como maximo
				if(!regexNumero) {//el numero debe ser de tipo numerico incluyendo 0
					if(serie!==""){//la serie debe ser diferente de vacio
						if(serie.length<=4){//el numero debe ser de 9 digitos como maximo
							if(!regexSerie) {//el numero debe ser de tipo numerico incluyendo 0
								var handler = dojo.xhrGet({
									preventCache:  false,
									url: this.controller + "?action=validadComprobante&serie=" + serie + "&numero=" + numero+"&establecimiento="+establecimiento+"&fechaEmision="+fechaEmision,
									handleAs: "json",
									sync: true,
									timeout: 10000
								});
								handler.addCallback(dojo.hitch(this, function(response){
									this.waitMessage.hide();
										if(response.codeError==1){
											
										}else if(response.codeError==7){
											mostrarMensaje(""+response.data);
										}else {
										mostrarMensaje(""+response.data);
										document.getElementById("numero").value="";
										document.getElementById("numero").focus();
										}	
								}));
								handler.addErrback(function(response){
									this.waitMessage.hide();
									mostrarMensaje("Ocurrio un error al validar datos del comprobante");
								});
							}else{mostrarMensaje("La serie debe ser numerica"); 
							document.getElementById("serie").value="";
							document.getElementById("numero").value="";
							document.getElementById("serie").focus();}
						}else{mostrarMensaje("la serie debe tener 4 caracteres"); 
						document.getElementById("serie").value="";
						document.getElementById("numero").value="";
						document.getElementById("serie").focus();}
					}else{mostrarMensaje("ingrese la serie"); 
					document.getElementById("serie").value="";
					 document.getElementById("numero").value="";
					 document.getElementById("serie").focus();}
				}else{ mostrarMensaje("El n\xFAmero debe ser de tipo numerico"); 
				document.getElementById("numero").value="";
				document.getElementById("numero").focus();}
			}else{	mostrarMensaje("El n\xFAmero maximo de caracteres es de 9 digitos");
			document.getElementById("numero").value="";
			document.getElementById("numero").focus();}
		 }
		}else{
			mostrarMensaje("Seleccione el establecimiento");
			document.getElementById("numero").value="";
		}
		}else{
			mostrarMensaje("Seleccione la fecha de emisi\xf3n");
			document.getElementById("numero").value="";
		}
	},	
	
	validarFacturaContin: function(id){
		//var serie= dijit.byId(id).value;		
		var idSerie = document.getElementById("idSerie").value;
		var idSerieNew = document.getElementById("idSerieNew").value;
		var numeroFactura= dijit.byId("pantallaInicial.numeroFE").value;
		var facturaNew= dijit.byId("pantallaInicial.numeroNuevaFE").value;
		
		//if (idSerie=="") return;
		
	    var factura= dijit.byId(id).value;
		factura = factura.replace(/^0+/, '');
		dijit.byId(id).attr('value',factura);
		
	    dijit.hideTooltip(dojo.byId(id));
	    this.limpiaMontos();
	    if (factura=="") return;
		this.wait("Consultando", "110px", 200);
		var handler = dojo.xhrGet({
			url: this.controller + "?action=existeFacturaContin&factura="+numeroFactura+"&serie="+idSerie,
    		handleAs: "json",
    		preventCache:  true,
    		sync: true,
    		timeout: 10000
			
    	});
    	handler.addCallback(dojo.hitch(this, function(res){    		  	
			this.waitMessage.hide();
    		if(res.codeError == 0 ) {    				
				valor = dijit.byId("pantallaInicial.tipoNotaCredito").getValue();
                this.compararFacturasContin(idSerie,idSerieNew,numeroFactura,facturaNew);
    		} else {
				dijit.byId(id).focus();
                this.iconTooltipMessage(id, "icon-ok-tooltip", res.messageError);
                return;
    		}
    	}));
    	handler.addErrback(function(res){
			this.waitMessage.hide();
    		mostrarMensaje("Ocurrio un error al validar la factura ingresada");
    	});	
	},
	
	validarFacturaContinNew: function(id){
		mostrarMensaje("validarFacturaContinNew");
		var idSerie = document.getElementById("idSerie").value;
		var idSerieNew = document.getElementById("idSerieNew").value;
		var numeroFactura= dijit.byId("pantallaInicial.numeroFE").value;
		var facturaNew= dijit.byId("pantallaInicial.numeroNuevaFE").value;
		
	    var factura= dijit.byId(id).value;
		factura = factura.replace(/^0+/, '');
		dijit.byId(id).attr('value',factura);
	    dijit.hideTooltip(dojo.byId(id));
	    this.limpiaMontos();
	    if (factura=="") return;
		this.wait("Consultando", "110px", 200);
		var handler = dojo.xhrGet({
			url: this.controller + "?action=existeFacturaContin&factura=" + facturaNew+"&serie="+idSerieNew,
    		handleAs: "json",
    		preventCache:  true,
    		sync: true,
    		timeout: 10000
			
    	});
    	handler.addCallback(dojo.hitch(this, function(res){    		  	
			this.waitMessage.hide();
    		if(res.codeError == 0 ) {    				
				valor = dijit.byId("pantallaInicial.tipoNotaCredito").getValue();
                this.compararFacturasContin(idSerie,idSerieNew,numeroFactura,facturaNew);
    		} else {
				dijit.byId(id).focus();
                this.iconTooltipMessage(id, "icon-ok-tooltip", res.messageError);
                return;
    		}
    	}));
    	handler.addErrback(function(res){
			this.waitMessage.hide();
    		mostrarMensaje("Ocurrio un error al validar la factura ingresada");
    	});	
	},
		
	compararFacturas: function(id){
		dijit.hideTooltip(dojo.byId("pantallaInicial.numeroFE"));
		dijit.hideTooltip(dojo.byId("pantallaInicial.numeroNuevaFE"));
		var factura= null;
		var factura2= null;
		this.facturaBean=null;
		factura= dijit.byId("pantallaInicial.numeroFE").value;
		factura2= dijit.byId("pantallaInicial.numeroNuevaFE").value;
		if ( factura!= ""){
			this.limpiaMontos();
      		this.wait("Consultando", "110px", 200);
    		var handler = dojo.xhrGet({
				url: this.controller + "?action=validarComprobante&TipoNotaCred=" + dijit.byId("pantallaInicial.tipoNotaCredito").value + "&factura=" + factura  + "&facturanew=" + factura2
    			// INI PAS20211U210100040  AHUISA
          + "&fecEmision=" + dojo.byId("pantallaInicial.fechaEmision").value,
          // FIN PAS20211U210100040  AHUISA
          handleAs: "json",
    			preventCache:  true,
    			sync: true,
    			timeout: 10000
    		});
    		handler.addCallback(dojo.hitch(this, function(res){
				dijit.hideTooltip(dojo.byId("pantallaInicial.numeroFE"));
				this.waitMessage.hide();
				if(res.codeError == 0 || res.codeError == 9) {
					this.facturaBean = eval("(" + res.data + ")");//whr  
					this.igvFE = this.facturaBean.igvPorcentaje;
					//PAS20175E210300011; corregido con el pase PAS20175E210300023
					if (this.igvFE < 1){
						this.igvFE = this.igvFE * 100;
					}

					this.formateaMontos();
					if (dijit.byId("pantallaInicial.tipoNotaCredito").value != "22") {
						dijit.byId("pantallaInicial.motivoEmisionNC").focus();
					}else{ dijit.byId("pantallaInicial.numeroNuevaFE").focus(); }	     		 	   
				} else {
					if(res.codeError == 1){
						this.iconTooltipMessage("pantallaInicial.numeroFE", "icon-ok-tooltip", res.messageError);
					}else{
					   this.iconTooltipMessage("pantallaInicial.numeroNuevaFE", "icon-ok-tooltip", res.messageError);
					}
			 
					return;
				}
    		}));
    		
			handler.addErrback(function(res){
				this.waitMessage.hide();
    			mostrarMensaje("Ocurrio un error al validar la factura ingresada");
    		});
    			
    		if (dijit.byId("pantallaInicial.tipoNotaCredito").value =="22"){
      		 	if ( factura2!= ""){
					this.wait("Consultando", "110px", 200);
          			var handler2 = dojo.xhrGet({
          				preventCache:  false,
          				url: this.controller + "?action=comparaFacturas&TipoNotaCred=" + dijit.byId("pantallaInicial.tipoNotaCredito").value + "&factura=" + factura + "&facturanew=" + factura2,
          				handleAs: "json",
          				sync: true,
          				timeout: 10000
          			});
          			handler2.addCallback(dojo.hitch(this, function(res){
          				this.waitMessage.hide();
          				dijit.hideTooltip(dojo.byId("pantallaInicial.numeroNuevaFE"));
          				if(res.codeError == 0) {
          					
						} else {
							dijit.byId("pantallaInicial.numeroNuevaFE").focus();
							this.iconTooltipMessage("pantallaInicial.numeroNuevaFE", "icon-ok-tooltip", res.messageError);
							return;
						}
          			}));
          			handler2.addErrback(function(res){
          				this.waitMessage.hide();
          				mostrarMensaje("Ocurrio un error al validar la factura ingresada");
          			});
      		 	}
			}
		}
	},
	
	compararFacturasContin: function(idSerie,idSerieNew,numeroFactura,facturaNew){
		this.facturaBean=null;
		if ( numeroFactura!= ""){
			this.limpiaMontos();
      		this.wait("Consultando", "110px", 200);
    		var handler = dojo.xhrGet({
				url: this.controller + "?action=validarComprobanteContin&TipoNotaCred=" + dijit.byId("pantallaInicial.tipoNotaCredito").value + "&factura=" + numeroFactura  + "&facturanew=" + facturaNew+"&idSerie="+idSerie+"&idSerieNew="+idSerieNew,
    			handleAs: "json",
    			preventCache:  true,
    			sync: true,
    			timeout: 10000
    		});
    		handler.addCallback(dojo.hitch(this, function(res){
				dijit.hideTooltip(dojo.byId("pantallaInicial.numeroFE"));
				this.waitMessage.hide();
				if(res.codeError == 0 || res.codeError == 9) {
					this.facturaBean = eval("(" + res.data + ")");//whr  
					this.igvFE = this.facturaBean.igvPorcentaje;
					//PAS20175E210300011; corregido con el pase PAS20175E210300023
					if (this.igvFE < 1){
						this.igvFE = this.igvFE * 100;
					}

					this.formateaMontos();
					if (dijit.byId("pantallaInicial.tipoNotaCredito").value != "22") {
						dijit.byId("pantallaInicial.motivoEmisionNC").focus();
					}else{ dijit.byId("pantallaInicial.numeroNuevaFE").focus(); }	     		 	   
				} else {
					if(res.codeError == 1){
						this.iconTooltipMessage("pantallaInicial.numeroFE", "icon-ok-tooltip", res.messageError);
					}else{
					   this.iconTooltipMessage("pantallaInicial.numeroNuevaFE", "icon-ok-tooltip", res.messageError);
					}
			 
					return;
				}
    		}));
    		
			handler.addErrback(function(res){
				this.waitMessage.hide();
    			mostrarMensaje("Ocurrio un error al validar la factura ingresada");
    		});
    			
    		if (dijit.byId("pantallaInicial.tipoNotaCredito").value =="22"){
      		 	if ( facturaNew!= ""){
					this.wait("Consultando", "110px", 200);
          			var handler2 = dojo.xhrGet({
          				preventCache:  false,
          				url: this.controller + "?action=comparaFacturasContin&TipoNotaCred=" + dijit.byId("pantallaInicial.tipoNotaCredito").value + "&factura=" + numeroFactura  + "&facturanew=" + facturaNew+"&idSerie="+idSerie+"&idSerieNew="+idSerieNew,
          				handleAs: "json",
          				sync: true,
          				timeout: 10000
          			});
          			handler2.addCallback(dojo.hitch(this, function(res){
          				this.waitMessage.hide();
          				dijit.hideTooltip(dojo.byId("pantallaInicial.numeroNuevaFE"));
          				if(res.codeError == 0) {
          					
						} else {
							dijit.byId("pantallaInicial.numeroNuevaFE").focus();
							this.iconTooltipMessage("pantallaInicial.numeroNuevaFE", "icon-ok-tooltip", res.messageError);
							return;
						}
          			}));
          			handler2.addErrback(function(res){
          				this.waitMessage.hide();
          				mostrarMensaje("Ocurrio un error al validar la factura ingresada");
          			});
      		 	}
			}
		}
	},
	
	
	
			validarFacturaNew: function(){
			
      //var factura= dijit.byId("pantallaInicial.numeroNuevaFE").value;
      //var factura2= dijit.byId("pantallaInicial.numeroFE").value;
      if ( factura!= ""){
      
      		this.wait("Consultando", "110px", 200);
    			var handler = dojo.xhrGet({
    				preventCache:  false,
    				url: this.controller + "?action=validarComprobante&TipoNotaCred=" + dijit.byId("pantallaInicial.tipoNotaCredito").value + "&factura=" + factura2 + "&facturanew=" + factura,
    				handleAs: "json",
    				sync: true,
    				timeout: 10000
    			});
    		  this.waitMessage.hide();
    			handler.addCallback(dojo.hitch(this, function(res){

    				dijit.hideTooltip(dojo.byId("pantallaInicial.numeroNuevaFE"));
    				if(res.codeError == 0) {
    				
    			
    				} else {
                this.iconTooltipMessage("pantallaInicial.numeroNuevaFE", "icon-ok-tooltip", "Factura electr\u00F3nica no ha sido emitida por el contribuyente.");
                return;
    				}
    			}));
    			handler.addErrback(function(res){
    				mostrarMensaje("Ocurrio un error al validar la factura ingresada.");
    			});
    			
    			 
    			 if (dijit.byId("pantallaInicial.tipoNotaCredito").value =="22"){
      		 	if ( factura2!= ""){
      		 	     	this.wait("Consultando", "110px", 200);
          			var handler2 = dojo.xhrGet({
          				preventCache:  false,
          				url: this.controller + "?action=comparaFacturas&TipoNotaCred=" + dijit.byId("pantallaInicial.tipoNotaCredito").value + "&factura=" + factura2 + "&facturanew=" + factura,
          				handleAs: "json",
          				sync: true,
          				timeout: 10000
          			});
          			this.waitMessage.hide();
          			handler2.addCallback(dojo.hitch(this, function(res1){
          				dijit.hideTooltip(dojo.byId("pantallaInicial.numeroNuevaFE"));
          				if(res1.codeError == 0) {

          					this.formateaMontos();
          				} else {
                      this.iconTooltipMessage("pantallaInicial.numeroNuevaFE", "icon-ok-tooltip", res1.messageError);
                      return;
          				}
          			}));
          			handler2.addErrback(function(res1){

          				mostrarMensaje("Ocurrio un error al validar la factura ingresada");
          			});
      		 	}
      		} 	 	
      }
  },
  
  validarFacturaNewContin: function(){
				
      var facturaNew= dijit.byId("pantallaInicial.numeroNuevaFE").value;
      var factura= dijit.byId("pantallaInicial.numeroFE").value;
	  var idSerieNew = document.getElementById("idSerieNew").value;
      if ( factura!= ""){
      
      		this.wait("Consultando", "110px", 200);
    			var handler = dojo.xhrGet({
    				preventCache:  false,
    				url: this.controller + "?action=validarComprobanteContinNew&TipoNotaCred=" + dijit.byId("pantallaInicial.tipoNotaCredito").value + "&facturaNew=" + facturaNew + "&idSerieNew=" + idSerieNew,
    				handleAs: "json",
    				sync: true,
    				timeout: 10000
    			});
    		  this.waitMessage.hide();
    			handler.addCallback(dojo.hitch(this, function(res){

    				dijit.hideTooltip(dojo.byId("pantallaInicial.numeroNuevaFE"));
    				if(res.codeError == 0) {
    				
    			
    				} else {
                this.iconTooltipMessage("pantallaInicial.numeroNuevaFE", "icon-ok-tooltip", "Factura electr\u00F3nica no ha sido emitida por el contribuyente.");
                return;
    				}
    			}));
    			handler.addErrback(function(res){
    				mostrarMensaje("Ocurrio un error al validar la factura ingresada.");
    			});
    			
    			 
    			 if (dijit.byId("pantallaInicial.tipoNotaCredito").value =="22"){
      		 	if ( factura2!= ""){
      		 	     	this.wait("Consultando", "110px", 200);
          			var handler2 = dojo.xhrGet({
          				preventCache:  false,
          				url: this.controller + "?action=comparaFacturas&TipoNotaCred=" + dijit.byId("pantallaInicial.tipoNotaCredito").value + "&facturaNew=" + facturaNew + "&idSerieNew=" + idSerieNew,
          				handleAs: "json",
          				sync: true,
          				timeout: 10000
          			});
          			this.waitMessage.hide();
          			handler2.addCallback(dojo.hitch(this, function(res1){
          				dijit.hideTooltip(dojo.byId("pantallaInicial.numeroNuevaFE"));
          				if(res1.codeError == 0) {

          					this.formateaMontos();
          				} else {
                      this.iconTooltipMessage("pantallaInicial.numeroNuevaFE", "icon-ok-tooltip", res1.messageError);
                      return;
          				}
          			}));
          			handler2.addErrback(function(res1){

          				mostrarMensaje("Ocurrio un error al validar la factura ingresada");
          			});
      		 	}
      		} 	
       		 	
      }
  },
  
  
  	/*
	iconTooltipMessage: function(node, iconClass, message) {
		if(dojo.isString(node)) node = dojo.byId(node);
		dijit.focus(node);
		node.focus();
		dijit.showTooltip('<div class="' + iconClass + '"><div>' + message + '</div></div>', node, []);
		//		node._refreshState();
		var blur = dojo.connect(node, "onBlur", function() {
			dijit.hideTooltip(node);
			node._refreshState();
			dojo.disconnect(blur);
		});
	},   
	*/
	
	iconTooltipMessage: function(node, iconClass, message) {
		if(dojo.isString(node)) node = dojo.byId(node);
		dijit.focus(node);
		node.focus();
		dijit.showTooltip('<div class="' + iconClass + '"><div>' + message + '</div></div>', node, []);
        var blur = dojo.connect(node, "onBlur", function() {
			dijit.hideTooltip(node);
			dojo.disconnect(blur);
		});
	},
    // INI PAS20211U210100040  AHUISA
    iconTooltipMessageFec: function(node, iconClass, message) {
        if(dojo.isString(node)) node = dojo.byId(node);
        dijit.focus(node);
        node.focus();
        dijit.showTooltip('<div class="' + iconClass + '"><div>' + message + '</div></div>', node, []);
        var blur = dojo.connect(node, "onblur", function() {
            dijit.hideTooltip(node);
            dojo.disconnect(blur);
        });
    },
    // FIN PAS20211U210100040  AHUISA

	iconTooltipMessageV2: function(node, iconClass, message) {
		require(["dijit/Tooltip", "dojo/dom", "dojo/on", "dijit/focus", "dojo/domReady!"], function(Tooltip, dom, on, focusUtil) {
			on(node, 'focus', function() {
				  Tooltip.show(message, node);
			});
			dojo.connect(dojo.byId(node), "blur", function() {
				  Tooltip.hide(node);
			});
		  })	 
		  node.focus();
		  //ESTE METODO DE ABAJO REVISA SI SE REALIZA ALGUN FOCUS O BLUR A CUALQUIER WIDGET
  /* 			require([ "dijit/focus" ], function(focusUtil){
			focusUtil.on("widget-focus", function(widget){
			  console.log("Focused widget", widget);
			});
			focusUtil.on("widget-blur", function(widget){
			  console.log("Blurred widget", widget);
			});
		  }); */
		  
	  },
	
		sendDocument: function() {
	
  	   if(!dijit.byId("generada.form").validate()){
  	      mostrarMensaje("Debe registrar una direccion de correo v\u00E1lida.");
          return;
       } 
  		if (dojo.trim(dijit.byId("generada.correoUser").getValue()) == "" ) {
  			mostrarMensaje("Por favor ingrese una direccion de correo.");
  			return;
  		}
		
			this.wait("Enviando", "110px", 100);
			var handler = dojo.xhrGet({
				preventCache:  false,
				url: this.controller + "?action=enviarCorreo&correoUser=" + dojo.trim(dijit.byId("generada.correoUser").getValue()),
				handleAs: "json",
				sync: true,
				timeout: 10000
			});
			handler.addCallback(dojo.hitch(this, function(response){
				this.waitMessage.hide();
				if(response.codeError == 0) {
					mostrarMensaje("Se envio correo a la siguiente direccion: " + dijit.byId("generada.correoUser").getValue());
					dijit.byId("generada.correoUser").focus();
				}
				else {
					this.messageBox(res.messageError);
				}
			}));
			handler.addErrback(function(response){
				this.waitMessage.hide();
				this.messageBox("Problemas al conectarse con el servidor");
			});
	},
	
	
	sendDocumentContin: function() {
  	   if(!dijit.byId("generada.form").validate()){
  	      mostrarMensaje("Debe registrar una direcci\xf3n de correo v\u00E1lida.");
          return;
       } 
  		if (dojo.trim(dijit.byId("generada.correoUser").getValue()) == "" ) {
  			mostrarMensaje("Por favor ingrese una direcci\xf3n de correo.");
  			return;
  		}
			this.wait("Enviando", "110px", 100);
			var handler = dojo.xhrGet({
				preventCache:  false,
				url: this.controller + "?action=enviarCorreoContin&correoUser=" + dojo.trim(dijit.byId("generada.correoUser").getValue()),
				handleAs: "json",
				sync: true,
				timeout: 10000
			});
			handler.addCallback(dojo.hitch(this, function(response){
				this.waitMessage.hide();
				if(response.codeError == 0) {
					mostrarMensaje("Se envio correo a la siguiente direcci\xf3n: " + dijit.byId("generada.correoUser").getValue());
					dijit.byId("generada.correoUser").focus();
				}
				else {
					this.messageBox(res.messageError);
				}
			}));
			handler.addErrback(function(response){
				this.waitMessage.hide();
				this.messageBox("Problemas al conectarse con el servidor");
			});
	},

	
	

	updateAmount: function() {	
		if (this.facturaBean==null) return;
		//var moneda = this.facturaBean.codigoMoneda;
		var moneda = this.changeMoneda(this.facturaBean.codigoMoneda);
		dijit.byId("pantallaInicial.descuentoGlobalNC").constraints = {min:0,currency:moneda, places:2};
		dijit.byId("pantallaInicial.ISCNC").constraints = {min:0,currency:moneda, places:2};
		dijit.byId("pantallaInicial.IGVNC").constraints = {min:0,currency:moneda, places:2};
		dijit.byId("pantallaInicial.descuentoGlobalNC").constraints = {min:0,currency:moneda, places:2};
		
		var montoISC = this.facturaBean.totalISC;
        if(montoISC == "" || montoISC=="0.00"){
			dijit.byId("pantallaInicial.ISCNC").attr('disabled', true);
    		dijit.byId("pantallaInicial.ISCNC").attr('value',"");	
    		dijit.byId("pantallaInicial.ISCNC").attr('style',"background-color:lightgray");	
            txtISC=0;
		}else{
			dijit.byId("pantallaInicial.ISCNC").attr('disabled', false);
			dijit.byId("pantallaInicial.ISCNC").attr('style',"background-color:white");	
			txtISC=dijit.byId("pantallaInicial.ISCNC").value;
        }
		
		var montoIGV = this.facturaBean.totalIGV;
        console.log("montoIGV=" ,montoIGV );////PAS20211U210100007-jmendozas
        if(montoIGV == "" || montoIGV=="0.00"){
			dijit.byId("pantallaInicial.IGVNC").attr('disabled', true);
    		dijit.byId("pantallaInicial.IGVNC").attr('value',"");		
    		dijit.byId("pantallaInicial.IGVNC").attr('style',"background-color:lightgray");
		}else{
			dijit.byId("pantallaInicial.IGVNC").attr('value',"0");	
			dijit.byId("pantallaInicial.IGVNC").attr('style',"background-color:white");
			txtDG =dijit.byId("pantallaInicial.descuentoGlobalNC").value;
			if (txtDG!="" && txtDG!=0 && txtDG!="0.00"){
				console.log("txtDG=" ,txtDG );////PAS20211U210100007-jmendozas
				console.log("txtISC=" ,txtISC );//PAS20211U210100007-jmendozas
				console.log("igvFE=" ,(this.igvFE/100) );//PAS20211U210100007-jmendozas
				var sumaNumDescuentos = txtDG + txtISC;//PAS20211U210100007-jmendozas
				var divIgvDescuento = this.igvFE/100;//PAS20211U210100007-jmendozas
				var igv_real = this.round(sumaNumDescuentos * divIgvDescuento,2);//PAS20211U210100007-jmendozas
				console.log("descuento real = " , igv_real);//PAS20211U210100007-jmendozas
				//dijit.byId("pantallaInicial.IGVNC").attr('value',(txtDG + txtISC)*(this.igvFE / 100 ) ); //IGV 19//PAS20211U210100007-jmendozas
				dijit.byId("pantallaInicial.IGVNC").attr('value',igv_real ); //IGV 19//PAS20211U210100007-jmendozas
            }else{
				dijit.byId("pantallaInicial.IGVNC").attr('value',"0");
            }
            dijit.byId("pantallaInicial.IGVNC").attr('disabled', true);
        }
		console.log("montoIGV=" ,montoIGV )//PAS20211U210100007-jmendozas
	},
		
	limpiaMontos: function() {
       dijit.byId("pantallaInicial.descuentoGlobalNC").attr('value',"");
       dijit.byId("pantallaInicial.ISCNC").attr('disabled', true);
	   dijit.byId("pantallaInicial.ISCNC").attr('value',"");
	   dijit.byId("pantallaInicial.ISCNC").attr('style',"background-color:lightgray");
       dijit.byId("pantallaInicial.IGVNC").attr('disabled', true);
	   dijit.byId("pantallaInicial.IGVNC").attr('value',"");
	   dijit.byId("pantallaInicial.IGVNC").attr('style',"background-color:lightgray");
    },
    
	formateaMontos: function() {
	 var txtDG =dijit.byId("pantallaInicial.descuentoGlobalNC").value;
	 var txtISC=0;
	 var txtIGV=0;
	 
	     if (this.facturaBean.codigoMoneda == null){
           	dijit.byId("pantallaInicial.ISCNC").attr('disabled', true);
	          dijit.byId("pantallaInicial.ISCNC").attr('value',"");	
	          dijit.byId("pantallaInicial.ISCNC").attr('style',"background-color:lightgray");
            dijit.byId("pantallaInicial.IGVNC").attr('disabled', true);
	          dijit.byId("pantallaInicial.IGVNC").attr('value',"");		
	          dijit.byId("pantallaInicial.IGVNC").attr('style',"background-color:lightgray");	
	          return;
       }
	 
      		 	   //var moneda = this.facturaBean.codigoMoneda;
      		 	   var moneda = this.changeMoneda(this.facturaBean.codigoMoneda);
        		 	  dijit.byId("pantallaInicial.descuentoGlobalNC").constraints = {min:0,currency:moneda, places:2};
            		dijit.byId("pantallaInicial.ISCNC").constraints = {min:0,currency:moneda, places:2};
            		dijit.byId("pantallaInicial.IGVNC").constraints = {min:0,currency:moneda, places:2};
            		dijit.byId("pantallaInicial.descuentoGlobalNC").constraints = {min:0,currency:moneda, places:2};
            		var montoISC = this.facturaBean.totalISC;
            		if(montoISC == "" || montoISC=="0.00"){
                		dijit.byId("pantallaInicial.ISCNC").attr('disabled', true);
    			          dijit.byId("pantallaInicial.ISCNC").attr('value',"");	
    			          dijit.byId("pantallaInicial.ISCNC").attr('style',"background-color:lightgray");	
                    txtISC=0;
			          }else{
			              dijit.byId("pantallaInicial.ISCNC").attr('disabled', false);
			              dijit.byId("pantallaInicial.ISCNC").attr('style',"background-color:white");	
			              txtISC=dijit.byId("pantallaInicial.ISCNC").value;
                }
            		
            		
            		var montoIGV = this.facturaBean.totalIGV;
					console.log("montoIGV2=",montoIGV);//PAS20211U210100007-jmendozas
            		if(montoIGV == "" || montoIGV=="0.00"){
            		    dijit.byId("pantallaInicial.IGVNC").attr('disabled', true);
    			          dijit.byId("pantallaInicial.IGVNC").attr('value',"");		
    			          dijit.byId("pantallaInicial.IGVNC").attr('style',"background-color:lightgray");
			          }else{
			              dijit.byId("pantallaInicial.IGVNC").attr('value',"0");	
			              dijit.byId("pantallaInicial.IGVNC").attr('style',"background-color:white");
			              txtDG =dijit.byId("pantallaInicial.descuentoGlobalNC").value;
			              if (txtDG!="" && txtDG!=0 && txtDG!="0.00"){
							  console.log("txtDG=" ,txtDG );//PAS20211U210100007-jmendozas
							  console.log("txtISC=" ,txtISC );//PAS20211U210100007-jmendozas
							  console.log("igvFE=" ,(this.igvFE/100) );//PAS20211U210100007-jmendozas
							  var sumaNumDescuentos = txtDG + txtISC;//PAS20211U210100007-jmendozas
							  var divIgvDescuento = this.igvFE/100;//PAS20211U210100007-jmendozas
							  var igv_real = this.round(sumaNumDescuentos * divIgvDescuento,2);//PAS20211U210100007-jmendozas
							  console.log("descuento real = " , igv_real);//PAS20211U210100007-jmendozas
							  console.log("montoIGV2=" ,(txtDG + txtISC)*(this.igvFE / 100 ) );//PAS20211U210100007-jmendozas
			                 //dijit.byId("pantallaInicial.IGVNC").attr('value',(txtDG + txtISC)*(this.igvFE / 100 ) ); //IGV 19 //PAS20211U210100007-jmendozas
							  dijit.byId("pantallaInicial.IGVNC").attr('value',igv_real);//PAS20211U210100007-jmendozas
						  }else{
                        dijit.byId("pantallaInicial.IGVNC").attr('value',"0");
                    }
                    dijit.byId("pantallaInicial.IGVNC").attr('disabled', true);
                }
				console.log("montoIGV2=",montoIGV);//PAS20211U210100007-jmendozas

                		
	},	
  	
  downloadDocument: function() {
		var formArchivo = dojo.byId("formArchivo");
		formArchivo.submit();
	},
	// PAS20211U210100010 -- Inicio
	downloadNCFEDocuPdf: function() {
		var formPDF = dojo.byId("formDescargaNCPdf");
		formPDF.submit();
	},
	// PAS20211U210100010 -- Fin
	
	printDocument: function() {
		window.open(this.controller + "?action=imprimirComprobante&preventCache=" + this.preventCache(), "imprimeCP" , "toolbar=0,location=0,directories=0,status=no,menubar=0,scrollbars=yes,resizable=yes,width=820,height=580,titlebar=no");
	},
	
	closeDocumentInicial: function() {
      dijit.hideTooltip(dojo.byId("pantallaInicial.numeroFE"));
      dijit.hideTooltip(dojo.byId("pantallaInicial.numeroNuevaFE"));
		//if (confirm("Desea salir del aplicativo?")) {
		mostrarMensajeConfirmacion("\u00BFDesea salir del aplicativo?", dojo.hitch(this, function(){
			this.closeDocument();
		}));
	},

    wait: function(message, width) {
		dojo.byId("waitMessage").innerHTML="<div class='dijitInline box-message'></div><div class='dijitInline'>&nbsp;" + message + "...</div>";
	    dojo.byId("waitMessage").style.width = width;
	    this.waitMessage.show();
	},      
		
	onFocus: function(id){
    var dato = dojo.byId(id).value;
    
    dijit.byId(id).attr('value',"");	
    
    dijit.byId(id).attr('value',dojo.trim(dato));	
  },
  
	backInicio: function() {
			
			dijit.hideTooltip(dojo.byId("numeroComprobante"));
			//this.content.onLoad = dojo.hitch(this, function(){
			//	this.initContent();
			//});
			//INI: PAS20201U210100188  Limpieza de variables de los Items Comprobantes.
				jsonStoreItemsNCFE.save();
				jsonStoreItemsNCFE.close();
				store=null;
				var grid = dijit.byId('ncCambioDetalles.ingreso-grid');
				if(grid!=undefined){
					grid.setStore(store);
					grid.update();		
				}		
			//FIN: PAS20201U210100188 
			this.content.setHref(this.controller + "?action=mostrarPantallaInicialConDatos&mode=hidden");
  		this.content.onLoad = dojo.hitch(this, function(){			
  		this.showOpcionesPorTipoNCFE();
			this.formateaMontos();});
	  },
	
	
	backInicioContin: function() {
		dijit.hideTooltip(dojo.byId("numeroComprobante"));
			//this.content.onLoad = dojo.hitch(this, function(){
			//	this.initContent();
			//});
		this.content.setHref(this.controller + "?action=mostrarPantallaInicialConDatos&mode=hidden");
  		this.content.onLoad = dojo.hitch(this, function(){
  		this.showOpcionesPorTipoNCFEContin();
		this.formateaMontos();});		
	  },
	
   
		iconEdit25: function(rowindex) {
		return "<a href=\"#\" title=\"Editar\" onclick=\"notaCreditoFE.editItem25(" + rowindex + ")\"><img class=\"icon-by-edit16\" src=\"/a/imagenes/see/icons/edit.gif\"/></a>"; 
	   },
	  
    	
		iconEdit26: function(rowindex) {

      var grilla =dijit.byId('ncCambioDetalles.ingreso-grid');
      var datos =grilla.store._arrayOfAllItems;

        var fila = grilla.getItem(rowindex-1);
        var valorModif= grilla.store.getValue(fila, "valorVtaUnitarioOriginal");
        valorModif = valorModif.replace(',','');
        if (valorModif< 0){ 
            return "";
        }else{
           return "<a href=\"#\" title=\"Editar\" onclick=\"notaCreditoFE.editItem26(" + rowindex + ")\"><img class=\"icon-by-edit16\" src=\"/a/imagenes/see/icons/edit.gif\"/></a>";
        }
     
     
	   },
     	
		iconEdit27: function(rowindex) {
		
    
      var grilla =dijit.byId('ncCambioDetalles.ingreso-grid');
      var datos =grilla.store._arrayOfAllItems;

        var fila = grilla.getItem(rowindex-1);
        var valorModif= grilla.store.getValue(fila, "valorVtaUnitarioOriginal");
        valorModif = valorModif.replace(',','');
        if (valorModif< 0){ 
            return "";
        }else{
           return "<a href=\"#\" title=\"Editar\" onclick=\"notaCreditoFE.editItem27(" + rowindex + ")\"><img class=\"icon-by-edit16\" src=\"/a/imagenes/see/icons/edit.gif\"/></a>";
        }
          
	   },
      
	//Descuento por Item
    editItem27: function(identificador) {
		
		store =dijit.byId('ncCambioDetalles.ingreso-grid').store;        
		store.fetchItemByIdentity({
			identity: identificador,
			onItem : function(item, request) {
				row = item;		
				currentLine = identificador 	;		
			},
			onError : function(item, request) {
				mostrarMensaje("Ocurrio un error al ubicar el documento");
				return;				
			}
		});
		
		var descripcionItem=dojo.trim(store.getValue(row, "descripcion"));
		/*var buscar="[*****] BONIFICACION [*****]";
		if (descripcionItem.search(buscar)!=-1 ){
			mostrarMensaje("No se puede editar un item de bonificaci\u00F3n.");
			return;		
		}*/
		
		bCargando= true;
		var otrosCargosTributos=dojo.trim(store.getValue(row, "otrosCargosTributosOriginal"));
		if (otrosCargosTributos != "" && otrosCargosTributos !=null  && otrosCargosTributos !="0.00"){
			mostrarMensaje("No podr\u00E1 seleccionarse un \u00EDtem que es Cargo o Tributo.");
			return;	
        }
      
      	var operacionGratuita=dojo.trim(store.getValue(row, "tipoBonificacion"));
		if (operacionGratuita == "BO01" ){
			mostrarMensaje("No podr\u00E1 seleccionarse un \u00EDtem que es Gratuito");
		    return;	
		} 		    
		//var moneda = this.facturaBean.codigoMoneda;
		var moneda = this.changeMoneda(this.facturaBean.codigoMoneda);
		dijit.byId("item27.botonAceptar").attr('disabled', false);
						
		this.dialogItem27.attr('title', "Captura NC - Descuento por Item");
		dojo.byId("item27.idItem").value = currentLine ; //store.getValue(row, "identificador");
	  	dojo.byId("item27.precioUnitarioOriginal").value =store.getValue(row, "precioUnitarioOriginal");
	  	dojo.byId("item27.descuentosOriginal").value =store.getValue(row, "descuentosOriginal");
	  	dojo.byId("item27.precioUnitario").value =store.getValue(row, "precioUnitario");
		dijit.byId("item27.unidadMedida").setValue(store.getValue(row, "unidadMedidaDesc"));						
		dojo.byId("item27.iscMontoOriginal").value=store.getValue(row, "iscMontoOriginal");		
		

		//dijit.byId("item27.cantidad").setValue(store.getValue(row, "cantidad"), false);
		/*if(store.getValue(row, "esImpuestoBolsaPlastico") == "IBP00"){
			//this.showHiddenDiv(document.getElementById("item.ICBPER1.show"),true); 
			//this.showHiddenDiv(document.getElementById("item.ICBPER2.show"),true); 
			dijit.byId("item27.impuestoBolsasPlastica00").setChecked("checked");
			
			dijit.byId("item27.cantidad").constraints = {min:0,places:0};
			dijit.byId("item27.cantidad").attr('value',this.round(store.getValue(row, "cantidad"), 0));	
		}else{*/
			dijit.byId("item27.impuestoBolsasPlastica01").setChecked("checked");
			//this.showHiddenDiv(document.getElementById("item.ICBPER1.show"),false); 
			//this.showHiddenDiv(document.getElementById("item.ICBPER2.show"),false); 
			dijit.byId("item27.cantidad").constraints = {min:0.0000000001, places:'2,10',pattern:'########.00########'}
			//dijit.byId("item27.cantidad").attr('value',this.round(store.getValue(row, "cantidad"), 2), 0);
      dijit.byId("item27.cantidad").attr('value',store.getValue(row, "cantidad"), 0);//PAS20201U210100022	
		//}		
		
		//dijit.byId("item27.cantidad").attr('readOnly', false);
		dijit.byId("item27.descripcion").setValue(store.getValue(row, "descripcion"));
		dijit.byId("item27.igvPorcentaje").setValue(store.getValue(row, "igvPorcentaje"));
		
    //INI: PAS20191U210100075    
	console.log(row);
    var esImpuestoBolsaPlastico = store.getValue(row, "esImpuestoBolsaPlastico");

	dijit.byId("item27.impuestoBolsasPlastica00").setAttribute('disabled', true);
	dijit.byId("item27.impuestoBolsasPlastica01").setAttribute('disabled', true);
		
    if(esImpuestoBolsaPlastico != "IBP00"){
    
		this.showHiddenDiv(document.getElementById("item.ICBPER1.show"),false); 
		this.showHiddenDiv(document.getElementById("item.ICBPER2.show"),false); 	
        dijit.byId("item27.impuestoBolsasPlastica01").setChecked("checked"); 
    }else{
		dijit.byId("item27.impuestoBolsasPlastica00").setChecked("checked");
		this.showHiddenDiv(document.getElementById("item.ICBPER1.show"),false); 
		this.showHiddenDiv(document.getElementById("item.ICBPER2.show"),true); 

		dijit.byId("item27.impuestoICBPER").constraints = {min:0,currency:moneda, places:2};//PAS20191U210100075
		dijit.byId("item27.impuestoICBPER").attr('value',store.getValue(row, "icbPerMonto"));//PAS20191U210100075
      //dijit.byId("item27.impuestoICBPER").setValue(store.getValue(row, "icbPerMonto"));//PAS20191U210100075 
      
      //dojo.byId("item26.tasaBolsaGlobal").value =store.getValue(row, "icbTasa");//PAS20191U210100075      
    }
    //FIN: PAS20191U210100075	
    
		if (store.getValue(row, "modificado") =="0"){
			dijit.byId("item27.descuentos").constraints = {min:0,currency:moneda, places: '2,10'};
			//dijit.byId("item27.descuentos").attr('value',"0.0000000000");
			dijit.byId("item27.descuentos").attr('value',"0.00");//PAS20201U210100022
  			//ISC
  			dijit.byId("item27.iscMonto").constraints = {min:0,currency:moneda, places:2};
        	var montoISC = store.getValue(row, "iscMontoOriginal");
        	if(montoISC == "" || montoISC=="0.00"){
				dijit.byId("item27.iscMonto").attr('disabled', true);
				dijit.byId("item27.iscMonto").attr('value',"");	
				dijit.byId("item27.iscMonto").attr('style',"background-color:lightgray");	
			}else{
				dijit.byId("item27.iscMonto").attr('disabled', false);
				dijit.byId("item27.iscMonto").attr('style',"background-color:white");	
				dijit.byId("item27.iscMonto").attr('value',"0");
			}
             					
			//IGV                      		
  			dijit.byId("item27.precioConIGV").constraints = {min:0,currency:moneda, places: '2,10'};
        	var montoIGV = store.getValue(row, "igvMonto");
        	if(montoIGV == "" || montoIGV=="0.00"){
				dijit.byId("item27.igvPorcentaje").setValue(0.00);
           		dijit.byId("item27.precioConIGV").attr('disabled', true);
				dijit.byId("item27.precioConIGV").attr('value',"");	
				dijit.byId("item27.precioConIGV").attr('style',"background-color:lightgray");	
			}else{
				dijit.byId("item27.precioConIGV").attr('disabled', false);
				dijit.byId("item27.precioConIGV").attr('style',"background-color:white");	
				dijit.byId("item27.precioConIGV").attr('value',"0");
			}
   				
  			dijit.byId("item27.importeVenta").constraints = {min:0,currency:moneda, places:'2,10'};// Inicio PAS20211U210100007-jmendozas
  			dijit.byId("item27.importeVenta").attr('value',"0");
		}else{
  			dijit.byId("item27.descuentos").constraints = {min:0,currency:moneda, places: '2,10'};
			//INI: PAS20201U210100188  Recuperacion de descuentos en caso no los recupere
			var desCuentoActualTemp = store.getValue(row, "descuentos");
			if(desCuentoActualTemp=="0.00"){
				var desCuentoActualTemp = store.getValue(row, "precioUnitario");
				if(desCuentoActualTemp!="0.00"){	
					store.setValue(row,'descuentos', store.getValue(row, "precioUnitario") );
				}
			}		
			//FIN: PAS20201U210100188
  			dijit.byId("item27.descuentos").attr('value',store.getValue(row, "descuentos"));  			
			
  			//ISC
  			dijit.byId("item27.iscMonto").constraints = {min:0,currency:moneda, places:2};
        	var montoISC = store.getValue(row, "iscMonto");
        	if(montoISC == "" || montoISC=="0.00" || dijit.byId("item27.iscMonto").getValue()=="0"){
				dijit.byId("item27.iscMonto").attr('disabled', true);
				dijit.byId("item27.iscMonto").attr('value',"");	
				dijit.byId("item27.iscMonto").attr('style',"background-color:lightgray");	
			}else{
				dijit.byId("item27.iscMonto").attr('disabled', false);
				dijit.byId("item27.iscMonto").attr('style',"background-color:white");	
				dijit.byId("item27.iscMonto").attr('value',montoISC);
			}
			
			//IGV                      		
  			dijit.byId("item27.precioConIGV").constraints = {min:0,currency:moneda, places:'2,10'};// Inicio PAS20211U210100007-jmendozas
        	var montoIGV = store.getValue(row, "igvMonto");
        	console.log("AmontoIGV-item27.precioConIGV",montoIGV);// Inicio PAS20211U210100007-jmendozas
        	if(montoIGV == "" || montoIGV=="0.00"){
        	    dijit.byId("item27.igvPorcentaje").setValue(0.00);
           		dijit.byId("item27.precioConIGV").attr('disabled', true);
				dijit.byId("item27.precioConIGV").attr('value',"");	
				dijit.byId("item27.precioConIGV").attr('style',"background-color:lightgray");	
			}else{
				dijit.byId("item27.precioConIGV").attr('disabled', false);
				dijit.byId("item27.precioConIGV").attr('style',"background-color:white");	
				dijit.byId("item27.precioConIGV").attr('value',montoIGV);
			}
			console.log("item27.importeVenta.x1")
  			dijit.byId("item27.importeVenta").constraints = {min:0,currency:moneda, places:'2,10'};// Inicio PAS20211U210100007-jmendozas
			dijit.byId("item27.importeVenta").attr('value', store.getValue(row, "importeVenta"));           
		}
		bCargando= false;
		this.dialogItem27.show();		
	},
	round : function(num, decimals) {
		var n = Math.pow(10, decimals);
        return Math.round( (n * num).toFixed(decimals) )  / n;
	}, 	
	updateItemAmount27: function() {
		var cantidad=0;
		var igvPorcentaje = 0;
		var cantidadXPrecio = 0;
		var iscMonto = 0;
		var igvMonto = 0;
		var otroMonto = 0;
		var otroTributo = 0;
		var totalItem = 0;
		var descuentos =0;
    var impuestoICBPER=0;//PAS20191U210100075
    var tasaBolsa = 0;//PAS20191U210100075

		if (bCargando == true) {return;}		
		igvPorcentaje = dijit.byId("item27.igvPorcentaje").getValue();    //IGV 19 
		console.log("igvPorcentaje updateItemAmount27--> " + igvPorcentaje); //PAS20201U210100022

		//PAS20191U210100075
		var valOpcionImpuestoBolsaPlastica = this.getValorOpcionImpuestoBolsaPlastica27();

		
		//cantidad=dijit.byId("item27.cantidad").value; 
		cantidad=dijit.byId("item27.cantidad").getValue(); //PAS20191U210100075 01.08
		
		console.log(cantidad);
		console.log(valOpcionImpuestoBolsaPlastica);		
		

		//PAS20191U210100075

		//var moneda = this.facturaBean.codigoMoneda;
		var moneda = this.changeMoneda(this.facturaBean.codigoMoneda);
		descuentos =dijit.byId("item27.descuentos").getValue();
		cantidadXPrecio = cantidad * descuentos;
		console.log("cantidadXPrecio updateItemAmount27--> " + cantidadXPrecio); //PAS20201U210100022
		
		iscMonto = dijit.byId("item27.iscMonto").getValue();
		if (isNaN(iscMonto)){ iscMonto = 0;}
		igvMonto = dijit.byId("item27.precioConIGV").getValue();		
		
		if (isNaN(igvMonto) || (dijit.byId("item27.igvPorcentaje").getValue() ==0)){ 
			igvMonto = 0;
		}else{		    
		   igvMonto = ((cantidadXPrecio + iscMonto)* igvPorcentaje);// Estaba comentado y se habilito con el PAS20201U210100022
		   //igvMonto = ((descuentos + iscMonto)* igvPorcentaje); Antes del pase PAS20201U210100022
		}
		console.log("igvMonto updateItemAmount27--> " + igvMonto); //PAS20201U210100022
		igvMonto = this.round(igvMonto,10); //PAS20201U210100022 // Inicio PAS20211U210100007-jmendozas
		console.log("igvMonto redondeado--> " + igvMonto); //PAS20201U210100022
		
		//IMPORTE DE VENTA=((VALOR UNITARIO)*CANTIDAD)-(DESCUENTOS)+(IGV)+(ISC MONTO)+(OTROS CARGOS)
		totalItem =cantidadXPrecio + igvMonto + iscMonto;// Estaba comentado y se habilito con el PAS20201U210100022
		//totalItem =descuentos + igvMonto + iscMonto; Antes del pase PAS20201U210100022

		//INI: PAS20191U210100075
		tasaBolsa = dojo.byId("item26.impuestoICBPER").value; 
		
		var monedadesc = this.facturaBean.descripcionMoneda;
		
		if(monedadesc !="SOLES"){

			impuestoICBPER = dijit.byId("item27.impuestoICBPER").getValue();
			if(isNaN(impuestoICBPER)){
				impuestoICBPER = 0;
			}
		}else{
			impuestoICBPER = cantidad * tasaBolsa;
			
		}
		console.log(impuestoICBPER);
		
		
		console.log(totalItem);
		dijit.byId("item27.impuestoICBPER").attr('value',dojo.currency.format(impuestoICBPER, {currency: moneda, places: 2}));
		totalItem  = totalItem + impuestoICBPER;
		//FIN: PAS20191U210100075
		
		dijit.byId("item27.descuentos").attr('value',dojo.currency.format(dijit.byId("item27.descuentos").getValue(), {currency: moneda,places: '2,10'}));		
		dijit.byId("item27.precioConIGV").attr('value',dojo.currency.format(igvMonto, {currency: moneda, places: '2,10'}));// Inicio PAS20211U210100007-jmendozas
		dijit.byId("item27.iscMonto").attr('value',dojo.currency.format(iscMonto, {currency: moneda, places: 2}), false);
		console.log("item27.importeVenta.x2")
		dijit.byId("item27.importeVenta").attr('value',dojo.currency.format(totalItem, {currency: moneda, places: '2,10'}));// Inicio PAS20211U210100007-jmendozas
		dijit.hideTooltip(dojo.byId("item27.importeVenta"));
        dijit.hideTooltip(dojo.byId("item27.descuentos"));
		dijit.hideTooltip(dojo.byId("item27.iscMonto"));		
	},	
	
	acceptDialogItem27: function() {
		//var moneda = this.facturaBean.codigoMoneda;
		var moneda = this.changeMoneda(this.facturaBean.codigoMoneda);
		var otrosTributosOriginal = this.facturaBean.totalOtrosTributos;       
		
    	if (dijit.byId("item27.descuentos").getValue() == "") {
			mostrarMensaje("Descuentos debe ser mayor a 0.")
			var node = dijit.byId("item27.descuentos");
			this.iconTooltipMessage(node.focusNode,"icon-ok-tooltip", "Debe consignarse descuentos.");				
			node.constraints = {min:0,currency:moneda, places: '2,10'};
			return;
		}		
		
		if (dijit.byId("item27.descuentos").getValue() <= 0){
			
			var node = dijit.byId("item27.descuentos");
			this.iconTooltipMessage(node.focusNode,"icon-ok-tooltip", "Descuentos debe ser mayor a 0.");				
			node.constraints = {min:0,currency:moneda, places: '2,10'};
			
			return;
		}	
		//INI PAS20191U210100075	
    	if (dijit.byId("item27.descuentos").getValue()==undefined || dijit.byId("item27.descuentos").getValue() == "" || isNaN(dijit.byId("item27.descuentos").getValue()) || dijit.byId("item27.descuentos").getValue() == NaN) {
			mostrarMensaje("Debe consignarse descuentos.")
			var node = dijit.byId("item27.descuentos");
			this.iconTooltipMessage(node.focusNode,"icon-ok-tooltip", "Debe consignarse descuentos.");				
			node.constraints = {min:0,currency:moneda, places: '2,10'};
			return;
		}		
		//FIN PAS20191U210100075	
			
		//if (dijit.byId("item27.descuentos").getValue() >= dojo.number.parse(dojo.byId("item27.precioUnitarioOriginal").value )) {
		//PAS20211U210100007-JMendozas
		console.log("log.item27.descuentos=", dijit.byId("item27.descuentos").getValue() );////PAS20211U210100007-JMendozas
    	console.log("log.item27.precioUnitarioOriginal=",dojo.number.parse(dojo.byId("item27.precioUnitarioOriginal").value ));//PAS20211U210100007-JMendozas
		console.log("log.item27.cantidad=",dojo.number.parse(dojo.byId("item27.cantidad").value ));//PAS20211U210100007-JMendozas
		console.log("log.descuentosOriginal=",store.getValue(row, "descuentosOriginal"));//PAS20211U210100007-JMendozas
		var calculoMontoValidacion = ((dojo.number.parse(dojo.byId("item27.precioUnitarioOriginal").value )*dojo.byId("item27.cantidad").value ) - (store.getValue(row, "descuentosOriginal")));//PAS20211U210100007-JMendozas
		console.log("log.calculoMontoValidacion=",calculoMontoValidacion);//PAS20211U210100007-JMendozas

		if (dijit.byId("item27.descuentos").getValue() >= calculoMontoValidacion ) {//PAS20211U210100007-JMendozas
			var node = dijit.byId("item27.descuentos");
			this.iconTooltipMessage(node.focusNode,"icon-ok-tooltip", "Descuentos debe ser menor al precio unitario por la cantidad menos los descuentos del item de la FE respecto de la cual se emitir\u00E1 la Nota de Cr\u00E9dito.");
			node.constraints = {min:0,currency:moneda, places: '2,10'};//PAS20211U210100007-JMendozas
			return;
		}				
		
		if (dijit.byId("item27.iscMonto").attr('disabled') == false){
			//if (dijit.byId("item27.iscMonto").getValue() == "" ) {
			if (dijit.byId("item27.iscMonto").getValue() === "" ) {
  				var node = dijit.byId("item27.iscMonto");
				this.iconTooltipMessage(node.focusNode,"icon-ok-tooltip", "Debe consignarse ISC.");  				
  				node.constraints = {min:0,currency:moneda, places:2};
  				return;
  			}	      
        	//if (dijit.byId("item27.iscMonto").getValue() <= 0 ) {
			if (dijit.byId("item27.iscMonto").getValue() < 0 ) {
  				var node = dijit.byId("item27.iscMonto");
  				this.iconTooltipMessage(node.focusNode,"icon-ok-tooltip", "ISC debe ser mayor que 0.");  			
  				node.constraints = {min:0,currency:moneda, places:2};
  				return;
  			}	
  				
  			if (dijit.byId("item27.iscMonto").getValue() >= dijit.byId("item27.descuentos").getValue()) {
  				var node = dijit.byId("item27.iscMonto");
  				this.iconTooltipMessage(node.focusNode,"icon-ok-tooltip", "ISC debe ser menor que los descuentos.");  					
  				node.constraints = {min:0,currency:moneda,places: '2,10'};
  				return;
  			}	
 			//if (dijit.byId("item27.iscMonto").getValue() >= dojo.number.parse(dojo.byId("item27.iscMontoOriginal").value ))
   			if (dijit.byId("item27.iscMonto").getValue() > dojo.number.parse(dojo.byId("item27.iscMontoOriginal").value )) {
  				var node = dijit.byId("item27.iscMonto");
  				this.iconTooltipMessage(node.focusNode,"icon-ok-tooltip", "ISC debe ser menor que el monto del ISC original.");  					
  				node.constraints = {min:0,currency:moneda, places:2};
  				return;
  			}
		}
		
		//    if(dijit.byId("item27.importeVenta").getValue() > dojo.number.parse(dojo.byId("item27.precioUnitarioOriginal").value )){
		//   if(dijit.byId("item27.importeVenta").getValue() > store.getValue(row, "importeVentaOriginal")){
		//      var node = dijit.byId("item27.importeVenta");
		//			this.iconTooltipMessage(node.focusNode,"icon-ok-tooltip", "Importe de venta debe ser menor que el importe de venta del item respectivo de la Factura Original");
		//		        return;     
		//    }  
		/*Inicio PAS20165E210300142*/
		//if(dijit.byId("item27.importeVenta").getValue() > dojo.number.parse(dojo.byId("item27.precioUnitarioOriginal").value )){ antes de PAS20201U210100022
		
		
		  //PAS20201U210100022 Compara valor de venta de factura original con el descuento de la NCE
      //precioUnitarioOriginal = cac:PricingReference/cac:AlternativeConditionPrice/cbc:PriceAmount
		console.log("item21.descuentos.valid1",dijit.byId("item27.descuentos").getValue());
		console.log("item21.precioUnitarioOriginal.valid1",dojo.byId("item27.precioUnitarioOriginal").value );
		if(dijit.byId("item27.descuentos").getValue() > dojo.number.parse(dojo.byId("item27.precioUnitarioOriginal").value )){
			var node = dijit.byId("item27.importeVenta");
   			this.iconTooltipMessage(node.focusNode,"icon-ok-tooltip", "Importe de venta debe ser menor que el importe de venta del item respectivo de la Factura Original");
  			return;     
		}     
		/*Fin PAS20165E210300142*/
		
		if(!dijit.byId("item27.form").validate()) return;
		///
		//INI PAS20191U210100075
		dijit.byId("item27.impuestoBolsasPlastica00").setAttribute('disabled', false);
		dijit.byId("item27.impuestoBolsasPlastica01").setAttribute('disabled', false);
		
		console.log("enviar formulario");
		
		//FIN PAS20191U210100075
		var nbControl = dijit.byId("item27.botonAceptar");
		nbControl.setAttribute('disabled', true);
		var nodeButton = nbControl.focusNode;
		var mode = dojo.byId("item27.action").value;
		this.wait("Editando", "95px", 200);	
		var handler = dojo.io.iframe.send({
			url: this.controller,
			handleAs: "json",
			sync: true,
			timeout: 10000,
			preventCache: true,
			form: "item27.form"
		});
		handler.addCallback(dojo.hitch(this, function(res){
		    this.waitMessage.hide();
			if(res.codeError == 0) {
				store.fetchItemByIdentity({
					identity: currentLine,
					onItem: dojo.hitch(this, function(item){
						store.setValue(item,'descuentos',dojo.byId("item27.descuentos").value );
						store.setValue(item,'precioUnitario',dojo.byId("item27.descuentos").value );
						if (dojo.byId("item27.iscMonto").value != ""){	store.setValue(item,'iscMonto',dojo.byId("item27.iscMonto").value ); }
						if (dojo.byId("item27.precioConIGV").value != ""){	store.setValue(item,'igvMonto',dojo.byId("item27.precioConIGV").value );}
						store.setValue(item,'modificado',"1");
						store.setValue(item,'importeVenta',dojo.byId("item27.importeVenta").value);        			
					}),
					onError: function(){}
				});
				
				var grid = dijit.byId('ncCambioDetalles.ingreso-grid');
				grid.setStore(store);
				grid.update();
				this.closeDialogItem27();
			} else {
				nbControl.setAttribute('disabled', false);
				this.iconTooltipMessage(nodeButton, "icon-error-tooltip", res.messageError);
			}
		}));
		handler.addErrback(dojo.hitch(this, function(res) {
			nbControl.setAttribute('disabled', false);
			this.waitMessage.hide();
			this.iconTooltipMessage(nodeButton, "icon-error-tooltip", res.messageError);
		}));
		
		nbControl.setAttribute('disabled', false);
		//INI PAS20191U210100075
		dijit.byId("item27.impuestoBolsasPlastica00").setAttribute('disabled', false);
		dijit.byId("item27.impuestoBolsasPlastica01").setAttribute('disabled', false);
		//FIN PAS20191U210100075
		
		dijit.hideTooltip(dojo.byId("item27.importeVenta"));//PAS20211U210100007-JMendozas
		dijit.hideTooltip(dojo.byId("item27.descuentos"));
		dijit.hideTooltip(dojo.byId("item27.iscMonto"));
		dijit.hideTooltip(dojo.byId("item27.importeVenta"));    
	},    
    
    closeDialogItem27: function() {
		dijit.hideTooltip(dojo.byId("item27.importeVenta"));//PAS20211U210100007-JMendozas
        dijit.hideTooltip(dojo.byId("item27.descuentos"));
		//dijit.hideTooltip(dojo.byId("item27.descuentos"));
		dijit.hideTooltip(dojo.byId("item27.iscMonto"));
		this.dialogItem27.hide();
	},	  
	  
	//Devolucion por Item
    editItem26: function(identificador) {
		console.warn("OPEN " , "ITEM26");// Inicio PAS20211U210100007-jmendozas
		store =dijit.byId('ncCambioDetalles.ingreso-grid').store;       
		store.fetchItemByIdentity({
			identity: identificador,
		    onItem : function(item, request) {
				row = item;		
				currentLine = identificador 	;		
		    },
		    onError : function(item, request) {
				mostrarMensaje("Ocurrio un error al ubicar el documento");
				return;				
		    }
		});
			console.log("editar");
			console.log(row);
		var descripcionItem=dojo.trim(store.getValue(row, "descripcion"));
		var buscar="[*****] BONIFICACION [*****]";
		var esBonificacion = false;
		if (descripcionItem.search(buscar)!=-1 ){
			esBonificacion = true;	
		}
		bCargando= true;
		dijit.byId("item26.descuentos").attr('value',"");	
		dijit.byId("item26.precioConIGV").attr('value',"");	
		dijit.byId("item26.iscMonto").attr('value',"");    
      
		var otrosCargosTributos=dojo.trim(store.getValue(row, "otrosCargosTributosOriginal"));
		if (otrosCargosTributos != "" && otrosCargosTributos !=null  && otrosCargosTributos !="0.00"){
			mostrarMensaje("No podr\u00E1 seleccionarse un \u00EDtem que es Cargo o Tributo.");
			return;	
        }
		//var moneda = this.facturaBean.codigoMoneda;
		var moneda = this.changeMoneda(this.facturaBean.codigoMoneda);
		var monedadesc = this.facturaBean.descripcionMoneda; //PAS20191U210100075
		dijit.byId("item26.botonAceptar").attr('disabled', false);
		this.dialogItem26.attr('title', "Captura NC - Devoluci\u00F3n por Item");
		dojo.byId("item26.idItem").value = currentLine ; //store.getValue(row, "identificador");
	  	dojo.byId("item26.precioUnitarioOriginal").value =store.getValue(row, "precioUnitarioOriginal");
	  	dojo.byId("item26.descuentosOriginal").value =store.getValue(row, "descuentosOriginal");
	  	dojo.byId("item26.valorVtaUnitarioOriginal").value =store.getValue(row, "valorVtaUnitarioOriginal");
		dijit.byId("item26.unidadMedida").setValue(store.getValue(row, "unidadMedidaDesc"));						
		dojo.byId("item26.iscMontoOriginal").value =store.getValue(row, "iscMontoOriginal");
        dojo.byId("item26.otrosCargosOriginal").value =store.getValue(row, "otrosCargosOriginal");
		//dijit.byId("item26.cantidad").setValue(store.getValue(row, "cantidad"), false);
		
		dijit.byId("item26.descripcion").setValue(store.getValue(row, "descripcion"));
		dijit.byId("item26.igvPorcentaje").setValue(store.getValue(row, "igvPorcentaje"));    
    
		
		//INI: PAS20191U210100075  

		var montoIcbPer = store.getValue(row, "icbPerMonto");
		dijit.byId("item26.impuestoBolsasPlastica00").setAttribute('disabled', true);
		dijit.byId("item26.impuestoBolsasPlastica01").setAttribute('disabled', true);
		
		console.log(monedadesc);
		if(monedadesc !="SOLES" && !(montoIcbPer == "" || montoIcbPer=="0")){
			dijit.byId("item26.impuestoICBPER").setAttribute('readOnly', false);
		}else{
			dijit.byId("item26.impuestoICBPER").setAttribute('readOnly', true);
		}
		
		
		//if(montoIcbPer == "" || montoIcbPer=="0"){
		if(store.getValue(row, "esImpuestoBolsaPlastico") != "IBP00"){			
			dijit.byId("item26.impuestoBolsasPlastica00").setAttribute('disabled', true);
			dijit.byId("item26.impuestoBolsasPlastica01").setAttribute('disabled', true);

			dijit.byId("item26.impuestoBolsasPlastica01").setChecked("checked");
			dojo.byId("item26.tasaBolsaGlobal").value =store.getValue(row, "icbTasa");//PAS20191U210100075
			dijit.byId("item26.impuestoICBPER").constraints = {min:0,currency:moneda, places:2};//PAS20191U210100075
			dijit.byId("item26.impuestoICBPER").attr('value',store.getValue(row, "icbPerMonto"));//PAS20191U210100075							
			
			//INI : PAS20191U210100075 20.07			
			//this.showHiddenDiv(document.getElementById("item26.ICBPER1.show"),true); 
			//this.showHiddenDiv(document.getElementById("item26.ICBPER2.show"),true);
			this.showHiddenDiv(document.getElementById("item26.ICBPER1.show"),false); 
			this.showHiddenDiv(document.getElementById("item26.ICBPER2.show"),false);
			dijit.byId("item26.tasaBolsa").constraints = {min:0,currency:moneda, places:2};
			dijit.byId("item26.tasaBolsa").attr('value',"0");			
			dijit.byId("item26.periodoBolsa").attr('value',"");
			
			//FIN : PAS20191U210100075 20.07
			//dijit.byId("item26.cantidad").setValue(dojo.trim(dojo.currency.format(store.getValue(row, "cantidad")), {places: '2,10'}));			
			dijit.byId("item26.cantidad").setValue(dojo.trim(store.getValue(row, "cantidad"), {places: '2,10'}));//PAS20201U210100022
		}else{
			dijit.byId("item26.impuestoBolsasPlastica00").setChecked("checked");
		  
			dojo.byId("item26.tasaBolsaGlobal").value =store.getValue(row, "icbTasa");//PAS20191U210100075

			//dijit.byId("item26.impuestoICBPER").constraints = {min:0,currency:moneda, places:2};//PAS20191U210100075
			//dijit.byId("item26.impuestoICBPER").attr('value',store.getValue(row, "icbPerMonto"));//PAS20191U210100075	
			//dijit.byId("item26.impuestoICBPER").attr('value',dojo.currency.format(store.getValue(row, "icbPerMonto"), {currency: moneda, places: 2}));    
			dijit.byId("item26.impuestoICBPER").constraints = {min:0,currency:moneda, places:2};//PAS20191U210100075
			dijit.byId("item26.impuestoICBPER").attr('value',store.getValue(row, "icbPerMonto"));//PAS20191U210100075	
			
			//INI : PAS20191U210100075 20.07
			this.showHiddenDiv(document.getElementById("item26.ICBPER1.show"),true); 
			this.showHiddenDiv(document.getElementById("item26.ICBPER2.show"),true);
			dijit.byId("item26.tasaBolsa").constraints = {min:0,currency:moneda, places:2};
			dijit.byId("item26.tasaBolsa").attr('value',store.getValue(row, "icbTasa"));
			var parts2 = store.getValue(row, "icbfechaemision").split('/');	
			document.getElementById("item26.periodoBolsa").value = parts2[2];
			//FIN : PAS20191U210100075 20.07
			dijit.byId("item26.cantidad").setValue(dojo.trim(dojo.currency.format(store.getValue(row, "cantidad")), {places: '2,10'})); //PAS20191U210100075  01.08 
			//dijit.byId("item26.cantidad").setValue(Number(store.getValue(row, "cantidad")).toFixed(0), false);
		}
		//FIN: PAS20191U210100075	
    			
		if (store.getValue(row, "modificado") =="0"){
			dijit.byId("item26.precioUnitario").constraints = {currency:moneda, places: '2,10'};
			dojo.byId("item26.precioUnitario").value= store.getValue(row, "valorVtaUnitarioOriginal");
			dojo.byId("item26.precioUnitario").value= dojo.number.format(dijit.byId("item26.precioUnitario").getValue(),{currency:moneda, places:'2,10'});
			//descuentos
  			dijit.byId("item26.descuentos").constraints = {min:0,currency:moneda, places:2};
        	var montoDescuentos = store.getValue(row, "descuentosOriginal");
        	if(montoDescuentos == "" || montoDescuentos=="0.00" || montoDescuentos=="0"){
				dijit.byId("item26.descuentos").attr('disabled', true);
  		        dijit.byId("item26.descuentos").attr('value',"");	
  		        dijit.byId("item26.descuentos").attr('style',"background-color:lightgray");	
            }else{
                dijit.byId("item26.descuentos").attr('disabled', false);
                dijit.byId("item26.descuentos").attr('style',"background-color:white");	
                dijit.byId("item26.descuentos").attr('value',"0");
            }
            					
  			//ISC
  			dijit.byId("item26.iscMonto").constraints = {min:0,currency:moneda, places:2};
        	var montoISC = store.getValue(row, "iscMontoOriginal");
		
        	if(montoISC == "" || montoISC=="0.00"){
				dijit.byId("item26.iscMonto").attr('disabled', true);
  		        dijit.byId("item26.iscMonto").attr('value',"");	
  		        dijit.byId("item26.iscMonto").attr('style',"background-color:lightgray");	
            }else{
                dijit.byId("item26.iscMonto").attr('disabled', false);
                dijit.byId("item26.iscMonto").attr('style',"background-color:white");	
                //dijit.byId("item26.iscMonto").attr('value',"0");//PASE PAS20201U210200016 Correccion 1
				dijit.byId("item26.iscMonto").setValue(dojo.number.format(montoISC,{places:2} ));//PASE PAS20201U210200016 Correccion 1
            }
              					
            //IGV                      		
  			dijit.byId("item26.precioConIGV").constraints = {min:0,currency:moneda, places:'2,10'};// Inicio PAS20211U210100007-jmendozas
        	var montoIGV = store.getValue(row, "igvMonto");
        	if((montoIGV == "" || montoIGV=="0.00") && (store.getValue(row, "tipoBeneficio") != "TB00")){
				dijit.byId("item26.igvPorcentaje").setValue(0.00);
            	dijit.byId("item26.precioConIGV").attr('disabled', true);
  		        dijit.byId("item26.precioConIGV").attr('value',"");	
  		        dijit.byId("item26.precioConIGV").attr('style',"background-color:lightgray");	
            }else{
                dijit.byId("item26.precioConIGV").attr('disabled', false);
                dijit.byId("item26.precioConIGV").attr('style',"background-color:white");	
                dijit.byId("item26.precioConIGV").attr('value',"0");
            }
           
        //INI: PAS20191U210100075   
        //ICBPER  			          
          /*dijit.byId("item26.impuestoICBPER").constraints = {min:0,currency:moneda, places:2};
        	var montoICBPer = store.getValue(row, "icbPerMonto");
        	if(montoICBPer == "" || montoICBPer=="0.00"){
				      dijit.byId("item26.impuestoICBPER").attr('disabled', true);
  		        dijit.byId("item26.impuestoICBPER").attr('value',"");	
  		        dijit.byId("item26.impuestoICBPER").attr('style',"background-color:lightgray");	
            }else{
                dijit.byId("item26.impuestoICBPER").attr('disabled', false);
                dijit.byId("item26.impuestoICBPER").attr('style',"background-color:white");	
                dijit.byId("item26.impuestoICBPER").attr('value',"0");
            }*/   
        //FIN: PAS20191U210100075

  			dijit.byId("item26.importeVenta").constraints = {min:0,currency:moneda, places:'2,10'};// Inicio PAS20211U210100007-jmendozas
  			dijit.byId("item26.importeVenta").attr('value',"0");
		}else{
			dijit.byId("item26.precioUnitario").constraints = {currency:moneda, places: '2,10'};
  			dijit.byId("item26.precioUnitario").attr('value',store.getValue(row, "precioUnitario"));  	

  			//descuentos
  			dijit.byId("item26.descuentos").constraints = {min:0,currency:moneda, places:2};
        	var montoDescuentos = store.getValue(row, "descuentosOriginal");
        	if(montoDescuentos == "" || montoDescuentos=="0.00" || montoDescuentos=="0"){
				dijit.byId("item26.descuentos").attr('disabled', true);
  		        dijit.byId("item26.descuentos").attr('value',"");	
  		        dijit.byId("item26.descuentos").attr('style',"background-color:lightgray");
            }else{
                dijit.byId("item26.descuentos").attr('disabled', false);
                dijit.byId("item26.descuentos").attr('style',"background-color:white");	
                dijit.byId("item26.descuentos").attr('value',store.getValue(row, "descuentos"));
            }	

  			//ISC
  			dijit.byId("item26.iscMonto").constraints = {min:0,currency:moneda, places:2};
			var montoISC = store.getValue(row, "iscMonto");//PASE PAS20201U210200016 Correccion2
			console.log("-->" + montoISC);
        		
        		if(montoISC == "" || montoISC=="0.00" || montoISC==undefined){ //PAS20191U210100075
					console.log("--><----");
					dijit.byId("item26.iscMonto").setValue(dojo.number.format("0.00",{places:2} ));
            	dijit.byId("item26.iscMonto").attr('disabled', true);
  		          dijit.byId("item26.iscMonto").attr('value',"");	
  		          dijit.byId("item26.iscMonto").attr('style',"background-color:lightgray");	
            }else{
                dijit.byId("item26.iscMonto").attr('disabled', false);
                dijit.byId("item26.iscMonto").attr('style',"background-color:white");	
                //dijit.byId("item26.iscMonto").attr('value',montoISC);
                dijit.byId("item26.iscMonto").setValue(dojo.number.format(montoISC,{places:2} ));
            }
              					
            //IGV                      		
  					dijit.byId("item26.precioConIGV").constraints = {min:0,currency:moneda, places:'2,10'};// Inicio PAS20211U210100007-jmendozas
        		var montoIGV = store.getValue(row, "igvMonto");
			console.warn("precioConIGV  2 : " ,montoIGV  )
        		if((montoIGV == "" || montoIGV=="0.00") && (store.getValue(row, "tipoBeneficio") != "TB00")){
        		    dijit.byId("item26.igvPorcentaje").setValue(0.00);
            		dijit.byId("item26.precioConIGV").attr('disabled', true);
  		          dijit.byId("item26.precioConIGV").attr('value',"");	
  		          dijit.byId("item26.precioConIGV").attr('style',"background-color:lightgray");	
            }else{

        		console.warn("precioConIGV : " ,montoIGV  )// Inicio PAS20211U210100007-jmendozas
                dijit.byId("item26.precioConIGV").attr('disabled', false);
                dijit.byId("item26.precioConIGV").attr('style',"background-color:white");	
                //dijit.byId("item26.precioConIGV").attr('value',montoIGV);
                dijit.byId("item26.precioConIGV").attr('value',dojo.currency.format(montoIGV, {currency: moneda, places: '2,10'}));// Inicio PAS20211U210100007-jmendozas
                //dijit.byId("item26.precioConIGV").constraints = {min:0,currency:moneda, places:2};
            }

            //INI: PAS20191U210100075   
            /*//ICBPER
      			dijit.byId("item26.impuestoICBPER").constraints = {min:0,currency:moneda, places:2};
            	var montoICBPer = store.getValue(row, "icbPerMonto");
            	if(montoICBPer == "" || montoICBPer=="0.00"){
    				      dijit.byId("item26.impuestoICBPER").attr('disabled', true);
      		        dijit.byId("item26.impuestoICBPER").attr('value',"");	
      		        dijit.byId("item26.impuestoICBPER").attr('style',"background-color:lightgray");	
                }else{
                    dijit.byId("item26.impuestoICBPER").attr('disabled', false);
                    dijit.byId("item26.impuestoICBPER").attr('style',"background-color:white");	                    
                    dijit.byId("item26.impuestoICBPER").setValue(dojo.number.format(montoICBPer,{places:2} ));
                }*/  
            //FIN: PAS20191U210100075
  				
  				  dijit.byId("item26.importeVenta").setValue(dojo.number.format(store.getValue(row, "importeVenta"),{places:'2,10'} ));// Inicio PAS20211U210100007-jmendozas
            dijit.byId("item26.importeVenta").constraints = {min:0,currency:moneda, places:'2,10'};// Inicio PAS20211U210100007-jmendozas
          }    
          
          //INI: PAS20191U210100075
          /*nrus = this.esNrus();
          console.log(nrus);
          
          var nrus = dojo.byId("item26.esNrus").value;
          if (nrus == 1){
      			//this.viewCheckedImpuestoBolsaPlastica();
      			this.showHiddenDiv(document.getElementById("item.ICBPER1.show"),false); //ocultar si es nrus
      			this.showHiddenDiv(document.getElementById("item.ICBPER2.show"),false); //ocultar si es nrus
      		}else{
      			//this.viewCheckedImpuestoBolsaPlastica();
      			this.showHiddenDiv(document.getElementById("item.ICBPER1.show"),true); //mostrar si no es nrus
      			this.showHiddenDiv(document.getElementById("item.ICBPER2.show"),true); //mostrar si no es nrus
      			
      		}  */
          //FIN: PAS20191U210100075

		  bCargando= false;
		  this.updateItemAmount26(); // PAS20191U210100075
		  this.dialogItem26.show();		
		},
		
		updateItemAmount26: function() {
		var cantidad=0;
		var igvPorcentaje = 0;
		var cantidadXPrecio = 0;
		var iscMonto = 0;
		var igvMonto = 0;
		var otroMonto = 0;
		var otroTributo = 0;
		var totalItem = 0;
		var descuentos =0;
		var precioUnitario =0;
    var impuestoICBPER=0;//PAS20191U210100075
    var tasaBolsa = 0;//PAS20191U210100075
		
		if (bCargando == true) {return;}
		
		
		//PAS20191U210100075
		var valOpcionImpuestoBolsaPlastica = this.getValorOpcionImpuestoBolsaPlastica();
		if (valOpcionImpuestoBolsaPlastica != "IBP00"){ //NO > IMPUESTO BOLSAS;

			//dijit.byId("item26.cantidad").constraints = {min:0,places:2};;
			//dijit.byId("item26.cantidad").attr('value',dijit.byId("item26.cantidad").getValue());
			
		}else{ // SI IMPUESTO BOLSAS				

			//dijit.byId("item26.cantidad").constraints = {min:0,places:0};
			//dijit.byId("item26.cantidad").attr('value',dijit.byId("item26.cantidad").getValue());
		}
		//cantidad=dijit.byId("item26.cantidad").value; 
		cantidad=dijit.byId("item26.cantidad").getValue(); //PAS20191U210100075 01.08
		//PAS20191U210100075
		
		igvPorcentaje = dijit.byId("item26.igvPorcentaje").getValue() ;    //IGV 19 

		//var moneda = this.facturaBean.codigoMoneda;
		var moneda = this.changeMoneda(this.facturaBean.codigoMoneda);

    if (dojo.byId("item26.precioUnitario").value ==""){
    }else{
          precioUnitario =dijit.byId("item26.precioUnitario").getValue();
    }
    descuentos =dijit.byId("item26.descuentos").getValue();
    if (isNaN(descuentos)){ descuentos = 0;}
		cantidadXPrecio = cantidad * precioUnitario;
		
		iscMonto = dijit.byId("item26.iscMonto").getValue();
		if (isNaN(iscMonto)){ iscMonto = 0;}
		
		igvMonto = dijit.byId("item26.precioConIGV").getValue();    
				
		if (isNaN(igvPorcentaje) || isNaN(cantidadXPrecio) || isNaN(descuentos)  || isNaN(iscMonto)  ||(dijit.byId("item26.igvPorcentaje").getValue() ==0)){ 
       igvMonto = 0;
    }else{
		   igvMonto = ((cantidadXPrecio - descuentos +  iscMonto)* igvPorcentaje);
    }
    
		
		//IMPORTE DE VENTA=((VALOR UNITARIO)*CANTIDAD)-(DESCUENTOS)+(IGV)+(ISC MONTO)+(OTROS CARGOS)
		totalItem =cantidadXPrecio -descuentos + igvMonto + iscMonto;
		
    //INI: PAS20191U210100075
	
    tasaBolsa = dojo.byId("item26.tasaBolsaGlobal").value; 
	

	var monedadesc = this.facturaBean.descripcionMoneda;

	
	if(monedadesc !="SOLES"){
		

		impuestoICBPER = dijit.byId("item26.impuestoICBPER").getValue();
		console.log(impuestoICBPER);
		//dijit.byId("item26.impuestoICBPER").attr('value',dojo.currency.format(impuestoICBPER, {currency: moneda, places: 2}));	
		
	}else{
		impuestoICBPER = cantidad * tasaBolsa;
		//dijit.byId("item26.impuestoICBPER").attr('value',dojo.currency.format(impuestoICBPER, {currency: moneda, places: 2}));
		//dijit.byId("item26.impuestoICBPER").attr('value',impuestoICBPER); //TEMP


	}
	dijit.byId("item26.impuestoICBPER").constraints = {min:0,currency:moneda, places:2};//PAS20191U210100075
	dijit.byId("item26.impuestoICBPER").attr('value',impuestoICBPER);//PAS20191U210100075
	
	console.log(impuestoICBPER);
    
    totalItem  = totalItem + impuestoICBPER;
    //FIN: PAS20191U210100075
	
	
	

		//dijit.byId("item26.precioUnitario").attr('value',dojo.currency.format(dojo.byId("item26.precioUnitario").value, {currency: moneda, places: 10}));
		dijit.byId("item26.descuentos").attr('value',dojo.currency.format(dijit.byId("item26.descuentos").getValue(), {currency: moneda, places: 2}));

		console.warn("item26.precioConIGV 5:" , igvMonto);// Inicio PAS20211U210100007-jmendozas
		dijit.byId("item26.precioConIGV").attr('value',dojo.currency.format(igvMonto, {currency: moneda, places: '2,10'}));// Inicio PAS20211U210100007-jmendozas
		dijit.byId("item26.importeVenta").attr('value',dojo.currency.format(totalItem, {currency: moneda, places: '2,10'}));// Inicio PAS20211U210100007-jmendozas
		//dijit.byId("item26.iscMonto").attr('value',dojo.currency.format(iscMonto, {currency: moneda, places: 2}), false);//PASE PAS20201U210200016 Correccion 5
		dijit.byId("item26.iscMonto").attr('value',dojo.currency.format(iscMonto, {currency: moneda, places: 2}));	//PASE PAS20201U210200016 Correccion 5
		dijit.hideTooltip(dojo.byId("item26.precioUnitario"));
		dijit.hideTooltip(dojo.byId("item26.descuentos"));
		dijit.hideTooltip(dojo.byId("item26.iscMonto"));
	
	},	
	
	
		acceptDialogItem26: function() {
      //var moneda = this.facturaBean.codigoMoneda;
      var moneda = this.changeMoneda(this.facturaBean.codigoMoneda);
      var otrosTributosOriginal = this.facturaBean.totalOtrosTributos; 
		
		  var descripcionItem=dojo.trim(dijit.byId("item26.descripcion").getValue());
		  var buscar="[*****] BONIFICACION [*****]";
		  var esBonificacion = false;
		  if (descripcionItem.search(buscar)!=-1 ){
          esBonificacion = true;	
       }
       
       //if (!esBonificacion) {
        	if (dijit.byId("item26.precioUnitario").getValue() == "" ) {
    				var node = dijit.byId("item26.precioUnitario");
    				this.iconTooltipMessage(node.focusNode,"icon-ok-tooltip", "Debe consignarse el valor unitario.");
    				
    				node.constraints = {currency:moneda, places: '2,10'};
    				return;
    			}	
     //}

      if(dijit.byId("item26.cantidad").getValue() == 0){
          var node = dijit.byId("item26.cantidad");
   				this.iconTooltipMessage(node.focusNode,"icon-ok-tooltip", "Cantidad a devolver no puede ser 0.");
  				return;     
      } 
      
      if(dijit.byId("item26.cantidad").getValue() > store.getValue(row, "cantidadOriginal")){
          var node = dijit.byId("item26.cantidad");
   				this.iconTooltipMessage(node.focusNode,"icon-ok-tooltip", "Cantidad a devolver debe ser menor o igual a la cantidad del item respectivo de la Factura Original");
  				return;     
      } 
      //if (!esBonificacion) {
        if (dijit.byId("item26.precioUnitario").getValue() > dojo.number.parse(dojo.byId("item26.valorVtaUnitarioOriginal").value )) {
  				var node = dijit.byId("item26.precioUnitario");
  				this.iconTooltipMessage(node.focusNode,"icon-ok-tooltip", "Valor Unitario debe ser menor al valor unitario de la Factura Original");
  				
  				node.constraints = {currency:moneda, places: '2,10'};
  				return;
  			}	 
      //}
      
      if (!(dijit.byId("item26.descuentos").getValue() == "") ) {
    			if (dijit.byId("item26.descuentos").getValue() <= 0 ) {
    				var node = dijit.byId("item26.descuentos");
    				this.iconTooltipMessage(node.focusNode,"icon-ok-tooltip", "Descuentos debe ser mayor a 0.");
    				
    				node.constraints = {min:0,currency:moneda, places:2};
    				return;
    			}	
    			
    			//if (dijit.byId("item26.descuentos").getValue() >= dojo.byId("item26.precioUnitario").value) { //PASE PAS20201U210200016 Correccion 5
    			if (dijit.byId("item26.descuentos").getValue() >= (dijit.byId("item26.precioUnitario").getValue()*dojo.byId("item26.cantidad").value))  {
    				var node = dijit.byId("item26.descuentos");
    				this.iconTooltipMessage(node.focusNode,"icon-ok-tooltip", "Descuentos debe ser menor al valor unitario por la cantidad.");
    				
    				node.constraints = {min:0,currency:moneda, places:2};
    				return;
    			}				
			}
      if (dijit.byId("item26.iscMonto").attr('disabled') == false){		  	
			// Inicio Bloque PAS20201U210200016 Correccion 3
			var totalxCantidad_Descuentos = 0;// PAS20201U210200016 Correccion 3
			var descuento26 = 0;// PAS20201U210200016 Correccion 3
			var cantidadUnitaria = dijit.byId("item26.cantidad").getValue();// PAS20201U210200016 Correccion 3
			var valorUnitario=dijit.byId("item26.precioUnitario").getValue();// PAS20201U210200016 Correccion 3
			    descuento26 =dijit.byId("item26.descuentos").getValue();// PAS20201U210200016 Correccion 3
			if (isNaN(descuento26)){ descuento26 = 0;}		// PAS20201U210200016 Correccion 3	

			totalxCantidad_Descuentos=  dojo.number.format((cantidadUnitaria*valorUnitario)-descuento26, { places: 2 });// PAS20201U210200016 Correccion 3
			var FormatTotalxCantidad_Descuentos =dojo.currency.format(totalxCantidad_Descuentos, {currency: moneda, places: 2});// PAS20201U210200016 Correccion 3
			// Fin  Bloque	PAS20201U210200016 Correccion 3	
			//PAS20211U210100037
			 if (dijit.byId("item26.iscMonto").getValue() === "" ) {
        	//if (dijit.byId("item26.iscMonto").getValue() == "" ) {
  					var node = dijit.byId("item26.iscMonto");
  					this.iconTooltipMessage(node.focusNode,"icon-ok-tooltip", "Debe consignarse ISC.");
  					
  					node.constraints = {min:0,currency:moneda, places:2};
  					return;
  				}	      
  				//if (dijit.byId("item26.iscMonto").getValue() <= 0 ) {
        	if (dijit.byId("item26.iscMonto").getValue() < 0 ) {
  					var node = dijit.byId("item26.iscMonto");
  					this.iconTooltipMessage(node.focusNode,"icon-ok-tooltip", "ISC debe ser mayor que 0.");
  					
  					node.constraints = {min:0,currency:moneda, places:2};
  					return;
  				}			
  				//if (dijit.byId("item26.iscMonto").getValue() >= dojo.number.parse(dojo.byId("item26.iscMontoOriginal").value )) {
  				if (dijit.byId("item26.iscMonto").getValue() > dojo.number.parse(dojo.byId("item26.iscMontoOriginal").value )) {
  					var node = dijit.byId("item26.iscMonto");
  					this.iconTooltipMessage(node.focusNode,"icon-ok-tooltip", "ISC debe ser menor o igual que el monto del ISC original.");
  					
  					node.constraints = {min:0,currency:moneda, places:2};
  					return;
  				}	
				
				//if (dijit.byId("item26.iscMonto").getValue() >= dijit.byId("item26.precioUnitario").getValue()) { // PAS20201U210200016 Correccion 3
				if (dijit.byId("item26.iscMonto").getValue() >	totalxCantidad_Descuentos) { // PAS20201U210200016 Correccion 3
  					var node = dijit.byId("item26.iscMonto");
  					this.iconTooltipMessage(node.focusNode,"icon-ok-tooltip", "ISC debe ser menor o igual a "+ FormatTotalxCantidad_Descuentos+  "  [ (Cantidad * Valor unitario)-descuentos ] ");// PAS20201U210200016 Correccion 3
  					
  					node.constraints = {min:0,currency:moneda, places:2};
  					return;
  				}
      }
      
      /*
      if(dijit.byId("item26.importeVenta").getValue() > dojo.number.parse(dojo.byId("item26.precioUnitarioOriginal").value )){
          var node = dijit.byId("item26.importeVenta");
   				this.iconTooltipMessage(node.focusNode,"icon-ok-tooltip", "Importe de venta debe ser menor que el importe de venta del item respectivo de la Factura Original");
  				return;     
      }     
*/

	
      if(!dijit.byId("item26.form").validate()) return;
	
	//INI PAS20191U210100075 - jsantivanez
		dijit.byId("item26.impuestoBolsasPlastica00").setAttribute('disabled', false);
		dijit.byId("item26.impuestoBolsasPlastica01").setAttribute('disabled', false); 	
		dijit.byId("item26.impuestoICBPER").setAttribute('disabled', false);
		
		dojo.byId("item26.impuestoICBPER").value = dojo.number.format(dijit.byId("item26.impuestoICBPER").getValue() ,{places:2} )
		
		console.log(dojo.byId("item26.impuestoICBPER").value)
	

		console.log(dijit.byId("item26.cantidad").value % 1);
		if(document.getElementById("item26.impuestoBolsasPlastica00").checked == true){
			if(dijit.byId("item26.cantidad").value % 1 > 0){
				mostrarMensaje("Cantidad invalida");
				return;
			}
		}
		
	
	
	//FIN PAS20191U210100075 - jsantivanez
	
		  var nbControl = dijit.byId("item26.botonAceptar");
      nbControl.setAttribute('disabled', true);
		  var nodeButton = nbControl.focusNode;
		  var mode = dojo.byId("item26.action").value;
      this.wait("Editando", "95px", 200);
	
	
	
  		var handler = dojo.io.iframe.send({
  			url: this.controller,
  			handleAs: "json",
  			sync: true,
  			timeout: 10000,
  			preventCache: true,
  			form: "item26.form"
  		});
		  handler.addCallback(dojo.hitch(this, function(res){
			    this.waitMessage.hide();
			   if(res.codeError == 0) {
        		store.fetchItemByIdentity({
        			identity: currentLine,
        			onItem: dojo.hitch(this, function(item){
					console.log(item);
        			store.setValue(item,'cantidad',dojo.byId("item26.cantidad").value );
        	  	store.setValue(item,'descuentos',dojo.byId("item26.descuentos").value );
        	  	store.setValue(item,'precioUnitario',dojo.byId("item26.precioUnitario").value );
				      store.setValue(item,'precioUnitarioOriginal',dojo.byId("item26.precioUnitario").value );
        	    //if (dojo.byId("item26.iscMonto").value != ""){	store.setValue(item,'iscMonto',dojo.byId("item26.iscMonto").value ); }//PASE PAS20201U210200016 Correccion 4
				if (dojo.byId("item26.iscMonto").value != ""){	store.setValue(item,'iscMonto',dijit.byId("item26.iscMonto").getValue()); }	//PASE PAS20201U210200016 Correccion 4		
        	  	if (dojo.byId("item26.precioConIGV").value != ""){	store.setValue(item,'igvMonto',dijit.byId("item26.precioConIGV").getValue() );}
        	  	store.setValue(item,'modificado',"1");
        	  	store.setValue(item,'importeVenta',dijit.byId("item26.importeVenta").getValue());
				
        		store.setValue(item,'icbPerMonto',dojo.byId("item26.impuestoICBPER").value );	//PAS20191U210100075
        			}),
        			onError: function(){}
        		});
					
			  	var grid = dijit.byId('ncCambioDetalles.ingreso-grid');
					grid.setStore(store);
					grid.update();
					this.closeDialogItem26();
			} else {
				nbControl.setAttribute('disabled', false);
				this.iconTooltipMessage(nodeButton, "icon-error-tooltip", res.messageError);
			}
		}));
		handler.addErrback(dojo.hitch(this, function(res) {
			nbControl.setAttribute('disabled', false);
			this.waitMessage.hide();
			this.iconTooltipMessage(nodeButton, "icon-error-tooltip", res.messageError);
		}));
		
		
	//INI PAS20191U210100075 - jsantivanez
		dijit.byId("item26.impuestoBolsasPlastica00").setAttribute('disabled', true);
		dijit.byId("item26.impuestoBolsasPlastica01").setAttribute('disabled', true);  
		dijit.byId("item26.impuestoICBPER").setAttribute('disabled', false);
	//FIN PAS20191U210100075 - jsantivanez
		nbControl.setAttribute('disabled', false);			

    dijit.hideTooltip(dojo.byId("item26.cantidad"));
    dijit.hideTooltip(dojo.byId("item26.precioUnitario"));
    dijit.hideTooltip(dojo.byId("item26.descuentos"));
    dijit.hideTooltip(dojo.byId("item26.iscMonto"));
    dijit.hideTooltip(dojo.byId("item26.importeVenta"));
	dijit.hideTooltip(dojo.byId("item26.impuestoICBPER")); //PAS20191U210100075
    },
    
    
    closeDialogItem26: function() {
    dijit.hideTooltip(dojo.byId("item26.cantidad"));
    		dijit.hideTooltip(dojo.byId("item26.precioUnitario"));
    dijit.hideTooltip(dojo.byId("item26.descuentos"));
    dijit.hideTooltip(dojo.byId("item26.iscMonto"));
    dijit.hideTooltip(dojo.byId("item26.importeVenta"));

		 this.dialogItem26.hide();
	  },
	  
	  
	    
	  //Error en descripcion
      editItem25: function(identificador) {	    
			store =dijit.byId('ncCambioDetalles.ingreso-grid').store;
        
		  store.fetchItemByIdentity({
		    identity: identificador,
		    onItem : function(item, request) {
		        row = item;		
            currentLine = identificador 	;		
		    },
		    onError : function(item, request) {
				mostrarMensaje("Ocurrio un error al ubicar el documento");
				return;				
		    }
		   });
		
		    bCargando= true;
					dijit.byId("item25.botonAceptar").attr('disabled', false);
							
			dojo.byId("item25.descripcionOriginal").value =store.getValue(row, "descripcion");			
		  var descripcionItem=dojo.trim(store.getValue(row, "descripcion"));
		  var descripcionItemNueva=dojo.trim(store.getValue(row, "descripcionNueva"));
		  var buscar="[*****] ";
		  var posicion = descripcionItem.search(buscar);
		  if (posicion !=-1 ){
         //descripcionItem = descripcionItem.replace("***** BONIFICACION *****", "");
			 	 //descripcionItemNueva = descripcionItemNueva.replace("***** BONIFICACION *****", "");	
         descripcionItem = descripcionItem.substring(0, posicion-4);
			 	 descripcionItemNueva = descripcionItemNueva.substring(0, posicion-4);		 	 
       }
					this.dialogItem25.attr('title', "Captura NC - Error en la descripci\u00F3n");
					dojo.byId("item25.idItem").value = currentLine ; //store.getValue(row, "identificador");
	 				dijit.byId("item25.unidadMedida").setValue(store.getValue(row, "unidadMedidaDesc"));						
					dijit.byId("item25.cantidad").setValue(store.getValue(row, "cantidad"), false);
					dijit.byId("item25.descripcionDice").setValue(descripcionItem);
				
				
					if (store.getValue(row, "modificado") =="0"){
					  	dijit.byId("item25.descripcionDebeDecir").attr('value',"");
				  }else{				      
              dijit.byId("item25.descripcionDebeDecir").attr('value',descripcionItemNueva);  		 			
        
          }
				  bCargando= false;
					this.dialogItem25.show();		
		},
				
     
		acceptDialogItem25: function() {
      var moneda = this.facturaBean.codigoMoneda;
		  //var moneda = this.changeMoneda(this.facturaBean.codigoMoneda);
    	if (dijit.byId("item25.descripcionDebeDecir").getValue() == "" ) {
				var node = dijit.byId("item26.descripcionDebeDecir");
				this.iconTooltipMessage(node.focusNode,"icon-ok-tooltip", "Debe consignarse la nueva descripci\u00F3n.");
				return;
			}	
      
	
  		var descripcionItemOriginal=dojo.trim(dojo.byId("item25.descripcionOriginal").value) ;
		  var descripcionItemNueva= dijit.byId("item25.descripcionDebeDecir").getValue();
		  descripcionItemNueva = descripcionItemNueva.toUpperCase();
		  var buscar="[*****] ";
		  var posicion = descripcionItemOriginal.search(buscar);
		  if (posicion !=-1 ){
			 	 descripcionItemNueva = descripcionItemNueva + descripcionItemOriginal.substring(posicion-4);	
			 	 dijit.byId("item25.descripcionDebeDecir").setValue(descripcionItemNueva);
			 	 dijit.byId("item25.descripcionDice").setValue(descripcionItemOriginal);
       }		
    //   mostrarMensaje("["+ descripcionItemNueva + "]");
//mostrarMensaje("["+ descripcionItemOriginal + "]");       
      if (descripcionItemNueva == descripcionItemOriginal){
          var node = dijit.byId("item25.descripcionDebeDecir");
   				this.iconTooltipMessage(node.focusNode,"icon-ok-tooltip", " 	Contenido del campo Debe Decir debe ser diferente al contenido del campo Dice");
  				return;   
      }
		  var nbControl = dijit.byId("item25.botonAceptar");
      nbControl.setAttribute('disabled', true);
		  var nodeButton = nbControl.focusNode;
		  var mode = dojo.byId("item25.action").value;
      this.wait("Editando", "95px", 200);
	
	
	
  		var handler = dojo.io.iframe.send({
  			url: this.controller,
  			handleAs: "json",
  			sync: true,
  			timeout: 10000,
  			preventCache: true,
  			form: "item25.form"
  		});
		  handler.addCallback(dojo.hitch(this, function(res){
			    this.waitMessage.hide();
			   if(res.codeError == 0) {
        		store.fetchItemByIdentity({
        			identity: currentLine,
        			onItem: dojo.hitch(this, function(item){
        	  	store.setValue(item,'descripcionNueva',dojo.byId("item25.descripcionDebeDecir").value );
        	  	store.setValue(item,'modificado',"1");
       			
        			}),
        			onError: function(){}
        		});
					
			  	var grid = dijit.byId('ncCambioDetalles.ingreso-grid');
					grid.setStore(store);
					grid.update();
					this.closeDialogItem25();
			} else {
				nbControl.setAttribute('disabled', false);
				this.iconTooltipMessage(nodeButton, "icon-error-tooltip", res.messageError);
			}
		}));
		handler.addErrback(dojo.hitch(this, function(res) {
			nbControl.setAttribute('disabled', false);
			this.waitMessage.hide();
			this.iconTooltipMessage(nodeButton, "icon-error-tooltip", res.messageError);
		}));
		
		nbControl.setAttribute('disabled', false);			

    dijit.hideTooltip(dojo.byId("item25.descripcionDebeDecir"));
   
    },
    
    closeDialogItem25: function() {
		 this.dialogItem25.hide();
	  },
	  
	  verPreliminarNC:function(tipo){
	    //Validamos que por lo menos se haya modificado un item
      var grilla =dijit.byId('ncCambioDetalles.ingreso-grid');
      var datos =grilla.store._arrayOfAllItems;
      var filas = grilla.store._arrayOfAllItems.length;
      var numModificados=0;
      
      //PAS20201U210100230 INI -opv	Modificado   
	/* for (i=0; i< filas;i++){
			var fila = grilla.getItem(i);
			var valorModif= grilla.store.getValue(fila, "modificado");
			if (valorModif==1){ numModificados ++;}
		}      
	  
		  if (numModificados == 0){
			  mostrarMensaje("Debe seleccionar por lo menos un Item de la FE, y consignar los datos de la Nota de Cr&eacute;dito.");
			  return;
		  }
		this.content.setHref(this.controller + "?action=preliminarComprobante&TipoNotaCred=" + tipo + "&factura=" + dijit.byId("pantallaInicial.numeroFE").value + "&motivo=" + dijit.byId("pantallaInicial.motivoEmisionNC").value);	 */
	  
	  if ( tipo == "29") {		
		for (i=0; i< filas;i++){
			if(grilla.store._itemsByIdentity[i] != undefined){				
				//NECESITA SER VALIDADO DE ESTA FORMA PARA NO DAR ERROR					
			   var valorModif= grilla.store._itemsByIdentity[i].modificado;
			   if (valorModif==1){ numModificados ++;}				
			}else{				
				mostrarMensaje("Debe registrar al menos 1 cuota.");																													  
				return;
			}			
		}	
		
		 var montoNetoModificado=true;
		 if  (Number(dijit.byId("infCred.montoNetoPendiente").value)==Number(dijit.byId("infCred.montoNetoPendienteOriginal").value) ){
		   montoNetoModificado=false
		 }	
		 if (numModificados == 0 && montoNetoModificado==false){
																		
		   mostrarMensaje("Debe modificar al menos un campo del comprobante para continuar.");
																													  
			 return;
		 }		  
		 this.infCreditoRegistrar();	//href preliminarComprobante esta dentro del metodo	  
								  
	 }else if(tipo == "28"){
		 for (i=0; i< filas;i++){
			//NECESITA SER VALIDADO DE ESTA FORMA PARA NO DAR ERROR
		   var valorModif= grilla.store._itemsByIdentity[i].modificado;
		   if (valorModif==1){ numModificados ++;}
		}   
		 if (numModificados == 0){
			 mostrarMensaje("Debe modificar al menos un campo del comprobante para continuar.");																													   
			 return;
		 }	
		 this.content.setHref(this.controller + "?action=preliminarComprobante&TipoNotaCred=" + tipo + "&factura=" + dijit.byId("pantallaInicial.numeroFE").value + "&motivo=" + dijit.byId("pantallaInicial.motivoEmisionNC").value);	
	 }	  
	 else {
		for (i=0; i< filas;i++){
		   var fila = grilla.getItem(i);
		   var valorModif= grilla.store.getValue(fila, "modificado");
		   if (valorModif==1){ numModificados ++;}
	   }      
		 if (numModificados == 0){
			 mostrarMensaje("Debe seleccionar por lo menos un Item de la FE, y consignar los datos de la Nota de Cr\u00e9dito.");
			 return;
		 }
	   this.content.setHref(this.controller + "?action=preliminarComprobante&TipoNotaCred=" + tipo + "&factura=" + dijit.byId("pantallaInicial.numeroFE").value + "&motivo=" + dijit.byId("pantallaInicial.motivoEmisionNC").value);	
	 }	
	//PAS20201U210100230 INI -opv	  
	},
	//INI PAS20191U210100075
	viewCheckedImpuestoBolsaPlastica: function() {
		var valOpcionImpuestoBolsaPlastica = this.getValorOpcionImpuestoBolsaPlastica();
		   	console.log("check " + valOpcionImpuestoBolsaPlastica);
		
		if (valOpcionImpuestoBolsaPlastica != "IBP00"){
			dojo.byId("item26.tasaBolsaGlobal").value = "0";
			this.updateItemAmount26();
			
		}else{
			//dojo.byId("item26.tasaBolsaGlobal").value = dojo.byId("item26.tasaBolsaGlobal2").value;
			this.updateItemAmount26();
		}
			
	},
	getValorOpcionImpuestoBolsaPlastica: function() {
		var valOpcionImpuestoBolsaPlastica="";
		for(i = 0; i < 2; i++) {
			//if(dijit.byId("item.subTipoTB0" + i).getValue() != false) {
			if(document.getElementById("item26.impuestoBolsasPlastica0"+i).checked == true) {
				valOpcionImpuestoBolsaPlastica = document.getElementById("item26.impuestoBolsasPlastica0"+i).value;
			}
		}
		return valOpcionImpuestoBolsaPlastica;
	},  	
	getValorOpcionImpuestoBolsaPlastica27: function() {
		var valOpcionImpuestoBolsaPlastica="";
		for(i = 0; i < 2; i++) {
			//if(dijit.byId("item.subTipoTB0" + i).getValue() != false) {
			if(document.getElementById("item27.impuestoBolsasPlastica0"+i).checked == true) {
				valOpcionImpuestoBolsaPlastica = document.getElementById("item26.impuestoBolsasPlastica0"+i).value;
			}
		}
		return valOpcionImpuestoBolsaPlastica;
	},  	
  //FIN PAS20191U210100075
  verPreliminarNCContin:function(tipo){
	  var serie = document.getElementById("serie").value;
		var numero = document.getElementById("numero").value;
		var idSerie = document.getElementById("idSerie").value;
	    //Validamos que por lo menos se haya modificado un item
      var grilla =dijit.byId('ncCambioDetalles.ingreso-grid');
      var datos =grilla.store._arrayOfAllItems;
      var filas = grilla.store._arrayOfAllItems.length;
      var numModificados=0;
      
      for (i=0; i< filas;i++){
        var fila = grilla.getItem(i);
        var valorModif= grilla.store.getValue(fila, "modificado");
        if (valorModif==1){ numModificados ++;}
      }
      
      if (numModificados == 0){
          mostrarMensaje("Debe seleccionar por lo menos un Item de la FE, y consignar los datos de la Nota de Cr\u00E9dito.");
          return;
      }
			this.content.setHref(this.controller + "?action=preliminarComprobanteContin&TipoNotaCred=" + tipo + "&factura=" + dijit.byId("pantallaInicial.numeroFE").value + "&motivo=" + dijit.byId("pantallaInicial.motivoEmisionNC").value+"&idSerie="+idSerie+"&serie="+serie+"&numero="+numero);	
  },
  
  
  	backModificaItems: function() {

			this.content.setHref(this.controller + "?action=regresarCambiarDetallesNC");
      
	  },

	//PAS20201U210100230 INI -opv  
	backModificaItemsFactoring: function() {
		this.content.setHref(this.controller + "?action=regresarCambiarDetallesNCFactoring");      
	},
	//PAS20201U210100230 FIN -opv
	  
	valorUnitario: function(valor, rowindex) {
	var valor2 = valor.replace(',','');

	    if (valor2<0){
	    return "";
      }else{
      return valor;
      } 
	
	},
	
		  changeMoneda: function(moneda){
       if(moneda=="XEU"){
		    return "EUR";
       }
       return moneda;
    }, 
	  onStyleRow :function(inRow){
      var store = dijit.byId('ncCambioDetalles.ingreso-grid').store;
       var item = store._arrayOfAllItems[ inRow.index ];
       if (item!=null){
           var modif = store.getValue(item, "modificado");
          if( modif == "1" ) {
                    with (inRow) {
                  
                      inRow.customStyles += ' color: blue; font-weight: bold';
               } 
          }
       }   
    },
    
		closeDocument: function() {
      dijit.hideTooltip(dojo.byId("numeroComprobante"));
      dijit.hideTooltip(dojo.byId("pantallaInicial.numeroFE"));
      dijit.hideTooltip(dojo.byId("pantallaInicial.numeroNuevaFE" ));
      dijit.hideTooltip(dojo.byId("pantallaInicial.descuentoGlobalNC"));
      dijit.hideTooltip(dojo.byId("pantallaInicial.ISCNC" ));
           
      this.content.onLoad = dojo.hitch(this, function(){
				this.initContent();
			});
			this.content.setHref(this.controller + "?action=mostrarPantallaInicial&mode=hidden");
	  },
	
         showHiddenDiv: function(node,show) {
	         	if (show == true) { //Mostrar
		 	       node.style.display = "";
	          } else { //Ocultar
		          	node.style.display = "none";
	         	}
          }
    // INI PAS20211U210100040  AHUISA
    ,
    validarFechaEmision: function(validarFechaIgvVigente){
      response = true;
      if (dijit.byId("pantallaInicial.fechaEmision").getValue() !=null && dijit.byId("pantallaInicial.fechaEmision").getValue() !=""){
        var fechaEmision = dojo.date.locale.format(dijit.byId("pantallaInicial.fechaEmision").getValue(), {datePattern: "yyyyMMdd", selector: "date"});
        
        var diasAnticipadosEmisionComprobante = dojo.number.parse(dojo.byId("pantallaInicial.diasAnticipadosEmisionComprobante").value);
        var parts =dojo.byId("pantallaInicial.fechaActual").value.split('-');
        var fechaActualRecuperado = new Date(parts[0],parts[1]-1,parts[2]);
        var fechaAnteriorRecuperado = new Date(parts[0],parts[1]-1,parts[2]);
        fechaAnteriorRecuperado.setDate(fechaAnteriorRecuperado.getDate() - 2);
        
        var fechaActual  = dojo.date.locale.format(fechaActualRecuperado, {datePattern: "yyyyMMdd", selector: "date"});
        var fechaAnterior = dojo.date.locale.format(fechaAnteriorRecuperado, {datePattern: "yyyyMMdd", selector: "date"});
        
        if (fechaEmision < fechaAnterior || fechaEmision > fechaActual){
          this.iconTooltipMessageFec("pantallaInicial.fechaEmision", "icon-ok-tooltip", "Fecha de Emisi\u00F3n solo puede ser entre dos d\u00EDas antes y el d\u00EDa de hoy.");
          response = false;
        }
      }
      return response;
    }
    // FIN PAS20211U210100040  AHUISA
    });
	
	
}
