
//PAS20211U210700098-Chrome-Inicio
//csanchezpe: se agrega accion cancelar para el caso de los else
function mostrarMensaje(msj, tipo = 1 )  {

		if ( dijit.byId('dlgMensaje') != undefined ) {
				require(["dojo/dom-construct"], function(domConstruct){
				  dijit.byId('dlgBtnAceptar').destroy();
				  dijit.byId('dlgMensaje').destroy();
				});
		}

		var aceptarDialog = new dijit.Dialog({ id: 'dlgMensaje', title: "Mensaje" });
		var respCallback = function(mouseEvent) {
				aceptarDialog.hide();
		};

		dojo.connect(aceptarDialog,"onCancel",function(){
				aceptarDialog.hide();
		});

		switch (tipo) {
				case 0: // OK
						questionDiv = dojo.create("div", {innerHTML:"<table><tr style='height:70px'><td><img src='/a/imagenes/pase_embarque.gif' border='0' alt=''></td><td style='padding-left: 5px;'>" + msj + "</td></tr></table>"});
						break;
				case 1: // INFO
						questionDiv = dojo.create("div", {innerHTML:"<table><tr style='height:70px'><td><img src='/a/imagenes/sigad/acciones/advertencia.gif' border='0' alt=''></td><td style='padding-left: 5px;'>" + msj + "</td></tr></table>"});
						break;
				case 2: // WARNING
						questionDiv = dojo.create("div", {innerHTML:"<table><tr style='height:70px'><td><img src='/a/imagenes/sigad/acciones/advertencia.gif' border='0' alt=''></td><td style='padding-left: 5px;'>" + msj + "</td></tr></table>"});
						break;
				case 3: // ERROR
						questionDiv = dojo.create("div", {innerHTML:"<table><tr style='height:70px'><td><img src='/a/imagenes/pase_no_embarque.gif' border='0' alt=''></td><td style='padding-left: 5px;'>" + msj + "</td></tr></table>"});
						break;
		}

		var aceptarButton = new dijit.form.Button( { label: 'Aceptar', id: 'dlgBtnAceptar', onClick: respCallback });
		var centroDiv = dojo.create('div', { style: { margin: "auto", textAlign: "center"} } );

		aceptarDialog.containerNode.appendChild(questionDiv);
		aceptarDialog.containerNode.appendChild(centroDiv);
		centroDiv.appendChild(aceptarButton.domNode);
		aceptarDialog.show();
}
//
//PAS20211U210700098-Chrome-Inicio
//csanchezpe: se agrega accion cancelar para el caso de los else
function mostrarMensajeConfirmacion ( msj, accionBtnAceptar, accionBtnCancelar = function() {} )  {

		if ( dijit.byId('dlgMensajeConfirmacion') != undefined ) {
				require(["dojo/dom-construct"], function(domConstruct){
				  dijit.byId('dlgBtnAceptarConfirm').destroy();
				  dijit.byId('dlgBtnCancelarConfirm').destroy();
				  dijit.byId('dlgMensajeConfirmacion').destroy();
				});
		}

		var dlgConfirmacion = new dijit.Dialog({ id: 'dlgMensajeConfirmacion', title: "Confirmar" });

		var respCallAceptar = function() {
			accionBtnAceptar();
			dlgConfirmacion.hide();
		};

		var respCallCancelar = function() {
			accionBtnCancelar();
			dlgConfirmacion.hide();
		};

		dojo.connect(dlgConfirmacion, "onCancel", function() {
			dlgConfirmacion.hide();
		});

		questionDiv = dojo.create("div", {innerHTML:"<table><tr style='height:70px'><td><img src='/a/imagenes/icons/questionMark32px.png' border='0' alt=''></td><td style='padding-left: 5px;'>" + msj + "</td></tr></table>"});

		var aceptarButton = new dijit.form.Button( { label: 'Aceptar', id: 'dlgBtnAceptarConfirm', onClick: respCallAceptar });
		var cancelarButton = new dijit.form.Button( { label: 'Cancelar', id: 'dlgBtnCancelarConfirm', onClick: respCallCancelar });

		var centroDiv = dojo.create('div', { style: { margin: "auto", textAlign: "center"} } );

		dlgConfirmacion.containerNode.appendChild(questionDiv);
		dlgConfirmacion.containerNode.appendChild(centroDiv);
		centroDiv.appendChild(aceptarButton.domNode);
		centroDiv.appendChild(cancelarButton.domNode);
		dlgConfirmacion.show();
}

//PAS20211U210700098-Fin
/**
* Inicio : Codigo JS para el RUM de www.site24x7.com
*/
var rumMOKey='50f24c93267cea63d8d794c54155b65a';
/**
* Inicio : Codigo JS para el RUM de www.site24x7.com
*/
var rumMOKey='50f24c93267cea63d8d794c54155b65a';
(function(){
if(window.performance && window.performance.timing && window.performance.navigation) {
        var site24x7_rum_beacon=document.createElement('script');
        site24x7_rum_beacon.async=true;
        site24x7_rum_beacon.setAttribute('src','//static.site24x7rum.com/beacon/site24x7rum-min.js?appKey='+rumMOKey);
        document.getElementsByTagName('head')[0].appendChild(site24x7_rum_beacon);
}
})(window)

/**
* Fin : Codigo JS para el RUM de www.site24x7.com
*/

/**
 * Boleta.js - JavaScript de la Boleta de venta Electronica.
 * Since: 05-01-2015
 * ResponseBean : codeError; messageError; data;
 */

if (!dojo._hasResource["servicio.registro.comppago.see.Boleta"]) {
	dojo._hasResource["servicio.registro.comppago.see.Boleta"] = true;
	dojo.provide("servicio.registro.comppago.see.Boleta");
	dojo.require("dojo.data.ItemFileWriteStore");
	dojo.require("dojo.data.ItemFileReadStore");
	dojo.require("dojo.io.iframe");
	dojo.require("dojox.validate.regexp");
	dojo.declare("servicio.registro.comppago.see.Boleta", null, {
	
	k : null,
	p : null,

	store : null,
	beanDatosCP : null,
	controller : "emitir.do",
	indRegitroGR : null,
	self : null,
	otherDocStore : null,
	ptoemiStore : null,
    nrus:null,//PAS20191U210100075
	constructor : function () {},

	igv10: 0.10,//IGV10-JRGS
	tasa10: 10,//IGV10-JRGS
	tasa18: 18,//IGV10-JRGS					 		   
	initialize : function () {
		
		this.content = dijit.byId("content");
		
		this.dialogItem = dijit.byId("dialogItem");
		this.dialogDocsLinked = dijit.byId("dialogDocsLinked");
		this.dialogInfAdicional = dijit.byId("dialogInfAdicional");
		this.dialogInfTrasladoBienes = dijit.byId("dialogInfTrasladoBienes");
		this.dialogPuntoPartida = dijit.byId("dialogPuntoPartida");
		this.dialogPuntoLlegada = dijit.byId("dialogPuntoLlegada");
		this.dialogEstablecimientoEmisor = dijit.byId("dialogEstablecimientoEmisor");
		this.dialogDireccionCliente = dijit.byId("dialogDireccionCliente");
		this.waitMessage = dijit.byId("waitMessage");
		this.indRegitroGR = 0;
	},

	initContent : function (param) {

		this.initialize();

		self = this;
		dijit.focus(dojo.byId("boleta.numeroDocumento"));

		dijit.byId("inicio.subTipoEE00").setChecked("checked");
		dijit.byId("inicio.subTipoEE00").setValue("0");
		dijit.byId("inicio.subTipoND00").setChecked("checked");
		dijit.byId("inicio.subTipoND00").setValue("0");
		dijit.byId("inicio.subTipoIM00").setChecked("checked");
		dijit.byId("inicio.subTipoIM00").setValue("IM00");
		dijit.byId("inicio.subTipoDE00").setChecked("checked");
		dijit.byId("inicio.subTipoDE00").setValue("DE00");
		dojo.byId("global.opcionEstablecimientoEmisorSeleccionado").value = "";
		dojo.byId("global.opcionEstablecimientoEmisorIdentifica").value = "";
		this.showOpcionesExportacion(0);
	},

	isValidRuc : function (ruc) {
		ruc = dojo.trim(ruc);
		if (!isNaN(ruc)) {
			if (ruc.length == 8) {
				suma = 0;
				for (i = 0; i < ruc.length - 1; i++) {
					digito = ruc.charAt(i) - '0';
					if (i == 0)
						suma += (digito * 2);
					else
						suma += (digito * (ruc.length - i));
				}
				resto = suma % 11;
				if (resto == 1)
					resto = 11;
				if (resto + (ruc.charAt(ruc.length - 1) - '0') == 11) {
					return true;
				}
			} else if (ruc.length == 11) {
				suma = 0;
				x = 6;
				for (i = 0; i < ruc.length - 1; i++) {
					if (i == 4)
						x = 8;
					digito = ruc.charAt(i) - '0';
					x--;
					if (i == 0)
						suma += (digito * x);
					else
						suma += (digito * x);
				}
				resto = suma % 11;
				resto = 11 - resto;
				if (resto >= 10)
					resto = resto - 10;
				if (resto == ruc.charAt(ruc.length - 1) - '0') {
					return true;
				}
			}
		}
		return false;
	},

	//PAS20175E210300029
	asignarIGVDiferente : function (igvPorcentaje, mostrarMensajes, fechaMinIgvPorcentaje, fechaMaxIgvPorcentaje) {
		this.wait("Asignando", "110px", 200);
		var handler = dojo.xhrGet({
				preventCache : false,
				url : this.controller + "?action=asignarIGVDiferente&igvDiferente=" + igvPorcentaje,
				handleAs : "json",
				sync : true,
				timeout : 10000
			});
		handler.addCallback(dojo.hitch(this, function (response) {
				if (response.codeError == 0) {
					igvPorcentaje = response.data;
				} else {
					mostrarMensaje(response.messageError);
				}
			}));
		handler.addErrback(function (response) {
			mostrarMensaje("Ocurri\u00F3 un error al recuperar la validaci\u00F3n del periodo de emisi\u00F3n del comprobante.");
		});

		dojo.byId("global.fechaMinIgvPorcentaje").value = fechaMinIgvPorcentaje;
		dojo.byId("global.fechaMaxIgvPorcentaje").value = fechaMaxIgvPorcentaje;

		dojo.byId("global.igvPorcentajeInicial").value = igvPorcentaje / 100;
		dojo.byId("global.igvPorcentaje").value = igvPorcentaje / 100;
		//document.getElementById("tablaIngreso.labelIgvPorcentaje").innerHTML = "IGV (" + igvPorcentaje + "%)";IGV10-JRGS

		if (mostrarMensajes) {
			this.iconTooltipMessage("boleta.fechaEmision", "icon-ok-tooltip", "La fecha de emisi\u00F3n seleccionada tiene otro valor de IGV (" + igvPorcentaje + ").");
		}
	},

	//PAS20175E210300029
	setFechaEmisionHoy : function () {
		//dijit.byId("boleta.fechaEmision").setValue(new Date());
		var parts = dojo.byId("boleta.fechaActual").value.split('-');
		var fechaActualRecuperado = new Date(parts[0], parts[1] - 1, parts[2]);
		dijit.byId("boleta.fechaEmision").setValue(fechaActualRecuperado);
	},

	//PAS20175E210300029
	setFechaEmisionPrevia : function () {
		dojo.byId("global.fecEmisionChange").value = "0";

		if (dojo.byId("global.fecEmisionPrevia").value == "") {
			this.setFechaEmisionHoy();
		} else {
			var fechaActualRecuperado = new Date(new Date(dojo.byId("global.fecEmisionPrevia").value));
			dijit.byId("boleta.fechaEmision").setValue(fechaActualRecuperado);
		}
	},

	//PAS20175E210300029
	validarFechaEmision : function (validarFechaIgvVigente) {
		localStorage.removeItem('data'); //DAG PAS20221U210700299
		response = true;
		if (dojo.byId("global.fecEmisionChange").value == "1") {
			if (dijit.byId("boleta.fechaEmision").getValue() != null && dijit.byId("boleta.fechaEmision").getValue() != "") {
				var fechaEmision = dojo.date.locale.format(dijit.byId("boleta.fechaEmision").getValue(), {
						datePattern : "yyyyMMdd",
						selector : "date"
					});
				//var fechaEmision = "20161201";
				dojo.byId("global.fecEmision").value = dojo.date.locale.format(dijit.byId("boleta.fechaEmision").getValue(), {
						datePattern : "MM/dd/yyyy",
						selector : "date"
					});

				var diasAnticipadosEmisionComprobante = dojo.number.parse(dojo.byId("factura.diasAnticipadosEmisionComprobante").value);
				var parts = dojo.byId("boleta.fechaActual").value.split('-');
				var fechaActualRecuperado = new Date(parts[0], parts[1] - 1, parts[2]);

				//var fechaActual  = dojo.date.locale.format(new Date(), {datePattern: "yyyyMMdd", selector: "date"});
				//var fechaAnterior = dojo.date.locale.format(dojo.date.add(new Date(),"day",-2), {datePattern: "yyyyMMdd", selector: "date"});
				var fechaActual = dojo.date.locale.format(fechaActualRecuperado, {
						datePattern : "yyyyMMdd",
						selector : "date"
					});
				var fechaAnterior = dojo.date.locale.format(dojo.date.add(fechaActualRecuperado, "day", diasAnticipadosEmisionComprobante), {
						datePattern : "yyyyMMdd",
						selector : "date"
					});

				if (fechaEmision < fechaAnterior || fechaEmision > fechaActual) {
					this.iconTooltipMessage("boleta.fechaEmision", "icon-ok-tooltip", "Fecha de Emisi\u00F3n solo puede ser entre dos d\u00EDas antes y el d\u00EDa de hoy.");
					response = false;
				} else if (fechaActual.substring(4, 6) > fechaEmision.substring(4, 6)) {
					var noPresentaLibrosPeriodo = 0;

					this.wait("Consultando", "110px", 200);
					var handler = dojo.xhrGet({
							preventCache : false,
							url : this.controller + "?action=recuperarNoPresentaLibrosPeriodo&anio=" + fechaEmision.substring(0, 4) + "&mes=" + fechaEmision.substring(4, 6),
							handleAs : "json",
							sync : true,
							timeout : 10000
						});
					handler.addCallback(dojo.hitch(this, function (response) {
							if (response.codeError == 0) {
								noPresentaLibrosPeriodo = response.data;
							} else {
								mostrarMensaje(response.messageError);
							}
						}));
					handler.addErrback(function (response) {
						mostrarMensaje("Ocurrio un error al recuperar la validaci\u00F3n del periodo de emisi\u00F3n del comprobante.");
					});

					this.waitMessage.hide();
					if (noPresentaLibrosPeriodo != "1") {
						response = false;
					}
				}

				if ((response) && (validarFechaIgvVigente != null) && (validarFechaIgvVigente)) {
					parts = dojo.byId("global.fechaMinIgvPorcentaje").value.split('/');
					var fechaMinIgv = parts[2] + parts[1] + parts[0];

					if (fechaEmision < fechaMinIgv) {
						this.wait("Consultando", "110px", 200);

						var handler = dojo.xhrGet({
								preventCache : false,
								url : this.controller + "?action=recuperarIgvConFecha&anio=" + fechaEmision.substring(0, 4) + "&mes=" + fechaEmision.substring(4, 6) + "&dia=" + fechaEmision.substring(6, 8),
								handleAs : "json",
								sync : true,
								timeout : 10000
							});
						handler.addCallback(dojo.hitch(this, function (response) {
								if (response.codeError == 0) {
									var row = eval("(" + response.data + ")");
									var igvPorcentajeGlobalAnterior = row.igvVigente;
									var fechaMinIgvPorcentaje = row.fechaMinIgvPorcentaje;
									var fechaMaxIgvPorcentaje = row.fechaMaxIgvPorcentaje;

									var grilla = dijit.byId("boleta.ingreso-grid");
									var filas = grilla.rowCount;

									if (filas > 0) {
										var mensajeCambioIGV = "La fecha de emisi\u00F3n seleccionada tiene otro valor de IGV (" + igvPorcentajeGlobalAnterior + "), tendr\u00E1 que volver a ingresar los items \u00BFDesea Continuar?";
										mostrarMensajeConfirmacion(mensajeCambioIGV, dojo.hitch(this, function(){
											this.eliminarItemsAll();
											this.asignarIGVDiferente(igvPorcentajeGlobalAnterior, true, fechaMinIgvPorcentaje, fechaMaxIgvPorcentaje);
										}), dojo.hitch(this, function(){
											this.setFechaEmisionPrevia();
											response = false;
										}));
										//if (confirm(mensajeCambioIGV)) {
										//	this.eliminarItemsAll();
										//	this.asignarIGVDiferente(igvPorcentajeGlobalAnterior, true, fechaMinIgvPorcentaje, fechaMaxIgvPorcentaje);
										//} else {
										//	this.setFechaEmisionPrevia();
										//	response = false;
										//}
									} else {
										this.asignarIGVDiferente(igvPorcentajeGlobalAnterior, true, fechaMinIgvPorcentaje, fechaMaxIgvPorcentaje);
									}
								} else {
									mostrarMensaje(response.messageError);
								}
							}));
						handler.addErrback(function (response) {
							mostrarMensaje("Ocurrio un error al recuperar la validaci\u00F3n del periodo de emisi\u00F3n del comprobante.");
						});

						this.waitMessage.hide();
					} else if (dojo.byId("global.fechaMaxIgvPorcentaje").value != "") {
						parts = dojo.byId("global.fechaMaxIgvPorcentaje").value.split('/');
						var fechaMaxIgv = parts[2] + parts[1] + parts[0];

						if (fechaEmision > fechaMaxIgv) {
							this.wait("Consultando", "110px", 200);

							var handler = dojo.xhrGet({
									preventCache : false,
									url : this.controller + "?action=recuperarIgvConFecha&anio=" + fechaEmision.substring(0, 4) + "&mes=" + fechaEmision.substring(4, 6) + "&dia=" + fechaEmision.substring(6, 8),
									handleAs : "json",
									sync : true,
									timeout : 10000
								});
							handler.addCallback(dojo.hitch(this, function (response) {
									if (response.codeError == 0) {
										var row = eval("(" + response.data + ")");
										var igvPorcentajeGlobalAnterior = row.igvVigente;
										dojo.byId("global.fechaMinIgvPorcentaje").value = row.fechaMinIgvPorcentaje;
										dojo.byId("global.fechaMaxIgvPorcentaje").value = row.fechaMaxIgvPorcentaje;

										this.iconTooltipMessage("boleta.fechaEmision", "icon-ok-tooltip", "La fecha de emisi\u00F3n seleccionada tiene otro valor de IGV (" + igvPorcentajeGlobalAnterior + ").");
										var grilla = dijit.byId("boleta.ingreso-grid");
										var filas = grilla.rowCount;

										if (filas > 0) {
											var mensajeCambioIGV = "La fecha de emisi\u00F3n seleccionada tiene otro valor de IGV (" + igvPorcentajeGlobalAnterior + "), tendr\u00E1 que volver a ingresar los items \u00BFDesea Continuar?";
											mostrarMensajeConfirmacion(mensajeCambioIGV, dojo.hitch(this, function(){
												this.asignarIGVDiferente(igvPorcentajeGlobalAnterior);
												this.eliminarItemsAll();
											}), dojo.hitch(this, function(){
												this.setFechaEmisionPrevia();
												response = false;
											}));
											//if (confirm(mensajeCambioIGV)) {
											//	this.asignarIGVDiferente(igvPorcentajeGlobalAnterior);
											//	this.eliminarItemsAll();
											//} else {
											//	this.setFechaEmisionPrevia();
											//	response = false;
											//}
										} else {
											this.asignarIGVDiferente(igvPorcentajeGlobalAnterior);
										}
									} else {
										mostrarMensaje(response.messageError);
									}
								}));
							handler.addErrback(function (response) {
								mostrarMensaje("Ocurri\u00F3 un error al recuperar la validaci\u00F3n del periodo de emisi\u00F3n del comprobante.");
							});

							this.waitMessage.hide();
						}
					}
				}

				if (response) {
					dojo.byId("global.fecEmisionPrevia").value = dojo.date.locale.format(dijit.byId("boleta.fechaEmision").getValue(), {
							datePattern : "MM/dd/yyyy",
							selector : "date"
						});
				}
			} else {
				this.iconTooltipMessage("boleta.fechaEmision", "icon-ok-tooltip", "Debe registrar la Fecha de Emisi\u00F3n.");
				response = false;
			}
		} else {
			dojo.byId("global.fecEmisionChange").value = "1";
		}
		return response;
	},

	validarFechaEmisionContin : function (validarFechaIgvVigente) {
		localStorage.removeItem('data'); //DAG PAS20221U210700299
		response = true;
		if (dojo.byId("global.fecEmisionChange").value == "1") {
			if (dijit.byId("boleta.fechaEmision").getValue() != null && dijit.byId("boleta.fechaEmision").getValue() != "") {
				var fechaEmision = dojo.date.locale.format(dijit.byId("boleta.fechaEmision").getValue(), {
						datePattern : "yyyyMMdd",
						selector : "date"
					});
				//var fechaEmision = "20161201";
				dojo.byId("global.fecEmision").value = dojo.date.locale.format(dijit.byId("boleta.fechaEmision").getValue(), {
						datePattern : "MM/dd/yyyy",
						selector : "date"
					});

				var diasAnticipadosEmisionComprobante = dojo.number.parse(dojo.byId("factura.diasAnticipadosEmisionComprobante").value);
				var parts = dojo.byId("boleta.fechaActual").value.split('-');
				var fechaActualRecuperado = new Date(parts[0], parts[1] - 1, parts[2]);

				//var fechaActual  = dojo.date.locale.format(new Date(), {datePattern: "yyyyMMdd", selector: "date"});
				//var fechaAnterior = dojo.date.locale.format(dojo.date.add(new Date(),"day",-2), {datePattern: "yyyyMMdd", selector: "date"});
				var fechaActual = dojo.date.locale.format(fechaActualRecuperado, {
						datePattern : "yyyyMMdd",
						selector : "date"
					});
				var fechaAnterior = dojo.date.locale.format(dojo.date.add(fechaActualRecuperado, "day", diasAnticipadosEmisionComprobante), {
						datePattern : "yyyyMMdd",
						selector : "date"
					});
				var fechaActualAdd2 = dojo.date.locale.format(dojo.date.add(new Date(), "day", 2), {
						datePattern : "yyyyMMdd",
						selector : "date"
					});
				if (fechaEmision > fechaActualAdd2) {
					this.iconTooltipMessage("boleta.fechaEmision", "icon-ok-tooltip", "Fecha de Emisi\u00F3n solo puede ser dos d\u00EDas despues del d\u00EDa de hoy.");
					response = false;
				}
				/* PAS20181U210300223 - contingencia no valida si el libro fue presentado
				else if (fechaActual.substring(4,6) > fechaEmision.substring(4,6)){
				var noPresentaLibrosPeriodo = 0;

				this.wait("Consultando", "110px", 200);
				var handler = dojo.xhrGet({
				preventCache:  false,
				url: this.controller + "?action=recuperarNoPresentaLibrosPeriodo&anio=" + fechaEmision.substring(0,4) + "&mes=" + fechaEmision.substring(4,6),
				handleAs: "json",
				sync: true,
				timeout: 10000
				});
				handler.addCallback(dojo.hitch(this, function(response){
				if(response.codeError == 0) {
				noPresentaLibrosPeriodo = response.data;
				} else {
				mostrarMensaje(response.messageError);
				}
				}));
				handler.addErrback(function(response){
				mostrarMensaje("Ocurrio un error al recuperar la validaci\u00F3n del periodo de emisi\u00F3n del comprobante.");
				});

				this.waitMessage.hide();
				if (noPresentaLibrosPeriodo != "1"){
				response = false;
				}
				}*/

				if ((response) && (validarFechaIgvVigente != null) && (validarFechaIgvVigente)) {
					parts = dojo.byId("global.fechaMinIgvPorcentaje").value.split('/');
					var fechaMinIgv = parts[2] + parts[1] + parts[0];

					if (fechaEmision < fechaMinIgv) {
						this.wait("Consultando", "110px", 200);

						var handler = dojo.xhrGet({
								preventCache : false,
								url : this.controller + "?action=recuperarIgvConFecha&anio=" + fechaEmision.substring(0, 4) + "&mes=" + fechaEmision.substring(4, 6) + "&dia=" + fechaEmision.substring(6, 8),
								handleAs : "json",
								sync : true,
								timeout : 10000
							});
						handler.addCallback(dojo.hitch(this, function (response) {
								if (response.codeError == 0) {
									var row = eval("(" + response.data + ")");
									var igvPorcentajeGlobalAnterior = row.igvVigente;
									var fechaMinIgvPorcentaje = row.fechaMinIgvPorcentaje;
									var fechaMaxIgvPorcentaje = row.fechaMaxIgvPorcentaje;

									var grilla = dijit.byId("boleta.ingreso-grid");
									var filas = grilla.rowCount;

									if (filas > 0) {
										var mensajeCambioIGV = "La fecha de emisi\u00F3n seleccionada tiene otro valor de IGV (" + igvPorcentajeGlobalAnterior + "), tendr\u00E1 que volver a ingresar los items \u00BFDesea Continuar?";
										mostrarMensajeConfirmacion(mensajeCambioIGV, dojo.hitch(this, function(){
											this.eliminarItemsAll();
											this.asignarIGVDiferente(igvPorcentajeGlobalAnterior, true, fechaMinIgvPorcentaje, fechaMaxIgvPorcentaje);
										}), dojo.hitch(this, function(){
											this.setFechaEmisionPrevia();
											response = false;
										}));
										//if (confirm(mensajeCambioIGV)) {
										//	this.eliminarItemsAll();
										//	this.asignarIGVDiferente(igvPorcentajeGlobalAnterior, true, fechaMinIgvPorcentaje, fechaMaxIgvPorcentaje);
										//} else {
										//	this.setFechaEmisionPrevia();
										//	response = false;
										//}
									} else {
										this.asignarIGVDiferente(igvPorcentajeGlobalAnterior, true, fechaMinIgvPorcentaje, fechaMaxIgvPorcentaje);
									}
								} else {
									mostrarMensaje(response.messageError);
								}
							}));
						handler.addErrback(function (response) {
							mostrarMensaje("Ocurrio un error al recuperar la validaci\u00F3n del periodo de emisi\u00F3n del comprobante.");
						});

						this.waitMessage.hide();
					} else if (dojo.byId("global.fechaMaxIgvPorcentaje").value != "") {
						parts = dojo.byId("global.fechaMaxIgvPorcentaje").value.split('/');
						var fechaMaxIgv = parts[2] + parts[1] + parts[0];

						if (fechaEmision > fechaMaxIgv) {
							this.wait("Consultando", "110px", 200);

							var handler = dojo.xhrGet({
									preventCache : false,
									url : this.controller + "?action=recuperarIgvConFecha&anio=" + fechaEmision.substring(0, 4) + "&mes=" + fechaEmision.substring(4, 6) + "&dia=" + fechaEmision.substring(6, 8),
									handleAs : "json",
									sync : true,
									timeout : 10000
								});
							handler.addCallback(dojo.hitch(this, function (response) {
									if (response.codeError == 0) {
										var row = eval("(" + response.data + ")");
										var igvPorcentajeGlobalAnterior = row.igvVigente;
										dojo.byId("global.fechaMinIgvPorcentaje").value = row.fechaMinIgvPorcentaje;
										dojo.byId("global.fechaMaxIgvPorcentaje").value = row.fechaMaxIgvPorcentaje;

										this.iconTooltipMessage("boleta.fechaEmision", "icon-ok-tooltip", "La fecha de emisi\u00F3n seleccionada tiene otro valor de IGV (" + igvPorcentajeGlobalAnterior + ").");
										var grilla = dijit.byId("boleta.ingreso-grid");
										var filas = grilla.rowCount;

										if (filas > 0) {
											var mensajeCambioIGV = "La fecha de emisi\u00F3n seleccionada tiene otro valor de IGV (" + igvPorcentajeGlobalAnterior + "), tendr\u00E1 que volver a ingresar los items \u00BFDesea Continuar?";
											mostrarMensajeConfirmacion(mensajeCambioIGV, dojo.hitch(this, function(){
												this.asignarIGVDiferente(igvPorcentajeGlobalAnterior);
												this.eliminarItemsAll();
											}), dojo.hitch(this, function(){
												this.setFechaEmisionPrevia();
												response = false;
											}))
											//if (confirm(mensajeCambioIGV)) {
											//	this.asignarIGVDiferente(igvPorcentajeGlobalAnterior);
											//	this.eliminarItemsAll();
											//} else {
											//	this.setFechaEmisionPrevia();
											//	response = false;
											//}
										} else {
											this.asignarIGVDiferente(igvPorcentajeGlobalAnterior);
										}
									} else {
										mostrarMensaje(response.messageError);
									}
								}));
							handler.addErrback(function (response) {
								mostrarMensaje("Ocurri\u00F3 un error al recuperar la validaci\u00F3n del periodo de emisi\u00F3n del comprobante.");
							});

							this.waitMessage.hide();
						}
					}
				}

				if (response) {
					dojo.byId("global.fecEmisionPrevia").value = dojo.date.locale.format(dijit.byId("boleta.fechaEmision").getValue(), {
							datePattern : "MM/dd/yyyy",
							selector : "date"
						});
				}
			} else {
				this.iconTooltipMessage("boleta.fechaEmision", "icon-ok-tooltip", "Debe registrar la Fecha de Emisi\u00F3n.");
				response = false;
			}
		} else {
			dojo.byId("global.fecEmisionChange").value = "1";
		}
		return response;
	},

	validarFechaVencimiento : function () {
		response = true;

		if (dijit.byId("boleta.fechaVencimiento").getValue() != null && dijit.byId("boleta.fechaVencimiento").getValue() != "") {
			dojo.byId("global.fecVencimiento").value = dojo.date.locale.format(dijit.byId("boleta.fechaVencimiento").getValue(), {
					datePattern : "MM/dd/yyyy",
					selector : "date"
				});

//			var fechaActual = dojo.date.locale.format(new Date(), {
//					datePattern : "yyyyMMdd",
//					selector : "date"
//				});
			var fechaEmision = dojo.date.locale.format(dijit.byId("boleta.fechaEmision").getValue(), {datePattern : "yyyyMMdd",selector : "date"});//JBM --PAS20221U210700127
			var fechaVencimiento = dojo.date.locale.format(dijit.byId("boleta.fechaVencimiento").getValue(), {datePattern : "yyyyMMdd",selector : "date"});

			if (fechaVencimiento < fechaEmision) {
				this.iconTooltipMessage("boleta.fechaVencimiento", "icon-ok-tooltip", "Fecha de Vencimiento debe ser igual o mayor a la Fecha de Emisi\u00F3n.");//JBM--260422---PAS20221U210700127
				response = false;
			}
		}

		return response;
	},

	docRelDocument : function () {
		if (!dijit.byId("boleta.form").validate())
			return;

		var totalItems = this.getTotalItemsEnGrid();
		if (totalItems < 1) {
			var node = dijit.byId("boleta.addItemButton");
			node.focusNode;
			mostrarMensaje("Por favor ingrese por lo menos un \xEDtem.");
			return;
		}

		/* Inicio PAS20201U210100285 - Giancarlo Nepo López */
		if (dojo.byId("boleta.totalMontoRedondeo") != null){ /* PAS20201U210100285 - Boleta Contingencia */
			var totalRedondeo = dijit.byId("boleta.totalMontoRedondeo").getValue();
			if (totalItems < 1 && totalRedondeo != ""){
				var node = dijit.byId("boleta.addItemButton");
				node.focusNode;
				mostrarMensaje("Por favor ingrese por lo menos un \xEDtem.");
				return;
			}
			
			if (totalRedondeo > 0.09 || totalRedondeo < -0.09){
				var node = dijit.byId("boleta.totalMontoRedondeo");
				this.warnTooltipMessage(node.focusNode, "El monto m&iacute;nimo es -0.09 y el m&aacute;ximo +0.09");
				return;
			}
			
			/* Inicio Validación Monto de Redondeo - Operaciones Gratuitas */
			if (dojo.byId("global.opcionOperacionesGratuitas").value == "1") {
				var array = dijit.byId("boleta.ingreso-grid").store._arrayOfTopLevelItems;
				var cant_op_gratuitas = 0;
				for (var i = 0; i < array.length; i++){
					if (array[i].tipoBonificacion == "BO01"){
						cant_op_gratuitas++;
					}
				}
				if (cant_op_gratuitas == array.length){
					if (totalRedondeo != 0){
						mostrarMensaje("En caso de haber ingresado todos los \xEDtems como Operaciones Gratuitas, no se debe ingresar el monto de redondeo del comprobante.")
						return;
					}
				}
			}
			/* Fin Validación Monto de Redondeo - Operaciones Gratuitas */
			
			/* Inicio Validación Monto de Redondeo - Boleta de Venta tiene Descuentos o Deduce Anticipos */
			if (dojo.byId("global.opcionPagoDeduccionAnticipado").value == "DE01") {
				var importeTotal = dojo.byId("boleta.totalGeneral2").value;
				var importeRedondeo = dojo.byId("boleta.totalMontoRedondeo").value;
				if (totalRedondeo != 0){
					if (importeTotal == importeRedondeo){
						mostrarMensaje("El monto de redondeo no debe ser igual al importe total del comprobante.");
						return;
					}
				}
			}
			/* Fin Validación Monto de Redondeo - Boleta de Venta tiene Descuentos o Deduce Anticipos */
		}
		/* Fin PAS20201U210100285 - Giancarlo Nepo López */

		if (totalItems > 19) {
			mostrarMensaje("El máximo número de ítems a ingresar no debe exceder de 20.");
			return;
		}

		var varTotalCT = this.getTotalItemsEnGridQueSonCargoTributo();
		if (totalItems == varTotalCT) {
			mostrarMensaje("Debe registrar por lo menos un ítem que no sea cargo o tributo.");
			return;
		}

		/* Inicio PAS20201U210100285 - Giancarlo Nepo López */
		dojo.byId("global.montoRedondeo").value = 0.00;
		
		if (dojo.byId("boleta.totalMontoRedondeo") != null){ /* PAS20201U210100285 - Boleta Contingencia */
			if(dijit.byId("boleta.totalMontoRedondeo") != undefined && (dijit.byId("boleta.totalMontoRedondeo").getValue() <= 0.09 && dijit.byId("boleta.totalMontoRedondeo").getValue() >= -0.09)){
				var totalRedondeo = dijit.byId("boleta.totalMontoRedondeo").getValue();
				dojo.byId("global.montoRedondeo").value = totalRedondeo;
			}
		}
		/* Fin PAS20201U210100285 - Giancarlo Nepo López*/

		var varTotalItemsGravados = this.getTotalItemsEnGridQueSonGravados();
		var varTotalItemsExonerados = this.getTotalItemsEnGridQueSonExonerados();
		var varTotalItemsInafectos = this.getTotalItemsEnGridQueSonInafectos();
		var varTotalItemsConISC = this.getTotalItemsEnGridQueTienenISC();

		if (dojo.byId("global.opcionPagoAnticipado").value == "1") {
			if (totalItems == varTotalItemsGravados || totalItems == varTotalItemsExonerados || totalItems == varTotalItemsInafectos) {}
			else {
				mostrarMensaje("Todos los ítems deben tener el mismo tipo de afectación: Gravados, Exonerados o Inafectos.");
				return;
			}

			if (totalItems == varTotalItemsConISC || varTotalItemsConISC == 0) {}
			else {
				mostrarMensaje("Si usa ISC, todos los ítems deben estar afectos.");
				return;
			}
		} else {
			var varTotalAnticipos = this.getTotalItemsEnGridQueSonAnticipos();
			if (totalItems == varTotalAnticipos) {
				mostrarMensaje("Debe registrar por lo menos un ítem que no sea anticipo.");
				return;
			}
		}

		if (dojo.byId("global.opcionPagoDeduccionAnticipado").value == "DE01") {
			var itemsIncorrectosFechaAnticipo = this.getItemsCompararFechaAnticipado();
			if (itemsIncorrectosFechaAnticipo != "") {
				mostrarMensaje("En el ítem " + itemsIncorrectosFechaAnticipo + ", la fecha de emisión de la boleta de Anticipo no puede ser mayor a la fecha de emisión del comprobante.");
				return;
			}
		}

		var varTotalImporte = dojo.byId("global.importeTotal").value;
		var tipoCambioRecuperado = 0;
		var varCodMoneda = dojo.byId("global.tipoMoneda").value;

		if (varCodMoneda != "PEN") {
			this.wait("Consultando", "110px", 200);
			var handler = dojo.xhrGet({
					preventCache : false,
					url : this.controller + "?action=recuperarTipoCambio&codMoneda=" + varCodMoneda,
					handleAs : "json",
					sync : true,
					timeout : 10000
				});
			handler.addCallback(dojo.hitch(this, function (response) {
					this.waitMessage.hide();
					if (response.codeError == 0) {
						tipoCambioRecuperado = response.data;
						varTotalImporte = varTotalImporte * tipoCambioRecuperado;
					} else {
						tipoCambioRecuperado = -1;
						mostrarMensaje(response.messageError);
					}
				}));
			handler.addErrback(function (response) {
				this.waitMessage.hide();
				mostrarMensaje("Ocurrió un error al recuperar tipo de cambio.");
			});
		}

		if (tipoCambioRecuperado == -1) {
			return;
		}

		var varExportacion = dojo.byId("global.opcionExportacion").value;
		var varTipoDocumento = dojo.byId("global.tipoDocumento").value;
		var varRazonSocial = dojo.byId("global.numeroDocumentoDesc").value;
		varDomicilioCliente = dojo.byId("global.opcionDomicilioCliente").value;

		if (varExportacion == "0" && varTotalImporte > 700) {
			if (varTipoDocumento == "-") {
				mostrarMensaje("Debe consignar los datos de identificación del cliente si la venta es superior a S/.700 o equivalente.");
				return;
			}
			//if (varDomicilioCliente == "0"){
			//	mostrarMensaje("Debe consignar la direcci\u00F3n del cliente si la venta es igual o superior a S/.700 o equivalente.");
			//	return;
			//}
		}

		if (varExportacion == "1" && varTotalImporte > 700) {
			if (varTipoDocumento == "-" && varRazonSocial == "") {
				mostrarMensaje("Debe consignar los datos de identificación del cliente si la venta es superior a S/.700 o equivalente.");
				return;
			}
		}
		//Inicio IGV10-JRGS
		var varTotalItemsIgv10= this.getTotalItemsConIgv10();
		var varTotalItemsIgv18= this.getTotalItemsConIgv18();
		var varTotalItemsGravTasa18= this.getTotalItemsGravTasa18();
		var varTotalItemsExoTasa0= this.getTotalItemsExoTasa0();
		var varTotalItemsInaTasa0= this.getTotalItemsInaTasa0();
		var varTotalItemsEnGridQueSonCargoTributo= this.getTotalItemsEnGridQueSonCargoTributo();
		
		console.log("global.opcionExportacion:" + dojo.byId("global.opcionExportacion").value)
		if(dojo.byId("global.opcionExportacion").value != "1"){
			if(((varTotalItemsGravTasa18 > 0  && varTotalItemsExoTasa0 > 0 && varTotalItemsInaTasa0 > 0) ||
				(varTotalItemsGravTasa18 > 0  && varTotalItemsExoTasa0 > 0) ||
					(varTotalItemsGravTasa18 > 0  && varTotalItemsInaTasa0 > 0) ||
						(varTotalItemsGravTasa18 > 0 && varTotalItemsEnGridQueSonCargoTributo > 0) ||
							(varTotalItemsExoTasa0 > 0 && varTotalItemsInaTasa0 > 0) ||
								(varTotalItemsExoTasa0 > 0) || (varTotalItemsInaTasa0 > 0)) &&
									(varTotalItemsIgv10 == 0)){				
										
			}else{
				if (totalItems == varTotalItemsIgv10 || totalItems == varTotalItemsIgv18 || (varTotalItemsIgv18 == 0  && varTotalItemsIgv10 > 0  && varTotalItemsEnGridQueSonCargoTributo > 0) || dojo.byId("global.perteneceBVNRUS").value == "1"){

				}else{
					mostrarMensaje("Todos los ítems deben tener la misma tasa de IGV: 10% o 18%");
																															  
				  return;
				}
			}
		}		
		//Fin IGV10-JRGS			 
		dojo.byId("global.fecVencimiento").value = "";
		if (!this.validarFechaVencimiento()) {
			return;
		}

		dojo.byId("global.fecEmision").value = "";
		if (!this.validarFechaEmision(false)) {
			return;
		}

		if (varDomicilioCliente == "1" &&
			dijit.byId("boleta.direccionCliente").value == "") {
			mostrarMensaje("Debe registrar la dirección del cliente.");
			return;
		}

		if (dojo.byId("global.opcionEstablecimientoEmisor").value == "1" &&
			dijit.byId("boleta.establecimientoEmisor").value == "") {
			mostrarMensaje("Debe registrar la Dirección del Emisor o Identificar si es una venta de un Emisor Itinerante.");
			return;
		}


		//INI PAS20191U210100075
		var array = dijit.byId("boleta.ingreso-grid").store._arrayOfTopLevelItems;
		var contImpuestoBolsas = 0;
		for (var i = 0; i < array.length; i++) {
			if (array[i].esImpuestoBolsaPlastico == "IBP00" ) {
				contImpuestoBolsas += 1;
			}
		}
		
		var parts = dojo.byId("boleta.fechaEmision").value.split('/');		
		var fechaEmision = new Date(parts[2],parts[1]-1,parts[0]);
		
		//fecha properties
		var parts2 = dojo.byId("item.FechaProperties").value.split('/');
		var fechaproperties = new Date(parts2[2],parts2[1]-1,parts2[0]);
		
		console.log("items con icbper :" + contImpuestoBolsas);
		console.log(dojo.byId("boleta.fechaEmision").value);
		console.log(dojo.byId("item.FechaProperties").value);

		
		if((fechaEmision < fechaproperties) && contImpuestoBolsas > 0){
			
			mostrarMensaje("No puede cambiar la fecha de emisión, existen ítems agregados con ICBPER.");
			
			return false;
			
		}
		//FIN PAS20191U210100075

		//Verifica si existe algun item con exonerado o inafecto
		dojo.byId("global.flagExoInafecto").value = this.checkExoneradoInafecto();
		
		// PAS20191U210100204	
		//PAS20211U210700098-Chrome
		var accionBtn01 = dojo.hitch(this, function() {
			var nbControl = dijit.byId("boleta.botonGrabarDocumento");
			nbControl.setAttribute('disabled', true);
			this.wait("Procesando", "110px", 200);
			var nodeButton = nbControl.focusNode;

			var handler = dojo.io.iframe.send({
					url : this.controller,
					handleAs : "json",
					sync : true,
					timeout : 10000,
					preventCache : true,
					form : "boleta.form"
				});

			handler.addCallback(dojo.hitch(this, function (res) {
					this.waitMessage.hide();
					if (res.codeError == 0) {
						this.content.onLoad = dojo.hitch(this, function () {
								var moneda = dojo.byId("global.tipoMoneda").value;
							});
						this.content.setHref(this.controller + "?action=showDocRelComprobante&preventCache=" + this.preventCache());
						this.content.onLoad = dojo.hitch(this, function () {
								dijit.byId("docsrel.observacion").setValue(dojo.byId("global.docsrel.observacion").value);

								if (dojo.byId("global.opcionFESectorPublico").value == "1") {
									this.showHiddenDiv(document.getElementById("docsrel.informacionFESectorPublico.show"), true);
								} else {
									this.showHiddenDiv(document.getElementById("docsrel.informacionFESectorPublico.show"), false);
								}
								if (dojo.byId("global.opcionSustentoTrasladoBienes").value == "1") {
									this.showHiddenDiv(document.getElementById("docsrel.informacionTrasladoBienes.show"), true);
								} else {
									this.showHiddenDiv(document.getElementById("docsrel.informacionTrasladoBienes.show"), false);
								}

							});

					} else {
						nbControl.setAttribute('disabled', false);
						this.waitMessage.hide();
						mostrarMensaje(res.messageError);
					}
				}));

			handler.addErrback(function (res) {
				nbControl.setAttribute('disabled', false);
				//this.waitMessage.hide();
				mostrarMensaje("Problemas al conectarse con el servidor");
			});
		});
		
			//if (this.getExisteDuplicados() > 0 && 
				//!confirm("Antes de continuar\nExisten ítems con información duplicada  ¿Desea continuar?")){
				//return;
			//}
			if (this.getExisteDuplicados() > 0){
				//// !confirm("Antes de continuar\nExisten ítems con información duplicada ¿Desea continuar?")){
				//return;
				mostrarMensajeConfirmacion("Antes de continuar\nExisten ítems con información duplicada ¿Desea continuar?", accionBtn01 );
			}else{
				accionBtn01();
			}
	},

	//Contingencia
	docRelDocumentContin : function () {
		if (!dijit.byId("boleta.form").validate())
			return;

		//Gimy, validacion de numero de serie
		if (document.getElementById("numero").value == ""){
			mostrarMensaje("Ingrese el numero de serie");
			document.getElementById("numero").focus();
			return;
		}
			
		var totalItems = this.getTotalItemsEnGrid();
		if (totalItems < 1) {
			var node = dijit.byId("boleta.addItemButton");
			node.focusNode;
			mostrarMensaje("Por favor ingrese por lo menos un item.");
			return;
		}

		if (totalItems > 19) {
			mostrarMensaje("El m\u00E1ximo n\u00FAmero de items a ingresar no debe exceder de 20.");
			return;
		}

		var varTotalCT = this.getTotalItemsEnGridQueSonCargoTributo();
		if (totalItems == varTotalCT) {
			mostrarMensaje("Debe registrar por lo menos un \u00EDtem que no sea cargo o tributo.");
			return;
		}

		var varTotalItemsGravados = this.getTotalItemsEnGridQueSonGravados();
		var varTotalItemsExonerados = this.getTotalItemsEnGridQueSonExonerados();
		var varTotalItemsInafectos = this.getTotalItemsEnGridQueSonInafectos();
		var varTotalItemsConISC = this.getTotalItemsEnGridQueTienenISC();

		if (dojo.byId("global.opcionPagoAnticipado").value == "1") {
			if (totalItems == varTotalItemsGravados || totalItems == varTotalItemsExonerados || totalItems == varTotalItemsInafectos) {}
			else {
				mostrarMensaje("Todos los \u00EDtems deben tener el mismo tipo de afectaci\u00F3n: Gravados, Exonerados o Inafectos.");
				return;
			}

			if (totalItems == varTotalItemsConISC || varTotalItemsConISC == 0) {}
			else {
				mostrarMensaje("Si usa ISC, todos los \u00EDtems deben estar afectos.");
				return;
			}
		} else {
			var varTotalAnticipos = this.getTotalItemsEnGridQueSonAnticipos();
			if (totalItems == varTotalAnticipos) {
				mostrarMensaje("Debe registrar por lo menos un \u00EDtem que no sea anticipo.");
				return;
			}
		}

		if (dojo.byId("global.opcionPagoDeduccionAnticipado").value == "DE01") {
			var itemsIncorrectosFechaAnticipo = this.getItemsCompararFechaAnticipado();
			if (itemsIncorrectosFechaAnticipo != "") {
				mostrarMensaje("En el \u00EDtem " + itemsIncorrectosFechaAnticipo + ", la fecha de emisi\u00F3n de la boleta de Anticipo no puede ser mayor a la fecha de emisi\u00F3n del comprobante.");
				return;
			}
		}

		var varTotalImporte = dojo.byId("global.importeTotal").value;
		var tipoCambioRecuperado = 0;
		var varCodMoneda = dojo.byId("global.tipoMoneda").value;

		if (varCodMoneda != "PEN") {
			this.wait("Consultando", "110px", 200);
			var handler = dojo.xhrGet({
					preventCache : false,
					url : this.controller + "?action=recuperarTipoCambio&codMoneda=" + varCodMoneda,
					handleAs : "json",
					sync : true,
					timeout : 10000
				});
			handler.addCallback(dojo.hitch(this, function (response) {
					this.waitMessage.hide();
					if (response.codeError == 0) {
						tipoCambioRecuperado = response.data;
						varTotalImporte = varTotalImporte * tipoCambioRecuperado;
					} else {
						tipoCambioRecuperado = -1;
						mostrarMensaje(response.messageError);
					}
				}));
			handler.addErrback(function (response) {
				this.waitMessage.hide();
				mostrarMensaje("Ocurri\u00F3 un error al recuperar tipo de cambio.");
			});
		}

		if (tipoCambioRecuperado == -1) {
			return;
		}

		var varExportacion = dojo.byId("global.opcionExportacion").value;
		var varTipoDocumento = dojo.byId("global.tipoDocumento").value;
		var varRazonSocial = dojo.byId("global.numeroDocumentoDesc").value;
		varDomicilioCliente = dojo.byId("global.opcionDomicilioCliente").value;

		if (varExportacion == "0" && varTotalImporte > 700) {
			if (varTipoDocumento == "-") {
				mostrarMensaje("Debe consignar los datos de identificaci\u00F3n del cliente si la venta es superior a S/.700 o equivalente.");
				return;
			}
		}

		if (varExportacion == "1" && varTotalImporte > 700) {
			if (varTipoDocumento == "-" && varRazonSocial == "") {
				mostrarMensaje("Debe consignar los datos de identificaci\u00F3n del cliente si la venta es superior a S/.700 o equivalente.");
				return;
			}
		}
		
		//Inicio IGV10-JRGS
		var varTotalItemsIgv10= this.getTotalItemsConIgv10();
		var varTotalItemsIgv18= this.getTotalItemsConIgv18();
		var varTotalItemsGravTasa18= this.getTotalItemsGravTasa18();
		var varTotalItemsExoTasa0= this.getTotalItemsExoTasa0();
		var varTotalItemsInaTasa0= this.getTotalItemsInaTasa0();
		var varTotalItemsEnGridQueSonCargoTributo= this.getTotalItemsEnGridQueSonCargoTributo();
		
		console.log("global.opcionExportacion:" + dojo.byId("global.opcionExportacion").value)
		if(dojo.byId("global.opcionExportacion").value != "1"){
			if(((varTotalItemsGravTasa18 > 0  && varTotalItemsExoTasa0 > 0 && varTotalItemsInaTasa0 > 0) ||
				(varTotalItemsGravTasa18 > 0  && varTotalItemsExoTasa0 > 0) ||
					(varTotalItemsGravTasa18 > 0  && varTotalItemsInaTasa0 > 0) ||
						(varTotalItemsGravTasa18 > 0 && varTotalItemsEnGridQueSonCargoTributo > 0) ||
							(varTotalItemsExoTasa0 > 0 && varTotalItemsInaTasa0 > 0) ||
								(varTotalItemsExoTasa0 > 0) || (varTotalItemsInaTasa0 > 0)) &&
									(varTotalItemsIgv10 == 0)){				
										
			}else{
				if (totalItems == varTotalItemsIgv10 || totalItems == varTotalItemsIgv18 || (varTotalItemsIgv18 == 0  && varTotalItemsIgv10 > 0  && varTotalItemsEnGridQueSonCargoTributo > 0) || dojo.byId("global.perteneceBVNRUS").value == "1"){

				}else{
					mostrarMensaje("Todos los ítems deben tener la misma tasa de IGV: 10% o 18%");
				  return;
				}
			}
		}		
		//Fin IGV10-JRGS

		dojo.byId("global.fecVencimiento").value = "";
		if (!this.validarFechaVencimiento()) {
			return;
		}

		dojo.byId("global.fecEmision").value = "";
		if (!this.validarFechaEmisionContin(false)) {
			return;
		}

		if (varDomicilioCliente == "1" &&
			dijit.byId("boleta.direccionCliente").value == "") {
			mostrarMensaje("Debe registrar la direcci\u00F3n del cliente.");
			return;
		}

		if (dojo.byId("global.opcionEstablecimientoEmisor").value == "1" &&
			dijit.byId("boleta.establecimientoEmisor").value == "") {
			mostrarMensaje("Debe registrar la Direcci\u00F3n del Emisor o Identificar si es una venta de un Emisor Itinerante.");
			return;
		}
		
		//INI PAS20191U210100075
		var array = dijit.byId("boleta.ingreso-grid").store._arrayOfTopLevelItems;
		var contImpuestoBolsas = 0;
		for (var i = 0; i < array.length; i++) {
			if (array[i].esImpuestoBolsaPlastico == "IBP00" ) {
				contImpuestoBolsas += 1;
			}
		}
		
		var parts = dojo.byId("boleta.fechaEmision").value.split('/');		
		var fechaEmision = new Date(parts[2],parts[1]-1,parts[0]);
		
		//fecha properties
		var parts2 = dojo.byId("item.FechaProperties").value.split('/');
		var fechaproperties = new Date(parts2[2],parts2[1]-1,parts2[0]);
		
		console.log("items con icbper :" + contImpuestoBolsas);
		console.log(dojo.byId("boleta.fechaEmision").value);
		console.log(dojo.byId("item.FechaProperties").value);

		
		if((fechaEmision < fechaproperties) && contImpuestoBolsas > 0){				
			mostrarMensaje("No puede cambiar la fecha de emisi\u00F3n, existen ítems agregados con ICBPER.");				
			return false;			
		}
		//FIN PAS20191U210100075
		
		//Verifica si existe algun item con exonerado o inafecto
		dojo.byId("global.flagExoInafecto").value = this.checkExoneradoInafecto();
		
		// PAS20191U210100204		
		//PAS20211U210700098-Chrome
		var accionBtn01Contin = dojo.hitch(this, function() {
		var nbControl = dijit.byId("boleta.botonGrabarDocumento");
		nbControl.setAttribute('disabled', true);
		this.wait("Procesando", "110px", 200);
		var nodeButton = nbControl.focusNode;

		var handler = dojo.io.iframe.send({
				url : this.controller,
				handleAs : "json",
				sync : true,
				timeout : 10000,
				preventCache : true,
				form : "boleta.form"
			});

		handler.addCallback(dojo.hitch(this, function (res) {
				this.waitMessage.hide();
				if (res.codeError == 0) {
					this.content.onLoad = dojo.hitch(this, function () {
							var moneda = dojo.byId("global.tipoMoneda").value;
						});
					this.content.setHref(this.controller + "?action=showDocRelComprobante&preventCache=" + this.preventCache());
					this.content.onLoad = dojo.hitch(this, function () {
							dijit.byId("docsrel.observacion").setValue(dojo.byId("global.docsrel.observacion").value);

							if (dojo.byId("global.opcionFESectorPublico").value == "1") {
								this.showHiddenDiv(document.getElementById("docsrel.informacionFESectorPublico.show"), true);
							} else {
								this.showHiddenDiv(document.getElementById("docsrel.informacionFESectorPublico.show"), false);
							}
							if (dojo.byId("global.opcionSustentoTrasladoBienes").value == "1") {
								this.showHiddenDiv(document.getElementById("docsrel.informacionTrasladoBienes.show"), true);
							} else {
								this.showHiddenDiv(document.getElementById("docsrel.informacionTrasladoBienes.show"), false);
							}

						});

				} else {
					nbControl.setAttribute('disabled', false);
					this.waitMessage.hide();
					mostrarMensaje(res.messageError);
				}
			}));

		handler.addErrback(function (res) {
			nbControl.setAttribute('disabled', false);
			//this.waitMessage.hide();
			mostrarMensaje("Problemas al conectarse con el servidor");
		});
	});
	
		if (this.getExisteDuplicados() > 0){
				//// !confirm("Antes de continuar\nExisten ítems con información duplicada ¿Desea continuar?")){
				//return;
				mostrarMensajeConfirmacion("Antes de continuar\nExisten ítems con información duplicada ¿Desea continuar?", accionBtn01Contin );
			}else{
				accionBtn01Contin();
			}
	},

	setDefaultMontosDocRel : function () {},

	validateAcceptTerminos : function () {
		var acepta = dijit.byId("condicionesSEE.cbTerminos");
		if (!acepta.getValue()) {
			mostrarMensaje("Debe aceptar las condiciones.");
			return;
		}
		this.content.setHref(this.controller + "?action=mostrarPrimeraBVE");
	},

	checkExoneradoInafecto : function () {
		var flagExoInaf = 0;
		var array = dijit.byId("boleta.ingreso-grid").store._arrayOfTopLevelItems;
		for (var i = 0; i < array.length; i++) {
			if (array[i].tipoBeneficio == "TB01" || array[i].tipoBeneficio == "TB02") {
				flagExoInaf = 1;
			}
		}
		return flagExoInaf;

	},

	previewDocument : function () {
		localStorage.removeItem('data'); //DAG PAS20221U210700299
		if (!dijit.byId("docsrel.form").validate())
			return;

		dojo.byId("global.docsrel.observacion").value = dijit.byId("docsrel.observacion").getValue();

		if (dojo.byId("global.opcionSustentoTrasladoBienes").value == "1") {
			if (dojo.byId("global.opcionPuntoPartidaDireccion").value == "" || dojo.byId("global.opcionPuntoLlegadaDireccion").value == "") {
				mostrarMensaje("Debe registrar el punto de partida y punto de llegada");
				return;
			}
		}

		if (dojo.byId("global.opcionEstablecimientoEmisorIdentifica").value == 2 && this.indRegitroGR == 0) {
			mostrarMensaje("Debe tener ingresada al menos una Gu\u00EDa de Remisi\u00F3n Remitente");
			return;
		}

		var nbControl = dijit.byId("docsrel.botonGrabarDocumento");
		nbControl.setAttribute('disabled', true);
		this.wait("Procesando", "110px", 200);

		var handler = dojo.io.iframe.send({
				url : this.controller,
				handleAs : "json",
				sync : true,
				timeout : 10000,
				preventCache : true,
				form : "docsrel.form"
			});

		handler.addCallback(dojo.hitch(this, function (res) {
				this.waitMessage.hide();
				if (res.codeError == 0) {
					this.content.onLoad = dojo.hitch(this, function () {
							var grid = dijit.byId("boleta.preview-grid");
							var datos = eval("(" + res.data + ")");

							var newStore = new dojo.data.ItemFileWriteStore({
									data : {
										identifier : 'identificador',
										items : datos,
										preventCache : true
									}
								});
							grid.setStore(newStore);
							grid.startup();
							grid.update();
						});
					this.content.setHref(this.controller + "?action=previewComprobante&preventCache=" + this.preventCache());
				} else {
					nbControl.setAttribute('disabled', false);
					mostrarMensaje(res.messageError);
				}
			}));
		handler.addErrback(function (res) {
			nbControl.setAttribute('disabled', false);
			this.waitMessage.hide();
			mostrarMensaje("Problemas al conectarse con el servidor");
		});
	},

	saveDocument: function () {
		if (!dijit.byId("boleta-preliminar.form").validate())
			return;
	//PAS20211U210700098-Chrome
	var accionBtnAceptarQ2 = dojo.hitch(this, function () {
		var nbBack = dijit.byId("boleta-preliminar.botonBackDocumento");
		var nbSave = dijit.byId("boleta-preliminar.botonGrabarDocumento");
		var nbClose = dijit.byId("boleta-preliminar.botonCloseDocumento");

		nbBack.setAttribute('disabled', true);
		nbSave.setAttribute('disabled', true);
		nbClose.setAttribute('disabled', true);

		this.wait("Grabando", "95px", 800);

		var handler = dojo.xhrGet({
				url : this.controller + "?action=grabarComprobante",
				handleAs : "json",
				preventCache : true,
				sync : true,
				timeout : 40000
			});

		handler.addCallback(dojo.hitch(this, function (res) {
				this.waitMessage.hide();
				if (res.codeError == 0) {
					this.content.onLoad = dojo.hitch(this, function () {
							this.iconTooltipMessage("numeroComprobante", "icon-ok-tooltip", "La boleta de venta se emiti&oacute; correctamente <br>Ha generado este n&uacute;mero.");
							var grid = dijit.byId("boleta.generada-grid");
							var datos = eval("(" + res.data + ")");
							var newStore = new dojo.data.ItemFileWriteStore({
									data : {
										identifier : 'identificador',
										items : datos,
										preventCache : true
									}
								});
							grid.setStore(newStore);
							grid.startup();
							grid.update();
						});
					this.content.setHref(this.controller + "?action=mostrarComprobante&preventCache=" + this.preventCache());
				} else {
					nbBack.setAttribute('disabled', false);
					nbSave.setAttribute('disabled', false);
					nbClose.setAttribute('disabled', false);
					mostrarMensaje(res.messageError);
				}
			}));
		handler.addErrback(dojo.hitch(this, function (res) {
				nbBack.setAttribute('disabled', false);
				nbSave.setAttribute('disabled', false);
				nbClose.setAttribute('disabled', false);

				this.waitMessage.hide();
				// PAS20221U210700020
				//mostrarMensaje("Problemas al emitir la Boleta de Venta Electr\u00F3nica.");
				mostrarMensaje("Se produjo un error al grabar el comprobante o documento. Por favor, volver a intentar.");
			}));
	});
	
	var accionBtnAceptarQ1 = function () {
        console.log("Aceptar1_Click()");
        mostrarMensajeConfirmacion("Est\xE1 Ud. seguro de emitir una Boleta de Venta Electr\xF3nica?", accionBtnAceptarQ2 );
    };
	
    // PAS20221U210600187
    if(this.getExistePosibleDuplicacion(1) > parseFloat(0)) {
        console.log("FlujoExistePosibleDuplicacion()");
        var numSerieCpeUltimoComprobante = dojo.byId("global.numSerieCpeUltimoComprobante").value;
        var numCpeUltimoComprobante = dojo.byId("global.numCpeUltimoComprobante").value;
        var numDocIdeRecepUltimoComprobante = dojo.byId("global.numDocIdeRecepUltimoComprobante").value;
        var importeTotalUltimoComprobante = dojo.byId("global.importeTotalUltimoComprobante").value;
                          
        var tiempoRestanteDuplicarBoleta = this.getExistePosibleDuplicacion(0);
        
        if(numDocIdeRecepUltimoComprobante != "-") {
        	mostrarMensaje("Ya existe una Boleta para " + numDocIdeRecepUltimoComprobante + ", con Importe Total de " + importeTotalUltimoComprobante + ", por favor verifique la Boleta " + numSerieCpeUltimoComprobante + "-" + numCpeUltimoComprobante + " desde la opci\u00F3n de Consultas, o int\u00E9ntelo en " + Math.ceil(tiempoRestanteDuplicarBoleta) +" min.");
        } else {
        	mostrarMensaje("Ya existe una Boleta con Importe Total de " + importeTotalUltimoComprobante + ", por favor verifique la Boleta " + numSerieCpeUltimoComprobante + "-" + numCpeUltimoComprobante + " desde la opci\u00F3n de Consultas, o int\u00E9ntelo en " + Math.ceil(tiempoRestanteDuplicarBoleta) +" min.");
        }
    // PAS20191U210100204
	//PAS20211U210700098-Chrome
	} else if (this.getExisteDuplicados() > 0){			
			console.log("FlujoDuplicados()");
			mostrarMensajeConfirmacion("Antes de continuar\nExisten ítems con información duplicada  ¿Desea continuar?", accionBtnAceptarQ1 );    
		}else{
			console.log("Alternativo()");
			mostrarMensajeConfirmacion("¿Est\xE1 Ud. seguro de emitir una Boleta de Venta Electr\xF3nica?", accionBtnAceptarQ2 );
		}
	},


	saveDocumentContin : function () {
		if (!dijit.byId("boleta-preliminar.form").validate())
			return;
	//PAS20211U210700098-Chrome		
	var accionBtnAceptarQ2Cont = dojo.hitch(this, function () {
		var nbBack = dijit.byId("boleta-preliminar.botonBackDocumento");
		var nbSave = dijit.byId("boleta-preliminar.botonGrabarDocumento");
		var nbClose = dijit.byId("boleta-preliminar.botonCloseDocumento");

		nbBack.setAttribute('disabled', true);
		nbSave.setAttribute('disabled', true);
		nbClose.setAttribute('disabled', true);

		this.wait("Grabando", "95px", 800);

		var handler = dojo.xhrGet({
				url : this.controller + "?action=grabarComprobanteContin",
				handleAs : "json",
				preventCache : true,
				sync : true,
				timeout : 40000
			});

		handler.addCallback(dojo.hitch(this, function (res) {
				this.waitMessage.hide();
				if (res.codeError == 0) {
					this.content.onLoad = dojo.hitch(this, function () {
						this.iconTooltipMessage("numeroComprobante", "icon-ok-tooltip", "El registro de la presente informaci\u00F3n constituye una declaraci\u00F3n jurada, acorde con la RS 113-2018/SUNAT. <br>Ha generado este n&uacute;mero."); /* Correccion tildes - PAS20201U210100285 - Giancarlo Nepo Lopez */
							var grid = dijit.byId("boleta.generada-grid");
							var datos = eval("(" + res.data + ")");
							var newStore = new dojo.data.ItemFileWriteStore({
									data : {
										identifier : 'identificador',
										items : datos,
										preventCache : true
									}
								});
							grid.setStore(newStore);
							grid.startup();
							grid.update();
						});
					this.content.setHref(this.controller + "?action=mostrarComprobante&preventCache=" + this.preventCache());
				} else {
					nbBack.setAttribute('disabled', false);
					nbSave.setAttribute('disabled', false);
					nbClose.setAttribute('disabled', false);
					mostrarMensaje(res.messageError);
				}
			}));
		handler.addErrback(dojo.hitch(this, function (res) {
				nbBack.setAttribute('disabled', false);
				nbSave.setAttribute('disabled', false);
				nbClose.setAttribute('disabled', false);

				this.waitMessage.hide();
				// PAS20221U210700020
				//mostrarMensaje("Problemas al emitir la Boleta de Venta por Contingencia.");
				mostrarMensaje("Se produjo un error al grabar el comprobante o documento. Por favor, volver a intentar.");
			}));
	});
	
	var accionBtnAceptarQ1Cont = function () {
        console.log("Aceptar1_Click()");
        mostrarMensajeConfirmacion("Est\u00E1 Ud. seguro de registrar una Boleta de Venta por Contingencia?", accionBtnAceptarQ2Cont );
    };
	
		// PAS20191U210100204
		//PAS20211U210700098-Chrome
		if (this.getExisteDuplicados() > 0){
			console.log("FlujoDuplicados()");
			mostrarMensajeConfirmacion("Antes de continuar\nExisten ítems con información duplicada  ¿Desea continuar?", accionBtnAceptarQ1Cont );    
		}else{
			console.log("Alternativo()");
			mostrarMensajeConfirmacion("Est\u00E1 Ud. seguro de registrar una Boleta de Venta por Contingencia?", accionBtnAceptarQ2Cont );
		}
	},

	closeDocument : function () {
		this.store = null;
		this.otherDocStore = null;

		this.resetValoresGlobales();

		this.content.onLoad = dojo.hitch(this, function () {
				this.initContent();
			});
		this.content.setHref(this.controller + "?action=mostrarInicial&mode=hidden");
	},

	closeDocumentGenerado : function () {
		mostrarMensajeConfirmacion("Debe haber otorgado la Boleta de Venta mediante su impresi\u00F3n en papel o remitido a trav\u00E9s de Correo Electr\u00F3nico.\u00BFDesea emitir otra Boleta de Venta?", dojo.hitch(this, function(){
			this.closeDocument();
		}));
	},

	closeDocumentInicial : function () {
		mostrarMensajeConfirmacion("¿Desea salir del aplicativo?", dojo.hitch(this, function(){
			this.closeDocument();
		}));
	},

	closeDocumentInicio : function () {
		mostrarMensajeConfirmacion("¿Desea cancelar la emisión de la Boleta de Venta Electrónica?", dojo.hitch(this, function(){
			this.closeDocument();
		}));
	},
	closeDocumentDocRel : function () {
		this.closeDocumentInicio();
	},
	closeDocumentIngreso : function () {
		this.closeDocumentInicio();
	},

	newDocument : function () {
		this.store = null;
		this.otherDocStore = null;
		this.content.onLoad = dojo.hitch(this, function () {
				this.initContent();
			});
		this.content.setHref(this.controller + "?action=showIngresoBoleta&mode=hidden");
	},

	showDialogItem : function (mode) {
		/* Inicio PAS20201U210100285 - Pago Anticipado */
		if (dojo.byId("global.opcionPagoDeduccionAnticipado").value == "DE01") {
			require(["dijit/registry"], function(registry){
				var formItems = registry.byId("item.form");
				formItems.reset();
			});
		}
		/* Fin PAS20201U210100285 - Pago Anticipado */
		
		if (mode == 1) {
			dojo.byId("global.origenInvocacionItem").value = "01";
			dijit.byId("item.botonAceptar").setAttribute('disabled', false);
			this.nuevoItem();
		} else if (mode == 2) {
			dojo.byId("global.origenInvocacionItem").value = "01";
			this.editItem();
		}
	},

	closeDialogItem : function () {
		mostrarMensajeConfirmacion("¿Desea cancelar la captura del ítem?", dojo.hitch(this, function(){
			this.dialogItem.hide();
		}));

	},

	acceptDialogItem : function () {
		if (!dijit.byId("item.cantidad").validate()) {
			return;
		}

		if (!dijit.byId("item.codigoItem").validate()) {
			return;
		}

		if (!dijit.byId("item.precioUnitario").validate()) {
			return;
		}

		if (!dijit.byId("item.precioDescuento").validate()) {
			return;
		}

		if (!dijit.byId("item.sistemaIsc").validate()) {
			return;
		}

		if (!dijit.byId("item.iscPorcentaje").validate()) {
			return;
		}

		if (!dijit.byId("item.iscMonto").validate()) {
			return;
		}

		if (!dijit.byId("item.precioConIGV").validate()) {
			return;
		}

		if (!dijit.byId("item.importeVenta").validate()) {
			return;
		}
		//INI PAS20191U210100075	01.08
		if(!dijit.byId("item.unidadMedida").validate())
		{
			return;
		}			
		//FIN PAS20191U210100075	01.08
		
		
		//INI PAS20191U210100075					
		monedades = dojo.byId("global.tipoMonedaDesc").value;
		var valOpcionImpuestoBolsaPlastica = this.getValorOpcionImpuestoBolsaPlastica();
		if(monedades != "SOLES"){
			if((dijit.byId("item.impuestoICBPER").getValue() <= 0 || isNaN(dijit.byId("item.impuestoICBPER").getValue()) ||dijit.byId("item.impuestoICBPER").getValue() == "") &&  valOpcionImpuestoBolsaPlastica == "IBP00")
			{
					mostrarMensaje("Impuesto ICBPER Invalido.")
						return;
			}			
			
		}
		
		if(monedades == "SOLES"){

			
			var valOpcionImpuestoBolsaPlastica = this.getValorOpcionImpuestoBolsaPlastica();

				if (valOpcionImpuestoBolsaPlastica == "IBP00"){ 
					
					//var anio = new Date().getFullYear();
					var parts = dojo.byId("boleta.fechaEmision").value.split('/');		

					var fechaEmision = new Date(parts[2],parts[1]-1,parts[0]);
				
					
					var anio2 = dijit.byId("item.periodoBolsa").get('displayedValue');
					
					if(anio2 <  fechaEmision.getFullYear().toString()){
						
						
						//var r = confirm("“La tasa del ICBPER corresponde a un periodo anterior” Esta seguro de marcar Si o No.");
						//if (r == true) {
						  
						//} else {
						//  return;
						//}
						mostrarMensajeConfirmacion("“La tasa del ICBPER corresponde a un periodo anterior” Esta seguro de marcar Si o No.", dojo.hitch(this, function(){}), dojo.hitch(this, function(){ return }));
					}
					
					
				
				}
		}
		
		
		//FIN PAS20191U210100075
		
		//if(!dijit.byId("item.form").validate()) return;
		var mode = dojo.byId("item.action").value;
		//PAS20175E210300024
		var anticipo = this.getValorOpcionAnticipo();
		if (anticipo == "1") {
			if (this.obtenerBoletaAnticipo(false) == false) {
				return;
			}
		}

		if ((dojo.byId("item.valOpcTipoCTItem").value != "1" && dojo.byId("item.valOpcTipoCTItem").value != "2") && dojo.byId("item.valOpcTipoBS").value == "") {
			mostrarMensaje("Debe seleccionar si el Item es Cargo/Tributo o Bien/Servicio.");
			return;
		}

		var moneda = dojo.byId("global.tipoMoneda").value;
		var anticipo = this.getValorOpcionAnticipo();
		var tipoItem = this.getValorOpcionTipoItem();
		if (tipoItem == "TI01" || tipoItem == "TI02") {
			if (anticipo != "1") {
				if (!dijit.byId("item.cantidad").getValue()) {
					this.warnTooltipMessage("item.cantidad", "Por favor ingrese una cantidad.");
					return;
				}
			} else {
				if (mode == "adicionarItem") {
					var serie = dijit.byId("item.boletaAnticipoSerie").getValue();
					var numero = dijit.byId("item.boletaAnticipoNumero").getValue();
					if (this.verSiBoletaDeAnticipoExisteEnGrid(serie, numero) == "1") {
						this.warnTooltipMessage("item.boletaAnticipoNumero", "Este pago anticipado ya fue utilizado en esta boleta de venta.");
						return;
					}
				}
				if (dojo.byId("item.boletaAnticipoMonto").value == "") {
					this.warnTooltipMessage("item.boletaAnticipoMonto", "Debe registrar el monto total de la boleta de venta de anticipo.");
					return;
				}
				if (dojo.byId("item.boletaAnticipoFechaEmision").value == "") {
					this.warnTooltipMessage("item.boletaAnticipoFechaEmision", "Debe registrar la fecha de emisi\u00F3n de la boleta de venta de anticipo.");
					return;
				}
				var fechaHoy = new Date();
				var fechaEmisionAnticipo = new Date(dojo.byId("item.boletaAnticipoFechaEmision").value.substring(3, 6) + dojo.byId("item.boletaAnticipoFechaEmision").value.substring(0, 3) + dojo.byId("item.boletaAnticipoFechaEmision").value.substring(6, 10));

				if (fechaEmisionAnticipo > fechaHoy) {
					this.iconTooltipMessage("item.boletaAnticipoFechaEmision", "icon-ok-tooltip", "La fecha de emisi\u00F3n de la boleta de venta de anticipo no puede ser mayor a la fecha actual.");
					return;
				}

				//PAS20175E210300029
				var fechaEmisionComprobante = new Date();
				if (dojo.byId("global.fecEmision").value != "") {
					fechaEmisionComprobante = new Date(dojo.byId("global.fecEmision").value);
				}

				if (fechaEmisionAnticipo > fechaEmisionComprobante) {
					this.iconTooltipMessage("item.boletaAnticipoFechaEmision", "icon-ok-tooltip", "La fecha de emisi\u00F3n de la boleta de Anticipo no puede ser mayor a la fecha de emisi\u00F3n del comprobante.");
					return;
				}
			}
		}

		var descripcion = dojo.trim(dijit.byId("item.descripcion").getValue());
		if (descripcion.length < 1) {
			this.warnTooltipMessage("item.descripcion", "Por favor ingrese una descripci&oacute;n");
			return;
		}
		if (/\"/.test(descripcion)) { //Verifica que la descripci\u00F3n no tenga "
			this.warnTooltipMessage("item.descripcion", 'Car&aacute;cter no permitido (")');
			return;
		}
		
		regexp1 = /^[a-zA-Z0-9À-ÿ\u00f1\u00d1!#$%&'()\u00a3*+,-.\/:;<=>?@^_`{|}~\]\[\\ ]+$/;
		regexp2 = /[ÿ]+$/;
		if (!regexp1.test(descripcion)|| regexp2.test(descripcion)) { //Verifica que la descripci\u00F3n no tenga caracteres especiales
		//this.warnTooltipMessage("item.descripcion", 'Contiene car&aacute;cter(es) no permitido(s).');
		mostrarMensaje("El texto de descripci&oacuten contiene car&aacute;cter(es) no permitido(s).");
		return;
		}
		
		//PAS20221U210600125 -Ini - Csantillan
		//this.isQuitarCharacterSpecial();
		//PAS20221U210600125 -Fin - Csantillan		

		var precioUnitario = dijit.byId("item.precioUnitario").getValue();
		if (precioUnitario > 99999999.99) {
			mostrarMensaje("Precio unitario sobrepasa el limite permitido.")
			return;
		}
		//if (dojo.byId("global.situacionEspecial").value != "SE01" ){    //MPCR 20110913   PAS201120500000026 - Para que se exija precio unitario aun en la FE de Venta gratuita
		//if (this.getValorOpcionTipoBonif() == ""){
		var precioUnitario = dijit.byId("item.precioUnitario").getValue();
		if (precioUnitario <= 0) {
			this.warnTooltipMessage("item.precioUnitario", "El valor unitario debe ser mayor a cero.");
			return;
		}

		if (dojo.byId("global.opcionNodomic").value == "1") {
			if (precioUnitario < 42) {
				this.warnTooltipMessage("item.precioUnitario", "Precio de venta del bien es menor a lo establecido en el Art\u00EDculo 11-G del DS 161-2012-EF");
				return;
			}
		}

		var descuento = dijit.byId("item.precioDescuento").getValue();
		if (descuento < 0) {
			this.warnTooltipMessage("item.precioDescuento", "El descuento no debe ser negativo.");
			return;
		}

		var tipoItem = this.getValorOpcionTipoItem();
		if (tipoItem == "TI01") {
			var unidadMedida = dijit.byId("item.unidadMedida").getValue();
			if (anticipo != "1") {
				if (dojo.trim(unidadMedida) == "000") {
					this.warnTooltipMessage("item.unidadMedida", "Por favor ingrese una unidad de medida.");
					return;
				}
			}
		}

		if (!dijit.byId("item.cantidad").getValue()) {
			dijit.byId("item.cantidad").setValue(1);
		}

		var cantidadXPrecioUnitario = dijit.byId("item.cantidad").getValue() * dijit.byId("item.precioUnitario").getValue();
		cantidadXPrecioUnitario.toFixed();
		if ((dijit.byId("item.cantidad").getValue() * dijit.byId("item.precioUnitario").getValue()) > 99999999.99) {
			mostrarMensaje("Valores numericos calculados sobrepasan el limite permitido.")
			return;
		}

		var descuento = dijit.byId("item.precioDescuento").getValue();
		if (descuento >= cantidadXPrecioUnitario) {
			var node = dijit.byId("item.precioDescuento");
			this.warnTooltipMessage(node.focusNode, "Descuento debe ser menor que Cantidad * Valor Unitario.");
			node.constraints = {
				currency : moneda,
				places : 2
			};
			node.setValue(0, false);
			return;
		}

		if (dojo.byId("item.importeVenta").value > 99999999.99) {
			mostrarMensaje("Valores numericos calculados sobrepasan el limite permitido.")
			return;
		}

		if (dojo.byId("global.opcionISC").value == "IM01") {
			if (dijit.byId("item.sistemaIsc").getValue() > 0) {
				if (dijit.byId("item.iscPorcentaje").getValue() <= 0) {
					var node = dijit.byId("item.iscPorcentaje");
					this.warnTooltipMessage(node.focusNode, "Debe ingresar un valor mayor a cero.");
					node.setValue(0, false);
					return;
				}
				if (dijit.byId("item.iscMonto").getValue() <= 0) {
					var node = dijit.byId("item.iscMonto");
					this.warnTooltipMessage(node.focusNode, "Debe ingresar un monto mayor a cero.");

					node.constraints = {
						currency : moneda,
						places : 2
					};
					node.setValue(0, false);
					return;
				}
			}

			if (dijit.byId("item.iscPorcentaje").getValue() < 0) {
				var node = dijit.byId("item.iscPorcentaje");
				this.warnTooltipMessage(node.focusNode, "Debe ingresar un valor mayor a cero.");
				node.setValue(0, false);
				return;
			} else {
				if (dijit.byId("item.iscPorcentaje").getValue() > 0) {
					if (dijit.byId("item.sistemaIsc").getValue() <= 0) {
						var node = dijit.byId("item.sistemaIsc");
						this.warnTooltipMessage(node.focusNode, "Debe ingresar un tipo de ISC.");
						node.setValue(0, false);
						return;
					}
					if (dijit.byId("item.iscMonto").getValue() <= 0) {
						var node = dijit.byId("item.iscMonto");
						this.warnTooltipMessage(node.focusNode, "Debe ingresar un monto mayor a cero.");

						node.constraints = {
							currency : moneda,
							places : 2
						};
						node.setValue(0, false);
						return;
					}
				}
			}

			if (dijit.byId("item.iscMonto").getValue() < 0) {
				var node = dijit.byId("item.iscMonto");
				this.warnTooltipMessage(node.focusNode, "Debe ingresar un monto mayor a cero.");

				node.constraints = {
					currency : moneda,
					places : 2
				};
				node.setValue(0, false);
				return;
			} else {
				if (dijit.byId("item.iscMonto").getValue() > 0) {
					if (dijit.byId("item.sistemaIsc").getValue() <= 0) {
						var node = dijit.byId("item.sistemaIsc");
						this.warnTooltipMessage(node.focusNode, "Debe ingresar un tipo de ISC.");
						node.setValue(0, false);
						return;
					}
					if (dijit.byId("item.iscPorcentaje").getValue() <= 0) {
						var node = dijit.byId("item.iscPorcentaje");
						this.warnTooltipMessage(node.focusNode, "Debe ingresar un valor mayor a cero.");
						node.setValue(0, false);
						return;
					}
				}
			}

			var cantidadXPrecioUnitario = dijit.byId("item.cantidad").getValue() * dijit.byId("item.precioUnitario").getValue();
			//cantidadXPrecioUnitario.toFixed();
			var descuento = dijit.byId("item.precioDescuento").getValue();

			//if (dijit.byId("item.iscMonto").getValue() > (this.roundNumber(cantidadXPrecioUnitario - descuento, 2))) { /* PAS20211U210100007 */
			if (dijit.byId("item.iscMonto").getValue() > (cantidadXPrecioUnitario - descuento)) {
				var node = dijit.byId("item.iscMonto");
				this.warnTooltipMessage(node.focusNode, "Monto de ISC no debe ser mayor que (Cantidad * Valor Unitario) - Descuento.");

				node.constraints = {
					currency : moneda,
					places : 2
				};
				node.setValue(0, false);
				return;
			}

		}

		var valTipoBonif = this.getValorOpcionTipoBonif();

		if (valTipoBonif == "BO01") {
			if (dojo.style(dojo.byId("item.divOperacionGratuitaCombo1.show"), "display") == "block") { //none
				if (dijit.byId("item.operacionGratuita1").getValue() == "00") {
					var node = dijit.byId("item.operacionGratuita1");
					this.warnTooltipMessage(node.focusNode, "Debe seleccionar el tipo de Operaci\u00F3n Gratuita.");
					node.setValue(0, false);
					return;
				}
			}
			if (dojo.style(dojo.byId("item.divOperacionGratuitaCombo2.show"), "display") == "block") {}
		}

		dojo.byId("item.valOpcTipoBS").value = this.getValorOpcionTipoItem();
		dojo.byId("item.valOpcTipoBenef").value = this.getValorOpcionTipoBenef();
		dojo.byId("item.valOpcTipoBonif").value = this.getValorOpcionTipoBonif();
		dojo.byId("item.valOpcExportacion").value = dojo.byId("global.opcionExportacion").value;
		dojo.byId("item.valOpcNodomic").value = dojo.byId("global.opcionNodomic").value;
		dojo.byId("item.valOpcPagoAnticipado").value = this.getValorOpcionAnticipo();
		dojo.byId("item.boletaAnticipoFechaEmisionAux").value = dojo.byId("item.boletaAnticipoFechaEmision").value;
		var nbControl = dijit.byId("item.botonAceptar");
		nbControl.setAttribute('disabled', true);

		//var mode = dojo.byId("item.action").value;
		if (mode == "adicionarItem") {
			this.wait("Adicionando", "110px", 100);
		} else {
			this.wait("Editando", "95px", 200);
		}

		//PAS20191U210100075				
		dijit.byId("item.impuestoICBPER").attr('disabled',false);
		
		/*if (dojo.byId("global.opcionPagoAnticipado").value == "1") {
			
			dijit.byId("check.impuestoBolsasPlastica00").attr('disabled',false);
			dijit.byId("check.impuestoBolsasPlastica01").attr('disabled',false);
			dijit.byId("item.periodoBolsa").attr('disabled',false);
		}*/
		
		if (dojo.byId("global.opcionOtrosCargosTributos").value == "1") {
			dijit.byId("check.impuestoBolsasPlastica00").setAttribute('disabled', false);
			dijit.byId("check.impuestoBolsasPlastica01").setAttribute('disabled', false);
			dijit.byId("item.periodoBolsa").setAttribute('disabled', false);		
		}
				

		if (dojo.byId("global.opcionPagoDeduccionAnticipado").value =="DE01"){
				dijit.byId("check.impuestoBolsasPlastica00").setAttribute('disabled', false);
				dijit.byId("check.impuestoBolsasPlastica01").setAttribute('disabled', false);
				dijit.byId("item.periodoBolsa").setAttribute('disabled', false);		
   
		}

		var handlerItem = dojo.io.iframe.send({
				url : this.controller,
				handleAs : "json",
				sync : true,
				timeout : 10000,
				preventCache : true,
				form : "item.form"
			});

		handlerItem.addCallback(dojo.hitch(this, function (res) {
				this.waitMessage.hide();
				console.log(res.codeError);
				if (res.codeError == 0) {
					
					
					var row = eval("(" + res.data + ")");
					if (mode == "adicionarItem") {
						this.addItemAction(row);
					} else {
						
						this.editItemAction(row);
					}
					
					this.dialogItem.hide();

					var grid = dijit.byId("boleta.ingreso-grid");
					grid.setStore(this.store);

					grid.update();

					this.updateTotalAmount();
				} else {
					nbControl.setAttribute('disabled', false);
					this.iconTooltipMessage(nodeButton, "icon-error-tooltip", res.messageError);
				}
			}));

		handlerItem.addErrback(dojo.hitch(this, function (res) {
				nbControl.setAttribute('disabled', false);
				this.waitMessage.hide();
				mostrarMensaje("Problemas al conectarse al servidor");
			}));

		nbControl.setAttribute('disabled', false);
		
		//PAS20191U210100075				
		dijit.byId("item.impuestoICBPER").attr('disabled',true);
		/*if (dojo.byId("global.opcionPagoAnticipado").value == "1") {
			
			dijit.byId("check.impuestoBolsasPlastica00").attr('disabled',true);
			dijit.byId("check.impuestoBolsasPlastica01").attr('disabled',true);
			dijit.byId("item.periodoBolsa").attr('disabled',true);
		}*/
		if (dojo.byId("global.opcionOtrosCargosTributos").value == "1") {
			dijit.byId("check.impuestoBolsasPlastica00").setAttribute('disabled', true);
			dijit.byId("check.impuestoBolsasPlastica01").setAttribute('disabled', true);
			dijit.byId("item.periodoBolsa").setAttribute('disabled', true);		
		}
		if (dojo.byId("global.opcionPagoDeduccionAnticipado").value =="DE01"){
				dijit.byId("check.impuestoBolsasPlastica00").setAttribute('disabled', true);
				dijit.byId("check.impuestoBolsasPlastica01").setAttribute('disabled', true);
				dijit.byId("item.periodoBolsa").setAttribute('disabled', true);		
   
		}

		//PAS20191U210100075
		
		this.updateTotalAmount();
	},

	addItemAction : function (row) {
		row.elimina = row.identificador;
		row.editar = row.identificador;

		if (this.store == null)
			this.store = new dojo.data.ItemFileWriteStore({
					data : {
						identifier : 'identificador',
						items : [row],
						preventCache : true
					}
				});
		else
			this.store.newItem(row);
		console.log(row);
	},

	editItemAction: function (row) {			
		console.log(row);
		
		this.store.fetchItemByIdentity({
			identity : row.identificador,
			onItem : dojo.hitch(this, function (item) {
				this.store.setValue(item, "tipoItem", row.tipoItem);

				this.store.setValue(item, "tipoItemDesc", row.tipoItemDesc);
				this.store.setValue(item, "tipoBeneficio", row.tipoBeneficio);
				this.store.setValue(item, "tipoBeneficioDesc", row.tipoBeneficioDesc);

				this.store.setValue(item, "unidadMedida", row.unidadMedida);
				this.store.setValue(item, "unidadMedidaDesc", row.unidadMedidaDesc);
				//mostrarMensaje(-2);
				//this.store.setValue(item, "cantidad", dojo.number._formatAbsolute(row.cantidad,"########.##########"));
				this.store.setValue(item, "cantidad", row.cantidad);
				this.store.setValue(item, "codigoItem", row.codigoItem);
				this.store.setValue(item, "descripcion", row.descripcion);
				this.store.setValue(item, "descripcionHidden", row.descripcionHidden);
				//mostrarMensaje(-1);
				this.store.setValue(item, "descripcionFinal", row.descripcionFinal);
				this.store.setValue(item, "codigoBonificacion", row.codigoBonificacion);
				this.store.setValue(item, "codigoBonificacionDesc", row.codigoBonificacionDesc);
				//mostrarMensaje(0);
				this.store.setValue(item, "tipoOtrosCargosTributos", row.tipoOtrosCargosTributos);
				this.store.setValue(item, "tipoBonificacion", row.tipoBonificacion);
				this.store.setValue(item, "otrosCargosTributos", row.otrosCargosTributos);
				//mostrarMensaje(1);
				this.store.setValue(item, "precioUnitario", dojo.number._formatAbsolute(row.precioUnitario, "########.##########"));
				this.store.setValue(item, "precioUnitarioAux", row.precioUnitarioAux);
				this.store.setValue(item, "descuentoMonto", row.descuentoMonto);
				this.store.setValue(item, "igvMonto", row.igvMonto);
				this.store.setValue(item, "igvPorcentaje", row.igvPorcentaje);
				this.store.setValue(item, "iscSistema", row.iscSistema);
				this.store.setValue(item, "iscPorcentaje", row.iscPorcentaje);
				//mostrarMensaje(2);
				this.store.setValue(item, "iscMonto", row.iscMonto);
				this.store.setValue(item, "otrosCargos", row.otrosCargos);
				this.store.setValue(item, "otrosTributos", row.otrosTributos);
				this.store.setValue(item, "importeVenta", row.importeVenta);
				this.store.setValue(item, "valorVenta", row.valorVenta);
				this.store.setValue(item, "precioUnitario", row.precioUnitario);
				console.log("---> " + row.importeICBPER)
				this.store.setValue(item, "icbPerPorcentaje", row.ICBPER); //PAS20191U210100075
				this.store.setValue(item, "importeICBPER", row.importeICBPER); //PAS20191U210100075
				this.store.setValue(item, "esImpuestoBolsaPlastico", row.esImpuestoBolsaPlastico); //PAS20191U210100075
				
				if (row.serieBoletaAnticipo != null) {
					this.store.setValue(item, "boletaAnticipoSerie", row.serieBoletaAnticipo);
					this.store.setValue(item, "boletaAnticipoNumero", row.numeroBoletaAnticipo);
					this.store.setValue(item, "boletaAnticipoFechaEmision", row.fechaEmisionBoletaAnticipo);
					this.store.setValue(item, "boletaAnticipoMonto", row.importeTotalBoletaAnticipo);
				}
				//mostrarMensaje(3);
			}),

			onError : function () {}
		});
	},

	//PAS20175E210300029
	eliminarItemsAll : function () {
		var grilla = dijit.byId("boleta.ingreso-grid");
		var filas = grilla.rowCount;
		for (i = 0; i < filas; i++) {
			var fila = grilla.getItem(0);
			var identificador = grilla.store.getValue(fila, "identificador");
			this.deleteItemDirecto(identificador);
		}
	},

	//PAS20175E210300029
	deleteItemDirecto : function (identificador) {
		if (identificador) {
			//Ubicamos el item
			var row;
			this.store.fetchItemByIdentity({
				identity : identificador,
				onItem : function (item, request) {
					row = item;
				},
				onError : function (item, request) {
					mostrarMensaje("Ocurrio un error al ubicar el item.");
					return;
				}
			});

			//if (!confirm("Desea eliminar el item " + row.descripcion + "?.")) {
			//	return;
			//}
		}

		this.store.fetchItemByIdentity({
			identity : identificador,
			onItem : dojo.hitch(this, function (item) {
				this.wait("Eliminando", "102px", 100);
				var handler = dojo.xhrGet({
						url : this.controller + "?action=eliminarItem&idItem=" + identificador,
						handleAs : "json",
						sync : true,
						preventCache : true,
						timeout : 10000
					});
				handler.addCallback(dojo.hitch(this, function (res) {
						this.waitMessage.hide();
						if (res.codeError == 0) {
							this.store.deleteItem(item);
							var grid = dijit.byId("boleta.ingreso-grid");
							grid.setStore(this.store);
							grid.update();

							this.updateTotalAmount();
						} else {
							mostrarMensaje(res.messageError);
						}
					}));
				handler.addErrback(dojo.hitch(this, function (res) {
						this.waitMessage.hide();
						mostrarMensaje("Problemas al conectarse al servidor.");
					}));

			}),
			onError : function () {
				mostrarMensaje("Ocurrio un error al ubicar el documento.");
			}
		});
	},

	deleteItem : function (identificador) {
		if (identificador) {
			//Ubicamos el item
			var row;
			this.store.fetchItemByIdentity({
				identity : identificador,
				onItem : function (item, request) {
					row = item;
				},
				onError : function (item, request) {
					mostrarMensaje("Ocurrio un error al ubicar el item.");
					return;
				}
			});

			//if (!confirm("Desea eliminar el item " + row.descripcion + "?.")) {
			//	return;
			//}
			mostrarMensajeConfirmacion("¿Desea eliminar el ítem " + row.descripcion + "?.", dojo.hitch(this, function(){
				this.store.fetchItemByIdentity({
					identity : identificador,
					onItem : dojo.hitch(this, function (item) {
						this.wait("Eliminando", "102px", 100);
						var handler = dojo.xhrGet({
								url : this.controller + "?action=eliminarItem&idItem=" + identificador,
								handleAs : "json",
								sync : true,
								preventCache : true,
								timeout : 10000
							});
						handler.addCallback(dojo.hitch(this, function (res) {
								this.waitMessage.hide();
								if (res.codeError == 0) {
									this.store.deleteItem(item);
									var grid = dijit.byId("boleta.ingreso-grid");
									grid.setStore(this.store);
									grid.update();

									this.updateTotalAmount();
								} else {
									mostrarMensaje(res.messageError);
								}
							}));
						handler.addErrback(dojo.hitch(this, function (res) {
								this.waitMessage.hide();
								mostrarMensaje("Problemas al conectarse al servidor.");
							}));

					}),
					onError : function () {
						mostrarMensaje("Ocurrio un error al ubicar el documento.");
					}
				});			
			}));
		}
	},

	availableIsc : function () {
		var sistema = dijit.byId("item.sistemaIsc").getValue();
		var iscPorcentCtrl = dijit.byId("item.iscPorcentaje");
		var iscMontoCtrl = dijit.byId("item.iscMonto");

		if (sistema == '0') {
			iscPorcentCtrl.setValue(0);
			iscMontoCtrl.setValue(0);
			iscPorcentCtrl.setAttribute('disabled', true);
			iscMontoCtrl.setAttribute('disabled', true);
		} else if (sistema == '1' || sistema == '3') {
			iscMontoCtrl.setAttribute('disabled', true);
			iscPorcentCtrl.setAttribute('disabled', false);
			iscPorcentCtrl.focus();
		} else {
			iscPorcentCtrl.setValue(0);
			iscPorcentCtrl.setAttribute('disabled', true);
			iscMontoCtrl.setAttribute('disabled', false);
			iscMontoCtrl.setValue(0);
			iscMontoCtrl.focus();
		}
	},

	valoresNumDocRecepFENoDomic : function () {
		var tipoDocSel = dijit.byId("inicio.tipoDocRecepFENodomic").getValue().substring(0, 1);
		if (tipoDocSel == "4") {
			dijit.byId("inicio.numeroDocRecepFENodomic").attr('regExp', '[A-Za-z0-9]+[-]{0,1}[A-Za-z0-9]+');
		} else {
			dijit.byId("inicio.numeroDocRecepFENodomic").attr('regExp', '[^|\~°¬¨"]+');
		}
	},

	validateType : function () {
		var td = dijit.byId("inicio.tipoDocumento").getValue();

		ndControl = dijit.byId("inicio.numeroDocumento");
		rzControl = dijit.byId("inicio.razonSocial");

		if (dojo.byId("global.validateType").value == "0") {
			ndControl.attr('value', '');
			rzControl.attr('value', '');
		} else {
			dojo.byId("global.validateType").value = "0";
		}

		if (td == "-") {
			ndControl.attr('disabled', true);
			//rzControl.attr('disabled',true);
			ndControl.attr('regExp', '[^|\~°¬¨"]+');
			ndControl.attr('maxLength', '100');
			rzControl.attr('disabled', false);
			rzControl.focus();
		} else {
			if (td == "1") { //DNI
				ndControl.attr('disabled', false);
				ndControl.attr('regExp', '[0-9]+');
				ndControl.attr('maxLength', '8');
				rzControl.attr('disabled', true);
				ndControl.focus();
			} else {
				if (td == "6") { //RUC
					ndControl.attr('disabled', false);
					ndControl.attr('regExp', '[0-9]+');
					ndControl.attr('maxLength', '11');
					rzControl.attr('disabled', true);
					ndControl.focus();
				} else { //0, 4, 7 o A
					ndControl.attr('disabled', false);
					ndControl.attr('regExp', '[A-Za-z0-9]+[-]{0,1}[A-Za-z0-9]+');
					ndControl.attr('maxLength', '15');
					rzControl.attr('disabled', false);
					ndControl.focus();
				}
			}
		}
	},

	validateDocument : function () {
		/** Via xhr valida el ruc en el servidor y devuelve los datos */
		//var razonSocial = dijit.byId("inicio.razonSocial");
		//razonSocial.attr('value', "");
		var td = dijit.byId("inicio.tipoDocumento").getValue();
		var ndControl = dijit.byId("inicio.numeroDocumento");
		var ndLength = dojo.trim(ndControl.getValue()).length;

		dojo.byId("global.opcionDomicilioClienteIdentifica").value = "";
		dojo.byId("global.opcionDomicilioClienteDireccion").value = "";
		dojo.byId("global.opcionEstablecimientoEmisorSeleccionado").value = "";

		//if(td != '-' && ndLength == 0){
		//	mostrarMensaje("Tiene que ingresar un numero de Documento.");
		//	ndControl.focus();
		//	return;
		//}else{
		if (td == "-" && ndLength == 0) {
			return;
		} else {
			if (td == "1") { //DNI
				if (ndLength != 8) {
					mostrarMensaje("N\u00FAmero de documento de identidad inconsistente.");
					ndControl.attr('value', "");
					ndControl.focus();
					return;
				}
			} else {
				if (td == "6") { //RUC
					this.self = this;
					if (!this.isValidRuc(dojo.trim(ndControl.getValue()))) {
						mostrarMensaje("Número de RUC incorrecto.");
						ndControl.attr('value', "");
						ndControl.focus();
						return;
					}
				} else { //0, 4, 7 o A
					if (ndLength > 15) {
						mostrarMensaje("N\u00FAmero de documento de identidad y/o nombre del cliente inconsistente.");
						ndControl.attr('value', "");
						ndControl.focus();
						return;
					}
					return;
				}
			}
		}

		this.wait("Consultando", "110px", 200);
		var handler = dojo.xhrGet({
				preventCache : false,
				url : this.controller + "?action=validarAdquiriente&tipoDocumento=" + td + "&numeroDocumento=" + dojo.trim(ndControl.getValue()),
				handleAs : "json",
				sync : true,
				timeout : 10000
			});
		handler.addCallback(dojo.hitch(this, function (response) {
				this.waitMessage.hide();
				if (response.codeError == 0) {
					var rzControl = dijit.byId("inicio.razonSocial");
					rzControl.attr('value', response.data);
					//dojo.byId("global.tipoDocumento").value = td;
				} else {
					ndControl.attr('value', "");
					ndControl.focus();
					mostrarMensaje(response.messageError);
				}
			}));
		handler.addErrback(function (response) {
			this.waitMessage.hide();
			mostrarMensaje("Ocurrio un error al validar el adquiriente");
		});
	},

	//Antonio
	validateEstablecimiento : function () {
		var establecimiento = document.getElementById("establecimiento").value;
		var regexEstablecimiento = false;
		var digitoEstablecimiento = "";
		var regex2 = /[0-9]|\./;
		for (i = 0; i < establecimiento.length; i++) {
			digitoEstablecimiento = establecimiento.charAt(i);
			if (!regex2.test(digitoEstablecimiento)) { //la serie debe ser numerica incluyendo 0
				regexEstablecimiento = true;
			}
		}
		if (establecimiento !== "") { //el establecimiento debe ser diferente de vacio
			if (establecimiento.length < 5) { //el establecimiento debe ser de 4 digitos como maximo
				if (!regexEstablecimiento) { //el establecimiento debe ser de tipo numerico incluyendo 0

				} else {
					mostrarMensaje("El establecimiento debe ser num\u00E9rico");
					document.getElementById("establecimiento").value = "";
					document.getElementById("establecimiento").focus();
				}
			} else {
				mostrarMensaje("El establecimiento debe ser menor a 5 digitos");
				document.getElementById("establecimiento").value = "";
				document.getElementById("establecimiento").focus();
			}
		}

	},

	//Antonio
	validateSerie : function () {
		var serie1 = document.getElementById("serie").value;
		var numero1 = document.getElementById("numero").value;
		var regexSerie1 = false;
		var regexNumero1 = false;
		var digitoSerie1 = "";
		var digitoNumero1 = "";
		var regex1 = /[0-9]|\./;
		for (i = 0; i < serie1.length; i++) {
			digitoSerie1 = serie1.charAt(i);
			if (!regex1.test(digitoSerie1)) { //la serie debe ser numerica incluyendo 0
				regexSerie1 = true;
			}
		}

		for (i = 0; i < numero1.length; i++) {
			digitoNumero1 = numero1.charAt(i);
			if (!regex1.test(digitoNumero1)) { //el numero debe ser de tipo numerico incluyendo 0
				regexNumero1 = true;
			}
		}

		if (serie1 !== "") { //la serie debe ser diferente de vacio
			if (serie1.length == 4) { //el numero debe ser de 9 digitos como maximo
				if (!regexSerie1) { //el numero debe ser de tipo numerico incluyendo 0
					document.getElementById("numero").value = "";
					document.getElementById("numero").focus();
				} else {
					mostrarMensaje("La serie debe ser num\u00E9rica");
					document.getElementById("serie").value = "";
					document.getElementById("numero").value = "";
					document.getElementById("serie").focus();
				}
			} else {
				mostrarMensaje("la serie debe tener 4 caracteres");
				document.getElementById("serie").value = "";
				document.getElementById("numero").value = "";
				document.getElementById("serie").focus();
			}
		}

	},

	//Antonio
	validateNumero : function () {
		var serie = document.getElementById("serie").value;
		var numero = document.getElementById("numero").value;
		var establecimiento = document.getElementById("establecimiento").value;
		if (establecimiento !== "") {

			var regexSerie = false;
			var regexNumero = false;
			var digitoSerie = "";
			var digitoNumero = "";
			var regex = /[0-9]|\./;
			for (i = 0; i < serie.length; i++) {
				digitoSerie = serie.charAt(i);
				if (!regex.test(digitoSerie)) { //la serie debe ser numerica incluyendo 0
					regexSerie = true;
				}
			}

			for (i = 0; i < numero.length; i++) {
				digitoNumero = numero.charAt(i);
				if (!regex.test(digitoNumero)) { //el numero debe ser de tipo numerico incluyendo 0
					regexNumero = true;
				}
			}

			if (numero !== "") { //la serie debe ser diferente de vacio
				if (numero.length <= 9) { //el numero debe ser de 9 digitos como maximo
					if (!regexNumero) { //el numero debe ser de tipo numerico incluyendo 0
						if (serie !== "") { //la serie debe ser diferente de vacio
							if (serie.length <= 4) { //el numero debe ser de 9 digitos como maximo
								if (!regexSerie) { //el numero debe ser de tipo numerico incluyendo 0
									var handler = dojo.xhrGet({
											preventCache : false,
											url : this.controller + "?action=validadComprobante&serie=" + serie + "&numero=" + numero + "&establecimiento=" + establecimiento,
											handleAs : "json",
											sync : true,
											timeout : 10000
										});
									handler.addCallback(dojo.hitch(this, function (response) {
											this.waitMessage.hide();
											if (response.codeError == 1) {}
											else if (response.codeError == 7) {
												document.getElementById("boleta.addItemButton").focus();//PAS20221U210700028 - Ajuste de foco
												mostrarMensaje("" + response.data);
											} else {
												mostrarMensaje("" + response.data);
												document.getElementById("numero").value = "";
												document.getElementById("numero").focus();
											}
										}));
									handler.addErrback(function (response) {
										this.waitMessage.hide();
										mostrarMensaje("Ocurri\u00F3 un error al validar datos del comprobante");
									});
								} else {
									mostrarMensaje("La serie debe ser num\u00E9rica");
									document.getElementById("serie").value = "";
									document.getElementById("numero").value = "";
									document.getElementById("serie").focus();
								}
							} else {
								mostrarMensaje("la serie debe tener 4 caracteres");
								document.getElementById("serie").value = "";
								document.getElementById("numero").value = "";
								document.getElementById("serie").focus();
							}
						} else {
							mostrarMensaje("ingrese la serie");
							document.getElementById("serie").value = "";
							document.getElementById("numero").value = "";
							document.getElementById("serie").focus();
						}
					} else {
						mostrarMensaje("El número debe ser de tipo num\u00E9rico");
						document.getElementById("numero").value = "";
						document.getElementById("numero").focus();
					}
				} else {
					mostrarMensaje("El numero maximo de caracteres es de 9 digitos");
					document.getElementById("numero").value = "";
					document.getElementById("numero").focus();
				}
			}
		} else {
			mostrarMensaje("Seleccione el establecimiento");
			document.getElementById("numero").value = "";
		}
	},

	validateRUCTraslado : function () {
		/** Via xhr valida el ruc en el servidor y devuelve los datos */
		var razonSocial = dijit.byId("trasladoBienes.razonSocial");
		razonSocial.attr('value', "");

		var ndControl = dijit.byId("trasladoBienes.rucTransportista");
		var ndLength = dojo.trim(ndControl.getValue()).length;
		if (ndLength != 11) {
			return;
		}

		self = this;
		if (!this.isValidRuc(dojo.trim(ndControl.getValue()))) {
			mostrarMensaje("Número de RUC incorrecto.");
			ndControl.attr('value', "");
			ndControl.focus();
			return;
		}

		this.wait("Consultando", "110px", 200);
		var handler = dojo.xhrGet({
				preventCache : false,
				url : this.controller + "?action=validarRUC&numeroDocumento=" + dojo.trim(ndControl.getValue()),
				handleAs : "json",
				sync : true,
				timeout : 10000
			});
		handler.addCallback(dojo.hitch(this, function (response) {
				this.waitMessage.hide();
				if (response.codeError == 0) {
					dijit.byId("trasladoBienes.razonSocial").attr('value', response.data);
				} else {
					var nroDoc = dijit.byId("trasladoBienes.rucTransportista");
					nroDoc.attr('value', "");
					nroDoc.focus();

					mostrarMensaje(response.messageError);

				}
			}));
		handler.addErrback(function (response) {
			this.waitMessage.hide();
			mostrarMensaje("Ocurrio un error al validar el adquiriente");
		});
	},

	showDocsLinked : function () {
		dijit.byId("docrel.tipoDocumento").reset();
		dijit.byId("docrel.serieDocumento").setValue("");
		dijit.byId("docrel.numeroDocumentoInicial").setValue("");
		dijit.byId("docrel.numeroDocumentoFinal").setValue("");

		var grid = dijit.byId("docrel-grid");
		if (grid.rowCount > 0 && this.otherDocStore == null) {
			grid.setStore(this.otherDocStore);
			grid.update();
		}
		this.dialogDocsLinked.show();
	},

	acceptDocsLinked : function () {

		this.dialogDocsLinked.hide();
	},

	showInformacionFESectorPublico : function () {

		this.dialogInfAdicional.show();
	},

	showInformacionTrasladoBienes : function () {

		this.dialogInfTrasladoBienes.show();
	},

	showPuntoPartida : function () {

		this.dialogPuntoPartida.show();
	},

	showPuntoLlegada : function () {

		this.dialogPuntoLlegada.show();
	},

	acceptInfAdicional : function () {
		if (!dijit.byId("infAdic.form").validate())
			return;
		dojo.byId("global.numeroExpediente").value = dijit.byId("infAdic.numeroExpediente").getValue();
		dojo.byId("global.ordenCompra").value = dijit.byId("infAdic.ordenCompra").getValue();
		dojo.byId("global.numeroProcesoSeleccion").value = dijit.byId("infAdic.numeroProcesoSeleccion").getValue();
		dojo.byId("global.codigoUnidadEjecutora").value = dijit.byId("infAdic.codigoUnidadEjecutora").getValue();
		dojo.byId("global.numeroContrato").value = dijit.byId("infAdic.numeroContrato").getValue();
		this.dialogInfAdicional.hide();
	},

	acceptPuntoPartida : function () {
		if (!dijit.byId("puntoPartida.form").validate())
			return;

		var tipoDireccion = this.getValorOpcionTipoDireccPP();
		if (tipoDireccion == null || tipoDireccion == "") {
			mostrarMensaje("Debe seleccionar el tipo de direcci\u00F3n del punto de partida.");
			return;
		}

		if (tipoDireccion == 1 || tipoDireccion == 2) {
			if (tipoDireccion == 2) {
				var ruc3ro = dijit.byId("puntoPartida.txt_ruc_tercero").getValue();
				if (ruc3ro == "") {
					mostrarMensaje("Debe ingresar un n\u00FAmero de RUC v\u00E1lido.");
					return;
				}
				if (ruc3ro.length != 11) {
					mostrarMensaje("Numero de RUC inv\u00E1lido");
					return;
				}

				if (!ruc3ro.matches("[0-9]+")) {
					mostrarMensaje("Numero de RUC inv\u00E1lido");
					return;
				}
			}
			var grilla = dijit.byId("puntoPartida.domiciliosGrid");
			var datos = grilla.store._arrayOfAllItems;
			var filas = grilla.store._arrayOfAllItems.length;
			var datoSel = "";
			var numSeleccionados = 0;
			for (i = 0; i < filas; i++) {
				if (dojo.byId("puntoPartida.selDomicilioGrid" + i).checked == true) {
					numSeleccionados++;
					var fila = grilla.getItem(i);
					var codigo = grilla.store.getValue(fila, "codigo");
					var ubigeo = grilla.store.getValue(fila, "ubigeo");
					var domicilio = grilla.store.getValue(fila, "domicilio");
					dojo.byId("global.opcionPuntoPartidaDireccion").value = domicilio;
					dojo.byId("puntoPartida.domicilio").value = domicilio;
					dojo.byId("puntoPartida.codigo").value = codigo;
					dojo.byId("puntoPartida.coddist").value = ubigeo;
					break;
				}
			}
			if (numSeleccionados == 0) {
				mostrarMensaje("Debe seleccionar un establecimiento.");
				return;
			}

		} else if (tipoDireccion == 3) {
			if (dojo.byId("puntoPartida.coddist").value == "" || dojo.byId("puntoPartida.coddist").value == "000000") {
				mostrarMensaje("Debe seleccionar departamento, provincia y distrito.");
				return;
			} else if (dijit.byId("puntoPartida.nomvia").getValue() == "" && dijit.byId("puntoPartida.nomzon").getValue() == "") {
				mostrarMensaje("Debe ingresar al menos uno de los campos marcados con asterisco (*).");
				return;
			} else if (dijit.byId("puntoPartida.nomvia").getValue() != "" && (dijit.byId("puntoPartida.tipvia").getValue() == "" || dijit.byId("puntoPartida.tipvia").getValue() == "11")) {
				mostrarMensaje("Debe ingresar el tipo de via.");
				return;
			} else if (dijit.byId("puntoPartida.nomzon").getValue() != "" && (dijit.byId("puntoPartida.tipzon").getValue() == "" || dijit.byId("puntoPartida.tipzon").getValue() == "11")) {
				mostrarMensaje("Debe ingresar al tipo de zona.");
				return;
			} else if (dijit.byId("puntoPartida.km").getValue() == "" && dijit.byId("puntoPartida.mz").getValue() == "" && dijit.byId("puntoPartida.lote").getValue() == "" && dijit.byId("puntoPartida.dep").getValue() == "" && dijit.byId("puntoPartida.int").getValue() == "") {
				mostrarMensaje("Debe ingresar al menos el kil\u00F3metro, manzana, lote, departamento o interior.");
				return;
			}
			var domicilio = "";
			if (dijit.byId("puntoPartida.nomvia").getValue() != "") {
				domicilio = dijit.byId("puntoPartida.tipvia").getDisplayedValue().substring(0, 4) + " " + dijit.byId("puntoPartida.nomvia").getValue() + " " + dijit.byId("puntoPartida.num").getValue();
			}

			if (dijit.byId("puntoPartida.nomzon").getValue() != "") {
				domicilio = domicilio + " " + dijit.byId("puntoPartida.tipzon").getDisplayedValue().substring(0, 4) + " " + dijit.byId("puntoPartida.nomzon").getValue();
			}
			if (dijit.byId("puntoPartida.mz").getValue() != "") {
				domicilio = domicilio + " MZA. " + dijit.byId("puntoPartida.mz").getValue();
			}
			if (dijit.byId("puntoPartida.lote").getValue() != "") {
				domicilio = domicilio + " LOTE. " + dijit.byId("puntoPartida.lote").getValue();
			}
			if (dijit.byId("puntoPartida.dep").getValue() != "") {
				domicilio = domicilio + " DPTO. " + dijit.byId("puntoPartida.dep").getValue();
			}
			if (dijit.byId("puntoPartida.int").getValue() != "") {
				domicilio = domicilio + " INT. " + dijit.byId("puntoPartida.int").getValue();
			}
			if (dijit.byId("puntoPartida.km").getValue() != "") {
				domicilio = domicilio + " KM. " + dijit.byId("puntoPartida.km").getValue();
			}
			if (dijit.byId("puntoPartida.refer").getValue() != "") {
				domicilio = domicilio + " " + dijit.byId("puntoPartida.refer").getValue();
			}

			domicilio = domicilio + (" ") + dijit.byId("puntoPartida.emisorDpto").getDisplayedValue() + "-" +
				dijit.byId("puntoPartida.emisorProv").getDisplayedValue() + "-" +
				dijit.byId("puntoPartida.emisorDist").getDisplayedValue();

			dojo.byId("global.opcionPuntoPartidaDireccion").value = domicilio;
		}

		this.wait("Procesando", "95px", 200);

		var handler = dojo.io.iframe.send({
				url : this.controller,
				handleAs : "json",
				sync : true,
				timeout : 10000,
				preventCache : true,
				form : "puntoPartida.form"
			});

		handler.addCallback(dojo.hitch(this, function (res) {
				this.waitMessage.hide();
				if (res.codeError == 0) {
					this.dialogPuntoPartida.hide();

				} else {
					mostrarMensaje(res.messageError);
					nbControl.attr('disabled', false);

				}
			}));

		handler.addErrback(function (res) {
			nbControl.attr('disabled', false);
			this.waitMessage.hide();
			mostrarMensaje("Problemas al conectarse con el servidor");
		});

	},

	acceptPuntoLlegada : function () {
		if (!dijit.byId("puntoLlegada.form").validate())
			return;

		var tipoDireccion = this.getValorOpcionTipoDireccPLL();
		if (tipoDireccion == null || tipoDireccion == "") {
			mostrarMensaje("Debe seleccionar el tipo de direcci\u00F3n del punto de llegada.");
			return;
		}

		if (tipoDireccion == 1 || tipoDireccion == 2) {
			if (tipoDireccion == 2) {
				var ruc3ro = dijit.byId("puntoLlegada.txt_ruc_tercero").getValue();
				if (ruc3ro == "") {
					mostrarMensaje("Debe ingresar un n\u00FAmero de RUC v\u00E1lido.");
					return;
				}
				if (ruc3ro.length != 11) {
					mostrarMensaje("Numero de RUC inv\u00E1lido");
					return;
				}

				if (!ruc3ro.matches("[0-9]+")) {
					mostrarMensaje("Numero de RUC inv\u00E1lido");
					return;
				}
			}
			var grilla = dijit.byId("puntoLlegada.domiciliosGrid");
			var datos = grilla.store._arrayOfAllItems;
			var filas = grilla.store._arrayOfAllItems.length;
			var datoSel = "";
			var numSeleccionados = 0;
			for (i = 0; i < filas; i++) {
				if (dojo.byId("puntoLlegada.selDomicilioGrid" + i).checked == true) {
					numSeleccionados++;
					var fila = grilla.getItem(i);
					var codigo = grilla.store.getValue(fila, "codigo");
					var ubigeo = grilla.store.getValue(fila, "ubigeo");
					var domicilio = grilla.store.getValue(fila, "domicilio");
					dojo.byId("global.opcionPuntoLlegadaDireccion").value = domicilio;
					dojo.byId("puntoLlegada.domicilio").value = domicilio;
					dojo.byId("puntoLlegada.codigo").value = codigo;
					dojo.byId("puntoLlegada.coddist").value = ubigeo;
					break;
				}
			}
			if (numSeleccionados == 0) {
				mostrarMensaje("Debe seleccionar un establecimiento.");
				return;
			}

		} else if (tipoDireccion == 3) {
			if (dojo.byId("puntoLlegada.coddist").value == "") {
				mostrarMensaje("Debe seleccionar departamento, provincia y distrito.");
				return;
			} else if (dijit.byId("puntoLlegada.nomvia").getValue() == "" && dijit.byId("puntoLlegada.nomzon").getValue() == "") {
				mostrarMensaje("Debe ingresar al menos uno de los campos marcados con asterisco (*).");
				return;
			} else if (dijit.byId("puntoLlegada.nomvia").getValue() != "" && (dijit.byId("puntoLlegada.tipvia").getValue() == "" || dijit.byId("puntoLlegada.tipvia").getValue() == "11")) {
				mostrarMensaje("Debe ingresar el tipo de via.");
				return;
			} else if (dijit.byId("puntoLlegada.nomzon").getValue() != "" && (dijit.byId("puntoLlegada.tipzon").getValue() == "" || dijit.byId("puntoLlegada.tipzon").getValue() == "11")) {
				mostrarMensaje("Debe ingresar al tipo de zona.");
				return;
			} else if (dijit.byId("puntoLlegada.km").getValue() == "" && dijit.byId("puntoLlegada.mz").getValue() == "" && dijit.byId("puntoLlegada.lote").getValue() == "" && dijit.byId("puntoLlegada.dep").getValue() == "" && dijit.byId("puntoLlegada.int").getValue() == "") {
				mostrarMensaje("Debe ingresar al menos el kil\u00F3metro, manzana, lote, departamento o interior.");
				return;
			}
			var domicilio = "";
			if (dijit.byId("puntoLlegada.nomvia").getValue() != "") {
				domicilio = dijit.byId("puntoLlegada.tipvia").getDisplayedValue().substring(0, 4) + " " + dijit.byId("puntoLlegada.nomvia").getValue() + " " + dijit.byId("puntoLlegada.num").getValue();
			}

			if (dijit.byId("puntoLlegada.nomzon").getValue() != "") {
				domicilio = domicilio + " " + dijit.byId("puntoLlegada.tipzon").getDisplayedValue().substring(0, 4) + " " + dijit.byId("puntoLlegada.nomzon").getValue();
			}
			if (dijit.byId("puntoLlegada.mz").getValue() != "") {
				domicilio = domicilio + " MZA. " + dijit.byId("puntoLlegada.mz").getValue();
			}
			if (dijit.byId("puntoLlegada.lote").getValue() != "") {
				domicilio = domicilio + " LOTE. " + dijit.byId("puntoLlegada.lote").getValue();
			}
			if (dijit.byId("puntoLlegada.dep").getValue() != "") {
				domicilio = domicilio + " DPTO. " + dijit.byId("puntoLlegada.dep").getValue();
			}
			if (dijit.byId("puntoLlegada.int").getValue() != "") {
				domicilio = domicilio + " INT. " + dijit.byId("puntoLlegada.int").getValue();
			}
			if (dijit.byId("puntoLlegada.km").getValue() != "") {
				domicilio = domicilio + " KM. " + dijit.byId("puntoLlegada.km").getValue();
			}
			if (dijit.byId("puntoLlegada.refer").getValue() != "") {
				domicilio = domicilio + " " + dijit.byId("puntoLlegada.refer").getValue();
			}

			domicilio = domicilio + (" ") + dijit.byId("puntoLlegada.emisorDpto").getDisplayedValue() + "-" +
				dijit.byId("puntoLlegada.emisorProv").getDisplayedValue() + "-" +
				dijit.byId("puntoLlegada.emisorDist").getDisplayedValue();

			dojo.byId("global.opcionPuntoLlegadaDireccion").value = domicilio;
		}

		this.wait("Procesando", "95px", 200);

		var handler = dojo.io.iframe.send({
				url : this.controller,
				handleAs : "json",
				sync : true,
				timeout : 10000,
				preventCache : true,
				form : "puntoLlegada.form"
			});

		handler.addCallback(dojo.hitch(this, function (res) {
				this.waitMessage.hide();
				if (res.codeError == 0) {
					this.dialogPuntoLlegada.hide();

				} else {
					mostrarMensaje(res.messageError);
					nbControl.attr('disabled', false);

				}
			}));

		handler.addErrback(function (res) {
			nbControl.attr('disabled', false);
			this.waitMessage.hide();
			mostrarMensaje("Problemas al conectarse con el servidor");
		});

	},

	closePuntoPartida : function () {
		this.dialogPuntoPartida.hide();
	},

	closePuntoLlegada : function () {
		this.dialogPuntoLlegada.hide();
	},

	closeTrasladoBienes : function () {

		if (this.getValorOpcionSujetoRealizaTraslado() == "") {
			mostrarMensaje("Debe seleccionar el sujeto que realizar\u00E1 el traslado.")
			return;
		}

		if (this.getValorOpcionModalidadTraslado() == "") {
			mostrarMensaje("Debe seleccionar la modalidad del traslado.")
			return;
		}

		if (this.getValorOpcionSujetoRealizaTraslado() == "1") {
			if (this.getValorOpcionModalidadTraslado() == "1") {
				if (dijit.byId("trasladoBienes.placaVehiculo").getValue() == "") {
					mostrarMensaje("Debe registrar la placa del Vehiculo");
					return;
				}

				if (dijit.byId("trasladoBienes.marcaVehiculo").getValue() == "") {
					mostrarMensaje("Debe registrar la marca del Vehiculo");
					return;
				}

				if (dijit.byId("trasladoBienes.nroLicenciaConducir").getValue() == "") {
					mostrarMensaje("Debe registrar el numero de licencia de conducir del conductor.");
					return;
				}
			} else {
				if (dijit.byId("trasladoBienes.rucTransportista").getValue() == "" || dijit.byId("trasladoBienes.razonSocial").getValue() == "") {
					mostrarMensaje("Debe registrar el numero de RUC del transportista.");
					return;
				}

			}
		}

		this.dialogInfTrasladoBienes.hide();
	},

	/*
	showMoreInfo: function() {
	var ndControl = dijit.byId("boleta.numeroDocumento");
	if(!this.isValidRuc(ndControl.getValue())) {
	ndControl.warnTooltipMessage("N&uacute;mero de RUC incorrecto");
	ndControl.setValue("");
	ndControl.focus();
	return;
	}

	this.wait("Consultando", "110px", 100);
	var handler = dojo.xhrGet({
	url: this.controller + "?action=consultaPorRuc&ruc=" + ndControl.getValue(),
	handleAs: "json",
	sync: true,
	timeout: 10000
	});
	handler.addCallback(dojo.hitch(this, function(res){
	this.waitMessage.hide();
	if(res.codeError == 0) {
	var row = eval("(" + res.data + ")");
	dojo.byId("vermas.ddp_numruc").innerHTML = row.ddp_numruc;
	dojo.byId("vermas.ddp_nombre").innerHTML = row.ddp_nombre;
	dojo.byId("vermas.ddp_comercial").innerHTML = row.ddp_nombre;
	dojo.byId("vermas.ddp_tpoemp_desc").innerHTML = row.ddp_tpoemp_desc;
	dojo.byId("vermas.ddp_fecalt").innerHTML = row.ddp_fecalt;
	dojo.byId("vermas.ddp_fecact").innerHTML = row.ddp_fecact;
	dojo.byId("vermas.ddp_estado_desc").innerHTML = row.ddp_estado_desc;
	dojo.byId("vermas.ddp_flag22_desc").innerHTML = row.ddp_flag22_desc;
	dojo.byId("vermas.direccion_desc").innerHTML = row.direccion_desc;
	this.dialogMoreInfo.show();
	}
	else this.messageBox(res.messageError);
	}));
	handler.addErrback(dojo.hitch(this, function(res) {
	this.waitMessage.hide();
	this.messageBox("Problemas al conectarse al servidor");
	}));
	},
	 */

	closeMoreInfo : function () {
		this.dialogMoreInfo.hide();
	},

	printDocument : function () {
		window.open(this.controller + "?action=imprimirComprobante&preventCache=" + this.preventCache(), "imprimeCP", "toolbar=0,location=0,directories=0,status=no,menubar=0,scrollbars=yes,resizable=yes,width=820,height=580,titlebar=no");
	},

	mostrarTaxFree : function (id) {
		mostrarMensaje("La constancia de TAX FREE tambi\u00E9n puede ser descargada desde la opci\u00F3n Consultas/FE Emitidas desde SOL");
		var formPDF = dojo.byId("formPDF");
		formPDF.submit();
		//window.open(this.controller + "?action=mostrarTaxFree&preventCache=" + this.preventCache(), "imprimeTaxFree" , "toolbar=0,location=0,directories=0,status=no,menubar=0,scrollbars=yes,resizable=yes,width=820,height=580,titlebar=no");
		//window.open("http://192.168.46.20:8080/cl-at-framework-unloadfile/descargaArchivoAlias?data0_sis_id=1000&data0_num_id=" + id, "imprimeTaxFree" , "toolbar=0,location=0,directories=0,status=no,menubar=0,scrollbars=yes,resizable=yes,width=820,height=580,titlebar=no");
	},

	downloadDocument : function () {
		var formArchivo = dojo.byId("formArchivo");
		formArchivo.submit();
	},

	// PAS20211U210100010 -- Inicio
	downloadPdfDocument : function () {
		var formDocupdf = dojo.byId("formDocumBoletaPDF");
		formDocupdf.submit();
	},
	// PAS20211U210100010 -- Fin
	
	evalTypeDocument : function () {
		var ndControl = dijit.byId("boleta.numeroDocumento");
		ndControl.invalidateCancel();
		var td = dijit.byId("boleta.tipoDocumento").getValue();
		if (td == '6' || td == '1') {
			ndControl.attr('disabled', false);
			this.setReadOnly("boleta.razonSocial", true);
			ndControl.focus();
		} else {
			var rsControl = dijit.byId("boleta.razonSocial");
			this.setReadOnly(rsControl, false);
			if (td == '-') {
				ndControl.attr('disabled', true);
				ndControl.setValue("");
				rsControl.focus();
			} else {
				ndControl.attr('disabled', false);
				ndControl.focus();
			}
		}
		this.validateDocument();
	},

	updateUnFormat : function () {
		var moneda = dojo.byId("global.tipoMoneda").value;

		var valor = dijit.byId("item.cantidad").getValue();
		//
		dijit.byId("item.cantidad").setValue(dojo.currency.format(valor, {
				currency : moneda,
				places : '2,10'
			}));
	},

	checkValorXDcto : function () {
		var cantidadXPrecio = 0;
		var precioDescuento = 0;
		var totalConDescuento = 0;

		cantidadXPrecio = dijit.byId("item.cantidad").getValue() * dijit.byId("item.precioUnitario").getValue();
		cantidadXPrecio.toFixed();
		precioDescuento = dijit.byId("item.precioDescuento").getValue();
		totalConDescuento = cantidadXPrecio - precioDescuento;

		if (totalConDescuento < 0) {
			mostrarMensaje("Descuento no puede ser mayor a la Cantidad por el Valor Unitario.")
			dijit.byId("item.precioDescuento").setValue(0);
			dijit.byId("item.precioDescuento").focus();
			return;
		} else {
			this.updateItemAmount();
		}
	},

	updateItemAmount : function () {
		var cantidad = 0;
		var igvPorcentaje = 0;
		var cantidadXPrecio = 0;
		var precioDescuento = 0;
		var totalConDescuento = 0;
		var iscMonto = 0;
		var igvMonto = 0;
		var otroMonto = 0;
		var otroTributo = 0;
		var totalItem = 0;
		var impuestoICBPER = 0;//PAS20191U210100075
		var tasaBolsa = 0;//PAS20191U210100075

		igvPorcentaje = dojo.byId("item.igvPorcentaje").value;
		var moneda = dojo.byId("global.tipoMoneda").value;
		var tipoItem = this.getValorOpcionTipoItem();

		//console.dir("updateItemAmount ---> " + dijit.byId("item.cantidad").getValue());
		//console.dir("updateItemAmount ---> " + dojo.byId("item.cantidad").value);

		//PAS20191U210100075
		var valOpcionImpuestoBolsaPlastica = this.getValorOpcionImpuestoBolsaPlastica();
		if (valOpcionImpuestoBolsaPlastica != "IBP00"){ //NO > IMPUESTO BOLSAS;

			//dijit.byId("item.cantidad").constraints = {min:0,places:2}; // PAS20191U210100075 01.08
			dijit.byId("item.cantidad").constraints = {min:0.0000000001, places:'2,10',pattern:'########.00########'} // PAS20191U210100075 01.08
			dijit.byId("item.cantidad").attr('value',dijit.byId("item.cantidad").getValue());
			//dijit.byId("item.periodoBolsa").attr('disabled',true); //31.07
		}else{ // SI IMPUESTO BOLSAS				

			console.log(" -------------------->" + dijit.byId("item.cantidad").getValue());
			dijit.byId("item.cantidad").attr('value',dojo.number.format(Math.floor(dijit.byId("item.cantidad").getValue()),{places:0} ));				
			//dijit.byId("item.cantidad").constraints = {min:0,max:20000,places:0};
			//dijit.byId("item.cantidad").attr('value',dijit.byId("item.cantidad").getValue());
		}
		//PAS20191U210100075
		
		if (dojo.byId("item.valOpcTipoCTItem").value != "0" && dojo.byId("item.valOpcTipoCTItem").value != "") {
			cantidad = 1.00;
		} else {
			if (this.getValorOpcionAnticipo() == "1") {
				cantidad = 1.00;
			} else {
				cantidad = dijit.byId("item.cantidad").getValue();
			}
		}
		
		/* Inicio PAS20211U210100007
		if (isNaN(dijit.byId("item.precioUnitario").getValue()) || dijit.byId("item.precioUnitario").getValue() === undefined){
			var precioUnitario = dijit.byId("item.precioUnitario").getDisplayedValue();
			if (isNaN(precioUnitario) || precioUnitario.trim() == ""){
				precioUnitario = "0.00";
			} else {
				precioUnitario = parseFloat(precioUnitario).toFixed(2);
			}
			dijit.byId("item.precioUnitario").validate();
			dijit.byId("item.precioUnitario").set("displayedValue", precioUnitario);
		}
		Fin PAS20211U210100007 */
		
		cantidadXPrecio = cantidad * dijit.byId("item.precioUnitario").getValue();
		//cantidadXPrecio = this.round(cantidadXPrecio, 10); /* PAS20211U210100007 */
		console.log("cantidad ---> " + cantidad); /* PAS20211U210100007 */
		console.log("precioUnitario ---> " + dijit.byId("item.precioUnitario").getValue()); /* PAS20211U210100007 */
		console.log("cantidadXPrecio ---> " + cantidadXPrecio); /* PAS20211U210100007 */
		//console.dir("updateItemAmount ---> " + cantidadXPrecio);
		precioDescuento = dijit.byId("item.precioDescuento").getValue();
		console.log("item.precioDescuento ---> " + dijit.byId("item.precioDescuento").getValue()); /* PAS20211U210100007 */
		console.log("precioDescuento ---> " + precioDescuento); /* PAS20211U210100007 */
		
		//totalConDescuento = cantidadXPrecio - precioDescuento; /* PAS20211U210100007 */
		/* Inicio PAS20211U210100007 */
		if(!isNaN(precioDescuento)){
			totalConDescuento = cantidadXPrecio - precioDescuento;
		} else {
			precioDescuento = 0;
		}
		/* Fin PAS20211U210100007 */
		console.log("totalConDescuento ---> " + totalConDescuento); /* PAS20211U210100007 */

		iscMonto = dijit.byId("item.iscMonto").getValue();
		igvMonto = ((totalConDescuento + iscMonto) * igvPorcentaje);
		//igvMonto = Math.round(igvMonto * 100)/100;//PAS20201U210100171
		igvMonto = (this.round(igvMonto * 100, 10)/100); /* PAS20211U210100007 */
		
		//otroMonto = dijit.byId("item.otrosCargos").getValue();
		//otroTributo = dijit.byId("item.otrosTributos").getValue();

		//IMPORTE DE VENTA=((VALOR UNITARIO)*CANTIDAD)-(DESCUENTOS)+(IGV)+(ISC MONTO)+(OTROS CARGOS)
		totalItem = totalConDescuento + igvMonto + iscMonto; // + otroMonto + otroTributo;
		console.log("totalItemPar ---> " + totalItem);
		igvMonto = parseFloat(igvMonto).toFixed(10);
		console.log("igvMonto ---> " + igvMonto); /* PAS20211U210100007 */
		//totalItem = (this.round(totalItem, 10)).toFixed(10); /* PAS20211U210100007 */
		//console.log("totalItem ---> " + totalItem); /* PAS20211U210100007 */
		
		dijit.byId("item.precioUnitario").attr('value', dojo.currency.format(dijit.byId("item.precioUnitario").getValue(), {
				currency : moneda,
				places : '2,10'
			}));

		dijit.byId("item.precioDescuento").attr('value', dojo.currency.format(precioDescuento, {
				currency : moneda,
				places : 2
			}));
		/* Se comenta PAS20211U210100007
		dijit.byId("item.precioConIGV").attr('value', dojo.currency.format(igvMonto, {
				currency : moneda,
				places : 2
			})); */ 
		
		this.roundTenDecimalAux("item.precioConIGV", this.removeZeros(igvMonto), moneda); /* PAS20211U210100007 */
		
		dijit.byId("item.iscMonto").attr('value', dojo.currency.format(iscMonto, {
				currency : moneda,
				places : 2
			}), false);
	
	// Impuesto Bolsas Plasticas - INI: PAS20191U210100075
		
		monedades = dojo.byId("global.tipoMonedaDesc").value;
		

		console.log("updateItemAmount ---> " + dijit.byId("item.impuestoICBPER").getValue());
		console.log("updateItemAmount ---> " + dojo.byId("item.impuestoICBPER").value);
		
		if(monedades != "SOLES"){		
			impuestoICBPER = dijit.byId("item.impuestoICBPER").getValue();
			console.log("--->" + impuestoICBPER);
			console.log("--->>>" + dojo.byId("item.tasaBolsaGlobal").value);
			//dijit.byId("item.tasaBolsa").attr('value',dojo.currency.format(0, {currency: moneda, places: 2}), false);
			dijit.byId("item.impuestoICBPER").constraints = {currency:moneda, places:2};
			dijit.byId("item.impuestoICBPER").attr('value',impuestoICBPER);
			

			dijit.byId("item.tasaBolsa").attr('value',dojo.currency.format("0", {currency: moneda, places: 2}));
			dojo.byId("item.tasaBolsaGlobal").value="0";	
			console.log("--->2 " + dijit.byId("item.impuestoICBPER").getValue());			
			
		}else{	
			
			dijit.byId("item.impuestoICBPER").attr('disabled',true);
			tasaBolsa = dojo.byId("item.tasaBolsaGlobal").value;//document.getElementById("item.tasaBolsaGlobal").value;		
			dijit.byId("item.tasaBolsa").attr('value',dojo.currency.format(tasaBolsa, {currency: moneda, places: 2}));

			
			console.log("tasaBolsa " +  tasaBolsa);
			
			console.log("cantidad :" + cantidad + "  tasabolsa" + tasaBolsa);
			
			impuestoICBPER = cantidad * tasaBolsa;
			
			console.log("impuestoICBPER :" + impuestoICBPER);
			
			//impuestoICBPER = this.round(impuestoICBPER, 2); /* PAS20211U210100007 */
			
			console.log("impuestoICBPER round :" + impuestoICBPER);
			
			dijit.byId("item.impuestoICBPER").constraints = {currency:moneda, places:2};
			dijit.byId("item.impuestoICBPER").attr('value',impuestoICBPER);
			
			
		}
		
		/* Inicio PAS20201U210100285 - Giancarlo Nepo López */
		var valorMontoRedondeo = 0.00;
		if (dojo.byId("item.montoRedondeoAux") != null){ /* Validación para Boleta de Contingencia */
			if(dojo.byId("item.montoRedondeoAux") != undefined){
				/* Inicio Validación de Anticipos */
				if (dijit.byId("item.boletaAnticipoSerie").getValue() != "" && dijit.byId("item.boletaAnticipoNumero").getValue() != ""){
					valorMontoRedondeo = dojo.number.parse(dojo.byId("item.montoRedondeoAux").value);
				}
				/* Fin Validación de Anticipos */
			}
		}
		/* Fin PAS20201U210100285 - Giancarlo Nepo López */
		
		console.log("impuestoICBPER --> " + impuestoICBPER); /* PAS20211U210100007 */
		console.log("valorMontoRedondeo --> " + valorMontoRedondeo); /* PAS20211U210100007 */
		console.log("totalItem --> " + totalItem); /* PAS20211U210100007 */
		
		totalItem  = totalItem + impuestoICBPER  + valorMontoRedondeo; /* PAS20201U210100285 - Se agrega Monto de Redondeo */;
		// Impuesto Bolsas Plasticas - FIN: PAS20191U210100075

		var valTipoBonif = this.getValorOpcionTipoBonif();
		
		console.log("calculo");
		totalItem = (this.round(totalItem, 10)).toFixed(10); /* PAS20211U210100007 */
		//console.log(totalItem); /* PAS20211U210100007 */
		console.log("totalItem ---> " + totalItem); /* PAS20211U210100007 */
		console.log(valTipoBonif);
		
		if (valTipoBonif == "BO01") { //dojo.byId("global.opcionExportacion").value == "1" ||
			//totalItem  = 0 + impuestoICBPER;
			/* Se comenta PAS20211U210100007
			dijit.byId("item.importeVenta").attr('value', dojo.currency.format(totalItem, {
					currency : moneda,
					places : 2
				})); */
			this.roundTenDecimalAux("item.importeVenta", this.removeZeros(totalItem), moneda); /* PAS20211U210100007 */
		} else {
			/* Se comenta PAS20211U210100007
			dijit.byId("item.importeVenta").attr('value', dojo.currency.format(totalItem, {
					currency : moneda,
					places : 2
				})); */
			this.roundTenDecimalAux("item.importeVenta", this.removeZeros(totalItem), moneda); /* PAS20211U210100007 */
		}
	},
	
	round: function(num, decimals) {
		var n = Math.pow(10, decimals);
        return Math.round((n * num).toFixed(decimals))/n;
	},
	
	removeZeros: function(number) {
		var allowDecimals = 10;
		if (isNaN(number)){
			return;
		}
		for (var i=-8; i<=-1; i++){
			var zerosString = "";
			for (var j=1; j<=Math.abs(i); j++){
				zerosString = zerosString + "0";
			}
			if (number.substr(i) == zerosString){
				number = parseFloat(number).toFixed(allowDecimals - Math.abs(i));
				return number;
				break;
			}
		}
		number = parseFloat(number).toFixed(10);
		return number;
	},
	
	roundTenDecimalAux: function(id,value,tipoMoneda){
		var moneyAux = 	dojo.currency.format(0.00, {currency: tipoMoneda});
		moneyAux = moneyAux.replace("0.00",value);
		dijit.byId(id).setValue(moneyAux);
	},

	updateTotalAmount : function () {
		var totalDescuentos = 0;
		var totalAnticipos = 0;
		var totalISC = 0;
		var totalIGV = 0;
		var totalOtrosCargos = 0;
		var totalOtrosTributos = 0;
		var subTotalVenta = 0;
		var totalGeneral = 0;
		var valorVenta = 0;
		var totalOpGravada = 0;
		var totalOpExonerada = 0;
		var totalOpInafecta = 0;
		//PAS20191U210100075		
		var totalCBPER=0;
		var totalCBPER2=0;
		//PAS20191U210100075
		var itemMontoRedondeo = 0; /* PAS20201U210100285 - Giancarlo Nepo Lopez */

		var totalItems = this.getTotalItemsEnGrid();
		if (totalItems > 0) {
			var array = dijit.byId("boleta.ingreso-grid").store._arrayOfTopLevelItems;
			for (var i = 0; i < array.length; i++) {

				//BO00 = Operacion No gratuita
				//BO01 = Operacion Gratuita
				if (array[i].tipoBonificacion == "BO01") { // Es Operacion gratuita
					/*
					if (array[i].tipoOtrosCargosTributos == "1") {
					totalGeneral += dojo.number.parse(array[i].otrosCargos);
					}
					if (array[i].tipoOtrosCargosTributos == "2") {
					totalGeneral +=  dojo.number.parse(array[i].otrosTributos);
					}

					if((array[i].tipoOtrosCargosTributos != "1") && (array[i].tipoOtrosCargosTributos != "2")){
					if (array[i].tipoBeneficio == "TB00"){//Gravados
					totalOpGravada += (dojo.number.parse(array[i].importeVenta) - dojo.number.parse(array[i].iscMonto) - dojo.number.parse(array[i].igvMonto));
					}
					if (array[i].tipoBeneficio == "TB01"){//Exonerados
					totalOpExonerada += (dojo.number.parse(array[i].importeVenta) - dojo.number.parse(array[i].iscMonto));
					}
					if (array[i].tipoBeneficio == "TB02"){//Inafectos
					totalOpInafecta += (dojo.number.parse(array[i].importeVenta) - dojo.number.parse(array[i].iscMonto));
					}
					}
					 */
					//INI : PAS20191U210100075
					 if (array[i].importeICBPER>0){
						totalCBPER += dojo.number.parse(array[i].importeICBPER);
					}
					//FIN : PAS20191U210100075
				}else{
				
				}

				if (array[i].tipoBonificacion == "BO00") { //No es operacion Gratuita
					if (array[i].tipoOtrosCargosTributos == "1") {
						totalOtrosCargos += dojo.number.parse(array[i].otrosCargos);
					}
					if (array[i].tipoOtrosCargosTributos == "2") {
						totalOtrosTributos += dojo.number.parse(array[i].otrosTributos);
					}

					if (array[i].tipoOtrosCargosTributos == "0") {
						if (array[i].anticipo == "1") {
							totalAnticipos += dojo.number.parse(array[i].valorVenta);
						} else {
							subTotalVenta += dojo.number.parse(array[i].valorVenta);
						}
						totalDescuentos += dojo.number.parse(array[i].descuentoMonto);
					}
					totalISC += dojo.number.parse(array[i].iscMonto);
					totalIGV += dojo.number.parse(array[i].igvMonto);

					if (array[i].tipoOtrosCargosTributos == "1") {
						totalGeneral += dojo.number.parse(array[i].otrosCargos);
					}
					if (array[i].tipoOtrosCargosTributos == "2") {
						totalGeneral += dojo.number.parse(array[i].otrosTributos);
					}
					if (array[i].tipoOtrosCargosTributos == "0") {
						totalGeneral += dojo.number.parse(array[i].importeVenta);
					}

					if (dojo.byId("global.opcionExportacion").value == "0") {
						if (array[i].tipoBeneficio == "TB00") { //Gravados
							//INI : PAS20191U210100075 20.07
							//totalOpGravada += (dojo.number.parse(array[i].importeVenta) - dojo.number.parse(array[i].iscMonto) - dojo.number.parse(array[i].igvMonto));
							totalOpGravada += (dojo.number.parse(array[i].importeVenta) - dojo.number.parse(array[i].iscMonto) - dojo.number.parse(array[i].igvMonto) - dojo.number.parse(array[i].importeICBPER));
							totalOpGravada += dojo.number.parse(array[i].montoRedondeo); /* PAS20201U210100285 - Pago Anticipado */
							//FIN : PAS20191U210100075 20.07
						}
						if (array[i].tipoBeneficio == "TB01") { //Exonerados
							totalOpExonerada += (dojo.number.parse(array[i].importeVenta) - dojo.number.parse(array[i].iscMonto));
						}
						if (array[i].tipoBeneficio == "TB02") { //Inafectos
							totalOpInafecta += (dojo.number.parse(array[i].importeVenta) - dojo.number.parse(array[i].iscMonto));
						}
					}
				}

				/* Inicio PAS20201U210100285 - Giancarlo Nepo Lopez */
				if(array[i].montoRedondeo != undefined){
					itemMontoRedondeo += dojo.number.parse(array[i].montoRedondeo);
				}
				/* Fin PAS20201U210100285 - Giancarlo Nepo Lopez */

				//PAS20191U210100075				
				totalCBPER2 += dojo.number.parse(array[i].importeICBPER);	
				//PAS20191U210100075				
			}
			totalAnticipos = dojo.number._formatAbsolute(totalAnticipos, "########.##########");
			//if (subTotalVenta<>0){ 	subTotalVenta = subTotalVenta + totalAnticipos;}
			valorVenta = subTotalVenta - totalDescuentos - totalAnticipos;
			totalOpGravada = parseFloat((totalOpGravada).toFixed(2));  /* PAS20201U210100285 - Pago Anticipado */
			//totalGeneral = (valorVenta - totalDescuentos) + totalISC + totalIGV + totalOtrosCargos + totalOtrosTributos;
		}
		
		var moneda = dojo.byId("global.tipoMoneda").value;
		/* Inicio PAS20201U210100285 - Giancarlo Nepo Lopez */
		var totalRedondeo = 0.00;
		if (dojo.byId("boleta.totalMontoRedondeo") != null){ /* PAS20201U210100285 - Boleta Contingencia */
			document.getElementById("boleta.totalMontoRedondeo").style.textAlign = "right";
			dijit.byId("boleta.totalMontoRedondeo").attr('value',dojo.currency.format(dijit.byId("boleta.totalMontoRedondeo").getValue(), {currency: moneda, places: '2,2',pattern:"\u00A4 #,##0.00;\u00A4 -#,##0.00"}));
			dojo.byId("global.montoRedondeo").value = dijit.byId("boleta.totalMontoRedondeo").getValue();
			totalRedondeo = dijit.byId("boleta.totalMontoRedondeo").getValue();
		}
		
		/* Fin PAS20201U210100285 - Giancarlo Nepo Lopez */
		dijit.byId("boleta.subTotalVenta").setValue(dojo.currency.format(subTotalVenta, {
				currency : moneda,
				places : 2
			}));
		dijit.byId("boleta.totalAnticipos").setValue(dojo.currency.format(totalAnticipos, {
				currency : moneda,
				places : 2
			}));
		dijit.byId("boleta.totalDescuentos").setValue(dojo.currency.format(totalDescuentos, {
				currency : moneda,
				places : 2
			}));
		dijit.byId("boleta.totalValorVenta").setValue(dojo.currency.format(valorVenta, {
				currency : moneda,
				places : 2
			}));
		dijit.byId("boleta.totalOpGravada").setValue(dojo.currency.format((parseFloat(totalOpGravada).toFixed(2)), {
				currency : moneda,
				places : 2
			}));
		dijit.byId("boleta.totalOpExonerada").setValue(dojo.currency.format(totalOpExonerada, {
				currency : moneda,
				places : 2
			}));
		dijit.byId("boleta.totalOpInafecta").setValue(dojo.currency.format(totalOpInafecta, {
				currency : moneda,
				places : 2
			}));
		dijit.byId("boleta.totalISC").setValue(dojo.currency.format(totalISC, {
				currency : moneda,
				places : 2
			}));
		dijit.byId("boleta.totalIGV").setValue(dojo.currency.format(totalIGV, {
				currency : moneda,
				places : 2
			}));
		//dijit.byId("boleta.totalOtrosCargos").setValue(dojo.currency.format(totalOtrosCargos, {places: 2}));
		dijit.byId("boleta.totalOtrosCargos").setValue(dojo.currency.format(totalOtrosCargos, {
				currency : moneda,
				places : 2
			}));
		dijit.byId("boleta.totalOtrosCargos2").setValue(dojo.currency.format(totalOtrosCargos, {
				currency : moneda,
				places : 2
			}));
		//dijit.byId("boleta.totalOtrosTributos").setValue(dojo.currency.format(totalOtrosTributos, {places: 2}));
		dijit.byId("boleta.totalOtrosTributos").setValue(dojo.currency.format(totalOtrosTributos, {
				currency : moneda,
				places : 2
			}));
		dijit.byId("boleta.totalOtrosTributos2").setValue(dojo.currency.format(totalOtrosTributos, {
				currency : moneda,
				places : 2
			}));
		//INI : PAS20191U210100075	20.07	
		dijit.byId("boleta.totalGeneral").setValue(dojo.currency.format(parseFloat((totalGeneral + totalCBPER + itemMontoRedondeo).toFixed(2)), { /* PAS20201U210100285 - Pago Anticipado */
		//dijit.byId("boleta.totalGeneral").setValue(dojo.currency.format((totalGeneral), {
			currency : moneda,
				places : 2,
				pattern:"\u00A4 #,##0.00;\u00A4 -#,##0.00"
			}));

		/* Inicio PAS20201U210100285 - Giancarlo Nepo Lopez */
		if (totalRedondeo > 0.09 || totalRedondeo < -0.09){
			dijit.byId("boleta.totalGeneral2").setValue(dojo.currency.format(parseFloat((totalGeneral + totalCBPER + itemMontoRedondeo).toFixed(2)), { /* PAS20201U210100285 - Pago Anticipado */
			//dijit.byId("boleta.totalGeneral2").setValue(dojo.currency.format( (totalGeneral), {	
					currency : moneda,
					places : 2 ,
					pattern:"\u00A4 #,##0.00;\u00A4 -#,##0.00"
				}));
			//FIN : PAS20191U210100075 20.07
		} else {
			dijit.byId("boleta.totalGeneral2").setValue(dojo.currency.format(parseFloat((totalGeneral + totalCBPER + totalRedondeo + itemMontoRedondeo).toFixed(2)), {
			//dijit.byId("boleta.totalGeneral2").setValue(dojo.currency.format( (totalGeneral), {	
					currency : moneda,
					places : 2 ,
					pattern:"\u00A4 #,##0.00;\u00A4 -#,##0.00"
				}));
			//FIN : PAS20191U210100075 20.07
		}	
		/* Fin PAS20201U210100285 - Giancarlo Nepo Lopez */

		//PAS20191U210100075
		//nrus = this.esNrus();
		
		var totalICBPERinput = dijit.byId("boleta.totalICBPERConting");

		
		if (totalICBPERinput != undefined){			
			
			dijit.byId("boleta.totalICBPERConting").setValue(dojo.currency.format(totalCBPER2, {currency: moneda, places: 2}));	
			dijit.byId("boleta.totalICBPERConting2").setValue(dojo.currency.format(totalCBPER2, {currency: moneda, places: 2}));	//PAS20191U210100075 20.07
		}		

		//PAS20191U210100075
		
		
		dojo.byId("global.importeTotal").value = totalGeneral;
		
		

	},

	/* Inicio PAS20201U210100285 - Giancarlo Nepo Lopez */
	updateAmountRound: function(){
		var moneda = dojo.byId("global.tipoMoneda").value;
		if (dojo.byId("boleta.totalMontoRedondeo") != null){ /* PAS20201U210100285 - Boleta Contingencia */
			var node = dijit.byId("boleta.totalMontoRedondeo");
			if((!(isNaN(node.getValue()))) && (node.getValue() <= 0.09 && node.getValue() >= -0.09)){
				this.updateTotalAmount();
			} else if (isNaN(node.getValue())){
				var _node = "boleta.totalMontoRedondeo";
				var message = "El monto m&iacute;nimo es -0.09 y el m&aacute;ximo +0.09";
				var iconClass = "icon-warn-tooltip";
				if(dojo.isString(_node)) _node = dojo.byId(_node);
				dijit.showTooltip('<div class="' + iconClass + '"><div>' + message + '</div></div>', _node, []);
				dijit.byId("boleta.totalMontoRedondeo").validate();
				dijit.byId("boleta.totalMontoRedondeo").set("displayedValue", 0.00);
				this.updateTotalAmount();
				dijit.hideTooltip(_node);
			} else {
				dijit.byId("boleta.totalMontoRedondeo").set("displayedValue", 0.00);
				this.updateTotalAmount();
				dijit.byId("boleta.totalMontoRedondeo").validate();
			}
		}
	},
	
	updateAmountRoundKeyup: function(){
		if (dojo.byId("boleta.totalMontoRedondeo") != null){ /* PAS20201U210100285 - Boleta Contingencia */
			var node = dijit.byId("boleta.totalMontoRedondeo");
			//dijit.byId("boleta.totalMontoRedondeo").validate();
			if(node.getValue() > 0.09 || node.getValue() < -0.09){
				this.warnTooltipMessage(node.focusNode, "El monto m&iacute;nimo es -0.09 y el m&aacute;ximo +0.09");
			} else if (isNaN(node.getValue())){
				this.warnTooltipMessage(node.focusNode, "El monto m&iacute;nimo es -0.09 y el m&aacute;ximo +0.09");
			} else {
				dijit.hideTooltip(node.focusNode);
			}
		}
	},
	/* Fin PAS20201U210100285 - Giancarlo Nepo Lopez */

	updateCurrency : function (moneda) {
		//subTotalVentas
		var subTotalVentas = dijit.byId("boleta.subTotalVenta");
		subTotalVentas.setValue(dojo.currency.format(subTotalVentas.getValue(), {
				currency : moneda,
				places : 2
			}));

		//totalAnticipos
		var totalAnticipos = dijit.byId("boleta.totalAnticipos");
		totalAnticipos.setValue(dojo.currency.format(totalAnticipos.getValue(), {
				currency : moneda,
				places : 2
			}));

		//totalDescuentos
		var totalDescuentos = dijit.byId("boleta.totalDescuentos");
		totalDescuentos.setValue(dojo.currency.format(totalDescuentos.getValue(), {
				currency : moneda,
				places : 2
			}));

		//totalValorVenta
		var totalValorVenta = dijit.byId("boleta.totalValorVenta");
		totalValorVenta.setValue(dojo.currency.format(totalValorVenta.getValue(), {
				currency : moneda,
				places : 2
			}));

		//totalOpGravada
		var totalOpGravada = dijit.byId("boleta.totalOpGravada");
		totalOpGravada.setValue(dojo.currency.format(totalOpGravada.getValue(), {
				currency : moneda,
				places : 2
			}));

		//totalOpExonerada
		var totalOpExonerada = dijit.byId("boleta.totalOpExonerada");
		totalOpExonerada.setValue(dojo.currency.format(totalOpExonerada.getValue(), {
				currency : moneda,
				places : 2
			}));

		//totalOpInafecta
		var totalOpInafecta = dijit.byId("boleta.totalOpInafecta");
		totalOpInafecta.setValue(dojo.currency.format(totalOpInafecta.getValue(), {
				currency : moneda,
				places : 2
			}));

		//totalISC
		var totalISC = dijit.byId("boleta.totalISC");
		totalISC.setValue(dojo.currency.format(totalISC.getValue(), {
				currency : moneda,
				places : 2
			}));

		//totalIGV
		var totalIGV = dijit.byId("boleta.totalIGV");
		totalIGV.setValue(dojo.currency.format(totalIGV.getValue(), {
				currency : moneda,
				places : 2
			}));

		//totalOtrosCargos
		var totalOtrosCargos = dijit.byId("boleta.totalOtrosCargos");
		totalOtrosCargos.setValue(dojo.currency.format(totalOtrosCargos.getValue(), {
				currency : moneda,
				places : 2
			}));

		//totalOtrosCargos2
		var totalOtrosCargos2 = dijit.byId("boleta.totalOtrosCargos2");
		totalOtrosCargos2.setValue(dojo.currency.format(totalOtrosCargos2.getValue(), {
				currency : moneda,
				places : 2
			}));

		//totalOtrosTributos
		var totalOtrosTributos = dijit.byId("boleta.totalOtrosTributos");
		//totalOtrosTributos.setValue(dojo.currency.format(totalOtrosTributos.getValue(), {places: 2}));
		totalOtrosTributos.setValue(dojo.currency.format(totalOtrosTributos.getValue(), {
				currency : moneda,
				places : 2
			}));

		//totalOtrosTributos2
		var totalOtrosTributos2 = dijit.byId("boleta.totalOtrosTributos2");
		totalOtrosTributos2.setValue(dojo.currency.format(totalOtrosTributos2.getValue(), {
				currency : moneda,
				places : 2
			}));

		//totalGeneral
		var totalGeneral = dijit.byId("boleta.totalGeneral");
		totalGeneral.setValue(dojo.currency.format(totalGeneral.getValue(), {
				currency : moneda,
				places : 2 ,
				pattern:"\u00A4 #,##0.00;\u00A4 -#,##0.00"
			}));

		//totalGeneral2
		var totalGeneral2 = dijit.byId("boleta.totalGeneral2");
		totalGeneral2.setValue(dojo.currency.format(totalGeneral2.getValue(), {
				currency : moneda,
				places : 2,
				pattern:"\u00A4 #,##0.00;\u00A4 -#,##0.00"
			}));

		/* Inicio PAS20201U210100285 - Giancarlo Nepo LÃ³pez */
		/* totalMontoRedondeo 
		var totalMontoRedondeo = dijit.byId("boleta.totalMontoRedondeo");
		totalMontoRedondeo.setValue(dojo.currency.format(totalMontoRedondeo.getValue(), {
			currency : moneda,
			places : 2 ,
			pattern:"\u00A4 #,##0.00;\u00A4 -#,##0.00"
		}));
		/* Fin PAS20201U210100285 - Giancarlo Nepo LÃ³pez */
			
		
		//nrus = this.esNrus();
		
		
		//PAS20191U210100075			
		var totalICBPERinput = dijit.byId("boleta.totalICBPERConting");

		
		if (totalICBPERinput != undefined){			
			
			var totalICBPER = dijit.byId("boleta.totalICBPERConting");
			
			dijit.byId("boleta.totalICBPERConting").setValue(dojo.currency.format(totalICBPER, {currency: moneda, places: 2,pattern:"\u00A4 #,##0.00;\u00A4 -#,##0.00"}));
			
		}
		//PAS20191U210100075
		dijit.byId("boleta.totalGeneral").setValue(dojo.currency.format(totalGeneral, {currency: moneda, places: 2,pattern:"\u00A4 #,##0.00;\u00A4 -#,##0.00"}));
		
		
		
		//PAS20191U210100075
	},

	addOtherDocument : function () {
		if (!dijit.byId("docrel.form").validate())
			return;

		var ndTipDoc = dijit.byId("docrel.tipoDocumento");
		var val = ndTipDoc.getValue();

		if (val == "-") {
			ndTipDoc.attr('invalidMessage', "Tiene que seleccionar el tipo de documento.");
			ndTipDoc.focus();
			return;
		}
		var ndSerie = dijit.byId("docrel.serieDocumento");
		//if (val == "01" || val == "02"){   Antes del cambio para GEM
		if (val == "09" || val == "31" || val == "09R" || val == "31R" || val == "60" || val == "62" || val == "60R" || val == "62R" || 
			val == "G9" || val == "61" || val == "63") { //PAS20221U210700300 - DAG

			var ndSerie2 = dojo.byId("docrel.serieDocumento");
			if (dojo.trim(ndSerie.value).length == 0) {
				// ndSerie.attr('invalidMessage', "Tiene que ingresar n&uacute;mero de serie");
				mostrarMensaje("Tiene que ingresar n\u00FAmero de serie");
				ndSerie.focus();
				return;
			}

			if (val == "60" || val == "62" || val == "60R" || val == "62R") { //INICIO - PAS20221U210700300 - DAG
				if (ndSerie.value != "G001" & ndSerie.value != "G010") {
					mostrarMensaje("El n&uacute;mero de serie debe ser G001 o G010");
					ndSerie.focus();
					return;
				}
			}
			
			if (val == "61" || val == "63"){ 
				if (ndSerie.value!= "G011"){
			   		mostrarMensaje( "El n&uacute;mero de serie debe ser G011.");
					ndSerie.focus();
					return;
				}
			}
		}//FIN - PAS20221U210700300 - DAG

		var ndNumero = dijit.byId("docrel.numeroDocumentoInicial");
		var ndNroDocFinal = dijit.byId("docrel.numeroDocumentoFinal");
	    if( parseInt(ndNumero.getValue()) > 0){//DAG - PAS20221U210700300

        }else{
            mostrarMensaje("Tiene que ingresar un número de documento!");
            ndNumero.focus();
            return;
        } // DAG - FIN - PAS20221U210700300
	    
		if (dojo.trim(ndNumero.getValue()).length == 0) {
			mostrarMensaje("Tiene que ingresar un número de documento");
			ndNumero.focus();
			return;
		}

		if (val == "09R" || val == "31R" || val == "60R" || val == "62R") {
			if (dojo.trim(ndNroDocFinal.getValue()).length == 0) {
				mostrarMensaje("Tiene que ingresar un número de documento");
				ndNroDocFinal.focus();
				return;
			}

			if (parseFloat(ndNumero.getValue()) >= parseFloat(ndNroDocFinal.getValue())) {
				mostrarMensaje("Numero inicial debe ser menor al numero final");
				//	ndNroDocFinal.attr('invalidMessage', "N&uacute;mero de documento debe ser mayor al inicial");
				ndNroDocFinal.focus();
				return;
			}
		}

		if (val == "09R" || val == "09") { //|| val == "60R" || val == "60"
			this.indRegitroGR++;
		}
		this.wait("Adicionando", "110px", 100);
		var nodeButton = dijit.byId("docrel.botonAddDoc").focusNode;

		if (dijit.byId("docrel-grid").rowCount > 9) {
			this.iconTooltipMessage(nodeButton, "icon-error-tooltip", "Solo puede agregar un maximo de 10 documentos relacionados.");
			this.waitMessage.hide();
			return;
		}

		var handler = dojo.xhrGet({
				url : this.controller,
				handleAs : "json",
				sync : true,
				timeout : 10000,
				preventCache : true,
				form : "docrel.form"
			});
		handler.addCallback(dojo.hitch(this, function (res) {
				this.waitMessage.hide();
				if (res.codeError == 0) {
					var oDoc = eval("(" + res.data + ")");
					var row = {
						identificador : oDoc.identificador,
						elimina : oDoc.identificador,
						tipo : oDoc.desTipoDocuRela,
						tipoCod : oDoc.tipoDocumentoRelacionado,
						serie : (oDoc.serieDocumentoRelacionado == "-" ? "" : oDoc.serieDocumentoRelacionado),
						numeroInicial : oDoc.numeroDocumentoRelacionadoInicial,
						numeroFinal : oDoc.numeroDocumentoRelacionadoFinal
					};
					if (this.otherDocStore == null)
						this.otherDocStore = new dojo.data.ItemFileWriteStore({
								data : {
									identifier : 'identificador',
									items : [row],
									preventCache : true
								}
							});
					else
						this.otherDocStore.newItem(row);
					var grid = dijit.byId("docrel-grid");
					grid.setStore(this.otherDocStore);
					grid.update();

					ndSerie.attr("readOnly", false);
					//if (val == "01" || val == "02"){   Antes del cambio para GEM
					if (val == "09" || val == "31" || val == "09R" || val == "31R" || val == "G9" ) { //INICIO - PAS20221U210700300 - DAG
						ndSerie.setValue("");
						ndNumero.setValue("");
						ndNroDocFinal.setValue("");
						ndSerie.focus();
					} else if (val == "60" || val == "62" || val == "60R" || val == "62R") {
						ndSerie.setValue("");
//						ndSerie.attr("readOnly", true);
						ndNumero.setValue("");
						ndNroDocFinal.setValue("");
						ndSerie.focus();
					}
					else if (val == "61" || val == "63") {
							ndSerie.setValue("G011");
							ndSerie.attr("readOnly", true);
							ndNumero.setValue("");
							ndNroDocFinal.setValue("");
							ndNumero.focus();
					} else {
						ndNumero.setValue("");
						ndNumero.focus();
					}//FIN - PAS20221U210700300 - DAG
				} else
					this.iconTooltipMessage(nodeButton, "icon-error-tooltip", res.messageError);
			}));
		handler.addErrback(dojo.hitch(this, function (res) {
				this.waitMessage.hide();
				this.iconTooltipMessage(nodeButton, "icon-error-tooltip", "Problemas al conectarse al servidor");
			}));
	},

	delOtherDocument : function (identificador) {
		//var nodeButton = dijit.byId("docrel.botonDelDoc").focusNode;
		var grid = dijit.byId("docrel-grid");

		if (!identificador) {
			var index = grid.getRowIndex();
			if (index > -1) {
				var row = grid.getRow(index);
				identificador = row.identificador;
			} else {
				mostrarMensaje("Seleccione un documento de la lista");
				return;
			}
		}

		this.otherDocStore.fetchItemByIdentity({
			identity : identificador,
			onItem : dojo.hitch(this, function (item) {
				this.wait("Eliminando", "102px", 100);
				var handler = dojo.xhrGet({
						url : this.controller + "?action=delOtroDocumento&idItem=" + identificador,
						handleAs : "json",
						sync : true,
						timeout : 10000
					});
				handler.addCallback(dojo.hitch(this, function (res) {
						this.waitMessage.hide();
						if (res.codeError == 0) {
							if (item.tipoCod == "09" || item.tipoCod == "09") { //|| item.tipoCod  == "60R" || item.tipoCod  == "60"
								this.indRegitroGR--;
							}
							this.otherDocStore.deleteItem(item);
							grid.setStore(this.otherDocStore);
							grid.update();
						} else {
							mostrarMensaje(res.messageError);
						}
					}));
				handler.addErrback(dojo.hitch(this, function (res) {
						this.waitMessage.hide();
						mostrarMensaje("Problemas al conectarse al servidor");
					}));

			}),
			onError : function () {
				mostrarMensaje("Ocurrio un error al ubicar el documento");
			}
		});
	},

	disableRUC : function (modo) {
		var ndRUC = dijit.byId("boleta.numeroDocumento");
		var ndDescRUC = dijit.byId("boleta.razonSocial");

		dojo.byId("boleta.situacionEspecial").value = this.getValorSituacionEspecial();

		if (modo == 0) {

			if (dojo.trim(ndRUC.getValue()) == "" && dojo.trim(ndDescRUC.getValue()) == "") {
				ndRUC.attr('disabled', false);
				ndRUC.setValue("");
				ndRUC.focus();

				ndDescRUC.attr('disabled', true);
				ndDescRUC.setValue("");
			}
			dijit.byId("boleta.tipoDocumento").attr("value", "6");
		} else {
			ndRUC.attr('disabled', true);
			ndRUC.setValue("");

			ndDescRUC.attr('disabled', false);
			ndDescRUC.setValue("");
			ndDescRUC.focus();
			dijit.byId("boleta.tipoDocumento").attr("value", "-");
		}
	},

	disableNroSerieEnDocRel : function () {
		var ndTipDoc = dijit.byId("docrel.tipoDocumento");
		var ndNroSerie = dijit.byId("docrel.serieDocumento");
		var ndNroDocInicial = dijit.byId("docrel.numeroDocumentoInicial");
		var ndNroDocFinal = dijit.byId("docrel.numeroDocumentoFinal");
		var val = ndTipDoc.getValue();
		ndNroSerie.attr("readOnly", false);
		this.showHiddenDiv(document.getElementById("docrel.numDocFinal.show"), false);
		dojo.byId("docrel.numeroIni").innerHTML = "N&uacute;mero Documento:"
			//if (val == "01" || val == "02"){   Antes del cambio para GEM
			if (val == "09" || val == "31" || val == "09R" || val == "31R" || val == "60" || val == "62" || val == "60R" || val == "62R" || val == "G9" || val == "61" || val == "63") {//PAS20221U210700300 - DAG
				ndNroSerie.attr('disabled', false);
				ndNroSerie.setValue("");

				ndNroDocInicial.setValue("");
				ndNroDocFinal.setValue("");
				dijit.byId("docrel.numeroDocumentoInicial").attr('regExp', '[0-9]+');
				dijit.byId("docrel.numeroDocumentoFinal").attr('regExp', '[0-9]+');
				dijit.byId("docrel.numeroDocumentoInicial").attr('maxLength', '10');
				dijit.byId("docrel.numeroDocumentoFinal").attr('maxLength', '10');
				if (val == "09R" || val == "31R" || val == "60R" || val == "62R") {
					dojo.byId("docrel.numeroIni").innerHTML = "N&uacute;mero Documento Inicial:"
						this.showHiddenDiv(document.getElementById("docrel.numDocFinal.show"), true);
				}
				if (val == "09" || val == "31" || val == "09R" || val == "31R") { 
					// PAS20201U210100081
					// ndNroSerie.attr('regExp', '[0-9]+');
					//ndNroSerie.attr('regExp','[E,e][G,g]01|[0-9]{4}|[T,t][A-Za-z0-9]{3}');
					  if(val == "09" || val == "09R" ){//INICIO - PAS20221U210700300 - DAG
						 // ndNroSerie.attr('regExp','[E,e][G,g]01|[E,e][G,g]02|[E,e][G,g]07|[0-9]{4}|[T,t]#99|[T,t]#|[T,t]|[T,t]|[A-Za-z0-9]{3}');
						  ndNroSerie.attr('regExp','[E,e][G,g]01|[E,e][G,g]02|[E,e][G,g]07|[0-9]{4}|[T,t][A-Za-z0-9]{3}');//dag
					  }else{
						  ndNroSerie.attr('regExp','[E,e][G,g]01|[E,e][G,g]03|[E,e][G,g]04|[0-9]{4}|[V,v][A-Za-z0-9]{3}'); 
					  }//FIN - PAS20221U210700300 - DAG
				} else {
					ndNroSerie.attr('regExp', '[Gg0-9]+');
				}
				
				            if (val == "G9" ){ //INICIO - PAS20221U210700300 - DAG
					                ndNroSerie.attr( 'regExp','[E,e][G,g]05|[E,e][G,g]06');
					//                   ndNroSerie.setValue("G001");
					                   //ndNroSerie.readOnly = true;
					//                   ndNroSerie.attr("readOnly", true);
					                   //ndNroSerie.attr('disabled',true);
					                   ndNroDocInicial.focus();
					            }else{
					                   ndNroSerie.focus();
					            }
					        
				
				            if (val == "61" || val == "63" ){
					                   ndNroSerie.setValue("G011");
					                   //ndNroSerie.readOnly = true;
					                     ndNroSerie.attr("readOnly", true);
					                   //ndNroSerie.attr('disabled',true);
					                   ndNroDocInicial.focus();
					                   ndNumero.focus();
					            }else{
					                   ndNroSerie.focus();
					            }
				
				if (val == "60" || val == "62" || val == "60R" || val == "62R") {
					ndNroSerie.attr('regExp','[G,g]001|[G,g]010');
					//ndNroSerie.readOnly = true;
//					ndNroSerie.attr("readOnly", true);
					//ndNroSerie.attr('disabled',true);
					ndNroSerie.focus();
				//	ndNroDocInicial.focus();
				} else {
					ndNroSerie.focus();
				}//FIN - PAS20221U210700300 - DAG

			} else {
				ndNroSerie.attr('disabled', true);
				ndNroDocInicial.setValue("");
				ndNroDocFinal.setValue("");
				dijit.byId("docrel.numeroDocumentoInicial").attr('regExp', '[A-Za-z0-9]+');
				dijit.byId("docrel.numeroDocumentoFinal").attr('regExp', '[A-Za-z0-9]+');
				dijit.byId("docrel.numeroDocumentoInicial").attr('maxLength', '10');
				dijit.byId("docrel.numeroDocumentoFinal").attr('maxLength', '10');
				this.showHiddenDiv(document.getElementById("docrel.numDocFinal.show"), false);
				ndNroDocInicial.focus();
			}
	},

	obtenerBoletaAnticipo : function (cambiarDatos) {
		var serie = dijit.byId("item.boletaAnticipoSerie").getValue();
		var numero = dijit.byId("item.boletaAnticipoNumero").getValue();

		if (serie == "" || numero == "") {
			return false;
		}

		if (serie == "E001" || serie.substring(0,1)=="F") {
			mostrarMensaje("N\u00FAmero de serie no v\u00E1lida.");
			return false;
		}

		//Validar documento f\u00EDsico
		//if (serie != "EB01") { //&& serie.substring(0,1)!="B" o GEM
		if (serie.substring(0,2)!="EB" && serie.substring(0,1)!="B"){
			dijit.byId("item.boletaAnticipoMonto").attr('disabled', false);

			var handler2 = dojo.xhrGet({
					url : this.controller + "?action=validarRangosCPAutorizados&tipoCP=" + "01" + "&nroSerieCP=" + serie + "&nroInicial=" + numero + "&nroFinal=" + numero,
					handleAs : "json",
					sync : true,
					timeout : 10000
				});
			handler2.addCallback(dojo.hitch(this, function (res) {
					if (res.codeError == 0) {
						if (cambiarDatos) {
							dijit.byId("item.descripcion").setValue("ANTICIPO: BOLETA DE VENTA NRO. " + serie + "-" + numero);
						}
						return true;
					} else {
						mostrarMensaje(res.messageError);
						return false;
					}
				}));
			handler2.addErrback(function (res) {
				this.waitMessage.hide();
				mostrarMensaje("Problemas al conectarse con el servidor");
				return false;
			});
			dijit.byId("item.boletaAnticipoMonto").attr('readOnly', false);
			return true;
		} else {}

		var handler = dojo.xhrGet({
				url : this.controller + "?action=obtenerBoletaAnticipo&serie=" + serie + "&numero=" + numero,
				handleAs : "json",
				sync : true,
				timeout : 10000
			});

		handler.addCallback(dojo.hitch(this, function (res) {
				if (res.codeError == 0) {
					if (res.data != null && res.data != "") {
						this.beanDatosCP = eval("(" + res.data + ")");
						if (this.beanDatosCP.subTipoComprobante != null) {
							//PAS20191U210300015
							if (dojo.byId("global.tipoMoneda").value != this.beanDatosCP.codigoMoneda){
								//mostrarMensaje(this.beanDatosCP.codigoMoneda);
								this.disableMontosItem();
								dijit.byId("item.boletaAnticipoMonto").setValue("");
								dijit.byId("item.precioUnitario").setValue(0);
								dojo.byId("item.boletaAnticipoFechaEmision").value = "";
								dojo.byId("item.boletaAnticipoFechaEmisionAux").value = "";
								dijit.byId("item.descripcion").setValue("");
								mostrarMensaje("El comprobante ingresado no puede tener otra moneda diferente al comprobante de referencia de anticipo.");
								return false;
							}
							
							if (cambiarDatos) {
								if (serie == "EB01") {
									dijit.byId("item.boletaAnticipoMonto").attr('readOnly', true);
									dijit.byId("item.iscMonto").attr('disabled', true);
									/* Inicio PAS20201U210100285 - Giancarlo Nepo LÃ³pez */
									if (dojo.byId("item.montoRedondeoAux") != null){ /* PAS20201U210100285 - Boleta Contingencia */
										dojo.byId("item.montoRedondeoAux").value = this.beanDatosCP.montoRedondeo; 
									}
									/* Fin PAS20201U210100285 - Giancarlo Nepo LÃ³pez */
									dijit.byId("item.boletaAnticipoMonto").setValue(dojo.number.format(this.beanDatosCP.montoTotalGeneral, {
											places : 2
										}));
									dijit.byId("item.precioUnitario").setValue(dojo.number.format(this.beanDatosCP.totalValorVenta, {
											places : '2,10'
										}));
									dijit.byId("item.iscMonto").setValue(dojo.number.format(this.beanDatosCP.totalISC, {
											places : 2
										}));
									dijit.byId("item.iscMonto").attr('disabled', true);
									if (this.beanDatosCP.totalISC != null && this.beanDatosCP.totalISC != "" && this.beanDatosCP.totalISC != "0") {
										dijit.byId("item.sistemaIsc").setValue("02");
										dijit.byId("item.iscPorcentaje").setValue("1");
									} else {
										dijit.byId("item.sistemaIsc").setValue("0");
										dijit.byId("item.iscPorcentaje").setValue("0");
									}

									dijit.byId("item.sistemaIsc").attr('disabled', true);
									dijit.byId("item.iscPorcentaje").attr('disabled', true);
									if (this.beanDatosCP.fechaEmision != "") {
										dojo.byId("item.boletaAnticipoFechaEmision").value = this.beanDatosCP.fechaEmision;
										dojo.byId("item.boletaAnticipoFechaEmisionAux").value = this.beanDatosCP.fechaEmision;
									}
									dijit.byId("item.descripcion").setValue("ANTICIPO: BOLETA DE VENTA NRO. " + serie + "-" + numero);
									//Inicio IGV10-JRGS
									if (this.beanDatosCP.detalleComprobanteBean[0].igvPorcentaje !=null ){
										if (this.beanDatosCP.detalleComprobanteBean[0].igvPorcentaje =="18.00")//Por mejorar
										{
											dijit.byId("item.subTipoIgv00").setChecked("checked");
											dijit.byId("item.subTipoIgv00").attr("disabled",true);
											dijit.byId("item.subTipoIgv01").attr("disabled",true);	        							
										}
										if (this.beanDatosCP.detalleComprobanteBean[0].igvPorcentaje =="10.00")//Por mejorar
										{
											dijit.byId("item.subTipoIgv01").setChecked("checked");
											dojo.byId("item.igvPorcentaje").value=this.igv10;//Por mejorar
											dijit.byId("item.subTipoIgv00").attr("disabled",true);
											dijit.byId("item.subTipoIgv01").attr("disabled",true);	        							
										}
									}
									//Fin IGV10-JRGS
									if (this.beanDatosCP.detalleComprobanteBean[0].tipoBeneficio != null) {
										if (this.beanDatosCP.detalleComprobanteBean[0].tipoBeneficio == "TB00") {
											dijit.byId("item.subTipoTB00").setChecked("checked");
											dijit.byId("item.subTipoTB00").attr("disabled", true);
											dijit.byId("item.subTipoTB01").attr("disabled", true);
											dijit.byId("item.subTipoTB02").attr("disabled", true);
										}
										if (this.beanDatosCP.detalleComprobanteBean[0].tipoBeneficio == "TB01") {
											dijit.byId("item.subTipoTB01").setChecked("checked");
											dojo.byId("item.igvPorcentaje").value = "0";
											dijit.byId("item.precioConIGV").setValue(0, false);
											dijit.byId("item.subTipoTB00").attr("disabled", true);
											dijit.byId("item.subTipoTB01").attr("disabled", true);
											dijit.byId("item.subTipoTB02").attr("disabled", true);
										}
										if (this.beanDatosCP.detalleComprobanteBean[0].tipoBeneficio == "TB02") {
											dijit.byId("item.subTipoTB02").setChecked("checked");
											dojo.byId("item.igvPorcentaje").value = "0";
											dijit.byId("item.precioConIGV").setValue(0, false);
											dijit.byId("item.subTipoTB00").attr("disabled", true);
											dijit.byId("item.subTipoTB01").attr("disabled", true);
											dijit.byId("item.subTipoTB02").attr("disabled", true);
										}
									}
									this.updateItemAmount(); /* PAS20201U210100285 - Pago Anticipado */
									//return true;
								} else {
									dijit.byId("item.boletaAnticipoMonto").attr('readOnly', true);
									dijit.byId("item.boletaAnticipoMonto").setValue(dojo.number.format(this.beanDatosCP.montoTotalGeneral, {
											places : 2
										}));
									if (this.beanDatosCP.fechaEmision != "") {
										dojo.byId("item.boletaAnticipoFechaEmision").value = this.beanDatosCP.fechaEmision;
										dojo.byId("item.boletaAnticipoFechaEmisionAux").value = this.beanDatosCP.fechaEmision;
									}
									dijit.byId("item.descripcion").setValue("ANTICIPO: BOLETA DE VENTA NRO. " + serie + "-" + numero);
									//return true;
								}
							}
							return true;
						} else {
							this.disableMontosItem();
							dijit.byId("item.boletaAnticipoMonto").setValue("");
							dijit.byId("item.precioUnitario").setValue(0);
							dojo.byId("item.boletaAnticipoFechaEmision").value = "";
							dojo.byId("item.boletaAnticipoFechaEmisionAux").value = "";
							dijit.byId("item.descripcion").setValue("");

							mostrarMensaje(res.messageError);
							return false;
						}
					}
				} else {
					this.disableMontosItem();
					dijit.byId("item.boletaAnticipoMonto").setValue("");
					//dijit.byId("item.precioUnitario").setValue(dojo.number.format(0,{places:2,10} ));
					dijit.byId("item.precioUnitario").setValue(0);
					dojo.byId("item.boletaAnticipoFechaEmision").value = "";
					dojo.byId("item.boletaAnticipoFechaEmisionAux").value = "";
					dijit.byId("item.descripcion").setValue("");

					dijit.byId("item.subTipoTB00").attr("disabled", false);
					dijit.byId("item.subTipoTB01").attr("disabled", false);
					dijit.byId("item.subTipoTB02").attr("disabled", false);

					mostrarMensaje(res.messageError);
					return false;
				}
			}));
		handler.addErrback(function (res) {
			this.waitMessage.hide();
			mostrarMensaje("Problemas al conectarse con el servidor." + res.messageError);
			return false;
		});
	},

	disableMontosItem : function () {
		var moneda = dojo.byId("global.tipoMoneda").value;

		var otrosCargosTrib = dojo.byId("item.valOpcTipoCTItem").value;
		var anticipo = this.getValorOpcionAnticipo();
		if (dojo.byId("global.opcionDscto").value == "DE00") {
			dijit.byId("item.precioDescuento").setValue(0, false);
			dijit.byId("item.precioDescuento").attr("disabled", true);
		} else {

			if (otrosCargosTrib == "0" || otrosCargosTrib == "") {

				dijit.byId("item.precioDescuento").attr("disabled", false);
			} else {
				dijit.byId("item.precioDescuento").setValue(0, false);
				dijit.byId("item.precioDescuento").attr('disabled', true);
				dijit.byId("item.precioDescuento").constraints = {
					currency : moneda,
					places : 2
				};
			}

		}

		valTipoBonif = this.getValorOpcionTipoBonif();
		if (valTipoBonif == "BO01") {
			this.showHiddenDiv(document.getElementById("item.divOperacionGratuitaCombo.show"), true);

			if (otrosCargosTrib == "" || otrosCargosTrib == "0") {
				this.showHiddenDiv(document.getElementById("item.divOperacionGratuitaCombo2.show"), false);
				this.showHiddenDiv(document.getElementById("item.divOperacionGratuitaCombo1.show"), true);
			} else {
				this.showHiddenDiv(document.getElementById("item.divOperacionGratuitaCombo2.show"), true);
				this.showHiddenDiv(document.getElementById("item.divOperacionGratuitaCombo1.show"), false);
			}
			dijit.byId("item.precioDescuento").setValue(0, false);
			dijit.byId("item.precioDescuento").attr("disabled", true);

		} else {

			this.showHiddenDiv(document.getElementById("item.divOperacionGratuitaCombo.show"), false);
			if (dojo.byId("global.opcionDscto").value == "DE00") {
				dijit.byId("item.precioDescuento").setValue(0, false);
				dijit.byId("item.precioDescuento").attr("disabled", true);
			} else {

				if (otrosCargosTrib == "0" || otrosCargosTrib == "") {

					dijit.byId("item.precioDescuento").attr("disabled", false);
				} else {
					dijit.byId("item.precioDescuento").setValue(0, false);
					dijit.byId("item.precioDescuento").attr('disabled', true);
					dijit.byId("item.precioDescuento").constraints = {
						currency : moneda,
						places : 2
					};
				}
			}
		}

		if (otrosCargosTrib == "0" || otrosCargosTrib == "") {
			dijit.byId("item.cantidad").attr('disabled', false);
			if (!dijit.byId("item.cantidad").getValue()) {
				dijit.byId("item.cantidad").setValue(1);
			}
			dijit.byId("item.unidadMedida").attr('disabled', false);
			//  				dijit.byId("item.unidadMedida").setValue("NIU");
			dijit.byId("item.unidadMedida").focus();

		} else {

			dijit.byId("item.cantidad").setValue("");
			dijit.byId("item.cantidad").attr('disabled', true);

			dijit.byId("item.unidadMedida").setValue("000");
			dijit.byId("item.unidadMedida").attr('disabled', true);
		}

		if (dojo.byId("global.opcionExportacion").value == "1" ||
			dojo.byId("global.opcionISC").value == "IM00" ||
			(otrosCargosTrib != "0" && otrosCargosTrib != "")) {
			dijit.byId("item.sistemaIsc").setValue("0");
			dijit.byId("item.sistemaIsc").attr('disabled', true);

			dijit.byId("item.iscPorcentaje").setValue(0, false);
			dijit.byId("item.iscPorcentaje").attr('disabled', true);

			dijit.byId("item.iscMonto").setValue(0, false);
			dijit.byId("item.iscMonto").constraints = {
				currency : moneda,
				places : 2
			};
			dijit.byId("item.iscMonto").attr('disabled', true);

		} else {
			dijit.byId("item.sistemaIsc").attr('disabled', false);
			dijit.byId("item.iscPorcentaje").attr('disabled', false);

			dijit.byId("item.iscMonto").constraints = {
				currency : moneda,
				places : 2
			};
			dijit.byId("item.iscMonto").attr('disabled', false);
		}

		//PAS20181U210300095
		if (dojo.byId("global.opcionExportacion").value == "1" ||
			(otrosCargosTrib != "0" && otrosCargosTrib != "") ||
			dojo.byId("global.perteneceBVNRUS").value == "1") {
			this.showTipoBeneficio(0);
		} else {
			this.showTipoBeneficio(1); //Mostramos igv
		}

		if (anticipo == "1") {
			dijit.byId("item.precioDescuento").setValue(0, false);
			dijit.byId("item.precioDescuento").attr('disabled', true);
			dijit.byId("item.precioDescuento").constraints = {
				currency : moneda,
				places : 2
			};
			dijit.byId("item.cantidad").setValue("1");
			dijit.byId("item.cantidad").attr('disabled', true);

			dijit.byId("item.unidadMedida").setValue("000");
			dijit.byId("item.unidadMedida").attr('disabled', true);
		}
		dijit.byId("item.importeVenta").constraints = {
			currency : moneda,
			places : 2
		};
		dijit.byId("item.importeVenta").attr('disabled', true);
	},

	getValorOpcionSujetoRealizaTraslado : function () {
		var valOpcionSujetoRealizaTraslado = "";
		for (i = 1; i < 3; i++) {
			if (dijit.byId("trasladoBienes.idSujetoRealizaTraslado0" + i).getValue() != false) {
				valOpcionSujetoRealizaTraslado = dijit.byId("trasladoBienes.idSujetoRealizaTraslado0" + i).getValue()
			}
		}
		return valOpcionSujetoRealizaTraslado;
	},

	getValorOpcionModalidadTraslado : function () {
		var valOpcionModalidadTraslado = "";
		for (i = 1; i < 3; i++) {
			if (dijit.byId("trasladoBienes.idModalidadTraslado0" + i).getValue() != false) {
				valOpcionModalidadTraslado = dijit.byId("trasladoBienes.idModalidadTraslado0" + i).getValue()
			}
		}
		return valOpcionModalidadTraslado;
	},

	getValorOpcionISC : function () {
		var valOpcionISC;
		for (i = 0; i < 2; i++) {
			if (dijit.byId("inicio.subTipoIM0" + i).getValue() != false) {
				valOpcionISC = dijit.byId("inicio.subTipoIM0" + i).getValue()
			}
		}
		return valOpcionISC;
	},

	getValorOpcionTipoDireccPP : function () {
		var valOpcionTipoDireccPP;
		for (i = 1; i < 4; i++) {
			if (dijit.byId("puntoPartida.subTipoEestabEmisor0" + i).getValue() != false) {
				valOpcionTipoDireccPP = dijit.byId("puntoPartida.subTipoEestabEmisor0" + i).getValue()
			}
		}
		return valOpcionTipoDireccPP;
	},

	getValorOpcionTipoDireccPLL : function () {
		var valOpcionTipoDireccPLL;
		for (i = 1; i < 4; i++) {
			if (dijit.byId("puntoLlegada.subTipoEestabEmisor0" + i).getValue() != false) {
				valOpcionTipoDireccPLL = dijit.byId("puntoLlegada.subTipoEestabEmisor0" + i).getValue()
			}
		}
		return valOpcionTipoDireccPLL;
	},

	getValorOpcionTipoDireccCliente : function () {
		var valOpcionTipoDireccCliente;
		for (i = 1; i < 4; i++) {
			if (dijit.byId("direccCliente.subTipoEdireccCliente0" + i).getValue() != false) {
				valOpcionTipoDireccCliente = dijit.byId("direccCliente.subTipoEdireccCliente0" + i).getValue()
			}
		}
		return valOpcionTipoDireccCliente;
	},

	getValorOpcionDscto : function () {
		var valOpcionDscto;
		for (i = 0; i < 2; i++) {
			if (dijit.byId("inicio.subTipoDE0" + i).getValue() != false) {
				valOpcionDscto = dijit.byId("inicio.subTipoDE0" + i).getValue()
			}
		}
		return valOpcionDscto;
	},

	getValorSituacionEspecial : function () {
		var valSituacionEspecial;
		for (i = 1; i < 2; i++) {
			if (dijit.byId("boleta.subTipoSE0" + i).getValue() != false) {
				valSituacionEspecial = dijit.byId("boleta.subTipoSE0" + i).getValue()
			}
		}
		return valSituacionEspecial;
	},

	getTotalItemsEnGrid : function () {
		var grid = dijit.byId("boleta.ingreso-grid");
		return (grid.store == null ? 0 : grid.rowCount);
	},

	getTotalItemsEnGridQueSonCargoTributo : function () {
		varTotalCT = 0;
		var grilla = dijit.byId("boleta.ingreso-grid");
		var filas = grilla.rowCount;
		for (i = 0; i < filas; i++) {
			var fila = grilla.getItem(i);

			var valorCT = grilla.store.getValue(fila, "otrosCargosTributos");
			if (valorCT != "0.00" && valorCT != "" && valorCT != "0") {
				varTotalCT++;
			}
		}

		return varTotalCT;
	},

	verSiBoletaDeAnticipoExisteEnGrid : function (serie, numero) {
		existeBoletaAnticipo = 0;
		var grilla = dijit.byId("boleta.ingreso-grid");
		var filas = grilla.rowCount;
		for (i = 0; i < filas; i++) {
			var fila = grilla.getItem(i);

			var anticipo = grilla.store.getValue(fila, "anticipo");
			if (anticipo == "1") {
				if (grilla.store.getValue(fila, "serieBoletaAnticipo") == serie && grilla.store.getValue(fila, "numeroBoletaAnticipo") == numero) {
					existeBoletaAnticipo = 1;
				}
			}
		}
		return existeBoletaAnticipo;
	},

	getTotalItemsEnGridQueSonAnticipos : function () {
		varTotalIG = 0;
		var grilla = dijit.byId("boleta.ingreso-grid");
		var filas = grilla.rowCount;
		for (i = 0; i < filas; i++) {
			var fila = grilla.getItem(i);

			var valorIG = grilla.store.getValue(fila, "tipoPagoAnticipado");
			if (valorIG == "1") {
				varTotalIG++;
			}
		}

		return varTotalIG;
	},

	//PAS20175E210300029
	getItemsCompararFechaAnticipado : function () {
		var existeBoletaAnticipo = "";
		var fechaEmisionDate = new Date();
		if (dojo.byId("global.fecEmision").value != "") {
			fechaEmisionDate = new Date(dojo.byId("global.fecEmision").value);
		}

		var grilla = dijit.byId("boleta.ingreso-grid");
		var filas = grilla.rowCount;

		for (i = 0; i < filas; i++) {
			var fila = grilla.getItem(i);
			var fechaAnticipo = grilla.store.getValue(fila, "fechaEmisionBoletaAnticipo");

			if (fechaAnticipo != null) {
				parts = fechaAnticipo.split('/');
				fechaAnticipoDate = new Date(parts[2], parts[1] - 1, parts[0]);

				if (fechaAnticipoDate > fechaEmisionDate) {
					j = i + 1;
					if (existeBoletaAnticipo == "") {
						existeBoletaAnticipo = "" + j;
					} else {
						existeBoletaAnticipo = existeBoletaAnticipo + ", " + j;
					}
				}
			}
		}
		return existeBoletaAnticipo;
	},

	getTotalItemsEnGridQueSonGravados : function () {
		varTotalIG = 0;
		var grilla = dijit.byId("boleta.ingreso-grid");
		var filas = grilla.rowCount;
		for (i = 0; i < filas; i++) {
			var fila = grilla.getItem(i);
			var valorIG = grilla.store.getValue(fila, "tipoBeneficio");
			if (valorIG == "TB00") {
				varTotalIG++;
			}
		}

		return varTotalIG;
	},

	getTotalItemsEnGridQueSonExonerados : function () {
		varTotalIG = 0;
		var grilla = dijit.byId("boleta.ingreso-grid");
		var filas = grilla.rowCount;
		for (i = 0; i < filas; i++) {
			var fila = grilla.getItem(i);
			var valorIG = grilla.store.getValue(fila, "tipoBeneficio");
			if (valorIG == "TB01") {
				varTotalIG++;
			}
		}

		return varTotalIG;
	},

	getTotalItemsEnGridQueSonInafectos : function () {
		varTotalIG = 0;
		var grilla = dijit.byId("boleta.ingreso-grid");
		var filas = grilla.rowCount;
		for (i = 0; i < filas; i++) {
			var fila = grilla.getItem(i);
			var valorIG = grilla.store.getValue(fila, "tipoBeneficio");
			if (valorIG == "TB02") {
				varTotalIG++;
			}
		}
		return varTotalIG;
	},

	getTotalItemsEnGridQueTienenISC : function () {
		varTotalIG = 0;
		var grilla = dijit.byId("boleta.ingreso-grid");
		var filas = grilla.rowCount;
		for (i = 0; i < filas; i++) {
			var fila = grilla.getItem(i);

			var valorIG = grilla.store.getValue(fila, "iscSistema");
			if (valorIG != "0") {
				varTotalIG++;
			}
		}

		return varTotalIG;
	},

	//Inicio IGV10-JRGS
	getTotalItemsConIgv10: function() {
		varTotalIG=0;
		var grilla = dijit.byId("boleta.ingreso-grid");
		var filas = grilla.rowCount;
		for (i=0; i< filas;i++){
			var fila = grilla.getItem(i);
			var valorIG = grilla.store.getValue(fila, "igvPorcentaje");
			if (valorIG ==this.tasa10 ) {
				varTotalIG++;
			}
		}
		return varTotalIG;
	},
	
	getTotalItemsConIgv18: function() {
		varTotalIG=0;
		var grilla = dijit.byId("boleta.ingreso-grid");
		var filas = grilla.rowCount;
		for (i=0; i< filas;i++){
			var fila = grilla.getItem(i);
			var valorIG = grilla.store.getValue(fila, "igvPorcentaje");
														   
			if (valorIG ==this.tasa18 ) {
				varTotalIG++;
			}
		}
		return varTotalIG;
	},
	getTotalItemsGravTasa18: function() {
		 varTotalIG=0;
		 var grilla = dijit.byId("boleta.ingreso-grid");
		 var filas = grilla.rowCount;
		 for (i=0; i< filas;i++){
			 var fila = grilla.getItem(i);
			 var valorIG = grilla.store.getValue(fila, "tipoBeneficio");
			 var valorIG2 = grilla.store.getValue(fila, "igvPorcentaje");
			 if (valorIG =="TB00" && valorIG2 ==this.tasa18) {
				 varTotalIG++;
			 }
		 }
		 return varTotalIG;
	},

	getTotalItemsExoTasa0: function() {
		varTotalIG=0;
		var grilla = dijit.byId("boleta.ingreso-grid");
		var filas = grilla.rowCount;
		for (i=0; i< filas;i++){
	        var fila = grilla.getItem(i);
	        var valorIG = grilla.store.getValue(fila, "tipoBeneficio");
			var valorIG2 = grilla.store.getValue(fila, "igvPorcentaje");
	        if (valorIG =="TB01" && valorIG2 == 0) {
	            varTotalIG++;
	        }
		}
		return varTotalIG;
	},

	getTotalItemsInaTasa0: function() {
		varTotalIG=0;
		var grilla = dijit.byId("boleta.ingreso-grid");
		var filas = grilla.rowCount;
		for (i=0; i< filas;i++){
			var fila = grilla.getItem(i);
			var valorIG = grilla.store.getValue(fila, "tipoBeneficio");
			var valorIG2 = grilla.store.getValue(fila, "igvPorcentaje");
			if (valorIG =="TB02" && valorIG2 == 0) {
				varTotalIG++;
			}
		}
		return varTotalIG;
	},
	//Fin IGV10-JRGS		 
	// PAS20191U210100204
	getExisteDuplicados: function(){
		existeduplicados = 0;
		var grilla;
		if (dijit.byId("boleta.ingreso-grid") != null){
			grilla = dijit.byId("boleta.ingreso-grid");
		}
		else if (dijit.byId("boleta.preview-grid") != null){
			grilla = dijit.byId("boleta.preview-grid");
		}
		else{
			return existeduplicados;
		}
		
		var filas = grilla.rowCount;
		if (filas > 1){
			for (i = 0; i < filas; i++){
				var fila = grilla.getItem(i);
				var cantidad = Math.abs(grilla.store.getValue(fila, "cantidad"));
				var unidadMedida = grilla.store.getValue(fila, "unidadMedida");
				var codigoItem = grilla.store.getValue(fila, "codigoItem").trim();
				var descripcion = grilla.store.getValue(fila, "descripcion").trim();
				var precioUnitario = Math.abs(grilla.store.getValue(fila, "precioUnitario"));
				var contenidoItem = cantidad + "-" + unidadMedida + "-" + codigoItem + "-" + descripcion + "-" + precioUnitario;
				
				for (j = 0; j < filas ; j++){
					if (i == j){ continue; }
					var filaComp = grilla.getItem(j);
					var cantidadComp = Math.abs(grilla.store.getValue(filaComp, "cantidad"));
					var unidadMedidaComp = grilla.store.getValue(filaComp, "unidadMedida");
					var codigoItemComp = grilla.store.getValue(filaComp, "codigoItem").trim();
					var descripcionComp = grilla.store.getValue(filaComp, "descripcion").trim();
					var precioUnitarioComp = Math.abs(grilla.store.getValue(filaComp, "precioUnitario"));					
					var contenidoItemComp = cantidadComp + "-" + unidadMedidaComp + "-" + codigoItemComp + "-" + descripcionComp + "-" + precioUnitarioComp;
					
					if (contenidoItem.trim() == contenidoItemComp.trim()){
						existeduplicados++;
						break;
					}
				}
				
				if (existeduplicados > 0){ break;}
			}
		}
		return existeduplicados;
	},
		
	// PAS20221U210600187
	getExistePosibleDuplicacion: function(recargarUltimoComprobante) {
        var tiempoRestanteDuplicarBoleta = 0;
         
        tiempoRestanteDuplicarBoleta = this.getTiempoRestanteDuplicarBoleta();
        
        if (recargarUltimoComprobante == 1) {
            var handler = dojo.xhrGet({
      		    preventCache:  false,
  				url: this.controller + "?action=obtenerUltimoComprobante",
  				handleAs: "json",
  				sync: true,
  				timeout: 10000
  			});
  						
            handler.addCallback(dojo.hitch(this, function(response) {
  			    if (response.codeError == 0) {
  					var row = eval("(" + response.data + ")");
                    
                    dojo.byId("global.primeraEmision").value = row.primeraEmision;
                    dojo.byId("global.numSerieCpeUltimoComprobante").value = row.numSerieCpeUltimoComprobante;
                    dojo.byId("global.numCpeUltimoComprobante").value = row.numCpeUltimoComprobante;
                    dojo.byId("global.numDocIdeRecepUltimoComprobante").value = row.numDocIdeRecepUltimoComprobante;
                    dojo.byId("global.codigoMonedaUltimoComprobante").value = row.codigoMonedaUltimoComprobante;
                    dojo.byId("global.importeTotalUltimoComprobante").value = row.importeTotalUltimoComprobante;      
                    dojo.byId("global.timestampFecModifUltimoComprobante").value = row.timestampFecModifUltimoComprobante;
                    
                    tiempoRestanteDuplicarBoleta = this.getTiempoRestanteDuplicarBoleta();
  				} 
  			}));
  			
            handler.addErrback(function(response) {
  			});
        }
        
		return tiempoRestanteDuplicarBoleta;
	},
    
    getTiempoRestanteDuplicarBoleta: function() {
        var tiempoRestanteDuplicarBoleta = 0;
        
        var primeraEmision = dojo.byId("global.primeraEmision").value;
        var numDocIdeRecepUltimoComprobante = dojo.byId("global.numDocIdeRecepUltimoComprobante").value;
        var codigoMonedaUltimoComprobante = dojo.byId("global.codigoMonedaUltimoComprobante").value;
        var importeTotalUltimoComprobante = dojo.byId("global.importeTotalUltimoComprobante").value;      
        var timestampFecModifUltimoComprobante = dojo.byId("global.timestampFecModifUltimoComprobante").value;
        
        var numDocIdeRecepComprobanteActual = dojo.byId("global.numeroDocumento").value;
        var codigoMonedaComprobanteActual = dojo.byId("global.tipoMoneda").value;
        var importeTotalComprobanteActual = dojo.byId("importeTotal").value;
        
        if(numDocIdeRecepUltimoComprobante == "") { 
            numDocIdeRecepUltimoComprobante = "-"
        }
        
        importeTotalUltimoComprobante = importeTotalUltimoComprobante.replaceAll("'", "");
        importeTotalUltimoComprobante = importeTotalUltimoComprobante.replaceAll(",", "");
        
        if(numDocIdeRecepComprobanteActual == "") { 
            numDocIdeRecepComprobanteActual = "-"
        }
        
        importeTotalComprobanteActual = importeTotalComprobanteActual.replaceAll("'", "");
        importeTotalComprobanteActual = importeTotalComprobanteActual.replaceAll(",", "");
        
        if (primeraEmision == "0") {
            intervaloTiempoUltimoComprobante = ((parseFloat(Date.now()) - parseFloat(timestampFecModifUltimoComprobante))/parseFloat(1000))/parseFloat(60);
                        
            if (numDocIdeRecepUltimoComprobante == numDocIdeRecepComprobanteActual &&  
                codigoMonedaUltimoComprobante == codigoMonedaComprobanteActual &&
				parseFloat(importeTotalUltimoComprobante) == parseFloat(importeTotalComprobanteActual) &&  
				intervaloTiempoUltimoComprobante >= parseFloat(0) &&      
                intervaloTiempoUltimoComprobante <= parseFloat(5)) {
                tiempoRestanteDuplicarBoleta = parseFloat(5) - intervaloTiempoUltimoComprobante;
            }
        }
        
        return tiempoRestanteDuplicarBoleta;  
    },
    
	enabledSituacionEspecial : function (valor) {
		dijit.byId("boleta.subTipoSE00").attr("disabled", valor);
		dijit.byId("boleta.subTipoSE01").attr("disabled", valor);
		dijit.byId("boleta.subTipoSE02").attr("disabled", valor);
	},

	updateLocalAsociado : function (valor) {
		dijit.byId("boleta.localAsociado").setValue(valor);
	},

	getValorOpcionTipoItem : function () {
		var valTipoItem = "";
		for (i = 1; i < 3; i++) {
			//if(dijit.byId("item.subTipoTI0" + i).getValue() != false) {
			if (dojo.byId("item.subTipoTI0" + i).checked == true) {
				valTipoItem = dijit.byId("item.subTipoTI0" + i).getValue()
			}
		}
		return valTipoItem;
	},

	getValorOpcionOtrosCargosTrib : function () {
		var valOtrosCargosTrib = "";
		for (i = 1; i < 3; i++) {
			//if(dijit.byId("item.subCT0" + i).getValue() != false) {
			if (dojo.byId("item.subCT0" + i).checked == true) {
				valOtrosCargosTrib = dijit.byId("item.subCT0" + i).getValue()
			}
		}
		return valOtrosCargosTrib;
	},

	getValorOpcionBienServicio : function () {
		var valBienServicio = "";
		for (i = 1; i < 3; i++) {
			//if(dijit.byId("item.subTipoTI0" + i).getValue() != false) {
			if (dojo.byId("item.subTipoTI0" + i).checked == true) {
				valBienServicio = dijit.byId("item.subTipoTI0" + i).getValue()
			}
		}
		return valBienServicio;
	},
//PAS20191U210100075
getValorOpcionImpuestoBolsaPlastica: function() {
	var valOpcionImpuestoBolsaPlastica="";
	for(i = 0; i < 2; i++) {
		//if(dijit.byId("item.subTipoTB0" + i).getValue() != false) {
		if(document.getElementById("check.impuestoBolsasPlastica0"+i).checked == true) {
			valOpcionImpuestoBolsaPlastica = document.getElementById("check.impuestoBolsasPlastica0"+i).value;
		}
	}
	return valOpcionImpuestoBolsaPlastica;
},
//PAS20191U210100075
	getValorOpcionTipoBenef : function () {
		var valTipoBeneficio = "";
		for (i = 0; i < 3; i++) {
			//if(dijit.byId("item.subTipoTB0" + i).getValue() != false) {
			if (dojo.byId("item.subTipoTB0" + i).checked == true) {
				valTipoBeneficio = dijit.byId("item.subTipoTB0" + i).getValue()
			}
		}
		return valTipoBeneficio;
	},
	//Inicio IGV10-JRGS
	getValorOpcionTipoIGV: function() {
		var valTipoIgv="";
		for(i = 0; i < 2; i++) {			
			if(dojo.byId("item.subTipoIgv0" + i).checked == true) {
				valTipoIgv = dijit.byId("item.subTipoIgv0" + i).getValue()
			}
		}
		return valTipoIgv;
	},
	//Fin IGV10-JRGS		 
	getValorOpcionTipoBonif : function () {
		var valTipoBonif = "";
		//if(dijit.byId("item.subTipoBO00").getValue() != false) {
		if (dojo.byId("item.subTipoBO00").checked == true) {
			valTipoBonif = dijit.byId("item.subTipoBO00").getValue();
		}
		return valTipoBonif;
	},

	getValorOpcionAnticipo : function () {
		var valTipoBonif = "1";
		if (dijit.byId("item.subTipoPagoAnticipado0").getValue() == false) {
			valTipoBonif = "0";
		}
		return valTipoBonif;
	},

	getValorOpcionInicialExportacion : function () {
		var valTipoExportacion = "";
		for (i = 0; i < 2; i++) {
			if (dojo.byId("inicio.subTipoEE0" + i).checked == true) {
				valTipoExportacion = dojo.byId("inicio.subTipoEE0" + i).value;
			}
		}
		return valTipoExportacion;
	},

	getValorOpcionInicialNoDomic : function () {
		var valNodomic = "";
		for (i = 0; i < 2; i++) {
			if (dojo.byId("inicio.subTipoND0" + i).checked == true) {
				valNodomic = dojo.byId("inicio.subTipoND0" + i).value;
			}
		}
		return valNodomic;
	},

	getValorOpcionInicialCargosTrib : function () {
		var valTipoExportacion = "";
		for (i = 0; i < 2; i++) {

			if (dojo.byId("inicio.subTipoCargosTribNoBaseImp0" + i).checked == true) {
				valTipoExportacion = dojo.byId("inicio.subTipoCargosTribNoBaseImp0" + i).value;
			}
		}
		return valTipoExportacion;
	},

	getValorOpcionFESectorPublico : function () {
		var valOpcionFESectorPublico = "";
		for (i = 0; i < 2; i++) {

			if (dojo.byId("inicio.subTipoFSP0" + i).checked == true) {
				valOpcionFESectorPublico = dojo.byId("inicio.subTipoFSP0" + i).value;
			}
		}
		return valOpcionFESectorPublico;
	},

	getValorOpcionPagoAnticipado : function () {
		var valOpcionPagoAnticipado = "";
		for (i = 0; i < 2; i++) {

			if (dojo.byId("inicio.subTipoFEPagoActicipado0" + i).checked == true) {
				valOpcionPagoAnticipado = dojo.byId("inicio.subTipoFEPagoActicipado0" + i).value;
			}
		}
		return valOpcionPagoAnticipado;
	},

	getValorOpcionPagoDeduccionAnticipado : function () {
		var valOpcionPagoDeduccionAnticipado = "";
		for (i = 0; i < 2; i++) {
			if (dojo.byId("inicio.subTipoDE0" + i).checked == true) {
				valOpcionPagoDeduccionAnticipado = dojo.byId("inicio.subTipoDE0" + i).value;
			}
		}
		return valOpcionPagoDeduccionAnticipado;

	},

	getValorOpcionInicialOperacionesGratuitas : function () {
		var valor = "";
		for (i = 0; i < 2; i++) {
			if (dojo.byId("inicio.subTipoOpeGratuita0" + i).checked == true) {
				valor = dojo.byId("inicio.subTipoOpeGratuita0" + i).value;
			}
		}
		return valor;
	},

	getValorEstablecimientoEmisor : function () {
		var valOpcionEstablecimientoEmisor = "";
		for (i = 0; i < 2; i++) {

			if (dojo.byId("inicio.subTipoEstEmi0" + i).checked == true) {
				valOpcionEstablecimientoEmisor = dojo.byId("inicio.subTipoEstEmi0" + i).value;
			}
		}

		if (valOpcionEstablecimientoEmisor == 0) {
			dojo.byId("global.opcionEstablecimientoEmisorDireccion").value = "";
		}

		return valOpcionEstablecimientoEmisor;
	},

	getValorOpcionDomicilioCliente : function () {
		var valOpcionDomicilioCliente = "";
		for (i = 0; i < 2; i++) {

			if (dojo.byId("inicio.subTipoDC0" + i).checked == true) {
				valOpcionDomicilioCliente = dojo.byId("inicio.subTipoDC0" + i).value;
			}
		}
		return valOpcionDomicilioCliente;
	},

	getValorOpcionSustentoTrasladoBienes : function () {
		var valOpcionSustentoTrasladoBienes = "";
		for (i = 0; i < 2; i++) {

			if (dojo.byId("inicio.subTipoTrasladoB0" + i).checked == true) {
				valOpcionSustentoTrasladoBienes = dojo.byId("inicio.subTipoTrasladoB0" + i).value;
			}
		}
		return valOpcionSustentoTrasladoBienes;
	},
//PAS20191U210100075
viewCheckedImpuestoBolsaPlastica: function() {
	var valOpcionImpuestoBolsaPlastica = this.getValorOpcionImpuestoBolsaPlastica();
	var moneda = dojo.byId("global.tipoMoneda").value;
	monedades = dojo.byId("global.tipoMonedaDesc").value;
	if(monedades != "SOLES"){

		if (valOpcionImpuestoBolsaPlastica != "IBP00"){ //NO > IMPUESTO BOLSAS
			dijit.byId("item.impuestoICBPER").attr('disabled',true);	
			dijit.byId("item.impuestoICBPER").constraints = {currency:moneda, places:2};
			dijit.byId("item.impuestoICBPER").attr('value',0);
			//dijit.byId("item.cantidad").attr('value',dojo.number.format(dijit.byId("item.cantidad").getValue(),{places:2} ));
			
		}else{ // SI IMPUESTO BOLSAS
			dijit.byId("item.impuestoICBPER").attr('disabled',false);
			dijit.byId("item.impuestoICBPER").constraints = {currency:moneda, places:2};
			dijit.byId("item.impuestoICBPER").attr('value',dijit.byId("item.impuestoICBPER").getValue());
			//dijit.byId("item.cantidad").attr('value',dojo.number.format(dijit.byId("item.cantidad").getValue(),{places:0} ));				
		}

	}
	
	
	if (valOpcionImpuestoBolsaPlastica != "IBP00"){
		dojo.byId("item.impuestoICBPER").value="0";
		dojo.byId("item.tasaBolsaGlobal").value="0";
		dijit.byId("item.periodoBolsa").set("displayedValue", "");
		dijit.byId("item.periodoBolsa").attr('disabled',true);
		dojo.byId("item.tasaBolsa").value = "0";
		dojo.byId("item.PeriodoBolsaGlobal").value = "";
		//dijit.byId("item.cantidad").attr('value',dojo.number.format(dijit.byId("item.cantidad").getValue(),{places:2} ));
	} else { //SI
		
		rsp = this.loadImpuestoBolsa();
		
		if(rsp){
			
			var anio = "";
			var parts = dojo.byId("boleta.fechaEmision").value.split('/');		

			var fechaEmision = new Date(parts[2],parts[1]-1,parts[0]);
			
			console.log(dijit.byId('item.periodoBolsa').getValue());
			console.log(dijit.byId('item.periodoBolsa').value);


			if(dojo.byId("item.PeriodoBolsaGlobal").value != ""){
				anio = dojo.byId("item.PeriodoBolsaGlobal").value
			}else{
				anio = fechaEmision.getFullYear();
				
			}
			console.log(dojo.byId("item.PeriodoBolsaGlobal").value);
			
			dojo.byId("item.tasaBolsaGlobal").value = dijit.byId('item.periodoBolsa').getValue();
			//dijit.byId("item.periodoBolsa").set("displayedValue",anio.toString() );

			if(monedades != "SOLES"){
				dijit.byId("item.periodoBolsa").set("displayedValue","");
				dijit.byId("item.periodoBolsa").attr('disabled',true);
			}else{
				dijit.byId("item.periodoBolsa").set("displayedValue",anio.toString() );
				dijit.byId("item.periodoBolsa").attr('disabled',false);
			}	

			this.selectperiodoBolsaChange(dijit.byId("item.periodoBolsa").getValue());
			//dijit.byId("item.cantidad").attr('value',dojo.number.format(dijit.byId("item.cantidad").getValue(),{places:0} ));
			//dijit.byId("item.cantidad").constraints = {min:0,max:20000,places:0};		
		}else{
			
			dijit.byId("check.impuestoBolsasPlastica01").setChecked("checked");
		}

	}	
	
	this.resetValIGV();    	
},
//PAS20191U210100075


	viewCheckedTipoBenef : function () {
		var valTipoBenef = this.getValorOpcionTipoBenef();
		var valTipoIgvPor = this.getValorOpcionTipoIGV();
		if (valTipoBenef != "TB00") {
			dojo.byId("item.igvPorcentaje").value = "0";
		} else {
			if(valTipoIgvPor != "IGV00"){//IGV10-JRGS
				dojo.byId("item.igvPorcentaje").value= this.igv10;//IGV10-JRGS Mejorar porcentaje nuevo
			}else{//IGV10-JRGS
				dojo.byId("item.igvPorcentaje").value = dojo.byId("global.igvPorcentaje").value;
			}
		}
		this.resetValIGV();
		//PAS20221U210700162-EBV/LSD
		this.viewChangeJsonOperGratuitasCombo("00"); //RAL - PAS20221U210700119

	},
	//PAS20221U210700162-EBV/LSD -INI
	//Inicio IGV10-JRGS
	viewCheckedTipoIgv: function() {		
		var valTipoIgvPor = this.getValorOpcionTipoIGV();
		var valBienServicio = this.getValorOpcionBienServicio();//IGV10-JRGS
		var valTipoBonif = this.getValorOpcionTipoBonif();//IGV10-JRGS
		if (valTipoIgvPor != "IGV00"){
			dijit.byId("item.subTipoTB00").setChecked("checked");
			dijit.byId("item.subTipoTB00").setAttribute('disabled', false);
			dijit.byId("item.subTipoTB01").setAttribute('disabled', true);
			dijit.byId("item.subTipoTB02").setAttribute('disabled', true);
		} else {
			if ((valBienServicio == "TI02") && (valTipoBonif == "BO01")){//IGV10-JRGS
				dijit.byId("item.subTipoTB02").setChecked("checked");//IGV10-JRGS
				dijit.byId("item.subTipoTB00").setAttribute('disabled', true);//IGV10-JRGS
				dijit.byId("item.subTipoTB01").setAttribute('disabled', true);//IGV10-JRGS
				dijit.byId("item.subTipoTB02").setAttribute('disabled', true);//IGV10-JRGS
			}else{//IGV10-JRGS
				dijit.byId("item.subTipoTB00").setChecked("checked");
				dijit.byId("item.subTipoTB00").setAttribute('disabled', false);
				dijit.byId("item.subTipoTB01").setAttribute('disabled', false);
				dijit.byId("item.subTipoTB02").setAttribute('disabled', false);
			}
		}
		
		var valTipoBenef = this.getValorOpcionTipoBenef();
		
		if (valTipoBenef != "TB00"){
			dojo.byId("item.igvPorcentaje").value="0";
		} else {
			if(valTipoIgvPor != "IGV00"){
				dojo.byId("item.igvPorcentaje").value= this.igv10;//Mejorar porcentaje nuevo
			}else{
				dojo.byId("item.igvPorcentaje").value = dojo.byId("global.igvPorcentaje").value;
			}
		}
		
		if(valTipoIgvPor == "IGV01"){
            this.estaPadronGeneric(); //DAG PAS20221U210700299
        }
	
		this.resetValIGV();

		this.viewChangeJsonOperGratuitasCombo("00");		
	},
	//Fin IGV10-JRGS				
	//INI RAL PAS20221U210700119
	viewChangeJsonOperGratuitasCombo : function (valor){
		console.log("valor => "+ valor);
		var tipoGratuito = dojo.byId("global.opcionOperacionesGratuitas").value;  
		var valTipoBenef = this.getValorOpcionTipoBenef(); //Si es Gravado/Exonerado/Inafecto
		this.clearComboGratuito();
		this.showHiddenDiv(document.getElementById("item.divOperacionGratuitaCombo1.show"), true);
		this.showHiddenDiv(document.getElementById("item.divOperacionGratuitaCombo2.show"), false);
		this.showHiddenDiv(document.getElementById("item.divOperacionGratuitaCombo3.show"), false);
		this.showHiddenDiv(document.getElementById("item.divOperacionGratuitaCombo4.show"), false);
		console.log("valTipoBenef => "+ valTipoBenef );
		var codigo = "";
		var descripcion = "";
		
		if (dojo.byId("global.opcionExportacion").value == "1") {
			codigo = ["40"];
			descripcion = ["EXPORTACIÓN B/S OP. GRATUITA"];		
		}else{
			if (valTipoBenef == "TB00") {
				codigo = ["11","12","13","14","15","16"];
				descripcion = ["PREMIO","DONACIÓN","RETIRO","PUBLICIDAD","BONIFICACIÓN","ENTREGA A TRABAJADORES"];
			}
			if (valTipoBenef == "TB01") {
				codigo = ["21"];
				descripcion = ["TRANSFERENCIA GRATUITA"];	
			}
			if (valTipoBenef == "TB02") {
				codigo = ["31","32","33","34","35","36","37"];
				descripcion = ["BONIFICACIÓN","RETIRO","MUESTRAS MÉDICAS","CONVENIO COLECTIVO","PREMIO","PUBLICIDAD","TRANSFERENCIA GRATUITA"]	
			}
		}
		var values = [];
		values.push({name:"-SELECCIONE OPCIÓN-", value:"00"});
		for (i=0;i<codigo.length;i++){
			values.push({name:descripcion[i], value:codigo[i]});
		}
		var dataItems = { identifier: 'value', items: values, handleAs: "json" ,preventCache: true};
		var listStorenew = new dojo.store.Memory({data:dataItems});
		var listaprov= eval("dijit.byId('item.operacionGratuita1')");
		listaprov.store =  listStorenew;
		console.log("valTipoBenef => "+ valTipoBenef );
		//dijit.byId("item.operacionGratuita1").setValue("00");
		if (valor==null || valor=="00"){
			console.log("AVN EP6 - VALOR == 00");
			dijit.byId("item.operacionGratuita1").setValue("00");
		}else{
			console.log("AVN EP6 - VALOR = "+valor);
			dijit.byId("item.operacionGratuita1").setValue(valor);
		}
	},
	
	//LIMPIAR LOS COMBOBOX
	clearComboGratuito : function (){
		eval("dijit.byId('item.operacionGratuita1').set('displayedValue','')")
		var lista= eval("dijit.byId('item.operacionGratuita1')");
		lista.store =  null;
	},
	
	viewChangeOperacionesGratuitasCombo : function (){
		var valTipoBenef = this.getValorOpcionTipoBenef();
		if (dojo.byId("global.opcionExportacion").value == "1") {
			this.showHiddenDiv(document.getElementById("item.divOperacionGratuitaCombo1.show"), false);
			this.showHiddenDiv(document.getElementById("item.divOperacionGratuitaCombo2.show"), false);
			this.showHiddenDiv(document.getElementById("item.divOperacionGratuitaCombo3.show"), false);
			this.showHiddenDiv(document.getElementById("item.divOperacionGratuitaCombo4.show"), true);
		} else {
			if (valTipoBenef == "TB00") {
				this.showHiddenDiv(document.getElementById("item.divOperacionGratuitaCombo1.show"), true);
				this.showHiddenDiv(document.getElementById("item.divOperacionGratuitaCombo2.show"), false);
				this.showHiddenDiv(document.getElementById("item.divOperacionGratuitaCombo3.show"), false);
				this.showHiddenDiv(document.getElementById("item.divOperacionGratuitaCombo4.show"), false);
			}else if (valTipoBenef == "TB01") {
				this.showHiddenDiv(document.getElementById("item.divOperacionGratuitaCombo1.show"), false);
				this.showHiddenDiv(document.getElementById("item.divOperacionGratuitaCombo2.show"), true);
				this.showHiddenDiv(document.getElementById("item.divOperacionGratuitaCombo3.show"), false);
				this.showHiddenDiv(document.getElementById("item.divOperacionGratuitaCombo4.show"), false);
			}else if(valTipoBenef == "TB02") {
				this.showHiddenDiv(document.getElementById("item.divOperacionGratuitaCombo1.show"), false);
				this.showHiddenDiv(document.getElementById("item.divOperacionGratuitaCombo2.show"), false);
				this.showHiddenDiv(document.getElementById("item.divOperacionGratuitaCombo3.show"), true);
				this.showHiddenDiv(document.getElementById("item.divOperacionGratuitaCombo4.show"), false);
			}else {
				this.showHiddenDiv(document.getElementById("item.divOperacionGratuitaCombo1.show"), false);
				this.showHiddenDiv(document.getElementById("item.divOperacionGratuitaCombo2.show"), false);
				this.showHiddenDiv(document.getElementById("item.divOperacionGratuitaCombo3.show"), false);
				this.showHiddenDiv(document.getElementById("item.divOperacionGratuitaCombo4.show"), false);
			}
		}
	},
	//FIN RAL PAS20221U210700119
	//PAS20221U210700162-EBV/LSD -FIN
	
	viewCheckedOtrosCargosTrib : function () {
		//Desactivamos Bien / servicio
		dijit.byId("item.subTipoTI01").setChecked("");
		dijit.byId("item.subTipoTI02").setChecked("");
		dojo.byId("item.valOpcTipoBS").value = "";

		var valFlag = dojo.byId("item.valOpcTipoCTItem").value;
		var valTipoItem = this.getValorOpcionOtrosCargosTrib();

		if (valFlag == valTipoItem) {
			dijit.byId("item.subCT0" + valTipoItem).setChecked("");
			dojo.byId("item.valOpcTipoCTItem").value = "0";
			this.showHiddenDiv(document.getElementById("item.divFEPagoAnticipado.show"), true);
		} else {
			dojo.byId("item.valOpcTipoCTItem").value = valTipoItem;
			this.showTipoBeneficio(0);
			dojo.byId("item.valOpcPagoAnticipado").value = "0";
			//dijit.byId("item.subTipoPagoAnticipado0").setValue("0");
			dijit.byId("item.subTipoPagoAnticipado0").attr('checked', false);
			this.showHiddenDiv(document.getElementById("item.divFEPagoAnticipado.show"), false);
		}
		
		//PAS20191U210100075 - jsantivanez
		
		if (dojo.byId("global.opcionOtrosCargosTributos").value == "1") {
			dijit.byId("check.impuestoBolsasPlastica00").setAttribute('disabled', true);
			dijit.byId("check.impuestoBolsasPlastica01").setAttribute('disabled', true);
			dijit.byId("item.periodoBolsa").setAttribute('disabled', true);
			dijit.byId("check.impuestoBolsasPlastica01").setChecked("checked");
			this.viewCheckedImpuestoBolsaPlastica();
			
		}
		//PAS20191U210100075 - jsantivanez
		
		
		this.disableMontosItem();
	},

	viewCheckedBienServicio : function () {
		var valFlag = dojo.byId("item.valOpcTipoBS").value;
		var valTipoItem = this.getValorOpcionBienServicio();

		if (valFlag == valTipoItem) {
			if (dojo.byId("global.opcionNodomic").value != "1") {
				dijit.byId("item.subTipo" + valTipoItem).setChecked("");
				dojo.byId("item.valOpcTipoBS").value = "";
			}
		} else {
			dojo.byId("item.valOpcTipoBS").value = valTipoItem;
		}

		//Desactivamos Cargo /tributo
		dijit.byId("item.subCT01").setChecked("");
		dijit.byId("item.subCT02").setChecked("");
		dojo.byId("item.valOpcTipoCTItem").value = "0";

		if (dojo.byId("global.opcionExportacion").value == "1" ||
			dojo.byId("global.perteneceBVNRUS").value == "1") {
			this.showTipoBeneficio(0);
		} else {
			this.showTipoBeneficio(1); //Mostramos igv
		}
		
		//PAS20191U210100075 - jsantivanez
		
		if (dojo.byId("global.opcionOtrosCargosTributos").value == "1") {
			dijit.byId("check.impuestoBolsasPlastica00").setAttribute('disabled', false);
			dijit.byId("check.impuestoBolsasPlastica01").setAttribute('disabled', false);
			dijit.byId("item.periodoBolsa").setAttribute('disabled', false);
			
		}
		this.viewCheckedImpuestoBolsaPlastica();
		//PAS20191U210100075 - jsantivanez
		

		this.disableMontosItem();
		//PAS20221U210700162-EBV/LSD - INI
		this.viewChangeJsonOperGratuitasCombo("00"); //RAL - PAS20221U210700119
		//viewChangeOperacionesGratuitasCombo //RAL - PAS20221U210700119
		//PAS20221U210700162-EBV/LSD - FIN
	},

	viewCheckedOperacionGratuita : function () {
		var moneda = dojo.byId("global.tipoMoneda").value;
		var valTipoBonif = this.getValorOpcionTipoBonif();

		if (dojo.byId("global.opcionDscto").value == "DE01" && valTipoBonif == "BO01") {
			dojo.byId("item.valOpcTipoBonif").value = "BO00";
			dijit.byId("item.subTipoBO00").setValue("BO00");
			dijit.byId("item.subTipoBO00").setChecked("");
			this.showHiddenDiv(document.getElementById("item.divOperacionGratuitaCombo.show"), false);

			//this.showHiddenDiv(document.getElementById("item.divFEPagoAnticipado.show"),true);
		} else {
			dojo.byId("item.valOpcTipoBonif").value = "BO01";
			dijit.byId("item.subTipoBO00").setValue("BO01");
			dijit.byId("item.subTipoBO00").setChecked("checked");
			this.showHiddenDiv(document.getElementById("item.divOperacionGratuitaCombo.show"), true);
			dojo.byId("item.valOpcPagoAnticipado").value = "0";
			//dijit.byId("item.subTipoPagoAnticipado0").setValue("0");
			dijit.byId("item.subTipoPagoAnticipado0").attr('checked', false);
			this.showHiddenDiv(document.getElementById("item.divFEPagoAnticipado.show"), false);
		}

		this.showTipoBeneficio(1);
		this.disableMontosItem();
		this.viewChangeJsonOperGratuitasCombo("00"); //IGV10-JRGS
	},

	viewCheckedAnticipo : function () {
		var valTipoBonif = this.getValorOpcionAnticipo();

		if (valTipoBonif == "1") {
			dojo.byId("item.valOpcPagoAnticipado").value = "1";
			//dijit.byId("item.subTipoPagoAnticipado0").attr('checked', true) ;
			this.showHiddenDiv(document.getElementById("item.divFEPagoAnticipado.show"), true);

			//Desactivamos Cargo /tributo
			dijit.byId("item.subCT01").setChecked("");
			dijit.byId("item.subCT02").setChecked("");
			dojo.byId("item.valOpcTipoCTItem").value = "0";

			dojo.byId("item.valOpcTipoBonif").value = "BO00";
			dijit.byId("item.subTipoBO00").setValue("BO00");
			dijit.byId("item.subTipoBO00").setChecked("");
			this.showHiddenDiv(document.getElementById("item.divOperacionGratuitaCombo.show"), false);

			dijit.byId("item.cantidad").setValue("1");
			dijit.byId("item.cantidad").attr('disabled', true);
			this.showHiddenDiv(document.getElementById("item.divFENoPagoAnticipado.show"), false);
			dojo.byId("rotuloValorUnitario").innerHTML = "Anticipo a Valor de Venta"
				dojo.byId("rotuloTotalItem").innerHTML = "Importe Total"
				this.showHiddenDiv(document.getElementById("item.divDescuentos.show"), false);
	//INI: PAS20191U210100075				
	if (dojo.byId("global.opcionPagoDeduccionAnticipado").value =="DE01"){
			dijit.byId("check.impuestoBolsasPlastica00").setAttribute('disabled', true);
			dijit.byId("check.impuestoBolsasPlastica01").setAttribute('disabled', true);
			dijit.byId("item.periodoBolsa").setAttribute('disabled', true);
			dijit.byId("check.impuestoBolsasPlastica01").setChecked("checked");                    
			this.viewCheckedImpuestoBolsaPlastica();			
		}
		//FIN: PAS20191U210100075	
	} else {
			dojo.byId("item.valOpcPagoAnticipado").value = "0";
			//	dijit.byId("item.subTipoPagoAnticipado0").attr('checked', false) ;
			this.showHiddenDiv(document.getElementById("item.divFEPagoAnticipado.show"), false);

			dijit.byId("item.cantidad").attr('disabled', false);
			dijit.byId("item.boletaAnticipoSerie").setValue("");
			dijit.byId("item.boletaAnticipoNumero").setValue("");
			dijit.byId("item.boletaAnticipoFechaEmision").setValue("");
			dojo.byId("item.boletaAnticipoFechaEmisionAux").value = "";
			this.showHiddenDiv(document.getElementById("item.divFENoPagoAnticipado.show"), true);
			dojo.byId("rotuloValorUnitario").innerHTML = "Valor Unitario ";
			dojo.byId("rotuloTotalItem").innerHTML = "Importe Total del Item ";
			this.showHiddenDiv(document.getElementById("item.divDescuentos.show"), true);
			
		  //INI: PAS20191U210100075				
		  if (dojo.byId("global.opcionPagoDeduccionAnticipado").value =="DE01"){
			dijit.byId("check.impuestoBolsasPlastica00").setAttribute('disabled', false);
				dijit.byId("check.impuestoBolsasPlastica01").setAttribute('disabled', false);
				dijit.byId("item.periodoBolsa").setAttribute('disabled', false);
		  }
		  //FIN: PAS20191U210100075 
			
		}

		this.disableMontosItem();
	},

	showOpcionesSujetoRealizaTraslado : function (valor) {
		if (valor == 1) { //1 Emisor - vendedor
			this.showHiddenDiv(document.getElementById("trasladoBienes.sujetoTraslado.show"), true);
			dijit.byId("trasladoBienes.idModalidadTraslado01").setAttribute('disabled', false);
			dijit.byId("trasladoBienes.idModalidadTraslado02").setAttribute('disabled', false);
		} else { // 2 Comprador
			this.showHiddenDiv(document.getElementById("trasladoBienes.sujetoTraslado.show"), false);
			this.showHiddenDiv(document.getElementById("trasladoBienes.sujetoTrasladoRUC.show"), false);
			dijit.byId("trasladoBienes.idModalidadTraslado01").setChecked("checked"); //Transporte Privado
			dijit.byId("trasladoBienes.idModalidadTraslado01").setValue("1");
			dijit.byId("trasladoBienes.idModalidadTraslado01").setAttribute('disabled', true);
			dijit.byId("trasladoBienes.idModalidadTraslado02").setAttribute('disabled', true);
			dijit.byId("trasladoBienes.placaVehiculo").setValue("");
			dijit.byId("trasladoBienes.marcaVehiculo").setValue("");
			dijit.byId("trasladoBienes.nroLicenciaConducir").setValue("");
			dijit.byId("trasladoBienes.rucTransportista").setValue("");
			dijit.byId("trasladoBienes.razonSocial").setValue("")
		}

	},

	showOpcionesModalidadTraslado : function (valor) {

		if (valor == 1) { //1 Privado
			this.showHiddenDiv(document.getElementById("trasladoBienes.sujetoTrasladoRUC.show"), false);

			dijit.byId("trasladoBienes.rucTransportista").setValue("");
			dijit.byId("trasladoBienes.razonSocial").setValue("")
		} else { // 2 Publico
			this.showHiddenDiv(document.getElementById("trasladoBienes.sujetoTrasladoRUC.show"), true);

		}

	},
	showExportacion : function (valor) {
		this.showOpcionesExportacion(0);
		if (valor == 1) {
			this.showHiddenDiv(document.getElementById("inicio.exportacion.show"), true);
		} else {

			this.showHiddenDiv(document.getElementById("inicio.exportacion.show"), false);
		}
	},

	showOpcionesExportacion : function (valor) {
		dijit.byId("inicio.subTipoIM00").setChecked("checked");
		dijit.byId("inicio.subTipoIM00").setValue("IM00");
		dijit.byId("inicio.subTipoCargosTribNoBaseImp00").setChecked("checked");
		dijit.byId("inicio.subTipoCargosTribNoBaseImp00").setValue("0");

		if (valor == 1) {
			/** Oculta:
			 *  ruc
			 *  isc
			 *  otros tributos y cargos
			 */
			dijit.byId("inicio.subTipoND00").setChecked("checked");
			dijit.byId("inicio.subTipoND00").setValue("0");
			dijit.byId("inicio.subTipoND00").setAttribute('disabled', true);
			dijit.byId("inicio.subTipoND01").setAttribute('disabled', true);
			//this.showHiddenDiv(document.getElementById("inicio.ruc.show"),false);
			this.showHiddenDiv(document.getElementById("inicio.ruc.show"), true);
			//this.showHiddenDiv(document.getElementById("inicio.razonSocial.show"),true);
			this.showHiddenDiv(document.getElementById("inicio.razonSocial.show"), false);
			//this.showHiddenDiv(document.getElementById("inicio.isc.show"),false);
			//this.showHiddenDiv(document.getElementById("inicio.descuentos.show"),true);
			this.showHiddenDiv(document.getElementById("inicio.cargosTribNoBaseImp.show"), false);

			this.showHiddenDiv(document.getElementById("inicio.domicilioCliente.show"), false);
			dojo.byId("inicio.subTipoDC01").checked = false;
			dojo.byId("inicio.subTipoDC00").checked = true;
			dojo.byId("global.opcionDomicilioCliente").value = "0";
			dojo.byId("global.opcionDomicilioClienteDireccion").value = "";

			//dijit.byId("inicio.tipoDocumento").attr("value", "0");
			//dijit.byId("inicio.numeroDocumento").setValue("");
			//dijit.byId("inicio.razonSocial").setValue("");
			//dijit.byId("inicio.exportacion.razonSocial").focus();
			//dijit.byId("inicio.exportacion.razonSocial").setValue(dojo.byId("global.numeroDocumentoExpDesc").value);
			dijit.byId("inicio.tipoMoneda").setValue("USD - DOLAR AMERICANO");
			//PAS20181U210300095
			if (dojo.byId("global.perteneceBVNRUS").value == "0") {
				this.showHiddenDiv(document.getElementById("inicio.isc.show"), false);
				this.showHiddenDiv(document.getElementById("inicio.descuentos.show"), true);
			}
		} else {
			/** Muestra
			 * ruc
			 * venta gratuita
			 * isc
			 * otros tributos y cargos
			 */
			dijit.byId("inicio.subTipoND00").setAttribute('disabled', false);
			dijit.byId("inicio.subTipoND01").setAttribute('disabled', false);
			this.showHiddenDiv(document.getElementById("inicio.ruc.show"), true);
			this.showHiddenDiv(document.getElementById("inicio.razonSocial.show"), false);
			//this.showHiddenDiv(document.getElementById("inicio.ventaGratuita.show"),false);   //true);
			//this.showHiddenDiv(document.getElementById("inicio.isc.show"),true);
			//this.showHiddenDiv(document.getElementById("inicio.descuentos.show"),true);
			this.showHiddenDiv(document.getElementById("inicio.cargosTribNoBaseImp.show"), true);
			if (this.getValorOpcionPagoAnticipado() == 1) {
				this.showHiddenDiv(document.getElementById("inicio.cargosTribNoBaseImp.show"), false);
			}
			this.showHiddenDiv(document.getElementById("inicio.domicilioCliente.show"), true);

			//var gtd = dojo.byId("global.tipoDocumento").value;
			//if (gtd != ""){
			//	dijit.byId("inicio.tipoDocumento").attr("value", gtd);
			//}else{
			//	dijit.byId("inicio.tipoDocumento").attr("value", "1"); //DNI
			//}
			//dijit.byId("inicio.exportacion.razonSocial").setValue("");
			if (dojo.byId("global.tipoMonedaDescLarge").value != null &&
				dojo.byId("global.tipoMonedaDescLarge").value != "") {
				dijit.byId("inicio.tipoMoneda").setValue(dojo.byId("global.tipoMonedaDescLarge").value);
			} else {
				//dijit.byId("inicio.tipoMoneda").setValue("PEN - NUEVOS SOLES");
				dijit.byId("inicio.tipoMoneda").setValue("PEN - SOLES");
			}

			//PAS20181U210300095
			if (dojo.byId("global.perteneceBVNRUS").value == "0") {
				this.showHiddenDiv(document.getElementById("inicio.descuentos.show"), true);
				this.showHiddenDiv(document.getElementById("inicio.isc.show"), true);

			}
		}

		document.getElementById("innerContent").style.height = "auto";
		document.getElementById("inicio.form").style.height = "auto";
	},

	showOpcionesNoDomic : function (valor) {
		if (valor == 1) {
			this.showOpcionesExportacion(0);
			this.showHiddenDiv(document.getElementById("inicio.noDomicReceptor.show"), true);
			dijit.byId("inicio.subTipoEE00").setChecked("checked");
			dijit.byId("inicio.subTipoEE00").setValue("0");
			dijit.byId("inicio.subTipoEE00").setAttribute('disabled', true);
			dijit.byId("inicio.subTipoEE01").setAttribute('disabled', true);
			this.showHiddenDiv(document.getElementById("inicio.ruc.show"), false);

			//this.showHiddenDiv(document.getElementById("inicio.razonSocial.show"),false);
			//dijit.byId("inicio.tipoDocumento").setValue("0");
			//dijit.byId("inicio.numeroDocumento").setValue("");
			//dijit.byId("inicio.razonSocial").setValue("");

			//dijit.byId("inicio.tipoDocRecepFENodomic").focus();
		} else {
			this.showOpcionesExportacion(this.getValorOpcionInicialExportacion());
			this.showHiddenDiv(document.getElementById("inicio.noDomicReceptor.show"), false);
			dijit.byId("inicio.subTipoEE00").setAttribute('disabled', false);
			dijit.byId("inicio.subTipoEE01").setAttribute('disabled', false);
			dijit.byId("inicio.subTipoND00").setAttribute('disabled', false);
			dijit.byId("inicio.subTipoND01").setAttribute('disabled', false);
			this.showHiddenDiv(document.getElementById("inicio.ruc.show"), true);

			//this.showHiddenDiv(document.getElementById("inicio.razonSocial.show"),true);
			//dijit.byId("inicio.exportacion.razonSocial").setValue("");
			//dijit.byId("inicio.tipoDocumento").setValue("0");
			//dijit.byId("inicio.numeroDocumento").setValue("");
			//dijit.byId("inicio.razonSocial").setValue("");

			dijit.byId("inicio.tipoDocRecepFENodomic").focus();
		}
	},

	showOpcionesPagoAnticipado : function (valor) {
		this.showOpcionesExportacion(this.getValorOpcionInicialExportacion());

		if (valor == 1) {
			dijit.byId("inicio.subTipoCargosTribNoBaseImp00").setChecked("checked");
			dijit.byId("inicio.subTipoCargosTribNoBaseImp00").setValue("0");
			dijit.byId("inicio.subTipoDE00").setChecked("checked");
			dijit.byId("inicio.subTipoDE00").setValue("DE00");
			dijit.byId("inicio.subTipoOpeGratuita00").setChecked("checked");
			dijit.byId("inicio.subTipoOpeGratuita00").setValue("0");

			this.showHiddenDiv(document.getElementById("inicio.descuentos.show"), false);
			this.showHiddenDiv(document.getElementById("inicio.cargosTribNoBaseImp.show"), false);
			this.showHiddenDiv(document.getElementById("inicio.operacionesGratuitas.show"), false);
		} else {
			this.showHiddenDiv(document.getElementById("inicio.descuentos.show"), true);
			this.showHiddenDiv(document.getElementById("inicio.cargosTribNoBaseImp.show"), true);
			this.showHiddenDiv(document.getElementById("inicio.operacionesGratuitas.show"), true);
			if (this.getValorOpcionInicialExportacion() == 1) {
				this.showHiddenDiv(document.getElementById("inicio.cargosTribNoBaseImp.show"), false);
			}
		}
	},

	showHiddenDiv : function (node, show) {
		if (show == true) { //Mostrar
			node.style.display = "";
		} else { //Ocultar
			node.style.display = "none";
		}
	},

	showTipoBeneficio : function (valor) { //Afectacion al IGV
		if (valor == 1) {
			if (this.getValorOpcionAnticipo() == 1) {}
			else {
				dijit.byId("item.subTipoTB00").setChecked("");
				dijit.byId("item.subTipoTB01").setChecked("");
				dijit.byId("item.subTipoTB02").setChecked("");
				if(dijit.byId("item.subTipoIgv00") != undefined){
					console.log("item.subTipoIgv00" + dojo.byId("item.subTipoIgv00").value);
					dijit.byId("item.subTipoIgv00").setChecked("");//IGV10-JRGS
				}
				if(dijit.byId("item.subTipoIgv01") != undefined){
					console.log("item.subTipoIgv01" + dojo.byId("item.subTipoIgv01").value);
					dijit.byId("item.subTipoIgv01").setChecked("");//IGV10-JRGS
				}									 
				this.showHiddenDiv(document.getElementById("item.divTipoBeneficio.show"), true);
				dojo.byId("item.igvPorcentaje").value = dojo.byId("global.igvPorcentaje").value;
				dijit.byId("item.subTipoTB00").setChecked("checked");
				dijit.byId("item.subTipoTB00").attr("disabled", false);
				dijit.byId("item.subTipoTB01").attr("disabled", false);
				dijit.byId("item.subTipoTB02").attr("disabled", false);
				if(dijit.byId("item.subTipoIgv00") != undefined){
					console.log("item.subTipoIgv00" + dojo.byId("item.subTipoIgv00").value);
					dijit.byId("item.subTipoIgv00").setChecked("checked");//IGV10-JRGS
				}
				if(dijit.byId("item.subTipoIgv01") != undefined){
					console.log("item.subTipoIgv01" + dojo.byId("item.subTipoIgv01").value);
					dijit.byId("item.subTipoIgv01").attr("disabled",false);//IGV10-JRGS
				}
			}
			if (dojo.byId("item.valOpcTipoBS").value == "TI02") { //Si es servicio
				var valTipoBonif = this.getValorOpcionTipoBonif();
				if (valTipoBonif == "BO01") {
					dijit.byId("item.subTipoTB02").setChecked("checked");
					dojo.byId("item.igvPorcentaje").value = "0";
					dijit.byId("item.precioConIGV").setValue(0, false);
					dijit.byId("item.subTipoTB00").attr("disabled", true);
					dijit.byId("item.subTipoTB01").attr("disabled", true);
					dijit.byId("item.subTipoTB02").attr("disabled", true);
				}
			}
		} else {
			dijit.byId("item.subTipoTB00").setChecked("");
			dijit.byId("item.subTipoTB01").setChecked("");
			dijit.byId("item.subTipoTB02").setChecked("");
			this.showHiddenDiv(document.getElementById("item.divTipoBeneficio.show"), false);
			dojo.byId("item.igvPorcentaje").value = "0";
			dijit.byId("item.subTipoTB00").attr("disabled", true);
			dijit.byId("item.subTipoTB01").attr("disabled", true);
			dijit.byId("item.subTipoTB02").attr("disabled", true);
		}
		this.resetValIGV();
	},

	validarMontoIGV : function () {
		var igvPorcentaje = dojo.byId("item.igvPorcentaje").value;
		var moneda = dijit.byId("inicio.tipoMoneda").getValue();
		var cantidadXPrecio = dijit.byId("item.cantidad").getValue() * dijit.byId("item.precioUnitario").getValue();
		cantidadXPrecio.toFixed();
		var precioDescuento = dijit.byId("item.precioDescuento").getValue();
		var totalConDescuento = cantidadXPrecio - precioDescuento;
		var igvMonto = ((totalConDescuento * igvPorcentaje) / 100);

		var valMontoIGV = dijit.byId("item.precioConIGV").getValue();
		if (valMontoIGV == igvMonto) {
			dijit.byId("item.precioConIGV").setValue(dojo.currency.format(igvMonto, {
					currency : moneda,
					places: 2
				}));
		} else {
			dijit.byId("item.precioConIGV").setValue("");
			this.attr('invalidMessage', "item.precioConIGV", "Monto ingresado del IGV es incorrecto.");
			dijit.byId("item.precioConIGV").focus();
			return;
		}
	},

	cargarValoresGlobales : function () {
		//dojo.byId("global.origenInvocacionItem").value = "";
		dojo.byId("global.numeroDocumento").value = dijit.byId("inicio.numeroDocumento").getValue();
		dojo.byId("global.numeroDocumentoDesc").value = dijit.byId("inicio.razonSocial").getValue();
		dojo.byId("global.numeroDocumentoExpDesc").value = dijit.byId("inicio.exportacion.razonSocial").getValue();
		dojo.byId("global.tipoMoneda").value = dojo.trim(dijit.byId("inicio.tipoMoneda").getValue().substring(0, 3));
		/*Inicio SAU20156R120400552*/
		if (dojo.byId("global.tipoMoneda").value == "XEU") {
			dojo.byId("global.tipoMoneda").value = "EUR"
		}
		/*Fin SAU20156R120400552*/
		dojo.byId("global.tipoMonedaDesc").value = dojo.trim(dijit.byId("inicio.tipoMoneda").getValue().substring(6, 25));

		dojo.byId("global.tipoMonedaDescLarge").value = dojo.trim(dijit.byId("inicio.tipoMoneda").getValue());

		dojo.byId("global.opcionDscto").value = this.getValorOpcionDscto();
		dojo.byId("global.opcionExportacion").value = this.getValorOpcionInicialExportacion();
		dojo.byId("global.opcionNodomic").value = this.getValorOpcionInicialNoDomic();
		dojo.byId("global.opcionISC").value = this.getValorOpcionISC();
		dojo.byId("global.opcionOperacionesGratuitas").value = this.getValorOpcionInicialOperacionesGratuitas();
		dojo.byId("global.opcionOtrosCargosTributos").value = this.getValorOpcionInicialCargosTrib();
		dojo.byId("global.opcionFESectorPublico").value = this.getValorOpcionFESectorPublico();
		dojo.byId("global.opcionPagoAnticipado").value = this.getValorOpcionPagoAnticipado();
		dojo.byId("global.opcionPagoDeduccionAnticipado").value = this.getValorOpcionPagoDeduccionAnticipado();
		dojo.byId("global.opcionEstablecimientoEmisor").value = this.getValorEstablecimientoEmisor();
		dojo.byId("global.opcionDomicilioCliente").value = this.getValorOpcionDomicilioCliente();
		dojo.byId("global.opcionSustentoTrasladoBienes").value = this.getValorOpcionSustentoTrasladoBienes();
		/*
		if (dojo.byId("global.opcionExportacion").value == "1") { //Exportacion Activada
			dojo.byId("global.tipoDocumento").value = "0"; //Sin ruc
		} else {
			//dojo.byId("global.tipoDocumento").value = "1";//DNI
			dojo.byId("global.tipoDocumento").value = dijit.byId("inicio.tipoDocumento").getValue();
		}
		*/
		//JuniorGs - Captura todo tipo de documento
		dojo.byId("global.tipoDocumento").value = dijit.byId("inicio.tipoDocumento").getValue();

		//PAS20181U210300095
		if (dojo.byId("global.opcionExportacion").value == "1" ||
			dojo.byId("global.perteneceBVNRUS").value == "1") {
			dojo.byId("global.igvPorcentaje").value = "0.00";
		} else {
			dojo.byId("global.igvPorcentaje").value = dojo.byId("global.igvPorcentajeInicial").value / 100;
		}

		dojo.byId("global.tipoDocumentoNodomic").value = dojo.trim(dijit.byId("inicio.tipoDocRecepFENodomic").getValue().substring(4, 55));
		dojo.byId("global.numeroDocumentonoDomic").value = dojo.trim(dijit.byId("inicio.numeroDocRecepFENodomic").getValue());
		dojo.byId("global.razonSocialNoDomic").value = dojo.trim(dijit.byId("inicio.nombreRazonRecepFENodomic").getValue());

		if (dojo.byId("global.opcionNodomic").value == "1") {
			dojo.byId("global.numeroDocumentoExpDesc").value = dojo.trim(dijit.byId("inicio.nombreRazonRecepFENodomic").getValue());
			dojo.byId("global.tipoDocumento").value = dojo.trim(dijit.byId("inicio.tipoDocRecepFENodomic").getValue().substring(0, 1));
			dojo.byId("global.numeroDocumento").value = dojo.trim(dijit.byId("inicio.numeroDocRecepFENodomic").getValue());
			dojo.byId("global.nacionalidadNoDomic").value = dojo.trim(dijit.byId("inicio.nacionalidadRecepFENodomic").getValue().substring(0, 4));
			dojo.byId("global.nacionalidadNoDomicDesc").value = dojo.trim(dijit.byId("inicio.nacionalidadRecepFENodomic").getValue().substring(6, 65));
			dojo.byId("global.tamNoDomic").value = dojo.trim(dijit.byId("inicio.tamRecepFENoDomic").getValue());
			dojo.byId("global.fecIngresoPaisNoDomic").value = dojo.date.locale.format(dijit.byId('inicio.fecIngresoPaisRecepFENoDomic').getValue(), {
					datePattern : "MM/dd/yyyy",
					selector : "date"
				});
			dojo.byId("global.tipoTarjetaNoDomic").value = dojo.trim(dijit.byId("inicio.tipoTarjetaRecepFENodomic").getValue().substring(0, 1));
			dojo.byId("global.numeroTarjetaNoDomic").value = dijit.byId("inicio.numeroTarjetaRecepFENodomic").getValue();
			dojo.byId("global.bancoTarjetaNoDomic").value = dojo.trim(dijit.byId("inicio.bancoEmisorTarjetaRecepFENodomic").getValue());
		}
	},

	resetValoresGlobales : function () {
		dojo.byId("global.modo").value = "00";
		dojo.byId("global.numeroDocumento").value = "";
		dojo.byId("global.numeroDocumentoDesc").value = "";
		dojo.byId("global.numeroDocumentoExpDesc").value = "";
		dojo.byId("global.tipoMoneda").value = "";
		dojo.byId("global.tipoMonedaDesc").value = "";

		dojo.byId("global.tipoMonedaDescLarge").value = "";

		dojo.byId("global.opcionDscto").value = "";
		dojo.byId("global.opcionExportacion").value = "0";
		dojo.byId("global.opcionNodomic").value = "0";
		dojo.byId("global.opcionISC").value = "";
		dojo.byId("global.opcionOperacionesGratuitas").value = "0";
		dojo.byId("global.opcionFESectorPublico").value = "0";
		dojo.byId("global.opcionPagoAnticipado").value = "0";
		dojo.byId("global.opcionPagoDeduccionAnticipado").value = "DE00";
		dojo.byId("global.opcionEstablecimientoEmisor").value = "0";
		dojo.byId("global.opcionEstablecimientoEmisorIdentifica").value = "";
		dojo.byId("global.opcionEstablecimientoEmisorDireccion").value = "";
		dojo.byId("global.opcionEstablecimientoEmisorSeleccionado").value = "";
		dojo.byId("global.opcionDomicilioCliente").value = "0";
		dojo.byId("global.opcionDomicilioClienteIdentifica").value = "";
		dojo.byId("global.opcionDomicilioClienteDireccion").value = "";
		dojo.byId("global.opcionDomicilioClienteSeleccionado").value = "";
		dojo.byId("global.opcionSustentoTrasladoBienes").value = "0";
		dojo.byId("global.numeroExpediente").value = "";
		dojo.byId("global.ordenCompra").value = "";
		dojo.byId("global.numeroProcesoSeleccion").value = "";
		dojo.byId("global.codigoUnidadEjecutora").value = "";
		dojo.byId("global.numeroContrato").value = "";
		dojo.byId("global.fecVencimiento").value = "";

		dojo.byId("global.tipoDocumento").value = "1"; //DNI
		//dojo.byId("global.tipoVenta").value="";

		dojo.byId("global.igvPorcentaje").value = dojo.byId("global.igvPorcentajeInicial").value / 100; //"0.19";
		dojo.byId("global.docsrel.localAsoc").value = "0000";
		dojo.byId("global.docsrel.observacion").value = "";
		dojo.byId("global.validateType").value = "0";
	},

	nuevoItem : function () {
		console.log("------------");

		/* Inicio PAS20201U210100285 - Pago Anticipado */
		if (dojo.byId("global.opcionPagoDeduccionAnticipado").value == "DE01") {
			require(["dijit/registry"], function(registry){
				var formItems = registry.byId("item.form");
				formItems.reset();
			});
		}
		/* Fin PAS20201U210100285 - Pago Anticipado */

		var moneda = dojo.byId("global.tipoMoneda").value;

		var totalItems = this.getTotalItemsEnGrid();
		
		//PAS20191U210100075
		
		dijit.byId("check.impuestoBolsasPlastica00").attr('disabled',false); 
		dijit.byId("check.impuestoBolsasPlastica01").attr('disabled',false);
		dijit.byId("item.cantidad").attr('disabled',false);
		
		monedades = dojo.byId("global.tipoMonedaDesc").value;
		
		if(monedades != "SOLES"){

			dijit.byId("item.impuestoICBPER").constraints = {currency:moneda, places:2};
			dijit.byId("item.impuestoICBPER").attr('value',dijit.byId("item.impuestoICBPER").getValue());
			
			var valOpcionImpuestoBolsaPlastica = this.getValorOpcionImpuestoBolsaPlastica();
			
			console.log(valOpcionImpuestoBolsaPlastica);
			
			if (valOpcionImpuestoBolsaPlastica != "IBP00"){
				dijit.byId("item.impuestoICBPER").attr('disabled',true);	
				
			}else{
				dijit.byId("item.impuestoICBPER").attr('disabled',false);	
			}
			
			
		}	
		//PAS20191U210100075
		monedades = dojo.byId("global.tipoMonedaDesc").value;
		
		if(monedades != "SOLES"){

			dijit.byId("item.impuestoICBPER").constraints = {currency:moneda, places:2};
			dijit.byId("item.impuestoICBPER").attr('value',dijit.byId("item.impuestoICBPER").getValue());
			
			var valOpcionImpuestoBolsaPlastica = this.getValorOpcionImpuestoBolsaPlastica();
			
			console.log(valOpcionImpuestoBolsaPlastica);
			
			if (valOpcionImpuestoBolsaPlastica != "IBP00"){
				dijit.byId("item.impuestoICBPER").attr('disabled',true);	
				
			}else{
				dijit.byId("item.impuestoICBPER").attr('disabled',false);	
			}
			
			
		}	
			
		dijit.byId("check.impuestoBolsasPlastica01").setChecked("checked");

		var valueIcbper = document.getElementById('boleta.totalICBPERConting');

				
		console.log(valueIcbper);
		
		if (valueIcbper != undefined){
			
			this.viewCheckedImpuestoBolsaPlastica();
			
			this.showHiddenDiv(document.getElementById("item.ICBPER1.show"),true); 
			this.showHiddenDiv(document.getElementById("item.ICBPER2.show"),true); 
		}else{
			this.viewCheckedImpuestoBolsaPlastica();
			this.showHiddenDiv(document.getElementById("item.ICBPER1.show"),false); 
			this.showHiddenDiv(document.getElementById("item.ICBPER2.show"),false); 
			
		}

		
		//PAS20191U210100075
		
		if (totalItems == 20) {
			var node = dijit.byId("item.botonAceptar").focusNode;
			mostrarMensaje("El máximo numero de ítems a ingresar no debe exceder de 20.");
			return;
		}

		dojo.byId("item.igvPorcentaje").value = dojo.byId("global.igvPorcentaje").value;
		var labeIgvPorcentaje = dojo.byId("global.igvPorcentaje").value;
		if (labeIgvPorcentaje < 1) {
			labeIgvPorcentaje = labeIgvPorcentaje * 100;
		}
		//document.getElementById("item.labelIgvPorcentaje").innerHTML = "IGV (" + labeIgvPorcentaje + "%)";IGV10-JRGS

		this.dialogItem.attr('title', "Nuevo Item");
		dojo.byId("item.idItem").value = "0";
		dojo.byId("item.action").value = "adicionarItem";

		dijit.byId("item.subTipoTI01").setChecked("");
		dijit.byId("item.subTipoTI02").setChecked("");
		dijit.byId("item.subTipoBO00").setChecked("");
		dijit.byId("item.subCT01").setChecked("");
		dijit.byId("item.subCT02").setChecked("");
		dojo.byId("item.valOpcTipoBS").value = "";
		dojo.byId("item.valOpcPagoAnticipado").value = "0";
		dijit.byId("item.subTipoPagoAnticipado0").attr('checked', false);
		this.showHiddenDiv(document.getElementById("item.divFEPagoAnticipado.show"), false);
		dijit.byId("item.boletaAnticipoSerie").attr('value', "");
		dijit.byId("item.boletaAnticipoNumero").attr('value', "");
		dijit.byId("item.boletaAnticipoMonto").attr('value', "");
		/* Inicio PAS20201U210100285 - Giancarlo Nepo LÃ³pez */
		if (dojo.byId("item.montoRedondeoAux") != null){ /* PAS20201U210100285 - Boleta Contingencia */
			dojo.byId("item.montoRedondeoAux").value = "0"; 
		}
		/* Fin PAS20201U210100285 - Giancarlo Nepo LÃ³pez */
		// INICIO PAS20201U210100161
		sessionStorage.clear();
        if(totalItems == 0) {
			dijit.byId("item.unidadMedida").attr("value", "NIU");
			dijit.byId("item.unidadMedida").attr('disabled',false);
			sessionStorage.setItem("undMedida",dijit.byId("item.unidadMedida").getValue());
        } else {
			dijit.byId("item.unidadMedida").value=JSON.parse(sessionStorage.getItem("undMedida"));
			dijit.byId("item.unidadMedida").attr("value", "NIU"); /* PAS20201U210100285 - Pago Anticipado */
			dijit.byId("item.unidadMedida").attr('disabled',false);
        }
		// FIN PAS20201U210100161
		
		

		dijit.byId("item.cantidad").attr('value', 1);
		dijit.byId("item.codigoItem").attr('value', "");
		dijit.byId("item.descripcion").attr('value', "");
		dijit.byId("item.precioUnitario").constraints = {
			currency : moneda,
			places : '2,10'
		};
		dijit.byId("item.precioUnitario").attr('value', 0);

		dijit.byId("item.precioDescuento").constraints = {
			currency : moneda,
			places : 2
		};
		dijit.byId("item.precioDescuento").attr('value', 0);

		dijit.byId("item.sistemaIsc").attr('value', "0");
		dijit.byId("item.iscPorcentaje").attr('disabled', true);
		dijit.byId("item.iscPorcentaje").attr('value', 0);

		dijit.byId("item.iscMonto").constraints = {
			currency : moneda,
			places : 2
		};
		dijit.byId("item.iscMonto").attr('value', 0);

		dijit.byId("item.precioConIGV").constraints = {
			currency : moneda,
			places : 2
		};
		dijit.byId("item.precioConIGV").attr('value', 0);

		dijit.byId("item.importeVenta").constraints = {
			currency : moneda,
			places : 2
		};
		dijit.byId("item.importeVenta").attr('value', 0);



		//PAS20181U210300095
		if (dojo.byId("global.opcionExportacion").value == "1" ||
			dojo.byId("global.perteneceBVNRUS").value == "1") {
			this.showTipoBeneficio(0);
		} else {
			this.showTipoBeneficio(1); //Mostramos igv
		}

		if (dojo.byId("global.opcionISC").value == "IM00") {
			dijit.byId("item.sistemaIsc").attr("disabled", true);
			dijit.byId("item.iscPorcentaje").attr("disabled", true);
			dijit.byId("item.iscMonto").attr("disabled", true);
		} else {
			dijit.byId("item.sistemaIsc").attr("disabled", false);
			dijit.byId("item.iscPorcentaje").attr("disabled", false);
			dijit.byId("item.iscMonto").attr("disabled", false);
		}

		if (dojo.byId("global.opcionDscto").value == "DE00") {
			dijit.byId("item.precioDescuento").attr("disabled", true);
		} else {
			dijit.byId("item.precioDescuento").attr("disabled", false);
		}

		if (dojo.byId("global.opcionExportacion").value == "1") {
			dijit.byId("item.subTipoBO00").setValue("BO00");
			dijit.byId("item.subTipoBO00").setChecked("");
		}

		if (dojo.byId("global.opcionNodomic").value == "1") {
			dijit.byId("item.subTipoTI01").setChecked("checked");
			dijit.byId("item.subTipoTI02").setChecked("");
			dijit.byId("item.subTipoTI02").setAttribute('disabled', true);
			dojo.byId("item.valOpcTipoBS").value = "TI01";
		} else {
			dijit.byId("item.subTipoTI02").setAttribute('disabled', false);
		}

		dojo.byId("item.valOpcTipoCTItem").value = "0"
			if (dojo.byId("global.opcionOtrosCargosTributos").value == "1") {
				if (dojo.byId("global.opcionNodomic").value == "1") {
					this.showHiddenDiv(document.getElementById("item.divOtrosCargosTributos.show"), false);
				} else {
					this.showHiddenDiv(document.getElementById("item.divOtrosCargosTributos.show"), true);
				}
			} else {
				this.showHiddenDiv(document.getElementById("item.divOtrosCargosTributos.show"), false);
			}
			dijit.byId("item.operacionGratuita1").setValue("00");//RAL PAS20221U210700119 //PAS20221U210700162-EBV/LSD
		if (dojo.byId("global.opcionOperacionesGratuitas").value == "1") {
			this.showHiddenDiv(document.getElementById("item.divOperacionGratuita.show"), true);
			this.viewChangeJsonOperGratuitasCombo("00"); //RAL PAS20221U210700119 //PAS20221U210700162-EBV/LSD
			//this.showHiddenDiv(document.getElementById("item.divOperacionGratuitaCombo.show"),true);
		} else {
			this.showHiddenDiv(document.getElementById("item.divOperacionGratuita.show"), false);
			this.showHiddenDiv(document.getElementById("item.divOperacionGratuitaCombo.show"), false);
		}

		if (dojo.byId("global.opcionPagoAnticipado").value == "1") {
			this.showHiddenDiv(document.getElementById("item.divPagoAnticipado.show"), false);
			dijit.byId("item.subTipoPagoAnticipado0").attr('checked', false);
		} else {
			if (dojo.byId("global.opcionDscto").value == "DE00") {
				this.showHiddenDiv(document.getElementById("item.divPagoAnticipado.show"), false);
				dijit.byId("item.subTipoPagoAnticipado0").attr('checked', false);
			} else {
				this.showHiddenDiv(document.getElementById("item.divPagoAnticipado.show"), true);
				dijit.byId("item.subTipoPagoAnticipado0").attr('checked', false);
				this.viewCheckedAnticipo();
			}
		}



  
		this.updateItemAmount();
		//this.showHiddenDiv(document.getElementById("dialogItem"),true);

		this.dialogItem.show();
	},

	editItem : function (identificador) {
		this.editItemRegular(identificador);
	},

	editItemRegular : function (identificador) {
		var row;

		/* Inicio PAS20201U210100285 - Pago Anticipado */
		if (dojo.byId("global.opcionPagoDeduccionAnticipado").value == "DE01") {
			require(["dijit/registry"], function(registry){
				var formItems = registry.byId("item.form");
				formItems.reset();
			});
		}
		/* Fin PAS20201U210100285 - Pago Anticipado */

		this.store.fetchItemByIdentity({
			identity : identificador,
			onItem : function (item, request) {
				row = item;
			},
			onError : function (item, request) {
				mostrarMensaje("Ocurrio un error al ubicar el documento");
				return;
			}
		});

		dijit.byId("item.botonAceptar").attr('disabled', false);
		var moneda = dojo.byId("global.tipoMoneda").value;

		this.dialogItem.attr('title', "Editando Item");
		dojo.byId("item.action").value = "editarItem";
		dojo.byId("item.idItem").value = this.store.getValue(row, "identificador");
		if(this.store.getValue(row, "igvPorcentaje") == this.tasa10){//IGV10-JRGS
			dijit.byId("item.subTipoTB00").setChecked("checked");//IGV10-JRGS
			dijit.byId("item.subTipoTB00").setAttribute('disabled', false);//IGV10-JRGS
			dijit.byId("item.subTipoTB01").setAttribute('disabled', true);//IGV10-JRGS
			dijit.byId("item.subTipoTB02").setAttribute('disabled', true);//IGV10-JRGS
		}else{//IGV10-JRGS
			if ((this.store.getValue(row, "igvPorcentaje") == "0") && (this.store.getValue(row, "tipoBonificacion") == "BO01") && (this.store.getValue(row, "tipoBeneficio") == "TB02")){//IGV10-JRGS
				dijit.byId("item.subTipoTB02").setChecked("checked");//IGV10-JRGS
				dijit.byId("item.subTipoTB00").setAttribute('disabled', true);//IGV10-JRGS
				dijit.byId("item.subTipoTB01").setAttribute('disabled', true);//IGV10-JRGS
				dijit.byId("item.subTipoTB02").setAttribute('disabled', true);//IGV10-JRGS
			}else{//IGV10-JRGS
				dijit.byId("item.subTipoTB00").attr("disabled",false);
				dijit.byId("item.subTipoTB01").attr("disabled",false);
				dijit.byId("item.subTipoTB02").attr("disabled",false);
			}
		}		
		if(dijit.byId("item.subTipoIgv00") != undefined){//IGV10-JRGS 		
			dijit.byId("item.subTipoIgv00").attr("disabled",false);//IGV10-JRGS
		}		
		if(dijit.byId("item.subTipoIgv01") != undefined){//IGV10-JRGS 			
			dijit.byId("item.subTipoIgv01").attr("disabled",false);//IGV10-JRGS
		}		  

		if (this.store.getValue(row, "tipoItem") != "TI00") {
			dojo.byId("item.valOpcTipoBS").value = dijit.byId("item.subTipo" + this.store.getValue(row, "tipoItem")).getValue();
			dijit.byId("item.subTipo" + this.store.getValue(row, "tipoItem")).setChecked("checked");
			dijit.byId("item.subTipo" + this.store.getValue(row, "tipoItem")).setValue(this.store.getValue(row, "tipoItem"));

		} else {
			dijit.byId("item.subTipoTI01").setChecked("");
			dijit.byId("item.subTipoTI02").setChecked("");
			dojo.byId("item.valOpcTipoBS").value = "";
		}

		if (this.store.getValue(row, "tipoOtrosCargosTributos") == "1" || this.store.getValue(row, "tipoOtrosCargosTributos") == "2") {
			dojo.byId("item.valOpcTipoCTItem").value = this.store.getValue(row, "tipoOtrosCargosTributos"); //dijit.byId("item.subCT0" + this.store.getValue(row, "tipoOtrosCargosTributos")).getValue();
			dijit.byId("item.subCT0" + this.store.getValue(row, "tipoOtrosCargosTributos")).setChecked("checked");
			dijit.byId("item.subCT0" + this.store.getValue(row, "tipoOtrosCargosTributos")).setValue(this.store.getValue(row, "tipoOtrosCargosTributos"));

		} else {
			dijit.byId("item.subCT01").setChecked("");
			dijit.byId("item.subCT02").setChecked("");
			dojo.byId("item.valOpcTipoCTItem").value = "";
		}

		if (this.store.getValue(row, "tipoBonificacion") == "BO01") {
			dijit.byId("item.subTipoBO00").setChecked("checked");
			dijit.byId("item.subTipoBO00").setValue(this.store.getValue(row, "tipoBonificacion"));

			if (this.store.getValue(row, "tipoBeneficio") != "") {
				dijit.byId("item.subTipo" + this.store.getValue(row, "tipoBeneficio")).setChecked("");
				dijit.byId("item.subTipo" + this.store.getValue(row, "tipoBeneficio")).setValue(this.store.getValue(row, "tipoBeneficio"));
				this.showHiddenDiv(document.getElementById("item.divTipoBeneficio.show"), false);
			}
		} else {
			dijit.byId("item.subTipoBO00").setValue("BO00");
			dijit.byId("item.subTipoBO00").setChecked("");

			if (this.store.getValue(row, "tipoBeneficio") != "") {
				dijit.byId("item.subTipo" + this.store.getValue(row, "tipoBeneficio")).setChecked("checked");
				dijit.byId("item.subTipo" + this.store.getValue(row, "tipoBeneficio")).setValue(this.store.getValue(row, "tipoBeneficio"));
				this.showHiddenDiv(document.getElementById("item.divTipoBeneficio.show"), true);
			}
		}

		if (this.store.getValue(row, "unidadMedida") == "-") {
			dijit.byId("item.unidadMedida").setValue("000");
		} else {
			dijit.byId("item.unidadMedida").setValue(this.store.getValue(row, "unidadMedida"));
		}

		if (this.store.getValue(row, "tipoBonificacion") == "BO01") {
			dojo.byId("item.igvPorcentaje").value = 0;
			dijit.byId("item.subTipoBO00").setValue(this.store.getValue(row, "tipoBonificacion"));
			dijit.byId("item.subTipoBO00").setChecked("checked");
			//PAS20221U210700162-EBV/LSD-INI
			console.log("AVN EP6 codigoBonificacion=>"+this.store.getValue(row, "codigoBonificacion")); //RAL PAS20221U210700119
			this.viewChangeJsonOperGratuitasCombo(this.store.getValue(row, "codigoBonificacion")); //RAL PAS20221U210700119
			//PAS20221U210700162-EBV/LSD-FIN
		} else {
			dojo.byId("item.igvPorcentaje").value = dojo.byId("global.igvPorcentaje").value;
			dijit.byId("item.subTipoBO00").setValue(this.store.getValue(row, "tipoBonificacion"));
			dijit.byId("item.subTipoBO00").setChecked("");
		}

		if (this.store.getValue(row, "tipoBeneficio") != "TB00") {
			dojo.byId("item.igvPorcentaje").value = 0;
		} else {
			if (this.store.getValue(row, "igvPorcentaje") == this.tasa10) {//IGV10-JRGS
				dojo.byId("item.igvPorcentaje").value = this.igv10;//IGV10-JRGS
			}
			else{//IGV10-JRGS
				dojo.byId("item.igvPorcentaje").value = dojo.byId("global.igvPorcentaje").value;
			}
		}

		if (this.store.getValue(row, "tipoBeneficio") == "TB00") {
			dijit.byId("item.subTipoTB00").setChecked("checked");
		}
		if (this.store.getValue(row, "tipoBeneficio") == "TB01") {
			dijit.byId("item.subTipoTB01").setChecked("checked");
		}
		if (this.store.getValue(row, "tipoBeneficio") == "TB02") {
			dijit.byId("item.subTipoTB02").setChecked("checked");
		}

		if(dijit.byId("item.subTipoIgv00") != undefined){//IGV10-JRGS 		
			if (this.store.getValue(row, "igvPorcentaje") == 0) {dijit.byId("item.subTipoIgv00").setChecked("checked");}//IGV10-JRGS Mejorar para traer la tasa
			if (this.store.getValue(row, "igvPorcentaje") == this.tasa18) {dijit.byId("item.subTipoIgv00").setChecked("checked");}//IGV10-JRGS Mejorar para traer la tasa		
		}		
		if(dijit.byId("item.subTipoIgv01") != undefined){//IGV10-JRGS 			
			if (this.store.getValue(row, "igvPorcentaje") == this.tasa10) {dijit.byId("item.subTipoIgv01").setChecked("checked");}//IGV10-JRGS Mejorar para traer la tasa
		}														  
		this.disableMontosItem();
		dijit.byId("item.cantidad").setValue(this.store.getValue(row, "cantidad"), false);
		dijit.byId("item.codigoItem").setValue(this.store.getValue(row, "codigoItem"));
		dijit.byId("item.descripcion").setValue(this.store.getValue(row, "descripcionHidden"));

		dijit.byId("item.precioUnitario").constraints = {
			currency : moneda,
			places : '2,10'
		};
		if (this.store.getValue(row, "tipoBonificacion") == "BO01") {//IGV10-JRGS
			dijit.byId("item.precioUnitario").setValue(Math.abs(this.store.getValue(row, "precioUnitarioAux").replace(/,/, "")), false);
			//var preUnitValorAbs = Math.abs(dojo.byId("item.precioUnitario"));
			dijit.byId("item.importeVenta").setValue(this.store.getValue(row, "importeVentaGratuita"), false);	
		}else{
			dijit.byId("item.precioUnitario").setValue(Math.abs(this.store.getValue(row, "precioUnitario").replace(/,/, "")), false);
			//var preUnitValorAbs = Math.abs(dojo.byId("item.precioUnitario"));
			dijit.byId("item.importeVenta").setValue(this.store.getValue(row, "importeVenta"), false);
		}

		dijit.byId("item.precioDescuento").setValue(this.store.getValue(row, "descuentoMonto"), false);
		//
		if (dojo.byId("global.opcionISC").value != "IM00") {
			dijit.byId("item.sistemaIsc").setValue(this.store.getValue(row, "iscSistema"), false);
			dijit.byId("item.iscPorcentaje").setValue(this.store.getValue(row, "iscPorcentaje"), false);
			dijit.byId("item.iscMonto").setValue(Math.abs(this.store.getValue(row, "iscMonto").replace(/,/, "")), false);
		}



		if (dojo.byId("global.opcionPagoAnticipado").value == "1") {
			this.showHiddenDiv(document.getElementById("item.divPagoAnticipado.show"), false);
			dijit.byId("item.subTipoPagoAnticipado0").attr('checked', false);
		} else {
			if (dojo.byId("global.opcionDscto").value == "DE00") {
				this.showHiddenDiv(document.getElementById("item.divPagoAnticipado.show"), false);
				dijit.byId("item.subTipoPagoAnticipado0").attr('checked', false);
			} else {
				this.showHiddenDiv(document.getElementById("item.divPagoAnticipado.show"), true);
				if (this.store.getValue(row, "anticipo") != "1") {
					dijit.byId("item.subTipoPagoAnticipado0").attr('checked', false);
				} else {
					dijit.byId("item.subTipoPagoAnticipado0").attr('checked', true);
					if (dijit.byId("item.boletaAnticipoSerie").getValue() == "EB01") { /* PAS20201U210100285 */
						dijit.byId("item.subTipoTB00").attr("disabled", true);
						dijit.byId("item.subTipoTB01").attr("disabled", true);
						dijit.byId("item.subTipoTB02").attr("disabled", true);
					}
					console.log("row ------> " + row);
					dojo.byId("item.boletaAnticipoSerie").value = this.store.getValue(row, "serieBoletaAnticipo", false);
					dojo.byId("item.boletaAnticipoNumero").value = this.store.getValue(row, "numeroBoletaAnticipo", false);
					dojo.byId("item.boletaAnticipoFechaEmision").value = this.store.getValue(row, "fechaEmisionBoletaAnticipo", false);
					dojo.byId("item.boletaAnticipoMonto").value = this.store.getValue(row, "importeTotalBoletaAnticipo", false);
					//Inicio IGV10-JRGS
					if (dijit.byId("item.boletaAnticipoSerie").getValue() =="EB01"){
    					dijit.byId("item.subTipoTB00").attr("disabled",true);
    					dijit.byId("item.subTipoTB01").attr("disabled",true);
    					dijit.byId("item.subTipoTB02").attr("disabled",true);
    				}
					console.log("item.igvPorcentaje " + dojo.byId("item.igvPorcentaje").value);
					//Fin IGV10-JRGS	
					this.obtenerBoletaAnticipo(true); /* PAS20201U210100285 */
				}
				this.viewCheckedAnticipo();
			}
		}

		if (this.store.getValue(row, "tipoBeneficio") != "TB00") {
			dojo.byId("item.igvPorcentaje").value = 0;
		} else {
			if (this.store.getValue(row, "igvPorcentaje") == this.tasa10) {//IGV10-JRGS
				dojo.byId("item.igvPorcentaje").value = this.igv10;//IGV10-JRGS
			}
			else{//IGV10-JRGS
				dojo.byId("item.igvPorcentaje").value = dojo.byId("global.igvPorcentaje").value;
			}
		}
		if (this.store.getValue(row, "tipoBeneficio") == "TB00") {
			dijit.byId("item.subTipoTB00").setChecked("checked");
		}
		if (this.store.getValue(row, "tipoBeneficio") == "TB01") {
			dijit.byId("item.subTipoTB01").setChecked("checked");
		}
		if (this.store.getValue(row, "tipoBeneficio") == "TB02") {
			dijit.byId("item.subTipoTB02").setChecked("checked");
		}
		if(dijit.byId("item.subTipoIgv00") != undefined){//IGV10-JRGS 		
			if (this.store.getValue(row, "igvPorcentaje") == 0) {dijit.byId("item.subTipoIgv00").setChecked("checked");}//IGV10-JRGS Mejorar para traer la tasa
			if (this.store.getValue(row, "igvPorcentaje") == this.tasa18) {dijit.byId("item.subTipoIgv00").setChecked("checked");}//IGV10-JRGS Mejorar para traer la tasa		
		}		
		if(dijit.byId("item.subTipoIgv01") != undefined){//IGV10-JRGS 			
			if (this.store.getValue(row, "igvPorcentaje") == this.tasa10) {dijit.byId("item.subTipoIgv01").setChecked("checked");}//IGV10-JRGS Mejorar para traer la tasa
		}														  			 
		this.updateItemAmount();

		if (this.store.getValue(row, "tipoBeneficio") != "TB00") {
			dojo.byId("item.igvPorcentaje").value = 0;
		} else {
			if (this.store.getValue(row, "igvPorcentaje") == this.tasa10) {//IGV10-JRGS
				dojo.byId("item.igvPorcentaje").value = this.igv10;//IGV10-JRGS
			}
			else{//IGV10-JRGS
				dojo.byId("item.igvPorcentaje").value = dojo.byId("global.igvPorcentaje").value;
			}
		}
		if (this.store.getValue(row, "tipoBeneficio") == "TB00") {
			dijit.byId("item.subTipoTB00").setChecked("checked");
		}
		if (this.store.getValue(row, "tipoBeneficio") == "TB01") {
			dijit.byId("item.subTipoTB01").setChecked("checked");
		}
		if (this.store.getValue(row, "tipoBeneficio") == "TB02") {
			dijit.byId("item.subTipoTB02").setChecked("checked");
		}
		if(dijit.byId("item.subTipoIgv00") != undefined){//IGV10-JRGS 		
			if (this.store.getValue(row, "igvPorcentaje") == 0) {dijit.byId("item.subTipoIgv00").setChecked("checked");}//IGV10-JRGS Mejorar para traer la tasa
			if (this.store.getValue(row, "igvPorcentaje") == this.tasa18) {dijit.byId("item.subTipoIgv00").setChecked("checked");}//IGV10-JRGS Mejorar para traer la tasa		
		}		
		if(dijit.byId("item.subTipoIgv01") != undefined){//IGV10-JRGS 			
			if (this.store.getValue(row, "igvPorcentaje") == this.tasa10) {dijit.byId("item.subTipoIgv01").setChecked("checked");}//IGV10-JRGS Mejorar para traer la tasa
		}
		if(this.store.getValue(row, "igvPorcentaje") == this.tasa10){//IGV10-JRGS
			dijit.byId("item.subTipoTB00").setChecked("checked");//IGV10-JRGS
			dijit.byId("item.subTipoTB00").setAttribute('disabled', false);//IGV10-JRGS
			dijit.byId("item.subTipoTB01").setAttribute('disabled', true);//IGV10-JRGS
			dijit.byId("item.subTipoTB02").setAttribute('disabled', true);//IGV10-JRGS
		}else{//IGV10-JRGS
			if ((this.store.getValue(row, "igvPorcentaje") == "0") && (this.store.getValue(row, "tipoBonificacion") == "BO01") && (this.store.getValue(row, "tipoBeneficio") == "TB02")){//IGV10-JRGS
				dijit.byId("item.subTipoTB02").setChecked("checked");//IGV10-JRGS
				dijit.byId("item.subTipoTB00").setAttribute('disabled', true);//IGV10-JRGS
				dijit.byId("item.subTipoTB01").setAttribute('disabled', true);//IGV10-JRGS
				dijit.byId("item.subTipoTB02").setAttribute('disabled', true);//IGV10-JRGS
			}else{//IGV10-JRGS
				dijit.byId("item.subTipoTB00").setAttribute("disabled",false);
				dijit.byId("item.subTipoTB01").setAttribute("disabled",false);
				dijit.byId("item.subTipoTB02").setAttribute("disabled",false);
			}
		}
	//PAS20191U210100075
	console.log(row);
	
	console.log(this.store.getValue(row, "importeICBPER"));
	monedades = dojo.byId("global.tipoMonedaDesc").value;
	if(monedades != "SOLES"){

		dijit.byId("item.impuestoICBPER").constraints = {currency:moneda, places:2};
		dijit.byId("item.impuestoICBPER").attr('value',this.store.getValue(row, "importeICBPER"));

		
	}else{
		var tasabolsaPorcentaje =  this.store.getValue(row, "icbPerPorcentaje");
		
		//dijit.byId("item.tasaBolsa").setValue(tasabolsaPorcentaje, false);
		

		var handler = dojo.xhrGet({
			preventCache:  false,
			url: this.controller + "?action=loadImpuestoBolsa",
			handleAs: "json",
			sync: true,
			timeout: 10000
		});
		
		handler.addCallback(dojo.hitch(this, function(res){
			//this.waitMessage.hide();
			this.unidadMedidaStore = null;
			var data = null;
			var values = [];
		var values2 = [];
		
		
			if(res.codeError == 0) {
				if(res.data.length > 0 && res.data != "[]") {
					data = eval("(" + res.data + ")");
					//values.push({name:"", abbreviation:"000"});              
					for (var x = 0 ; x < data.length ; x++) {     

						console.log("1>>>>>" + data[x].tasaTributo);
						console.log("2>>>>>" + tasabolsaPorcentaje);
						if (this.round(data[x].tasaTributo, 2)== this.round(tasabolsaPorcentaje, 2)){
							console.log(">>>>>" + data[x].periodoTributo);
							//mostrarMensaje(data[x].periodoTributo + " - " + data[x].tasaTributo);
							var parts = dojo.byId("boleta.fechaEmision").value.split('/');		
							var fechaEmision = new Date(parts[2],parts[1]-1,parts[0]);
							if (fechaEmision.getFullYear() > 2023){
								dojo.byId("item.PeriodoBolsaGlobal").value = fechaEmision.getFullYear();
								dojo.byId("item.periodoBolsa").value = fechaEmision.getFullYear();
							}else{
								dojo.byId("item.PeriodoBolsaGlobal").value = data[x].periodoTributo;
								dojo.byId("item.periodoBolsa").value = data[x].periodoTributo;
							}
							
							dojo.byId("item.tasaBolsaGlobal").value = tasabolsaPorcentaje;

							console.log(document.getElementById("item.tasaBolsaGlobal").value + " <--- ghlobal" );
							
							
							dojo.byId("item.tasaBolsa").value = tasabolsaPorcentaje;							
							
							//dijit.byId("item.periodoBolsa").set("displayedValue", data[x].periodoTributo);
							//dijit.byId("item.tasaBolsa").setValue(tasabolsaPorcentaje, false);	
							
						}
						
					}								
				}else {
					 this.unidadMedidaStore = null;
				}
			} else {
				this.iconTooltipMessage(nodeButton, "icon-error-tooltip", res.messageError);
			}
			
		}));
		
		handler.addErrback(function(res){
			
			this.messageBox("Problemas al conectarse con el servidor");
		});


	}
	//PAS20191U210100075	



	if(this.store.getValue(row, "esImpuestoBolsaPlastico") == "IBP00"){
		//this.showHiddenDiv(document.getElementById("item.ICBPER1.show"),true); 
		//this.showHiddenDiv(document.getElementById("item.ICBPER2.show"),true); 
		dijit.byId("check.impuestoBolsasPlastica00").setChecked("checked");
		
		dijit.byId("item.cantidad").constraints = {min:0,places:0};
		dijit.byId("item.cantidad").attr('value',this.round(this.store.getValue(row, "cantidad"), 0));	
	}else{
		dijit.byId("check.impuestoBolsasPlastica01").setChecked("checked");
		//this.showHiddenDiv(document.getElementById("item.ICBPER1.show"),false); 
		//this.showHiddenDiv(document.getElementById("item.ICBPER2.show"),false); 
		dijit.byId("item.cantidad").constraints = {min:0.0000000001, places:'2,10',pattern:'########.00########'}
		dijit.byId("item.cantidad").attr('value',this.store.getValue(row, "cantidad"), 0);	
	}

	var valueIcbper = document.getElementById('boleta.totalICBPERConting');		
	console.log(valueIcbper);	
	if (valueIcbper != undefined){
		this.showHiddenDiv(document.getElementById("item.ICBPER1.show"),true); 
		this.showHiddenDiv(document.getElementById("item.ICBPER2.show"),true); 
	}else{
		this.viewCheckedImpuestoBolsaPlastica();
		this.showHiddenDiv(document.getElementById("item.ICBPER1.show"),false); 
		this.showHiddenDiv(document.getElementById("item.ICBPER2.show"),false); 
	}

	this.viewCheckedImpuestoBolsaPlastica();
	console.log("------>" + this.store.getValue(row, "tipoItem"));
	if (this.store.getValue(row, "tipoItem") == "TI01" || this.store.getValue(row, "tipoItem") == "TI02") {
		dijit.byId("item.subTipo" + this.store.getValue(row, "tipoItem")).setChecked("checked");
		dijit.byId("item.subTipo" + this.store.getValue(row, "tipoItem")).setValue(this.store.getValue(row, "tipoItem"));

	}
	if (this.store.getValue(row, "tipoItem") == "TI00" ) {
		
		if (this.store.getValue(row, "tipoOtrosCargosTributos") == "1" || this.store.getValue(row, "tipoOtrosCargosTributos") == "2" ) {
			dijit.byId("check.impuestoBolsasPlastica00").setAttribute('disabled', true);
			dijit.byId("check.impuestoBolsasPlastica01").setAttribute('disabled', true);
			dijit.byId("item.periodoBolsa").setAttribute('disabled', true);
			dijit.byId("check.impuestoBolsasPlastica01").setChecked("checked");
		}
	}
	
	//PAS20191U210100075


		this.dialogItem.show();
	},

	sendDocument : function () {
		//if(!dijit.byId("generada.form").validate()) return;

		if (dojo.trim(dijit.byId("generada.correoUser").getValue()) == "") {
			mostrarMensaje("Por favor ingrese una direccion de correo.");
			return;
		}

		this.wait("Enviando", "110px", 100);
		var handler = dojo.xhrGet({
				preventCache : false,
				url : this.controller + "?action=enviarCorreo&correoUser=" + dojo.trim(dijit.byId("generada.correoUser").getValue()),
				handleAs : "json",
				sync : true,
				timeout : 10000
			});
		handler.addCallback(dojo.hitch(this, function (response) {
				this.waitMessage.hide();
				if (response.codeError == 0) {
					mostrarMensaje("Se envió correo a la siguiente dirección: " + dijit.byId("generada.correoUser").getValue());
					//dijit.byId("generada.correoUser").setValue("");
					dijit.byId("generada.correoUser").focus();
				} else {
					this.messageBox(res.messageError);
				}
			}));
		handler.addErrback(function (response) {
			this.waitMessage.hide();
			this.messageBox("Problemas al conectarse con el servidor");
		});
	},

	sendDocumentContin : function () {
		//if(!dijit.byId("generada.form").validate()) return;

		if (dojo.trim(dijit.byId("generada.correoUser").getValue()) == "") {
			mostrarMensaje("Por favor ingrese una direccion de correo.");
			return;
		}

		this.wait("Enviando", "110px", 100);
		var handler = dojo.xhrGet({
				preventCache : false,
				url : this.controller + "?action=enviarCorreoContin&correoUser=" + dojo.trim(dijit.byId("generada.correoUser").getValue()),
				handleAs : "json",
				sync : true,
				timeout : 10000
			});
		handler.addCallback(dojo.hitch(this, function (response) {
				this.waitMessage.hide();
				if (response.codeError == 0) {
					mostrarMensaje("Se envió correo a la siguiente dirección: " + dijit.byId("generada.correoUser").getValue());
					//dijit.byId("generada.correoUser").setValue("");
					dijit.byId("generada.correoUser").focus();
				} else {
					this.messageBox(res.messageError);
				}
			}));
		handler.addErrback(function (response) {
			this.waitMessage.hide();
			this.messageBox("Problemas al conectarse con el servidor");
		});
	},

	backInicial : function () {
		mostrarMensajeConfirmacion("Sr. Contribuyente, al regresar al seteo del CP, tendr\u00E1 que volver a ingresar la informaci\u00F3n. \u00BFDesea continuar?", dojo.hitch(this, function(){
			this.store = null;
			dojo.byId("global.modo").value = "01"; //edicion
			dojo.byId("global.validateType").value = "1";

			this.wait("Enviando", "110px", 100);
			var handler = dojo.xhrGet({
					preventCache : false,
					url : this.controller + "?action=backDatosInicial",
					handleAs : "json",
					sync : true,
					timeout : 10000
				});
			handler.addCallback(dojo.hitch(this, function (response) {
					this.waitMessage.hide();
					if (response.codeError == 0) {
						this.content.onLoad = dojo.hitch(this, function () {
								var valExportacion = dojo.byId("global.opcionExportacion").value;
								dijit.byId("inicio.subTipoEE0" + valExportacion).setChecked("checked");
								dijit.byId("inicio.subTipoEE0" + valExportacion).setValue(valExportacion);

								var valNoDomic = dojo.byId("global.opcionNodomic").value;
								dijit.byId("inicio.subTipoND0" + valNoDomic).setChecked("checked");
								dijit.byId("inicio.subTipoND0" + valNoDomic).setValue(valNoDomic);

								var valPagoAnticipado = dojo.byId("global.opcionPagoAnticipado").value;
								dijit.byId("inicio.subTipoFEPagoActicipado0" + valPagoAnticipado).setChecked("checked");
								dijit.byId("inicio.subTipoFEPagoActicipado0" + valPagoAnticipado).setValue(valPagoAnticipado);

								var valEstablecimientoEmisor = dojo.byId("global.opcionEstablecimientoEmisor").value;
								dijit.byId("inicio.subTipoEstEmi0" + valEstablecimientoEmisor).setChecked("checked");
								dijit.byId("inicio.subTipoEstEmi0" + valEstablecimientoEmisor).setValue(valEstablecimientoEmisor);

								var valDomicilioCliente = dojo.byId("global.opcionDomicilioCliente").value;
								dijit.byId("inicio.subTipoDC0" + valDomicilioCliente).setChecked("checked");
								dijit.byId("inicio.subTipoDC0" + valDomicilioCliente).setValue(valDomicilioCliente);

								dijit.byId("inicio.tipoMoneda").setValue(dojo.byId("global.tipoMonedaDescLarge").value);

								var valDescuentos = dojo.byId("global.opcionDscto").value;
								dijit.byId("inicio.subTipo" + valDescuentos).setChecked("checked");
								dijit.byId("inicio.subTipo" + valDescuentos).setValue(valDescuentos);

								var valOperacionesGratuitas = dojo.byId("global.opcionOperacionesGratuitas").value;
								dijit.byId("inicio.subTipoOpeGratuita0" + valOperacionesGratuitas).setChecked("checked");
								dijit.byId("inicio.subTipoOpeGratuita0" + valOperacionesGratuitas).setValue(valOperacionesGratuitas);

								var valOtrosCargosTrib = dojo.byId("global.opcionOtrosCargosTributos").value;
								dijit.byId("inicio.subTipoCargosTribNoBaseImp0" + valOtrosCargosTrib).setChecked("checked");
								dijit.byId("inicio.subTipoCargosTribNoBaseImp0" + valOtrosCargosTrib).setValue(valOtrosCargosTrib);

								dijit.byId("inicio.tipoDocumento").setValue(dojo.byId("global.tipoDocumento").value);
								dijit.byId("inicio.numeroDocumento").setValue(dojo.byId("global.numeroDocumento").value);
								dijit.byId("inicio.razonSocial").setValue(dojo.byId("global.numeroDocumentoDesc").value);

								if (dijit.byId("inicio.tipoDocumento").getValue() == '1') { //Si es DNI pq ya estaba seteado
									dojo.byId("global.validateType").value = "0";
								}

								if (valNoDomic == "1") {
									this.showOpcionesNoDomic(1);
									dijit.byId("inicio.tipoDocRecepFENodomic").setValue(dojo.byId("global.tipoDocumento").value + " - " + dojo.byId("global.tipoDocumentoNodomic").value);
									dijit.byId("inicio.numeroDocRecepFENodomic").setValue(dojo.byId("global.numeroDocumento").value);
									dijit.byId("inicio.nombreRazonRecepFENodomic").setValue(dojo.byId("global.razonSocialNoDomic").value);
									dijit.byId("inicio.nacionalidadRecepFENodomic").setValue(dojo.byId("global.nacionalidadNoDomic").value + " - " + dojo.byId("global.nacionalidadNoDomicDesc").value);
									dijit.byId("inicio.tamRecepFENoDomic").setValue(dojo.byId("global.tamNoDomic").value);
									dijit.byId("inicio.fecIngresoPaisRecepFENoDomic").setValue(new Date(dojo.byId("global.fecIngresoPaisNoDomic").value));
									dijit.byId("inicio.tipoTarjetaRecepFENodomic").setValue(dojo.byId("global.tipoTarjetaNoDomic").value);
									dijit.byId("inicio.numeroTarjetaRecepFENodomic").setValue(dojo.byId("global.numeroTarjetaNoDomic").value);
									dijit.byId("inicio.bancoEmisorTarjetaRecepFENodomic").setValue(dojo.byId("global.bancoTarjetaNoDomic").value);
								} else {
									this.showOpcionesNoDomic(0);
									if (valExportacion == "0") {
										this.showOpcionesExportacion(0);
										var opcionISC = dojo.byId("global.opcionISC").value;
										dijit.byId("inicio.subTipo" + opcionISC).setChecked("checked");
										dijit.byId("inicio.subTipo" + opcionISC).setValue(opcionISC);

										var opcionDscto = dojo.byId("global.opcionDscto").value;
										dijit.byId("inicio.subTipo" + opcionDscto).setChecked("checked");
										dijit.byId("inicio.subTipo" + opcionDscto).setValue(opcionDscto);
									} else {
										this.showOpcionesExportacion(1);
										dijit.byId("inicio.exportacion.razonSocial").setValue(dojo.byId("global.numeroDocumentoExpDesc").value);
										var opcionISC = dojo.byId("global.opcionISC").value;
										dijit.byId("inicio.subTipo" + opcionISC).setChecked("checked");
										dijit.byId("inicio.subTipo" + opcionISC).setValue(opcionISC);
									}
								}
								//PAS20181U210300095
								if (dojo.byId("global.perteneceBVNRUS").value == "0") {
									this.showOpcionesPagoAnticipado(valPagoAnticipado);
								}
							});

						this.content.setHref(this.controller + "?action=backInicial&preventCache=" + this.preventCache());
					} else {
						this.messageBox(res.messageError);
					}
				}));
			handler.addErrback(function (response) {
				this.waitMessage.hide();
				this.messageBox("Problemas al conectarse con el servidor");
			});
		}));

	},

	backIngreso : function () {

		this.wait("Enviando", "110px", 100);

		dojo.byId("global.modo").value = "01"; //edicion

		var handler = dojo.xhrGet({
				preventCache : false,
				url : this.controller + "?action=backDatosIngreso",
				handleAs : "json",
				sync : true,
				timeout : 10000
			});

		handler.addCallback(dojo.hitch(this, function (res) {
				this.waitMessage.hide();
				if (res.codeError == 0) {
					this.content.onLoad = dojo.hitch(this, function () {
							var gtd = dojo.byId("global.tipoDocumento").value;
							if (gtd == "1" || gtd == "4" || gtd == "6" || gtd == "7" || gtd == "A") {
								this.showHiddenDiv(document.getElementById("boleta.ruc.show"), true);
								this.showHiddenDiv(document.getElementById("boleta.razonSocial.show"), false);
								this.showHiddenDiv(document.getElementById("boleta.docsNoDomic.show"), false);

								dijit.byId("boleta.numeroDocumento").setValue(dojo.byId("global.numeroDocumento").value);
								dijit.byId("boleta.razonSocial").setValue(dojo.byId("global.numeroDocumentoDesc").value);
							} else { //"-", "0"
								this.showHiddenDiv(document.getElementById("boleta.ruc.show"), false);
								this.showHiddenDiv(document.getElementById("boleta.razonSocial.show"), true);
								this.showHiddenDiv(document.getElementById("boleta.docsNoDomic.show"), false);

								dijit.byId("boleta.exportacion.razonSocial").setValue(dojo.byId("global.numeroDocumentoDesc").value);
							}

							if (dojo.byId("global.opcionNodomic").value == "1") {
								dijit.byId("boleta.tipoDocumentoNoDomic").setValue(dojo.byId("global.tipoDocumentoNodomic").value);
								dijit.byId("boleta.numeroDocumentoNoDomic").setValue(dojo.byId("global.numeroDocumentonoDomic").value);
								dijit.byId("boleta.razonSocialNoDomic").setValue(dojo.byId("global.razonSocialNoDomic").value);
								this.showHiddenDiv(document.getElementById("boleta.ruc.show"), false);
								this.showHiddenDiv(document.getElementById("boleta.razonSocial.show"), false);
								this.showHiddenDiv(document.getElementById("boleta.docsNoDomic.show"), true);
							}

							if (dojo.byId("global.opcionExportacion").value == "1" || dojo.byId("global.opcionOperacionesGratuitas").value == "1") {
								this.showHiddenDiv(document.getElementById("boleta.situacionEspecial.show"), true);
							} else {
								this.showHiddenDiv(document.getElementById("boleta.situacionEspecial.show"), false);
							}

							dijit.byId("boleta.tipoMonedaDesc").setValue(dojo.byId("global.tipoMonedaDesc").value);

							if (dojo.byId("global.opcionEstablecimientoEmisor").value == "1") {
								this.showHiddenDiv(document.getElementById("boleta.estabEmisor.show"), true);
								dijit.byId("boleta.establecimientoEmisor").set("value", dojo.byId("global.opcionEstablecimientoEmisorDireccion").value);
							} else {
								this.showHiddenDiv(document.getElementById("boleta.estabEmisor.show"), false);
								dijit.byId("boleta.establecimientoEmisor").set("value", "");
							}

							if (dojo.byId("global.opcionDomicilioCliente").value == "1") {
								this.showHiddenDiv(document.getElementById("boleta.direccCliente.show"), true);
								dijit.byId("boleta.direccionCliente").set("value", dojo.byId("global.opcionDomicilioClienteDireccion").value);
							} else {
								this.showHiddenDiv(document.getElementById("boleta.direccCliente.show"), false);
								dijit.byId("boleta.direccionCliente").set("value", "");
							}

							var grid = dijit.byId("boleta.ingreso-grid");
							grid.setStore(this.store);
							grid.update();
							/* Inicio PAS20201U210100285 - Giancarlo Nepo LÃ³pez */
							if (dojo.byId("boleta.totalMontoRedondeo") != null){ /* PAS20201U210100285 - Boleta Contingencia */
								document.getElementById("boleta.totalMontoRedondeo").style.textAlign = "right";
								if (dojo.byId("global.montoRedondeo").value!= ""){
									var redondeo = dojo.byId("global.montoRedondeo").value;
									var moneda = dojo.byId("global.tipoMoneda").value;
									dijit.byId("boleta.totalMontoRedondeo").constraints = {min:-0.09,max:0.09,currency:moneda, places: '2,2',pattern:"\u00A4 #,##0.00;\u00A4 -#,##0.00"};
									if(redondeo < 0){
										dijit.byId("boleta.totalMontoRedondeo").set("displayedValue", redondeo);
									} else {
										dijit.byId("boleta.totalMontoRedondeo").setValue(dojo.currency.format(redondeo,{currency:moneda}));
									}
								}
							}
							/* Fin PAS20201U210100285 - Giancarlo Nepo LÃ³pez */
							//grid.refresh();
							this.updateTotalAmount();

							if (dojo.byId("global.fecVencimiento").value != "") {
								dijit.byId("boleta.fechaVencimiento").setValue(new Date(dojo.byId("global.fecVencimiento").value));
							}
							//PAS20221U210700162-INI
							if (dojo.byId("global.opcionOperacionesGratuitas").value == "1") {
								dijit.byId("boleta.chkOperGratuitas").attr('checked', true);
							}
							
							if (dojo.byId("global.opcionExportacion").value == "1") {
								dijit.byId("boleta.chkExportacion").attr('checked', true);
							}
							//PAS20221U210700162-FIN
							if (dojo.byId("global.fecEmision").value != "") {
								dijit.byId("boleta.fechaEmision").setValue(new Date(dojo.byId("global.fecEmision").value));//PAS20221U210700162
							}
						});

					this.content.setHref(this.controller + "?action=backIngreso&preventCache=" + this.preventCache());
				} else {
					nbControl.attr('disabled', false);
					this.iconTooltipMessage(nodeButton, "icon-error-tooltip", res.messageError);
				}
			}));

		handler.addErrback(function (response) {
			this.waitMessage.hide();
			this.messageBox("Problemas al conectarse con el servidor");
		});
	},

	backIngresoContin : function () {

		this.wait("Enviando", "110px", 100);

		dojo.byId("global.modo").value = "01"; //edicion

		var handler = dojo.xhrGet({
				preventCache : false,
				url : this.controller + "?action=backDatosIngresoContin",
				handleAs : "json",
				sync : true,
				timeout : 10000
			});

		handler.addCallback(dojo.hitch(this, function (res) {
				this.waitMessage.hide();
				if (res.codeError == 0) {
					var obj = JSON.parse(res.data);
					var ser = obj.serie;
					var num = obj.numero;
					var estab = obj.establecimiento;
					this.content.onLoad = dojo.hitch(this, function () {
							document.getElementById("serie").value = ser;
							document.getElementById("numero").value = num;
							document.getElementById("establecimiento").value = estab;
							this.showHiddenDiv(document.getElementById("serie"), true);
							this.showHiddenDiv(document.getElementById("numero"), true);
							this.showHiddenDiv(document.getElementById("establecimiento"), true);

							var gtd = dojo.byId("global.tipoDocumento").value;
							if (gtd == "1" || gtd == "4" || gtd == "6" || gtd == "7" || gtd == "A") {
								this.showHiddenDiv(document.getElementById("boleta.ruc.show"), true);
								this.showHiddenDiv(document.getElementById("boleta.razonSocial.show"), false);
								this.showHiddenDiv(document.getElementById("boleta.docsNoDomic.show"), false);

								dijit.byId("boleta.numeroDocumento").setValue(dojo.byId("global.numeroDocumento").value);
								dijit.byId("boleta.razonSocial").setValue(dojo.byId("global.numeroDocumentoDesc").value);
							} else { //"-", "0"
								this.showHiddenDiv(document.getElementById("boleta.ruc.show"), false);
								this.showHiddenDiv(document.getElementById("boleta.razonSocial.show"), true);
								this.showHiddenDiv(document.getElementById("boleta.docsNoDomic.show"), false);

								dijit.byId("boleta.exportacion.razonSocial").setValue(dojo.byId("global.numeroDocumentoDesc").value);
							}

							if (dojo.byId("global.opcionNodomic").value == "1") {
								dijit.byId("boleta.tipoDocumentoNoDomic").setValue(dojo.byId("global.tipoDocumentoNodomic").value);
								dijit.byId("boleta.numeroDocumentoNoDomic").setValue(dojo.byId("global.numeroDocumentonoDomic").value);
								dijit.byId("boleta.razonSocialNoDomic").setValue(dojo.byId("global.razonSocialNoDomic").value);
								this.showHiddenDiv(document.getElementById("boleta.ruc.show"), false);
								this.showHiddenDiv(document.getElementById("boleta.razonSocial.show"), false);
								this.showHiddenDiv(document.getElementById("boleta.docsNoDomic.show"), true);
							}

							if (dojo.byId("global.opcionExportacion").value == "1" || dojo.byId("global.opcionOperacionesGratuitas").value == "1") {
								this.showHiddenDiv(document.getElementById("boleta.situacionEspecial.show"), true);
							} else {
								this.showHiddenDiv(document.getElementById("boleta.situacionEspecial.show"), false);
							}

							dijit.byId("boleta.tipoMonedaDesc").setValue(dojo.byId("global.tipoMonedaDesc").value);

							if (dojo.byId("global.opcionEstablecimientoEmisor").value == "1") {
								this.showHiddenDiv(document.getElementById("boleta.estabEmisor.show"), true);
								dijit.byId("boleta.establecimientoEmisor").set("value", dojo.byId("global.opcionEstablecimientoEmisorDireccion").value);
							} else {
								this.showHiddenDiv(document.getElementById("boleta.estabEmisor.show"), false);
								dijit.byId("boleta.establecimientoEmisor").set("value", "");
							}

							if (dojo.byId("global.opcionDomicilioCliente").value == "1") {
								this.showHiddenDiv(document.getElementById("boleta.direccCliente.show"), true);
								dijit.byId("boleta.direccionCliente").set("value", dojo.byId("global.opcionDomicilioClienteDireccion").value);
							} else {
								this.showHiddenDiv(document.getElementById("boleta.direccCliente.show"), false);
								dijit.byId("boleta.direccionCliente").set("value", "");
							}

							var grid = dijit.byId("boleta.ingreso-grid");
							grid.setStore(this.store);
							grid.update();
							//grid.refresh();
							this.updateTotalAmount();

							if (dojo.byId("global.fecVencimiento").value != "") {
								dijit.byId("boleta.fechaVencimiento").setValue(new Date(dojo.byId("global.fecVencimiento").value));
							}

							//PAS20221U210700162-INI
							if (dojo.byId("global.opcionOperacionesGratuitas").value == "1") {
								dijit.byId("boleta.chkOperGratuitas").attr('checked', true);
							}
							
							if (dojo.byId("global.opcionExportacion").value == "1") {
								dijit.byId("boleta.chkExportacion").attr('checked', true);
							}
							//PAS20221U210700162-FIN
							
							if (dojo.byId("global.fecEmision").value != "") {
								dijit.byId("boleta.fechaEmision").setValue(new Date(dojo.byId("global.fecEmision").value));//PAS20221U210700162
							}
						});

					this.content.setHref(this.controller + "?action=backIngreso&preventCache=" + this.preventCache());
				} else {
					nbControl.attr('disabled', false);
					this.iconTooltipMessage(nodeButton, "icon-error-tooltip", res.messageError);
				}
			}));

		handler.addErrback(function (response) {
			this.waitMessage.hide();
			this.messageBox("Problemas al conectarse con el servidor");
		});
	},

	backDocRel : function () {
		dojo.byId("global.modo").value = "01"; //edicion

		this.wait("Enviando", "110px", 100);
		var handler = dojo.xhrGet({
				preventCache : false,
				url : this.controller + "?action=backDatosDocRel",
				handleAs : "json",
				sync : true,
				timeout : 10000
			});

		handler.addCallback(dojo.hitch(this, function (res) {
				this.waitMessage.hide();
				if (res.codeError == 0) {

					this.content.onLoad = dojo.hitch(this, function () {
							dijit.byId("docsrel.observacion").setValue(dojo.byId("global.docsrel.observacion").value);
							if (dojo.byId("global.opcionFESectorPublico").value == "1") {
								this.showHiddenDiv(document.getElementById("docsrel.informacionFESectorPublico.show"), true);
							} else {
								this.showHiddenDiv(document.getElementById("docsrel.informacionFESectorPublico.show"), false);
							}
							var moneda = dojo.byId("global.tipoMoneda").value;

						});

					this.content.setHref(this.controller + "?action=backDocRel&preventCache=" + this.preventCache());
				} else {
					nbControl.attr('disabled', false);
					this.iconTooltipMessage(nodeButton, "icon-error-tooltip", res.messageError);
				}
			}));

		handler.addErrback(function (response) {
			this.waitMessage.hide();
			this.messageBox("Problemas al conectarse con el servidor");
		});
	},

	getValorOpcionIdEstabEmisor : function () {
		var valOpcionIdEstabEmisor;
		for (i = 1; i < 3; i++) {
			if (dijit.byId("estabEmisor.idEstab0" + i).getValue() != false) {
				valOpcionIdEstabEmisor = dijit.byId("estabEmisor.idEstab0" + i).getValue()
			}
		}
		return valOpcionIdEstabEmisor;
	},

	showNextDireccionCliente : function () {

		var tipoDireccion = this.getValorOpcionTipoDireccCliente();
		dojo.byId("global.opcionDomicilioClienteIdentifica").value = tipoDireccion;

		if (tipoDireccion == null || tipoDireccion == "") {
			mostrarMensaje("Debe seleccionar el tipo de direcci\u00F3n del cliente.");
			return;
		}

		dojo.byId("direccCliente.num_ruc_domicilio").value = dojo.byId("global.numRucEmisor").value;

		if (tipoDireccion == 1 || tipoDireccion == 2) {
			if (tipoDireccion == 1) {
				dojo.byId("direccCliente.num_ruc_domicilio").value = dojo.byId("global.numeroDocumento").value;
			} else {
				if (tipoDireccion == 2) {
					var ruc3ro = dijit.byId("direccCliente.txt_ruc_tercero").getValue();
					if (ruc3ro == "") {
						mostrarMensaje("Debe de ingresar RUC.");
						return;
					}
					if (ruc3ro.length != 11) {
						mostrarMensaje("RUC no válido.");
						return;
					}

					if (!this.isValidRuc(ruc3ro)) {
						mostrarMensaje("RUC no válido.");
						return;
					}

					dojo.byId("direccCliente.num_ruc_domicilio").value = ruc3ro;
				}
			}

			var grilla = dijit.byId("direccCliente.domiciliosGrid");
			var datos = grilla.store._arrayOfAllItems;
			var filas = grilla.store._arrayOfAllItems.length;
			var datoSel = "";
			var numSeleccionados = 0;
			for (i = 0; i < filas; i++) {
				if (dojo.byId("direccCliente.selDomicilioGrid" + i).checked == true) {
					numSeleccionados++;
					dojo.byId("global.opcionDomicilioClienteSeleccionado").value = i;
					var fila = grilla.getItem(i);
					var codigo = grilla.store.getValue(fila, "codigo");
					var ubigeo = grilla.store.getValue(fila, "ubigeo");
					var domicilio = grilla.store.getValue(fila, "domicilio");
					var cod_estab = grilla.store.getValue(fila, "cod_estab");
					dojo.byId("global.opcionDomicilioClienteDireccion").value = domicilio;
					dojo.byId("direccCliente.domicilio").value = domicilio;
					dojo.byId("direccCliente.codigo").value = codigo;
					dojo.byId("direccCliente.coddist").value = ubigeo;
					dojo.byId("direccCliente.cod_estab").value = cod_estab;
					break;
				}
			}
			if (numSeleccionados == 0) {
				mostrarMensaje("Debe seleccionar un establecimiento.");
				return;
			}

		} else if (tipoDireccion == 3) {
			if (dojo.byId("direccCliente.coddist").value == "" || dojo.byId("direccCliente.coddist").value == "000000") {
				mostrarMensaje("Debe seleccionar departamento, provincia y distrito.");
				return;
			} else if (dijit.byId("direccCliente.nomvia").getValue() == "" && dijit.byId("direccCliente.nomzon").getValue() == "") {
				mostrarMensaje("Debe ingresar al menos uno de los campos marcados con asterisco (*).");
				return;
			}
      //<!-- PAS20211U210700185 -->
      
           
        else if (dijit.byId("direccCliente.num").getValue() == "" && dijit.byId("direccCliente.km").getValue() == "" && dijit.byId("direccCliente.mz").getValue() == "") {
				alert("Debe ingresar el n\u00FAmero o kil\u00F3metro o manzana");
				return;
        
      }
      
       else if (dijit.byId("direccCliente.num").getValue() != "" && dijit.byId("direccCliente.km").getValue() != "" && dijit.byId("direccCliente.mz").getValue() != ""|| 
                 dijit.byId("direccCliente.num").getValue() != "" && dijit.byId("direccCliente.km").getValue() != "" && dijit.byId("direccCliente.mz").getValue() == ""||
                 dijit.byId("direccCliente.num").getValue() != "" && dijit.byId("direccCliente.km").getValue() == "" && dijit.byId("direccCliente.mz").getValue() != ""||
                 dijit.byId("direccCliente.num").getValue() == "" && dijit.byId("direccCliente.km").getValue() != "" && dijit.byId("direccCliente.mz").getValue() != "")
         {
				alert("Debe ingresar solo el n\u00FAmero o kil\u00F3metro o manzana");
				return;
        
      } 
      
       else if (dijit.byId("direccCliente.mz").getValue() != "" && dijit.byId("direccCliente.lote").getValue() == "") {
				alert("Debe ingresar el lote");
				return;
        
      }      
       
        
      //<!-- PAS20211U210700185 -->
                  //<!-- PAS20211U210700185 -->
     /*       
      
      
      
      
       else if (dijit.byId("direccCliente.nomvia").getValue() != "" && (dijit.byId("direccCliente.tipvia").getValue() == "" || dijit.byId("direccCliente.tipvia").getValue() == "11")) {
				mostrarMensaje("Debe ingresar el tipo de via.");
				return;
			} else if (dijit.byId("direccCliente.nomzon").getValue() != "" && (dijit.byId("direccCliente.tipzon").getValue() == "" || dijit.byId("direccCliente.tipzon").getValue() == "11")) {
				mostrarMensaje("Debe ingresar al tipo de zona.");
				return;
			} else if (dijit.byId("direccCliente.km").getValue() == "" && dijit.byId("direccCliente.mz").getValue() == "" && dijit.byId("direccCliente.lote").getValue() == "" && dijit.byId("direccCliente.dep").getValue() == "" && dijit.byId("direccCliente.int").getValue() == "") {
				mostrarMensaje("Debe ingresar al menos el kil\u00F3metro, manzana, lote, departamento o interior.");
				return;
			}      */
      //<!-- PAS20211U210700185 -->

			var domicilio = "";
			if (dijit.byId("direccCliente.nomvia").getValue() != "") {
				domicilio = dijit.byId("direccCliente.tipvia").getDisplayedValue().substring(0, 4) + " " + dijit.byId("direccCliente.nomvia").getValue() + " " + dijit.byId("direccCliente.num").getValue();
			}

			if (dijit.byId("direccCliente.nomzon").getValue() != "") {
				domicilio = domicilio + " " + dijit.byId("direccCliente.tipzon").getDisplayedValue().substring(0, 4) + " " + dijit.byId("direccCliente.nomzon").getValue();
			}
			if (dijit.byId("direccCliente.mz").getValue() != "") {
				domicilio = domicilio + " MZA. " + dijit.byId("direccCliente.mz").getValue();
			}
			if (dijit.byId("direccCliente.lote").getValue() != "") {
				domicilio = domicilio + " LOTE. " + dijit.byId("direccCliente.lote").getValue();
			}
			if (dijit.byId("direccCliente.dep").getValue() != "") {
				domicilio = domicilio + " DPTO. " + dijit.byId("direccCliente.dep").getValue();
			}
			if (dijit.byId("direccCliente.int").getValue() != "") {
				domicilio = domicilio + " INT. " + dijit.byId("direccCliente.int").getValue();
			}
			if (dijit.byId("direccCliente.km").getValue() != "") {
				domicilio = domicilio + " KM. " + dijit.byId("direccCliente.km").getValue();
			}
			if (dijit.byId("direccCliente.refer").getValue() != "") {
				domicilio = domicilio + " " + dijit.byId("direccCliente.refer").getValue();
			}

			domicilio = domicilio + (" ") + dijit.byId("direccCliente.emisorDpto").getDisplayedValue() + "-" +
				dijit.byId("direccCliente.emisorProv").getDisplayedValue() + "-" +
				dijit.byId("direccCliente.emisorDist").getDisplayedValue();

			dojo.byId("global.opcionDomicilioClienteDireccion").value = domicilio;
			dojo.byId("direccCliente.domicilio").value = domicilio;
			dojo.byId("direccCliente.cod_estab").value = "0";
		}

		this.wait("Procesando", "95px", 200);

		var handler = dojo.io.iframe.send({
				url : this.controller + "?action=datosDireccCliente&subTipoEdireccCliente=" + dojo.byId("direccCliente.subTipoEdireccCliente").value + "&codigo=" + dojo.byId("direccCliente.codigo").value + "&coddist=" + dojo.byId("direccCliente.coddist").value + "&domicilio=" + dojo.byId("direccCliente.domicilio").value + "&cod_estab=" + dojo.byId("direccCliente.cod_estab").value + "&num_ruc_domicilio=" + dojo.byId("direccCliente.num_ruc_domicilio").value + "&refer=" + dojo.byId("direccCliente.refer").value + "&tipvia=" + dijit.byId("direccCliente.tipvia").get('value') + "&tipzon=" + dijit.byId('direccCliente.tipzon').get('value') + "&num=" + dojo.byId("direccCliente.num").value + "&mz=" + dojo.byId("direccCliente.mz").value + "&lote=" + dojo.byId("direccCliente.lote").value + "&dep=" + dojo.byId("direccCliente.dep").value + "&int=" + dojo.byId("direccCliente.int").value + "&km=" + dojo.byId("direccCliente.km").value + "&nomzon=" + dojo.byId("direccCliente.nomzon").value + "&nomvia=" + dojo.byId("direccCliente.nomvia").value,
				handleAs : "json",
				sync : true,
				timeout : 10000,
				preventCache : true
			});

		handler.addCallback(dojo.hitch(this, function (res) {
				this.waitMessage.hide();
				if (res.codeError == 0) {
					dijit.byId("boleta.direccionCliente").set("value", dojo.byId("global.opcionDomicilioClienteDireccion").value);
					this.dialogDireccionCliente.hide();
          //<!-- PAS20211U210700185 -->
          this.dialogDireccionCliente.reset();
          //<!-- PAS20211U210700185 -->
				} else {
					mostrarMensaje(res.messageError);
					nbControl.attr('disabled', false);
          //<!-- PAS20211U210700185 -->
          this.dialogDireccionCliente.reset();
          //<!-- PAS20211U210700185 -->
				}
			}));

		handler.addErrback(function (res) {
			nbControl.attr('disabled', false);
			this.waitMessage.hide();
			mostrarMensaje("Problemas al conectarse con el servidor");
		});
	},

	showNextEstabEmisor : function () {
		var varValorIdEstabEmisor = this.getValorOpcionIdEstabEmisor();
		if (varValorIdEstabEmisor != null && varValorIdEstabEmisor != "") {
			dojo.byId("global.opcionEstablecimientoEmisorIdentifica").value = varValorIdEstabEmisor;
		} else {
			mostrarMensaje("Debe seleccionar el tipo del establecimiento.");
			return;
		}

		var grilla = dijit.byId('estabEmisor.domiciliosGrid');
		var datos = grilla.store._arrayOfAllItems;
		var filas = grilla.store._arrayOfAllItems.length;
		var datoSel = "";
		var numSeleccionados = 0;
		for (i = 0; i < filas; i++) {
			if (dojo.byId("estabEmisor.selDomicilioGrid" + i).checked == true) {
				numSeleccionados++;
				var fila = grilla.getItem(i);
				var codigo = grilla.store.getValue(fila, "codigo");
				var ubigeo = grilla.store.getValue(fila, "ubigeo");
				var domicilio = grilla.store.getValue(fila, "domicilio");
				var cod_estab = grilla.store.getValue(fila, "cod_estab");
				dojo.byId("global.opcionEstablecimientoEmisorDireccion").value = domicilio;
				//datoSel = dijit.byId("estabEmisor.selDomicilioGrid"+valorCheck).getValue();
				dojo.byId("global.opcionEstablecimientoEmisorSeleccionado").value = i;
				dojo.byId("estabEmisor.cod_estab").value = cod_estab;
			}
		}

		if (varValorIdEstabEmisor == 1 && numSeleccionados == 0) {
			mostrarMensaje("Debe seleccionar un establecimiento.");
			return;
		}
		dojo.byId("estabEmisor.num_ruc_domicilio").value = dojo.byId("global.numRucEmisor").value;

		this.wait("Procesando", "95px", 200);
		var handler = dojo.io.iframe.send({
				url : this.controller + "?action=datosEstabEmisor&id=" + dojo.byId("global.opcionEstablecimientoEmisorIdentifica").value + "&codigo=" + codigo + "&ubigeo=" + ubigeo + "&domicilio=" + domicilio + "&num_ruc_domicilio=" + dojo.byId("estabEmisor.num_ruc_domicilio").value + "&cod_estab=" + dojo.byId("estabEmisor.cod_estab").value,
				handleAs : "json",
				sync : true,
				timeout : 10000,
				preventCache : true
			});

		handler.addCallback(dojo.hitch(this, function (res) {
				this.waitMessage.hide();
				if (res.codeError == 0) {
					//PAS20201U210100151
					// dijit.byId("boleta.establecimientoEmisor").set("value", res.data);
					dijit.byId("boleta.establecimientoEmisor").set("value", dojo.byId("global.opcionEstablecimientoEmisorDireccion").value);
					this.dialogEstablecimientoEmisor.hide();
				} else {
					mostrarMensaje(res.messageError);
					nbControl.attr('disabled', false);
				}
			}));

		handler.addErrback(function (res) {
			nbControl.attr('disabled', false);
			this.waitMessage.hide();
			mostrarMensaje("Problemas al conectarse con el servidor");
		});
	},

	showNextEstabEmisorContin : function () {
		var varValorIdEstabEmisor = this.getValorOpcionIdEstabEmisor();
		if (varValorIdEstabEmisor != null && varValorIdEstabEmisor != "") {
			dojo.byId("global.opcionEstablecimientoEmisorIdentifica").value = varValorIdEstabEmisor;
		} else {
			mostrarMensaje("Debe seleccionar el tipo del establecimiento.");
			return;
		}

		var grilla = dijit.byId('estabEmisor.domiciliosGrid');
		var datos = grilla.store._arrayOfAllItems;
		var filas = grilla.store._arrayOfAllItems.length;
		var datoSel = "";
		var numSeleccionados = 0;
		for (i = 0; i < filas; i++) {
			if (dojo.byId("estabEmisor.selDomicilioGrid" + i).checked == true) {
				numSeleccionados++;
				var fila = grilla.getItem(i);
				var codigo = grilla.store.getValue(fila, "codigo");
				var ubigeo = grilla.store.getValue(fila, "ubigeo");
				var domicilio = grilla.store.getValue(fila, "domicilio");
				var cod_estab = grilla.store.getValue(fila, "cod_estab");
				dojo.byId("global.opcionEstablecimientoEmisorDireccion").value = domicilio;
				//datoSel = dijit.byId("estabEmisor.selDomicilioGrid"+valorCheck).getValue();
				dojo.byId("global.opcionEstablecimientoEmisorSeleccionado").value = i;
				dojo.byId("estabEmisor.cod_estab").value = cod_estab;
			}
		}

		if (varValorIdEstabEmisor == 1 && numSeleccionados == 0) {
			mostrarMensaje("Debe seleccionar un establecimiento.");
			return;
		}
		dojo.byId("estabEmisor.num_ruc_domicilio").value = dojo.byId("global.numRucEmisor").value;

		this.wait("Procesando", "95px", 200);
		var handler = dojo.io.iframe.send({
				url : this.controller + "?action=datosEstabEmisor&id=" + dojo.byId("global.opcionEstablecimientoEmisorIdentifica").value + "&codigo=" + codigo + "&ubigeo=" + ubigeo + "&domicilio=" + domicilio + "&num_ruc_domicilio=" + dojo.byId("estabEmisor.num_ruc_domicilio").value + "&cod_estab=" + dojo.byId("estabEmisor.cod_estab").value,
				handleAs : "json",
				sync : true,
				timeout : 10000,
				preventCache : true
			});

		handler.addCallback(dojo.hitch(this, function (res) {
				this.waitMessage.hide();
				if (res.codeError == 0) {
					dijit.byId("boleta.establecimientoEmisor").set("value", dojo.byId("global.opcionEstablecimientoEmisorDireccion").value);
					document.getElementById("establecimiento").value = (res.data);
					document.getElementById("numero").value = "";
					this.dialogEstablecimientoEmisor.hide();
				} else {
					mostrarMensaje(res.messageError);
					nbControl.attr('disabled', false);
				}
			}));

		handler.addErrback(function (res) {
			nbControl.attr('disabled', false);
			this.waitMessage.hide();
			mostrarMensaje("Problemas al conectarse con el servidor");
		});
	},

	showBoletaIngreso : function () {
		localStorage.removeItem('data'); //DAG PAS20221U210700299
		if (!dijit.byId("inicio.form").validate())
			return;
		this.cargarValoresGlobales();

		dijit.byId("inicio.botonGrabarDocumento").attr('disabled', false);
		var valExportacion = dojo.byId("global.opcionExportacion").value;
		var valNodomic = dojo.byId("global.opcionNodomic").value;

		if (valExportacion == "1") { //Exportacion
			//if (dojo.trim(dijit.byId("inicio.exportacion.razonSocial").getValue()) == ""){
			//	var node = dijit.byId("inicio.exportacion.razonSocial").focusNode;
			//	node.focus();
			//	mostrarMensaje("Por favor ingrese una Razon Social.");
			//	return;
			//}
			var td = dijit.byId("inicio.tipoDocumento").getValue();
			var ndControl = dijit.byId("inicio.numeroDocumento");
			var ndLength = dojo.trim(ndControl.getValue()).length;
			var rzControl = dijit.byId("inicio.razonSocial");
			var rzLength = dojo.trim(rzControl.getValue()).length;

			if (td == '-' && rzLength == 0) {
				mostrarMensaje("Por favor ingrese el nombre del Cliente.");
				rzControl.focus();
				return;
			} else if (td != '-' && ndLength == 0) {
				mostrarMensaje("Tiene que ingresar un número de Documento.");
				ndControl.focus();
				return;
			} else {
				if (td != "-") {
					if (td == "1") { //DNI
						if (ndLength != 8) {
							mostrarMensaje("N\u00FAmero de documento de identidad inconsistente.");
							ndControl.attr('value', "");
							ndControl.focus();
							return;
						}
					} else {
						if (td == "6") { //RUC
							this.self = this;
							if (!this.isValidRuc(dojo.trim(ndControl.getValue()))) {
								mostrarMensaje("N\u00FAmero de RUC incorrecto.");
								ndControl.attr('value', "");
								ndControl.focus();
								return;
							}
						} else { //0, 4, 7 o A
							if (ndLength > 15 || rzLength == 0) {
								mostrarMensaje("N\u00FAmero de documento de identidad y/o nombre del cliente inconsistente.");
								ndControl.attr('value', "");
								ndControl.focus();
								return;
							}
						}
					}
				}
			}

			this.showTipoBeneficio(0);
		} else {
			if (valNodomic == "1") { //No domiciliado
				var tipoDocNodomic = dijit.byId("inicio.tipoDocRecepFENodomic").getValue().substring(0, 1);
				if (tipoDocNodomic == "-") {
					this.iconTooltipMessage("inicio.tipoDocRecepFENodomic", "icon-ok-tooltip", "Debe seleccionar el tipo de documento.");
					return;
				}
				var numeroDocNodomic = dojo.trim(dijit.byId("inicio.numeroDocRecepFENodomic").getValue());
				if (numeroDocNodomic == "") {
					this.iconTooltipMessage("inicio.numeroDocRecepFENodomic", "icon-ok-tooltip", "Debe registrar el numero de documento.");
					return;
				}
				var nombreDocNodomic = dojo.trim(dijit.byId("inicio.nombreRazonRecepFENodomic").getValue());
				if (nombreDocNodomic == "") {
					this.iconTooltipMessage("inicio.nombreRazonRecepFENodomic", "icon-ok-tooltip", "Debe registrar el nombre o razon social.");
					return;
				}
				var paisNoDomic = dijit.byId("inicio.nacionalidadRecepFENodomic").getValue().substring(0, 1);
				if (paisNoDomic == "-") {
					this.iconTooltipMessage("inicio.nacionalidadRecepFENodomic", "icon-ok-tooltip", "Debe seleccionar el pa\u00EDs de origen.");
					return;
				}

				////////////
				var fechaIngreso = dojo.byId("inicio.fecIngresoPaisRecepFENoDomic").value;
				if (fechaIngreso == "") {
					this.iconTooltipMessage("inicio.fecIngresoPaisRecepFENoDomic", "icon-ok-tooltip", "Debe registrar la fecha de ingreso al pais.");
					return;
				}
				fechaIngreso = dijit.byId("inicio.fecIngresoPaisRecepFENoDomic").getValue();
				var fechaHoy = new Date();
				var fechaIngresoDate = new Date(fechaIngreso);

				if (fechaIngresoDate > fechaHoy) {
					this.iconTooltipMessage("inicio.fecIngresoPaisRecepFENoDomic", "icon-ok-tooltip", "Fecha de ingreso al pais no puede ser mayor a la fecha de hoy");
					return;
				}

				//////////
				var tipoTarjeta = dijit.byId("inicio.tipoTarjetaRecepFENodomic").getValue().substring(0, 1);
				if (tipoTarjeta == "-") {
					this.iconTooltipMessage("inicio.tipoTarjetaRecepFENodomic", "icon-ok-tooltip", "Debe seleccionar el tipo de tarjeta.");
					return;
				}
				var numeroTarjeta = dojo.byId("inicio.numeroTarjetaRecepFENodomic").value;
				if (numeroTarjeta == "") {
					this.iconTooltipMessage("inicio.numeroTarjetaRecepFENodomic", "icon-ok-tooltip", "Debe registrar el numero de tarjeta.");
					return;
				}

				var bancoTarjeta = dojo.trim(dijit.byId("inicio.bancoEmisorTarjetaRecepFENodomic").getValue());
				if (bancoTarjeta == "") {
					//this.iconTooltipMessage("inicio.bancoEmisorTarjetaRecepFENodomic", "icon-ok-tooltip", "Debe registrar el banco emisor de la tarjeta.");
					//return;
				}

				mostrarMensaje("La Boleta de Venta Electronica de Venta Nacional a No Domiciliados es solo para venta de bienes.");
			} else {
				var td = dijit.byId("inicio.tipoDocumento").getValue();
				var ndControl = dijit.byId("inicio.numeroDocumento");
				var ndLength = dojo.trim(ndControl.getValue()).length;
				var rzControl = dijit.byId("inicio.razonSocial");
				var rzLength = dojo.trim(rzControl.getValue()).length;

				if (td != '-' && ndLength == 0) {
					mostrarMensaje("Tiene que ingresar un número de Documento.");
					ndControl.focus();
					return;
				} else {
					if (td != "-") {
						if (td == "1") { //DNI
							if (ndLength != 8) {
								mostrarMensaje("N\u00FAmero de documento de identidad inconsistente.");
								ndControl.attr('value', "");
								ndControl.focus();
								return;
							}
						} else {
							if (td == "6") { //RUC
								this.self = this;
								if (!this.isValidRuc(dojo.trim(ndControl.getValue()))) {
									mostrarMensaje("N\u00FAmero de RUC incorrecto.");
									ndControl.attr('value', "");
									ndControl.focus();
									return;
								}
							} else { //0, 4, 7 o A
								if (ndLength > 15 || rzLength == 0) {
									mostrarMensaje("N\u00FAmero de documento de identidad y/o nombre del cliente inconsistente.");
									ndControl.attr('value', "");
									ndControl.focus();
									return;
								}
							}
						}
					}
				}

				this.showTipoBeneficio(1);
			}
		}

		var nbControl = dijit.byId("inicio.botonGrabarDocumento");
		nbControl.attr('disabled', true);
		this.wait("Procesando", "95px", 200);
		dojo.byId("action").value = "datosInicial";
		var self = this;
		var handler = dojo.io.iframe.send({
				url : this.controller,
				handleAs : "json",
				sync : true,
				timeout : 10000,
				preventCache : true,
				form : "global.form"
			});

		handler.addCallback(dojo.hitch(this, function (res) {
				this.waitMessage.hide();
				
				if (res.codeError == 0) {

					this.content.onLoad = dojo.hitch(this, function () {

							document.getElementById("boleta.form").style.height = "auto";

							if (dojo.byId("global.opcionEstablecimientoEmisor").value == "1") {
								this.showHiddenDiv(document.getElementById("boleta.estabEmisor.show"), true);
								//dijit.byId("boleta.establecimientoEmisor").set("value",dojo.byId("global.opcionEstablecimientoEmisorDireccion").value);
								dijit.byId("boleta.establecimientoEmisor").set("value", "");
								
								//PAS20201U210100151
								var newStore =[];
								
								var URL = "emitir.do?action=getDomiciliosEmisor";
								var kw = {
				           				url:URL,
				           				handleAs: "json",      
				           				load: function(response, ioArgs) {
				           				       console.log(response);
				           				       newStore= response.items;
				           						},      
				           				preventCache: false,      
				           				timeout: 35000,
				           				sync:true,      
				           				error: function(error,ioArgs){        
				           						mostrarMensaje("Ha ocurrido el siguiente error:" + error.message + " " +  ioArgs.xhr.status);      
				       				}};
								dojo.xhrGet(kw);
								
								var filas=newStore.length;
								
								for (i=0; i< filas;i++){
									if(i==0 && newStore[i].tipo=='DOMICILIO FISCAL'){
										dojo.byId("global.opcionEstablecimientoEmisorIdentifica").value = 1;
										
										dojo.byId("global.opcionEstablecimientoEmisorDireccion").value = newStore[i].domicilio;
										dojo.byId("global.opcionEstablecimientoEmisorSeleccionado").value = i;
										
										var handler = dojo.io.iframe.send({
										url: this.controller + "?action=datosEstabEmisor&id=" + dojo.byId("global.opcionEstablecimientoEmisorIdentifica").value + "&codigo=" + newStore[i].codigo + "&ubigeo=" + newStore[i].ubigeo + "&domicilio=" + encodeURIComponent(newStore[i].domicilio) + "&num_ruc_domicilio=" + encodeURIComponent(dojo.byId("global.numRucEmisor").value) + "&cod_estab=" +  newStore[i].cod_estab,
										handleAs: "json",
											sync: true,
											timeout: 10000,
											preventCache: true
										});
										
										handler.addCallback(dojo.hitch(this, function(res){
											if(res.codeError == 0) {
												dijit.byId("boleta.establecimientoEmisor").set("value",dojo.byId("global.opcionEstablecimientoEmisorDireccion").value);
												
												if (document.getElementById("establecimiento")){
													document.getElementById("establecimiento").value=(res.data);
												}
											}
										}));
										
										break;
									}
								}
								//PAS20201U210100151
								
							} else {
								this.showHiddenDiv(document.getElementById("boleta.estabEmisor.show"), false);
								dijit.byId("boleta.establecimientoEmisor").set("value", "");
							}

							if (dojo.byId("global.opcionDomicilioCliente").value == "1") {
								this.showHiddenDiv(document.getElementById("boleta.direccCliente.show"), true);
								dijit.byId("boleta.direccionCliente").set("value",dojo.byId("global.opcionDomicilioClienteDireccion").value);              						    
								
								//PAS20201U210100151
								if (dojo.byId("global.tipoDocumento").value == "6") {
									dijit.byId("direccCliente.subTipoEdireccCliente01").setChecked("checked");
									
									var newStore =[];
									
									var URL = "emitir.do?action=getDomiciliosCliente";
									var kw = {
											url:URL,
											handleAs: "json",      
											load: function(response, ioArgs) {
												   
												   newStore= response.items;
													},      
											preventCache: false,      
											timeout: 35000,
											sync:true,      
											error: function(error,ioArgs){        
													mostrarMensaje("Ha ocurrido el siguiente error:" + error.message + " " +  ioArgs.xhr.status);      
										}};
									dojo.xhrGet(kw);
									
									var filas=newStore.length;
									
									for (i=0; i< filas;i++){
										if(i==0 && newStore[i].tipo=='DOMICILIO FISCAL'){
											dojo.byId("global.opcionDomicilioClienteDireccion").value = newStore[i].domicilio;
											dojo.byId("global.opcionDomicilioClienteSeleccionado").value = i;
											
											var handler = dojo.io.iframe.send({
												url: this.controller + "?action=datosDireccCliente&subTipoEdireccCliente=1&codigo=" + newStore[i].codigo + "&coddist=" + newStore[i].ubigeo + "&domicilio=" + encodeURIComponent(newStore[i].domicilio) + "&cod_estab=" + newStore[i].cod_estab + "&num_ruc_domicilio=" + dojo.byId("global.numRucEmisor").value + "&refer=&tipvia=&tipzon=&num=&mz=&lote=&dep=&int=&km=&nomzon=&nomvia=",
												handleAs: "json",
												sync: true,
												timeout: 10000,
												preventCache: true
											});
											
											handler.addCallback(dojo.hitch(this, function(res){
												this.waitMessage.hide();
												if(res.codeError == 0) {
													dijit.byId("boleta.direccionCliente").set("value",dojo.byId("global.opcionDomicilioClienteDireccion").value);										
												} else {
													mostrarMensaje(res.messageError);	
													nbControl.attr('disabled', false);				
												}
											}));
											
											break;
										}
									}
								}	
								//PAS20201U210100151
								
							} else {
								this.showHiddenDiv(document.getElementById("boleta.direccCliente.show"), false);
								dijit.byId("boleta.direccionCliente").set("value", "");
							}
					
							this.iconTooltipMessage("boleta.addItemButtonToolTip", "icon-ok-tooltip", "Adicionar &iacutetems a la Boleta de Venta.");

							var gtd = dojo.byId("global.tipoDocumento").value;
							if (gtd == "1" || gtd == "4" || gtd == "6" || gtd == "7" || gtd == "A") {
								this.showHiddenDiv(document.getElementById("boleta.ruc.show"), true);
								this.showHiddenDiv(document.getElementById("boleta.razonSocial.show"), false);

								dijit.byId("boleta.numeroDocumento").setValue(dojo.byId("global.numeroDocumento").value);
								dijit.byId("boleta.razonSocial").setValue(dojo.byId("global.numeroDocumentoDesc").value);
							} else {
								this.showHiddenDiv(document.getElementById("boleta.ruc.show"), false);
								this.showHiddenDiv(document.getElementById("boleta.razonSocial.show"), true);

								dijit.byId("boleta.exportacion.razonSocial").setValue(dojo.byId("global.numeroDocumentoDesc").value);
							}

							if (dojo.byId("global.opcionExportacion").value == "1") {
								dijit.byId("boleta.chkExportacion").attr('checked', true);
							}

							if (dojo.byId("global.opcionOperacionesGratuitas").value == "1") {
								dijit.byId("boleta.chkOperGratuitas").attr('checked', true);
							}

							if (dojo.byId("global.opcionNodomic").value == "1") {
								dijit.byId("boleta.tipoDocumentoNoDomic").setValue(dojo.byId("global.tipoDocumentoNodomic").value);
								dijit.byId("boleta.numeroDocumentoNoDomic").setValue(dojo.byId("global.numeroDocumentonoDomic").value);
								dijit.byId("boleta.razonSocialNoDomic").setValue(dojo.byId("global.razonSocialNoDomic").value);
								this.showHiddenDiv(document.getElementById("boleta.ruc.show"), false);
								this.showHiddenDiv(document.getElementById("boleta.razonSocial.show"), false);
								this.showHiddenDiv(document.getElementById("boleta.docsNoDomic.show"), true);
							}

							if (dojo.byId("global.opcionExportacion").value == "1" || dojo.byId("global.opcionOperacionesGratuitas").value == "1") {
								this.showHiddenDiv(document.getElementById("boleta.situacionEspecial.show"), true);
							} else {
								this.showHiddenDiv(document.getElementById("boleta.situacionEspecial.show"), false);
							}
								
							dijit.byId("boleta.tipoMonedaDesc").setValue(dojo.byId("global.tipoMonedaDesc").value);

							/* Inicio PAS20201U210100285 - Giancarlo Nepo LÃ³pez */
							var moneda = dojo.byId("global.tipoMoneda").value;
							if (dojo.byId("boleta.totalMontoRedondeo") != null){ /* PAS20201U210100285 - Boleta Contingencia */
								document.getElementById("boleta.totalMontoRedondeo").style.textAlign = "right";
								dijit.byId("boleta.totalMontoRedondeo").constraints = {min:-0.09,max:0.09,currency:moneda, places: '2,2',pattern:"\u00A4 #,##0.00;\u00A4 -#,##0.00"};
								dijit.byId("boleta.totalMontoRedondeo").attr('value',0.00);
							}
							/* Fin PAS20201U210100285 - Giancarlo Nepo LÃ³pez */

							this.updateTotalAmount();
							this.loadUnidadMedida();
							//this.loadImpuestoBolsa();
							//PAS20191U210100075 - jsantivanez
							
							
							/*if (dojo.byId("global.opcionPagoAnticipado").value == "1") {
								
								dijit.byId("check.impuestoBolsasPlastica00").setAttribute('disabled', true);
								dijit.byId("check.impuestoBolsasPlastica01").setAttribute('disabled', true);
								dijit.byId("item.periodoBolsa").setAttribute('disabled', true);
								
							}*/
							//PAS20191U210100075 - jsantivanez
						});
						console.log("HGOLA4")
					this.content.setHref(this.controller + "?action=showIngresoBoleta&preventCache=" + this.preventCache());
				} else {
					mostrarMensaje(res.messageError);
					nbControl.attr('disabled', false);
				}
			}));

		handler.addErrback(function (res) {
			nbControl.attr('disabled', false);
			this.waitMessage.hide();
			mostrarMensaje("Problemas al conectarse con el servidor");
		});
	},

	validateRUCTercero : function () {

		var emisor = dojo.byId("global.numRucEmisor").value;
		var ndControl = dojo.byId("direccCliente.txt_ruc_tercero");

		var ndLength = dojo.trim(ndControl.value).length;
		if (ndLength != 11) {
			return;
		}
		if (ndLength == 0) {
			mostrarMensaje("Tiene que ingresar un número de RUC.");
			ndControl.attr('value', "");
			ndControl.focus();
			return;
		}

		if (dojo.trim(ndControl.value) == emisor) {
			mostrarMensaje("No debe ingresar su propio n\u00FAmero de RUC como el de un tercero.");
			ndControl.attr('value', "");
			ndControl.focus();
			return;
		}

		if (!this.isValidRuc(dojo.trim(ndControl.value))) {
			mostrarMensaje("N\u00FAmero de RUC inv\u00E1lido.");
			ndControl.attr('value', "");
			ndControl.focus();
			return;
		}

		var handler = dojo.xhrGet({
				preventCache : false,
				url : this.controller + "?action=buscarEstabTercero&rucTercero=" + dojo.trim(ndControl.value),
				handleAs : "json",
				sync : true,
				timeout : 10000
			});
		handler.addCallback(dojo.hitch(this, function (res) {
				if (res.codeError == 0) {
					var newStore = new dojo.data.ItemFileWriteStore({
							url : 'emitir.do?action=getDomicilios'
						});
					var grid = dijit.byId("direccCliente.domiciliosGrid");
					grid.setStore(null);
					grid.setStore(newStore);
					this.showHiddenDiv(document.getElementById("direccCliente.div_domin_terc"), true);
				} else {
					mostrarMensaje(res.messageError);
				}
			}));
		handler.addErrback(function (res) {
			mostrarMensaje("Ocurrio un error al obtener los domicilios del tercero: " + res.message);
		});
	},

	validateRUCTerceroPP : function () {

		var emisor = dojo.byId("global.numRucEmisor").value;
		var ndControl = dojo.byId("puntoPartida.txt_ruc_tercero");

		var ndLength = dojo.trim(ndControl.value).length;
		if (ndLength != 11) {
			return;
		}
		if (ndLength == 0) {
			mostrarMensaje("Tiene que ingresar un número de RUC.");
			ndControl.attr('value', "");
			ndControl.focus();
			return;
		}

		if (dojo.trim(ndControl.value) == emisor) {
			mostrarMensaje("No debe ingresar su propio n\u00FAmero de RUC como el de un tercero.");
			ndControl.attr('value', "");
			ndControl.focus();
			return;
		}

		if (!self.isValidRuc(dojo.trim(ndControl.value))) {
			mostrarMensaje("N\u00FAmero de RUC inv\u00E1lido.");
			ndControl.attr('value', "");
			ndControl.focus();
			return;
		}

		var handler = dojo.xhrGet({
				preventCache : false,
				url : self.controller + "?action=buscarEstabTercero&rucTercero=" + dojo.trim(ndControl.value),
				handleAs : "json",
				sync : true,
				timeout : 10000
			});
		handler.addCallback(dojo.hitch(self, function (res) {
				if (res.codeError == 0) {

					var newStore = new dojo.data.ItemFileWriteStore({
							url : 'emitir.do?action=getDomicilios'
						});
					var grid = dijit.byId("puntoPartida.domiciliosGrid");
					grid.setStore(newStore);

					self.showHiddenDiv(document.getElementById("puntoPartida.div_domin_terc"), true);
				} else {

					mostrarMensaje(res.messageError);

				}
			}));
		handler.addErrback(function (res) {

			mostrarMensaje("Ocurrio un error al obtener los domicilios del tercero: " + res.message);
		});

	},

	validateRUCTerceroPLL : function () {

		var emisor = dojo.byId("global.numRucEmisor").value;
		var ndControl = dojo.byId("puntoLlegada.txt_ruc_tercero");

		var ndLength = dojo.trim(ndControl.value).length;
		if (ndLength != 11) {
			return;
		}
		if (ndLength == 0) {
			mostrarMensaje("Tiene que ingresar un número de RUC.");
			ndControl.attr('value', "");
			ndControl.focus();
			return;
		}

		if (dojo.trim(ndControl.value) == emisor) {
			mostrarMensaje("No debe ingresar su propio n\u00FAmero de RUC como el de un tercero.");
			ndControl.attr('value', "");
			ndControl.focus();
			return;
		}

		if (!self.isValidRuc(dojo.trim(ndControl.value))) {
			mostrarMensaje("N\u00FAmero de RUC inv\u00E1lido.");
			ndControl.attr('value', "");
			ndControl.focus();
			return;
		}

		var handler = dojo.xhrGet({
				preventCache : false,
				url : self.controller + "?action=buscarEstabTercero&rucTercero=" + dojo.trim(ndControl.value),
				handleAs : "json",
				sync : true,
				timeout : 10000
			});
		handler.addCallback(dojo.hitch(self, function (res) {
				if (res.codeError == 0) {

					var newStore = new dojo.data.ItemFileWriteStore({
							url : 'emitir.do?action=getDomicilios'
						});
					var grid = dijit.byId("puntoLlegada.domiciliosGrid");
					grid.setStore(newStore);

					self.showHiddenDiv(document.getElementById("puntoLlegada.div_domin_terc"), true);
				} else {

					mostrarMensaje(res.messageError);

				}
			}));
		handler.addErrback(function (res) {

			mostrarMensaje("Ocurrio un error al obtener los domicilios del tercero: " + res.message);
		});

	},

	loadUnidadMedida : function () {
		var handler = dojo.xhrGet({
				preventCache : false,
				url : this.controller + "?action=loadUnidadMedida",
				handleAs : "json",
				sync : true,
				timeout : 10000
			});
		handler.addCallback(dojo.hitch(this, function (res) {
				//this.waitMessage.hide();
				this.unidadMedidaStore = null;
				var data = null;
				var values = [];
				if (res.codeError == 0) {
					if (res.data.length > 0 && res.data != "[]") {
						data = eval("(" + res.data + ")");
						values.push({
							name : "",
							abbreviation : "000"
						});
						for (var x = 0; x < data.length; x++) {
							//mostrarMensaje(data[x].unidadMedida + " - " + data[x].descripcionMedida);
							values.push({
								name : data[x].descripcionMedida,
								abbreviation : data[x].unidadMedida
							});
						}
					} else {
						this.unidadMedidaStore = null;
					}
				} else {
					this.iconTooltipMessage(nodeButton, "icon-error-tooltip", res.messageError);
				}
				var dataItems = {
					identifier : 'abbreviation',
					items : values,
					handleAs : "json",
					preventCache : true
				};
				var store = new dojo.store.Memory({
						data : dataItems
					});
				dijit.byId("item.unidadMedida").store = store;
			}));

		handler.addErrback(function (res) {
			//this.waitMessage.hide();
			this.messageBox("Problemas al conectarse con el servidor");
		});
	},

	//INI: PAS20191U210100075 jsantivanez
	loadImpuestoBolsa: function() {
	  

		var parts = dojo.byId("boleta.fechaEmision").value.split('/');		

		var fechaEmision = new Date(parts[2],parts[1]-1,parts[0]);
		
		//fecha properties
		var parts2 = dojo.byId("item.FechaProperties").value.split('/');
		var fechaproperties = new Date(parts2[2],parts2[1]-1,parts2[0]);
		
		console.log(dojo.byId("boleta.fechaEmision").value);
		console.log(dojo.byId("item.FechaProperties").value);

		
		if(fechaEmision < fechaproperties){
			
			mostrarMensaje("ICBPER es invalido en comprobantes inferiores a la fecha " + dojo.byId("item.FechaProperties").value);
			
			return false;
			
		}else{

			var moneda = dojo.byId("global.tipoMoneda").value;
			var handler = dojo.xhrGet({
				preventCache:  false,
				url: this.controller + "?action=loadImpuestoBolsa",
				handleAs: "json",
				sync: true,
				timeout: 10000
			});
			
			handler.addCallback(dojo.hitch(this, function(res){
				//this.waitMessage.hide();
				this.unidadMedidaStore = null;
				var data = null;
				var values = [];
			var values2 = [];
				if(res.codeError == 0) {
					if(res.data.length > 0 && res.data != "[]") {
						data = eval("(" + res.data + ")");
						values.push({name:"", abbreviation:"000"});              
						for (var x = 0 ; x < data.length ; x++) {     

							
							if (data[x].periodoTributo==fechaEmision.getFullYear() || (data[x].periodoTributo==fechaEmision.getFullYear() -1 && fechaEmision.getMonth() == 0)){
								values.push({name:data[x].periodoTributo, abbreviation:data[x].tasaTributo});
							  //mostrarMensaje(data[x].periodoTributo + " - " + data[x].tasaTributo);	  
							}else if (fechaEmision.getFullYear() > 2023){
								
								/*if(fechaEmision.getMonth() == 0){
									
									values.push({name:(fechaEmision.getFullYear() - 1).toString() , abbreviation:"0.50"} );
								}*/
								
								values.push({name:fechaEmision.getFullYear().toString(), abbreviation:"0.50"} );
								break;
							}
							
						}								
					}else {
						 this.unidadMedidaStore = null;
					}
				} else {
					this.iconTooltipMessage(nodeButton, "icon-error-tooltip", res.messageError);
				}

				var dataItems = { identifier: 'abbreviation', items: values, handleAs: "json" ,preventCache: true};
				

				var store = new dojo.store.Memory({data:dataItems});     
				
				

				dijit.byId("item.periodoBolsa").store = store; 
			  

				var selectperiodoBolsa = dijit.byId('item.periodoBolsa');



				
				/*selectperiodoBolsa.on('change', function(evt) {		
					console.log("tasa bolsaaaaa" + evt);
					dijit.byId("item.tasaBolsa").attr('value',dojo.currency.format(evt, {currency: moneda, places: 2}));
					//dijit.byId("item.tasaBolsa").setValue(evt);  
					document.getElementById("item.tasaBolsaGlobal").value = evt;	
					document.getElementById("item.PeriodoBolsaGlobal").value = dijit.byId("item.periodoBolsa").get('displayedValue');
				});*/
				
				var anio = fechaEmision.getFullYear();
				if (anio > 2023){
					anio = "2023";
				}
				//dijit.byId("item.periodoBolsa").set("displayedValue", anio.toString());	  
				
			}));
			
			handler.addErrback(function(res){
				//this.waitMessage.hide();
				this.messageBox("Problemas al conectarse con el servidor");
			});

			return true;
		}
	},
	selectperiodoBolsaChange: function(evt) {
		
		console.log("tasa bolsaaaaa1 " + evt);
		if(evt == "000"){
			
			console.log(dojo.byId("item.PeriodoBolsaGlobal").value);
			
			dijit.byId("item.periodoBolsa").set("displayedValue", dojo.byId("item.PeriodoBolsaGlobal").value);
			
		}else{
			
		var moneda = dojo.byId("global.tipoMoneda").value;
		var evt = dijit.byId('item.periodoBolsa').getValue();
		console.log("tasa bolsaaaaa2 " + evt);
		
		dijit.byId("item.tasaBolsa").attr('value',dojo.currency.format(evt, {currency: moneda, places: 2}));
		//dijit.byId("item.tasaBolsa").setValue(evt);  
		document.getElementById("item.tasaBolsaGlobal").value = evt;	
		document.getElementById("item.PeriodoBolsaGlobal").value = dijit.byId("item.periodoBolsa").get('displayedValue');
		this.updateItemAmount();
		
		}	
	},

	esNrus: function() {
		
		var handler = dojo.xhrGet({
			preventCache:  false,
			url: this.controller + "?action=validadNRus",
			handleAs: "json",
			sync: true,
			timeout: 10000
		});
		
		handler.addCallback(dojo.hitch(this, function(res){
			//this.waitMessage.hide();
			this.unidadMedidaStore = null;
			var data = null;
			var values = [];
			var values2 = [];
			if(res.codeError == 0) {
					if(res.data.length > 0 && res.data != "[]") {
					data = eval("(" + res.data + ")");
					console.log(data);    
					for (var x = 0 ; x < data.length ; x++) {     
						
						console.log(data[x].fechavalida);
						console.log(data[x].indice);
						
						if (data[x].fechavalida==true){
				
							if (data[x].indice==0){
								
								//No es NRUS
								//return false;
								this.nrus = false;
								
							}else{
								//Es NRUS
								//return true;
								this.nrus = true;
							}
						   
						}else {
							//ocultar
							//return true;
							this.nrus = true;
						}
						
					}								
					}else {
						 this.unidadMedidaStore = null;
					}
			} else {
				this.iconTooltipMessage(nodeButton, "icon-error-tooltip", res.messageError);
			}
			
		}));
		
		handler.addErrback(function(res){
			//this.waitMessage.hide();
			this.messageBox("Problemas al conectarse con el servidor");
		});
		
	},
	//FIN: PAS20191U210100075

	resetValIGV : function () {
		var moneda = dojo.byId("global.tipoMoneda").value;

		dijit.byId("item.precioConIGV").constraints = {
			currency : moneda,
			places : 2
		};
		dijit.byId("item.precioConIGV").setValue(0, false);
		this.updateItemAmount();
	},

	iconDel : function (rowindex) {
		return "<a href=\"#\" title=\"Eliminar\" onclick=\"boleta.deleteItem('" + rowindex + "')\"><img class=\"icon-by-del16\" src=\"/a/imagenes/s.gif\"/></a>";
	},

	iconEdit : function (rowindex) {
		return "<a href=\"#\" title=\"Editar\" onclick=\"boleta.editItem(" + rowindex + ")\"><img class=\"icon-by-edit16\" src=\"/a/imagenes/s.gif\"/></a>";
	},

	iconDelDocRel : function (rowindex) {
		return "<a href=\"#\" title=\"Eliminar\" onclick=\"boleta.delOtherDocument(" + rowindex + ")\"><img class=\"icon-by-del16\" src=\"/a/imagenes/s.gif\"/></a>";
	},

	valorUnitario : function (valor, rowindex) {
		var valor2 = valor.replace(',', '');

		if (valor2 < 0) {
			return "";
		} else {
			return valor;
		}

	},

	showEmisorEstaVent : function () {
		this.showHiddenDiv(document.getElementById("estabEmisor.div_domiciliosGrid"), true);

		var newStore = new dojo.data.ItemFileWriteStore({
				url : 'emitir.do?action=getDomiciliosEmisor'
			});
		var grid = dijit.byId("estabEmisor.domiciliosGrid");
		grid.setStore(null);
		grid.setStore(newStore);
	},

	showEmisorItinerante : function () {
		this.showHiddenDiv(document.getElementById("estabEmisor.div_domiciliosGrid"), false);
	},

	showEstablecimientoEmisor : function () {
		this.dialogEstablecimientoEmisor.show();
		/*
		if (dojo.byId("global.opcionEstablecimientoEmisorIdentifica").value == "") {
			dijit.byId("estabEmisor.idEstab01").setChecked("checked");
			this.showEmisorEstaVent();
		}
		*/
		
		// PAS20201U210100151
		var varValorIdEstabEmisor = this.getValorOpcionIdEstabEmisor();
		if (varValorIdEstabEmisor == null || varValorIdEstabEmisor == "" || dojo.byId("global.opcionEstablecimientoEmisorIdentifica").value == "") {
			dijit.byId("estabEmisor.idEstab01").setChecked("checked");
			this.showEmisorEstaVent();
		}
		
	},

	showEstabProp : function () {
		var newStore = new dojo.data.ItemFileWriteStore({
				url : 'emitir.do?action=getDomiciliosCliente'
			});
		var grid = dijit.byId("direccCliente.domiciliosGrid");
		grid.setStore(null);
		grid.setStore(newStore);

		this.showHiddenDiv(document.getElementById("direccCliente.div_establecimiento"), true);
		this.showHiddenDiv(document.getElementById("direccCliente.div_domin_terc"), true);
		this.showHiddenDiv(document.getElementById("direccCliente.div_otro_local"), false);
		this.showHiddenDiv(document.getElementById("direccCliente.div_ruc_tercero"), false);
		dojo.byId("direccCliente.txt_ruc_tercero").value = "";
		dojo.byId("direccCliente.subTipoEdireccCliente").value = "1";
	},

	showEstabTerc : function () {
		this.showHiddenDiv(document.getElementById("direccCliente.div_domin_terc"), false);
		this.showHiddenDiv(document.getElementById("direccCliente.div_establecimiento"), true);
		this.showHiddenDiv(document.getElementById("direccCliente.div_ruc_tercero"), true);
		this.showHiddenDiv(document.getElementById("direccCliente.div_otro_local"), false);
		dojo.byId("direccCliente.subTipoEdireccCliente").value = "2";
	},

	showEstabOtro : function () {
		this.showHiddenDiv(document.getElementById('direccCliente.div_establecimiento'), false);
		this.showHiddenDiv(document.getElementById('direccCliente.div_ruc_tercero'), false);
		document.getElementById('direccCliente.div_otro_local').style.display = "block";
		document.getElementById('direccCliente.txt_ruc_tercero').value = "";
		dojo.byId("direccCliente.subTipoEdireccCliente").value = "3";
	},

	showDireccionCliente : function () {
		this.dialogDireccionCliente.show();

    //<!-- PAS20211U210700185 -->
    /*
		if (dojo.byId("global.opcionDomicilioClienteIdentifica").value == "") {
    */
      if (dojo.byId("global.opcionDomicilioClienteIdentifica").value == ""||dojo.byId("global.opcionDomicilioClienteIdentifica").value != "") {
    //<!-- PAS20211U210700185 -->
			if (dojo.byId("global.tipoDocumento").value == "6") {
				this.showHiddenDiv(document.getElementById("direccCliente.div_propioCliente.show"), true);
				dijit.byId("direccCliente.subTipoEdireccCliente01").setChecked("checked");
				this.showEstabProp();
			} else {
				this.showHiddenDiv(document.getElementById("direccCliente.div_propioCliente.show"), false);
				dijit.byId("direccCliente.subTipoEdireccCliente02").setChecked("checked");
				this.showEstabTerc();
			}
		}
	},
	
	///INICIO: DAG PAS20221U210700299
	estaPadronGeneric: function() {
        const data = JSON.parse(localStorage.getItem('data'));
        if(data != null){
            if (data.codeError == 0 ) {
                if( data.data =='0' ){
                    mostrarMensaje("El contribuyente no se encontraría comprendido en los requisitos de la Ley N° 31556",tipo = 1);
                  }
              }
        }else{
            this.buscarPadronGeneric();
        }
    },
	
	buscarPadronGeneric: function() {
		var info="";
		var fechaEmision = dojo.date.locale.format(dijit.byId("boleta.fechaEmision").getValue(), {datePattern: "yyyyMMdd", selector: "date"});
		console.log("fecha jbm--> " + fechaEmision.substring(0,6));
		
		var handler = dojo.xhrGet({
			preventCache:  false,
			url: this.controller + "?action=validaPadronGeneric&periodo="+ dojo.trim(fechaEmision.substring(0,6))+"&info="+info,
			handleAs: "json",
			sync: true,
			timeout: 10000
		});
		console.log("fecha jbm--> " + handler);
		
		handler.addCallback(dojo.hitch(this, function(res){
			localStorage.setItem('data', JSON.stringify(res));
			if (res.codeError == 0 ) {
				
				if( res.data =='0' ){
	  		
	  			mostrarMensaje("El contribuyente no se encontraría comprendido en los requisitos de la Ley N° 31556");
				}
	  		}
	
			
	  	}));
	
		handler.addErrback(function(response){
			//this.waitMessage.hide();
			this.messageBox("Problemas al conectarse con el servidor");
		});
	},	
   //FIN: DAG PAS20221U210700299

	showEstabPropPP : function () {
		var newStore = new dojo.data.ItemFileWriteStore({
				url : 'emitir.do?action=getDomiciliosEmisor'
			});
		var grid = dijit.byId("puntoPartida.domiciliosGrid");
		grid.setStore(newStore);

		this.showHiddenDiv(document.getElementById("puntoPartida.div_establecimiento"), true);
		this.showHiddenDiv(document.getElementById("puntoPartida.div_domin_terc"), true);
		this.showHiddenDiv(document.getElementById("puntoPartida.div_otro_local"), false);
		this.showHiddenDiv(document.getElementById("puntoPartida.div_ruc_tercero"), false);
		dojo.byId("puntoPartida.txt_ruc_tercero").value = "";
	},

	showEstabTercPP : function () {
		this.showHiddenDiv(document.getElementById("puntoPartida.div_domin_terc"), false);
		this.showHiddenDiv(document.getElementById("puntoPartida.div_establecimiento"), true);

		this.showHiddenDiv(document.getElementById("puntoPartida.div_ruc_tercero"), true);
		this.showHiddenDiv(document.getElementById("puntoPartida.div_otro_local"), false);
	},

	showEstabOtroPP : function () {
		this.showHiddenDiv(document.getElementById('puntoPartida.div_establecimiento'), false);
		this.showHiddenDiv(document.getElementById('puntoPartida.div_ruc_tercero'), false);
		document.getElementById('puntoPartida.div_otro_local').style.display = "block";
		document.getElementById('puntoPartida.txt_ruc_tercero').value = "";
	},

	showEstabPropPLL : function () {
		var newStore = new dojo.data.ItemFileWriteStore({
				url : 'emitir.do?action=getDomiciliosEmisor'
			});
		var grid = dijit.byId("puntoLlegada.domiciliosGrid");
		grid.setStore(newStore);

		this.showHiddenDiv(document.getElementById("puntoLlegada.div_establecimiento"), true);
		this.showHiddenDiv(document.getElementById("puntoLlegada.div_domin_terc"), true);
		this.showHiddenDiv(document.getElementById("puntoLlegada.div_otro_local"), false);
		this.showHiddenDiv(document.getElementById("puntoLlegada.div_ruc_tercero"), false);
		dojo.byId("puntoLlegada.txt_ruc_tercero").value = "";
	},

	showEstabTercPLL : function () {
		this.showHiddenDiv(document.getElementById("puntoLlegada.div_domin_terc"), false);
		this.showHiddenDiv(document.getElementById("puntoLlegada.div_establecimiento"), true);

		this.showHiddenDiv(document.getElementById("puntoLlegada.div_ruc_tercero"), true);
		this.showHiddenDiv(document.getElementById("puntoLlegada.div_otro_local"), false);
	},

	showEstabOtroPLL : function () {
		this.showHiddenDiv(document.getElementById('puntoLlegada.div_establecimiento'), false);
		this.showHiddenDiv(document.getElementById('puntoLlegada.div_ruc_tercero'), false);
		document.getElementById('puntoLlegada.div_otro_local').style.display = "block";
		document.getElementById('puntoLlegada.txt_ruc_tercero').value = "";
	},

	daraltaadomicilio : function (coddist, tipodomic, tipvia, nomvia, tipzon, nomzon, local, km, mz, lote, dep, int) {
		//mostrarMensaje("tipodomic="+tipodomic+" tipvia="+tipvia+" nomvia="+nomvia+" tipzon="+tipzon+" nomzon="+nomzon+" local="+local);
		var seguir = 0;
		var cod_tipodomic;
		var cod_local;

		if (tipodomic != undefined) {
			cod_tipodomic = valorradiobutton(tipodomic);

			//mostrarMensaje("cod_tipodomic="+cod_tipodomic);

			if (cod_tipodomic == 1 || cod_tipodomic == 2) {
				if (local != null) {
					cod_local = valorradiobutton(local);

					//mostrarMensaje("cod_local="+cod_local);

					if (cod_local == -1)
						mostrarMensaje("Debe escoger un local de la lista.");
					else {
						document.formaltadomicilio.accion.value = "DaAltaADomicilioAdicional2";
						seguir = 1;
					}
				} else
					mostrarMensaje("No hay ning\u00FAn local seleccionado. Realice una b\u00FAsqueda por RUC de un tercero si desea usar esta opci\u00F3n.");
			} else if (cod_tipodomic == 3) {
				if (coddist.value.length < 6)
					mostrarMensaje("Debe seleccionar departamento, provincia y distrito.");
				else if (trim(nomvia.value) == "" && trim(nomzon.value) == "")
					mostrarMensaje("Debe ingresar al menos uno de los campos marcados con asterisco (*).");
				else if (trim(nomvia.value) != "" && tipvia.selectedIndex == 11)
					mostrarMensaje("Debe ingresar el tipo de via.");
				else if (trim(nomzon.value) != "" && tipzon.selectedIndex == 11)
					mostrarMensaje("Debe ingresar al tipo de zona.");
				else if (km.value == "" && mz.value == "" && lote.value == "" && dep.value == "" && int.value == "")
					mostrarMensaje("Debe ingresar al menos el kil\u00F3metro, manzana, lote, departamento o interior.");
				else {
					document.formaltadomicilio.accion.value = "DaAltaADomicilioAdicional2";
					seguir = 1;
				}
			} else
				mostrarMensaje("Debe primero registrar un local, para ello seleccione una de las opciones.");
		}

		if (seguir == 1) {
			document.formaltadomicilio.btn_aceptar.disabled = true;
			document.formaltadomicilio.submit();
		}
	},

	limpiar : function (tipodomic) {
		var valtipodomic = valorradiobutton(tipodomic);

		if (valtipodomic == "2") {
			document.formaltadomicilio.numruc3.value = "";
		} else if (valtipodomic == "3") {
			document.formaltadomicilio.dpto.selectedIndex = 0;
			document.formaltadomicilio.prov.selectedIndex = 0;
			document.formaltadomicilio.dist.selectedIndex = 0;
			document.formaltadomicilio.coddpto.value = "";
			document.formaltadomicilio.codprov.value = "";
			document.formaltadomicilio.coddist.value = "";
			document.formaltadomicilio.tipvia.selectedIndex = 11;
			document.formaltadomicilio.nomvia.value = "";
			document.formaltadomicilio.num.value = "";
			document.formaltadomicilio.lote.value = "";
			document.formaltadomicilio.km.value = "";
			document.formaltadomicilio.dep.value = "";
			document.formaltadomicilio.mz.value = "";
			document.formaltadomicilio.int.value = "";
			document.formaltadomicilio.tipzon.selectedIndex = 11;
			document.formaltadomicilio.nomzon.value = "";
			document.formaltadomicilio.refer.value = "";
		}
	},

	//funciones para eventos
	startup : function () {
		dojo.parser.parse(dojo.byId('container'));
		setTimeout(dojo.hitch(this, function () {
				this.initialize();
			}), 250);

	},

	preventCache : function () {
		return new Date().valueOf();
	},

	wait : function (message, width) {
		dojo.byId("waitMessage").innerHTML = "<div class='dijitInline box-message'></div><div class='dijitInline'>&nbsp;" + message + "...</div>";
		dojo.byId("waitMessage").style.width = width;
		this.waitMessage.show();
	},

	iconTooltipMessage : function (node, iconClass, message) {
		if (dojo.isString(node))
			node = dojo.byId(node);
		dijit.focus(node);
		node.focus();
		dijit.showTooltip('<div class="' + iconClass + '"><div>' + message + '</div></div>', node, []);
		var blur = dojo.connect(node, "onblur", function () {
				dijit.hideTooltip(node);
				dojo.disconnect(blur);
			});
	},

	warnTooltipMessage : function (node, message) {
		this.iconTooltipMessage(node, "icon-warn-tooltip", message);
	},

	roundNumber : function (number, digits) {
		var multiple = Math.pow(10, digits);
		var rndedNum = Math.round(number * multiple) / multiple;

		return rndedNum;
	},
	round : function(num, decimals) {
		var n = Math.pow(10, decimals);
		return Math.round( (n * num).toFixed(decimals) )  / n;
	}, 		


	formatSelUbigeoEmisor : function (value, rowindex) {
		var valEstablecimientoEmisorSeleccionado = dojo.byId("global.opcionEstablecimientoEmisorSeleccionado").value;
		if (valEstablecimientoEmisorSeleccionado != null &&
			valEstablecimientoEmisorSeleccionado != "" &&
			valEstablecimientoEmisorSeleccionado == rowindex) {
			return "<input id='estabEmisor.selDomicilioGrid" + rowindex + "' name='estabEmisor.selDomicilioGrid'  dojoType='dijit.form.RadioButton' type='radio' value='" + rowindex + "' checked ='checked' />"
		} else {
			//PAS20201U210100151
			if(rowindex==0){
				return "<input id='estabEmisor.selDomicilioGrid" + rowindex + "' name='estabEmisor.selDomicilioGrid'  dojoType='dijit.form.RadioButton' type='radio' value='" + rowindex + "' checked ='checked' />"
				// "<a href=\"#\" onclick=\"descargaRVIPortal.descargarZip('" + rowindex +  "')\"> <img src=\"/a/imagenes/see/icons/download_16p.gif\" /></a>"
			}else{
				return "<input id='estabEmisor.selDomicilioGrid" + rowindex + "' name='estabEmisor.selDomicilioGrid'  dojoType='dijit.form.RadioButton' type='radio' value='" + rowindex + "' />"
				// "<a href=\"#\" onclick=\"descargaRVIPortal.descargarZip('" + rowindex +  "')\"> <img src=\"/a/imagenes/see/icons/download_16p.gif\" /></a>"
			}
			//PAS20201U210100151
		}
	},

	formatSelUbigeoCliente : function (value, rowindex) {
		var valDomicilioClienteSeleccionado = dojo.byId("global.opcionDomicilioClienteSeleccionado").value;
		if (valDomicilioClienteSeleccionado != null &&
			valDomicilioClienteSeleccionado != "" &&
			valDomicilioClienteSeleccionado == rowindex) {
			return "<input id='direccCliente.selDomicilioGrid" + rowindex + "' name='direccCliente.selDomicilioGrid'  dojoType='dijit.form.RadioButton' type='radio' value='" + rowindex + "' checked ='checked' />"
			// "<a href=\"#\" onclick=\"descargaRVIPortal.descargarZip('" + rowindex +  "')\"> <img src=\"/a/imagenes/see/icons/download_16p.gif\" /></a>"
		} else {
			//PAS20201U210100151
			if(rowindex==0){
				
				return "<input id='direccCliente.selDomicilioGrid" + rowindex + "' name='direccCliente.selDomicilioGrid'  dojoType='dijit.form.RadioButton' type='radio' value='" + rowindex + "' checked ='checked' />"
				// "<a href=\"#\" onclick=\"descargaRVIPortal.descargarZip('" + rowindex +  "')\"> <img src=\"/a/imagenes/see/icons/download_16p.gif\" /></a>"
			}else{
				return "<input id='direccCliente.selDomicilioGrid" + rowindex + "' name='direccCliente.selDomicilioGrid'  dojoType='dijit.form.RadioButton' type='radio' value='" + rowindex + "' />"
				// "<a href=\"#\" onclick=\"descargaRVIPortal.descargarZip('" + rowindex +  "')\"> <img src=\"/a/imagenes/see/icons/download_16p.gif\" /></a>"
			}
			//PAS20201U210100151
		}
	},

	formatSelUbigeoPLL : function (value, rowindex) {
		return "<input id='puntoLlegada.selDomicilioGrid" + rowindex + "' name='puntoLlegada.selDomicilioGrid'  dojoType='dijit.form.RadioButton' type='radio' value='" + rowindex + "' />"
		// "<a href=\"#\" onclick=\"descargaRVIPortal.descargarZip('" + rowindex +  "')\"> <img src=\"/a/imagenes/see/icons/download_16p.gif\" /></a>"
	},

	formatSelUbigeoPP : function (value, rowindex) {
		return "<input id='puntoPartida.selDomicilioGrid" + rowindex + "' name='puntoPartida.selDomicilioGrid'  dojoType='dijit.form.RadioButton' type='radio' value='" + rowindex + "' />"
		// "<a href=\"#\" onclick=\"descargaRVIPortal.descargarZip('" + rowindex +  "')\"> <img src=\"/a/imagenes/see/icons/download_16p.gif\" /></a>"
	},

	clearddlb : function (q, m) {
		if (q != null) {
			//longitud = q.length
			//for (var x=0;x<=longitud;x++){
			//  q.options[0]=null
			//}


			//eval("dijit.byId('" + q + "').set(value,'')")
			eval("dijit.byId('" + q + "').set('displayedValue','')")

			var lista = eval("dijit.byId('" + q + "')");
			lista.store = null;
		}
	},

	O : function (desc, val) {
		this.desc = desc;
		this.val = val;
	},

	validaubigeo : function (ubigeo) {
		for (j = 0; j < k.length; j++) {
			if (ubigeo == this.k[j].val) {
				return true
			}
		}
		return false
	},
	noSort : function (index) {
		return false;
	},
	
	//PAS20221U210600125-Ini-Csantillan
	isQuitarCharacterSpecial: function() {

		dojo.require("dojox.string.sprintf");
		var descripcion = dojo.trim(dijit.byId("item.descripcion").getValue());
		var textofinal = "";
		var carac = "";
		if(descripcion.length >= 1) {

		var parts = descripcion.split("");
		    for(i=0; i < parts.length; i++) {
				carac= descripcion[i].split("");
				carac = carac.toString().toUpperCase();
				var arrch = ["☺","☻", "♥", "♦", "♣", "♠", "•", "◘","○","◙","♂","♀","♪","♫","☼","►","◄","↕","‼","¶","§","▬","↨","↑","↓","→","←","∟","↔","▲","▼","ֲ","","–"]
				var flag = 0
				for (var j = 0; j < arrch.length; j++) {
					var caray = arrch[j];
					if (carac == caray ){
						flag = 1
					}
				}
				if (flag==1){
					textofinal = textofinal + "";
				}
				else{
					textofinal = textofinal + carac;
				}
			}
			dijit.byId("item.descripcion").setValue(textofinal);
		}
	}
	//PAS20221U210600125-Fin-Csantillan
	
});
}
