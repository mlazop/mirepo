/**
 * ConsultarFacturaIT.js - JavaScript de la Conslta de Emision Electr&oacute;nica - Factura.
 * Author: Erick Cavalie
 * Fecha: 08-06-2010
 * ResponseBean : codeError; messageError; data;
 */
 
 
 //regExp="[F|E|f|e]{1}[A-Za-z0-9]{3}"   
 
if (!dojo._hasResource["servicio.registro.comppago.see.ConsultarFacturaITGEM"]) {
    dojo._hasResource["servicio.registro.comppago.see.ConsultarFacturaITGEM"] = true;
    dojo.provide("servicio.registro.comppago.see.ConsultarFacturaITGEM");
    
    dojo.require("dojo.data.ItemFileWriteStore");
    dojo.require("dojo.io.iframe");
    
	dojo.declare("servicio.registro.comppago.see.ConsultarFacturaITGEM", null, {
    	dataStore: null,  
		store: null,       
        controller: "consultar.do",
        
        constructor: function(){
        },		
    	      
        initialize: function(){
    		this.content = dijit.byId("content");    		
            this.waitMessage = dijit.byId("waitMessage");
        },
        
        startup: function(){
            dojo.parser.parse(dojo.byId('container'));
            setTimeout(dojo.hitch(this, function(){
                this.hideLoader();
            }), 250);
        },
        
        hideLoader: function(){
            this.initialize();
            var loader = dojo.byId('loader');
            var _this = this;
            dojo.fadeOut({
                node: loader,
                duration: 250,
                onEnd: function(){
                	dijit.byId('content').domNode.style.visibility = "visible";            	
                    loader.style.display = "none";
                }
            }).play();
        },
         
        initContent: function(){
            /*Nada al cargar el formulario*/
        	this.store = null;
        },  	
		
		
		check21:function(value, rowindex){			
			console.dir(">> check21 value= "+value);
	        if( value == "3" ) {return "Si";}			
			return "";
        },  	
		
		
    	validarPeriodo: function(){
    		var ndPeriodo = dijit.byId("criterio.periodo");
    		if(dojo.trim(ndPeriodo.getValue()).length == 0 || dojo.trim(ndPeriodo.getValue()).length < 6) {
				//this.messageBoxError("Tiene que ingresar un periodo valido con formato YYYYMM.");
    			alert("Tiene que ingresar un periodo valido con formato YYYYMM.");
    			
    			ndPeriodo.setValue("");
    			ndPeriodo.focus();    			
    			return false;
    		}
    	},
    	
    	realizarConsulta: function(){
			
    		//if(!dijit.byId("criterio.form").validate()) return false ;
			if(null!=document.formConsulta.buscarPor){
				if("porDoc" == document.formConsulta.buscarPor.value ){					
					var tipConsulta = dijit.byId('criterio.tipoConsulta') ; 
					if(tipConsulta=='11' || tipConsulta=='14' || tipConsulta=='16'){
						if(!dijit.byId("criterio.ruc").validate()||!dijit.byId("criterio.serie").validate()||!dijit.byId("criterio.numero").validate()){
							alert("Complete la informaci\u00F3n requerida para la consulta.");
							return false; 
						}
					}else{
						if(!dijit.byId("criterio.serie").validate()||!dijit.byId("criterio.numero").validate()){
							alert("Complete la informaci\u00F3n requerida para la consulta.");
							return false; 
						}
					}
					
				}				
			}
    		this.cargarValoresGlobales();
    		
    		this.wait("Consultando", "110px", 100);
    		
    		var handler = dojo.io.iframe.send({
    			url: this.controller,
    			handleAs: "json",
    			sync: true,
    			timeout: 10000,
    			preventCache: true,
    			form: "criterio.form"
    		});
    		
			handler.addCallback(dojo.hitch(this, function(res){
				this.waitMessage.hide();
				if(res.codeError == 0) {
					this.content.onLoad = dojo.hitch(this, function(){
						var data = eval("(" + res.data + ")");	
						this.dataStore	=  data ; 
						this.store = new dojo.data.ItemFileWriteStore({data: {identifier: 'id', items: data}});
						var context = this.getContext();
			    		//var periodo = dijit.byId(context + ".periodoDesc");
			    		//periodo.setValue(dojo.byId("global.periodoDesc").value)
			    		var grid = dijit.byId(context + ".facturasGrid");
						grid.setStore(this.store);
						grid.startup();
					});
					this.content.setHref(this.controller + "?action=mostrarListado&tipoConsulta=" + dojo.byId("global.tipoConsulta").value + "&preventCache=" + this.preventCache());					
				} else {
					//this.messageBoxError(res.messageError);
					alert(res.messageError);
				}
			}));
			handler.addErrback(dojo.hitch(this, function(res) {
    			this.waitMessage.hide();
				//this.messageBoxError("Ocurrio un error al momento de ejecutar la consulta.");
				alert("Ocurri\u00F3 un error al momento de ejecutar la consulta.");
			}));
    	}, 	
    	
    	imprimirListado: function(rowIndex){
    		window.open(this.controller + "?action=imprimirListado&periodoDesc=" + dojo.byId("global.periodoDesc").value + "&tipoConsulta=" + dojo.byId("global.tipoConsulta").value + "&preventCache=" + this.preventCache(), "imprimeListado" , "toolbar=0,location=0,directories=0,status=no,menubar=0,scrollbars=yes,resizable=yes,width=1000,height=580,titlebar=no");    		
    	},    	
    	
        descargar: function(rowIndex){
    		var context = this.getContext();
			
	        var row = dijit.byId(context + ".facturasGrid").getItem(rowIndex);
			
			dojo.byId("formArchivo.ruc").value = row.nroRucEmisor;
			dojo.byId("formArchivo.tipo").value = row.codFactura;
			dojo.byId("formArchivo.serie").value = row.nroSerie;
			dojo.byId("formArchivo.numero").value = row.nroFactura;
			dojo.byId("formArchivo.isGEM").value = "isGEM";

			dojo.byId("formArchivo").submit();			
    	},  	
    	
        view: function(rowIndex){
	        var row = dijit.byId(this.getContext() + ".facturasGrid").getItem(rowIndex);
			
			/*Inicio PAS20231U210600138*/
			/*window.open(this.controller + "?action=verImprimirFactura&ruc=" + row.nroRucEmisor + "&tipo=" + row.codFactura +"&serie=" + row.nroSerie + "&numero=" + row.nroFactura + "&isGEM=isGEM", "imprimeFactura", "toolbar=0,location=0,directories=0,status=no,menubar=0,scrollbars=yes,resizable=yes,width=1000,height=580,titlebar=no");*/
			console.log("datos: ",row);
			window.open(this.controller + "?action=verImprimirFactura&rowIndex=" + rowIndex, "imprimeFactura", "toolbar=0,location=0,directories=0,status=no,menubar=0,scrollbars=yes,resizable=yes,width=1000,height=580,titlebar=no");
			/*Fin PAS20231U210600138*/
    	},
    	
        messageBoxOKCancel: function(message, iconClass){
            var dialog = dijit.byId("dialogOkCancel");
            if (dialog) {
                dojo.byId("ok_cancelMessage").innerHTML = this.chunkString(message, 40);
                if (iconClass) {
                    dojo.addClass("ok_cancelIcon", iconClass);
                }
                else {
                    dojo.addClass("ok_cancelIcon", "icon-alert-info");
                }
                dijit.byId('dialogOkCancel').domNode.style.visibility = "visible";
                dialog.show();
            }
        },
        
    	cargarValoresGlobales: function() {
    		/*dojo.byId("global.periodo").value = dijit.byId("criterio.periodo").getValue();
    		dojo.byId("global.periodoDesc").value = 
    			dijit.byId("criterio.periodo").getValue().substring(4) + "/" + 
    			dijit.byId("criterio.periodo").getValue().substring(0,4);
    		*/
    		dojo.byId("global.tipoConsulta").value = dijit.byId("criterio.tipoConsulta").getValue();
    	
    	},
    	    	   	
    	linkView: function(rowindex) {	
			var contextos = [,,,,,,,,,,"emitido","recibido","rechazado","emitidoNC","recibidoNC","emitidoND","recibidoND","emitido",,,"emitidoNC",,"emitidoND"] ;			
			console.dir(">> global.tipoConsulta = "+dojo.byId("global.tipoConsulta").value);
			var context = contextos[dojo.byId("global.tipoConsulta").value];
			console.dir(">> Contexto :: "+context) ; 
			var row = dijit.byId( context + ".facturasGrid").getItem(rowindex);
			console.dir("indEstado = "+row.indEstado) ; 
			if(row.indEstado=="0" || row.indEstado=="2")
				return "<a href=\"#\" onclick=\"consultaFactura.view('" + rowindex +  "')\"> <img src=\"/a/imagenes/see/icons/viewdoc.gif\" /></a>" ; 
			else 
				return "" ;       		
    	},
    	
		getContext: function() {
    		var context = "emitido";
    		if (dojo.byId("global.tipoConsulta").value == 10) {
    			context = "emitido";
    		}
    		if (dojo.byId("global.tipoConsulta").value == 11) {
    			context = "recibido";
    		}
    		if (dojo.byId("global.tipoConsulta").value == 12) {
    			context = "rechazado";		    			
    		}
    		if (dojo.byId("global.tipoConsulta").value == 13 || dojo.byId("global.tipoConsulta").value == 20) {
    			context = "emitidoNC";
    		}
    		if (dojo.byId("global.tipoConsulta").value == 14) {
    			context = "recibidoNC";
    		}
    		if (dojo.byId("global.tipoConsulta").value == 15 || dojo.byId("global.tipoConsulta").value == 22) {
    			context = "emitidoND";
    		}
    		if (dojo.byId("global.tipoConsulta").value == 16) {
    			context = "recibidoND";
    		}
    		return context; 
    	},
		
        linkDescargar: function(rowindex) {
    		return "<a href=\"#\" onclick=\"consultaFactura.descargar('" + rowindex +  "')\"> <img src=\"/a/imagenes/see/icons/download_16p.gif\" />Descargar Factura (XML)</a>"
    	}, 	
    	linkDescargarNC: function(rowindex) {
    		return "<a href=\"#\" onclick=\"consultaFactura.descargar('" + rowindex +  "')\"> <img src=\"/a/imagenes/see/icons/download_16p.gif\" />Descargar NC (XML)</a>"
    	},  
		linkDescargarND: function(rowindex) {
    		return "<a href=\"#\" onclick=\"consultaFactura.descargar('" + rowindex +  "')\"> <img src=\"/a/imagenes/see/icons/download_16p.gif\" />Descargar ND (XML)</a>"
    	},
    	
    	mostrarDescripTipo: function(value, rowindex) {
  
        if( value == "21" ) {return "Anulaci&oacute;n de la Operaci&oacute;n";}
        if( value == "22" ) {return "Anulaci&oacute;n por Error en el RUC";}     
        if( value == "23" ) {return "Descuento Global";}
        if( value == "24" ) {return "Devoluci&oacute;n Total";}
        if( value == "25" ) {return "Correcci&oacute;n por Error en la Descripci&oacute;n";}
        if( value == "26" ) {return "Devoluci&oacute;n por Item";}
        if( value == "27" ) {return "Descuento por Item";}
        if( value == "41" ) {return "Intereses por Mora";}
        if( value == "42" ) {return "Aumento en el Valor";}
    	},
		
		
    	mostrarDescripTipoNC: function(value, rowindex) {
  
        if( value == "01") {return "Anulaci&oacute;n de la Operaci&oacute;n";}
        if( value == "02") {return "Anulaci&oacute;n por Error en el RUC";}     
        if( value == "03") {return "Correcci&oacute;n por Error en la Descripci&oacute;n";}		
        if( value == "04") {return "Descuento Global";}
        if( value == "05") {return "Descuento por Item";}		
        if( value == "06") {return "Devoluci&oacute;n Total";}
        if( value == "07") {return "Devoluci&oacute;n por Item";}
        if( value == "08") {return "Bonificaci&oacute;n";}
        if( value == "09") {return "Disminuci&oacute;n en el valor";}
        if( value == "10" ) {return "Otros Conceptos ";}
	    if( value == "11" ) {return "Otros Conceptos Por eventos posteriores al inicio del traslado de los bienes (aplicable para factura que sustenta traslado de bienes)";}
    	},
				
				
    	mostrarDescripTipoND: function(value, rowindex) {
  
        if( value == "01") {return "Intereses por mora";}
        if( value == "02") {return "Aumento en el valor";}     
        if( value == "03") {return "Penalidades/ otros conceptos ";}		
    	},				
		
    	   	
      	wait: function(message, width) {
    		dojo.byId("waitMessage").innerHTML="<div class='dijitInline box-message'></div><div class='dijitInline'>&nbsp;" + message + "...</div>";
    	    dojo.byId("waitMessage").style.width = width;
    	    this.waitMessage.show();
    	},
    	
    	messageBoxError: function(message, iconClass) {
    		var dialog = dijit.byId("dialogError");
    		if(dialog) {
    			dojo.byId("alertMessage").innerHTML=this.chunkString(message, 40);
    			if(iconClass) dojo.addClass("alertIcon", iconClass);
    			else dojo.addClass("alertIcon", "icon-alert-error");
    			dijit.byId('dialogError').domNode.style.visibility = "visible";

    			dialog.show();
    		}
    	},    	
    	
    	chunkString: function(cad, size) {
    		var aCad = cad.split(" ");
    		for(i = 0; i < aCad.length; i++) {
    			if(aCad[i].length > size) {
    				return this.wordWrap(cad, size, "<br/>", 2);
    			}
    		}
    		return cad;
    	},
    	
        mostrarFiltro: function(){
			var handler = dojo.xhrGet({
				preventCache:  false,
				url: this.controller + "?action=dataCriterios",
				handleAs: "json",
				sync: true,
				timeout: 10000
			});    		
    		
			handler.addCallback(dojo.hitch(this, function(res){
				this.waitMessage.hide();
				if(res.codeError == 0) {
					this.content.onLoad = dojo.hitch(this, function(){

					});
					this.content.setHref(this.controller + "?action=backCriterios&preventCache=" + this.preventCache());					
				} else {
					//this.messageBoxError(res.messageError);
					alert(res.messageError);
				}
			}));
			handler.addErrback(dojo.hitch(this, function(res) {
    			this.waitMessage.hide();
				//this.messageBoxError("Ocurrio un error al momento de ejecutar la consulta.");
				alert("Ocurri\u00F3 un error al momento de ejecutar la consulta.");
			}));    		
        },
  
        salirConsulta: function(){
            //this.messageBoxOKCancel("Desea salir de la Aplicacion?.", "icon-alert-info");
        	if (confirm("\xbf Desea salir de la Aplicaci\xf3n?.")) {
        		this.cerrarConsulta();
        	}
        },
        
        salirListado: function(){
            //this.messageBoxOKCancel("Desea salir del listado de Facturas?.", "icon-alert-info");
        	if (confirm("\xbf Desea salir del listado ?.")) {
        		this.cerrarConsulta();
        	}
        },        
        
        cerrarConsulta: function(){
            dijit.byId('dialogOkCancel').hide();
            this.mostrarFiltro();
         },
         
     	preventCache: function() {
     		return new Date().valueOf();
     	},
		
    	
		// JCZ julio-2011
		showRucEmisor: function() {			
			var tipConsulta = dijit.byId('criterio.tipoConsulta') ; 			
			var trRucEm = document.getElementById("divRucEm");
			
			var fila = document.getElementById("filareceptor");
			
			
			if(trRucEm!=null && ( tipConsulta=='11' || tipConsulta=='14' || tipConsulta=='16'  ) ){				
				document.getElementById("divRucEm").style.display = 'block' ;
				document.getElementById("divSep").style.display = 'block' ;
				document.getElementById("divInput").style.display = 'block' ;				
				 fila.style.display = "none"; //ocultar fila 
				
				
			 }else{								
				document.getElementById("divRucEm").style.display = 'none' ;
				document.getElementById("divSep").style.display = 'none' ;
				document.getElementById("divInput").style.display = 'none' ;
				
				fila.style.display = ""; //mostrar fila 
			 }			
			 
			 
			 
			 
			 
			var ndControl = dijit.byId("criterio.serie");			
			if(tipConsulta=='10' || tipConsulta=='11' || tipConsulta=='13' || tipConsulta=='14' || tipConsulta=='15' || tipConsulta=='16'){				
				ndControl.attr('regExp','[F|f]{1}[A-Za-z0-9]{3}');			
				ndControl.attr('invalidMessage','Ingrese un n&uacute;mero de serie correcto para el comprobante seleccionado, Ejemplo: FA01.');			

			}else{
 				if(tipConsulta=='17' || tipConsulta=='20' || tipConsulta=='22'){					
					ndControl.attr('regExp','[B|b]{1}[A-Za-z0-9]{3}');				
					ndControl.attr('invalidMessage','Ingrese un n&uacute;mero de serie correcto para el comprobante seleccionado, Ejemplo: BA01.');								
				}
			}			 
			 
    	},
		
    	noSort: function(index){ 
    		 return false;
    	}    
    });
}
