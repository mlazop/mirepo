/**
 * ConsultarFacturaIA.js - JavaScript de la Conslta de Emision Electr�nica - Factura.
 * Author: Erick Cavalie
 * Fecha: 08-06-2010
 * ResponseBean : codeError; messageError; data;
 */
if (!dojo._hasResource["servicio.registro.comppago.see.ConsultarFacturaIA"]) {
    dojo._hasResource["servicio.registro.comppago.see.ConsultarFacturaIA"] = true;
    dojo.provide("servicio.registro.comppago.see.ConsultarFacturaIA");
    
    dojo.require("dojo.data.ItemFileWriteStore");
    dojo.require("dojo.io.iframe");
    
    dojo.declare("servicio.registro.comppago.see.ConsultarFacturaIA", null, {
    	store: null,       
        controller: "consultar.do",
        
        constructor: function(){
        },
        
        initialize: function(){
    		this.content = dijit.byId("content");    		
            this.waitMessage = dijit.byId("waitMessage");
            
            var size = dojo.marginBox(this.content.domNode);
            x = Math.floor((size.w - 102) / 2);
            y = Math.floor((size.h - 34) / 2);
            this.content.loadingMessage = 
            	'<div class="ext-el-mask"></div>' +
            	'<div class="ext-el-mask-msg x-mask-loading" style="left: ' + x + 'px; top: ' + y + 'px;"><div>Cargando...</div></div>';
        },
		
		restaFechas : function(f1,f2)
		{
			var aFecha1 = f1.split('/'); 
			var aFecha2 = f2.split('/'); 
			var fFecha1 = Date.UTC(aFecha1[2],aFecha1[1]-1,aFecha1[0]); 
			var fFecha2 = Date.UTC(aFecha2[2],aFecha2[1]-1,aFecha2[0]); 
			var dif = fFecha2 - fFecha1;
			var dias = Math.floor(dif / (1000 * 60 * 60 * 24)); 
			return dias;
		},
        
        startup: function(){
            dojo.parser.parse(dojo.byId('container'));
            setTimeout(dojo.hitch(this, function(){
                this.hideLoader();
            }), 250);
        },
        
        hideLoader: function(){
            this.initialize();
            var loader = dojo.byId('loader');
            var _this = this;
            dojo.fadeOut({
                node: loader,
                duration: 250,
                onEnd: function(){
                    dijit.byId('main').domNode.style.visibility = "visible";
                    loader.style.display = "none";
                }
            }).play();
        },
         
        initContent: function(){
            /*Nada al cargar el formulario*/
        	this.store = null;
        },
 
     	
		check21: function(rowindex) {
			if (rowindex == "1") {
				return "<img src=\"/a/imagenes/see/icons/icon-complete.gif\" />";
			} else {
				return "";
			}
		},
		
    	// PAS20211U210100010 -- Inicio
    	descargarComprobantePdf: function(rowIndex){
    		var context = this.getContext();
			
	        var row = dijit.byId(context + ".facturasGrid").getItem(rowIndex);
			
			dojo.byId("formArchivoComprobantePdf.ruc").value = row.nroRucEmisor;
			dojo.byId("formArchivoComprobantePdf.tipo").value = row.codFactura;
			dojo.byId("formArchivoComprobantePdf.serie").value = row.nroSerie;
			dojo.byId("formArchivoComprobantePdf.numero").value = row.nroFactura;

			dojo.byId("formArchivoComprobantePdf").submit();
    	},  	
    	// PAS20211U210100010 -- Fin
    	
    	descargarPDF: function(rowIndex){
    		var context = this.getContext();
			
	      var row = dijit.byId(context + ".facturasGrid").getItem(rowIndex);
			
  			dojo.byId("formArchivoPDF.idPDF").value = row.idPDF;
        dojo.byId("formArchivoPDF.nombrePDF").value = row.nombrePDF;
  			dojo.byId("formArchivoPDF").submit();			
    	}, 
    	
        validarNroRUC: function(){
    		/** Via xhr valida el ruc en el servidor y devuelve los datos */
    		var nroRUCDesc = dijit.byId("criterio.nroRUCDesc");
    		nroRUCDesc.setValue("");
    		
    		var ndNroRUC = dijit.byId("criterio.nroRUC");
    		if(dojo.trim(ndNroRUC.getValue()).length == 0) {
				//this.messageBoxError("Tiene que ingresar un n&uacute;mero de RUC.");
				alert("Tiene que ingresar un numero de RUC.");
    			
    			ndNroRUC.setValue("");
    			nroRUCDesc.setValue("");
    			ndNroRUC.focus();    			
    			return false;
    		}
    		if(dojo.trim(ndNroRUC.getValue()).length < 11) {
				//this.messageBoxError("Tiene que ingresar un n&uacute;mero de RUC valido de 11 digitos.");
				alert("Tiene que ingresar un numero de RUC valido de 11 digitos.");
    			
    			ndNroRUC.setValue("");
    			nroRUCDesc.setValue("");
    			ndNroRUC.focus();    			
    			return false;
    		}
    		if(!this.isValidRuc(dojo.trim(ndNroRUC.getValue()))) {
				//this.messageBoxError("N&uacute;mero de RUC incorrecto");
				alert("Numero de RUC incorrecto.");
    			
    			ndNroRUC.setValue("");
    			nroRUCDesc.setValue("");
    			ndNroRUC.focus();    			
    			return false;
    		}
    		this.wait("Consultando", "110px", 100);
    		var handler = dojo.xhrGet({
    			preventCache:  false,
    			url: this.controller + "?action=validarRUC&nroRUC=" + dojo.trim(ndNroRUC.getValue()),
    			handleAs: "json",
    			sync: true,
    			timeout: 10000
    		});
    		handler.addCallback(dojo.hitch(this, function(res){
    			this.waitMessage.hide();
    			if(res.codeError == 0) {
    				dijit.byId("criterio.nroRUCDesc").setValue(res.data);
    				//dijit.byId("criterio.periodo").focus();
					dijit.byId("criterio.fec_desde").focus();
    			} else {
    				//this.messageBoxError(res.messageError);
    				alert(res.messageError);
    				
        			ndNroRUC.setValue("");
        			nroRUCDesc.setValue("");
        			ndNroRUC.focus();
        		}
    		}));
    		handler.addErrback(function(res){
    			this.waitMessage.hide();
				//this.messageBoxError("Ocurrio un error al validar el documento.");
				alert("Ocurrio un error al validar el documento.");
    			
    			ndNroRUC.setValue("");
    			nroRUCDesc.setValue("");
    			ndNroRUC.focus();
    		});
    	},   	
    	
    	validarPeriodo: function(){
    		var ndPeriodo = dijit.byId("criterio.periodo");
    		if(dojo.trim(ndPeriodo.getValue()).length == 0 || dojo.trim(ndPeriodo.getValue()).length < 6) {
				//this.messageBoxError("Tiene que ingresar un periodo valido con formato YYYYMM.");
				alert("Tiene que ingresar un periodo valido con formato YYYYMM.");
    			
    			ndPeriodo.setValue("");
    			ndPeriodo.focus();    			
    			return false;
    		}
    	},
		
		retryRealizarConsulta: function(){
			var handler = dojo.io.iframe.send({
    			url: this.controller,
    			handleAs: "json",
    			sync: true,
    			timeout: 10000,
    			preventCache: true,
    			form: "criterio.form"
    		});
    		
			handler.addCallback(dojo.hitch(this, function(res){
				this.waitMessage.hide();
				if(res.codeError == 0) {
					this.content.onLoad = dojo.hitch(this, function(){
						var data = eval("(" + res.data + ")");						
						this.store = new dojo.data.ItemFileWriteStore({data: {identifier: 'id', items: data}});

						var context = this.getContext();
						
			    		var periodo = dijit.byId(context + ".periodoDesc");
			    		periodo.setValue(dojo.byId("global.periodoDesc").value);
			    		
			    		var rucEmisorDesc = dijit.byId(context + ".rucEmisorDesc");
			    		rucEmisorDesc.attr('value', dojo.byId("global.rucEmisor").value + " - " + dojo.byId("global.rucEmisorDesc").value);

			    		
			    		var grid = dijit.byId(context + ".facturasGrid");
						grid.setStore(this.store);
						grid.startup();
					});
					this.content.setHref(this.controller + "?action=mostrarListado&tipoConsulta=" + dojo.byId("global.tipoConsulta").value + "&preventCache=" + this.preventCache());					
				} else {
					//this.messageBoxError(res.messageError);	
					alert(res.messageError);
				}
			}));
			handler.addErrback(dojo.hitch(this, function(res) {
    			this.waitMessage.hide();
				//this.messageBoxError("Ocurrio un error al momento de ejecutar la consulta.");
				alert("Ocurrio un error al momento de ejecutar la consulta.");
			}));
		},
    	
    	realizarConsulta: function(){
    		if(!dijit.byId("criterio.form").validate()) return;
    		
    		if(dojo.trim(dijit.byId("criterio.nroRUC").getValue()).length == 0) {
				//this.messageBoxError("Tiene que ingresar un N&uacute;mero de RUC."); 
				alert("Tiene que ingresar un Numero de RUC.");
				
    			return;
    		}
			
			if (typeof dijit.byId("criterio.periodo") != 'undefined'){
				if(dojo.trim(dijit.byId("criterio.periodo").getValue()).length == 0) {
					//this.messageBoxError("Tiene que ingresar un periodo con formato YYYYMM.");
					alert("Tiene que ingresar un periodo con formato YYYYMM.");
					return;
				}
			} else if ((typeof dijit.byId("criterio.fec_desde") != 'undefined') &&
			(typeof dijit.byId("criterio.fec_hasta") != 'undefined')){
				if(dojo.trim(dijit.byId("criterio.fec_desde").getValue()).length == 0) {
					alert("Tiene que ingresar un periodo con formato dd/mm/yyyy.");
					dijit.byId("criterio.fec_desde").focus();
					return;
				}
				
				if(dojo.trim(dijit.byId("criterio.fec_hasta").getValue()).length == 0) {
					alert("Tiene que ingresar un periodo con formato dd/mm/yyyy.");
					dijit.byId("criterio.fec_hasta").focus();
					return;
				}
				
				var dias = this.restaFechas(dijit.byId("criterio.fec_desde").getValue(),dijit.byId("criterio.fec_hasta").getValue());
				
				if(dias>31){
					alert("El rango de fechas no debe ser mayor a 31 d\u00EDas calendarios");				
					return;	
				}
			}
			
    		this.cargarValoresGlobales();
    		
    		this.wait("Consultando", "110px", 100);
    		
    		var handler = dojo.io.iframe.send({
    			url: this.controller,
    			handleAs: "json",
    			sync: true,
    			timeout: 10000,
    			preventCache: true,
    			form: "criterio.form"
    		});
    		
			handler.addCallback(dojo.hitch(this, function(res){
				this.waitMessage.hide();
				if(res.codeError == 0) {
					this.content.onLoad = dojo.hitch(this, function(){
						var data = eval("(" + res.data + ")");						
						this.store = new dojo.data.ItemFileWriteStore({data: {identifier: 'id', items: data}});

						var context = this.getContext();
						
			    		var periodo = dijit.byId(context + ".periodoDesc");
			    		periodo.setValue(dojo.byId("global.periodoDesc").value);
			    		
			    		var rucEmisorDesc = dijit.byId(context + ".rucEmisorDesc");
			    		rucEmisorDesc.attr('value', dojo.byId("global.rucEmisor").value + " - " + dojo.byId("global.rucEmisorDesc").value);

			    		
			    		var grid = dijit.byId(context + ".facturasGrid");
						grid.setStore(this.store);
						grid.startup();
					});
					this.content.setHref(this.controller + "?action=mostrarListado&tipoConsulta=" + dojo.byId("global.tipoConsulta").value + "&preventCache=" + this.preventCache());					
				} else {
					//this.messageBoxError(res.messageError);	
					alert(res.messageError);
				}
			}));
			handler.addErrback(dojo.hitch(this, function(res) {
    			this.waitMessage.hide();
				//this.messageBoxError("Ocurrio un error al momento de ejecutar la consulta.");
				//alert("Ocurrio un error al momento de ejecutar la consulta.");
				this.retryRealizarConsulta();
			}));
    	}, 	
    	
    	imprimirListado: function(rowIndex){
    		window.open(this.controller + "?action=imprimirListado&rucEmisor=" + dojo.byId("global.rucEmisor").value + "&rucEmisorDesc=" + dojo.byId("global.rucEmisorDesc").value + "&periodoDesc=" + dojo.byId("global.periodoDesc").value + "&tipoConsulta=" + dojo.byId("global.tipoConsulta").value + "&preventCache=" + this.preventCache(), "imprimeListado" , "toolbar=0,location=0,directories=0,status=no,menubar=0,scrollbars=yes,resizable=yes,width=1000,height=580,titlebar=no");    		
    	},    	
    	
        descargar: function(rowIndex){
    		var context = this.getContext();
			
	        var row = dijit.byId(context + ".facturasGrid").getItem(rowIndex);
			
			dojo.byId("formArchivo.ruc").value = row.nroRucEmisor;
			dojo.byId("formArchivo.tipo").value = row.codFactura;
			dojo.byId("formArchivo.serie").value = row.nroSerie;
			dojo.byId("formArchivo.numero").value = row.nroFactura;

			dojo.byId("formArchivo").submit();			
    	},  	
    	
        view: function(rowIndex){
	        var row = dijit.byId(this.getContext() + ".facturasGrid").getItem(rowIndex);
	        //window.open(this.controller + "?action=verImprimirFactura&ruc=" + row.nroRucEmisor + "&tipo=" + row.codFactura +"&serie=" + row.nroSerie + "&numero=" + row.nroFactura, "imprimeFactura" , "toolbar=0,location=0,directories=0,status=no,menubar=0,scrollbars=yes,resizable=yes,width=1000,height=580,titlebar=no");
	        window.open(this.controller + "?action=verImprimirFactura&rowIndex=" + rowIndex, "imprimeFactura" , "toolbar=0,location=0,directories=0,status=no,menubar=0,scrollbars=yes,resizable=yes,width=1000,height=580,titlebar=no");
    	},
    	
        messageBoxOKCancel: function(message, iconClass){
            var dialog = dijit.byId("dialogOkCancel");
            if (dialog) {
                dojo.byId("ok_cancelMessage").innerHTML = this.chunkString(message, 40);
                if (iconClass) {
                    dojo.addClass("ok_cancelIcon", iconClass);
                }
                else {
                    dojo.addClass("ok_cancelIcon", "icon-alert-info");
                }
                dijit.byId('dialogOkCancel').domNode.style.visibility = "visible";
                dialog.show();
            }
        },
        
    	cargarValoresGlobales: function() {        	
        	dojo.byId("global.rucEmisor").value = dijit.byId("criterio.nroRUC").getValue();
        	dojo.byId("global.rucEmisorDesc").value = dijit.byId("criterio.nroRUCDesc").getValue();        	
        	
			if (typeof dijit.byId("criterio.periodo") != 'undefined'){
				dojo.byId("global.periodo").value = dijit.byId("criterio.periodo").getValue();
				dojo.byId("global.periodoDesc").value = 
				dijit.byId("criterio.periodo").getValue().substring(4) + "/" + 
				dijit.byId("criterio.periodo").getValue().substring(0,4);
			} else if (typeof dijit.byId("criterio.fec_desde") != 'undefined'){
				dojo.byId("global.periodoDesc").value = dijit.byId("criterio.fec_desde").getValue() + " - " + dijit.byId("criterio.fec_hasta").getValue();
    		}
			
    		dojo.byId("global.tipoConsulta").value = dijit.byId("criterio.tipoConsulta").getValue();    	
    	},
    	
    	getContext: function() {
    		var context = "emitido";
    		if (dojo.byId("global.tipoConsulta").value == 10) {
    			context = "emitido";
    		}
    		if (dojo.byId("global.tipoConsulta").value == 11) {
    			context = "recibido";
    		}
    		if (dojo.byId("global.tipoConsulta").value == 12) {
    			context = "rechazado";		    			
    		}
    		if (dojo.byId("global.tipoConsulta").value == 13) {
    			context = "emitidoNC";
    		}
    		if (dojo.byId("global.tipoConsulta").value == 14) {
    			context = "recibidoNC";
    		}
    		if (dojo.byId("global.tipoConsulta").value == 15) {
    			context = "emitidoND";
    		}
    		if (dojo.byId("global.tipoConsulta").value == 16) {
    			context = "recibidoND";
    		}
			if (dojo.byId("global.tipoConsulta").value == 17) {
    			context = "emitido";
    		}
			if (dojo.byId("global.tipoConsulta").value == 18) {
    			context = "recibido";
    		}
			if (dojo.byId("global.tipoConsulta").value == 20) {
    			context = "emitidoNC";
    		}
			if (dojo.byId("global.tipoConsulta").value == 22) {
    			context = "emitidoND";
    		}
    		return context; 
    	},
    
	linkViewNew: function(value, rowindex) {
		var result = "...";
		if (value == "1"){ //ind_puede_descargar
			result = "<a href=\"#\" onclick=\"consultaFactura.view('" + rowindex +  "')\"> <img src=\"/a/imagenes/see/icons/viewdoc.gif\" /></a>"
		}
		return result;
    },
	
	linkView: function(rowindex) {
		return "<a href=\"#\" onclick=\"consultaFactura.view('" + rowindex +  "')\"> <img src=\"/a/imagenes/see/icons/viewdoc.gif\" /></a>"
	},
	
	linkDescargarNew: function(value, rowindex) {
		var result = "..."; 
		if (value == "1"){ //ind_puede_descargar
			result = "<a href=\"#\" onclick=\"consultaFactura.descargar('" + rowindex +  "')\"> <img src=\"/a/imagenes/see/icons/download_16p.gif\" />Descargar Factura (XML)</a>"
		}		
		return result;
    },
			
	linkDescargar: function(rowindex) {
		return "<a href=\"#\" onclick=\"consultaFactura.descargar('" + rowindex +  "')\"> <img src=\"/a/imagenes/see/icons/download_16p.gif\" />Descargar Factura (XML)</a>"
	},
	
	linkDescargarBVENew: function(value, rowindex) {
		var result = "...";
		if (value == "1"){ //ind_puede_descargar
			result = "<a href=\"#\" onclick=\"consultaFactura.descargar('" + rowindex +  "')\"> <img src=\"/a/imagenes/see/icons/download_16p.gif\" />Descargar BVE (XML)</a>"
		}
		return result;
    },
	
	linkDescargarBVE: function(rowindex) {
		return "<a href=\"#\" onclick=\"consultaFactura.descargar('" + rowindex +  "')\"> <img src=\"/a/imagenes/see/icons/download_16p.gif\" />Descargar BVE (XML)</a>"
	},
	
	linkDescargarNCNew: function(value, rowindex) {
		var result = "...";
		if (value == "1"){
			result = "<a href=\"#\" onclick=\"consultaFactura.descargar('" + rowindex +  "')\"> <img src=\"/a/imagenes/see/icons/download_16p.gif\" />Descargar NC (XML)</a>"
		}
		return result;
    },
	
	linkDescargarNC: function(rowindex) {
		return "<a href=\"#\" onclick=\"consultaFactura.descargar('" + rowindex +  "')\"> <img src=\"/a/imagenes/see/icons/download_16p.gif\" />Descargar NC (XML)</a>"
	},
	
	linkDescargarNDNew: function(value, rowindex) {
		var result = "...";
		if (value == "1"){
			result = "<a href=\"#\" onclick=\"consultaFactura.descargar('" + rowindex +  "')\"> <img src=\"/a/imagenes/see/icons/download_16p.gif\" />Descargar ND (XML)</a>"
		}
		return result;
    },

	linkDescargarND: function(rowindex) {
		return "<a href=\"#\" onclick=\"consultaFactura.descargar('" + rowindex +  "')\"> <img src=\"/a/imagenes/see/icons/download_16p.gif\" />Descargar ND (XML)</a>"
	},
	
	linkDescargarPDFNew: function(value, rowindex) {
		var result = "...";
		if (value == "1"){ //ind_puede_descargar
			var row = dijit.byId("emitido.facturasGrid").getItem(rowindex);

			if (row.nombrePDF != ""){
				result = "<a href=\"#\" onclick=\"consultaFactura.descargarPDF('" + rowindex +  "')\"> <img src=\"/a/imagenes/see/icons/download_16p.gif\" />Descargar TAX FREE (PDF)</a>"
			}
		}		
		return result;
    },
 
	linkDescargarPDF: function(rowindex) {		
		var row = dijit.byId("emitido.facturasGrid").getItem(rowindex);
        if (row.nombrePDF != ""){
   		    return "<a href=\"#\" onclick=\"consultaFactura.descargarPDF('" + rowindex +  "')\"> <img src=\"/a/imagenes/see/icons/download_16p.gif\" />Descargar TAX FREE (PDF)</a>"
		}
   	},  
    
    // PAS20211U210100010 -- Inicio
    linkDescargarComprobantePdf: function(value, rowindex) {
		var result = "...";
		if (value == "1"){
			result = "<a href=\"#\" onclick=\"consultaFactura.descargarComprobantePdf('" + rowindex +  "')\"> <img src=\"/a/imagenes/see/icons/download_16p.gif\" />Descargar PDF</a>"
		}
		return result;
    },
    // PAS20211U210100010 -- Fin   	
   	
	mostrarDescripTipo: function(value, rowindex) {  
        if( value == "21" ) {return "Anulaci\u00F3n de la Operaci\u00F3n";}
        if( value == "22" ) {return "Anulaci\u00F3n por Error en el RUC";}     
        if( value == "23" ) {return "Descuento Global";}
        if( value == "24" ) {return "Devoluci\u00F3n Total";}
        if( value == "25" ) {return "Correcci\u00F3n por Error en la Descripci\u00F3n";}
        if( value == "26" ) {return "Devoluci\u00F3n por Item";}
        if( value == "27" ) {return "Descuento por Item";}
        if( value == "41" ) {return "Intereses por Mora";}
        if( value == "42" ) {return "Aumento en el Valor";}
        if( value == "43" ) {return "Penalidad";}
		//PAS20201U210100230
		if(value=="28"){return "Otros Conceptos"}
		if(value=="29"){return "Ajustes - montos y/o fechas de pago"}
	},
             
    isValidRuc: function(ruc) {
    		ruc = dojo.trim(ruc);
    		if(!isNaN(ruc)) {
    			if(ruc.length == 8) {
    				suma = 0;
    				for(i=0; i < ruc.length-1; i++) {
    					digito = ruc.charAt(i) - '0';
    					if(i == 0) suma += (digito * 2);
    					else suma += (digito * (ruc.length - i));
    				}
    				resto = suma % 11;
    				if(resto == 1) resto = 11;
    				if(resto + (ruc.charAt(ruc.length - 1) - '0') == 11) {
    					return true;
    				}
    			}
    			else if(ruc.length == 11){
    				suma = 0;
    				x = 6;
    				for(i=0; i < ruc.length - 1; i++) {
    					if(i == 4) x = 8;
    					digito = ruc.charAt(i) - '0';
    					x--;
    					if(i == 0) suma += (digito * x);
    					else suma += (digito * x);
    				}
    				resto = suma % 11;
    				resto = 11 - resto;
    				if(resto >= 10) resto = resto - 10;
    				if(resto == ruc.charAt(ruc.length - 1) - '0') {
    					return true;
    				}      
    			}
    		}
    		return false;
    	},   	
    	
      	wait: function(message, width) {
    		dojo.byId("waitMessage").innerHTML="<div class='dijitInline box-message'></div><div class='dijitInline'>&nbsp;" + message + "...</div>";
    	    dojo.byId("waitMessage").style.width = width;
    	    this.waitMessage.show();
    	},
    	
    	messageBoxError: function(message, iconClass) {
    		var dialog = dijit.byId("dialogError");
    		if(dialog) {
    			dojo.byId("alertMessage").innerHTML=this.chunkString(message, 40);
    			if(iconClass) dojo.addClass("alertIcon", iconClass);
    			else dojo.addClass("alertIcon", "icon-alert-error");
    			dijit.byId('dialogError').domNode.style.visibility = "visible";

    			dialog.show();
    		}
    	},    	
    	
    	chunkString: function(cad, size) {
    		var aCad = cad.split(" ");
    		for(i = 0; i < aCad.length; i++) {
    			if(aCad[i].length > size) {
    				return this.wordWrap(cad, size, "<br/>", 2);
    			}
    		}
    		return cad;
    	},
    	
        mostrarFiltro: function(){
//    		this.content.setHref(this.controller + "?action=mostrarCriterios" + "&preventCache=" + this.preventCache());
			var handler = dojo.xhrGet({
				preventCache:  false,
				url: this.controller + "?action=dataCriterios",
				handleAs: "json",
				sync: true,
				timeout: 10000
			});    		
    		
			handler.addCallback(dojo.hitch(this, function(res){
				this.waitMessage.hide();
				if(res.codeError == 0) {
					this.content.onLoad = dojo.hitch(this, function(){

					});
					this.content.setHref(this.controller + "?action=backCriterios&preventCache=" + this.preventCache());					
				} else {
					//this.messageBoxError(res.messageError);
					alert(res.messageError);
				}
			}));
			handler.addErrback(dojo.hitch(this, function(res) {
    			this.waitMessage.hide();
				//this.messageBoxError("Ocurrio un error al momento de ejecutar la consulta.");
    			alert("Ocurrio un error al momento de ejecutar la consulta.");
			}));    		
        },
  
        salirConsulta: function(){
            //this.messageBoxOKCancel("Desea salir de la Aplicacion?.", "icon-alert-info");
        	if (confirm("\xbf Desea salir de la Aplicaci\xf3n?.")) {
        		this.cerrarConsulta();
        	}        	
        },
        
        salirListado: function(){
            //this.messageBoxOKCancel("Desea salir del listado de Facturas?.", "icon-alert-info");
        	if (confirm("\xbf Desea salir del listado ?.")) {
        		this.cerrarConsulta();
        	}        	
        },        
        
        cerrarConsulta: function(){
            dijit.byId('dialogOkCancel').hide();
            this.mostrarFiltro();
         },
         
     	preventCache: function() {
     		return new Date().valueOf();
     	},
    	
    	noSort: function(index){ 
    		 return false;
    	}     
    });
}
