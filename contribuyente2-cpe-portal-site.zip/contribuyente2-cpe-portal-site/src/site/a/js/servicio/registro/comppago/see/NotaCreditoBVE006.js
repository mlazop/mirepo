/**
 * NotaCreditoBVE.js - JavaScript de la Emision de Notas de Cr\u00E9dito de Boleta de Venta Electr\u00F3nica.
 * Fecha: 2015-02-09
 * ResponseBean : codeError; messageError; data;
 */

/**
 * PAS20211U210600213-Chrome-Inicio
 * narista: ajustes por problemas de navegador
 */
 
 function mostrarMensaje(msj, tipo = 1 )  {

			if ( dijit.byId('dlgMensaje') != undefined ) {
					require(["dojo/dom-construct"], function(domConstruct){
					  dijit.byId('dlgBtnAceptar').destroy();
					  dijit.byId('dlgMensaje').destroy();
					});
			}

			var aceptarDialog = new dijit.Dialog({ id: 'dlgMensaje', title: "Mensaje" });
			var respCallback = function(mouseEvent) {
					aceptarDialog.hide();
			};

			dojo.connect(aceptarDialog,"onCancel",function(){
					aceptarDialog.hide();
			});

			switch (tipo) {
					case 0: // OK
							questionDiv = dojo.create("div", {innerHTML:"<table><tr style='height:70px'><td><img src='/a/imagenes/pase_embarque.gif' border='0' alt=''></td><td style='padding-left: 5px;'>" + msj + "</td></tr></table>"});
							break;
					case 1: // INFO
							questionDiv = dojo.create("div", {innerHTML:"<table><tr style='height:70px'><td><img src='/a/imagenes/sigad/acciones/advertencia.gif' border='0' alt=''></td><td style='padding-left: 5px;'>" + msj + "</td></tr></table>"});
							break;
					case 2: // WARNING
							questionDiv = dojo.create("div", {innerHTML:"<table><tr style='height:70px'><td><img src='/a/imagenes/sigad/acciones/advertencia.gif' border='0' alt=''></td><td style='padding-left: 5px;'>" + msj + "</td></tr></table>"});
							break;
					case 3: // ERROR
							questionDiv = dojo.create("div", {innerHTML:"<table><tr style='height:70px'><td><img src='/a/imagenes/pase_no_embarque.gif' border='0' alt=''></td><td style='padding-left: 5px;'>" + msj + "</td></tr></table>"});
							break;
			}

			var aceptarButton = new dijit.form.Button( { label: 'Aceptar', id: 'dlgBtnAceptar', onClick: respCallback });
			var centroDiv = dojo.create('div', { style: { margin: "auto", textAlign: "center"} } );

			aceptarDialog.containerNode.appendChild(questionDiv);
			aceptarDialog.containerNode.appendChild(centroDiv);
			centroDiv.appendChild(aceptarButton.domNode);
			aceptarDialog.show();
	}
  
//narista: se agrega accion cancelar para el caso de los else
function mostrarMensajeConfirmacion ( msj, accionBtnAceptar, accionBtnCancelar = function() {} )  {

		if ( dijit.byId('dlgMensajeConfirmacion') != undefined ) {
				require(["dojo/dom-construct"], function(domConstruct){
				  dijit.byId('dlgBtnAceptarConfirm').destroy();
				  dijit.byId('dlgBtnCancelarConfirm').destroy();
				  dijit.byId('dlgMensajeConfirmacion').destroy();
				});
		}

		var dlgConfirmacion = new dijit.Dialog({ id: 'dlgMensajeConfirmacion', title: "Confirmar" });

		var respCallAceptar = function() {
			accionBtnAceptar();
			dlgConfirmacion.hide();
		};

		var respCallCancelar = function() {
			accionBtnCancelar();
			dlgConfirmacion.hide();
		};

		dojo.connect(dlgConfirmacion, "onCancel", function() {
			dlgConfirmacion.hide();
		});

		questionDiv = dojo.create("div", {innerHTML:"<table><tr style='height:70px'><td><img src='/a/imagenes/icons/questionMark32px.png' border='0' alt=''></td><td style='padding-left: 5px;'>" + msj + "</td></tr></table>"});

		var aceptarButton = new dijit.form.Button( { label: 'Aceptar', id: 'dlgBtnAceptarConfirm', onClick: respCallAceptar });
		var cancelarButton = new dijit.form.Button( { label: 'Cancelar', id: 'dlgBtnCancelarConfirm', onClick: respCallCancelar });

		var centroDiv = dojo.create('div', { style: { margin: "auto", textAlign: "center"} } );

		dlgConfirmacion.containerNode.appendChild(questionDiv);
		dlgConfirmacion.containerNode.appendChild(centroDiv);
		centroDiv.appendChild(aceptarButton.domNode);
		centroDiv.appendChild(cancelarButton.domNode);
		dlgConfirmacion.show();
}
//PAS20211U210600213-Fin

 




  /**
* Inicio : Codigo JS para el RUM de www.site24x7.com
*/
var rumMOKey='7c9688e69190206000618b5777f405b5';
(function(){
if(window.performance && window.performance.timing && window.performance.navigation) {
        var site24x7_rum_beacon=document.createElement('script');
        site24x7_rum_beacon.async=true;
        site24x7_rum_beacon.setAttribute('src','//static.site24x7rum.com/beacon/site24x7rum-min.js?appKey='+rumMOKey);
        document.getElementsByTagName('head')[0].appendChild(site24x7_rum_beacon);
}
})(window)
/**
* Fin : Codigo JS para el RUM de www.site24x7.com
*/ 
 
if (!dojo._hasResource["servicio.registro.comppago.see.NotaCreditoBVE"]) {
    dojo._hasResource["servicio.registro.comppago.see.NotaCreditoBVE"] = true;
    dojo.provide("servicio.registro.comppago.see.NotaCreditoBVE");
    
    dojo.require("dojo.data.ItemFileWriteStore");
    dojo.require("dojo.io.iframe");
    
    dojo.declare("servicio.registro.comppago.see.NotaCreditoBVE", null, {
		store: null,   
		boletaBean: null,
		igvBVE:null, 
		controller: "emitirNCBVE.do",
        
        constructor: function(){ },
        
        initialize: function(){
    		this.content = dijit.byId("content");    		
            this.waitMessage = dijit.byId("waitMessage");
            this.dialogItem25 =  dijit.byId("dialogItem25");
            this.dialogItem26 =  dijit.byId("dialogItem26");
            this.dialogItem27 =  dijit.byId("dialogItem27");
        },
        
        startup: function(){
            dojo.parser.parse(dojo.byId('container'));
            setTimeout(dojo.hitch(this, function(){
                this.hideLoader();
            }), 250);
        },
        
        hideLoader: function(){
            this.initialize();
            var loader = dojo.byId('loader');
            var _this = this;
            dojo.fadeOut({
                node: loader,
                duration: 250,
                onEnd: function(){
                	dijit.byId('content').domNode.style.visibility = "visible";            	
                    loader.style.display = "none";
                }
            }).play();
        },
         
        initContent: function(){
            /*Nada al cargar el formulario*/
        	this.store = null;
        	//this.boletaBean = null;
        	dijit.hideTooltip(dojo.byId("numeroComprobante"));
        	dijit.focus(dojo.byId("pantallaInicial.tipoNotaCredito"));
        },  	
    	
         
      	preventCache: function() {
      		return new Date().valueOf();
      	} ,
       
	showOpcionesPorTipoNCBVE: function() {    
		valor = dijit.byId("pantallaInicial.tipoNotaCredito").value;
        if (valor == "21" || valor == "" ) {
			this.showHiddenDiv(document.getElementById("inicio.motivo.show"),true);
        	this.showHiddenDiv(document.getElementById("inicio.numeronuevaBVE.show"),false);
        	this.showHiddenDiv(document.getElementById("inicio.descuentosBVE.show"),false);
        	if (valor == "" ) {
				this.showHiddenDiv(document.getElementById("inicio.leyendaNota21"),false);
        		this.showHiddenDiv(document.getElementById("inicio.leyendaNota22"),false);
        		this.showHiddenDiv(document.getElementById("inicio.leyendaNota23"),false);
        		this.showHiddenDiv(document.getElementById("inicio.leyendaNota24"),false);
        	}
        	if (valor == "21" ) {
				this.showHiddenDiv(document.getElementById("inicio.leyendaNota21"),true);
				this.showHiddenDiv(document.getElementById("inicio.leyendaNota22"),false);
        		this.showHiddenDiv(document.getElementById("inicio.leyendaNota23"),false);
        		this.showHiddenDiv(document.getElementById("inicio.leyendaNota24"),false);       		  
        	}
        }
        
		if (valor == "22") {
			this.showHiddenDiv(document.getElementById("inicio.motivo.show"),false);
        	this.showHiddenDiv(document.getElementById("inicio.numeronuevaBVE.show"),true);
        	this.showHiddenDiv(document.getElementById("inicio.descuentosBVE.show"),false);
        	this.showHiddenDiv(document.getElementById("inicio.leyendaNota21"),false);
        	this.showHiddenDiv(document.getElementById("inicio.leyendaNota22"),true);
        	this.showHiddenDiv(document.getElementById("inicio.leyendaNota23"),false);
        	this.showHiddenDiv(document.getElementById("inicio.leyendaNota24"),false);
        }
        
		if (valor == "23") {
			this.showHiddenDiv(document.getElementById("inicio.motivo.show"),true);
        	this.showHiddenDiv(document.getElementById("inicio.numeronuevaBVE.show"),false);
        	this.showHiddenDiv(document.getElementById("inicio.descuentosBVE.show"),true);
        	this.showHiddenDiv(document.getElementById("inicio.leyendaNota21"),false);
        	this.showHiddenDiv(document.getElementById("inicio.leyendaNota22"),false);
        	this.showHiddenDiv(document.getElementById("inicio.leyendaNota23"),true);
        	this.showHiddenDiv(document.getElementById("inicio.leyendaNota24"),false);
        }	
        
		if (valor == "24") {
			this.showHiddenDiv(document.getElementById("inicio.motivo.show"),true);
        	this.showHiddenDiv(document.getElementById("inicio.numeronuevaBVE.show"),false);
        	this.showHiddenDiv(document.getElementById("inicio.descuentosBVE.show"),false);
        	this.showHiddenDiv(document.getElementById("inicio.leyendaNota21"),false);
        	this.showHiddenDiv(document.getElementById("inicio.leyendaNota22"),false);
        	this.showHiddenDiv(document.getElementById("inicio.leyendaNota23"),false);
        	this.showHiddenDiv(document.getElementById("inicio.leyendaNota24"),true);
        }	
	
        if (valor == "25" || valor == "26" || valor == "27" ) {
			this.showHiddenDiv(document.getElementById("inicio.motivo.show"),true);
        	this.showHiddenDiv(document.getElementById("inicio.numeronuevaBVE.show"),false);
        	this.showHiddenDiv(document.getElementById("inicio.descuentosBVE.show"),false);
        	this.showHiddenDiv(document.getElementById("inicio.leyendaNota21"),false);
        	this.showHiddenDiv(document.getElementById("inicio.leyendaNota22"),false);
        	this.showHiddenDiv(document.getElementById("inicio.leyendaNota23"),false);
        	this.showHiddenDiv(document.getElementById("inicio.leyendaNota24"),false);
        }
        
		dijit.hideTooltip(dojo.byId("pantallaInicial.numeroBVE"));
		dijit.hideTooltip(dojo.byId("pantallaInicial.numeroNuevaBVE"));  
		
		if (valor == ""){
			dijit.byId("pantallaInicial.tipoNotaCredito").focus();
		} else {
			dijit.byId("pantallaInicial.numeroBVE").focus();
		}
	},
	
	showOpcionesPorTipoNCBVEContin: function() {    
		valor = dijit.byId("pantallaInicial.tipoNotaCredito").value;
        if (valor == "21" || valor == "" ) {
			this.showHiddenDiv(document.getElementById("inicio.motivo.show"),true);
        	this.showHiddenDiv(document.getElementById("inicio.numeronuevaBVE.show"),false);
        	this.showHiddenDiv(document.getElementById("inicio.descuentosBVE.show"),false);
        	if (valor == "" ) {
				this.showHiddenDiv(document.getElementById("inicio.leyendaNota21"),false);
        		this.showHiddenDiv(document.getElementById("inicio.leyendaNota22"),false);
        		this.showHiddenDiv(document.getElementById("inicio.leyendaNota23"),false);
        		this.showHiddenDiv(document.getElementById("inicio.leyendaNota24"),false);
        	}
        	if (valor == "21" ) {
				this.showHiddenDiv(document.getElementById("inicio.leyendaNota21"),true);
				this.showHiddenDiv(document.getElementById("inicio.leyendaNota22"),false);
        		this.showHiddenDiv(document.getElementById("inicio.leyendaNota23"),false);
        		this.showHiddenDiv(document.getElementById("inicio.leyendaNota24"),false);       		  
        	}
        }
        
		if (valor == "22") {
			this.showHiddenDiv(document.getElementById("inicio.motivo.show"),false);
        	this.showHiddenDiv(document.getElementById("inicio.numeronuevaBVE.show"),true);
        	this.showHiddenDiv(document.getElementById("inicio.descuentosBVE.show"),false);
        	this.showHiddenDiv(document.getElementById("inicio.leyendaNota21"),false);
        	this.showHiddenDiv(document.getElementById("inicio.leyendaNota22"),true);
        	this.showHiddenDiv(document.getElementById("inicio.leyendaNota23"),false);
        	this.showHiddenDiv(document.getElementById("inicio.leyendaNota24"),false);
        }
        
		if (valor == "23") {
			this.showHiddenDiv(document.getElementById("inicio.motivo.show"),true);
        	this.showHiddenDiv(document.getElementById("inicio.numeronuevaBVE.show"),false);
        	this.showHiddenDiv(document.getElementById("inicio.descuentosBVE.show"),true);
        	this.showHiddenDiv(document.getElementById("inicio.leyendaNota21"),false);
        	this.showHiddenDiv(document.getElementById("inicio.leyendaNota22"),false);
        	this.showHiddenDiv(document.getElementById("inicio.leyendaNota23"),true);
        	this.showHiddenDiv(document.getElementById("inicio.leyendaNota24"),false);
        }	
        
		if (valor == "24") {
			this.showHiddenDiv(document.getElementById("inicio.motivo.show"),true);
        	this.showHiddenDiv(document.getElementById("inicio.numeronuevaBVE.show"),false);
        	this.showHiddenDiv(document.getElementById("inicio.descuentosBVE.show"),false);
        	this.showHiddenDiv(document.getElementById("inicio.leyendaNota21"),false);
        	this.showHiddenDiv(document.getElementById("inicio.leyendaNota22"),false);
        	this.showHiddenDiv(document.getElementById("inicio.leyendaNota23"),false);
        	this.showHiddenDiv(document.getElementById("inicio.leyendaNota24"),true);
        }	
	
        if (valor == "25" || valor == "26" || valor == "27" ) {
			this.showHiddenDiv(document.getElementById("inicio.motivo.show"),true);
        	this.showHiddenDiv(document.getElementById("inicio.numeronuevaBVE.show"),false);
        	this.showHiddenDiv(document.getElementById("inicio.descuentosBVE.show"),false);
        	this.showHiddenDiv(document.getElementById("inicio.leyendaNota21"),false);
        	this.showHiddenDiv(document.getElementById("inicio.leyendaNota22"),false);
        	this.showHiddenDiv(document.getElementById("inicio.leyendaNota23"),false);
        	this.showHiddenDiv(document.getElementById("inicio.leyendaNota24"),false);
        }
        
		dijit.hideTooltip(dojo.byId("pantallaInicial.numeroBVE"));
		dijit.hideTooltip(dojo.byId("pantallaInicial.numeroNuevaBVE"));  
		
		if (valor == ""){
			dijit.byId("pantallaInicial.tipoNotaCredito").focus();
		}else {
			//dijit.byId("pantallaInicial.numeroBVE").focus();
			document.getElementById("serie").focus();
		}
	},
	
	
       
	verBoletaNC: function() {
		var numBoleta = dijit.byId("pantallaInicial.numeroBVE").value;
        if (numBoleta == ""){
		  	mostrarMensaje("Debe registrar el n\xFAmero de la Boleta de Venta Electr\xf3nica.");
            return;
        }
        var handler = dojo.xhrGet({
			url: this.controller + "?action=obtenerXml&boleta=" +numBoleta,
            handleAs: "json",
            sync: true,
            timeout: 10000
        });        
        handler.addCallback(dojo.hitch(this, function(res){
    		if (res.codeError == 0) {
				var xml=dijit.byId("boletaxml");
                var dBoleta = dijit.byId("dialogBoleta");
				if(dBoleta) {
					dBoleta.show();
					xml.attr("href","BoletaGenerada.jsp");
    		    }
    		} else {                         
				mostrarMensaje(res.messageError);
    			return;
    		}
		}));
    	handler.addErrback(function(res){
			this.waitMessage.hide();
    		mostrarMensaje("Problemas al conectarse con el servidor");
    	});
	},
	
		verBoletaNCContin: function() {
		var idSerie = document.getElementById("idSerie").value;
		var numBoleta = dijit.byId("pantallaInicial.numeroBVE").value;
        if (idSerie == ""){
			mostrarMensaje("Debe registrar la serie de la Boleta de Venta.");
            return;
        }
		if (numBoleta == ""){
			mostrarMensaje("Debe registrar el n\xFAmero de la Boleta de Venta.");
            return;
        }
        var handler = dojo.xhrGet({
			url: this.controller + "?action=obtenerXmlContin&boleta=" +numBoleta+"&idSerie="+idSerie,
            handleAs: "json",
            sync: true,
            timeout: 10000
        });        
        handler.addCallback(dojo.hitch(this, function(res){
    		if (res.codeError == 0) {
				var xml=dijit.byId("boletaxml");
                var dBoleta = dijit.byId("dialogBoleta");
				if(dBoleta) {
					dBoleta.show();
					xml.attr("href","BoletaGenerada.jsp");
    		    }
    		} else {                         
				mostrarMensaje(res.messageError);
    			return;
    		}
		}));
    	handler.addErrback(function(res){
			this.waitMessage.hide();
    		mostrarMensaje("Problemas al conectarse con el servidor");
    	});
	},
	
         verBoletaNew: function() {
           var numBoleta = dijit.byId("pantallaInicial.numeroNuevaBVE").getValue();
           if (numBoleta == ""){
              mostrarMensaje("Debe registrar el n\xFAmero de la Nueva Boleta de Venta Electr\xf3nica.");
              return;
           }
           var handler = dojo.xhrGet({
                    url: this.controller + "?action=obtenerXml&boleta=" +numBoleta,
                    handleAs: "json",
                    sync: true,
                    timeout: 10000
           });        
           handler.addCallback(dojo.hitch(this, function(res){
    		   if (res.codeError == 0) {
                 var xml=dijit.byId("boletaxml");
                 var dBoleta = dijit.byId("dialogBoleta");
    		         if(dBoleta) {      
                 			dBoleta.show();
                      xml.attr("href","BoletaGenerada.jsp");
    		         }                                                                        
    			 } else {                                 
    				  mostrarMensaje(res.messageError);
    				  return;
    			 }
    		}));
    		handler.addErrback(function(res){
    			this.waitMessage.hide();
    			mostrarMensaje("Problemas al conectarse con el servidor");
    		});
         },
          
		  verBoletaNewContin: function() {
		   var idSerieNew = document.getElementById("idSerieNew").value;
           var numBoleta = dijit.byId("pantallaInicial.numeroNuevaBVE").getValue();
		   if (idSerieNew == ""){
              mostrarMensaje("Debe registrar la serie de la Nueva Boleta de Venta.");
              return;
           }
           if (numBoleta == ""){
              mostrarMensaje("Debe registrar el n\xFAmero de la Nueva Boleta de Venta.");
              return;
           }
           var handler = dojo.xhrGet({
                    url: this.controller + "?action=obtenerXmlContin&boleta=" +numBoleta+"&idSerie="+idSerieNew,
                    handleAs: "json",
                    sync: true,
                    timeout: 10000
           });        
           handler.addCallback(dojo.hitch(this, function(res){
    		   if (res.codeError == 0) {
                 var xml=dijit.byId("boletaxml");
                 var dBoleta = dijit.byId("dialogBoleta");
    		         if(dBoleta) {      
                 			dBoleta.show();
                      xml.attr("href","BoletaGenerada.jsp");
    		         }                                                                        
    			 } else {                                 
    				  mostrarMensaje(res.messageError);
    				  return;
    			 }
    		}));
    		handler.addErrback(function(res){
    			this.waitMessage.hide();
    			mostrarMensaje("Problemas al conectarse con el servidor");
    		});
         },
		 
          
        verPreliminar: function() {
            if(!dijit.byId("criterio.form").validate()) return;
			
            // INI PAS20211U210100040  AHUISA
            if (!this.validarFechaEmision(false)){
              return;
            }
            // FIN PAS20211U210100040  AHUISA
           	valor = dojo.byId("pantallaInicial.tipoNotaCredito").value;
           	if (valor == ""){
           	  mostrarMensaje("Debe seleccionar el tipo de Nota de Cr\xE9dito a emitir.");
           	  return;
            }
            if (dojo.byId("pantallaInicial.numeroBVE").value == ""){
           	  mostrarMensaje("Debe ingresar el n\xFAmero de Boleta de Venta Electr\xf3nica respecto a la cual se emitir\xE1 la Nota de Cr\xE9dito.");
           	  return;                
            } 
            valor = dijit.byId("pantallaInicial.tipoNotaCredito").getValue();
        	if (valor == "21" || valor == "25" || valor == "26" || valor == "27") {
                if (dojo.byId("pantallaInicial.motivoEmisionNC").value == ""){
             	    mostrarMensaje("Debe ingresar el motivo o sustento por el cu\u00E1l se emitir\xE1 la Nota de Cr\xE9dito.");
             	    return;                
                }
        	}
        	/*if (valor == "22") {
              if (dijit.byId("pantallaInicial.numeroNuevaBVE").value == ""){
             	  alert("Debe ingresar el n\xFAmero de la nueva Boleta de Venta Electr\xf3nica.");
             	  return;                
              } 
        		}*/
        	
			valor = dijit.byId("pantallaInicial.tipoNotaCredito").getValue();
            
			if (this.boletaBean!=null && valor == "23") {
              if (dojo.byId("pantallaInicial.motivoEmisionNC").value == ""){
             	  mostrarMensaje("Debe ingresar el motivo o sustento por el cu\u00E1l se emitir\xE1 la Nota de Cr\xE9dito.");
             	  return;                
              } 
              if (dojo.byId("pantallaInicial.descuentoGlobalNC").value == "" ){
             	  mostrarMensaje("Debe consignarse el descuento global.");
             	  return;                
              } 
              if (dijit.byId("pantallaInicial.descuentoGlobalNC").getValue()  == 0){
             	  mostrarMensaje("Descuento Global debe ser mayor que cero.");
             	  return;                
              }              
              var totalValorVenta = this.boletaBean.montoTotalGeneral;
            
              var desc = dijit.byId("pantallaInicial.descuentoGlobalNC").getValue();
              var isc = 0;
              var igv = 0;
              if (dijit.byId("pantallaInicial.descuentoGlobalNC").getValue() >= totalValorVenta){
             	  mostrarMensaje("Descuento Global debe ser menor que el Valor de Venta de la BVE respecto de la cual se emitir\u00E1 la NC.");
             	  return;                
              } 
              
              if (dijit.byId("pantallaInicial.descuentoGlobalNC").getValue() == 0){
                 	  mostrarMensaje("Descuento Global debe ser mayor que cero");
                 	  return;                
              }   
                  
              //Validamos ISC
              if (dijit.byId("pantallaInicial.ISCNC").disabled == false){
                  if (dojo.byId("pantallaInicial.ISCNC").value == "" ){
                 	  mostrarMensaje("Debe consignarse el ISC.");
                 	  return;                
                  }               
                  if (dijit.byId("pantallaInicial.ISCNC").getValue() == 0){
                 	  mostrarMensaje("ISC debe ser mayor que cero");
                 	  return;                
                  }   
                  
                  if (dijit.byId("pantallaInicial.ISCNC").getValue() >= totalValorVenta){
                 	  mostrarMensaje("ISC debe ser menor que el Valor de Venta de la BVE respecto de la cual se emitir\u00E1 la NC");
                 	  return;                
                  }
                  
                  if (dijit.byId("pantallaInicial.ISCNC").getValue() >= dijit.byId("pantallaInicial.descuentoGlobalNC").getValue()){
                 	  mostrarMensaje("ISC debe ser menor que el monto de Descuento Global Registrado");
                 	  return;                
                  }  
  
                  var totalISC = this.boletaBean.totalISC;
                  if (dijit.byId("pantallaInicial.ISCNC").getValue() >= totalISC){
                 	  mostrarMensaje("ISC registrado debe ser menor al ISC de la BVE respecto de la cual se emitir\u00E1 la NC");
                 	  return;                
                  }                
                  isc = dijit.byId("pantallaInicial.ISCNC").getValue() ;
              }
              igv = dijit.byId("pantallaInicial.IGVNC").getValue() ;
              if ((desc + igv + isc ) >= totalValorVenta){
             	  mostrarMensaje("La suma del Descuento Global + IGV + ISC debe ser menor que el Valor de Venta de la BVE respecto de la cual se emitir\u00E1 la NC.");
             	  return;                
              } 
        	}	
        		
        	valor = dijit.byId("pantallaInicial.tipoNotaCredito").getValue();
            if (valor == "24") {
              if (dojo.byId("pantallaInicial.motivoEmisionNC").value == ""){
             	  mostrarMensaje("Debe ingresar el motivo o sustento por el cu\u00E1l se emitir\xE1 la Nota de Cr\xE9dito.");
             	  return;                
              } 
        	}	
      		var handler = dojo.xhrGet({
            url: this.controller + "?action=validarComprobante&TipoNotaCred=" + dijit.byId("pantallaInicial.tipoNotaCredito").value + "&boleta=" + dojo.byId("pantallaInicial.numeroBVE").value + "&boletanew=" + dojo.byId("pantallaInicial.numeroNuevaBVE").value
                        // INI PAS20211U210100040  AHUISA
                        + "&fecEmision=" + dojo.byId("pantallaInicial.fechaEmision").value,
                        // FIN PAS20211U210100040  AHUISA
    					handleAs: "json",
    					sync: true,
    					preventCache: true,
    					timeout: 10000
            });        
            handler.addCallback(dojo.hitch(this, function(res){
    		   if (res.codeError == 0) {
              		  if (valor == "25" || valor == "26" ||valor == "27") {
                            // INI PAS20211U210100040  AHUISA
    		                //this.content.setHref(this.controller + "?action=cambiarDetallesNC&TipoNotaCred=" + dijit.byId("pantallaInicial.tipoNotaCredito").value + "&boleta=" + dijit.byId("pantallaInicial.numeroBVE").value + "&motivo=" + dijit.byId("pantallaInicial.motivoEmisionNC").value+ "&boletanew=" + dijit.byId("pantallaInicial.numeroNuevaBVE").value+ "&descuento=" + dijit.byId("pantallaInicial.descuentoGlobalNC").value+ "&isc=" + dijit.byId("pantallaInicial.ISCNC").value+ "&igv=" + dijit.byId("pantallaInicial.IGVNC").value);
                            this.content.setHref(this.controller + "?action=cambiarDetallesNC&TipoNotaCred=" + dijit.byId("pantallaInicial.tipoNotaCredito").value + "&boleta=" + dijit.byId("pantallaInicial.numeroBVE").value + "&motivo=" + dijit.byId("pantallaInicial.motivoEmisionNC").value+ "&boletanew=" + dijit.byId("pantallaInicial.numeroNuevaBVE").value+ "&descuento=" + dijit.byId("pantallaInicial.descuentoGlobalNC").value+ "&isc=" + dijit.byId("pantallaInicial.ISCNC").value+ "&igv=" + dijit.byId("pantallaInicial.IGVNC").value+ "&fecEmision=" + dojo.byId("pantallaInicial.fechaEmision").value);
                            // FIN PAS20211U210100040  AHUISA
                        }
         		        if (valor == "21" || valor == "22" ||valor == "23" ||valor == "24" ) {
                            // INI PAS20211U210100040  AHUISA
                    		//this.content.setHref(this.controller + "?action=preliminarComprobante&TipoNotaCred=" + dijit.byId("pantallaInicial.tipoNotaCredito").value + "&boleta=" + dijit.byId("pantallaInicial.numeroBVE").value + "&motivo=" + dijit.byId("pantallaInicial.motivoEmisionNC").value+ "&boletanew=" + dijit.byId("pantallaInicial.numeroNuevaBVE").value+ "&descuento=" + dijit.byId("pantallaInicial.descuentoGlobalNC").value+ "&isc=" + dijit.byId("pantallaInicial.ISCNC").value+ "&igv=" + dijit.byId("pantallaInicial.IGVNC").value);
                            this.content.setHref(this.controller + "?action=preliminarComprobante&TipoNotaCred=" + dijit.byId("pantallaInicial.tipoNotaCredito").value + "&boleta=" + dijit.byId("pantallaInicial.numeroBVE").value + "&motivo=" + dijit.byId("pantallaInicial.motivoEmisionNC").value+ "&boletanew=" + dijit.byId("pantallaInicial.numeroNuevaBVE").value+ "&descuento=" + dijit.byId("pantallaInicial.descuentoGlobalNC").value+ "&isc=" + dijit.byId("pantallaInicial.ISCNC").value+ "&igv=" + dijit.byId("pantallaInicial.IGVNC").value+ "&fecEmision=" + dojo.byId("pantallaInicial.fechaEmision").value);
                            // FIN PAS20211U210100040  AHUISA
                    }    		   
    			 } else {     
               if (res.codeError == 9) {
                   
                   /*******PAS20211U210600213 - ajustes navegador 
               		if (!confirm(res.messageError + " \u00BFDesea continuar?. Puede revisar las notas de credito emitidas en la opci\u00F3n de consultas.")){
              			return;
              		}else{
              		  if (valor == "25" || valor == "26" ||valor == "27") {
                            // INI PAS20211U210100040  AHUISA
    		                //this.content.setHref(this.controller + "?action=cambiarDetallesNC&TipoNotaCred=" + dijit.byId("pantallaInicial.tipoNotaCredito").value + "&boleta=" + dijit.byId("pantallaInicial.numeroBVE").value + "&motivo=" + dijit.byId("pantallaInicial.motivoEmisionNC").value+ "&boletanew=" + dijit.byId("pantallaInicial.numeroNuevaBVE").value+ "&descuento=" + dijit.byId("pantallaInicial.descuentoGlobalNC").value+ "&isc=" + dijit.byId("pantallaInicial.ISCNC").value+ "&igv=" + dijit.byId("pantallaInicial.IGVNC").value);
                            this.content.setHref(this.controller + "?action=cambiarDetallesNC&TipoNotaCred=" + dijit.byId("pantallaInicial.tipoNotaCredito").value + "&boleta=" + dijit.byId("pantallaInicial.numeroBVE").value + "&motivo=" + dijit.byId("pantallaInicial.motivoEmisionNC").value+ "&boletanew=" + dijit.byId("pantallaInicial.numeroNuevaBVE").value+ "&descuento=" + dijit.byId("pantallaInicial.descuentoGlobalNC").value+ "&isc=" + dijit.byId("pantallaInicial.ISCNC").value+ "&igv=" + dijit.byId("pantallaInicial.IGVNC").value+ "&fecEmision=" + dojo.byId("pantallaInicial.fechaEmision").value);
                            // FIN PAS20211U210100040  AHUISA
                        }
         		        if (valor == "21" || valor == "22" ||valor == "23" ||valor == "24" ) {
                            // INI PAS20211U210100040  AHUISA
                    		//this.content.setHref(this.controller + "?action=preliminarComprobante&TipoNotaCred=" + dijit.byId("pantallaInicial.tipoNotaCredito").value + "&boleta=" + dijit.byId("pantallaInicial.numeroBVE").value + "&motivo=" + dijit.byId("pantallaInicial.motivoEmisionNC").value+ "&boletanew=" + dijit.byId("pantallaInicial.numeroNuevaBVE").value+ "&descuento=" + dijit.byId("pantallaInicial.descuentoGlobalNC").value+ "&isc=" + dijit.byId("pantallaInicial.ISCNC").value+ "&igv=" + dijit.byId("pantallaInicial.IGVNC").value);
                            this.content.setHref(this.controller + "?action=preliminarComprobante&TipoNotaCred=" + dijit.byId("pantallaInicial.tipoNotaCredito").value + "&boleta=" + dijit.byId("pantallaInicial.numeroBVE").value + "&motivo=" + dijit.byId("pantallaInicial.motivoEmisionNC").value+ "&boletanew=" + dijit.byId("pantallaInicial.numeroNuevaBVE").value+ "&descuento=" + dijit.byId("pantallaInicial.descuentoGlobalNC").value+ "&isc=" + dijit.byId("pantallaInicial.ISCNC").value+ "&igv=" + dijit.byId("pantallaInicial.IGVNC").value+ "&fecEmision=" + dojo.byId("pantallaInicial.fechaEmision").value);
                            // FIN PAS20211U210100040  AHUISA
                    }
                  } 
                  **/
				  // PAS20221U210700019 correccion errores ortograficos
                  //mostrarMensajeConfirmacion(res.messageError + " \u00BFDesea continuar?. Puede revisar las notas de cr\xE9dito emitidas en la opci\u00F3n de consultas.",
				  mostrarMensajeConfirmacion(res.messageError + " \u00BFDesea continuar? Puede revisar las notas de cr\xE9dito emitidas en la opci\u00F3n de consultas.",
						             dojo.hitch(this, function(){
					            if (valor == "25" || valor == "26" ||valor == "27") {
                            // INI PAS20211U210100040  AHUISA
    		                //this.content.setHref(this.controller + "?action=cambiarDetallesNC&TipoNotaCred=" + dijit.byId("pantallaInicial.tipoNotaCredito").value + "&boleta=" + dijit.byId("pantallaInicial.numeroBVE").value + "&motivo=" + dijit.byId("pantallaInicial.motivoEmisionNC").value+ "&boletanew=" + dijit.byId("pantallaInicial.numeroNuevaBVE").value+ "&descuento=" + dijit.byId("pantallaInicial.descuentoGlobalNC").value+ "&isc=" + dijit.byId("pantallaInicial.ISCNC").value+ "&igv=" + dijit.byId("pantallaInicial.IGVNC").value);
                            this.content.setHref(this.controller + "?action=cambiarDetallesNC&TipoNotaCred=" + dijit.byId("pantallaInicial.tipoNotaCredito").value + "&boleta=" + dijit.byId("pantallaInicial.numeroBVE").value + "&motivo=" + dijit.byId("pantallaInicial.motivoEmisionNC").value+ "&boletanew=" + dijit.byId("pantallaInicial.numeroNuevaBVE").value+ "&descuento=" + dijit.byId("pantallaInicial.descuentoGlobalNC").value+ "&isc=" + dijit.byId("pantallaInicial.ISCNC").value+ "&igv=" + dijit.byId("pantallaInicial.IGVNC").value+ "&fecEmision=" + dojo.byId("pantallaInicial.fechaEmision").value);
                            // FIN PAS20211U210100040  AHUISA
                        }
         		        if (valor == "21" || valor == "22" ||valor == "23" ||valor == "24" ) {
                            // INI PAS20211U210100040  AHUISA
                    		//this.content.setHref(this.controller + "?action=preliminarComprobante&TipoNotaCred=" + dijit.byId("pantallaInicial.tipoNotaCredito").value + "&boleta=" + dijit.byId("pantallaInicial.numeroBVE").value + "&motivo=" + dijit.byId("pantallaInicial.motivoEmisionNC").value+ "&boletanew=" + dijit.byId("pantallaInicial.numeroNuevaBVE").value+ "&descuento=" + dijit.byId("pantallaInicial.descuentoGlobalNC").value+ "&isc=" + dijit.byId("pantallaInicial.ISCNC").value+ "&igv=" + dijit.byId("pantallaInicial.IGVNC").value);
                            this.content.setHref(this.controller + "?action=preliminarComprobante&TipoNotaCred=" + dijit.byId("pantallaInicial.tipoNotaCredito").value + "&boleta=" + dijit.byId("pantallaInicial.numeroBVE").value + "&motivo=" + dijit.byId("pantallaInicial.motivoEmisionNC").value+ "&boletanew=" + dijit.byId("pantallaInicial.numeroNuevaBVE").value+ "&descuento=" + dijit.byId("pantallaInicial.descuentoGlobalNC").value+ "&isc=" + dijit.byId("pantallaInicial.ISCNC").value+ "&igv=" + dijit.byId("pantallaInicial.IGVNC").value+ "&fecEmision=" + dojo.byId("pantallaInicial.fechaEmision").value);
                            // FIN PAS20211U210100040  AHUISA
                    }
						
					//////}
					}) ,  dojo.hitch(this, function(){
                          })   )
					//);
                          
                          
                          
                          
                          
                 /////////////7  
               }else{                       
        				  mostrarMensaje(res.messageError);
                  return;
              }
    			 }
    		}));
    		handler.addErrback(function(res){
    			this.waitMessage.hide();
    			mostrarMensaje("Problemas al conectarse con el servidor");
    		});    			 
    }  ,    
  
  
  
  verPreliminarContin: function() {
		var serie = document.getElementById("serie").value;
		var numero = document.getElementById("numero").value;
		var idSerie = document.getElementById("idSerie").value;
		var idSerieNew = document.getElementById("idSerieNew").value;
		var boleta= dijit.byId("pantallaInicial.numeroBVE").value;
		var boleta2= dijit.byId("pantallaInicial.numeroNuevaBVE").value;
		if(numero==""){
			mostrarMensaje("Ingrese el n\xFAmero de serie");
			document.getElementById("numero").focus();
			return;
		}
		
            if(!dijit.byId("criterio.form").validate()) return;
			
           	valor = dojo.byId("pantallaInicial.tipoNotaCredito").value;
           	if (valor == ""){
           	  mostrarMensaje("Debe seleccionar el tipo de Nota de Cr\xE9dito a emitir.");
           	  return;
            }
            if (dojo.byId("pantallaInicial.numeroBVE").value == ""){
           	  mostrarMensaje("Debe ingresar el n\xFAmero de Boleta de Venta por Contingencia respecto a la cual se emitir\xE1 la Nota de Cr\xE9dito.");
           	  return;                
            } 
            valor = dijit.byId("pantallaInicial.tipoNotaCredito").getValue();
        	if (valor == "21" || valor == "25" || valor == "26" || valor == "27") {
                if (dojo.byId("pantallaInicial.motivoEmisionNC").value == ""){
             	    mostrarMensaje("Debe ingresar el motivo o sustento por el cu\u00E1l se emitir\xE1 la Nota de Cr\xE9dito.");
             	    return;                
                }
        	}
        	/*if (valor == "22") {
              if (dijit.byId("pantallaInicial.numeroNuevaBVE").value == ""){
             	  alert("Debe ingresar el n\xFAmero de la nueva Boleta de Venta Electr\xf3nica.");
             	  return;                
              } 
        		}*/
        	
			valor = dijit.byId("pantallaInicial.tipoNotaCredito").getValue();
            
			if (this.boletaBean!=null && valor == "23") {
              if (dojo.byId("pantallaInicial.motivoEmisionNC").value == ""){
             	  mostrarMensaje("Debe ingresar el motivo o sustento por el cu\u00E1l se emitir\xE1 la Nota de Cr\xE9dito.");
             	  return;                
              } 
              if (dojo.byId("pantallaInicial.descuentoGlobalNC").value == "" ){
             	  mostrarMensaje("Debe consignarse el descuento global.");
             	  return;                
              } 
              if (dijit.byId("pantallaInicial.descuentoGlobalNC").getValue()  == 0){
             	  mostrarMensaje("Descuento Global debe ser mayor que cero.");
             	  return;                
              }              
              var totalValorVenta = this.boletaBean.montoTotalGeneral;
            
              var desc = dijit.byId("pantallaInicial.descuentoGlobalNC").getValue();
              var isc = 0;
              var igv = 0;
              if (dijit.byId("pantallaInicial.descuentoGlobalNC").getValue() >= totalValorVenta){
             	  mostrarMensaje("Descuento Global debe ser menor que el Valor de Venta de la BVE respecto de la cual se emitir\u00E1 la NC.");
             	  return;                
              } 
              
              if (dijit.byId("pantallaInicial.descuentoGlobalNC").getValue() == 0){
                 	  mostrarMensaje("Descuento Global debe ser mayor que cero");
                 	  return;                
              }   
                  
              //Validamos ISC
              if (dijit.byId("pantallaInicial.ISCNC").disabled == false){
                  if (dojo.byId("pantallaInicial.ISCNC").value == "" ){
                 	  mostrarMensaje("Debe consignarse el ISC.");
                 	  return;                
                  }               
                  if (dijit.byId("pantallaInicial.ISCNC").getValue() == 0){
                 	  mostrarMensaje("ISC debe ser mayor que cero");
                 	  return;                
                  }   
                  
                  if (dijit.byId("pantallaInicial.ISCNC").getValue() >= totalValorVenta){
                 	  mostrarMensaje("ISC debe ser menor que el Valor de Venta de la BVE respecto de la cual se emitir\u00E1 la NC");
                 	  return;                
                  }
                  
                  if (dijit.byId("pantallaInicial.ISCNC").getValue() >= dijit.byId("pantallaInicial.descuentoGlobalNC").getValue()){
                 	  mostrarMensaje("ISC debe ser menor que el monto de Descuento Global Registrado");
                 	  return;                
                  }  
  
                  var totalISC = this.boletaBean.totalISC;
                  if (dijit.byId("pantallaInicial.ISCNC").getValue() >= totalISC){
                 	  mostrarMensaje("ISC registrado debe ser menor al ISC de la BVE respecto de la cual se emitir\u00E1 la NC");
                 	  return;                
                  }                
                  isc = dijit.byId("pantallaInicial.ISCNC").getValue() ;
              }
              igv = dijit.byId("pantallaInicial.IGVNC").getValue() ;
              if ((desc + igv + isc ) >= totalValorVenta){
             	  mostrarMensaje("La suma del Descuento Global + IGV + ISC debe ser menor que el Valor de Venta de la BVE respecto de la cual se emitir\u00E1 la NC.");
             	  return;                
              } 
        	}	
        		
        	valor = dijit.byId("pantallaInicial.tipoNotaCredito").getValue();
            if (valor == "24") {
              if (dojo.byId("pantallaInicial.motivoEmisionNC").value == ""){
             	  mostrarMensaje("Debe ingresar el motivo o sustento por el cu\u00E1l se emitir\xE1 la Nota de Cr\xE9dito.");
             	  return;                
              } 
        	}	
      		var handler = dojo.xhrGet({
            url: this.controller + "?action=validarComprobanteContin&TipoNotaCred=" + dijit.byId("pantallaInicial.tipoNotaCredito").value + "&boleta=" + boleta + "&boletanew=" + boleta2+"&idSerie="+idSerie+"&idSerieNew="+idSerieNew,
    					handleAs: "json",
    					sync: true,
    					preventCache: true,
    					timeout: 10000
            });//PAS20191U210100075  22.07 para tipo nc anulacion por error en el ruc (P_SNADE007-33037) falto el igual(=)
            handler.addCallback(dojo.hitch(this, function(res){
    		   if (res.codeError == 0) {
              		  if (valor == "25" || valor == "26" ||valor == "27") {
    		                this.content.setHref(this.controller + "?action=cambiarDetallesNCContin&TipoNotaCred=" + dijit.byId("pantallaInicial.tipoNotaCredito").value + "&boleta=" +boleta+"&motivo=" + dijit.byId("pantallaInicial.motivoEmisionNC").value+ "&boletanew="+boleta2+"&descuento=" + dijit.byId("pantallaInicial.descuentoGlobalNC").value+ "&isc=" + dijit.byId("pantallaInicial.ISCNC").value+ "&igv=" + dijit.byId("pantallaInicial.IGVNC").value+"&serie="+serie+"&idSerie="+idSerie+"&idSerieNew="+idSerieNew+"&numero="+numero);
    		            }
         		        if (valor == "21" || valor == "22" ||valor == "23" ||valor == "24" ) {
                    		this.content.setHref(this.controller + "?action=preliminarComprobanteContin&TipoNotaCred=" + dijit.byId("pantallaInicial.tipoNotaCredito").value + "&boleta="+boleta+"&motivo=" + dijit.byId("pantallaInicial.motivoEmisionNC").value+ "&boletanew="+boleta2+"&descuento=" + dijit.byId("pantallaInicial.descuentoGlobalNC").value+ "&isc=" + dijit.byId("pantallaInicial.ISCNC").value+ "&igv=" + dijit.byId("pantallaInicial.IGVNC").value+"&serie="+serie+"&idSerie="+idSerie+"&idSerieNew="+idSerieNew+"&numero="+numero);
                    }    		   
    			 } else {     
               if (res.codeError == 9) {
               
                   
               	/*
                 	if (!confirm(res.messageError + " \u00BFDesea continuar?. Puede revisar las notas de credito emitidas en la opci\u00F3n de consultas.")){
              			return;
              		}else{
              		  if (valor == "25" || valor == "26" ||valor == "27") {
    		                this.content.setHref(this.controller + "?action=cambiarDetallesNCContin&TipoNotaCred=" + dijit.byId("pantallaInicial.tipoNotaCredito").value + "&boleta="+boleta+"&motivo=" + dijit.byId("pantallaInicial.motivoEmisionNC").value+ "&boletanew=" + boleta2+ "&descuento=" + dijit.byId("pantallaInicial.descuentoGlobalNC").value+ "&isc=" + dijit.byId("pantallaInicial.ISCNC").value+ "&igv=" + dijit.byId("pantallaInicial.IGVNC").value+"&serie="+serie+"&idSerie="+idSerie+"&idSerieNew="+idSerieNew+"&numero="+numero);
    		            }
         		        if (valor == "21" || valor == "22" ||valor == "23" ||valor == "24" ) {
                    		this.content.setHref(this.controller + "?action=preliminarComprobanteContin&TipoNotaCred=" + dijit.byId("pantallaInicial.tipoNotaCredito").value + "&boleta=" + dijit.byId("pantallaInicial.numeroBVE").value + "&motivo=" + dijit.byId("pantallaInicial.motivoEmisionNC").value+ "&boletanew=" + dijit.byId("pantallaInicial.numeroNuevaBVE").value+ "&descuento=" + dijit.byId("pantallaInicial.descuentoGlobalNC").value+ "&isc=" + dijit.byId("pantallaInicial.ISCNC").value+ "&igv=" + dijit.byId("pantallaInicial.IGVNC").value+"&serie="+serie+"&idSerie="+idSerie+"&idSerieNew="+idSerieNew+"&numero="+numero);
                    }
                  } 
                  */
				  // PAS20221U210700019 correccion errores ortograficos
                  //mostrarMensajeConfirmacion(res.messageError + " \u00BFDesea continuar?. Puede revisar las notas de credito emitidas en la opci\u00F3n de consultas.",
				  mostrarMensajeConfirmacion(res.messageError + " \u00BFDesea continuar? Puede revisar las notas de cr\u00E9dito emitidas en la opci\u00F3n de consultas.",
						         dojo.hitch(this, function(){
					
						        if (valor == "25" || valor == "26" ||valor == "27") {
    		                this.content.setHref(this.controller + "?action=cambiarDetallesNCContin&TipoNotaCred=" + dijit.byId("pantallaInicial.tipoNotaCredito").value + "&boleta="+boleta+"&motivo=" + dijit.byId("pantallaInicial.motivoEmisionNC").value+ "&boletanew=" + boleta2+ "&descuento=" + dijit.byId("pantallaInicial.descuentoGlobalNC").value+ "&isc=" + dijit.byId("pantallaInicial.ISCNC").value+ "&igv=" + dijit.byId("pantallaInicial.IGVNC").value+"&serie="+serie+"&idSerie="+idSerie+"&idSerieNew="+idSerieNew+"&numero="+numero);
    		            }
         		        if (valor == "21" || valor == "22" ||valor == "23" ||valor == "24" ) {
                    		this.content.setHref(this.controller + "?action=preliminarComprobanteContin&TipoNotaCred=" + dijit.byId("pantallaInicial.tipoNotaCredito").value + "&boleta=" + dijit.byId("pantallaInicial.numeroBVE").value + "&motivo=" + dijit.byId("pantallaInicial.motivoEmisionNC").value+ "&boletanew=" + dijit.byId("pantallaInicial.numeroNuevaBVE").value+ "&descuento=" + dijit.byId("pantallaInicial.descuentoGlobalNC").value+ "&isc=" + dijit.byId("pantallaInicial.ISCNC").value+ "&igv=" + dijit.byId("pantallaInicial.IGVNC").value+"&serie="+serie+"&idSerie="+idSerie+"&idSerieNew="+idSerieNew+"&numero="+numero);
                    }
				      	}) , dojo.hitch(this, function(){
                    })      )
                  
                  
                  ////
               }else{                       
        				  mostrarMensaje(res.messageError);
                  return;
              }
    			 }
    		}));
    		handler.addErrback(function(res){
    			this.waitMessage.hide();
    			mostrarMensaje("Problemas al conectarse con el servidor");
    		});    			 
    }  ,  
	
	
	
  	saveDocument: function() {
	/*
  	if (!confirm("Est\xE1 Ud. seguro de emitir una Nota de Cr\xE9dito?")){
			return;
		}
	*/
  var accionBtnAceptarQ2 = dojo.hitch(this, function () {
  	
		var nbBack = dijit.byId("notaCredito-preliminar.botonBackDocumento");
		var nbSave = dijit.byId("notaCredito-preliminar.botonGrabarDocumento");
		var nbClose = dijit.byId("notaCredito-preliminar.botonCloseDocumento");
		
		nbBack.setAttribute('disabled', true);
		nbSave.setAttribute('disabled', true);
		nbClose.setAttribute('disabled', true);
		
		this.wait("Grabando", "95px", 800);
		
        var handler = dojo.xhrGet({
            url: this.controller + "?action=grabarComprobante",
            handleAs: "json",
            preventCache: true,
            sync: true,
            timeout: 10000
        });
				
        handler.addCallback(dojo.hitch(this, function(res){
            this.waitMessage.hide();
			if (res.codeError == 0) {
			    this.content.onLoad = dojo.hitch(this, function(){
					this.iconTooltipMessage("numeroComprobante", "icon-ok-tooltip", "La nota de cr&eacute;dito se emiti&oacute; correctamente <br>Ha generado este n&uacute;mero.");
				});            	
				this.content.setHref(this.controller + "?action=mostrarComprobante&preventCache=" + this.preventCache());
			} else {
    			nbBack.setAttribute('disabled', false);
    			nbSave.setAttribute('disabled', false);
    			nbClose.setAttribute('disabled', false);
				
                mostrarMensaje(res.messageError);
            }
        }));
        handler.addErrback(dojo.hitch(this, function(res){
  			nbBack.setAttribute('disabled', false);
  			nbSave.setAttribute('disabled', false);
  			nbClose.setAttribute('disabled', false);
  			
            this.waitMessage.hide();
			//PAS20221U210700020
            //mostrarMensaje("Problemas al emitir la Nota de Credito Electronica.");
			mostrarMensaje("Se produjo un error al grabar el comprobante o documento. Por favor, volver a intentar.");
        }));
      });
		// INI PAS20221U210700019
		//mostrarMensajeConfirmacion("Esta Ud. seguro de emitir una Nota de Cr\xE9dito?", accionBtnAceptarQ2 );
        mostrarMensajeConfirmacion("\u00BFEst\u00E1 Ud. seguro de emitir una Nota de Cr\u00E9dito?", accionBtnAceptarQ2 );
		// FIN PAS20221U210700019
        
	},
		
	saveDocumentContin: function() {
		/**
		 *if (!confirm("Esta Ud. seguro de registrar una Nota de Cr\xE9dito por Contingencia?")){
			return;
		}
    */
	var accionBtnAceptarQ2Contingencia = dojo.hitch(this, function () {
    
		var nbBack = dijit.byId("notaCredito-preliminar.botonBackDocumento");
		var nbSave = dijit.byId("notaCredito-preliminar.botonGrabarDocumento");
		var nbClose = dijit.byId("notaCredito-preliminar.botonCloseDocumento");
		
		nbBack.setAttribute('disabled', true);
		nbSave.setAttribute('disabled', true);
		nbClose.setAttribute('disabled', true);
		
		this.wait("Grabando", "95px", 800);
		
        var handler = dojo.xhrGet({
            url: this.controller + "?action=grabarComprobanteContin",
            handleAs: "json",
            preventCache: true,
            sync: true,
            timeout: 10000
        });
				
        handler.addCallback(dojo.hitch(this, function(res){
            this.waitMessage.hide();
			if (res.codeError == 0) {
			    this.content.onLoad = dojo.hitch(this, function(){
					this.iconTooltipMessage("numeroComprobante", "icon-ok-tooltip", "El registro de la presente informaci\u00F3n constituye una declaraci\u00F3n jurada, acorde con la RS 113-2018/SUNAT. <br>Ha generado este n&uacute;mero."); /* CorrecciÃ³n tildes - PAS20201U210100285 - Giancarlo Nepo LÃ³pez */
				});            	
				this.content.setHref(this.controller + "?action=mostrarComprobante&preventCache=" + this.preventCache());
			} else {
    			nbBack.setAttribute('disabled', false);
    			nbSave.setAttribute('disabled', false);
    			nbClose.setAttribute('disabled', false);
				
                mostrarMensaje(res.messageError);
            }
        }));
        handler.addErrback(dojo.hitch(this, function(res){
  			nbBack.setAttribute('disabled', false);
  			nbSave.setAttribute('disabled', false);
  			nbClose.setAttribute('disabled', false);
  			
            this.waitMessage.hide();
			//PAS20221U210700020
            //mostrarMensaje("Problemas al emitir la Nota de Cr\u00E9dito por Contingencia.");
			mostrarMensaje("Se produjo un error al grabar el comprobante o documento. Por favor, volver a intentar.");
        }));
          });
		// INI PAS20221U210700019
		//mostrarMensajeConfirmacion("\u00BFEsta Ud. seguro de registrar una Nota de Cr\xE9dito Contingencia?", accionBtnAceptarQ2Contingencia );
	   	mostrarMensajeConfirmacion("\u00BFEst\u00E1 Ud. seguro de registrar una Nota de Cr\u00E9dito Contingencia?", accionBtnAceptarQ2Contingencia );
        // FIN PAS20221U210700019
	},
	
	
    validarBoleta: function(id){		
	    var boleta= dijit.byId(id).value;
		boleta = boleta.replace(/^0+/, '');
		dijit.byId(id).attr('value',boleta);
		
	    dijit.hideTooltip(dojo.byId(id));
	    this.limpiaMontos();
	    if (boleta=="") return;
        this.wait("Consultando", "110px", 200);
        var handler = dojo.xhrGet({
			url: this.controller + "?action=existeBoleta&boleta=" + boleta ,
    		handleAs: "json",
    		preventCache:  true,
    		sync: true,
    		timeout: 10000
    	});
    	handler.addCallback(dojo.hitch(this, function(res){    		  	
			this.waitMessage.hide();
    		if(res.codeError == 0 ) {
				valor = dijit.byId("pantallaInicial.tipoNotaCredito").getValue();
				this.compararBoletas(id);
    		} else {
				dijit.byId(id).focus();
				this.iconTooltipMessage(id, "icon-ok-tooltip", res.messageError);
				return;
    		}
    	}));
    	handler.addErrback(function(res){
			this.waitMessage.hide();
			mostrarMensaje("Ocurrio un error al validar la boleta de venta ingresada");
    	});	
	},
	
	
	validarBoletaContin: function(id){		
		var idSerie = document.getElementById("idSerie").value;
		var idSerieNew = document.getElementById("idSerieNew").value;
		var numeroBoleta= dijit.byId("pantallaInicial.numeroBVE").value;
		var boletaNew= dijit.byId("pantallaInicial.numeroNuevaBVE").value;
		
		if (idSerie=="") return;
		
	    var boleta= dijit.byId(id).value;
		boleta = boleta.replace(/^0+/, '');
		dijit.byId(id).attr('value',boleta);
		
	    dijit.hideTooltip(dojo.byId(id));
	    this.limpiaMontos();
	    if (boleta=="") return;
        this.wait("Consultando", "110px", 200);
        var handler = dojo.xhrGet({
			url: this.controller + "?action=existeBoletaContin&boleta=" + numeroBoleta+"&idSerie="+idSerie ,
    		handleAs: "json",
    		preventCache:  true,
    		sync: true,
    		timeout: 10000
    	});
    	handler.addCallback(dojo.hitch(this, function(res){    		  	
			this.waitMessage.hide();
    		if(res.codeError == 0 ) {
				valor = dijit.byId("pantallaInicial.tipoNotaCredito").getValue();
				this.compararBoletasContin(idSerie,idSerieNew,numeroBoleta,boletaNew);
    		} else {
				dijit.byId(id).focus();
				this.iconTooltipMessage(id, "icon-ok-tooltip", res.messageError);
				return;
    		}
    	}));
    	handler.addErrback(function(res){
			this.waitMessage.hide();
			mostrarMensaje("Ocurrio un error al validar la boleta de venta ingresada");
    	});	
	},
	 
	//Antonio
	validateEstablecimiento: function(){
		var establecimiento = document.getElementById("establecimiento").value;
		var regexEstablecimiento=false;
		var digitoEstablecimiento="";
		var regex2 = /[0-9]|\./;
		for (i=0; i< establecimiento.length;i++){
		digitoEstablecimiento= establecimiento.charAt(i);
			if(!regex2.test(digitoEstablecimiento)) {//la serie debe ser numerica incluyendo 0
			regexEstablecimiento=true;
			}
      	 }
					if(establecimiento!==""){//el establecimiento debe ser diferente de vacio
						if(establecimiento.length<5){//el establecimiento debe ser de 4 digitos como maximo
							if(!regexEstablecimiento) {//el establecimiento debe ser de tipo numerico incluyendo 0
							}else{mostrarMensaje("El establecimeinto debe ser numerico"); 
							document.getElementById("establecimiento").value="";
							document.getElementById("establecimiento").focus();
							}
						}else{mostrarMensaje("El establecimiento debe ser menor a 5 d\00EDgitos"); 
						document.getElementById("establecimiento").value="";
						document.getElementById("establecimiento").focus();
						}
					}
	},	
	
	
	//Antonio
	validateSerie: function(){
		var serie1 = document.getElementById("serie").value;
		var numero1 = document.getElementById("numero").value;
		
		var regexSerie1=false;
		var regexNumero1=false;
		var digitoSerie1="";
		var digitoNumero1="";
		var regex1 = /[0-9]|\./;
		for (i=0; i< serie1.length;i++){
		digitoSerie1= serie1.charAt(i);
			if(!regex1.test(digitoSerie1)) {//la serie debe ser numerica incluyendo 0
			regexSerie1=true;
			}
      	 }
		
		for (i=0; i< numero1.length;i++){
		digitoNumero1= numero1.charAt(i);
			if(!regex1.test(digitoNumero1)) {//el numero debe ser de tipo numerico incluyendo 0
			regexNumero1=true;
			}
      	 }
					if(serie1!==""){//la serie debe ser diferente de vacio
						if(serie1.length==4){//el numero debe ser de 9 digitos como maximo
							if(!regexSerie1) {//el numero debe ser de tipo numerico incluyendo 0
							document.getElementById("numero").value="";
							document.getElementById("numero").focus();
							}else{mostrarMensaje("La serie debe ser numerica"); 
							document.getElementById("serie").value="";
							document.getElementById("numero").value="";
							document.getElementById("serie").focus();}
						}else{mostrarMensaje("la serie debe tener 4 caracteres"); 
						document.getElementById("serie").value="";
						document.getElementById("numero").value="";
						document.getElementById("serie").focus();}
					}
	},	
	
	//Antonio
	validateSerieId: function(){
		var serie2 = document.getElementById("idSerie").value;
		var regexSerie2=false;
		var digitoSerie2="";
		//var regex2 = /[0-9]|\./;
		/*for (i=0; i< serie2.length;i++){
		digitoSerie2= serie2.charAt(i);
			if(!regex2.test(digitoSerie2)) {//la serie debe ser numerica incluyendo 0
			regexSerie2=true;
			}
      	 }*/
         var regex2 = /(?=.*\b[eE][bB]01\b)[eE][bB]01|(?=.*\b[bB][A-Za-z0-9]{3}\b)[bB][A-Za-z0-9]{3}|(?=.*\b[0-9]{4}\b)[0-9]{3}/;
          if(!regex2.test(serie2)) {//la serie debe ser numerica incluyendo 0
            regexSerie2=true;
      	 }
		
					if(serie2!==""){//la serie debe ser diferente de vacio
						if(serie2.length==4){//el numero debe ser de 9 digitos como maximo
							if(!regexSerie2) {//el numero debe ser de tipo numerico incluyendo 0
							}else{
                                //alert("La serie debe ser numerica"); 
                                mostrarMensaje("La serie debe ser numerica o con el siguiente formato EB01 o BXXX");
							document.getElementById("idSerie").value="";
							document.getElementById("idSerie").focus();}
						}else{mostrarMensaje("la serie debe tener 4 caracteres"); 
						document.getElementById("idSerie").value="";
						document.getElementById("idSerie").focus();}
					}
	},	
	
	//Antonio
	validateNumero: function(){		
		var serie = document.getElementById("serie").value;
		var numero = document.getElementById("numero").value;
		var establecimiento = document.getElementById("establecimiento").value;
		var fechaEmision = document.getElementById("fechaEmision").value;
		if(fechaEmision!==""){
			
		if(establecimiento!==""){
			
		var regexSerie=false;
		var regexNumero=false;
		var digitoSerie="";
		var digitoNumero="";
		var regex = /[0-9]|\./;
		for (i=0; i< serie.length;i++){
		digitoSerie= serie.charAt(i);
			if(!regex.test(digitoSerie)) {//la serie debe ser numerica incluyendo 0
			regexSerie=true;
			}
      	 }
		for (i=0; i< numero.length;i++){
		digitoNumero= numero.charAt(i);
			if(!regex.test(digitoNumero)) {//el numero debe ser de tipo numerico incluyendo 0
			regexNumero=true;
			}
      	 }
		 if(numero!==""){//la serie debe ser diferente de vacio
			if(numero.length<=9){//el numero debe ser de 9 digitos como maximo
				if(!regexNumero) {//el numero debe ser de tipo numerico incluyendo 0
					if(serie!==""){//la serie debe ser diferente de vacio
						if(serie.length<=4){//el numero debe ser de 9 digitos como maximo
							if(!regexSerie) {//el numero debe ser de tipo numerico incluyendo 0
								var handler = dojo.xhrGet({
									preventCache:  false,
									url: this.controller + "?action=validadComprobante&serie=" + serie + "&numero=" + numero+"&establecimiento="+establecimiento+"&fechaEmision="+fechaEmision,
									handleAs: "json",
									sync: true,
									timeout: 10000
								});
								handler.addCallback(dojo.hitch(this, function(response){
									this.waitMessage.hide();
										if(response.codeError==1){
											
										}else if(response.codeError==7){
											//PAS20221U210700028 - Ajuste de foco												
											document.getElementById("pantallaInicial.numeroBVE").focus();				
                                            document.getElementById('pantallaInicial.numeroBVE').addEventListener('focus',document.getElementById("idSerie").focus(),false);
											//Fin ajuste de foco - PAS20221U210700028	
											mostrarMensaje(""+response.data);
										}else {
										mostrarMensaje(""+response.data);
										document.getElementById("numero").value="";
										document.getElementById("numero").focus();
										}	
								}));
								handler.addErrback(function(response){
									this.waitMessage.hide();
									mostrarMensaje("Ocurrio un error al validar datos del comprobante");
								});
							}else{mostrarMensaje("La serie debe ser numerica"); 
							document.getElementById("serie").value="";
							document.getElementById("numero").value="";
							document.getElementById("serie").focus();}
						}else{mostrarMensaje("la serie debe tener 4 caracteres"); 
						document.getElementById("serie").value="";
						document.getElementById("numero").value="";
						document.getElementById("serie").focus();}
					}else{mostrarMensaje("ingrese la serie"); 
					document.getElementById("serie").value="";
					 document.getElementById("numero").value="";
					 document.getElementById("serie").focus();}
				}else{ mostrarMensaje("El numero debe ser de tipo numerico"); 
				document.getElementById("numero").value="";
				document.getElementById("numero").focus();}
			}else{	mostrarMensaje("El n\xFAmero m\u00E1ximo de caracteres es de 9 d\00EDgitos");
			document.getElementById("numero").value="";
			document.getElementById("numero").focus();}
		 }
		}else{
			mostrarMensaje("Seleccione el establecimiento");
			document.getElementById("numero").value="";
		}
		}else{
			mostrarMensaje("Seleccione la fecha de emisi\u00F3n");
			document.getElementById("numero").value="";
		}
	},	
	
		
	compararBoletasContin: function(idSerie,idSerieNew,numeroBoleta,boletaNew){
		dijit.hideTooltip(dojo.byId("pantallaInicial.numeroBVE"));
		dijit.hideTooltip(dojo.byId("pantallaInicial.numeroNuevaBVE"));
		//var boleta= null;
		//var boleta2= null;
		this.boletaBean=null;
		boleta= dijit.byId("pantallaInicial.numeroBVE").value;
		boleta2= dijit.byId("pantallaInicial.numeroNuevaBVE").value;
		if ( boleta!= ""){
			this.limpiaMontos();
      		this.wait("Consultando", "110px", 200);
    		var handler = dojo.xhrGet({
				url: this.controller + "?action=validarComprobanteContin&TipoNotaCred=" + dijit.byId("pantallaInicial.tipoNotaCredito").value + "&boleta=" + numeroBoleta  + "&boletanew=" + boletaNew+"&idSerie="+idSerie+"&idSerieNew="+idSerieNew,
    			handleAs: "json",
    			preventCache:  true,
    			sync: true,
    			timeout: 10000
    		});
    		handler.addCallback(dojo.hitch(this, function(res){
				dijit.hideTooltip(dojo.byId("pantallaInicial.numeroBVE"));
				this.waitMessage.hide();
				if(res.codeError == 0 || res.codeError == 9) {
					this.boletaBean = eval("(" + res.data + ")");
					this.igvBVE = this.boletaBean.igvPorcentaje;
					this.formateaMontos();
					if (dijit.byId("pantallaInicial.tipoNotaCredito").value != "22") {
						dijit.byId("pantallaInicial.motivoEmisionNC").focus();
					}else{ dijit.byId("pantallaInicial.numeroNuevaBVE").focus(); }	     		 	   
    			} else {
					if(res.codeError == 1){
						this.iconTooltipMessage("pantallaInicial.numeroBVE", "icon-ok-tooltip", res.messageError);
					}else{
					   this.iconTooltipMessage("pantallaInicial.numeroNuevaBVE", "icon-ok-tooltip", res.messageError);
					}
			 
					return;
    			}
    		}));
    		
			handler.addErrback(function(res){
				this.waitMessage.hide();
    			mostrarMensaje("Ocurrio un error al validar la boleta de venta ingresada");
    		});
    			
    		if (dijit.byId("pantallaInicial.tipoNotaCredito").value =="22"){
      		 	if ( boleta2!= ""){
					this.wait("Consultando", "110px", 200);
          			var handler2 = dojo.xhrGet({
          				preventCache:  false,
          				url: this.controller + "?action=comparaBoletasContin&TipoNotaCred=" + dijit.byId("pantallaInicial.tipoNotaCredito").value + "&boleta=" + boleta + "&boletanew=" + boletaNew+"&idSerie="+idSerie+"&idSerieNew="+idSerieNew,
          				handleAs: "json",
          				sync: true,
          				timeout: 10000
          			});
          			handler2.addCallback(dojo.hitch(this, function(res){
          				this.waitMessage.hide();
          				dijit.hideTooltip(dojo.byId("pantallaInicial.numeroNuevaBVE"));
          				if(res.codeError == 0) {
          					
          				} else {
          				    dijit.byId("pantallaInicial.numeroNuevaBVE").focus();
							this.iconTooltipMessage("pantallaInicial.numeroNuevaBVE", "icon-ok-tooltip", res.messageError);
							return;
          				}
          			}));
          			handler2.addErrback(function(res){
          				this.waitMessage.hide();
          				mostrarMensaje("Ocurrio un error al validar la boleta de venta ingresada");
          			});
      		 	}
			}
		}
	},
	
	
	compararBoletas: function(id){
		dijit.hideTooltip(dojo.byId("pantallaInicial.numeroBVE"));
		dijit.hideTooltip(dojo.byId("pantallaInicial.numeroNuevaBVE"));
		var boleta= null;
		var boleta2= null;
		this.boletaBean=null;
		boleta= dijit.byId("pantallaInicial.numeroBVE").value;
		boleta2= dijit.byId("pantallaInicial.numeroNuevaBVE").value;
		if ( boleta!= ""){
			this.limpiaMontos();
      		this.wait("Consultando", "110px", 200);
    		var handler = dojo.xhrGet({
				url: this.controller + "?action=validarComprobante&TipoNotaCred=" + dijit.byId("pantallaInicial.tipoNotaCredito").value + "&boleta=" + boleta  + "&boletanew=" + boleta2
                // INI PAS20211U210100040  AHUISA
                + "&fecEmision=" + dojo.byId("pantallaInicial.fechaEmision").value,
                // FIN PAS20211U210100040  AHUISA
    			handleAs: "json",
    			preventCache:  true,
    			sync: true,
    			timeout: 10000
    		});
    		handler.addCallback(dojo.hitch(this, function(res){
				dijit.hideTooltip(dojo.byId("pantallaInicial.numeroBVE"));
				this.waitMessage.hide();
				if(res.codeError == 0 || res.codeError == 9) {
					this.boletaBean = eval("(" + res.data + ")");
					this.igvBVE = this.boletaBean.igvPorcentaje;
					this.formateaMontos();
					if (dijit.byId("pantallaInicial.tipoNotaCredito").value != "22") {
						dijit.byId("pantallaInicial.motivoEmisionNC").focus();
					}else{ dijit.byId("pantallaInicial.numeroNuevaBVE").focus(); }	     		 	   
    			} else {
					if(res.codeError == 1){
						this.iconTooltipMessage("pantallaInicial.numeroBVE", "icon-ok-tooltip", res.messageError);
					}else{
					   this.iconTooltipMessage("pantallaInicial.numeroNuevaBVE", "icon-ok-tooltip", res.messageError);
					}
			 
					return;
    			}
    		}));
    		
			handler.addErrback(function(res){
				this.waitMessage.hide();
    			mostrarMensaje("Ocurrio un error al validar la boleta de venta ingresada");
    		});
    			
    		if (dijit.byId("pantallaInicial.tipoNotaCredito").value =="22"){
      		 	if ( boleta2!= ""){
					this.wait("Consultando", "110px", 200);
          			var handler2 = dojo.xhrGet({
          				preventCache:  false,
          				url: this.controller + "?action=comparaBoletas&TipoNotaCred=" + dijit.byId("pantallaInicial.tipoNotaCredito").value + "&boleta=" + boleta + "&boletanew=" + boleta2,
          				handleAs: "json",
          				sync: true,
          				timeout: 10000
          			});
          			handler2.addCallback(dojo.hitch(this, function(res){
          				this.waitMessage.hide();
          				dijit.hideTooltip(dojo.byId("pantallaInicial.numeroNuevaBVE"));
          				if(res.codeError == 0) {
          					
          				} else {
          				    dijit.byId("pantallaInicial.numeroNuevaBVE").focus();
							this.iconTooltipMessage("pantallaInicial.numeroNuevaBVE", "icon-ok-tooltip", res.messageError);
							return;
          				}
          			}));
          			handler2.addErrback(function(res){
          				this.waitMessage.hide();
          				mostrarMensaje("Ocurrio un error al validar la boleta de venta ingresada");
          			});
      		 	}
			}
		}
	},
	
	
			validarBoletaNew: function(){
      //var boleta= dijit.byId("pantallaInicial.numeroNuevaBVE").value;
      //var boleta2= dijit.byId("pantallaInicial.numeroBVE").value;
      if ( boleta!= ""){
      
      		this.wait("Consultando", "110px", 200);
    			var handler = dojo.xhrGet({
    				preventCache:  false,
    				url: this.controller + "?action=validarComprobante&TipoNotaCred=" + dijit.byId("pantallaInicial.tipoNotaCredito").value + "&boleta=" + boleta2 + "&boletanew=" + boleta,
    				handleAs: "json",
    				sync: true,
    				timeout: 10000
    			});
    		  this.waitMessage.hide();
    			handler.addCallback(dojo.hitch(this, function(res){
    				dijit.hideTooltip(dojo.byId("pantallaInicial.numeroNuevaBVE"));
    				if(res.codeError == 0) {
    				
    			
    				} else {
                this.iconTooltipMessage("pantallaInicial.numeroNuevaBVE", "icon-ok-tooltip", "Boleta de Venta electr\u00F3nica no ha sido emitida por el contribuyente.");
                return;
    				}
    			}));
    			handler.addErrback(function(res){
    				mostrarMensaje("Ocurrio un error al validar la boleta ingresada.");
    			});
    			
    			 
    			 if (dijit.byId("pantallaInicial.tipoNotaCredito").value =="22"){
      		 	if ( boleta2!= ""){
      		 	     	this.wait("Consultando", "110px", 200);
          			var handler2 = dojo.xhrGet({
          				preventCache:  false,
          				url: this.controller + "?action=comparaBoletas&TipoNotaCred=" + dijit.byId("pantallaInicial.tipoNotaCredito").value + "&boleta=" + boleta2 + "&boletanew=" + boleta,
          				handleAs: "json",
          				sync: true,
          				timeout: 10000
          			});
          			this.waitMessage.hide();
          			handler2.addCallback(dojo.hitch(this, function(res1){
          				dijit.hideTooltip(dojo.byId("pantallaInicial.numeroNuevaBVE"));
          				if(res1.codeError == 0) {
          					this.formateaMontos();
          				} else {
                      this.iconTooltipMessage("pantallaInicial.numeroNuevaBVE", "icon-ok-tooltip", res1.messageError);
                      return;
          				}
          			}));
          			handler2.addErrback(function(res1){
          				mostrarMensaje("Ocurrio un error al validar la boleta de venta ingresada");
          			});
      		 	}
      		} 	
      		 	
      		 	
      }
  },
  
  	/*
	iconTooltipMessage: function(node, iconClass, message) {
		if(dojo.isString(node)) node = dojo.byId(node);
		dijit.focus(node);
		node.focus();
		dijit.showTooltip('<div class="' + iconClass + '"><div>' + message + '</div></div>', node, []);
		//		node._refreshState();
		var blur = dojo.connect(node, "onBlur", function() {
			dijit.hideTooltip(node);
			node._refreshState();
			dojo.disconnect(blur);
		});
	},   
	*/
	
	iconTooltipMessage: function(node, iconClass, message) {
		if(dojo.isString(node)) node = dojo.byId(node);
		dijit.focus(node);
		node.focus();
		dijit.showTooltip('<div class="' + iconClass + '"><div>' + message + '</div></div>', node, []);
        var blur = dojo.connect(node, "onBlur", function() {
			dijit.hideTooltip(node);
			dojo.disconnect(blur);
		});
	},
    // INI PAS20211U210100040  AHUISA
    iconTooltipMessageFec: function(node, iconClass, message) {
        if(dojo.isString(node)) node = dojo.byId(node);
        dijit.focus(node);
        node.focus();
        dijit.showTooltip('<div class="' + iconClass + '"><div>' + message + '</div></div>', node, []);
        var blur = dojo.connect(node, "onblur", function() {
            dijit.hideTooltip(node);
            dojo.disconnect(blur);
        });
    },
    // FIN PAS20211U210100040  AHUISA
	
		sendDocument: function() {
	
  	   if(!dijit.byId("generada.form").validate()){
  	      mostrarMensaje("Debe registrar una direcci\u00F3n de correo v\u00E1lida.");
          return;
       } 
  		if (dojo.trim(dijit.byId("generada.correoUser").getValue()) == "" ) {
  			mostrarMensaje("Por favor ingrese una direcci\u00F3n de correo.");
  			return;
  		}
		
			this.wait("Enviando", "110px", 100);
			var handler = dojo.xhrGet({
				preventCache:  false,
				url: this.controller + "?action=enviarCorreo&correoUser=" + dojo.trim(dijit.byId("generada.correoUser").getValue()),
				handleAs: "json",
				sync: true,
				timeout: 10000
			});
			handler.addCallback(dojo.hitch(this, function(response){
				this.waitMessage.hide();
				if(response.codeError == 0) {
					mostrarMensaje("Se envio correo a la siguiente direcci\u00F3n: " + dijit.byId("generada.correoUser").getValue());
					dijit.byId("generada.correoUser").focus();
				}
				else {
					this.messageBox(res.messageError);
				}
			}));
			handler.addErrback(function(response){
				this.waitMessage.hide();
				this.messageBox("Problemas al conectarse con el servidor");
			});
	},
	
	sendDocumentContin: function() {
	
  	   if(!dijit.byId("generada.form").validate()){
  	      mostrarMensaje("Debe registrar una direcci\u00F3n de correo v\u00E1lida.");
          return;
       } 
  		if (dojo.trim(dijit.byId("generada.correoUser").getValue()) == "" ) {
  			mostrarMensaje("Por favor ingrese una direcci\u00F3n de correo.");
  			return;
  		}
		
			this.wait("Enviando", "110px", 100);
			var handler = dojo.xhrGet({
				preventCache:  false,
				url: this.controller + "?action=enviarCorreoContin&correoUser=" + dojo.trim(dijit.byId("generada.correoUser").getValue()),
				handleAs: "json",
				sync: true,
				timeout: 10000
			});
			handler.addCallback(dojo.hitch(this, function(response){
				this.waitMessage.hide();
				if(response.codeError == 0) {
					mostrarMensaje("Se envi\u00F3 correo a la siguiente direcci\u00F3n: " + dijit.byId("generada.correoUser").getValue());
					dijit.byId("generada.correoUser").focus();
				}
				else {
					this.messageBox(res.messageError);
				}
			}));
			handler.addErrback(function(response){
				this.waitMessage.hide();
				this.messageBox("Problemas al conectarse con el servidor");
			});
	},
	updateAmount: function() {
		if (this.boletaBean==null) return;
    
		/*Inicio SAU20156R120400552*/
		//var moneda = this.boletaBean.codigoMoneda;
		var moneda = this.changeMoneda(this.boletaBean.codigoMoneda);
		/*Fin SAU20156R120400552*/   
    
		dijit.byId("pantallaInicial.descuentoGlobalNC").constraints = {min:0,currency:moneda, places:2};
		dijit.byId("pantallaInicial.ISCNC").constraints = {min:0,currency:moneda, places:2};
		dijit.byId("pantallaInicial.IGVNC").constraints = {min:0,currency:moneda, places:2};
		dijit.byId("pantallaInicial.descuentoGlobalNC").constraints = {min:0,currency:moneda, places:2};
		
		var montoISC = this.boletaBean.totalISC;
        if(montoISC == "" || montoISC=="0.00"){
			dijit.byId("pantallaInicial.ISCNC").attr('disabled', true);
    		dijit.byId("pantallaInicial.ISCNC").attr('value',"");	
    		dijit.byId("pantallaInicial.ISCNC").attr('style',"background-color:lightgray");	
            txtISC=0;
		}else{
			dijit.byId("pantallaInicial.ISCNC").attr('disabled', false);
			dijit.byId("pantallaInicial.ISCNC").attr('style',"background-color:white");	
			txtISC=dijit.byId("pantallaInicial.ISCNC").value;
        }
		
		var montoIGV = this.boletaBean.totalIGV;
        if(montoIGV == "" || montoIGV=="0.00"){
			dijit.byId("pantallaInicial.IGVNC").attr('disabled', true);
    		dijit.byId("pantallaInicial.IGVNC").attr('value',"");
    		dijit.byId("pantallaInicial.IGVNC").attr('style',"background-color:lightgray");
		}else{
			dijit.byId("pantallaInicial.IGVNC").attr('value',"0");	
			dijit.byId("pantallaInicial.IGVNC").attr('style',"background-color:white");
			txtDG =dijit.byId("pantallaInicial.descuentoGlobalNC").value;
			if (txtDG!="" && txtDG!=0 && txtDG!="0.00"){
				dijit.byId("pantallaInicial.IGVNC").attr('value',(txtDG + txtISC)*(this.igvBVE / 100 ) ); //IGV 19                
			}else{
				dijit.byId("pantallaInicial.IGVNC").attr('value',"0");
            }
			dijit.byId("pantallaInicial.IGVNC").attr('disabled', true);
        }
	},
		
	limpiaMontos: function() {
		dijit.byId("pantallaInicial.descuentoGlobalNC").attr('value',"");	
		dijit.byId("pantallaInicial.ISCNC").attr('disabled', true);
	    dijit.byId("pantallaInicial.ISCNC").attr('value',"");	
	    dijit.byId("pantallaInicial.ISCNC").attr('style',"background-color:lightgray");	
        dijit.byId("pantallaInicial.IGVNC").attr('disabled', true);
	    dijit.byId("pantallaInicial.IGVNC").attr('value',"");		
	    dijit.byId("pantallaInicial.IGVNC").attr('style',"background-color:lightgray");		
    },
    
	formateaMontos: function() {
	 var txtDG =dijit.byId("pantallaInicial.descuentoGlobalNC").value;
	 var txtISC=0;
	 var txtIGV=0;
	 
	     if (this.boletaBean.codigoMoneda == null){
           	dijit.byId("pantallaInicial.ISCNC").attr('disabled', true);
	          dijit.byId("pantallaInicial.ISCNC").attr('value',"");	
	          dijit.byId("pantallaInicial.ISCNC").attr('style',"background-color:lightgray");
            dijit.byId("pantallaInicial.IGVNC").attr('disabled', true);
	          dijit.byId("pantallaInicial.IGVNC").attr('value',"");		
	          dijit.byId("pantallaInicial.IGVNC").attr('style',"background-color:lightgray");	
	          return;
       }
	 
                /*Inicio SAU20156R120400552*/
                //var moneda = this.boletaBean.codigoMoneda;
                var moneda = this.changeMoneda(this.boletaBean.codigoMoneda);
                /*Fin SAU20156R120400552*/
                
        		 	  dijit.byId("pantallaInicial.descuentoGlobalNC").constraints = {min:0,currency:moneda, places:2};
            		dijit.byId("pantallaInicial.ISCNC").constraints = {min:0,currency:moneda, places:2};
            		dijit.byId("pantallaInicial.IGVNC").constraints = {min:0,currency:moneda, places:2};
            		dijit.byId("pantallaInicial.descuentoGlobalNC").constraints = {min:0,currency:moneda, places:2};
            		var montoISC = this.boletaBean.totalISC;
            		if(montoISC == "" || montoISC=="0.00"){
                		dijit.byId("pantallaInicial.ISCNC").attr('disabled', true);
    			          dijit.byId("pantallaInicial.ISCNC").attr('value',"");	
    			          dijit.byId("pantallaInicial.ISCNC").attr('style',"background-color:lightgray");	
                    txtISC=0;
			          }else{
			              dijit.byId("pantallaInicial.ISCNC").attr('disabled', false);
			              dijit.byId("pantallaInicial.ISCNC").attr('style',"background-color:white");	
			              txtISC=dijit.byId("pantallaInicial.ISCNC").value;
                }
            		
            		
            		var montoIGV = this.boletaBean.totalIGV;
            		if(montoIGV == "" || montoIGV=="0.00"){
            		    dijit.byId("pantallaInicial.IGVNC").attr('disabled', true);
    			          dijit.byId("pantallaInicial.IGVNC").attr('value',"");		
    			          dijit.byId("pantallaInicial.IGVNC").attr('style',"background-color:lightgray");
			          }else{
			              dijit.byId("pantallaInicial.IGVNC").attr('value',"0");	
			              dijit.byId("pantallaInicial.IGVNC").attr('style',"background-color:white");
			              txtDG =dijit.byId("pantallaInicial.descuentoGlobalNC").value;
			              if (txtDG!="" && txtDG!=0 && txtDG!="0.00"){
			                 dijit.byId("pantallaInicial.IGVNC").attr('value',(txtDG + txtISC)*(this.igvBVE / 100 ) ); //IGV 19
                    }else{
                        dijit.byId("pantallaInicial.IGVNC").attr('value',"0");
                    }
                    dijit.byId("pantallaInicial.IGVNC").attr('disabled', true);
                }   
                		
	},	
  	
	downloadDocument: function() {
		var formArchivo = dojo.byId("formArchivo");
		formArchivo.submit();
	},
	//PAS20211U210100010 -- Inicio  
	downloadPdfNCDocument: function() {
		var formPdfnc = dojo.byId("formDownloadNCBoletapdf");
		formPdfnc.submit();
	},
	//PAS20211U210100010 -- Fin
	
	printDocument: function() {
		window.open(this.controller + "?action=imprimirComprobante&preventCache=" + this.preventCache(), "imprimeCP" , "toolbar=0,location=0,directories=0,status=no,menubar=0,scrollbars=yes,resizable=yes,width=820,height=580,titlebar=no");
	},
	
	closeDocumentInicial: function() {
		dijit.hideTooltip(dojo.byId("pantallaInicial.numeroBVE"));
		dijit.hideTooltip(dojo.byId("pantallaInicial.numeroNuevaBVE"));
    
    mostrarMensajeConfirmacion("\u00BFDesea emitir otra Nota de Cr\u00E9dito?", dojo.hitch(this, function(){
		  	this.closeDocument();
      }));
    
		/**PAS20211U210600213 - ajustes navegador 
    if (confirm("\u00BFDesea emitir otra Nota de Cr\u00E9dito?")) {
			this.closeDocument();
		}*/    
    
	},
	closeDocumentInicialGenerada: function() {
		dijit.hideTooltip(dojo.byId("pantallaInicial.numeroBVE"));
		dijit.hideTooltip(dojo.byId("pantallaInicial.numeroNuevaBVE"));
    
      mostrarMensajeConfirmacion("Debe haber otorgado la Nota de Cr\u00E9dito mediante su impresi\u00F3n en papel o remitido a trav\u00E9s de Correo Electr\u00F3nico. \u00BFDesea emitir otra Nota de Cr\u00E9dito?", dojo.hitch(this, function(){
		  	this.closeDocument();
      }));        
		    
    /**PAS20211U210600213 - ajustes navegador 
     if (confirm("Debe haber otorgado la Nota de Cr\u00E9dito mediante su impresi\u00F3n en papel o remitido a trav\u00E9s de Correo Electr\u00F3nico. \u00BFDesea emitir otra Nota de Cr\u00E9dito?")) {
			this.closeDocument();
		 }
     */     
    
	},
	wait: function(message, width) {
		dojo.byId("waitMessage").innerHTML="<div class='dijitInline box-message'></div><div class='dijitInline'>&nbsp;" + message + "...</div>";
	    dojo.byId("waitMessage").style.width = width;
	    this.waitMessage.show();
	},
		
	onFocus: function(id){
		var dato = dojo.byId(id).value;    
		dijit.byId(id).attr('value',"");    
		dijit.byId(id).attr('value',dojo.trim(dato));	
	},
  
		backInicio: function() {
			
			dijit.hideTooltip(dojo.byId("numeroComprobante"));
			//this.content.onLoad = dojo.hitch(this, function(){
			//	this.initContent();
			//});
			this.content.setHref(this.controller + "?action=mostrarPantallaInicialConDatos&mode=hidden");
  		this.content.onLoad = dojo.hitch(this, function(){
  		this.showOpcionesPorTipoNCBVE();
			this.formateaMontos();});
	  },
	
   
	iconEdit25: function(rowindex) {
		return "<a href=\"#\" title=\"Editar\" onclick=\"notaCreditoBVE.editItem25(" + rowindex + ")\"><img class=\"icon-by-edit16\" src=\"/a/imagenes/see/icons/edit.gif\"/></a>"; 
	},
	  
    	
	iconEdit26: function(rowindex) {
      var grilla =dijit.byId('ncCambioDetalles.ingreso-grid');
      var datos =grilla.store._arrayOfAllItems;
        var fila = grilla.getItem(rowindex-1);
        var valorModif= grilla.store.getValue(fila, "valorVtaUnitarioOriginal");
        valorModif = valorModif.replace(',','');
        if (valorModif< 0){ 
            return "";
        }else{
           return "<a href=\"#\" title=\"Editar\" onclick=\"notaCreditoBVE.editItem26(" + rowindex + ")\"><img class=\"icon-by-edit16\" src=\"/a/imagenes/see/icons/edit.gif\"/></a>";
        }
     
     
	   },
     	
		iconEdit27: function(rowindex) {
		
    
      var grilla =dijit.byId('ncCambioDetalles.ingreso-grid');
      var datos =grilla.store._arrayOfAllItems;
        var fila = grilla.getItem(rowindex-1);
        var valorModif= grilla.store.getValue(fila, "valorVtaUnitarioOriginal");
        valorModif = valorModif.replace(',','');
        if (valorModif< 0){ 
            return "";
        }else{
           return "<a href=\"#\" title=\"Editar\" onclick=\"notaCreditoBVE.editItem27(" + rowindex + ")\"><img class=\"icon-by-edit16\" src=\"/a/imagenes/see/icons/edit.gif\"/></a>";
        }
          
	   },
      
    //Descuento por Item
    editItem27: function(identificador) {	    
		store =dijit.byId('ncCambioDetalles.ingreso-grid').store;       
		store.fetchItemByIdentity({
			identity: identificador,
		    onItem : function(item, request) {
				row = item;		
				currentLine = identificador 	;		
		    },
		    onError : function(item, request) {
				mostrarMensaje("Ocurrio un error al ubicar el documento");
				return;				
		    }
		});
		console.log(row);
		var descripcionItem=dojo.trim(store.getValue(row, "descripcion"));
		/*var buscar="[*****] BONIFICACION [*****]";
		if (descripcionItem.search(buscar)!=-1 ){
			alert("No se puede editar un item de bonificaci\u00F3n.");
			return;		
		}*/
		bCargando= true;
		var otrosCargosTributos=dojo.trim(store.getValue(row, "otrosCargosTributosOriginal"));
		if (otrosCargosTributos != "" && otrosCargosTributos !=null  && otrosCargosTributos !="0.00"){
			mostrarMensaje("No podr\u00E1 seleccionarse un \u00EDtem que es Cargo o Tributo.");
			return;	
        }
      
      	var operacionGratuita=dojo.trim(store.getValue(row, "tipoBonificacion"));
		if (operacionGratuita == "BO01" ){
			mostrarMensaje("No podr\u00E1 seleccionarse un \u00EDtem que es Gratuito");
			return;	
        }
		
        /*Inicio SAU20156R120400552*/
        var moneda = this.boletaBean.codigoMoneda;          
        //var moneda = this.changeMoneda(this.boletaBean.codigoMoneda);
        /*Fin SAU20156R120400552*/
		dijit.byId("item27.botonAceptar").attr('disabled', false);
							
		this.dialogItem27.attr('title', "Captura NC - Descuento por Item");
		dojo.byId("item27.idItem").value = currentLine ; //store.getValue(row, "identificador");
	  	dojo.byId("item27.precioUnitarioOriginal").value =store.getValue(row, "precioUnitarioOriginal");
	  	dojo.byId("item27.descuentosOriginal").value =store.getValue(row, "descuentosOriginal");
	  	dojo.byId("item27.precioUnitario").value =store.getValue(row, "precioUnitario");
		dijit.byId("item27.unidadMedida").setValue(store.getValue(row, "unidadMedidaDesc"));						
        dojo.byId("item27.iscMontoOriginal").value=store.getValue(row, "iscMontoOriginal");	
		//dijit.byId("item27.cantidad").setValue(store.getValue(row, "cantidad"), false);
		dijit.byId("item27.descripcion").setValue(store.getValue(row, "descripcion"));
		dijit.byId("item27.igvPorcentaje").setValue(store.getValue(row, "igvPorcentaje"));
		
		//INI: PAS20191U210100075    
		var montoIcbPer = store.getValue(row, "icbPerMonto");
		if(store.getValue(row, "esImpuestoBolsaPlastico") == "IBP00"){
		
			//this.showHiddenDiv(document.getElementById("item.ICBPER1.show"),false); //ocultar si es nrus
			//this.showHiddenDiv(document.getElementById("item.ICBPER2.show"),false); //ocultar si es nrus
			dijit.byId("item27.cantidad").constraints = {min:0,places:0};
			dijit.byId("item27.cantidad").attr('value',this.round(store.getValue(row, "cantidad"), 0));		  
		}else{
			//this.showHiddenDiv(document.getElementById("item.ICBPER1.show"),true); //mostrar si no es nrus
			//this.showHiddenDiv(document.getElementById("item.ICBPER2.show"),true); //mostrar si no es nrus
			dijit.byId("item27.impuestoICBPER").constraints = {min:0,currency:moneda, places:2};//PAS20191U210100075
			dijit.byId("item27.impuestoICBPER").attr('value',store.getValue(row, "icbPerMonto"));//PAS20191U210100075
		  //dijit.byId("item27.impuestoICBPER").setValue(store.getValue(row, "icbPerMonto"));//PAS20191U210100075 
		  
		  //dojo.byId("item26.tasaBolsaGlobal").value =store.getValue(row, "icbTasa");//PAS20191U210100075    
			dijit.byId("item27.cantidad").constraints = {min:0.0000000001, places:'2,10',pattern:'########.00########'}
			dijit.byId("item27.cantidad").attr('value',this.round(store.getValue(row, "cantidad"), 2), 0);			  
		}
		//FIN: PAS20191U210100075
		
		if (store.getValue(row, "modificado") =="0"){					
			dijit.byId("item27.descuentos").constraints = {min:0,currency:moneda, places:10};
  			dijit.byId("item27.descuentos").attr('value',"0.0000000000");					
  			//ISC
  			dijit.byId("item27.iscMonto").constraints = {min:0,currency:moneda, places:2};
        	var montoISC = store.getValue(row, "iscMontoOriginal");
        	if(montoISC == "" || montoISC=="0.00"){
				dijit.byId("item27.iscMonto").attr('disabled', true);
  		        dijit.byId("item27.iscMonto").attr('value',"");	
  		        dijit.byId("item27.iscMonto").attr('style',"background-color:lightgray");	
			}else{
                dijit.byId("item27.iscMonto").attr('disabled', false);
                dijit.byId("item27.iscMonto").attr('style',"background-color:white");	
                dijit.byId("item27.iscMonto").attr('value',"0");
            }
            
            //IGV                      		
  			dijit.byId("item27.precioConIGV").constraints = {min:0,currency:moneda, places:2};
        	var montoIGV = store.getValue(row, "igvMonto");
        	if(montoIGV == "" || montoIGV=="0.00"){
				dijit.byId("item27.igvPorcentaje").setValue(0.00);
            	dijit.byId("item27.precioConIGV").attr('disabled', true);
  		        dijit.byId("item27.precioConIGV").attr('value',"");	
  		        dijit.byId("item27.precioConIGV").attr('style',"background-color:lightgray");	
            }else{
                dijit.byId("item27.precioConIGV").attr('disabled', false);
                dijit.byId("item27.precioConIGV").attr('style',"background-color:white");	
                dijit.byId("item27.precioConIGV").attr('value',"0");
            }
  			dijit.byId("item27.importeVenta").constraints = {min:0,currency:moneda, places:2};
  			dijit.byId("item27.importeVenta").attr('value',"0");
		}else{				  
  			dijit.byId("item27.descuentos").constraints = {min:0,currency:moneda, places:10};
  			dijit.byId("item27.descuentos").attr('value',store.getValue(row, "descuentos"));
  			//ISC
  			dijit.byId("item27.iscMonto").constraints = {min:0,currency:moneda, places:2};
        	var montoISC = store.getValue(row, "iscMonto");
        	if(montoISC == "" || montoISC=="0.00" || montoISC==undefined || dijit.byId("item27.iscMonto").getValue()=="0"){ //PAS20191U210100075
				dijit.byId("item27.iscMonto").attr('disabled', true);
  		        dijit.byId("item27.iscMonto").attr('value',"");	
  		        dijit.byId("item27.iscMonto").attr('style',"background-color:lightgray");	
            }else{
                dijit.byId("item27.iscMonto").attr('disabled', false);
                dijit.byId("item27.iscMonto").attr('style',"background-color:white");	
                dijit.byId("item27.iscMonto").attr('value',montoISC);
            }
              					
            //IGV                      		
  			dijit.byId("item27.precioConIGV").constraints = {min:0,currency:moneda, places:2};
        	var montoIGV = store.getValue(row, "igvMonto");
        	if(montoIGV == "" || montoIGV=="0.00"){
				dijit.byId("item27.igvPorcentaje").setValue(0.00);
            	dijit.byId("item27.precioConIGV").attr('disabled', true);
  		        dijit.byId("item27.precioConIGV").attr('value',"");	
  		        dijit.byId("item27.precioConIGV").attr('style',"background-color:lightgray");	
            }else{
                dijit.byId("item27.precioConIGV").attr('disabled', false);
                dijit.byId("item27.precioConIGV").attr('style',"background-color:white");	
                dijit.byId("item27.precioConIGV").attr('value',montoIGV);
            }  
  				
  			dijit.byId("item27.importeVenta").constraints = {min:0,currency:moneda, places:2};  
            dijit.byId("item27.importeVenta").attr('value', store.getValue(row, "importeVenta"));           
		}
		bCargando= false;
		this.dialogItem27.show();		
	},
		
	updateItemAmount27: function() {
		var cantidad=0;
		var igvPorcentaje = 0;
		var cantidadXPrecio = 0;
		var iscMonto = 0;
		var igvMonto = 0;
		var otroMonto = 0;
		var otroTributo = 0;
		var totalItem = 0;
		var descuentos =0;
		var impuestoICBPER=0;//PAS20191U210100075
		var tasaBolsa = 0;//PAS20191U210100075
		if (bCargando == true) {return;}
		
		igvPorcentaje = dijit.byId("item27.igvPorcentaje").getValue();    //IGV 19 
		//PAS20191U210100075
		var valOpcionImpuestoBolsaPlastica = this.getValorOpcionImpuestoBolsaPlastica();
		if (valOpcionImpuestoBolsaPlastica != "IBP00"){ //NO > IMPUESTO BOLSAS;
			dijit.byId("item27.cantidad").constraints = {min:0,places:2};;
			dijit.byId("item27.cantidad").attr('value',dijit.byId("item27.cantidad").getValue());
			
		}else{ // SI IMPUESTO BOLSAS				
			dijit.byId("item27.cantidad").constraints = {min:0,places:0};
			dijit.byId("item27.cantidad").attr('value',dijit.byId("item27.cantidad").getValue());
		}
		cantidad=dijit.byId("item27.cantidad").getValue(); //PAS20191U210100075 01.08
		//cantidad=dijit.byId("item27.cantidad").value;
		//PAS20191U210100075
		/*Inicio SAU20156R120400552*/
		//var moneda = this.boletaBean.codigoMoneda;
		var moneda = this.changeMoneda(this.boletaBean.codigoMoneda);
		/*Fin SAU20156R120400552*/
		descuentos =dijit.byId("item27.descuentos").getValue();
		cantidadXPrecio = cantidad * descuentos;		
		iscMonto = dijit.byId("item27.iscMonto").getValue();
		if (isNaN(iscMonto)){ iscMonto = 0;}		
		igvMonto = dijit.byId("item27.precioConIGV").getValue();
		
		if (isNaN(igvMonto) || (dijit.byId("item27.igvPorcentaje").getValue() ==0)){ 
			igvMonto = 0;
		}else{
		   //igvMonto = ((cantidadXPrecio + iscMonto)* igvPorcentaje);
		   igvMonto = ((descuentos + iscMonto)* igvPorcentaje);
		}
		
		//IMPORTE DE VENTA=((VALOR UNITARIO)*CANTIDAD)-(DESCUENTOS)+(IGV)+(ISC MONTO)+(OTROS CARGOS)
		//totalItem =cantidadXPrecio + igvMonto + iscMonto;
		totalItem =descuentos + igvMonto + iscMonto;
		
		//INI: PAS20191U210100075
		tasaBolsa = dojo.byId("item26.impuestoICBPER").value; 
		
		var monedadesc = this.boletaBean.descripcionMoneda;
		
		if(monedadesc !="SOLES"){
			
			impuestoICBPER = dijit.byId("item27.igvPorcentaje").getValue();
		}else{
			impuestoICBPER = cantidad * tasaBolsa;
			
		}
		
		
		
		
		dijit.byId("item27.impuestoICBPER").attr('value',dojo.currency.format(impuestoICBPER, {currency: moneda, places: 2}));
		totalItem  = totalItem + impuestoICBPER;
		//FIN: PAS20191U210100075
		
		dijit.byId("item27.descuentos").attr('value',dojo.currency.format(dijit.byId("item27.descuentos").getValue(), {currency: moneda, places: 10}));		
		dijit.byId("item27.precioConIGV").attr('value',dojo.currency.format(igvMonto, {currency: moneda, places: 2}));
		dijit.byId("item27.iscMonto").attr('value',dojo.currency.format(iscMonto, {currency: moneda, places: 2}), false);
		dijit.byId("item27.importeVenta").attr('value',dojo.currency.format(totalItem, {currency: moneda, places: 2}));	
        dijit.hideTooltip(dojo.byId("item27.descuentos"));
		dijit.hideTooltip(dojo.byId("item27.iscMonto"));		
	},	
	acceptDialogItem27: function() {
		/*Inicio SAU20156R120400552*/
		//var moneda = this.boletaBean.codigoMoneda;
		var moneda = this.changeMoneda(this.boletaBean.codigoMoneda);
		/*Fin SAU20156R120400552*/
		var otrosTributosOriginal = this.boletaBean.totalOtrosTributos;       
		
    	if (dijit.byId("item27.descuentos").getValue() == "" ) {
			var node = dijit.byId("item27.descuentos");
			this.iconTooltipMessage(node.focusNode,"icon-ok-tooltip", "Debe consignarse descuentos.");				
			node.constraints = {min:0,currency:moneda, places:10};
			return;
		}	
		if (dijit.byId("item27.descuentos").getValue() <= 0 ) {
			var node = dijit.byId("item27.descuentos");
			this.iconTooltipMessage(node.focusNode,"icon-ok-tooltip", "Descuentos debe ser mayor a 0.");			
			node.constraints = {min:0,currency:moneda, places:10};
			return;
		}	
			
		//if (dijit.byId("item27.descuentos").getValue() >= dojo.number.parse(dojo.byId("item27.precioUnitarioOriginal").value )) {
		if (dijit.byId("item27.descuentos").getValue() >= ((dojo.number.parse(dojo.byId("item27.precioUnitarioOriginal").value )*dojo.byId("item27.cantidad").value ) - (store.getValue(row, "descuentosOriginal"))) ) {
			var node = dijit.byId("item27.descuentos");
			this.iconTooltipMessage(node.focusNode,"icon-ok-tooltip", "Descuentos debe ser menor al precio unitario por la cantidad menos los descuentos del item de la BVE respecto de la cual se emitir\u00E1 la Nota de Cr\u00E9dito.");				
			node.constraints = {min:0,currency:moneda, places:10};
			return;
		}				
		
		if (dijit.byId("item27.iscMonto").attr('disabled') == false){
        	if (dijit.byId("item27.iscMonto").getValue() == "" ) {
  				var node = dijit.byId("item27.iscMonto");
  				this.iconTooltipMessage(node.focusNode,"icon-ok-tooltip", "Debe consignarse ISC.");  					
  				node.constraints = {min:0,currency:moneda, places:2};
  				return;
  			}	      
        	
			if (dijit.byId("item27.iscMonto").getValue() <= 0 ) {
  				var node = dijit.byId("item27.iscMonto");
  				this.iconTooltipMessage(node.focusNode,"icon-ok-tooltip", "ISC debe ser mayor que 0.");  					
  				node.constraints = {min:0,currency:moneda, places:2};
  				return;
  			}	
  				
  			if (dijit.byId("item27.iscMonto").getValue() >= dijit.byId("item27.descuentos").getValue()) {
  				var node = dijit.byId("item27.iscMonto");
  				this.iconTooltipMessage(node.focusNode,"icon-ok-tooltip", "ISC debe ser menor que los descuentos.");  					
  				node.constraints = {min:0,currency:moneda, places:10};
  				return;
  			}	
 
   			if (dijit.byId("item27.iscMonto").getValue() >= dojo.number.parse(dojo.byId("item27.iscMontoOriginal").value )) {
  				var node = dijit.byId("item27.iscMonto");
  				this.iconTooltipMessage(node.focusNode,"icon-ok-tooltip", "ISC debe ser menor que el monto del ISC original.");  					
  				node.constraints = {min:0,currency:moneda, places:2};
  				return;
  			}
		}
		if(dijit.byId("item27.importeVenta").getValue() > dojo.number.parse(dojo.byId("item27.precioUnitarioOriginal").value )){
		//if(dijit.byId("item27.importeVenta").getValue() > store.getValue(row, "importeVentaOriginal")){
			var node = dijit.byId("item27.importeVenta");
   			this.iconTooltipMessage(node.focusNode,"icon-ok-tooltip", "Importe de venta debe ser menor que el importe de venta del item respectivo de la Boleta de Venta Original");
  			return;     
		}
		if(!dijit.byId("item27.form").validate()) return;
		///
		var nbControl = dijit.byId("item27.botonAceptar");
		nbControl.setAttribute('disabled', true);
		var nodeButton = nbControl.focusNode;
		var mode = dojo.byId("item27.action").value;
		this.wait("Editando", "95px", 200);	
  		var handler = dojo.io.iframe.send({
  			url: this.controller,
  			handleAs: "json",
  			sync: true,
  			timeout: 10000,
  			preventCache: true,
  			form: "item27.form"
  		});
		
		handler.addCallback(dojo.hitch(this, function(res){
			this.waitMessage.hide();
			if(res.codeError == 0) {
				store.fetchItemByIdentity({
					identity: currentLine,
					onItem: dojo.hitch(this, function(item){
						store.setValue(item,'descuentos',dojo.byId("item27.descuentos").value );
						store.setValue(item,'precioUnitario',dojo.byId("item27.descuentos").value );
						if (dojo.byId("item27.iscMonto").value != ""){	store.setValue(item,'iscMonto',dojo.byId("item27.iscMonto").value ); }
						if (dojo.byId("item27.precioConIGV").value != ""){	store.setValue(item,'igvMonto',dojo.byId("item27.precioConIGV").value );}
						store.setValue(item,'modificado',"1");
						store.setValue(item,'importeVenta',dojo.byId("item27.importeVenta").value);        			
					}),
					onError: function(){}
				});
						
				var grid = dijit.byId('ncCambioDetalles.ingreso-grid');
				grid.setStore(store);
				grid.update();
				this.closeDialogItem27();
			} else {
				nbControl.setAttribute('disabled', false);
				this.iconTooltipMessage(nodeButton, "icon-error-tooltip", res.messageError);
			}
		}));
		handler.addErrback(dojo.hitch(this, function(res) {
			nbControl.setAttribute('disabled', false);
			this.waitMessage.hide();
			this.iconTooltipMessage(nodeButton, "icon-error-tooltip", res.messageError);
		}));
		
		nbControl.setAttribute('disabled', false);			
		dijit.hideTooltip(dojo.byId("item27.descuentos"));
		dijit.hideTooltip(dojo.byId("item27.descuentos"));
		dijit.hideTooltip(dojo.byId("item27.iscMonto"));
    },    
    
    closeDialogItem27: function() {
        dijit.hideTooltip(dojo.byId("item27.descuentos"));
		dijit.hideTooltip(dojo.byId("item27.descuentos"));
		dijit.hideTooltip(dojo.byId("item27.iscMonto"));
		 this.dialogItem27.hide();
	},
	
	round: function(num, decimals) {
		var n = Math.pow(10, decimals);
        return Math.round((n * num).toFixed(decimals))/n;
	},
	
	remove: function(number) {
		var allowDecimals = 10;
		if (isNaN(number)){
			return;
		}
		for (var i=-8; i<=-1; i++){
			var zerosString = "";
			for (var j=1; j<=Math.abs(i); j++){
				zerosString = zerosString + "0";
			}
			if (number.substr(i) == zerosString){
				number = parseFloat(number).toFixed(allowDecimals - Math.abs(i));
				return number;
				break;
			}
		}
		number = parseFloat(number).toFixed(10);
		return number;
	},
	
	roundTenDecimalAux: function(id,value,tipoMoneda){
		var moneyAux = 	dojo.currency.format(0.00, {currency: tipoMoneda});
		moneyAux = moneyAux.replace("0.00",value);
		dijit.byId(id).setValue(moneyAux);
	},
	  
	//Devolucion por Item
    editItem26: function(identificador) {
    	store =dijit.byId('ncCambioDetalles.ingreso-grid').store;
        store.fetchItemByIdentity({
		    identity: identificador,
		    onItem : function(item, request) {
		        row = item;		
            currentLine = identificador 	;		
		    },
		    onError : function(item, request) {
				mostrarMensaje("Ocurrio un error al ubicar el documento");
				return;				
		    }
		});
		   
		console.log(row);
		var descripcionItem=dojo.trim(store.getValue(row, "descripcion"));
		var buscar="[*****] BONIFICACION [*****]";
		var esBonificacion = false;
		if (descripcionItem.search(buscar)!=-1 ){
			esBonificacion = true;	
		}
		
		bCargando= true;
		dijit.byId("item26.descuentos").attr('value',"");	
		dijit.byId("item26.precioConIGV").attr('value',"");	
		dijit.byId("item26.iscMonto").attr('value',"");			    
		var otrosCargosTributos=dojo.trim(store.getValue(row, "otrosCargosTributosOriginal"));
		if (otrosCargosTributos != "" && otrosCargosTributos !=null  && otrosCargosTributos !="0.00"){
		    mostrarMensaje("No podr\u00E1 seleccionarse un \u00EDtem que es Cargo o Tributo.");
			return;	
        }
		/*Inicio SAU20156R120400552*/
		//var moneda = this.boletaBean.codigoMoneda;
		var moneda = this.changeMoneda(this.boletaBean.codigoMoneda);
		var monedadesc = this.boletaBean.descripcionMoneda; //PAS20191U210100075
		/*Fin SAU20156R120400552*/
		dijit.byId("item26.botonAceptar").attr('disabled', false);
							
		this.dialogItem26.attr('title', "Captura NC - Devoluci\u00F3n por Item");
		dojo.byId("item26.idItem").value = currentLine ; //store.getValue(row, "identificador");
	  	dojo.byId("item26.precioUnitarioOriginal").value =store.getValue(row, "precioUnitarioOriginal");
	  	dojo.byId("item26.descuentosOriginal").value =store.getValue(row, "descuentosOriginal");
	  	dojo.byId("item26.valorVtaUnitarioOriginal").value =store.getValue(row, "valorVtaUnitarioOriginal");
		dijit.byId("item26.unidadMedida").setValue(store.getValue(row, "unidadMedidaDesc"));						
		dojo.byId("item26.iscMontoOriginal").value =store.getValue(row, "iscMontoOriginal");
        dojo.byId("item26.otrosCargosOriginal").value =store.getValue(row, "otrosCargosOriginal");
		
		//dijit.byId("item26.cantidad").setValue(store.getValue(row, "cantidad"), false);
		//dijit.byId("item26.cantidad").setValue(dojo.trim(dojo.currency.format(store.getValue(row, "cantidad")), {places: '2,10'}));
		dijit.byId("item26.descripcion").setValue(dojo.trim(store.getValue(row, "descripcion")));
		dijit.byId("item26.igvPorcentaje").setValue(store.getValue(row, "igvPorcentaje"));
				
		//INI: PAS20191U210100075  
		var montoIcbPer = store.getValue(row, "icbPerMonto");
		dijit.byId("item26.impuestoBolsasPlastica00").setAttribute('disabled', true);
		dijit.byId("item26.impuestoBolsasPlastica01").setAttribute('disabled', true);
		
		console.log(monedadesc);
		if(monedadesc !="SOLES" && !(montoIcbPer == "" || montoIcbPer=="0")){
			dijit.byId("item26.impuestoICBPER").setAttribute('readOnly', false);
		}else{
			dijit.byId("item26.impuestoICBPER").setAttribute('readOnly', true);
		}
		
		
		if(store.getValue(row, "esImpuestoBolsaPlastico") != "IBP00"){
			dijit.byId("item26.impuestoBolsasPlastica00").setAttribute('disabled', true);
			dijit.byId("item26.impuestoBolsasPlastica01").setAttribute('disabled', true);
			dijit.byId("item26.impuestoBolsasPlastica01").setChecked("checked");
			dojo.byId("item26.tasaBolsaGlobal").value =store.getValue(row, "icbTasa");//PAS20191U210100075
			dijit.byId("item26.impuestoICBPER").constraints = {min:0,currency:moneda, places:2};//PAS20191U210100075
			dijit.byId("item26.impuestoICBPER").attr('value',store.getValue(row, "icbPerMonto"));//PAS20191U210100075
			this.showHiddenDiv(document.getElementById("item26.ICBPER1.show"),false); 
			this.showHiddenDiv(document.getElementById("item26.ICBPER2.show"),false);			
		
			dijit.byId("item26.tasaBolsa").constraints = {min:0,currency:moneda, places:2};//PAS20191U210100075
			dijit.byId("item26.tasaBolsa").attr('value',"0");//PAS20191U210100075
			
			dijit.byId("item26.periodoBolsa").attr('value',"");//PAS20191U210100075
			
			//dijit.byId("item26.cantidad").setValue(dojo.trim(dojo.currency.format(store.getValue(row, "cantidad")), {places: '2,10'})); /* PAS20211U210100007 */
			dijit.byId("item26.cantidad").setValue(dojo.trim(store.getValue(row, "cantidad"))); /* PAS20211U210100007 */
		}else{
			dijit.byId("item26.impuestoBolsasPlastica00").setChecked("checked");
		  
			dojo.byId("item26.tasaBolsaGlobal").value =store.getValue(row, "icbTasa");//PAS20191U210100075
	
			dijit.byId("item26.impuestoICBPER").constraints = {min:0,currency:moneda, places:2};//PAS20191U210100075
			dijit.byId("item26.impuestoICBPER").attr('value',store.getValue(row, "icbPerMonto"));//PAS20191U210100075	
			//dijit.byId("item26.impuestoICBPER").attr('value',dojo.currency.format(store.getValue(row, "icbPerMonto"), {currency: moneda, places: 2}));    
			this.showHiddenDiv(document.getElementById("item26.ICBPER1.show"),true); 
			this.showHiddenDiv(document.getElementById("item26.ICBPER2.show"),true);
			
			
			dijit.byId("item26.tasaBolsa").constraints = {min:0,currency:moneda, places:2};//PAS20191U210100075
			dijit.byId("item26.tasaBolsa").attr('value',store.getValue(row, "icbTasa"));//PAS20191U210100075
			
			var parts2 = store.getValue(row, "icbfechaemision").split('/');	
			
			
			document.getElementById("item26.periodoBolsa").value = parts2[2];
			//dijit.byId("item26.periodoBolsa").attr('value',parts2[2]);//PAS20191U210100075
		
			//dijit.byId("item26.cantidad").setValue(dojo.trim(store.getValue(row, "cantidad"))); /* PAS20211U210100007 */
			dijit.byId("item26.cantidad").setValue(dojo.trim(dojo.currency.format(store.getValue(row, "cantidad")), {places: '2,10'}));
			//dijit.byId("item26.cantidad").setValue(Number(store.getValue(row, "cantidad")).toFixed(0), false);
			//dijit.byId("item26.cantidad").setValue(dojo.trim(store.getValue(row, "cantidad"))); /* PAS20211U210100007 */
		}
		//FIN: PAS20191U210100075	
				
		if (store.getValue(row, "modificado") =="0"){
			//dijit.byId("item26.precioUnitario").constraints = {currency:moneda, places:'2,10'};
			dojo.byId("item26.precioUnitario").value= dojo.trim(store.getValue(row, "valorVtaUnitarioOriginal"));
			//dojo.byId("item26.precioUnitario").value= dojo.number.format(dojo.byId("item26.precioUnitario").value,{currency:moneda, places:'2,10'}); /* PAS20211U210100007 */
			dojo.byId("item26.precioUnitario").value= dojo.number.format(dijit.byId("item26.precioUnitario").getValue(),{currency:moneda, places:'2,10'}); /* PAS20211U210100007 */
			//descuentos
			dijit.byId("item26.descuentos").constraints = {min:0,currency:moneda, places:2};
			var montoDescuentos = store.getValue(row, "descuentosOriginal");
        	if(montoDescuentos == "" || montoDescuentos=="0.00" || montoDescuentos=="0"){
				dijit.byId("item26.descuentos").attr('disabled', true);
  		        dijit.byId("item26.descuentos").attr('value',"");	
  		        dijit.byId("item26.descuentos").attr('style',"background-color:lightgray");	
            }else{
                dijit.byId("item26.descuentos").attr('disabled', false);
                dijit.byId("item26.descuentos").attr('style',"background-color:white");	
                dijit.byId("item26.descuentos").attr('value',"0");
            }
            					
  			//ISC
  			dijit.byId("item26.iscMonto").constraints = {min:0,currency:moneda, places:2};
        	var montoISC = store.getValue(row, "iscMontoOriginal");
        	if(montoISC == "" || montoISC=="0.00" || (isNaN(montoISC) && montoISC.indexOf(" 0.00") > -1)){
            	dijit.byId("item26.iscMonto").attr('disabled', true);
  		        dijit.byId("item26.iscMonto").attr('value',"");	
  		        dijit.byId("item26.iscMonto").attr('style',"background-color:lightgray");	
            }else{
                dijit.byId("item26.iscMonto").attr('disabled', false);
                dijit.byId("item26.iscMonto").attr('style',"background-color:white");	
                dijit.byId("item26.iscMonto").attr('value',"0");
            }
              					
            //IGV                      		
  			//dijit.byId("item26.precioConIGV").constraints = {min:0,currency:moneda, places:2}; /* PAS20211U210100007 */
        	dijit.byId("item26.precioConIGV").constraints = {min:0,currency:moneda, places:'2,10'}; /* PAS20211U210100007 */
        	var montoIGV = store.getValue(row, "igvMonto");
        	if((montoIGV == "" || montoIGV=="0.00") && (store.getValue(row, "tipoBeneficio") != "TB00")){
        		dijit.byId("item26.igvPorcentaje").setValue(0.00);
            	dijit.byId("item26.precioConIGV").attr('disabled', true);
  		        dijit.byId("item26.precioConIGV").attr('value',"");	
  		        dijit.byId("item26.precioConIGV").attr('style',"background-color:lightgray");	
            }else{
                dijit.byId("item26.precioConIGV").attr('disabled', false);
                dijit.byId("item26.precioConIGV").attr('style',"background-color:white");	
                dijit.byId("item26.precioConIGV").attr('value',"0");
            }
  			//dijit.byId("item26.importeVenta").constraints = {min:0,currency:moneda, places:2}; /* PAS20211U210100007 */
        	dijit.byId("item26.importeVenta").constraints = {min:0,currency:moneda, places:'2,10'}; /* PAS20211U210100007 */
  			dijit.byId("item26.importeVenta").attr('value',"0");
		}else{
			dijit.byId("item26.precioUnitario").constraints = {currency:moneda, places:'2,10'};
  			//dijit.byId("item26.precioUnitario").attr('value',store.getValue(row, "precioUnitario"));
			//dojo.byId("item26.precioUnitario").value= dojo.trim(store.getValue(row, "precioUnitario")); /* PAS20211U210100007 */
			dojo.byId("item26.precioUnitario").value= dojo.number.format(dijit.byId("item26.precioUnitario").getValue(),{currency:moneda, places:'2,10'}); /* PAS20211U210100007 */
			
  			//descuentos
  			dijit.byId("item26.descuentos").constraints = {min:0,currency:moneda, places:2};
        	var montoDescuentos = store.getValue(row, "descuentosOriginal");
        	if(montoDescuentos == "" || montoDescuentos=="0.00" || montoDescuentos=="0"){
				dijit.byId("item26.descuentos").attr('disabled', true);
  		        dijit.byId("item26.descuentos").attr('value',"");	
  		        dijit.byId("item26.descuentos").attr('style',"background-color:lightgray");	
            }else{
                dijit.byId("item26.descuentos").attr('disabled', false);
                dijit.byId("item26.descuentos").attr('style',"background-color:white");	
                dijit.byId("item26.descuentos").attr('value',store.getValue(row, "descuentos"));
            }	
  			//ISC
  			dijit.byId("item26.iscMonto").constraints = {min:0,currency:moneda, places:2};
        	var montoISC = store.getValue(row, "iscMonto");
        	if(montoISC == "" || montoISC=="0.00" || (isNaN(montoISC) && montoISC.indexOf(" 0.00") > -1)){
				dijit.byId("item26.iscMonto").attr('disabled', true);
  		        dijit.byId("item26.iscMonto").attr('value',"");	
  		        dijit.byId("item26.iscMonto").attr('style',"background-color:lightgray");	
            }else{
                dijit.byId("item26.iscMonto").attr('disabled', false);
                dijit.byId("item26.iscMonto").attr('style',"background-color:white");	
                //dijit.byId("item26.iscMonto").attr('value',montoISC);
                dijit.byId("item26.iscMonto").setValue(dojo.number.format(montoISC,{places:2} ));
            }
              					
            //IGV                      		
  			//dijit.byId("item26.precioConIGV").constraints = {min:0,currency:moneda, places:2}; /* PAS20211U210100007 */
  			dijit.byId("item26.precioConIGV").constraints = {min:0,currency:moneda, places:'2,10'}; /* PAS20211U210100007 */
        	var montoIGV = store.getValue(row, "igvMonto"); 
        	if((montoIGV == "" || montoIGV=="0.00") && (store.getValue(row, "tipoBeneficio") != "TB00")){
        		dijit.byId("item26.igvPorcentaje").setValue(0.00);
            	dijit.byId("item26.precioConIGV").attr('disabled', true);
  		        dijit.byId("item26.precioConIGV").attr('value',"");	
  		        dijit.byId("item26.precioConIGV").attr('style',"background-color:lightgray");	
            }else{
                dijit.byId("item26.precioConIGV").attr('disabled', false);
                dijit.byId("item26.precioConIGV").attr('style',"background-color:white");	
                //dijit.byId("item26.precioConIGV").attr('value',montoIGV);
                //dijit.byId("item26.precioConIGV").attr('value',dojo.currency.format(montoIGV, {currency: moneda, places: 2})); /* PAS20211U210100007 */
                dijit.byId("item26.precioConIGV").attr('value',dojo.currency.format(montoIGV, {currency: moneda, places: '2,10'})); /* PAS20211U210100007 */
                //dijit.byId("item26.precioConIGV").constraints = {min:0,currency:moneda, places:2};
            }
			
  			//dijit.byId("item26.importeVenta").setValue(dojo.number.format(store.getValue(row, "importeVenta"),{places:2})); /* PAS20211U210100007 */
        	dijit.byId("item26.importeVenta").setValue(dojo.number.format(store.getValue(row, "importeVenta")));
            //dijit.byId("item26.importeVenta").constraints = {min:0,currency:moneda, places:2}; /* PAS20211U210100007 */
  			dijit.byId("item26.importeVenta").constraints = {min:0,currency:moneda, places:'2,10'}; /* PAS20211U210100007 */
        }
		bCargando= false;
		
		
		this.updateItemAmount26(); // PAS20191U210100075
		this.dialogItem26.show();
	},
		
	updateItemAmount26: function() {
		var cantidad=0;
		var igvPorcentaje = 0;
		var cantidadXPrecio = 0;
		var iscMonto = 0;
		var igvMonto = 0;
		var otroMonto = 0;
		var otroTributo = 0;
		var totalItem = 0;
		var descuentos =0;
		var precioUnitario =0;
		var impuestoICBPER=0;//PAS20191U210100075
		var tasaBolsa = 0;//PAS20191U210100075
		if (bCargando == true) {return;}
		
		igvPorcentaje = dijit.byId("item26.igvPorcentaje").getValue() ;    //IGV 19 
		//PAS20191U210100075
		var valOpcionImpuestoBolsaPlastica = this.getValorOpcionImpuestoBolsaPlastica();
		
		cantidad=dijit.byId("item26.cantidad").getValue(); //PAS20191U210100075 01.08
		//cantidad=dijit.byId("item26.cantidad").value; ?????????????
		console.log(cantidad);
	
		//PAS20191U210100075
		/*Inicio SAU20156R120400552*/
       //var moneda = this.boletaBean.codigoMoneda;
       var moneda = this.changeMoneda(this.boletaBean.codigoMoneda);
    /*Fin SAU20156R120400552*/
		if (dojo.byId("item26.precioUnitario").value == "" || dojo.byId("item26.precioUnitario").value == undefined ){
		}else{
			  precioUnitario = dijit.byId("item26.precioUnitario").getValue();
			  
		}
		descuentos =dijit.byId("item26.descuentos").getValue();
		if (isNaN(descuentos)){ descuentos = 0;}
			cantidadXPrecio = cantidad * precioUnitario;
			
			iscMonto = dijit.byId("item26.iscMonto").getValue();
			if (isNaN(iscMonto)){ iscMonto = 0;}
			
			igvMonto = dijit.byId("item26.precioConIGV").getValue();
			
			if (isNaN(igvMonto) || (dijit.byId("item26.igvPorcentaje").getValue() ==0)){ 
				igvMonto = 0;
			} else {
				igvMonto = ((cantidadXPrecio - descuentos +  iscMonto)* igvPorcentaje);
			}    
		
		console.log( "cantidad * precio " + cantidadXPrecio);
		
		//IMPORTE DE VENTA=((VALOR UNITARIO)*CANTIDAD)-(DESCUENTOS)+(IGV)+(ISC MONTO)+(OTROS CARGOS)
		totalItem =cantidadXPrecio -descuentos + igvMonto + iscMonto;
		//INI: PAS20191U210100075
		
		tasaBolsa = dojo.byId("item26.tasaBolsaGlobal").value; 
		
		var monedadesc = this.boletaBean.descripcionMoneda;
		
		if(monedadesc !="SOLES"){
			
			impuestoICBPER = dijit.byId("item26.impuestoICBPER").getValue();
			console.log(impuestoICBPER);
			//dijit.byId("item26.impuestoICBPER").attr('value',dojo.currency.format(impuestoICBPER, {currency: moneda, places: 2}));	
			
		}else{
			impuestoICBPER = cantidad * tasaBolsa;
			//dijit.byId("item26.impuestoICBPER").attr('value',dojo.currency.format(impuestoICBPER, {currency: moneda, places: 2}));
			//dijit.byId("item26.impuestoICBPER").attr('value',impuestoICBPER); //TEMP
		}
		dijit.byId("item26.impuestoICBPER").constraints = {min:0,currency:moneda, places:2};//PAS20191U210100075
		dijit.byId("item26.impuestoICBPER").attr('value',impuestoICBPER);//PAS20191U210100075
		
		console.log(impuestoICBPER);
		
		totalItem  = totalItem + impuestoICBPER;
		//FIN: PAS20191U210100075
		//dijit.byId("item26.precioUnitario").attr('value',dojo.currency.format(dojo.byId("item26.precioUnitario").value, {currency: moneda, places: 10}));
		dijit.byId("item26.descuentos").attr('value',dojo.currency.format(dijit.byId("item26.descuentos").getValue(), {currency: moneda, places: 2}));
		//dijit.byId("item26.precioConIGV").attr('value',dojo.currency.format(igvMonto, {currency: moneda, places: 2})); /* PAS20211U210100007 */
		dijit.byId("item26.precioConIGV").attr('value',dojo.currency.format(igvMonto, {currency: moneda, places: '2,10'})); /* PAS20211U210100007 */
		//igvMonto = parseFloat(igvMonto).toFixed(10); /* PAS20211U210100007 */
		//this.roundTenDecimalAux("item26.precioConIGV", this.remove(igvMonto), moneda); /* PAS20211U210100007 */
		//dijit.byId("item26.importeVenta").attr('value',dojo.currency.format(totalItem, {currency: moneda, places: 2})); /* PAS20211U210100007 */
		//dijit.byId("item26.importeVenta").attr('value',dojo.currency.format(totalItem, {currency: moneda, places: '2,10'})); /* PAS20211U210100007 */
		totalItem = parseFloat(totalItem).toFixed(10); /* PAS20211U210100007 */
		this.roundTenDecimalAux("item26.importeVenta", this.remove(totalItem), moneda); /* PAS20211U210100007 */
		dijit.byId("item26.iscMonto").attr('value',dojo.currency.format(iscMonto, {currency: moneda, places: 2}), false);
		
		dijit.hideTooltip(dojo.byId("item26.precioUnitario"));
		dijit.hideTooltip(dojo.byId("item26.descuentos"));
		dijit.hideTooltip(dojo.byId("item26.iscMonto"));	
	},	
	acceptDialogItem26: function() {
		/*Inicio SAU20156R120400552*/
    //var moneda = this.boletaBean.codigoMoneda;
      var moneda = this.changeMoneda(this.boletaBean.codigoMoneda);
    /*Fin SAU20156R120400552*/
		var otrosTributosOriginal = this.boletaBean.totalOtrosTributos; 
		
		var descripcionItem=dojo.trim(dijit.byId("item26.descripcion").getValue());
		var buscar="[*****] BONIFICACION [*****]";
		var esBonificacion = false;
		if (descripcionItem.search(buscar)!=-1 ){
          esBonificacion = true;	
		}
       
        //if (!esBonificacion) {
        if (dijit.byId("item26.precioUnitario").getValue() == "" ) {
    		var node = dijit.byId("item26.precioUnitario");
    		this.iconTooltipMessage(node.focusNode,"icon-ok-tooltip", "Debe consignarse el valor unitario.");
    		
    		//node.constraints = {currency:moneda, places:10}; /* PAS20211U210100007 */
  			node.constraints = {currency:moneda, places:'2,10'}; /* PAS20211U210100007 */
    		return;
    	}	
		//}
		if(dijit.byId("item26.cantidad").getValue() == 0){
			var node = dijit.byId("item26.cantidad");
			this.iconTooltipMessage(node.focusNode,"icon-ok-tooltip", "Cantidad a devolver no puede ser 0.");
			return;     
		}
      
		console.log("cantidadOriginal --> " + store.getValue(row, "cantidadOriginal")); /* PAS20211U210100007 */
		console.log("parseFloat cantidadOriginal --> " + parseFloat(store.getValue(row, "cantidadOriginal"))); /* PAS20211U210100007 */
		console.log("item26.cantidad --> " + dijit.byId("item26.cantidad").getValue()); /* PAS20211U210100007 */
		
		if(dijit.byId("item26.cantidad").getValue() > parseFloat(store.getValue(row, "cantidadOriginal"))){ /* PAS20211U210100007 */
			var node = dijit.byId("item26.cantidad");
   			this.iconTooltipMessage(node.focusNode,"icon-ok-tooltip", "Cantidad a devolver debe ser menor o igual a la cantidad del item respectivo de la Boleta de Venta Original");
  			return;     
		} 
		//if (!esBonificacion) {
        if (dijit.byId("item26.precioUnitario").getValue() > dojo.number.parse(dojo.byId("item26.valorVtaUnitarioOriginal").value )) {
  			var node = dijit.byId("item26.precioUnitario");
  			this.iconTooltipMessage(node.focusNode,"icon-ok-tooltip", "Valor Unitario debe ser menor al valor unitario de la Boleta de Venta Original");
  			
  			//node.constraints = {currency:moneda, places:10}; /* PAS20211U210100007 */
  			node.constraints = {currency:moneda, places:'2,10'}; /* PAS20211U210100007 */
  			return;
  		}	 
		//}
        if (!(dijit.byId("item26.descuentos").getValue() == "") ) {
    		if (dijit.byId("item26.descuentos").getValue() <= 0 ) {
    			var node = dijit.byId("item26.descuentos");
    			this.iconTooltipMessage(node.focusNode,"icon-ok-tooltip", "Descuentos debe ser mayor a 0.");
    			
    			node.constraints = {min:0,currency:moneda, places:2};
    			return;
    		}	
    		
    		//if (dijit.byId("item26.descuentos").getValue() >= dojo.byId("item26.precioUnitario").value) {
    		if (dijit.byId("item26.descuentos").getValue() >= (dijit.byId("item26.precioUnitario").getValue()*dojo.byId("item26.cantidad").value))  {
				var node = dijit.byId("item26.descuentos");
    			this.iconTooltipMessage(node.focusNode,"icon-ok-tooltip", "Descuentos debe ser menor al valor unitario por la cantidad.");
    			
    			node.constraints = {min:0,currency:moneda, places:2};
    			return;
    		}				
		}
		if (dijit.byId("item26.iscMonto").attr('disabled') == false){
        	//if (dijit.byId("item26.iscMonto").getValue() == "" ) {
                //PAS20211U210100037
             if (dijit.byId("item26.iscMonto").getValue() === "" ) {
  				var node = dijit.byId("item26.iscMonto");
  				this.iconTooltipMessage(node.focusNode,"icon-ok-tooltip", "Debe consignarse ISC.");
  				
  				node.constraints = {min:0,currency:moneda, places:2};
  				return;
  			}	      
			//if (dijit.byId("item26.iscMonto").getValue() <= 0 ) {
            if (dijit.byId("item26.iscMonto").getValue() < 0 ) {
  				var node = dijit.byId("item26.iscMonto");
  				this.iconTooltipMessage(node.focusNode,"icon-ok-tooltip", "ISC debe ser mayor que 0.");
  				
  				node.constraints = {min:0,currency:moneda, places:2};
  				return;
  			}	
  			
  			if (dijit.byId("item26.iscMonto").getValue() >= dijit.byId("item26.precioUnitario").getValue()) {
  				var node = dijit.byId("item26.iscMonto");
  				this.iconTooltipMessage(node.focusNode,"icon-ok-tooltip", "ISC debe ser menor al precio unitario.");
  				
  				node.constraints = {min:0,currency:moneda, places:2};
  				return;
  			}	
  			
  			if (dijit.byId("item26.iscMonto").getValue() > dojo.number.parse(dojo.byId("item26.iscMontoOriginal").value )) {
  				var node = dijit.byId("item26.iscMonto");
  				this.iconTooltipMessage(node.focusNode,"icon-ok-tooltip", "ISC debe ser menor o igual que el monto del ISC original.");
  				
  				node.constraints = {min:0,currency:moneda, places:2};
  				return;
  			}	
		}
      
		/*
		if(dijit.byId("item26.importeVenta").getValue() > dojo.number.parse(dojo.byId("item26.precioUnitarioOriginal").value )){
			var node = dijit.byId("item26.importeVenta");
   			this.iconTooltipMessage(node.focusNode,"icon-ok-tooltip", "Importe de venta debe ser menor que el importe de venta del item respectivo de la Boleta de Venta Original");
  			return;     
		}     
		*/      
		if(!dijit.byId("item26.form").validate()) return;
	
		//INI PAS20191U210100075 - jsantivanez
			dijit.byId("item26.impuestoBolsasPlastica00").setAttribute('disabled', false);
			dijit.byId("item26.impuestoBolsasPlastica01").setAttribute('disabled', false); 	
			dijit.byId("item26.impuestoICBPER").setAttribute('disabled', false);
			
			dojo.byId("item26.impuestoICBPER").value = dojo.number.format(dijit.byId("item26.impuestoICBPER").getValue() ,{places:2} )
			
			console.log(dojo.byId("item26.impuestoICBPER").value)
		
			console.log(dijit.byId("item26.cantidad").value % 1);
			if(document.getElementById("item26.impuestoBolsasPlastica00").checked == true){
				if(dijit.byId("item26.cantidad").value % 1 > 0){
					mostrarMensaje("Cantidad invalida");
					return;
				}
			}
		
		
		//FIN PAS20191U210100075 - jsantivanez
	
		var nbControl = dijit.byId("item26.botonAceptar");
		nbControl.setAttribute('disabled', true);
		var nodeButton = nbControl.focusNode;
		var mode = dojo.byId("item26.action").value;
		this.wait("Editando", "95px", 200);
	
  		var handler = dojo.io.iframe.send({
  			url: this.controller,
  			handleAs: "json",
  			sync: true,
  			timeout: 10000,
  			preventCache: true,
  			form: "item26.form"
  		});
		  handler.addCallback(dojo.hitch(this, function(res){
			   this.waitMessage.hide();
			   if(res.codeError == 0) {
				   	store.fetchItemByIdentity({
        			identity: currentLine,
        			onItem: dojo.hitch(this, function(item){
        			//store.setValue(item,'cantidad',dojo.byId("item26.cantidad").value); /* PAS20211U210100007 */
        			store.setValue(item,'cantidad',dojo.number.format(dijit.byId("item26.cantidad").getValue() ,{places:'2,10'} )); /* PAS20211U210100007 */
					store.setValue(item,'descuentos',dojo.byId("item26.descuentos").value );
					store.setValue(item,'precioUnitario',dojo.byId("item26.precioUnitario").value );					
					store.setValue(item,'precioUnitarioOriginal',dojo.byId("item26.precioUnitario").value );
					if (dojo.byId("item26.iscMonto").value != ""){	store.setValue(item,'iscMonto',dojo.byId("item26.iscMonto").value ); }
					if (dojo.byId("item26.precioConIGV").value != ""){	store.setValue(item,'igvMonto',dijit.byId("item26.precioConIGV").getValue() );}
					store.setValue(item,'modificado',"1");
					store.setValue(item,'importeVenta',dijit.byId("item26.importeVenta").getValue()); 
					store.setValue(item,'icbPerMonto',dojo.byId("item26.impuestoICBPER").value );	//PAS20191U210100075
					
        			}),
        			onError: function(){}
        		});
					
			  	var grid = dijit.byId('ncCambioDetalles.ingreso-grid');
				grid.setStore(store);
				grid.update();
				this.closeDialogItem26();
			} else {
				nbControl.setAttribute('disabled', false);
				this.iconTooltipMessage(nodeButton, "icon-error-tooltip", res.messageError);
			}
		}));
		handler.addErrback(dojo.hitch(this, function(res) {
			nbControl.setAttribute('disabled', false);
			this.waitMessage.hide();
			this.iconTooltipMessage(nodeButton, "icon-error-tooltip", res.messageError);
		}));
		//INI PAS20191U210100075 - jsantivanez
		dijit.byId("item26.impuestoBolsasPlastica00").setAttribute('disabled', true);
		dijit.byId("item26.impuestoBolsasPlastica01").setAttribute('disabled', true);  
		dijit.byId("item26.impuestoICBPER").setAttribute('disabled', true);
		//FIN PAS20191U210100075 - jsantivanez
		nbControl.setAttribute('disabled', false);			
		dijit.hideTooltip(dojo.byId("item26.cantidad"));
		dijit.hideTooltip(dojo.byId("item26.precioUnitario"));
		dijit.hideTooltip(dojo.byId("item26.descuentos"));
		dijit.hideTooltip(dojo.byId("item26.iscMonto"));
		dijit.hideTooltip(dojo.byId("item26.importeVenta"));
    },
    
    
    closeDialogItem26: function() {
		dijit.hideTooltip(dojo.byId("item26.cantidad"));
    	dijit.hideTooltip(dojo.byId("item26.precioUnitario"));
		dijit.hideTooltip(dojo.byId("item26.descuentos"));
		dijit.hideTooltip(dojo.byId("item26.iscMonto"));
		dijit.hideTooltip(dojo.byId("item26.importeVenta"));
		this.dialogItem26.hide();
	},
	  
	//Error en descripcion
    editItem25: function(identificador) {	    
		store =dijit.byId('ncCambioDetalles.ingreso-grid').store;
        
		store.fetchItemByIdentity({
			identity: identificador,
		    onItem : function(item, request) {
		        row = item;		
            currentLine = identificador 	;		
		    },
		    onError : function(item, request) {
				mostrarMensaje("Ocurrio un error al ubicar el documento");
				return;				
		    }
		});
		
		bCargando= true;
		dijit.byId("item25.botonAceptar").attr('disabled', false);
							
		dojo.byId("item25.descripcionOriginal").value =store.getValue(row, "descripcion");			
		var descripcionItem=dojo.trim(store.getValue(row, "descripcion"));
		var descripcionItemNueva=dojo.trim(store.getValue(row, "descripcionNueva"));
		var buscar="[*****] ";
		var posicion = descripcionItem.search(buscar);
		if (posicion !=-1 ){
			//descripcionItem = descripcionItem.replace("***** BONIFICACION *****", "");
			//descripcionItemNueva = descripcionItemNueva.replace("***** BONIFICACION *****", "");	
			descripcionItem = descripcionItem.substring(0, posicion-4);
			descripcionItemNueva = descripcionItemNueva.substring(0, posicion-4);		 	 
		}
		this.dialogItem25.attr('title', "Captura NC - Error en la descripci\u00F3n");
		dojo.byId("item25.idItem").value = currentLine ; //store.getValue(row, "identificador");
	 	dijit.byId("item25.unidadMedida").setValue(store.getValue(row, "unidadMedidaDesc"));
		//dijit.byId("item25.cantidad").setValue(store.getValue(row, "cantidad"), false);
	 	console.log("cantidad --> " + row.cantidad); /* PAS20211U210100007 */
		//dijit.byId("item25.cantidad").setValue(dojo.trim(dojo.currency.format(store.getValue(row, "cantidad")), {places: '2,10'})); /* PAS20211U210100007 */
	 	dijit.byId("item25.cantidad").setValue(row.cantidad); /* PAS20211U210100007 */
	 	dijit.byId("item25.descripcionDice").setValue(descripcionItem);
				
		if (store.getValue(row, "modificado") =="0"){
		  	dijit.byId("item25.descripcionDebeDecir").attr('value',"");
		}else{				      
            dijit.byId("item25.descripcionDebeDecir").attr('value',descripcionItemNueva);        
        }
		bCargando= false;
		this.dialogItem25.show();		
	},
		
		    
		    
		acceptDialogItem25: function() {
     // var moneda = this.boletaBean.codigoMoneda;
      
		
    	if (dijit.byId("item25.descripcionDebeDecir").getValue() == "" ) {
				var node = dijit.byId("item26.descripcionDebeDecir");
				this.iconTooltipMessage(node.focusNode,"icon-ok-tooltip", "Debe consignarse la nueva descripci\u00F3n.");
				return;
			}	
    	
    	regexp1 = /^[a-zA-Z0-9À-ÿ\u00f1\u00d1!#$%&'()\u00a3*+,-.\/:;<=>?@^_`{|}~\]\[\\ ]+$/;
		regexp2 = /[ÿ]+$/;
		if (!regexp1.test(dijit.byId("item25.descripcionDebeDecir").getValue())|| 
				regexp2.test(dijit.byId("item25.descripcionDebeDecir").getValue())) {  //Verifica que la descripci\u00F3n no tenga caracteres especiales
		//this.warnTooltipMessage("item.descripcion", 'Contiene car&aacute;cter(es) no permitido(s).');
		mostrarMensaje("El texto de descripci&oacuten contiene car&aacute;cter(es) no permitido(s).");
		return;
		}
      
	//PAS20221U210600125 -Ini - Csantillan
	//	this.isQuitarCharacterSpecial();
	//PAS20221U210600125 -Fin - Csantillan
	
  		var descripcionItemOriginal=dojo.trim(dojo.byId("item25.descripcionOriginal").value) ;
		  var descripcionItemNueva= dijit.byId("item25.descripcionDebeDecir").getValue();
		  descripcionItemNueva = descripcionItemNueva.toUpperCase();
		  var buscar="[*****] ";
		  var posicion = descripcionItemOriginal.search(buscar);
		  if (posicion !=-1 ){
			 	 descripcionItemNueva = descripcionItemNueva + descripcionItemOriginal.substring(posicion-4);	
			 	 dijit.byId("item25.descripcionDebeDecir").setValue(descripcionItemNueva);
			 	 dijit.byId("item25.descripcionDice").setValue(descripcionItemOriginal);
       }		
    //   alert("["+ descripcionItemNueva + "]");
//alert("["+ descripcionItemOriginal + "]");       
      if (descripcionItemNueva == descripcionItemOriginal){
          var node = dijit.byId("item25.descripcionDebeDecir");
   				this.iconTooltipMessage(node.focusNode,"icon-ok-tooltip", " 	Contenido del campo Debe Decir debe ser diferente al contenido del campo Dice");
  				return;   
      }
		  var nbControl = dijit.byId("item25.botonAceptar");
      nbControl.setAttribute('disabled', true);
		  var nodeButton = nbControl.focusNode;
		  var mode = dojo.byId("item25.action").value;
      this.wait("Editando", "95px", 200);
	
	
	
  		var handler = dojo.io.iframe.send({
  			url: this.controller,
  			handleAs: "json",
  			sync: true,
  			timeout: 10000,
  			preventCache: true,
  			form: "item25.form"
  		});
		  handler.addCallback(dojo.hitch(this, function(res){
			    this.waitMessage.hide();
			   if(res.codeError == 0) {
					store.fetchItemByIdentity({
        			identity: currentLine,
        			onItem: dojo.hitch(this, function(item){
					store.setValue(item,'descripcionNueva',dojo.byId("item25.descripcionDebeDecir").value );
					store.setValue(item,'modificado',"1");
       			
        			}),
        			onError: function(){}
        		});
					
			  	var grid = dijit.byId('ncCambioDetalles.ingreso-grid');
					grid.setStore(store);
					grid.update();
					this.closeDialogItem25();
			} else {
				nbControl.setAttribute('disabled', false);
				this.iconTooltipMessage(nodeButton, "icon-error-tooltip", res.messageError);
			}
		}));
		handler.addErrback(dojo.hitch(this, function(res) {
			nbControl.setAttribute('disabled', false);
			this.waitMessage.hide();
			this.iconTooltipMessage(nodeButton, "icon-error-tooltip", res.messageError);
		}));
		
		nbControl.setAttribute('disabled', false);			
    dijit.hideTooltip(dojo.byId("item25.descripcionDebeDecir"));
   
    },
    
    closeDialogItem25: function() {
		 this.dialogItem25.hide();
	  },
	  
	  verPreliminarNC:function(tipo){
	    //Validamos que por lo menos se haya modificado un item
      var grilla =dijit.byId('ncCambioDetalles.ingreso-grid');
      var datos =grilla.store._arrayOfAllItems;
      var filas = grilla.store._arrayOfAllItems.length;
      var numModificados=0;
      
      for (i=0; i< filas;i++){
        var fila = grilla.getItem(i);
        var valorModif= grilla.store.getValue(fila, "modificado");
        if (valorModif==1){ numModificados ++;}
      }
      
      if (numModificados == 0){
          mostrarMensaje("Debe seleccionar por lo menos un Item de la BVE, y consignar los datos de la Nota de Cr\u00E9dito.");
          return;
      }
			this.content.setHref(this.controller + "?action=preliminarComprobante&TipoNotaCred=" + tipo + "&boleta=" + dijit.byId("pantallaInicial.numeroBVE").value + "&motivo=" + dijit.byId("pantallaInicial.motivoEmisionNC").value);	
  },
	//INI PAS20191U210100075
	viewCheckedImpuestoBolsaPlastica: function() {
		var valOpcionImpuestoBolsaPlastica = this.getValorOpcionImpuestoBolsaPlastica();
			console.log("check " + valOpcionImpuestoBolsaPlastica);
		
		if (valOpcionImpuestoBolsaPlastica != "IBP00"){
			dojo.byId("item26.tasaBolsaGlobal").value = "0";
			this.updateItemAmount26();
			
		}else{
			//dojo.byId("item26.tasaBolsaGlobal").value = dojo.byId("item26.tasaBolsaGlobal2").value;
			this.updateItemAmount26();
		}
			
	},
	getValorOpcionImpuestoBolsaPlastica: function() {
		var valOpcionImpuestoBolsaPlastica="";
		for(i = 0; i < 2; i++) {
			//if(dijit.byId("item.subTipoTB0" + i).getValue() != false) {
			if(document.getElementById("item26.impuestoBolsasPlastica0"+i).checked == true) {
				valOpcionImpuestoBolsaPlastica = document.getElementById("item26.impuestoBolsasPlastica0"+i).value;
			}
		}
		return valOpcionImpuestoBolsaPlastica;
	},  	
	//FIN PAS20191U210100075
  verPreliminarNCContin:function(tipo){
	    //Validamos que por lo menos se haya modificado un item
		
		var serie = document.getElementById("serie").value;
		var numero = document.getElementById("numero").value;
		var idSerie = document.getElementById("idSerie").value;
		var boleta= dijit.byId("pantallaInicial.numeroBVE").value;
		if(numero==""){
			mostrarMensaje("Ingrese el numero de serie");
			document.getElementById("numero").focus();
			return;
		}
		
      var grilla =dijit.byId('ncCambioDetalles.ingreso-grid');
      var datos =grilla.store._arrayOfAllItems;
      var filas = grilla.store._arrayOfAllItems.length;
      var numModificados=0;
      
      for (i=0; i< filas;i++){
        var fila = grilla.getItem(i);
        var valorModif= grilla.store.getValue(fila, "modificado");
        if (valorModif==1){ numModificados ++;}
      }
      
      if (numModificados == 0){
          mostrarMensaje("Debe seleccionar por lo menos un Item de la BVE, y consignar los datos de la Nota de Cr\u00E9dito.");
          return;
      }
			this.content.setHref(this.controller + "?action=preliminarComprobanteContin&TipoNotaCred=" + tipo + "&boleta=" + dijit.byId("pantallaInicial.numeroBVE").value + "&motivo=" + dijit.byId("pantallaInicial.motivoEmisionNC").value+"&idSerie="+idSerie+"&serie="+serie+"&numero="+numero);	
  },
  
  	backModificaItems: function() {
			this.content.setHref(this.controller + "?action=regresarCambiarDetallesNC");
	},
	  
	valorUnitario: function(valor, rowindex) {
	var valor2 = valor.replace(',','');
	    if (valor2<0){
	    return "";
      }else{
      return valor;
      } 
	
	},
	
	  onStyleRow :function(inRow){
      var store = dijit.byId('ncCambioDetalles.ingreso-grid').store;
       var item = store._arrayOfAllItems[ inRow.index ];
       if (item!=null){
           var modif = store.getValue(item, "modificado");
          if( modif == "1" ) {
                    with (inRow) {
                  
                      inRow.customStyles += ' color: blue; font-weight: bold';
               } 
          }
       }   
    },
    
		closeDocument: function() {
      dijit.hideTooltip(dojo.byId("numeroComprobante"));
      dijit.hideTooltip(dojo.byId("pantallaInicial.numeroBVE"));
      dijit.hideTooltip(dojo.byId("pantallaInicial.numeroNuevaBVE" ));
      dijit.hideTooltip(dojo.byId("pantallaInicial.descuentoGlobalNC"));
      dijit.hideTooltip(dojo.byId("pantallaInicial.ISCNC" ));
           
      this.content.onLoad = dojo.hitch(this, function(){
				this.initContent();
			});
			this.content.setHref(this.controller + "?action=mostrarPantallaInicial&mode=hidden");
	  },
	   /*Inicio SAU20156R120400552*/
	  changeMoneda: function(moneda){
       if(moneda=="XEU"){
		    return "EUR";
       }
       return moneda;
    }, 
    /*Fin SAU20156R120400552*/
         showHiddenDiv: function(node,show) {
	         	if (show == true) { //Mostrar
		  	       node.style.display = "";
	          } else { //Ocultar
		          	node.style.display = "none";
	         	}
          }
          // INI PAS20211U210100040  AHUISA
    ,
    validarFechaEmision: function(validarFechaIgvVigente){
      response = true;
      if (dijit.byId("pantallaInicial.fechaEmision").getValue() !=null && dijit.byId("pantallaInicial.fechaEmision").getValue() !=""){
        var fechaEmision = dojo.date.locale.format(dijit.byId("pantallaInicial.fechaEmision").getValue(), {datePattern: "yyyyMMdd", selector: "date"});
        
        var diasAnticipadosEmisionComprobante = dojo.number.parse(dojo.byId("pantallaInicial.diasAnticipadosEmisionComprobante").value);
        var parts =dojo.byId("pantallaInicial.fechaActual").value.split('-');
        var fechaActualRecuperado = new Date(parts[0],parts[1]-1,parts[2]);
        var fechaAnteriorRecuperado = new Date(parts[0],parts[1]-1,parts[2]);
        fechaAnteriorRecuperado.setDate(fechaAnteriorRecuperado.getDate() - 2);
        
        var fechaActual  = dojo.date.locale.format(fechaActualRecuperado, {datePattern: "yyyyMMdd", selector: "date"});
        var fechaAnterior = dojo.date.locale.format(fechaAnteriorRecuperado, {datePattern: "yyyyMMdd", selector: "date"});
        
        if (fechaEmision < fechaAnterior || fechaEmision > fechaActual){
          this.iconTooltipMessageFec("pantallaInicial.fechaEmision", "icon-ok-tooltip", "Fecha de Emisi\u00F3n solo puede ser entre dos d\u00EDas antes y el d\u00EDa de hoy.");
          response = false;
        }
      }
      return response;
    },
    // FIN PAS20211U210100040  AHUISA
    
	//PAS20221U210600125-Ini-Csantillan
	isQuitarCharacterSpecial: function() {

		dojo.require("dojox.string.sprintf");
		var descripcion = dojo.trim(dijit.byId("item25.descripcionDebeDecir").getValue());
		var textofinal = "";
		var carac = "";
		if(descripcion.length >= 1) {

		var parts = descripcion.split("");
		    for(i=0; i < parts.length; i++) {
				carac= descripcion[i].split("");
				carac = carac.toString().toUpperCase();
				var arrch = ["☺","☻", "♥", "♦", "♣", "♠", "•", "◘","○","◙","♂","♀","♪","♫","☼","►","◄","↕","‼","¶","§","▬","↨","↑","↓","→","←","∟","↔","▲","▼","ֲ","","–"]
				var flag = 0
				for (var j = 0; j < arrch.length; j++) {
					var caray = arrch[j];
					if (carac == caray ){
						flag = 1
					}
				}
				if (flag==1){
					textofinal = textofinal + "";
				}
				else{
					textofinal = textofinal + carac;
				}
			}
			dijit.byId("item25.descripcionDebeDecir").setValue(textofinal);
		}
	}
	//PAS20221U210600125-Fin-Csantillan
    
    });
}