    var $txtMontoRetencion =$('#txtMontoRetencion');
	var $txtPorcentaje =$('#txtPorcentaje');
	var $txtBaseImponible =$('#txtBaseImponible');
    var $formretencion = $("#form-retencion");	
    var $panelRetencion = $('#panel-retencion');	
	var $btnPreview = $('#btnPreview');

		
	function formateoNumero(obj)
{

 
 var numero=convertirNumero(obj.value)
  
 var num = new NumberFormat();

  num.setInputDecimal('.');
  num.setNumber(numero); 
  num.setPlaces('2', true);
  num.setCurrency(false);
  num.setCurrencyPosition(num.LEFT_OUTSIDE);
  num.setNegativeFormat(num.LEFT_DASH);
  num.setNegativeRed(false);
  num.setSeparators(false, ',', ',');
  obj.value = num.toFormatted();




}


function convertirNumero(num)

	{
			//numero tiene decimales
			
			if ( (num % 1 != 0)   && (num<=99999999.99) ){
				
				return num;
				
			}
			
			else{
			
					
					num=num.substring(0,8);
					
					return num;
			
			}




	}

	

(function(window, $, _) {
    
		$(document).ready(function() { 
    $('#mostrar-factura').click(function (e) {
        //prevents re-size from happening before tab shown
        e.preventDefault();
          
        //fire re-size of footable
        $('.footable').trigger('footable_resize'); 
    });
	
	
	
});
	
	
	
	/*
     * :::: CONTAINERS :::: END
     */
    // Notese como se reciclan los selectores para hacer el menor
    // numero de consultas al DOM.
	
	
	

    var $containerBusqueda = $("#paso-1");
    var $containerPreview = $("#preliminar-factura");

    var $formEmail = $("#email-send");
    var $formBusqueda = $containerBusqueda.find('form');
    var $formByPass = $("#bypassForm");
    var $formNotaCredito = $("#formNotaCredito");

    var $formNotaDebitoDetalles = $("#formNotaDebitoDetalles");
    var $btnMostrarFactura = $("#mostrar-factura");
    var $btnVolverFactura = $("#btnVolverFactura");
    var $modalPreloader = $('#modalPreloader');
    var $hidMaximo = $formNotaDebitoDetalles.find('#hidMaximo');

    var $_maxMontoField = $formNotaDebitoDetalles.find("#maxMonto");

    var $modalMensajes = $('#modalMensajes');
    
    var $tabla = $("#table");


    $btnMostrarFactura.on('click', function(e) {
        $containerPreview.removeClass('hidden')
        $containerBusqueda.addClass('hidden');
    })

    $btnVolverFactura.on('click', function(e) {
        $containerBusqueda.removeClass('hidden')
        $containerPreview.addClass('hidden');
    })

	var $txtFactura = $('#txtFactura');
	$txtFactura.change(function() {
		$txtFactura.val($txtFactura.val().replace(/^0+/, ''));
	});

    $formNotaCredito.validate({
        debug: true,

        rules: {

            txtFactura: {
                required: true,
                digits: true,
                minlength: 1
            },



        },
        /*** FIX ATTEMPT **/
        invalidHandler: function(event, validator) {
            var offset = $(validator.errorList[0].element).offset();
            $(window).scrollTop(offset.top - 30);
        },
        /*** END / FIX ATTEMPT **/


        submitHandler: function(form) {

            $modalPreloader.modal('show');
            var formData = $(form).serializeObject();
            var url = 'emitirNCFEResp.do?action=validarComprobante';
            var url_redirigir = 'emitirNCFEResp.do?action=verDatosIngreso';
            $.ajax({
                method: 'post',
                url: url,
                data: formData,
                dataType: 'json',

                success: function(data) {

                    var msj = data.messageError;
                    $('#divMensaje').text(msj);


                    if ( (data.codeError == 1) && (!!msj) )

                    {
                        $modalMensajes.modal('show');
						
                    } 
					
					else if ( (data.codeError == 4) && (!!msj) )

                    {

                        $modalMensajes.modal('show');

                    }
					
					else if ( (data.codeError == 9) && (!!msj) )
					{
     					   $modalMensajes.modal('show');
						
						$('#btnSistema').click(function(){
								 
								window.location.href = url_redirigir;
							});
					
					} 
					
					else if (data.codeError == 0)

                    {
								window.location.href = url_redirigir;
							
                    } 
					
					else

                    {
                        console.log(msj);
                    }

                },
                error: function() {
                    alert('Ha ocurrido un error por favor intentelo dentro de unos minutos.');
                },

                complete: function()
                {
                    $modalPreloader.modal('hide');
                }
            });
        }
    });

    $formNotaDebitoDetalles.validate({
        onkeyup: false,
        //  onchange: false,
        //  onclick: false,
        //  onfocusout: false,
        rules: {

            txtMotivo: {
                required: {

                    depends: function() {
                        $(this).val($.trim($(this).val()));
                        return true;
                    }

                },
                minlength: 5,
                validStr: true,
                maxlength: 250

            },

            txtDescuento: {
                required: true,
                number: true,
                lessThan: {
                    param: function() {
                        return $_maxMontoField.val();
                    }
                },
				validateDescTotal: true,//
                min: 0 + Number.MIN_VALUE
            }
        },
        messages: {
            txtDescuento: {
                lessThan: function(val) {
                    return "El monto de descuento no puede ser mayor a {0}".format($.number($_maxMontoField.val(), 2));
                }
            }
        },
        submitHandler: function(form) {
            form.submit();
            // eliminar todo esto en el vivo.
            //window.location.href = 'paso-3.html';
        }
    });



    $(".number").keydown(function(e) {
        // Permite: backspace, delete, tab, escape, enter and .(190 )
        if ($.inArray(e.keyCode, [46, 8, 9, 27, 13, 110]) !== -1 ||
            // Permite: Ctrl+A
            (e.keyCode == 65 && e.ctrlKey === true) ||
            // Permite: home, end, left, right
            (e.keyCode >= 35 && e.keyCode <= 39)) {
            // solo permitir lo que no este dentro de estas condiciones es un return false
            return;
        }
        // Aseguramos que son numeros
        if ((e.shiftKey || (e.keyCode < 48 || e.keyCode > 57)) && (e.keyCode < 96 || e.keyCode > 105)) {
            e.preventDefault();
        }
    });


    $(".decimal").keydown(function(e) {
        // Permite: backspace, delete, tab, escape, enter and .(190 )
        if ($.inArray(e.keyCode, [46, 8, 9, 27, 13, 110, 190]) !== -1 ||
            // Permite: Ctrl+A
            (e.keyCode == 65 && e.ctrlKey === true) ||
            // Permite: home, end, left, right
            (e.keyCode >= 35 && e.keyCode <= 39)) {
            // solo permitir lo que no este dentro de estas condiciones es un return false
            return;
        }
        // Aseguramos que son numeros
        if ((e.shiftKey || (e.keyCode < 48 || e.keyCode > 57)) && (e.keyCode < 96 || e.keyCode > 105)) {
            e.preventDefault();
        }
    });

	function round(num, decimals) {//PAS20221U210700050
		var n = Math.pow(10, decimals);
        return Math.round( (n * num).toFixed(decimals) )  / n;
	}

    $('.calculate-igv').bind('change keyup', function(argument) {

        var total = '0.00';
        var descuento = $('#txtDescuento').numVal();
        var porcentaje = $('#hidPorcentaje').numVal();
		if (porcentaje < 1) { porcentaje = porcentaje * 100;}
        var subtotal = parseFloat(descuento) * parseFloat(porcentaje);
        if (isNaN(subtotal))
            total = 0.00;
        else
            total = subtotal / 100;

		//$('#txtIgv').val(total.toFixed(2));		
        var igv23 = round(total,2);//PAS20221U210700050
		$('#txtIgv').val(igv23);
		console.log('1');



    });
		
		
	$.validator.addMethod("validateDescTotal", function(value, element, param) {
        var valid = validateDescTotal();
        $(element).data('validateDescTotal', valid ? '1' : '0');		
		return valid;
    }, "La suma del Descuento Global + IGV  debe ser menor que el Valor de Venta de la FE respecto de la cual se emitir&aacute; la NC.");
	
	function validateDescTotal(){
		
		var retorno = true;
		
		var totalValorVenta = $_maxMontoField.val();
        var totalIgv = '0.00';
        var descuento = $('#txtDescuento').numVal();
        var porcentaje = $('#hidPorcentaje').numVal();
		if (porcentaje < 1) { porcentaje = porcentaje * 100;}
        var subtotal = parseFloat(descuento) * parseFloat(porcentaje);
        if (isNaN(subtotal)){
            totalIgv = 0.00;
        }else{
            totalIgv = (subtotal / 100);
			totalIgv = round(totalIgv,2);//PAS20221U210700050			
		}
		
		if ((descuento + totalIgv ) >= totalValorVenta){
			//alert("La suma del Descuento Global + IGV  debe ser menor que el Valor de Venta de la FE respecto de la cual se emitirá la NC");			
			retorno = false;
		}
		
		return retorno;
	}

	
	


    // fix 20-10-2015
    $('[data-format-numeric]').on('change', function(e) {
        var places = e.target.getAttribute('data-decimal-places') || 2;
        var groupDelimiter = e.target.getAttribute('data-group-delimiter') || undefined;
        e.target.value = $(this).numVal().toMoney(places, groupDelimiter);
    });
    // end - fix 20-10-2015


    /*
     * :::: FORM VALIDATE :::: / END
     */

    $formEmail.validate(_.extend(window._validatorWallSettings, {
        rules: {
            txtEmail: {
                required: true,
                email: true,
                regex: /\b[A-Z0-9._%+-]+@[A-Z0-9.-]+\.[A-Z]{2,4}\b/i
            }
        },
        submitHandler: function(form) {
            var formData = $(form).serializeObject();
            var url = 'emitirNCFEResp.do?action=enviarCorreo';
            $.ajax({
                method: 'post',
                url: url,
                data: formData,
                success: function() {

                    var msj = 'El correo ha sido enviado.';
                    $('#divMensaje').text(msj);
                    $modalMensajes.modal('show');
                    $("#txtEmail").val();
                },
                error: function() {
                    alert('Se presento un problema, por favor intentelo luego de  unos minutos.');
                }
            });
        }
    }));

    /*
     * :::: SETUP :::: START
     */

    $modalPreloader.modal({
        backdrop: 'static',
        keyboard: false,
        show: false
    });

    // $containerGenerar.find('[data-toggle="popover"]').popover()


	
	



    

    $tabla.footable();

    //$btnBuscar.hide();
    //$btnValidar.hide();

    /*
     * :::: SETUP :::: / END
     */

    $("[data-toggle]").on('click', function(e) {
        e.preventDefault();
    });

})(window, jQuery, _);



//INI-OPV: PAS20201U210100231 FUNCION PARA ESPERAR QUE FORMULARIO CARGUE
$(document).ready(function () {
	var formNotaCreditoInfCredito = $("#formNotaCreditoInfCredito");
	if(formNotaCreditoInfCredito.length){
		InitInfCredito();
	}   
	var formNotaRetencion = $("#form-retencion");
	if(formNotaRetencion.length){
		InitInfRetencion();
	} 	
});
//FIN-OPV: PAS20201U210100231

//INI-OPV: PAS20201U210100231 FUNCION QUE CONTIENE TODOS LOS METODOS DEL FORMULARIO INFORMACION DE CREDITO Y CUOTA
function InitInfCredito(){
	//INI-OPV: PAS20201U210100231 Variables InfCredito y Cuotas 
	//Variables relacionadas a InfCredito PRINCIPAL
			  
				  
	var $formInfCredito = $('#formNotaCreditoInfCredito');
	var $SumaMontoInfCredito=0;
		  
			
	//Variables relacionadas a InfCredito MODAL			
	var $tablaInfCredito = $("#tabla-InfCredito");	
	$tablaInfCredito.footable({
		"paging": {
			"enabled": true,
			"size": 20
		}
	});
	var _itemEditandoInfCredito=false;	
	var _ItemsInfCredito = [];
	//Variable estatica sirve para Saber que columnas van a ser identificadas al momento de renderizar tabla inf CREDITO
	var	_itemSchemaInfCredito = {
		modificar:"Modificar",
		eliminar:"Eliminar",
		numeroCuota:"Numero Cuota",
		montoCuota:"Monto Cuota",
		fechaVencimiento:"Fecha Vencimiento"
	};

	//Variables relacionadas a InfCuotas
	var $modalInfCuotas = $("#modal-InfCuotas");
	var $btnMostrarModalInfCuotas = $("#btnMostrarModalInfCuotas");
	
	var $btnMostrarPreliminar = $("#btnMostrarPreliminar");
	
	var $formModalInfCuotas = $modalInfCuotas.find('#form-modal-InfCuotas');   
	var	$CantidadEditada=0;
	
	var $ImporteTotal= Number($("#importeTotal29").numVal()); // RECUPERA IMPORTE TOTAL DE INPUT HIDDEN 
	var $CreditoCuotasMaximo= Number($("#creditoCuotasMaximo29").val()); // RECUPERA MAXIMO CUOTAS DE INPUT HIDDEN 
	var $FechaEmision=$('#fecEmision29').val();
	
	//FIN-OPV: PAS20201U210100231-OPV Variables InfCredito y Cuotas 
	var $modalPreloaderCredito = $('#modalPreloader');
	$modalPreloaderCredito.modal({
        backdrop: 'static',
        keyboard: false,
        show: false
    });						   
	recuperarDatosInfCredito();	
 
//--------------Formulario y metodos Inf-CREDITO-----------------------
	
	//PAS20201U210100231-OPV
	function recuperarDatosInfCredito(){		
		var url = 'emitirNCFEResp.do?action=getJsonItemsNCFactoring'; 
    	$.ajax({
            url: url,
            type: "POST",
            dataType: 'json',
            success: function(data) { 
				if(data.items.length!=0){
					_ItemsInfCredito = [];
					//OPV-INI-Compatibilidad Internet Explorer	
					//data.items.forEach(element=>{	
					for (i=0; i < data.items.length; i++) {
						var element=data.items[i];
						var dataCuota={
							modificar:element.modifica,
							eliminar:element.elimina,
							numeroCuota: element.numeroCuota,
							montoCuota: element.montoCuota,
							fechaVencimiento: element.fechaVencimiento, 
							fechaVencimientoDate: stringToDate(element.fechaVencimiento,"dd/MM/yyyy","/"),
							modificado: Number(element.modificado)
						};	
						dataCuota.itemId = _.uniqueId('');
						agregarInfCuotas(dataCuota);
						_itemEditandoInfCredito = false;     
						//Recalcular y Renderizar -opv
						// for(i=0;i< _ItemsInfCredito.length;i++){					
						// 	_ItemsInfCredito[i].numeroCuota=i+1;
						// }
						renderInfCredito();
					}
					//OPV-FIN-Compatibilidad Internet Explorer
				}            
            },
    		
            error: function () {

            },
            complete: function () {

            }
          });

	}
	//PAS20201U210100231-OPV

	function validarFormInfCreditoValidarSiEditaron(){	
		var existeError=false;
		
		//Deberia ser "true" si es modificada
		var grillaModificada=false;
		//Deberia ser "false" si es modificada
		var errorMontoNoModificado=false;
		//OPV-INI-Compatibilidad Internet Explorer	
		//_ItemsInfCredito.forEach(element=>{
		for (i=0; i < _ItemsInfCredito.length; i++) {
			var element=_ItemsInfCredito[i];
			if(element.modificado==1){
				grillaModificada=true;
			}
		};	
		//OPV-FIN-Compatibilidad Internet Explorer		
		if( Number($("#txtMontoNetoOriginal").numVal()) == Number($("#txtMontoNeto").numVal())){
			errorMontoNoModificado=true;
		}
		if(grillaModificada==false && errorMontoNoModificado==true){
			existeError=true
		}

		return existeError;
	}
	
	//PAS20201U210100231-OPV
	function validarFormInfCreditoSumaCuotas(){
		
		var montoNeto = Number($('#txtMontoNeto').numVal()); //PAS20211U210700145 - EBV

		if($ImporteTotal==0)
		{
			return true;
		} 
		//
		var sumaCuot = $SumaMontoInfCredito.toFixed(2);
		if(sumaCuot!=montoNeto)//PAS20211U210700145 - EBV
		{
			return true;
		} 	

		return false;
	}
	
	//INI-OPV:PAS20201U210100231-Validaciones para Inf-CREDITO
 
	//PAS20201U210100231-OPV
	function validarFormInfCreditoDespuesMinimoCuotas(){																	  
																		 
		if(_ItemsInfCredito.length==0 )
		{			
			return true;
  
		} 
		return false;
	}
	//PAS20201U210100231-OPV

	
	//PAS20201U210100231-OPV fecha de Emision mayor a fecha de vencimiento
	function validarFormInfCreditoDespuesMinimoFechaVencimiento(){
		var existeError=false;
																				  
    		if(_ItemsInfCredito.length>0 )
			{		
				 var fechaEmision= stringToDate($FechaEmision,"dd/MM/yyyy","/");
				//VALIDAR SI EXISTEN CUOTAS CON FECHA DE VENCIMIENTO MENOR
				//OPV-INI-Compatibilidad Internet Explorer	
				//_ItemsInfCredito.forEach(element=>{
				for (i=0; i < _ItemsInfCredito.length; i++) {
					var element=_ItemsInfCredito[i];
					if(fechaEmision>element.fechaVencimientoDate){
						existeError= true;						
					}

				};
				//OPV-FIN-Compatibilidad Internet Explorer
			} 
 
		return existeError;
	}		 
						 
											
   
					  
   
			   
	
  
										
   
			   
	 

			   
  
	//INI-OPV:PAS20201U210100231
	function validarFormInfCreditoMontoNeto(){
		 
		if($ImporteTotal==0)
		{
			return true;
		} 
		
		;
		if(Number($('#txtMontoNeto').numVal())>$ImporteTotal )
		{
			return true;
		} 	
   
		return false;
	}
	
	
	//FIN-OPV:PAS20201U210100231-Validaciones para InfCredito
	$formInfCredito.validate(_.extend(window._validatorWallSettings, {
        debug: true,
		ignore: "",
        rules: {
			hiddenHelperInfCreditoAntes:{
				required: function (argument) {
					return validarFormInfCreditoValidarSiEditaron()
				},												 
   
				moreThan: function (argument) {
					return validarFormInfCreditoSumaCuotas()
				},
			},	
			txtMontoNeto: {
                required: true,
				moreThan:0,
				lessThan: function (argument) {
					return validarFormInfCreditoMontoNeto()
				},

            },
			txtMotivo: {
                required: {

                    depends: function() {
                        $(this).val($.trim($(this).val()));
                        return true;
                    }

                },
                minlength: 5,
                validStr: true,
                maxlength: 250

            },
			hiddenHelperInfCreditoDespues:{
				required: function (argument) {
					return validarFormInfCreditoDespuesMinimoCuotas()
				},
				lessThan: function (argument) {
					return validarFormInfCreditoDespuesMinimoFechaVencimiento()
				},					
	  
			},
           
        },
        // estos mensajes estan aqui porque son dinamicos respecto al html
        messages: {
			hiddenHelperInfCreditoAntes: {
				required: 'Debe modificar al menos un campo del comprobante para continuar.',
											 
				moreThan: 'La suma de las cuotas debe ser igual al Monto neto pendiente de pago.' //PAS20211U210700145 - EBV				
            },			
            hiddenHelperInfCreditoDespues: {
				required: 'Agregue como mínimo una cuota a la Factura',   
				lessThan: 'Existen cuotas con fecha de vencimiento incorrectas, deben ser menor a la fecha de emisión del comprobante'				
            },
            txtMontoNeto: {
                required: 'Debe registrar el Monto neto pendiente de pago',
				moreThan: 'El monto debe ser mayor a 0',
				lessThan: 'El monto no puede ser mayor al importe total de la factura.'
            }
        },
		submitHandler: function(form) {			
				
			var url = 'emitirNCFEResp.do?action=guardarInfCredito';
			var url_redirigir = 'emitirNCFEResp.do?action=preliminarComprobante';
			//INI-OPV: PAS20201U210100231 -- ARRAY InfCredito
			var  _ListaCreditos=[];
			 //OPV-INI-Compatibilidad Internet Explorer
			 //_ItemsInfCredito.forEach(element=>{
			for (i=0; i < _ItemsInfCredito.length; i++) {
				  var element=_ItemsInfCredito[i];
				  var Cuota={
					  numeroCuota:element.numeroCuota,
					  montoCuota:element.montoCuota,
					  fechaVencimiento:element.fechaVencimiento,
					  modificado:element.modificado
				  }
				  _ListaCreditos.push(Cuota);	
				
			  };	
			 //OPV-FIN-Compatibilidad Internet Explorer
			 //FIN-OPV: PAS20201U210100231 
			
			var _datosEnvio = {
				InfCredito: {
					//PAS20201U210100231-OPV   Factoring Credito
					ListaCreditos:	_ListaCreditos
					,MontoNetoPendiente: $('#txtMontoNeto').numVal()//PAS20201U210100231-OPV
					,txtMotivo: $('#txtMotivo').val()
				 },
			};
			$modalPreloaderCredito.modal('show');  
			 $.ajax({
					data: {
						variable: JSON.stringify(_datosEnvio),
					},
					method: 'post',
					dataType: 'json',
					url: url,
				}).done(function (data, textStatus, jqXHR) {
					//PAS20201U210100231-OPV   Validaciones y Respuestas
					if ( data.codeError == 1){
						var msj = data.messageError;
						$modalPreloaderCredito.modal('hide');		
						$('#divMensaje').text(msj);
						var $modalMensajes = $('#modalMensajes');
						$modalMensajes.modal('show'); 
					}else if( data.codeError == 0){
						$modalPreloaderCredito.modal('hide');
						window.location.href = url_redirigir;  
					}
					//PAS20201U210100231-OPV  
				}).fail(function (jqXHR, textStatus, errorThrown) {
					if (console && console.log) {
						console.log("La solicitud a fallado: " + textStatus);
					}
					$modalPreloader.modal('hide');			
					alert('Se presentó un inconveniente al emitir el comprobante. Verifique las consultas. Inténtelo en unos minutos.');
					return;
				});

			}
   
	}));
	
	//PAS20201U210100231-OPV
	function evalNull(object) {
		var result = false;
		if (object != null && typeof object != "undefined") {
			if (object instanceof Array) {
				if (object.length > 0)
					result = true;
			} else {
				result = true;
			}
		}
		return result;
	}
	//PAS20201U210100231-OPV
	function isNoEmpty(object) {
		var result = false;
		if (object != null && object != "" && typeof object != "undefined") {
			if (object instanceof Array) {
				if (object.length > 0)
					result = true;
			} else {
				result = true;
			}
		}
		return result;
	}
	//PAS20201U210100231-OPV
	function showMensajeConfirmacion(mensaje, fn, titulo, fnHiddenModal) {
		titulo = $.trim(titulo) || 'Mensaje';
		var idRamdon = Math.round(Math.random() * 10009874621);
		var $m = $('<div class="modal fade" id="m' + idRamdon
				+ '" tabindex="-1" role="dialog" aria-labelledby="' + titulo
				+ '" aria-hidden="true"/>');
		var $mDialog = $('<div class="modal-dialog">');
		var $mContent = $('<div class="modal-content">');
		if (evalNull(titulo)) {
			$mContent.append('<div class="modal-header"><h3 class="modal-title">'
					+ titulo + '</h3></div>');
		}
		var mBody = $('<div class="modal-body">');
		mBody
				.append('<div class="row">'
						+ '<div class="col-md-12 col-xs-12 text-center ">'
						+ '<button type="button" class="btn si-modal btn-primary">Aceptar</button>'
						+ '</div>' + '</div>');
		mBody.prepend('<p class="text-justify">' + mensaje + '</p>');
		var btnSI = $(mBody.find('.si-modal').get(0));
		btnSI.click(function() {
			if ($.isFunction(fn))
				fn();
			$m.modal('hide');
		});
		$m.on('hidden.bs.modal', function(e) {
			$m.remove();
			if ($.isFunction(fnHiddenModal))
				fnHiddenModal($m);
		})
		$m.append($mDialog);
		$mDialog.append($mContent);
		$mContent.append(mBody);
		$m.modal({
			show : true,
			backdrop : "static"
		});
	}
	
	
//--------------Formulario y metodos Inf-CUOTAS-----------------------
	
	//INI-OPV: PAS20201U210100231
	$btnMostrarModalInfCuotas.on('click', function (e) {
	  _itemEditandoInfCredito=false;
	  $CantidadEditada=0;
	  $('#txtInfCuotasMonto').val(0);
	  $('#txtInfCuotasFechaVencimiento').val(null);
      $modalInfCuotas.modal('show');
    });
	
	//PAS20201U210100231-OPV EN CASO SE NECESITE MANEJAR EL DATEPICKER DE INFCUOTAS
/* 	var $datepickerInfCuotas = $('#txtInfCuotasFechaVencimiento');
	$datepickerInfCuotas.datepicker({
        endDate: new Date(),
		startDate: '-2d'
    }).on('changeDate', function(e) {
        $datepickerHidden.val(e.format());		
    }); */
	
	//PAS20201U210100231-OPV Funcion Generica para transformar string a date
	function stringToDate(_date,_format,_delimiter)
	{
		var formatLowerCase=_format.toLowerCase();
		var formatItems=formatLowerCase.split(_delimiter);
		var dateItems=_date.split(_delimiter);
		var monthIndex=formatItems.indexOf("mm");
		var dayIndex=formatItems.indexOf("dd");
		var yearIndex=formatItems.indexOf("yyyy");
		var month=parseInt(dateItems[monthIndex]);
		month-=1;
		var formatedDate = new Date(dateItems[yearIndex],month,dateItems[dayIndex]);
		return formatedDate;
	};
	//INI-OPV: PAS20201U210100231-Validaciones para infCuotas
	function validarFormInfCuotaFecha(){
		var fechaString=$('#txtInfCuotasFechaVencimiento').val();
		if(fechaString!=''){
			var fechaDate=stringToDate(fechaString,"dd/MM/yyyy","/");
			var fechaEmision= stringToDate($FechaEmision,"dd/MM/yyyy","/");
			if(fechaDate<=fechaEmision){//PAS20211U210700145 - EBV
				return true;
			}			
		}		
		return false ;
	}
	//PAS20201U210100231-OPV
	function validarFormInfCuotaMaximoNumeroCuotas(){
		var maximoNumeroCuotaHidden= Number($('#globalcreditoCuotasMaximo').val());
		if($CantidadEditada!=0){
			return false;
		}
		else if(_ItemsInfCredito.length==maximoNumeroCuotaHidden ){			
			return true;
		} 	
		return false;
	}
	//PAS20201U210100231-OPV
	function validarFormInfCuotaSumaCuotas(){
		var temporal=0;
		var montoNeto = Number($('#txtMontoNeto').numVal()); //PAS20211U210700145 - EBV
		if($CantidadEditada==0){
			
			temporal=Number($SumaMontoInfCredito);
		}else{
			temporal=Number($SumaMontoInfCredito)-$CantidadEditada;
		}				
		var sumaProvisional= (Number($('#txtInfCuotasMonto').numVal())+temporal);
		if(sumaProvisional!=montoNeto) //PAS20211U210700145 - EBV
		{
			return true;
		} 
		return false;
	}
	
	//FIN-OPV: PAS20201U210100231 -Validaciones para infCuotas
	

	//INI-OPV: PAS20201U210100231 Ejecucion Validaciones de InfCuotas
	$formModalInfCuotas.validate(_.extend(window._validatorWallSettings, {
        debug: true,
        rules: {
			hiddenHelperInfCuotas:{
				required: function (argument) {
					return validarFormInfCuotaMaximoNumeroCuotas()
				},
			},			
            txtInfCuotasMonto: {
				required: true,   
				moreThan: 0,
				//lessThan: function (argument) {
				//	return validarFormInfCuotaSumaCuotas() //PAS20211U210700145 - EBV	
				//},			
            },
            txtInfCuotasFechaVencimiento: {
                required: true,
				moreThan: function (argument) {
					return validarFormInfCuotaFecha()
				},
            }
           
        },
        // estos mensajes estan aqui porque son d&iacute;n&aacute;micos respecto al html
        messages: {
			hiddenHelperInfCuotas: {
				required: 'Su comprobante electrónico puede tener máximo 12 cuotas',      
            },			
            txtInfCuotasMonto: {
				required: 'Ingrese monto de la cuota', 
				moreThan: 'El monto de cuota debe ser mayor a cero',
				//lessThan: 'La suma de las cuotas debe ser igual al Monto neto pendiente de pago.' //PAS20211U210700145 - EBV				
            },
            txtInfCuotasFechaVencimiento: {
                required: 'Ingrese una fecha de vencimiento',
				moreThan: 'La fecha de la cuota debe ser mayor a la fecha de emisión' //PAS20211U210700145 - EBV
            }
        },
        submitHandler: function(form) {
            var data = $(form).last().serializeObject(); 

			var dataCuota={
				modificar:"Modificar",
				eliminar:"Eliminar",
				numeroCuota: 0,
				montoCuota: data.txtInfCuotasMonto,
				fechaVencimiento: data.txtInfCuotasFechaVencimiento, 
				fechaVencimientoDate: stringToDate(data.txtInfCuotasFechaVencimiento,"dd/MM/yyyy","/"),
				modificado: 1				
			};
            if (_itemEditandoInfCredito) {
                console.log("edit InfCuotas"); 
                editarInfCuotas({
                    itemId: _itemEditandoInfCredito
                }, dataCuota);
            } else {
                console.log("add InfCuotas"); 
                dataCuota.itemId = _.uniqueId('');
                agregarInfCuotas(dataCuota);
            }
            $modalInfCuotas.modal('hide');
            _itemEditandoInfCredito = false;     
			//Recalcular y Renderizar -opv
            infCreditoOrdenarPorFecha();
			renderInfCredito();
        }
    }));
	
	
	
	//PAS20201U210100231-OPV
	function agregarInfCuotas(data) {
        _ItemsInfCredito.push(data);
    }
	//PAS20201U210100231-OPV
    function eliminarInfCuotas(criteria) {
        _ItemsInfCredito = _.reject(_ItemsInfCredito, criteria);
    }
	//PAS20201U210100231-OPV
    function buscarInfCuotas(criteria) {
        return _.find(_ItemsInfCredito, criteria);
    }
	//PAS20201U210100231-OPV
    function editarInfCuotas(criteria, data) {
        var doc = buscarInfCuotas(criteria);
        doc = _.extend(doc, data);
    }
	
 
	//PAS20201U210100231-OPV Renderizar Data a la tabla InfCredito
	function renderInfCredito() {
        var tbody = $tablaInfCredito.find('tbody');
        tbody.empty();   
		$SumaMontoInfCredito=0;
        for (var i in _ItemsInfCredito) {           
            var doc = _ItemsInfCredito[i];           
            var $row = $('<tr/>', {
                'data-item-id': doc.itemId
            });
            for (var k in _itemSchemaInfCredito) {
                var text = doc[k];
				if (k == 'modificar'){
					text = $('<td/>').append($('<button/>').attr('type', 'button').addClass('btn btn-warning btn-sm editar').append($('<i/>').addClass('glyphicon glyphicon-edit')));					
				}
				if (k == 'eliminar'){
					text =  $('<td/>').append($('<button/>').attr('type', 'button').addClass('btn btn-danger btn-sm remover').append($('<i/>').addClass('glyphicon glyphicon-remove')));
				}
				if(k == 'montoCuota'){
					$SumaMontoInfCredito=$SumaMontoInfCredito+ Number(text.replace(/,/g, ""));	
					var numero=Number(text.replace(/,/g, ""));
					text=numero.toMoney(2);				
				}				
                $('<td/>').html(text).appendTo($row);
            }
			$row.appendTo(tbody);
        }
        //$("#items-counter").text(_ItemsInfCredito.length)
        $modalInfCuotas.find('.lista-errores').empty();
/*      $panelItems.find('.lista-errores').empty();
        $hiddenHelperItem.val(_ItemsInfCredito.length); */
        $tablaInfCredito.trigger('footable_initialize');
    }
	//PAS20201U210100231-OPV Evento Eliminar Grilla InfCredito
	$tablaInfCredito.on('click', 'button.remover', function(e) {
        var rowId = $(e.target).closest('tr').attr('data-item-id');
        eliminarInfCuotas({
            itemId: rowId
        });
		//Recalcular y Renderizar -opv
		infCreditoOrdenarPorFecha();
        renderInfCredito();
    })
	//PAS20201U210100231-OPV Evento Editar Grilla InfCredito
    $tablaInfCredito.on('click', 'button.editar', function(e) {
        var rowId = $(e.target).closest('tr').attr('data-item-id');
        var currItem = buscarInfCuotas({
            itemId: rowId
        });
		//Preparar Modal con valores y mostrarlo
        _itemEditandoInfCredito = currItem.itemId;
        popularModalInfCuotas(currItem);
        $modalInfCuotas.modal('show');
    })
	//PAS20201U210100231-OPV Actualizar Valores del Modal
	function popularModalInfCuotas(data, triggerChange, ignoreCodigo) {
		$('#txtInfCuotasMonto').val(data.montoCuota);
		$('#txtInfCuotasFechaVencimiento').val(data.fechaVencimiento);
		$CantidadEditada=Number(data.montoCuota);
    }
	//PAS20201U210100231-OPV Ordenar Data por fecha de vencimiento
	function infCreditoOrdenarPorFecha() {
		if(_ItemsInfCredito.length >0){
			//ORDENAR ELEMENTOS
			_ItemsInfCredito.sort(function (x, y) {
				let a = x.fechaVencimientoDate,
					b = y.fechaVencimientoDate;
				return a - b;
			});
			for(i=0;i< _ItemsInfCredito.length;i++){					
				_ItemsInfCredito[i].numeroCuota=i+1;	
				_ItemsInfCredito[i].modificado=1;
			}	
		}		
    }
	
	//METODOS UTILES
	
	
//FIN-OPV:PAS20201U210100231
	
	
}
//INI-PAS20201U210100231-DRR	
	function SoloNumeroDecimal(e, field) {
        key = e.keyCode ? e.keyCode : e.which
            // backspace
        if (key == 8) return true
            // 0-9 a partir del .decimal  
        if (field.value != "") {
            if ((field.value.indexOf(".")) > 0) {
                //si tiene un punto valida dos digitos en la parte decimal
                if (key > 47 && key < 58) {
                    if (field.value == "") return true
                        //regexp = /[0-9]{1,10}[\.][0-9]{1,3}$/
                    regexp = /[0-9]{2}$/
                    return !(regexp.test(field.value))
                }
            }
        }
        // 0-9 
        if (key > 47 && key < 58) {
            if (field.value == "") return true
            regexp = /[0-9]{10}/
            return !(regexp.test(field.value))
        }
        // .
        if (key == 46) {
            if (field.value == "") return false
            regexp = /^[0-9]+$/
			//PAS20201U210100231- reemplazar coma -OPV
			var remplazo=field.value;
			remplazo=remplazo.replaceAll(/,/g, "");
	        //return regexp.test(field.value)
			return regexp.test(remplazo);
			//PAS20201U210100231-OPV			   
        }
        // other key
        return false
    }	
//FIN-PAS20201U210100231-DRR	


function calculaRetencion(){
    
        //var $txtMontoRetencion =$('#txtMontoRetencion');
        var baseRetencion = $txtBaseImponible.numVal();
		var porcentajeRetencion = $txtPorcentaje.numVal();
		var montoRetencion = 0;

        montoRetencion = Number(baseRetencion)*Number(porcentajeRetencion)/100.00;

		$txtMontoRetencion.val(Number.parseFloat(Math.round(montoRetencion*100))/100);
    //$('#txtMontoRetencion').val(montoRetencion);
}


//INI-PAS20201U210100231-DRR
function InitInfRetencion(){
	
	//PAS20201U210100231-OPV
	function validarFormRetencionMayorImporteTotal(){
		var montototal=  $('#importe-total').numVal();
		if(Number($('#txtBaseImponible').numVal())>Number(montototal) && $('#txtTipoMoneda28').val()=="PEN")
		{
			return true;
		} 
		return false;
	}
	

	
    /*
    $btnPreview.on('click', function (e) {

        if($txtBaseImponible.val().length>0){
            if(!$formretencion.valid())
            return;
        }
        
            
    });
*/

    $formretencion.validate(_.extend(window._validatorWallSettings, {
        rules: {
            txtBaseImponible:{
				notEqual: $('#txtBaseImponibleHidden').numVal(),
                moreThan: 0,
				lessThan: function (argument) {
					return validarFormRetencionMayorImporteTotal() 
				},	
            },
			
			txtMotivo: {
                required: {

                    depends: function() {
                        $(this).val($.trim($(this).val()));
                        return true;
                    }

                },
                minlength: 5,
                validStr: true,
                maxlength: 250

            }
            
        },
        messages: {
			
            txtBaseImponible:{
				notEqual: "Debe modificar al menos un campo del comprobante para continuar",
                moreThan: 'El monto base debe ser mayor a cero',
                lessThan: "El monto base no puede ser mayor al importe total de la factura"
            }
        },
        submitHandler: function(form) {
            form.submit();
            // eliminar todo esto en el vivo.
            //window.location.href = 'paso-3.html';
        }
    }))
}


//FIN-PAS20201U210100231-DRR