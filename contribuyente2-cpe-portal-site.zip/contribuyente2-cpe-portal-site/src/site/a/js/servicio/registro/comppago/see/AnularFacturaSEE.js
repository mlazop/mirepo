/**
 * AnularFacturaSEE.js - JavaScript de la Anulacion de Facturas Electronicas
 * Author: Patricia Chacaliaza
 * Fecha: 02-03-2010
 * ResponseBean : codeError; messageError; data;
 */
if (!dojo._hasResource["sunat.comprobante.AnularFacturaSEE"]) {
dojo._hasResource["sunat.comprobante.AnularFacturaSEE"] = true;
dojo.provide("sunat.comprobante.AnularFacturaSEE");

dojo.require("dojo.data.ItemFileWriteStore");
dojo.require("dojo.data.ItemFileReadStore");
dojo.require("dojo.io.iframe");
dojo.require("dojox.grid.DataGrid");
dojo.require("dojox.grid.cells.dijit");
dojo.require("dojox.data.CsvStore");
dojo.require("dijit.form.Button");
dojo.require("dojo.data.api.Read");
dojo.require("dojo.parser");

dojo.declare("sunat.comprobante.AnularFacturaSEE", null,{
	storeFacturasxAnular: null,


	count: 0,
	
	controller: "rechazar.do",
	
	constructor: function() {},

	initialize: function() {
		this.content = dijit.byId("content");
			
	  this.waitMessage = dijit.byId("waitMessage");
    
		var size = dojo.marginBox(this.content.domNode);
		x = Math.floor((size.w - 102)/2);
		y = Math.floor((size.h - 34)/2);

		this.content.loadingMessage = 
		'<div class="ext-el-mask-msg x-mask-loading" style="left: ' + x + 'px; top: ' + y + 'px;"><div>Cargando...</div></div>';
	},

	startup: function(){

		dojo.parser.parse(dojo.byId('container'));
		setTimeout(dojo.hitch(this, function(){
			this.hideLoader();
		}), 250);

	},

	
	 salirAfiliarSEE: function(){

		 this.messageBoxOKCancel("Desea salir del aplicativo.","icon-alert-info" );

	},
	
	cerrarAfiliarSEE: function(){
  dijit.byId('dialogOkCancel').hide();
		 //this.delete;

	},
/***inicio whr ***/
	mostrarFacturaRechazada: function(){

	var fechaEmi=dojo.date.locale.format(dijit.byId("fecEmisionFac").getValue(), {datePattern: "yyyy/MM/dd", selector: "date"});
	this.wait("consultando", "95px");
           var handler = dojo.xhrGet({
                url: this.controller + "?action=verificarExistenciaFacturasPendientesRechazoPorFecha&fecEmisionFac=" +fechaEmi,
				//sync: true,
                handleAs: "json",
                timeout: 4000000
            });        

         handler.addCallback(dojo.hitch(this, function(res){
             this.waitMessage.hide();
            if (res.codeError == 0) {
					var grid = dijit.byId("facturasGrid");
					var datos = eval("(" + res.data + ")");
					var jsonStoreFacturasxAnular = new dojo.data.ItemFileWriteStore({
							data: {
								identifier: datos.identifier,
								label: datos.label,
								items: datos.items
							},
							handleAs: "json",
							 clearOnClose: true,
						urlPreventCache: true //WHR, quitamos la coma
						});	

					grid.noDataMessage = "<span color=blue >Contribuyente No tiene facturas pendientes de rechazo.</span>";
					grid.setStore(jsonStoreFacturasxAnular);
              grid.render();

			}
			else {
				alert("De persistir el problema, comuniquese a nuestra central de atención http://www.sunat.gob.pe/quienesSomos/callcenter.html. ");
			}
		}));
		
		handler.addErrback(function(res){
	           this.waitMessage.hide();
	        
			alert("Problemas al conectarse con el servidor");
		});
	},
	
	/***fin whr ***/
	
anularFacturas: function(){
			var grilla =dijit.byId('facturasGrid');
      var datos =grilla.store._arrayOfAllItems;
      var filas = grilla.store._arrayOfAllItems.length;
      //alert (filas);
      var numSeleccionados=0;
      var numComboVacio=0;
      
      for (i=0; i< filas;i++){
        var fila = grilla.getItem(i);
        var valorCheck = grilla.store.getValue(fila, "ind_rechazo");
      
        if (valorCheck==true){
            numSeleccionados ++;
            var celda = grilla.getCell(6);
            if (celda.getValue(i)!= "1" &&  celda.getValue(i)!= "2" && celda.getValue(i)!= "3" ){
                numComboVacio++;
            }

        }
      }
      
      if (numSeleccionados == 0){
          alert("No se han seleccionado Facturas Electr\xf3nicas para ser rechazadas");
          return;
      }else{
          if (numComboVacio > 0){
             alert("Todas las Facturas seleccionadas deben consignar un motivo de rechazo");
             return;
          }
      }
      
      if (confirm("\xbfEst\xe1 seguro de rechazar la(s) Factura(s) Electr\xf3nica(s) seleccionada(s)?")){
         this.grabarAnularFacturas()
      }

	},
	
	grabarAnularFacturas: function(){
	
    var dialogAlert = dijit.byId("dialogOkCancelGrabar");
     dialogAlert.hide();
    var nbControl = dijit.byId("listfactxanularSEE.btnGrabar");
		nbControl.setAttribute('disabled', true);
    

    var grilla =dijit.byId('facturasGrid');
      

      var filas = grilla.store._arrayOfAllItems.length;
      var data ="[";
      for (i=0; i< filas;i++){
        var fila = grilla.getItem(i);
        
        var valorCheck = grilla.store.getValue(fila, "ind_rechazo");
       
        if (valorCheck == true) {
            var celda1 = grilla.getCell(1);
            var celda5 = grilla.getCell(5);
            var celda6 = grilla.getCell(6);
            var valorCelda1 = grilla.store.getValue(fila, "uid2");
            var valorCelda3 = grilla.store.getValue(fila, "num_importe_total");
            var valorCelda7 = grilla.store.getValue(fila, "tip_doc_recep");
            var valorCelda8 = grilla.store.getValue(fila, "num_ruc_recep");
            var valorCelda9 = grilla.store.getValue(fila, "num_ruc");
            if (data.length > 1){ data = data +",";}
            data = data + "{" + celda1.name + ":'" +valorCelda1 +"'," +
            "ind_rechazo" + ":'" +celda5.getValue(i) +"'," +
            "tip_doc_recep"  + ":'" +valorCelda7 +"'," +
            "num_ruc_recep"  + ":'" +valorCelda8 +"'," +
            "motivo_rechazo" + ":'" +celda6.getValue(i) +"'," +
            "num_ruc" + ":'" +valorCelda9 +"'," +
            "num_importe_total" + ":'" +valorCelda3 +"'}";
        }
      }
      data = data + "]";
      this.wait("Grabando", "95px");
           var handler = dojo.xhrGet({
                url: this.controller + "?action=anularFacturas&items=" +data,
                handleAs: "json",
                sync: true,
                timeout: 10000
            });        

         handler.addCallback(dojo.hitch(this, function(res){
             this.waitMessage.hide();
             nbControl.setAttribute('disabled', false);
			if (res.codeError == 0) {
					nbControl.setAttribute('disabled', false);
                    var newStore = new dojo.data.ItemFileWriteStore({url: 'rechazar.do?action=getFacturasPorAnular'});
                    var grid = dijit.byId("facturasGrid");
                    grid.setStore(newStore);
                    alert("Se rechazaron las facturas seleccionadas.");
 			}
			else {
				nbControl.setAttribute('disabled', false);
				alert("Problemas al grabar los rechazos");
			}
		}));
		handler.addErrback(function(res){
	           this.waitMessage.hide();
	           nbControl.setAttribute('disabled', false);
			alert("Problemas al conectarse con el servidor");
		});
	},
  preventCache: function() {
		return new Date().valueOf();
	},
  		
	initContent: function() {

	},
	
	onStartDialog: function(idDialog, idControl) {
   userGrid = dijit.byId('userListingGrid');
	},
	
		
	hideLoader: function(){
		this.initialize();
		var loader = dojo.byId('loader');
		var _this = this;
		dojo.fadeOut({
			node: loader,
			duration: 250,
			onEnd: function(){
				dijit.byId('main').domNode.style.visibility = "visible";
				loader.style.display = "none";
			}
		}).play();
	},
	
	messageBoxError: function(message, iconClass) {
		var dialogAlert = dijit.byId("dialogAlert");
		if(dialogAlert) {
			dojo.byId("alertMessage").innerHTML=this.chunkString(message, 40);
			if(iconClass) dojo.addClass("alertIcon", iconClass);
			else dojo.addClass("alertIcon", "icon-alert-error");
			dijit.byId('dialogAlert').domNode.style.visibility = "visible";

			dialogAlert.show();
		}
	},
	
	messageBoxOKCancel: function(message, iconClass) {
		var dialogAlert = dijit.byId("dialogOkCancel");
		if(dialogAlert) {
			dojo.byId("ok_cancelMessage").innerHTML=this.chunkString(message, 40);
			if(iconClass) dojo.addClass("ok_cancelIcon", iconClass);
			else dojo.addClass("ok_cancelIcon", "icon-alert-info");
			dijit.byId('dialogOkCancel').domNode.style.visibility = "visible";

			dialogAlert.show();
		}
	},
	
		messageBoxOKCancelGrabar: function(message, iconClass) {
		var dialogAlert = dijit.byId("dialogOkCancelGrabar");
		if(dialogAlert) {
			dojo.byId("ok_cancelMessage2").innerHTML=this.chunkString(message, 40);
			if(iconClass) dojo.addClass("ok_cancelIcon2", iconClass);
			else dojo.addClass("ok_cancelIcon2", "icon-alert-info");
			dijit.byId('dialogOkCancelGrabar').domNode.style.visibility = "visible";

			dialogAlert.show();
		}
	},
	
	
	chunkString: function(cad, size) {
		var aCad = cad.split(" ");
		for(i = 0; i < aCad.length; i++) {
			if(aCad[i].length > size) {
				return this.wordWrap(cad, size, "<br/>", 2);
			}
		}
		return cad;
	},
	
	wordWrap: function(cad, m, b, c) {
	    var i, j, l, s, r;
	    if(m < 1) return cad;
	    for(i = -1, l = (r = cad.split("\n")).length; ++i < l; r[i] += s)
	        for(s = r[i], r[i] = ""; s.length > m; r[i] += s.slice(0, j) + ((s = s.slice(j)).length ? b : ""))
	            j = c == 2 || (j = s.slice(0, m + 1).match(/\S*(\s)?$/))[1] ? m : j.input.length - j[0].length
	            || c == 1 && m || j.input.length + (j = s.slice(m).match(/^\S*/)).input.length;
	    return r.join("\n");
	},
	
    formatNumFactura: function(value, rowindex) {
      return  value + " " + "<a href=\"#\" onclick=\"anularFacturaSEE.verXml('" + rowindex +  "')\"><img  src=\"/a/imagenes/documents.gif\" /> </a>"
    }  ,
	
	verXml: function(rowIndex) {
        var grilla =dijit.byId('facturasGrid');
        var fila = grilla.getItem(rowIndex);
        
        var valorCelda1 = grilla.store.getValue(fila, "uid2");

       var handler = dojo.xhrGet({
                url: this.controller + "?action=obtenerXml&factura=" +valorCelda1,
                handleAs: "json",
                sync: true,
                timeout: 10000
         });        
         handler.addCallback(dojo.hitch(this, function(res){
			if (res.codeError == 0) {
                var xml=dijit.byId("facturaxml");
                var dFactura = dijit.byId("dialogFactura");
		         if(dFactura) {      
             			dFactura.show();
                        xml.attr("href","FacturaGenerada.jsp");
		          }                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                
			}
			else {                                 
				alert("Problemas al obtener la factura");
			}
		}));
		handler.addErrback(function(res){
			this.waitMessage.hide();
			alert("Problemas al conectarse con el servidor");
		});

        
    },
    
    xmlShow: function(texto) {
		var dialogAlert = dijit.byId("dialogFactura");
		if(dialogAlert) {
             dojo.byId("dialogFactura").innerHTML= texto; 
			dialogAlert.show();
		}
	},

    
	habilitaMotivoRechazo: function(rowindex,object) {
    if (object!=null){
    	
        var grilla =dijit.byId('facturasGrid');
        var fila = grilla.getItem(rowindex);
        var valorCheck = grilla.store.getValue(fila, "ind_rechazo");

        //alert (celda3);
        //celda.rowindex=-1;
        //celda2.index= -1;
        //celda2=" ";
        //for (i=0; i< 5;i++){
            var celda = grilla.getCell(6);
            var celda2 = grilla.store.getValue(fila, "motivo_rechazo");
            if (valorCheck==true){
                celda.editable=true;
                //celda.setValue("-");
                celda.rowindex=-1;celda.rowindex=-1;
                
                //celda2.index= -1;
            }else{
            	celda.setValue("-");
                celda.rowindex=-1;celda.rowindex=-1;
                celda.editable=false;
                if (celda2 =="1" || celda2 =="2" ||  celda2 =="3" ){
                  	celda = grilla.getCell(6);
                	celda2 = grilla.store.getValue(fila, "motivo_rechazo");
                	celda.editable=true;
                	celda.setValue("-");
                    celda.rowindex=-1;celda.rowindex=-1;
                    celda.editable=false;
                }	
                if (celda2 =="1" || celda2 =="2" ||  celda2 =="3" ){
                  	celda = grilla.getCell(6);
                	celda2 = grilla.store.getValue(fila, "motivo_rechazo");
                	celda.editable=true;
                	celda.setValue("-");
                    celda.rowindex=-1;celda.rowindex=-1;
                    celda.editable=false;
                }	
            }
            valorCheck = grilla.store.getValue(fila, "ind_rechazo");
            if (valorCheck==true){
                celda.editable=true;
                celda.rowindex=-1;celda.rowindex=-1;
            }else{
            	celda.setValue("-");
                celda.rowindex=-1;celda.rowindex=-1;
                celda.editable=false;
            }
        //}
       
        return valorCheck;
    }
    
  },
  
  	wait: function(message, width) {

	  dojo.byId("waitMessage").innerHTML="<div dojoType='dijit.ProgressBar'  indeterminate='true' >&nbsp;" + message + "...</div>";
		//this.waitMessage.setMessage("<div class='dijitInline box-message'></div><div class='dijitInline'>&nbsp;" + message + "...</div>");
        dojo.byId("waitMessage").style.width = width;
		//this.waitMessage.setWidth(width);
		this.waitMessage.show();
	},
	
    
     
  trim : function(str, chars) {
	return this.ltrim(this.rtrim(str, chars), chars);
},
 
 ltrim : function(str, chars) {
	chars = chars || "\\s";
	return str.replace(new RegExp("^[" + chars + "]+", "g"), "");
},
 
 rtrim : function( str, chars) {
	chars = chars || "\\s";
	return str.replace(new RegExp("[" + chars + "]+$", "g"), "");
},

    imprimirPDF : function(){
            window.open(this.controller + "?action=imprimirPDF" );
    }
    
    
});

}
