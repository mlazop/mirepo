// (function(window, $, _) {
    /*
     * :::: CONTAINERS :::: START
     */


 var $formTerminos = $("#form-terminos");

var $chkacepto=$("#chkacepto");



    $formTerminos.validate(_.extend(window._validatorWallSettings, {
        debug: false,
        rules: {
            chkacepto: {
                required: true
            }
        },

        messages: { 

      
          chkacepto: {

        required: "Debe aceptar los t&eacute;rminos y condiciones"

        }


    }
       
        
    }));

    $formTerminos.submit();




// })(window, jQuery, _);