var $modalPreloader = $('#modalPreloader');
	

var isMobile = {
	Android: function() {
		return navigator.userAgent.match(/Android/i);
	},
	BlackBerry: function() {
		return navigator.userAgent.match(/BlackBerry/i);
	},
	iOS: function() {
		return navigator.userAgent.match(/iPhone|iPad|iPod/i);
	},
	Opera: function() {
		return navigator.userAgent.match(/Opera Mini/i);
	},
	Windows: function() {
		return navigator.userAgent.match(/IEMobile/i);
	},
	any: function() {
		return (isMobile.Android() || isMobile.BlackBerry() || isMobile.iOS() || isMobile.Opera() || isMobile.Windows());
	}
};	


var _monedaDescripcion = {
	'PEN': 'SOLES',
	'XEU': 'EUROS',
	'USD': 'DOLAR AMERICANO',
	'GBP': 'LIBRA ESTERLINA',
	'JPY': 'YEN',
	'SEK': 'CORONA SUECA',
	'CHF': 'FRANCO SUIZO',
	'CAD': 'DOLAR CANADIENSE'
}

var _monedaDescripcion2 = {
	'SOLES': 'PEN',
	'EUROS': 'XEU',
	'DOLAR AMERICANO': 'USD',
	'LIBRA ESTERLINA': 'GBP',
	'YEN': 'JPY' ,
	'CORONA SUECA': 'SEK',
	'FRANCO SUIZO': 'CHF',
	'DOLAR CANADIENSE': 'CAD' 
}



var _mediopago = {	
'007':'CHEQUES CON LA CL&Aacute;USULA DE "NO NEGOCIABLE", "INTRANSFERIBLES", "NO A LA ORDEN" U OTRA EQUIVALENTE, A QUE SE REFIERE EL INCISO G) DEL ARTICULO 5� DE LA LEY',
'001':'DEP&Oacute;SITO EN CUENTA',
'011':'DOCUMENTOS EMITIDOS POR LAS EDPYMES Y LAS COOPERATIVAS DE AHORRO Y CR&Eacute;DITO NO AUTORIZADAS A CAPTAR DEP&Oacute;SITOS DEL P&Uacute;BLICO',
'008':'EFECTIVO, POR OPERACIONES EN LAS QUE NO EXISTE OBLIGACI&Oacute;N DE UTILIZAR MEDIO DE PAGO',
'009':'EFECTIVO, EN LOS DEM&Aacute;S CASOS',
'010':'MEDIOS DE PAGO USADOS EN COMERCIO EXTERIOR', 
'004':'ORDEN DE PAGO',
'005':'TARJETA DE D&Eacute;BITO',
'006':'TARJETA DE CR&Eacute;DITO EMITIDA EN EL PA&Iacute;S POR UNA EMPRESA DEL SISTEMA FINANCIERO', 
'012':'TARJETA DE CR&Eacute;DITO EMITIDA EN EL PA&Iacute;S O EN EL EXTERIOR POR UNA EMPRESA NO PERTENECIENTE AL SISTEMA FINANCIERO, CUYO OBJETO PRINCIPAL SEA LA EMISI&Oacute;N Y ADMINISTRACI&Oacute;N DE TARJETAS DE CR&Eacute;DITO',
'013':'TARJETAS DE CR&Eacute;DITO EMITIDAS EN EL EXTERIOR POR EMPRESAS BANCARIAS O FINANCIERAS NO DOMICILIADAS',
'003':'TRANSFERENCIA DE FONDOS',
'999':'OTROS MEDIOS DE PAGO'
}

/*
var _mediopago = {	
'001':'DEP&Oacute;SITO EN CUENTA',
'002':'GIRO',
'003':'TRANSFERENCIA DE FONDOS',
'004':'ORDEN DE PAGO',
'005':'TARJETA DE D&Eacute;BITO',
'006':'TARJETA DE CR&Eacute;DITO EMITIDA EN EL PA&Iacute;S POR UNA EMPRESA DEL SISTEMA FINANCIERO', 
'007':'CHEQUES CON LA CL&Aacute;USULA DE "NO NEGOCIABLE", "INTRANSFERIBLES", "NO A LA ORDEN" U OTRA EQUIVALENTE, A QUE SE REFIERE EL INCISO G) DEL ARTICULO 5� DE LA LEY',
'008':'EFECTIVO, POR OPERACIONES EN LAS QUE NO EXISTE OBLIGACI&Oacute;N DE UTILIZAR MEDIO DE PAGO',
'009':'EFECTIVO, EN LOS DEM&Aacute;S CASOS',
'010':'MEDIOS DE PAGO USADOS EN COMERCIO EXTERIOR', 
'011':'DOCUMENTOS EMITIDOS POR LAS EDPYMES Y LAS COOPERATIVAS DE AHORRO Y CR&Eacute;DITO NO AUTORIZADAS A CAPTAR DEP&Oacute;SITOS DEL P&Uacute;BLICO',
'012':'TARJETA DE CR&Eacute;DITO EMITIDA EN EL PA&Iacute;S O EN EL EXTERIOR POR UNA EMPRESA NO PERTENECIENTE AL SISTEMA FINANCIERO, CUYO OBJETO PRINCIPAL SEA LA EMISI&Oacute;N Y ADMINISTRACI&Oacute;N DE TARJETAS DE CR&Eacute;DITO',
'013':'TARJETAS DE CR&Eacute;DITO EMITIDAS EN EL EXTERIOR POR EMPRESAS BANCARIAS O FINANCIERAS NO DOMICILIADAS',
'101':'TRANSFERENCIAS - COMERCIO EXTERIOR',
'102':'CHEQUES BANCARIOS - COMERCIO EXTERIOR',
'103':'ORDEN DE PAGO SIMPLE - COMERCIO EXTERIOR',
'104':'ORDEN DE PAGO DOCUMENTARIO - COMERCIO EXTERIOR',
'105':'REMESA SIMPLE - COMERCIO EXTERIOR',
'106':'REMESA DOCUMENTARIA - COMERCIO EXTERIOR',
'107':'CARTA DE CR&Eacute;DITO SIMPLE - COMERCIO EXTERIOR',
'108':'CARTA DE CR&Eacute;DITO DOCUMENTARIO - COMERCIO EXTERIOR',
'999':'OTROS MEDIOS DE PAGO'
}
*/


var _tipoDireccion = {
	'01': 'PUNTO DE VENTA',
	'02': 'PUNTO DE PRODUCCI&Oacute;N',
	'03': 'PUNTO DE EXTRACCI&Oacute;N',
	'04': 'PUNTO DE EXPLOTACI&Oacute;N DE LOS PRODUCTOS',
	'05': 'NINGUNO'
}

var _tipoDocumentoRelacionado = {
	'09': 'Guia de Remisi&oacute;n Remitente',
	'31': 'Guia de Remisi&oacute;n de Transportista',
	'G9': 'Guia de Remisi&oacute;n por Eventos',
	'99': 'Otro documento'
}	

var _moneda = {
	'USD': '&dollar;',
	'PEN': 'S/',
	//'EUR': '&euro;',
	'XEU': '&euro;',
	'GBP': '&pound;',
	'JPY': '&yen;',
	'SEK': 'kr',
	'CAD': 'C&dollar;',        
	'CHF': 'CHF'
}	


var _tipoDocumentoIdentidad = {
	"1": "DNI",
	"4": "CARNET DE EXTRANJERIA",
	"7": "PASAPORTE"
	/*"4": "RUC"*/
}	

var _afectacionIGV = {
	"Gravado": "Gravado",
	"Exonerado": "Exonerado",
	"Inafecto": "Inafecto"
}		

var _afectacionIR = {
	"Gravado": "Gravado",
	"No Gravado": "No Gravado"
}			

var _porcentajeIR = {
	"0.015": "Tasa 1.50%",
	"0.04": "Tasa 4.00%"	
}	
var _tipoMedida = {
	'4A':'BOBINAS',
	'BE':'FARDO',
	'BG':'BOLSA',
	'BJ':'BALDE',
	'BLL':'BARRILES',
	'BO':'BOTELLAS',
	'BX':'CAJA',
	'C62':'PIEZAS',
	'CA':'LATAS',
	'CEN':'CIENTO DE UNIDADES',
	'CJ':'CONOS',
	'CMK':'CENTIMETRO CUADRADO',
	'CMQ':'CENTIMETRO CUBICO',
	'CMT':'CENTIMETRO LINEAL',
	'CT':'CARTONES',
	'CY':'CILINDRO',
	'DR':'TAMBOR',
	'DZN':'DOCENA',
	'DZP':'DOCENA POR 0**6 ',
	'FOT':'PIES',
	'FTK':'PIES CUADRADOS',
	'FTQ':'PIES CUBICOS',
	'GLI':'GALON INGLES (4,545956L)',
	'GLL':'US GALON (3,7843 L)',
	'GRM':'GRAMO',
	'GRO':'GRUESA',
	'HLT':'HECTOLITRO',
	'INH':'PULGADAS',
	'KGM':'KILOGRAMO',
	'KT':'KIT',
	'KTM':'KILOMETRO',
	'KWH':'KILOVATIO HORA',
	'LBR':'LIBRAS',
	'LEF':'HOJA',
	'LTN':'TONELADA LARGA',
	'LTR':'LITRO',
	'MGM':'MILIGRAMOS',
	'MLL':'MILLARES',
	'MLT':'MILILITRO',
	'MMK':'MILIMETRO CUADRADO',
	'MMQ':'MILIMETRO CUBICO',
	'MMT':'MILIMETRO ',
	'MTK':'METRO CUADRADO',
	'MTQ':'METRO CUBICO',
	'MTR':'METRO',
	'MWH':'MEGAWATT HORA',
	'NIU':'UNIDAD',
	'ONZ':'ONZAS',
	'PF':'PALETAS',
	'PG':'PLACAS ',
	'PK':'PAQUETE',
	'PR':'PAR',
	'RM':'RESMA',
	'SET':'JUEGO',
	'ST':'PLIEGO',
	'STN':'TONELADA CORTA',
	'TNE':'TONELADAS',
	'TU':'TUBOS',
	'UM':'MILLON DE UNIDADES',
	'YDK':'YARDA CUADRADA',
	'YRD':'YARDA'
}	



var _tipoProducto = {
	'TI01': 'Bien',
	'TI02': 'Servicio'
}

function obtenerFecha(dias) {

    var f = new Date();

    f.setDate(f.getDate() + dias);

    var dia = f.getDate();
    var mes = f.getMonth() + 1;
    var anio = f.getFullYear();

    if (dia < 10) dia = "0" + dia;
    if (mes < 10) mes = "0" + mes;
	
	
    var fecha = dia + "/" + mes + "/" + anio;
    return fecha;
}

function obtenerPrimerDiaMes() {

    var f = new Date();

    var dia = "01";
    var mes = f.getMonth() + 1;
    var anio = f.getFullYear();

    if (mes < 10) mes = "0" + mes;
	
    var fecha = dia + "/" + mes + "/" + anio;
    return fecha;
}	


	


function SoloNumeroDecimal(e, field) {
	key = e.keyCode ? e.keyCode : e.which
		// backspace
	if (key == 8) return true
		// 0-9 a partir del .decimal  
	if (field.value != "") {
		if ((field.value.indexOf(".")) > 0) {
			//si tiene un punto valida dos digitos en la parte decimal
			if (key > 47 && key < 58) {
				if (field.value == "") return true
					//regexp = /[0-9]{1,10}[\.][0-9]{1,3}$/
				regexp = /[0-9]{2}$/
				return !(regexp.test(field.value))
			}
		}
	}
	// 0-9 
	if (key > 47 && key < 58) {
		if (field.value == "") return true
		regexp = /[0-9]{10}/;
		return !(regexp.test(field.value))
	}
	// .
	if (key == 46) {
		if (field.value == "") return false;
		regexp = /^[0-9]+$/;
		return regexp.test(field.value)
	}
	// other key
	return false;
}
	

function formatoMoneda(num){
	
	 var separador= ","; // separador para los miles
	 var sepDecimal= '.'; // separador para los decimales	
	 
	 //consola(num);	 
	 
	 if(num==0){
		return "0.00";	 
	 }

	if(num!=""){
		 num = Number(num).toFixed(2);
		 num +='';
		 var splitStr = num.split('.');
		 var splitLeft = splitStr[0];
		 var splitRight = splitStr.length > 1 ? sepDecimal + splitStr[1] : '';
		 var regx = /(\d+)(\d{3})/;
		 while (regx.test(splitLeft)) {
		 splitLeft = splitLeft.replace(regx, '$1' + separador + '$2');
		 }
		 return splitLeft +splitRight;		
	}else{
		return "";	
	}
}	

function buscarValorArray(valorABuscar, Lista){
	var html;
	
	//console.log("valorABuscar:"+valorABuscar);
   _.each(Lista, function(v, k) {								 
		//console.log("k:"+k);						  
		//console.log("v:"+v);						  		
		if(k==valorABuscar){
			html = v;	
			return true;
		}						
	});		
	return html;
}





function restaFechas(f1,f2) {
	
		///console.log("f1:"+f1);
		//console.log("f2:"+f2)		
	
	
		var momentFechaIni =  moment(f1, "DD/MM/YYYY");
		var momentFechaFin = moment(f2, "DD/MM/YYYY");
		var difDias = momentFechaFin.diff(momentFechaIni,"days");
		return difDias;
}	

function validaEmail(valor){	
	
	var patron=/^([a-zA-Z0-9_.+-])+\@(([a-zA-Z0-9-])+\.)+([a-zA-Z0-9]{2,4})+$/;
	if(!patron.test(valor)){
		return false;
	}else{
		return true;
	}				
}	


function comparaSiFechaInicioMenorIgualFechaFin(fechaInicial,fechaFinal)
	{
		//console.log("fechaInicial:"+fechaInicial);
		//console.log("fechaFinal:"+fechaFinal);
		
	var valuesStart=fechaInicial.split("/");
	var valuesEnd=fechaFinal.split("/");
	
	
	//var valuesStart=fechaInicial.split("/");
	//var valuesEnd=$(fechaFinal).val().split("/");
	
		//console.log("valuesStart:"+valuesStart);
		//console.log("valuesEnd:"+valuesEnd);	
	
		// Verificamos que la fecha no sea posterior a la actual
		var dateStart=new Date(valuesStart[2],(valuesStart[1]-1),valuesStart[0]);
		var dateEnd=new Date(valuesEnd[2],(valuesEnd[1]-1),valuesEnd[0]);
		
		if(dateStart<=dateEnd)
		{
				return true;	
		}
		
		return false;
	}	
	
	
	
	function validaNumerico(valor) {
		  if (!/^([0-9])*$/.test(valor)){
		      return false;
		  }
		return true;
	}	
	
function completarPatron (str, max, patron) {	
  patron = patron.toString();
  str = str.toString();
  return str.length < max ? completarPatron(patron+str, max,patron) : str;
}

function validaSoloNumero(e){
    tecla = (document.all) ? e.keyCode : e.which;

    //Tecla de retroceso para borrar, siempre la permite
    if (tecla==8){
        return true;
    }
        
    // Patron de entrada, en este caso solo acepta numeros
    patron =/[0-9]/;
    tecla_final = String.fromCharCode(tecla);
    return patron.test(tecla_final);
}

function redondeo(numero, decimales)
{
	var flotante = parseFloat(numero);
	var resultado = Math.round(flotante*Math.pow(10,decimales))/Math.pow(10,decimales);
	return resultado;
}



function sumaFecha(d, fecha)
{
 var Fecha = new Date();
 var sFecha = fecha || (Fecha.getDate() + "/" + (Fecha.getMonth() +1) + "/" + Fecha.getFullYear());
 var sep = sFecha.indexOf('/') != -1 ? '/' : '-';
 var aFecha = sFecha.split(sep);
 var fecha = aFecha[2]+'/'+aFecha[1]+'/'+aFecha[0];
 fecha= new Date(fecha);
 fecha.setDate(fecha.getDate()+parseInt(d));
 var anno=fecha.getFullYear();
 var mes= fecha.getMonth()+1;
 var dia= fecha.getDate();
 mes = (mes < 10) ? ("0" + mes) : mes;
 dia = (dia < 10) ? ("0" + dia) : dia;
 var fechaFinal = dia+sep+mes+sep+anno;
 return (fechaFinal);
 }