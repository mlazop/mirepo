
	var $btnvolver = $('#btnvolver');	
	var $btnDescargarPDF = $("#btnDescargarPDF");
	var $btnDescargarXML = $("#btnDescargarXML");		
	var $entornoApp = "";
	var $tituloVista = $("#tituloVista");
	var $primeraFE = $("#primeraFE");
	var $tipoComprobante = $("#tipoComprobante");	
	var $divBloqueDireccionDNI = $('#divBloqueDireccionDNI');	

	//$tipoComprobante.val("1"); emision electr�nica
	//$tipoComprobante.val("2");  emision fisica
	//$tipoComprobante.val("3");  emision contingencia
	
	var $fechaLimiteEmitir =     $("#fechaLimite");
	var $esAPP = $("#esAPP").val();
	
	var $chkAcepto = $("#chkAcepto");	
	var $modalCondiciones = $("#modal-condiciones");
	
	 //PAS20191U210300032		
	 var $fec_fall_pnat = "";
	 //Fin PAS20191U210300032

	 //PAS20191U2103XXXXX	
	 var $monto_uit = 0;
	 var $monto_emitido = 0;
	 ////////////////////
	
	//var $fechaMensaje = "01/07/2018" ;
	//Este, mensaje estar� disponible hasta el   01.07.2018.
	
	//$primeraFE.val("1");
	
	//console.log("primeraFE:"+$primeraFE.val());
	
	//var dias = restaFechas(obtenerFecha(0),$fechaMensaje);						
	
	//console.log("dias:"+dias);
/*	if(dias>=0){
		if($primeraFE.val()=="1"){
			$modalCondiciones.modal('show');			
		}
	}	
*/	
	
	
	if( isMobile.any()) //si es movil
	{
		$btnDescargarPDF.addClass('hidden');		
		$btnDescargarXML.addClass('hidden');	
	}else{// si no es movil
		//alert("ocultando boton");
		
		if($tipoComprobante.val()==2 || $tipoComprobante.val()==3){//Si  es fisico		
			$btnDescargarXML.addClass('hidden');	
		}
        	
	}
	
	if( isMobile.any() && $esAPP=="1" ) //si es movil
	{
		$entornoApp = "emitirliquidacion.htm";
	}else{// si no es movil
		$entornoApp = "emitirliquidacion.do";
		$btnvolver.addClass('hidden');	
	}	
	
	//console.log("$esAPP:"+$esAPP);
	
	 
	
	var $direccionVendedorDNI;// = "";
	var $ubigeoVendedorDNI;// = "";
	var $desUbigeoVendedorDNI;// = "";	
	
	var $direccionVendedorUltima;// = "direccionVendedorUltima";	
	var $ubigeoVendedorUltima;// = "direccionVendedorUltima";	
	var $desUbigeoVendedorUltima;// = "";
	
	var $valorCambioDolar = 1;
	var $igvPorcentajeGlobal;
    
	
	
    var _DireccionesEmisor = [];
    var _DireccionesEmisorSchema = {
        "codigo": "codigo",
        "tipo": "tipo",
        "ubigeo": "ubigeo",
        "domicilio": "domicilio",		
    };



	//Bloque Datos del vendedor
	var $txtDocumento = $("#txtDocumento");		
	var $selTipoDocumento = $("#selTipoDocumento");	
	var $formLiquidacionDatosVendedor = $("#form-liquidacion-datos-vendedor");	
	var $txtRazonSocial = $("#txtRazonSocial");	
	var $btnContinuarPaso = $("#btnContinuarPaso");		
    var $hiddenRucEmisor = $('#rucEmisor');		
	var $hiddenDireccionEmisor = $('#direccionEmisor');		
	var $hiddenRazonSocialEmisor = $('#razonSocialEmisor');		
	var $hiddenNombreComercialEmisor =$('#nombreComercialEmisor');		
	var $hiddenDepartamentoEmisor = $('#departamentoEmisor');	



	
	

	//Bloque Datos de direcci�n del vendedor	
	var $formLiquidacionDireccion = $('#form-liquidacion-direccion');
	 
    var $panelLiquidacionDireccion = $('#panel-liquidacion-direccion');
    var $btnAdmDireccion =  $panelLiquidacionDireccion.find('#btnAdmDireccion');
	var $txtDireccionVendedor = $("#txtDireccionVendedor");	
	var $hidDireccionVendedor = $("#hidDireccionVendedor");
	var $hidUbigeoVendedor = $("#hidUbigeoVendedor");
	var $hidDesUbigeoVendedor = $("#hidDesUbigeoVendedor");
	
    var $btnValidarDatosVendedor = $('#btnValidarDatosVendedor');	
	$txtDireccionVendedor.prop('disabled', 'disabled');

	var $btnCondiciones = $("#btnCondiciones");
	var $selTipoDireccionVendedor = $("#selTipoDireccionVendedor");
	var $divListaErroresVendedor = $("#div-lista-errores-vendedor");
	
	
	//Bloque Pantalla Datos de la operaci�n
	var $txtDireccionOperacion = $("#txtDireccionOperacion");		
	$txtDireccionOperacion.prop('disabled', 'disabled');
	
	var $hidDireccionOperacion = $("#hidDireccionOperacion");
	var $hidUbigeoOperacion = $("#hidUbigeoOperacion");
	var $hidDesUbigeoOperacion = $("#hidDesUbigeoOperacion");
	var $hidCodEstablecimiento = $("#hidCodEstablecimiento");
	
    var $panelLiquidacionOperacion = $('#panel-liquidacion-operacion');
    var $btnLiquidacionVendedor =  $panelLiquidacionOperacion.find('#boton-liquidacion-vendedor');	
	var $btnLiquidacionOperacion =  $panelLiquidacionOperacion.find('#boton-liquidacion-operacion');	
	var $btnLiquidacionItems =  $panelLiquidacionOperacion.find('#boton-liquidacion-items');	
	var $btnLiquidacionComplementarios =  $panelLiquidacionOperacion.find('#boton-liquidacion-complementarios');	
	
	var $selTipoDireccionOperacion = $("#selTipoDireccionOperacion");
	
	var $selMoneda = $("#selMoneda");
	var $selMonedaSeleccionada = "PEN";
	var $txtFechaEmision = $("#txtFechaEmision");
	var $formLiquidacionOperacion= $("#form-liquidacion-operacion"); 
	var $chkGratuita = $("#chkGratuita");	


	//Bloque de los items del comprobante
	var $panelLiquidacionItems = $('#panel-liquidacion-items');
	var $btnItems =  $panelLiquidacionItems.find('#btnItems');	
	
	
	//Bloque de los datos complementarios
	var $panelLiquidacionComplementarios = $('#panel-liquidacion-complementarios');	
	var $btnDocumentos = $("#btnDocumentos");	 
	var $btnVehiculos = $("#btnVehiculos");	 
	var $formLiquidacionComplementarios = $("#form-liquidacion-complementarios");	 	
    var $hiddenHelperDR = $formLiquidacionComplementarios.find("#hiddenHelperDR");	
    var $hiddenHelperVehiculos = $formLiquidacionComplementarios.find("#hiddenHelperVehiculos");			
	var $txtObservaciones = $("#txtObservaciones");	 
		
	//Bloque Botones de vista preliminar
    var $btnPreview = $('#btnPreview');
	var $btnVolverADNI = $('#btnVolverADNI');


	
	
	//Pantalla flotante de elegir direccion	
	var $modalItemLabel = $("#modal-item-Label");			
	var $modalDireccion = $("#modal-direccion");			
	var $btnSeleccionarDireccion = $("#btnSeleccionarDireccion");	
	var $formModalDireccion = $("#form-modal-direccion");
	var $selDepartamento = $("#selDepartamento");
	var $selProvincia = $("#selProvincia");
	var $selDistrito = $("#selDistrito");	
	
	//Pantalla flotante para seleccionar una direccion de una lista de direcciones
	var $modalDirecciones = $("#modal-direcciones");
	var $tablaDireccionesEmisor = $("#tabla-direcciones-emisor");	
	

	//Pantalla flotante para visualizar los items
    var $modalItem = $("#modal-item");
	var $modalMostrarItems = $("#modal-mostrar-items");
	var $btnOpenModalAgregarItem = $("#open-modal-item");	
    var $formModalItem = $modalItem.find('#form-modal-item');
	
		
	//Pantalla flotante para agregar los items
	var $formItem = $("#form-item")
	var $panelItems = $('#panel-liquidacion-items');
    var $tablaItem = $("#tabla-item");	
	var $hiddenHelperItem = $formItem.find("#hiddenHelperItem");
	
    var $txtCodigo = $formModalItem.find('#txtCodigo');
    var $txtDescripcion = $formModalItem.find('#txtDescripcion');
	var $txtCodigoUsuario = $formModalItem.find("#txtCodigoUsuario");	

    //var $txtCodigo = $formModalItem.find('#txtCodigo');
    //var $txtDescripcion = $formModalItem.find('#txtDescripcion');
    var $selUnidadMedida = $formModalItem.find('#selUnidadMedida');
    //var $selTipo = $formModalItem.find('#selTipo');
	
	//var $txtDescripcion = $("#txtDescripcion");			
	//var $selUnidadMedida = $("#selUnidadMedida");	
	var $txtValorUnitario = $("#txtValorUnitario");
	var $txtCantidad = $("#txtCantidad");
	var $selTipoIgv = $("#selTipoIgv");	
	var $txtIGV = $("#txtIGV");			
	var $selTipoAfectacionIR = $("#selTipoAfectacionIR");	
	var $selPorcentajeIR = $("#selPorcentajeIR");		
	var $txtRetencion = $("#txtRetencion");		
	var $txtImporte = $("#txtImporte");		
	var _Items = [];
    var _itemSchema = {		
        txtCantidad: "Cantidad",        		
        selUnidadMedida: "Unidad de Medida",						
        txtCodigo: "C&oacute;digo",		
		txtCodigoUsuario:"C&oacute;digo de usuario",		
		txtDescripcion: "Descripci&oacute;n",				
        txtValorUnitario: "Valor Unitario",				
		selTipoIgv: "Tipo Igv",//GRAVADO O EXONERADO						
        txtIGV: "IGV",				
		selTipoAfectacionIR: "Tipo IR",
		selPorcentajeIR: "Porcentaje IR",
		txtRetencion:"Retenci&oacute; IR",
        txtImporte: "Importe neto"
    }
	
	
	//Pantalla flotante para visualizar los documentos relacionados
	var $modalDocumentoRelacionado	 = $("#modal-documento-relacionado");	
	var $modalListaDocumentoRelacionado	 = $("#modal-mostrar-documento-relacionado");	
	var $btnOpenModalDR = $("#open-modal-documento-relacionado");
    var $formModalDocumentoRelacionado = $modalDocumentoRelacionado.find('#form-modal-documento-relacionado');
	
	var _DocumentosRelacionadosSchema = {
		txtDocumentoNro:"Orden",
        selTipoDocumentoRelacionado: "Tipo de Documento",
        txtSerie: "Serie",
        txtNumero: "N&uacute;mero"
    }
    var _DocumentosRelacionados = [];
	
	//Pantalla flotante para agregar los documentos relacionados	
	var $selTipoDocumentoRelacionado= $("#selTipoDocumentoRelacionado");		
	var $txtSerie= $("#txtSerie");		
	var $txtNumero= $("#txtNumero");				
    var $tablaDocumento = $("#tabla-documento-relacionado");

	
	//Pantalla flotante para visualizar los vehiculos
 	var $tablaVehiculo = $("#tabla-vehiculo");
	var $modalAgregarVehiculos	 = $("#modal-agregar-vehiculos");		
	var $modalMostrarVehiculos	 = $("#modal-mostrar-vehiculos");			
	var $btnOpenModalAgregarVehiculo = $("#open-modal-Agregar-vehiculo");

	
	//Pantalla flotante para agregar los vehiculos	
	var $formModalAgregarVehiculos = $("#form-modal-agregar-vehiculos");
	var $txtPlacaNro = $("#txtPlacaNro");	
	
	var _VehiculosSchema = {
		txtPlacaNro:"Orden",
        txtPlaca: "Placa"
    }
    var _Vehiculos = [];	
	
	
	
	//Pantalla flotante de calendario
    var $modalDatepicker = $('#modal-datepicker');
    var $datepicker = $modalDatepicker.find("#datepicker-placeholder");
    var $datepickerHidden = $modalDatepicker.find("#datepicker-value");
    var $btnCloseDatepicker = $modalDatepicker.find('#modal-datepicker-close');
	
	
	//Pantalla de vista previa
    var $btnVolverFactura = $('#btnVolverFactura');	
    var $btnEmitirFactura = $("#btnEmitirFactura");
	var $btnEnviarCorreo = $("#btnEnviarCorreo");
	var $btnEmitirNuevo = $("#btnEmitirNuevo");	
	var $hiddensubTotalVentas=  $("#hiddensubTotalVentas");
	var $hiddenanticipos =  $("#hiddenanticipos");
	var $hiddenvalorVenta =  $("#hiddenvalorVenta");
	var $hiddentotalIGV =  $("#hiddentotalIGV");
	var $hiddentotalVenta =  $("#hiddentotalVenta");
	var $hiddentotalIGVCredito =  $("#hiddentotalIGVCredito");
	var $hiddentotalRetencion =  $("#hiddentotalRetencion");
	var $hiddenimporteNeto =  $("#hiddenimporteNeto");	
	var $hiddenTotalValorVentaOperaGratuitas =  $("#hiddenTotalValorVentaOperaGratuitas");		
	
	
	//Pantalla flotante de envio de correo	
	var $txtEmail = $('#txtEmail');
	var $formModalCorreo = $("#form-modal-correo");	
	var $modalCorreo = $("#modal-correo");		
	
/*	
	$("#campoOcultar1").hide();
	$("#campoOcultar2").hide();
	$("#campoOcultar3").hide();
	$("#campoOcultar4").hide();	
	*/
	
	 
	 $("#txtValorUnitario").inputmask( "decimal", { allowPlus: false, allowMinus: false, radixPoint: ".", autoGroup: false, groupSeparator: ",", groupSize: 8, integerDigits: "8", digits: "10"} );
	 $("#txtCantidad").inputmask( "decimal", { allowPlus: false, allowMinus: false, radixPoint: ".", autoGroup: false, groupSeparator: ",", groupSize: 8, integerDigits: "8", digits: "10"} );	 
	 
	 
	 $('#txtValorUnitario').css({'text-align':'left'});
	 $('#txtCantidad').css({'text-align':'left'});	 
	
	//*******************************************************************************	
	//Inicializando con datos	
	
	//variable para determinar de que bloque ha venido la solicitud
	//a la pantalla de direccion
	

	
	var opcionDireccion = 0;
	
	
	var jsonDistritos = (function () {
		var json = null;
		$.ajax({
			async: false,
			global: false,
				  
			url: '/a/js/servicio/registro/comppago/see/liquidacioncompra/json/Distritos.json',
			dataType:'JSON',
			success: function (data) {
			json = data.distritos;
		}
		});
		return json;
	})();
	
	
	var jsonProvincias = (function () {
		var json = null;
		$.ajax({
			async: false,
			global: false,
			url: '/a/js/servicio/registro/comppago/see/liquidacioncompra/json/Provincias.json',
			dataType:'JSON',
			success: function (data) {
			json = data.provincias;
		}
		});
		return json;
	})();
	
	// Cargar Variable jsonEstadosOpciones
	// ==============================================================
	var jsonDepartamentos = (function () {
		var json = null;
		$.ajax({
			async: false,
			global: false,
			url: '/a/js/servicio/registro/comppago/see/liquidacioncompra/json/Departamentos.json',
			dataType:'JSON',
			success: function (data) {
			json = data.departamentos;
		}
		});
		return json;
	})();		
	
	    var $selTipo = $formModalItem.find('#selTipo')
	//Carga de selectores

	
	
	function cargarSelectoresInicio()
	{
			$selTipoDireccionVendedor.empty();
			$selTipoDireccionOperacion.empty();
			
			_.each(_tipoDireccion, function (v, k) {
				  $('<option/>', {
					  value: k
				  }).html(v).appendTo($selTipoDireccionVendedor);
				  
				  $('<option/>', {
					  value: k
				  }).html(v).appendTo($selTipoDireccionOperacion);		  
			});			
			
			
			$selTipo.empty();
			_.each(_tipoProducto, function (v, k) {
				  $('<option/>', {
					  value: k,
					  selected:(k=='PEN')
				  }).html(v).appendTo($selTipo);
			});		
			
			$selMoneda.empty();			
			_.each(_monedaDescripcion, function (v, k) {
				  $('<option/>', {
					  value: k,
					  selected:(k=='PEN')
				  }).html(v).appendTo($selMoneda);
			});
			
			$selTipoDocumentoRelacionado.empty();						
			_.each(_tipoDocumentoRelacionado, function (v, k) {
				  $('<option/>', {
					  value: k
				  }).html(v).appendTo($selTipoDocumentoRelacionado);
			});	
			
			$selTipoDocumento.empty();									
			_.each(_tipoDocumentoIdentidad, function (v, k) {
				  $('<option/>', {
					  value: k
				  }).html(v).appendTo($selTipoDocumento);
			});
		
	}
	
	
	function cargarMedida(){	
	
		$selUnidadMedida.empty();
		
		_.each(_tipoMedida, function(v, k) {								 
			$('<option/>', {
				value: k,
				selected:(k=='NIU')
			}).html(v).appendTo($selUnidadMedida);
		});	
	}
	
	function cargaAfectacionIGV(){
		
		$selTipoIgv.empty();
		
		_.each(_afectacionIGV, function(v, k) {
			$('<option/>', {
				value: k,
				selected:(k=='Gravado')
			}).html(v).appendTo($selTipoIgv);
		});
	}
	
	function cargaAfectacionIR(){
		
		$selTipoAfectacionIR.empty();		
		_.each(_afectacionIR, function(v, k) {
			$('<option/>', {
				value: k,
				selected:(k=='Gravado')
			}).html(v).appendTo($selTipoAfectacionIR);
		});	
	}
	
	function cargaPorcentajeIR(){
		
		$selPorcentajeIR.empty();				
		_.each(_porcentajeIR, function(v, k) {
			$('<option/>', {
				value: k,
				selected:(k=='0.015')
			}).html(v).appendTo($selPorcentajeIR);
		});
	}
	
	
	//***********************************************************************************
	//Bloque Datos del vendedor	

	$formLiquidacionDatosVendedor.validate({
        rules: {
            txtDocumento: { 
					required: true, 
					minlength: function () {
							var tipo = $selTipoDocumento.val();
							if (tipo == '1') {
								return 8;
							} else {
								return 1;
							}
						}, 
					maxlength: function () {
							var tipo = $selTipoDocumento.val();
							if (tipo == '1') {
								return 8;
							} else {
								return 12;
							}
						}, 
					validaNumerico: false/*function () {
							var tipo = $selTipoDocumento.val();
							if (tipo == '1') {
								return true;
							} else {
								return false;
							}
						}*/
					},
			txtRazonSocial:{
					required: function () {
							var tipo = $selTipoDocumento.val();
							if (tipo == '1') {
								return false;
							} else {
								return true;
							}
						}
					}			
        },
        messages: {
			txtDocumento: {
				validaNumerico: "Debe ingresar solo valores num\u00e9ricos para el campo DNI",
				required: function () {
							return "Debe ingresar un valor para el campo n\u00FAmero de documento";
							
							//var tipo = $selTipoDocumento.val();
							//if (tipo == '1') {
								//return "Debe ingresar un valor para el campo DNI";
							//} else  {
								//if (tipo == '4') {
								//return "Debe ingresar 12 caracteres alfanum\u00e9ricos para el campo n\u00FAmero de documento de identidad";
							//}//else if (tipo == '') {
								//return "Debe ingresar un valor para el campo Pasaporte";
							//}
						},
				minlength: function () {
							var tipo = $selTipoDocumento.val();
							if (tipo == '1') {
								return "Debe ingresar 8 d&iacute;gitos para el campo n\u00FAmero de documento";
							} 
						}
			},
			txtRazonSocial: {
				required: "Debe ingresar un valor para el campo Apellidos y Nombres",
			}
        },
        submitHandler: function(form){
            $modalPreloader.modal('show');
			validarExistenciaDNI();		
		}
			
    });	
	

	
	
	
	
		
	 var numeroUIT=0;
	 var valorActualDolar = 0;
	 
	 function validarExistenciaDNI(){
       	 
		 
		//console.log("$entornoApp:"+$entornoApp);
		 
        var url = $entornoApp+'?action=validarExistenciaDNICliente'; 		
	
		var formData = {	txtDocumento: $txtDocumento.val(),
			 		        tipoComprobante: $tipoComprobante.val(),
							selTipoDocumento : $selTipoDocumento.val(),
							txtRazonSocial : $txtRazonSocial.val().toUpperCase()
		               };
		
      $.ajax({
        url: url,
        type: "POST",
        data: formData,
        dataType: 'json',
        success: function(data) {
			
		 //PAS20191U2103XXXXX	
		$documentoEsDNI = data.documentoEsDNI;
		
		

		
		//console.log("monto_uit:"+$monto_uit);
		//console.log("monto_emitido:"+$monto_emitido);
		
		//////////////////////////	
		
        if(data.estado == '0'){ 
            $txtDocumento.data('pivot-valid', '0');
			$txtDocumento.val("");
			$modalPreloader.modal('hide');
            bootbox.alert('El N\u00FAmero de documento ingresado no es v\u00E1lido');           
            return; 
         }

         if (data.estado == '2') {
				bootbox.alert('El vendedor debe ser mayor de edad');
				 return;
         }

         if (data.estado == '3') {
                bootbox.alert('El vendedor debe estar no fallecido');
				 return;
         }

         if(data.estado == '4'){
				bootbox.alert('El vendedor tiene asociado un n\u00FAmero de RUC. Solo es permitido si su RUC tiene el estado: Baja definitiva, Baja de oficio, Baja Mult.Inscr, N\u00FAm. Interno identif o Anulaci\u00F3n \u23AF Error SUNAT'); 
            return;
          }	  
		 
		 /*
         if(data.estado == '5'){
			 	
				//alert("numeroUIT:"+numeroUIT);
				
				
				var fecha = new Date();
				var anio = fecha.getFullYear();
				//console.log('El a�o actual es: '+anio);								
				if(anio==2018){
					alert('El vendedor ha superado la venta de liquidaci\u00F3n de compra por un monto mayor a '+numeroUIT+' UITs contadas desde octubre del presente a\u00F1o');					
				}else{
					alert('El vendedor ha superado la venta anual de liquidaci\u00F3n de compra por un monto mayor a '+numeroUIT+' UITs contadas desde enero del presente a\u00F1o');					
				}

            return;
          }	*/	  
		  
		  //PAS20191U210300032
          if(data.estado == '6'){
				$fec_fall_pnat = data.fec_fall_pnat;
				//console.log("recuperando $fec_fall_pnat:"+$fec_fall_pnat);
          }	
		  //fin PAS20191U210300032
		  
		  if (typeof data.estado == 'undefined'){
				$txtDocumento.data('pivot-valid', '0');
				$txtDocumento.val("");
				bootbox.alert('El N\u00FAmero de documento ingresado no es v\u00E1lido');
            return;
          } 
		  
		  	$direccionVendedorUltima = data.ultimaDireccion;
			$ubigeoVendedorUltima  = data.ubigeoVendedorUltima;		
			$desUbigeoVendedorUltima = data.desubigeoUltima;
						
/*			console.log("$direccionVendedorUltima:"+$direccionVendedorUltima);
			console.log("$ubigeoVendedorUltima:"+$ubigeoVendedorUltima);
			console.log("$desUbigeoVendedorUltima:"+$desUbigeoVendedorUltima);*/			
			
			$direccionVendedorDNI = '';
			$ubigeoVendedorDNI = '';
			$desUbigeoVendedorDNI = '';
			$txtDireccionVendedor.val('');
			$txtDireccionOperacion.val('');
			
		    if($documentoEsDNI == 'Si'){
			
				$direccionVendedorDNI = data.direccionDNI;	
				$ubigeoVendedorDNI = data.ubigeoVendedorDNI;
				$desUbigeoVendedorDNI = data.desUbigeoDNI;			
				
				$txtDireccionVendedor.val($direccionVendedorDNI+"\n"+$desUbigeoVendedorDNI);					
				$hidDireccionVendedor.val($direccionVendedorDNI);			
				$hidUbigeoVendedor.val($ubigeoVendedorDNI);
				$hidDesUbigeoVendedor.val($desUbigeoVendedorDNI);
				
				$txtDireccionOperacion.val($direccionVendedorDNI+"\n"+$desUbigeoVendedorDNI);				
				$hidDireccionOperacion.val($direccionVendedorDNI);
				$hidUbigeoOperacion.val($ubigeoVendedorDNI);
				$hidDesUbigeoOperacion.val($desUbigeoVendedorDNI);				
				
			}else{

				if($desUbigeoVendedorUltima!='')
				$txtDireccionVendedor.val($direccionVendedorUltima+"\n"+$desUbigeoVendedorUltima);					
				$hidDireccionVendedor.val($direccionVendedorUltima);			
				$hidUbigeoVendedor.val($ubigeoVendedorUltima);
				$hidDesUbigeoVendedor.val($desUbigeoVendedorUltima);
				
				if($desUbigeoVendedorUltima!='')
				$txtDireccionOperacion.val($direccionVendedorUltima+"\n"+$desUbigeoVendedorUltima);				
				$hidDireccionOperacion.val($direccionVendedorUltima);
				$hidUbigeoOperacion.val($ubigeoVendedorUltima);
				$hidDesUbigeoOperacion.val($desUbigeoVendedorUltima);							
				
			}
						
/*			console.log("$direccionVendedorDNI:"+$direccionVendedorDNI);
			console.log("$ubigeoVendedorDNI:"+$ubigeoVendedorDNI);
			console.log("$desUbigeoVendedorDNI:"+$desUbigeoVendedorDNI);	*/
			
	        $txtRazonSocial.val(data.razon_social.toUpperCase());		
			
/*			console.log("$txtDireccionOperacion:"+$txtDireccionOperacion.val());
			console.log("$hidDireccionOperacion:"+$hidDireccionOperacion.val());
			console.log("$hidUbigeoOperacion:"+$hidUbigeoOperacion.val());			
			console.log("$hidDesUbigeoOperacion:"+$hidDesUbigeoOperacion.val());	*/					
			
			$txtDocumento.val(data.dni);		
			
			_DireccionesEmisor = data.establecimientosEmisor;
			
			$igvPorcentajeGlobal = (data.igvPorcentajeGlobal/100);
			
			//console.log("$igvPorcentajeGlobal:"+$igvPorcentajeGlobal);
			
			$btnValidarDatosVendedor.addClass('hidden');
			$btnContinuarPaso.removeClass('hidden');	
			$txtDocumento.prop('disabled', 'disabled');	
			$txtRazonSocial.prop('disabled', 'disabled');
			$selTipoDocumento.prop('disabled', 'disabled');			
			
			prefetchProductos();

        },
		
        error: function () {
          bootbox.alert('error');
		  
          //$txtDocumento.data('pivot-valid', '0');
  		  $txtDocumento.val("");
          //$razonSocial.closest('.form-group').addClass('hidden');
         // $btnValidarDatosReceptor.removeClass('hidden');
          //$btnContinuar.addClass('hidden');
        },
        complete: function () {

	
			$modalPreloader.modal('hide');		  
          //$formFacturaDatosReceptor.valid();
        }
      });
    }	
	
    $btnContinuarPaso.on('click', function (e) {
	        $panelLiquidacionDireccion.removeClass('hidden').find('.panel-collapse').collapse('show');			
	        $panelLiquidacionOperacion.removeClass('hidden').find('.panel-collapse').collapse('show');						
	        $panelLiquidacionItems.removeClass('hidden').find('.panel-collapse').collapse('show');			
	        $panelLiquidacionComplementarios.removeClass('hidden').find('.panel-collapse').collapse('show');						
			$panelLiquidacionItems.removeClass('hidden').find('.panel-collapse').collapse('show');
			$panelLiquidacionAnticipos.removeClass('hidden').find('.panel-collapse').collapse('show');
			
			$btnContinuarPaso.addClass('hidden');
			$btnvolver.addClass('hidden');		
	        $("#buttons").removeClass('hidden');			
			renderDireccionesEmisor();
			$dniFiltroAnticipo.val($txtDocumento.val());
			
    });	
	
	
	//Fin Bloque Datos del vendedor		
	//***********************************************************************************

	

	//***********************************************************************************
	//Bloque Datos de direcci�n del vendedor
    $btnAdmDireccion.on('click', function (e) {
									
   	  $modalItemLabel.html("Agregar direcci&oacute;n del vendedor");								
      $modalDireccion.modal('show');	  
	  opcionDireccion = 1;
	  var hidUbigeoVendedor =  $hidUbigeoVendedor.val();	  
	  setSeleccionarDireccion(hidUbigeoVendedor);	  
	  $("#txtDireccion").val($hidDireccionVendedor.val());

      $formModalDireccion.find('.alert').remove();	  
      $formModalDireccion.find('.has-error').removeClass('has-error');
      //$formModalDireccion.find(':input').val('');
	   
    });
	
	$formLiquidacionDireccion.validate(_.extend(window._validatorWallSettings, {
        rules: {
            txtDireccionVendedor: {
                required: true
            }
        },
        messages: {
            txtDireccionVendedor: {
                required: "Debe ingresar la direcci&oacute;n del vendedor"
                }
        }
    }));	
	
	
	//Bloque Pantalla Datos del VEndedor
	$('input[type=radio][name=opcvendedor]').on('change, click', function() {
		 var dir = "";
		 switch($(this).val()) {
			 case '0':			 
				 $txtDireccionVendedor.val($direccionVendedorDNI+"\n"+$desUbigeoVendedorDNI);
				 $hidDireccionVendedor.val($.trim($direccionVendedorDNI));
				 $hidUbigeoVendedor.val($.trim($ubigeoVendedorDNI));
				 $hidDesUbigeoVendedor.val($.trim($desUbigeoVendedorDNI));
				 
				var valor = $('input:radio[name=opciones]:checked').val()  	
				if(valor==0){ 
				
					 dir = $hidDireccionVendedor.val();
					 if($hidDesUbigeoVendedor.val()!=""){
						 dir = dir + "\n" + $hidDesUbigeoVendedor.val();
					 }				
				
					$txtDireccionOperacion.val(dir);					 
					//$txtDireccionOperacion.val($hidDireccionVendedor.val()+"\n"+$hidDesUbigeoVendedor.val());					 					
				 }
				 break;
			 case '1':				 
			 
			 	 dir = $direccionVendedorUltima;
				 if($desUbigeoVendedorUltima!=""){
					 dir = dir + "\n" + $desUbigeoVendedorUltima;
				 }
				 //$txtDireccionVendedor.val($direccionVendedorUltima+"\n"+$desUbigeoVendedorUltima);
				 $txtDireccionVendedor.val(dir);
 				 $hidUbigeoVendedor.val($.trim($ubigeoVendedorUltima));
				 $hidDireccionVendedor.val($.trim($direccionVendedorUltima));
				 $hidDesUbigeoVendedor.val($.trim($desUbigeoVendedorUltima));	
				 
				 var valor = $('input:radio[name=opciones]:checked').val()  	
				 if(valor==0) { 
				 
						 dir = $hidDireccionVendedor.val();
						 if($hidDesUbigeoVendedor.val()!=""){
							 dir = dir + "\n" + $hidDesUbigeoVendedor.val();
						 }				
					
						 $txtDireccionOperacion.val(dir);						 
				 
				 		 //$txtDireccionOperacion.val($hidDireccionVendedor.val()+"\n"+$hidDesUbigeoVendedor.val());
						
						 $hidUbigeoOperacion.val($.trim($ubigeoVendedorUltima));
						 $hidDireccionOperacion.val($.trim($direccionVendedorUltima));
						 $hidDesUbigeoOperacion.val($.trim($desUbigeoVendedorUltima));						
				 }					 
				 
				 break;
			 case '2':
				  $modalItemLabel.html("Agregar direcci&oacute;n del vendedor");								
				  $modalDireccion.modal('show');	  
				  opcionDireccion = 1;
				 // console.log("$hidUbigeoVendedor.val():"+$hidUbigeoVendedor.val());
				  //var hidUbigeoVendedor =  $hidUbigeoVendedor.val();	  
				  setSeleccionarDireccion($hidUbigeoVendedor.val());	  
				  $("#txtDireccion").val($hidDireccionVendedor.val());
			
				  $formModalDireccion.find('.alert').remove();	  
				  $formModalDireccion.find('.has-error').removeClass('has-error');			 
				 break;
				 
		 }
		 
		 
/*			console.log("$direccionVendedorDNI:"+$direccionVendedorDNI);
			console.log("$ubigeoVendedorDNI:"+$ubigeoVendedorDNI);
			console.log("$desUbigeoVendedorDNI:"+$desUbigeoVendedorDNI);	
			
			console.log("$direccionVendedorUltima:"+$direccionVendedorUltima);
			console.log("$ubigeoVendedorUltima:"+$ubigeoVendedorUltima);
			console.log("$desUbigeoVendedorUltima:"+$desUbigeoVendedorUltima);		*/		 
		 
		 
	});		
	
	//Fin Bloque Datos de direcci�n del vendedor
	//***********************************************************************************
	
	
	//***********************************************************************************
	//Bloque Pantalla Datos de la operaci�n
	

	$txtFechaEmision.on('change, click', function() {
												  
																			  
	});
	
	$('input[type=radio][name=opciones]').on('change, click', function() {
		 switch($(this).val()) {
			 case '0':			 
				 $txtDireccionOperacion.val($hidDireccionVendedor.val()+"\n"+$hidDesUbigeoVendedor.val());
				 $hidUbigeoOperacion.val($hidUbigeoVendedor.val());
				 $hidDireccionOperacion.val($hidDireccionVendedor.val());
				 $hidDesUbigeoOperacion.val($hidDesUbigeoVendedor.val());
				 $hidCodEstablecimiento.val("");
				 break;
			 case '1':				 
				 //renderDireccionesEmisor();
				 $modalDirecciones.modal('show');
				 break;
			 case '2':
				 $modalItemLabel.html("Agregar direcci&oacute;n de la operaci&oacute;n");											 
 				 $modalDireccion.modal('show');
				 opcionDireccion = 2;
				 var hidUbigeoOperacion =  $hidUbigeoOperacion.val();
			  	 setSeleccionarDireccion(hidUbigeoOperacion);	  				 
 			     $("#txtDireccion").val($hidDireccionOperacion.val());				 
				 break;
				 
		 }
	});	

	//Al hacer clic en el boton flecha invertida para desplegar la opci�n
    $btnLiquidacionOperacion.on('click', function (e) {
		var valor = $('input:radio[name=opciones]:checked').val()  	
		if(valor==0) { 		
				$txtDireccionOperacion.val($hidDireccionVendedor.val()+"\n"+$hidDesUbigeoVendedor.val());
				$hidUbigeoOperacion.val($hidUbigeoVendedor.val());				
			    $hidDireccionOperacion.val($hidDireccionVendedor.val());
				$hidDesUbigeoOperacion.val($hidDesUbigeoVendedor.val());
		}									  
    });
	
	
    $btnLiquidacionVendedor.on('click', function (e) {
												  

    });	
	
	
	
	
  $formLiquidacionOperacion.validate(_.extend(window._validatorWallSettings, {
        rules: {						
			txtSerieFisico: {
                required: { depends: 
							function(element){
								
									//console.log("$tipoComprobante:"+$tipoComprobante.val());
									if($tipoComprobante.val() == "2" || $tipoComprobante.val() == "3"){
										return true;
									}else{
										return false;
									}
							}				
				        },
				 minlength: {	
				 		    param: 4, 
							depends: 
							function(element){								
									//console.log("$tipoComprobante maxlength:"+$tipoComprobante.val());
									if($tipoComprobante.val() == "2" || $tipoComprobante.val() == "3"){
										return true;
									}else{
										return false;
									}
							}						 
					 }	
            },	
			txtNumeroFisico: {
                required:  { 
				            depends: 
							function(element){
									//console.log("$tipoComprobante:"+$tipoComprobante.val());
									if($tipoComprobante.val() == "2" || $tipoComprobante.val() == "3"){
										return true;
									}else{
										return false;
									}
							 }				
				          }
            },				
			txtFechaEmision: {
                required: true				
            },
            selMoneda: {
                required: true
            },
            txtDireccionOperacion: {
                required: true
            }
        },
        messages: {
			txtSerieFisico: {
                required: "Debe ingresar la serie del comprobante",
				minlength:"Serie del la LC F&iacute;sica es de 4 d&iacute;gitos"
            },
			txtNumeroFisico: {
                required: "Debe ingresar el n&uacute;mero del comprobante"
            },
			txtFechaEmision: {
                required: "Puede ingresar la fecha de emisi&oacute;n hasta 2 d&iacute;as anteriores a la fecha actual"
            },
            selMoneda: {
                required: "Seleccione la Moneda"
            },
            txtDireccionOperacion: {
                required: "Debe ingresar la direcci&oacute;n de la operaci&oacute;n"
            }
        }
    }));
  
  
  $chkGratuita.on('click', function(e){												
		actualizarResumen();									
   });	  
	
	//Fin Bloque Pantalla Datos de la operaci�n	
	//***********************************************************************************	


	//***********************************************************************************
	//Bloque de los items del comprobante 	
	
    $btnItems.on('click', function (e) {									
		renderItem();
		$modalMostrarItems.modal('show');	
		//$("#selPorcentajeIR").prop('disabled', 'disabled');	
    });	

	$formItem.validate(_.extend(window._validatorWallSettings, {
        rules: {
            hiddenHelperItem: {
                moreThan: 0
                //lessThan: 10
            }
        },
        ignore: '.ignored-field',
        messages: {
            hiddenHelperItem: {
                moreThan: "Agregue un &iacute;tem a la Liquidaci&oacute;n de Compra"
            }
        }
    }));

	//Fin Bloque de los items del comprobante
	//***********************************************************************************	



	//***********************************************************************************
	//Bloque de visualizar documentos relacionados	
	
    $btnDocumentos.on('click', function (e) {									
		$modalListaDocumentoRelacionado.modal('show');				
    });	
	

	
	//Fin Bloque de visualizar documentos relacionados	
	//***********************************************************************************


	


	//***********************************************************************************
	//Bloque de visualizar los vechiculos
    $btnVehiculos.on('click', function (e) {									
		$modalMostrarVehiculos.modal('show');				
    });		
	//***********************************************************************************
	//Bloque de los vechiculos
	

	//***********************************************************************************
	//Bloque Botones de vista preliminar
    $btnVolverADNI.on('click', function (e) {		
		//console.log("$entornoApp  btnVolverADNI:"+$entornoApp);
		volverInicio();
		//window.location.href = "/ol-ti-itemisionliquidacion/"+$entornoApp+"?tipo="+$tipoComprobante.val();
    });	


	//console.log("$fechaLimiteEmitir.val() antes:"+$fechaLimiteEmitir.val());

	$divListaErroresComplementarios = $("#div-lista-errores-complementarios");

    $btnPreview.on('click', function (e) {		
	
	    if(!$formLiquidacionDireccion.valid())
            return;
			
			//console.log("$txtDireccionVendedor.val:"+$txtDireccionVendedor.val());
			//console.log("$txtDireccionVendedor.val length:"+$txtDireccionVendedor.val().length);
			
		if($txtDireccionVendedor.val()==""){
			$divListaErroresVendedor.removeClass('hidden');
			$divListaErroresVendedor.html('<div class="alert alert-danger"><li><span class="error" style="display: inline;">Debe ingresar la direcci\u00F3n del vendedor</span></li></div>');			
			return;
		}	
		
		$divListaErroresVendedor.addClass('hidden');
			
        if(!$formLiquidacionOperacion.valid())
            return;			
			
		//console.log("$txtDireccionOperacion.val:"+$txtDireccionOperacion.val());
			//console.log("$txtDireccionOperacion.val length:"+$txtDireccionOperacion.val().length);			
			
		if($txtDireccionOperacion.val()==""){
			$divListaErroresOperacion.removeClass('hidden');
			$divListaErroresOperacion.html('<div class="alert alert-danger"><li><span class="error" style="display: inline;">Debe ingresar la direcci\u00F3n de la operaci\u00F3n</span></li></div>');			
			return;
		}
		
		$divListaErroresOperacion.addClass('hidden');
        
        if(!$formItem.valid())
            return;	
		
        if(!$formLiquidacionComplementarios.valid())
            return;					

		//var tempSumaItems = $montoNetoLC + "";
		var tempSumaItems = $montoNetoLCSinAnticipos + "";
		
		tempSumaItems = parseFloat(tempSumaItems.replace(/,/g, ''));
		
		//console.log("tempSumaItems:"+tempSumaItems);
		//console.log("deducido_suma:"+deducido_suma);
		
		if(deducido_suma>tempSumaItems){
			//alert("El importe de pagos (inc. Deducciones) no debe exceder el total del importe de los items");
			$divListaErroresComplementarios.removeClass('hidden');
			$divListaErroresComplementarios.html('<div class="alert alert-danger"><li><span class="error" style="display: inline;">El importe de pagos (inc. Deducciones) no debe exceder el total del importe de los items</span></li></div>');			
   		    return;
		}else{
			$divListaErroresComplementarios.addClass('hidden');	
		}			
		
		//console.log("$tipoComprobante.val() en preview"+$tipoComprobante.val());
		
		validarMontoUIT();
		
		if($tipoComprobante.val()==2 || $tipoComprobante.val()==3){//fisico		
			validarSerieNumero();			
		}else{		
			showPreview();					
		}
    });

    function showPreview () {
		
        $modalPreloader.modal('show');
        var data = prepararDatosPreview();
		
		if($tipoComprobante.val()==1){//Eletronico		
			$tituloVista.text("Vista Preliminar de Liquidaci\u00F3n de Compra Electr\u00F3nica");
		}else if($tipoComprobante.val()==2){//fisico	
			$tituloVista.text("Vista Preliminar de Liquidaci\u00F3n de Compra F\u00EDsica");
		}else {
			$tituloVista.text("Vista Preliminar de Liquidaci\u00F3n de Compra");
		}
		
		
        $('#root-panels').addClass('hidden');
        $("#panel-preview").removeClass('hidden');
		
        $('#btnEnviarCorreo').addClass('hidden');
        $('#btnEmitirNuevo').addClass('hidden');		
        $('#btnDescargarPDF').addClass('hidden');
        $('#btnDescargarXML').addClass('hidden');		
		$btnRegistroPagos.addClass('hidden');		
		
		
        $.get('liquidacion-xhr.html').success(function (rtext) {
            var tpl = _.template(rtext)
            var parsed = tpl(data)
			
			$("#serienumero").html("");			
            $("#preview-factura").html(parsed).find('table').footable();
            $modalPreloader.modal('hide');
        });
    }
	
	
    $tablaDocumento.footable();
    $tablaItem.footable();	
	$tablaVehiculo.footable();	
    $tablaDireccionesEmisor.footable();
	
    $('.modal').on('shown.bs.modal', function() {
        $(this).find('.footable').trigger('footable_initialize');
    })	
	
    var _datosCompletos = {};
	var _datosEnvio = {}; 
	var _datosItems = {};
    var _datosDocumentos = {};
    var _datosVehiculos = {};	
	
	function splitDireccion(str){
		//console.log("str:"+str);
		var res = str.split("<br/>");	
		//console.log("res.length <br/>:"+res.length);
		if(res.length==0) res = str.split("<br>");	
		
		//console.log("res.length <br>:"+res.length);
		if(res.length==0) res = str.split("\n");	
		
		//console.log("res.length \n:"+res.length);		
		
		//console.log("res[0]:"+res[0]);
		//console.log("res[1]:"+res[1]);
		return res[0];
	}
	

	function prepararDatosPreview () {
      var d = new Date();
	  
		
		//_Items.length = 0;
		
		var _array = [];
		//var _array = _Items;
		
		$.each(_Items, function( key, obj ) {			
													
			var tempo = {	txtCantidad : obj.txtCantidad,
							selUnidadMedida: obj.selUnidadMedida,
							txtCodigo: obj.txtCodigo,
							txtCodigoUsuario: obj.txtCodigoUsuario,
							txtValorUnitario: obj.txtValorUnitario,									
							selTipoIgv: obj.selTipoIgv,
							txtIGV: obj.txtIGV,
							selTipoAfectacionIR: obj.selTipoAfectacionIR,
							selPorcentajeIR: obj.selPorcentajeIR,
							txtRetencion: obj.txtRetencion,
							txtImporte: obj.txtImporte,
							txtDescripcion: obj.txtDescripcion	
			}
			_array.push(tempo);					
		 });	


	var tituloVistaPreliminar="";
	if($tipoComprobante.val()==1){//Eletronico		
		tituloVistaPreliminar = "Liquidaci&oacute;n de Compra Electr&oacute;nica";
	}else if($tipoComprobante.val()==2){//fisico	
		tituloVistaPreliminar = "Liquidaci&oacute;n de Compra F&iacute;sica";
	}else{
		tituloVistaPreliminar = "Liquidaci&oacute;n de Compra";
	}
	 
	     $tipoDocumento = "DNI";
	 if($selTipoDocumento.val()=="1"){
		 $tipoDocumento = "DNI";		 
	 }else if($selTipoDocumento.val()=="4"){
		 $tipoDocumento = "Carnet de Extranjeria";		 
	 }else if($selTipoDocumento.val()=="7"){
		 $tipoDocumento = "Pasaporte";		 
	 } 
	
	//console.log("$tipoDocumento:"+$tipoDocumento);	
	
	  
      var retObj = {
		  
			preview: {
				titulo: tituloVistaPreliminar
			},
			
			emisor: {
			  ruc: $hiddenRucEmisor.val(),
			  tipoDoc: "RUC",
			  direccion: $hiddenDireccionEmisor.val(),
			  razon_social: $hiddenRazonSocialEmisor.val(),
			  nombre_comercial: $hiddenNombreComercialEmisor.val(),
			  departamento: $hiddenDepartamentoEmisor.val()
			},
			liquidacion: {
				fecha_emision: $txtFechaEmision.val(),			
				razon_social: $txtRazonSocial.val(),	
				tipo_documento : $tipoDocumento,				
				dni: $txtDocumento.val(),			
				direccion_vendedor: $txtDireccionVendedor.val(),
				direccion_operacion: $txtDireccionOperacion.val(),				
				moneda: $selMoneda.val(),
				observaciones: $txtObservaciones.val(),
				tipoLiquidacion : $('input:radio[name=rdoAnticipos]:checked').val(), 
			},
			resumen: {
				 monedaSimbolo: $(".simbolo-moneda").html(),		
				 subTotalVentas: $hiddensubTotalVentas.val(),
				 anticipos : $hiddenanticipos.val(),
				 valorVenta : $hiddenvalorVenta.val(),
				 totalIGV : $hiddentotalIGV.val(),
				 totalVenta : $hiddentotalVenta.val(),
				 totalIGVCredito : $hiddentotalIGVCredito.val(),
				 totalRetencion : $hiddentotalRetencion.val(),
				 importeNeto : $hiddenimporteNeto.val()
			},
			
			documentos_relacionados: _DocumentosRelacionados,
			items: _array,
			Vehiculos: _Vehiculos      
      };




		var _arrayTempoDeducciones = [];

		$.each(_deducciones_seleccionadas, function( key, obj ) {	
													
/*			console.log("num_deduccion:"+obj.num_deduccion);													
			console.log("serie:"+obj.serie);													
			console.log("numero:"+obj.numero);													
			console.log("importeneto:"+obj.importeneto);													
			console.log("importededucido:"+obj.importededucido);	*/															
													
													
			var tempo = {	num_deduccion : obj.num_deduccion,
							serie: obj.serie,
							numero: obj.numero,
							importeneto: obj.importeneto,
							importededucido: obj.importededucido							
			}
			_arrayTempoDeducciones.push(tempo);					
		 });



    var retObj2 = {				  
			emisor: {
			  ruc: $hiddenRucEmisor.val(),
			  direccion: $hiddenDireccionEmisor.val(),
			  razon_social: $hiddenRazonSocialEmisor.val(),
			  nombre_comercial: $hiddenNombreComercialEmisor.val(),
			  departamento: $hiddenDepartamentoEmisor.val(),
			},
			liquidacion: {
				fecha_emision: $txtFechaEmision.val(),			
				nombres: $txtRazonSocial.val(),			
				numeroDocumento: $txtDocumento.val(),	
				tipoDocumento: $selTipoDocumento.val(),
				direccion_vendedor: $hidDireccionVendedor.val(),
				ubigeo_vendedor: $hidUbigeoVendedor.val(), 
				descripcion_ubigeo_vendedor: $hidDesUbigeoVendedor.val(),
				tipo_direccion_vendedor: $selTipoDireccionVendedor.val(),
				direccion_entrega: $hidDireccionOperacion.val(),				
				ubigeo_entrega: $hidUbigeoOperacion.val(),
				descripcion_ubigeo_entrega: $hidDesUbigeoOperacion.val(),
				tipo_direccion_operacion: $selTipoDireccionOperacion.val(),				
				cod_establecimiento: $hidCodEstablecimiento.val(),
				moneda_iso: $selMoneda.val(),
				observaciones: $txtObservaciones.val(),
				monedaSimbolo: $(".simbolo-moneda").html(),		
				subTotalVentas: ($hiddensubTotalVentas.val()).replace(',',''),
				anticipos : ($hiddenanticipos.val()).replace(',',''),
				valorVenta : ($hiddenvalorVenta.val()).replace(',',''),
				totalIGV : ($hiddentotalIGV.val()).replace(',',''),
				totalVenta : ($hiddentotalVenta.val()).replace(',',''),
				totalIGVCredito : ($hiddentotalIGVCredito.val()).replace(',',''),
				totalRetencion : ($hiddentotalRetencion.val()).replace(',',''),
				importeNeto : ($hiddenimporteNeto.val()).replace(',',''),
				tipoLiquidacion : $('input:radio[name=rdoAnticipos]:checked').val(), 
				mto_canc_pago: 0,
				mto_canc_deduc: deducido_suma,
				mto_saldo : deducido_saldo,
				chkGratuita: $('input:checkbox[name=chkGratuita]:checked').val(),
				totalGratuito: ($hiddenTotalValorVentaOperaGratuitas.val()).replace(',',''),
				tipoComprobante : $tipoComprobante.val(),
				serieFisico : $txtSerieFisico.val(),
				numeroFisico  : $txtNumeroFisico.val()				
			},
			documentos_relacionados: _DocumentosRelacionados,
			items: _array,
			Vehiculos: _Vehiculos,
			deducciones: _arrayTempoDeducciones
      };


      var retObj3 = {
        items: _array      
      };


      var retObj4 = {

      liquidacion: {
				fecha_emision: $txtFechaEmision.val(),			
				razon_social: $txtRazonSocial.val(),	
                tipo_documento : $tipoDocumento,				
				dni: $txtDocumento.val(),			
				direccion_vendedor: $txtDireccionVendedor.val(),
				direccion_operacion: $txtDireccionOperacion.val(),				
				moneda: $selMoneda.val(),
				observaciones: $txtObservaciones.val()
        }      
      };

	  var retObj5 = {
         documentos_relacionados: _DocumentosRelacionados,      
      };
	  
	  var retObj6 = {		  
		 Vehiculos: _Vehiculos      
      };	  

	  
      retObj.documentos_relacionados = _.map(retObj.documentos_relacionados, function (doc) {
        doc.selTipoDocumentoRelacionado_val = _tipoDocumentoRelacionado[doc.selTipoDocumentoRelacionado]
        return doc;
      });	  
	  
      retObj.items = _.map(retObj.items, function (i) {
        i.selUnidadMedida_val = _tipoMedida[i.selUnidadMedida]
		//i.selTipoIgv_val = 18.00 //
        return i;
      });
	  
      retObj.liquidacion.moneda_simbolo = encodeURIComponent(_moneda[retObj.liquidacion.moneda]);
      retObj.liquidacion.moneda = _monedaDescripcion[retObj.liquidacion.moneda];
	  
      _datosCompletos = retObj;
      _datosEnvio=retObj2;

      _datosItems=retObj3;
      _datosLiquidacion=retObj4;      
      _datosDocumentos=retObj5;      
      _datosVehiculos=retObj6;      	  
	  
	  
//	  console.log("JSON.stringify(_arrayPagos):"+JSON.stringify(_datosCompletos));	  
	  
	  
      return retObj;

    } // fin preparar datos


	$formLiquidacionComplementarios.validate(_.extend(window._validatorWallSettings, {
        rules: {
            txtObservaciones: {
                maxlength: 500
            },
			hiddenHelperDeduccionesAnticipos:{				
				moreThan: { 
							param: 0,
							depends: 
							function(element){		
								 //console.log("$hiddenHelperDeduccionesAnticipos.val(0):"+$hiddenHelperDeduccionesAnticipos.val());
								 //console.log("rdoAnticipos:"+$('input:radio[name=rdoAnticipos]:checked').val());
								if($('input:radio[name=rdoAnticipos]:checked').val()== 1){
									return true;
								}else{
									return false;
								}
							}
						}
	        }
		},
        messages: {
            txtDireccionVendedor: {
                maxlength: "Debe ingresar la observaci&oacute;n como m&aacute;ximo 500 caracteres"
                },
			hiddenHelperDeduccionesAnticipos:{
				moreThan: "Agregue un anticipo a la Liquidaci&oacute;n de compra con deducci&oacute;n"	
			}	
		}
        
    }));

	//Fin Bloque Botones de vista preliminar
	//***********************************************************************************


		
	//***********************************************************************************	
	//Pantalla flotante de elegir direccion	
	
	//Cargar los departamentos
	cargarDepartamentos("selDepartamento",jsonDepartamentos);	
	
	$selDepartamento.on('change', function (e) {
		 cargarProvincias("selProvincia",jsonProvincias);
		 cargarDistritos("selDistrito",jsonDistritos);
	});
	
	$selProvincia.on('change', function (e) {
		 cargarDistritos("selDistrito",jsonDistritos);
		 $selDistrito.val("");
	});	
	
	function cargarDepartamentos(id,lstDepartamentosJson){
		$("#"+id).empty();
		var tOption="<option value=''>Departamento</option>";
		$.each(lstDepartamentosJson, function( index, value ) {
			tOption = tOption + " <option value='"+$.trim(value.id) +"'>"+$.trim(value.nombre)+"</option>";
		});	
		if(tOption != ""){
			$("#"+id).append(tOption);
		}  	
	}
	
	function buscarGlosa(id,lstJson,esHTML){
		var nombre="";
		$.each(lstJson, function( index, value ) {									 
			if($.trim(id)==$.trim(value.id)){													  
				nombre = $.trim(value.nombre);
				
				if(esHTML==0){
				    nombre = nombre.replace('&Ntilde;', '\u00D1');					
				}
				
				return true;
			}
		});			
		return nombre;
	}	
		
	function cargarProvincias(id,lstProvinciasJson){	
		$("#"+id).empty();
		var tOption="<option value=''>Provincia</option>";		
		var selDepartamento = $selDepartamento.val();
		$.each(lstProvinciasJson, function( index, value ) {										   
			var codigo = $.trim(value.id);									   
			codigo = codigo.substr(0,2);								   										   
			if(selDepartamento==codigo){							   
				tOption = tOption + " <option value='"+$.trim(value.id) +"'>"+$.trim(value.nombre)+"</option>";
			}
		});	
		if(tOption != ""){
			$("#"+id).append(tOption);
		}  	
	}	
	
	function cargarDistritos(id,lstDistritosJson){		
		$("#"+id).empty();
		var tOption="<option value=''>Distrito</option>";		
		var selProvincia = $selProvincia.val();
		$.each(lstDistritosJson, function( index, value ) {										   
			var codigo = $.trim(value.id);									   
			codigo = codigo.substr(0,4);								   									   
							
			if(selProvincia==codigo){					
				tOption = tOption + " <option value='"+$.trim(value.id) +"'>"+$.trim(value.nombre)+"</option>";
			}
		});	
		if(tOption != ""){
			$("#"+id).append(tOption);
		}  	
	}	

	//Validacion del formulario
	$formModalDireccion.validate(_.extend(window._validatorWallSettings,{
        rules: {
            selDepartamento: { required: true }, 
            selProvincia: { required: true}, 
            selDistrito: { required: true}, 
            txtDireccion: { required: true, minlength:5, maxlength:250} 			
        },
        messages: {
			selDepartamento: {	required: "Debe seleccionar un departamento" },
			selProvincia: {	required: "Debe seleccionar una provincia" },
			selDistrito: {	required: "Debe seleccionar un distrito" },			
			txtDireccion: {	required: "Debe ingresar la direcci&oacute;n del vendedor",
							minlength:"Debe ingresar la direcci&oacute;n del vendedor y como m&iacute;nimo 5 caracteres",
							maxlength:"Debe ingresar la direcci&oacute;n del vendedor como m&aacute;ximo 250 caracteres"
						}						
        },
		
        submitHandler: function(form){
			
			var selDepartamento = $("#selDepartamento").val();
			var selProvincia = $("#selProvincia").val();
			var selDistrito = $("#selDistrito").val();
			var txtDireccion = $("#txtDireccion").val();
	
			var selDepartamento_value = $("#selDepartamento option:selected").html();
			var selProvincia_value = $("#selProvincia option:selected").html();
			var selDistrito_value = $("#selDistrito option:selected").html();		
	
			//var hidDireccion = txtDireccion;
			var desUbigeo = selDepartamento_value+"-"+selProvincia_value+"-"+selDistrito_value;
			//var hidUbigeo = selDepartamento+"-"+selProvincia+"-"+selDistrito;
			
			if(opcionDireccion==1){//indica direccion del  vendedor
				$txtDireccionVendedor.val(txtDireccion+"\n"+desUbigeo);	
				$hidDireccionVendedor.val(txtDireccion);
				$hidUbigeoVendedor.val(selDistrito);
				$hidDesUbigeoVendedor.val(desUbigeo);
			}if(opcionDireccion==2){//indica direccion de la operacion
				$txtDireccionOperacion.val(txtDireccion+"\n"+desUbigeo);	
				$hidDireccionOperacion.val(txtDireccion);
				$hidUbigeoOperacion.val(selDistrito);
				$hidDesUbigeoOperacion.val(desUbigeo);
				$hidCodEstablecimiento.val("");
			}		
			
			var valor = $('input:radio[name=opciones]:checked').val();  	
			if(valor==0) { 
				$txtDireccionOperacion.val($hidDireccionVendedor.val()+"\n"+$hidDesUbigeoVendedor.val());
				$hidUbigeoOperacion.val($hidUbigeoVendedor.val());
				$hidDireccionOperacion.val($hidDireccionVendedor.val());
				$hidDesUbigeoOperacion.val($hidDesUbigeoVendedor.val());						
			}
			
			
			//var valor = $('input:radio[name=opciones]:checked').val()  	
			//if(valor==0) $txtDireccionOperacion.val($txtDireccionVendedor.val());	
			$modalDireccion.modal('hide');	
       }
    }));			
	
	//boton de seleccionar direccion ingresada	
    $btnSeleccionarDireccion.on('click', function (e) {
    });	
	
	function setDepartamento(departamento) {	
		$('#selDepartamento option:selected').removeAttr('selected');	  	  
		$("#selDepartamento option").each(function(){												   
			if($(this).val() == departamento){
				$(this).val(departamento).prop("selected", "true");          				
			}
		});	    	
	}
	
	function setProvincia(provincia) {	
		$('#selProvincia option:selected').removeAttr('selected');	  		
		
		 cargarProvincias("selProvincia",jsonProvincias);			
		
		$("#selProvincia option").each(function(){												   
												
			//console.log("$(this).val():"+$(this).val());												
			//console.log("provincia:"+provincia);															
			if($(this).val() == provincia){
				$(this).val(provincia).prop("selected", "true");          				
			}
		});	    	
	}	
	
	function setDistrito(distrito) {	
		$('#selDistrito option:selected').removeAttr('selected');	  	  
		
		cargarDistritos("selDistrito",jsonDistritos);	
		 
		$("#selDistrito option").each(function(){												   
			if($(this).val() == distrito){
				$(this).val(distrito).prop("selected", "true");          				
			}
		});	    	
	}	
	
	function setSeleccionarDireccion(ubigeoOperacion){
		
		 //var arrDatosDireccion  = ubigeoOperacion.split("-");
				  
		  if(ubigeoOperacion.length>0){			  

			  var departamento = ubigeoOperacion.substring(0,2);
			  var provincia = ubigeoOperacion.substring(0,4);
			  var distrito = ubigeoOperacion.substring(0,6);

		  
		  
		  	  //console.log("departamento:"+departamento);
		  	  //console.log("provincia:"+provincia);
		      //console.log("distrito:"+distrito);				
			  setDepartamento(departamento);
			  setProvincia(provincia);
			  setDistrito(distrito);		  
		  }			
	}
	
	//Fin Pantalla flotante de elegir direccion	
	//***********************************************************************************
	
	
	//***********************************************************************************
	//Pantalla flotante para seleccionar una direccion de una lista de direcciones
    $modalDirecciones.on('click', '.agregar', function(e) {													   
        _direccionSeleccionada = $(this).closest('tr').attr('data-row-id');
        var direccion = _.find(_DireccionesEmisor, {codigo: _direccionSeleccionada})
        //$txtLugarEntrega.val(direccion.domicilio);
        //$modalDirecciones.modal('hide');													   
													   
													   
        var direccion_ = direccion.domicilio;//		$(this).attr('data-address');        		
		    //direccion_ = direccion_.replace('<br/>', '\n');
		
		$hidCodEstablecimiento.val(direccion.codigo);
		
		  //console.log("direccion.codigo:"+direccion.codigo);
			
			
		  var splitDireccion = direccion_.split('<br/>');
		  if(splitDireccion.length<2) splitDireccion = direccion_.split('<br>');
  		  if(splitDireccion.length<2) splitDireccion = direccion_.split('\n');
		
		  direccion_ = splitDireccion[0];
		  
		  var departamento = "";
		  var provincia = "";
		  var distrito  = "";
		  
		  if(direccion.ubigeo.length>0){
			  departamento = direccion.ubigeo.substring(0,2);
			  //console.log("departamento:"+departamento);
			  departamento = buscarGlosa(departamento,jsonDepartamentos,0);
			  //console.log("departamento:"+departamento);			  
			  
			  provincia = direccion.ubigeo.substring(0,4);
			  //console.log("provincia:"+provincia);
			  provincia = buscarGlosa(provincia,jsonProvincias,0);
			  //console.log("provincia:"+provincia);			  
			  
			  distrito = direccion.ubigeo.substring(0,6);			
			  //console.log("distrito:"+distrito);			  
			  distrito = buscarGlosa(distrito,jsonDistritos,0);	
			  //console.log("distrito:"+distrito);			  			  
		  }
		  
		  var desDireccion = departamento + "-"+ provincia + "-"+distrito;
			
        $txtDireccionOperacion.val(direccion_ + "\n"+desDireccion );
			
		$hidUbigeoOperacion.val(direccion.ubigeo);
		$hidDireccionOperacion.val(direccion_);
		$hidDesUbigeoOperacion.val(desDireccion);		
        $modalDirecciones.modal('hide');
    });	
	
	
    function renderDireccionesEmisor() {
        var tbody = $tablaDireccionesEmisor.find('tbody');
        tbody.empty();
        for (var i in _DireccionesEmisor) {
            var direccion = _DireccionesEmisor[i];
            var $row = $('<tr/>', {
                'data-row-id': direccion.codigo
            });
            $('<td/>').append(
              $('<button/>').addClass('btn btn-primary agregar').append(
                $('<i/>').addClass('glyphicon glyphicon-ok')
              )
            ).appendTo($row);
            for (var k in _DireccionesEmisorSchema) {
                var text = direccion[k];
                $('<td/>').html(text).appendTo($row);
            }
            $row.appendTo(tbody);
        }
        $tablaDireccionesEmisor.trigger('footable_initialize');
    }	
	
	//Fin Pantalla flotante para seleccionar una direccion de una lista de direcciones	
	//***********************************************************************************	
	
	

	//***********************************************************************************
	//Pantalla flotante para visualizar los items
    $btnOpenModalAgregarItem.on('click', function (e) {
									
		//console.log("_Items.length:"+_Items.length);
		
        if(_Items.length >= 10){
            bootbox.alert('Puede ingresar como m\u00E1ximo 10 \u00EDtems');
            return;
        }
												   
        $formModalItem.find('.alert').remove();
        $formModalItem.find('.has-error').removeClass('has-error');
        $formModalItem.find(':input').val('');	
		
		
		cargarMedida();
		cargaAfectacionIGV();
		cargaAfectacionIR();
		cargaPorcentajeIR();				
		$txtCantidad.val("1.00");
		$txtRetencion.val("0.00");
		$txtImporte.val("0.00");
		$txtIGV.val("0.00");
		//$selPorcentajeIR.prop('disabled', 'disabled');
		$modalItem.modal('show');											
    });		
	
	//Fin Pantalla flotante para visualizar los items
	//***********************************************************************************	


	//***********************************************************************************
	//Pantalla flotante para agregar los items
	
	//var _itemEditando = false;
	
    $('[data-format-numeric]').on('change', function(e){
        var places = e.target.getAttribute('data-decimal-places') || 10;
        var groupDelimiter = e.target.getAttribute('data-group-delimiter') || undefined;
        e.target.value = $(this).numVal().toMoney(places, groupDelimiter);
    });	
	
	 $('.calculate-total').bind('change keyup', function(e) {													 
		calculaIGV();
		calculaIR();    		
    });

    $formModalItem.validate(_.extend(window._validatorWallSettings, {
        debug: true,
        rules: {
            txtCodigo : { required: true//,
						  //minlength: 8, maxlength: 8, 
						  //validaNumerico: true, 
						  //validaSiCatalogo: "txtCodigo" 
						  }, 
            txtCodigoUsuario  : { maxlength: 30}, 			
            txtDescripcion : { required: true,maxlength: 200
			//, validaSiCatalogo: "txtDescripcion"
			}, 
            selUnidadMedida: { required: true}, 
            txtValorUnitario : { required: true, moreThan: 0},//, validaDecimal: true}, maxlength: 11,
            txtCantidad: { required: true,  moreThan:0},// ,maxlength: 11, validaDecimal: true}, 
            selTipoIgv: { required: true}, 
            txtIGV : { required: true }, 
            selTipoAfectacionIR: { required: true}, 
            selPorcentajeIR: { 
								required:  
								function(element){
									var ind2 = $('select[name=selTipoAfectacionIR]').val();
									if(ind2==1){ 
										return true;
									}else{ 
										return false;
									}
								}			
			}, 						
			txtRetencion: { required: true}, 									
            txtImporte: { required: true} 	
        },
        // estos mensajes estan aqui porque son d&iacute;n&aacute;micos respecto al html
        messages: {
			txtCodigo: { 
								required: "Ingrese un valor en el campo C&oacute;digo de SUNAT", 
								minlength: "Ingrese como m&iacute;nimo 8 caracteres para el campo C&oacute;digo de SUNAT",
								maxlength: "Ingrese como m&aacute;ximo 8 caracteres para el campo C&oacute;digo de SUNAT",								
								validaNumerico: "Debe ingresar solo valores num&eacute;ricos para el campo C&oacute;digo de SUNAT",
								validaSiCatalogo: "Debe ingresar un c&oacute;digo bien SUNAT existente en su cat&aacute;logo"
								
								}, 
            txtCodigoUsuario  : { maxlength: "Ingrese como m&aacute;ximo 30 caracteres para el campo C&oacute;digo de usuario"}, 						
            txtDescripcion : { 
							   required: "Ingrese un valor en el campo Descripci&oacute;n", 
							   maxlength: "Ingrese como m&aacute;ximo 200 caracteres para el campo Descripci&oacute;n"
   							  // validaSiCatalogo: "Debe seleccionar una descripci&oacute;n existente en el cat&aacute;logo"
							  }, 
            selUnidadMedida: { required: "Seleccione un valor en el campo Unidad de medida"}, 
            txtValorUnitario : { required: "Ingrese un valor en el campo Valor unitario", 
								 validaNumerico: "Ingresar solo valores num&eacute;ricos de hasta 8 enteros y hasta 2 decimales para el campo Valor unitario",
								 maxlength: "Ingresar solo valores num&eacute;ricos de hasta 8 enteros y hasta 2 decimales para el campo Valor unitario",
								 moreThan:"Debe ingresar un valor mayor a cero para Valor unitario"
								 }, 
            txtCantidad: {       required: "Ingrese un valor en el campo Cantidad", 
								 validaNumerico: "Ingresar solo valores num&eacute;ricos de hasta 8 enteros y hasta 2 decimales para el campo Cantidad",
								 maxlength: "Ingresar solo valores num&eacute;ricos de hasta 8 enteros y hasta 2 decimales para el campo Cantidad",
								 moreThan:"Debe ingresar un valor mayor a cero para Cantidad"
								 }, 
            selTipoIgv: { required: "Seleccione un valor en el campo tipo de afectaci&oacute;n IGV"}, 
			txtIGV			    : { required: "Ingrese un valor en el campo IGV"}, 
            selTipoAfectacionIR: { required: "Seleccione un valor en el campo el tipo de afectaci&oacute;n IR"},
			txtRetencion	    : { required: "Ingrese un valor en el campo Monto de la retenci&oacute;n de Renta"}, 
			txtImporte		    : { required: "Ingrese un valor en el campo Importe neto de operaci&oacute;n"} 
        },
        submitHandler: function(form) {
            var data = $(form).last().serializeObject();
			
			
			//console.log("data antes de poner"+ data.txtCodigo);
			//var x = data.txtCodigo.split("-");
            //text = $.trim(x[0]);
		    //data.txtCodigo = text;
			
			//console.log("data despues de poner"+ data.txtCodigo);
			
            var criteria = {
                        txtCodigo: data.txtCodigo,
                        txtDescripcion: data.txtDescripcion/*,
                        selUnidadMedida: data.selUnidadMedida,
                        txtValorUnitario: data.txtValorUnitario,
                        txtImporte: data.txtImporte*/
            };
           
            duplicated = !! _.findWhere(_Items, criteria);
 
            if(duplicated){
                bootbox.alert('El item ingresado ya existe en la lista de items');
                return;
            }			
			
			/*
            if (_itemEditando) {
                editarItem({
                    itemId: _itemEditando
                }, data);
            } else {*/
                data.itemId = _.uniqueId('');
				
				//console.log("data.itemId:"+data.itemId);
				if($('input:radio[name=rdoAnticipos]:checked').val()==0){ 
					if(_Items.length>0){ 
						actualizarItemsAnticipo("agregar"); 
					}
				}
                agregarItem(data);
            //}
            $modalItem.modal('hide');
            //_itemEditando = false;
            //actualizarResumen();
        }
    }));
	
	
	function actualizarResumen()
	{
		
		//console.log("actualizarResumen");
		
		var subTotalVentas=0;
		var anticipos = 0;
		var valorVenta = 0;
		var totalIGV = 0;
		var totalVenta = 0;
		var totalIGVCredito = 0;
		var totalRetencion = 0;
		var importeNeto = 0;
	
        _.each(_Items, function(e) {
            subTotalVentas +=  parseFloat(e.txtValorUnitario.replace(/,/g, '')) * parseFloat(e.txtCantidad.replace(/,/g, ''))  || 0  ;
			
            //totalValorDescuentos += parseFloat(e.txtDescuento.replace(/,/g, '')) || 0;
            totalIGV += parseFloat(e.txtIGV.replace(/,/g, '')) || 0;
           // totalImporte += parseFloat(e.txtImporte.replace(/,/g, '')) || 0;
            totalRetencion += parseFloat(e.txtRetencion.replace(/,/g, '')) || 0;
        });	
		
		
		subTotalVentas = redondeo(subTotalVentas,2);
		totalIGV = redondeo(totalIGV,2);
		totalRetencion = redondeo(totalRetencion,2);
		$montoVentaLC = subTotalVentas;
		
		$hiddenTotalValorVentaOperaGratuitas.val("0.00");
		if($chkGratuita.prop('checked')){
			$hiddenTotalValorVentaOperaGratuitas.val(subTotalVentas.toMoney(2));
			subTotalVentas = 0;
			totalIGV = 0;
			totalRetencion = 0;
		}		
	
		//console.log("actualizarResumen");
		anticipos = deducido_suma;
		
	
		//console.log("anticipos:"+anticipos);
	
		//cambio en pase PAS20191U210100153		
		valorVenta = subTotalVentas;
		////antes del pase PAS20191U210100153:  valorVenta = subTotalVentas- anticipos;
		
		//console.log("subTotalVentas:"+subTotalVentas);
		
		totalVenta =  valorVenta + totalIGV;

		//console.log("totalVenta:"+totalVenta);	
		//totalVenta = Math.round10(totalVenta,2);
		totalVenta = redondeo(totalVenta,2);
		//console.log("totalVenta redondeo:"+totalVenta);	
		
		totalIGVCredito = totalIGV;
		//cambio en pase PAS20191U210100153
		importeNeto = totalVenta - totalIGV - totalRetencion - anticipos;	
		//antes del pase PAS20191U210100153: importeNeto = totalVenta - totalIGV - totalRetencion - anticipos;	
		importeNeto = redondeo(importeNeto,2);		
		
		//console.log("totalVenta:"+totalVenta);
		//console.log("totalIGV:"+totalIGV);		
		//console.log("totalRetencion:"+totalRetencion);
		//console.log("importeNeto:"+importeNeto);
		
		////antes del pase PAS20191U210100153:  $montoNetoLC = importeNeto + anticipos;
		$montoNetoLC = importeNeto; // + anticipos;
		$montoNetoLCSinAnticipos = totalVenta - totalIGV - totalRetencion;
		
		//console.log("$montoNetoLCSinAnticipos:"+$montoNetoLCSinAnticipos);
		
		$hiddensubTotalVentas.val(subTotalVentas.toMoney(2));
		$hiddenanticipos.val(anticipos.toMoney(2));
		$hiddenvalorVenta.val(valorVenta.toMoney(2));
		$hiddentotalIGV.val(totalIGV.toMoney(2));
		$hiddentotalVenta.val(totalVenta.toMoney(2));
		$hiddentotalIGVCredito.val(totalIGVCredito.toMoney(2));
		$hiddentotalRetencion.val(totalRetencion.toMoney(2));
		$hiddenimporteNeto.val(importeNeto.toMoney(2));	
		
		
		//console.log("$hiddenimporteNeto.val(:"+$hiddenimporteNeto.val());
		
		//deducido_importeneto = importeNeto.toMoney(2);
	
	}
		

    function agregarItem(data) {
        _Items.push(data);
        renderItem();
    }
	
    $tablaItem.on('click', 'button.remover', function(e) {
        var rowId = $(e.target).closest('tr').attr('data-item-id');
		//console.log("button.remover:"+rowId);
        eliminarItem({
            itemId: rowId
        });
        //refrescarResumen();
    });
	
    function eliminarItem(criteria) {
		
		//console.log("criteria:"+criteria);
        _Items = _.reject(_Items, criteria)
        renderItem();
    }	 
	
	function renderItem() {
		
		recorrerItems();		
		
		
        var tbody = $tablaItem.find('tbody');
        tbody.empty();
        for (var i in _Items) {
			
            var doc = _Items[i];		
			
			//console.log("doc.itemId:"+doc.itemId);		
			
            var $row = $('<tr/>', {
                'data-item-id': doc.itemId
            });
			
			//console.log("row:"+$row );
            for (var k in _itemSchema) {
				
				//console.log("k:"+k);
                var text = doc[k];
				//console.log("text_:"+text);
				/*
                if (k == 'txtCodigo') {
					var x = text.split("-");
                    text = $.trim(x[0]);
                }	*/							
				
                if (k == 'selUnidadMedida') {
                    text = _tipoMedida[text];
                }				
                if (k == 'selTipoIgv') {
                    text = _afectacionIGV[text];
                }								
				if (k == 'selTipoAfectacionIR'){
					text = _afectacionIR[text];
					//if(typeof text == 'undefined') text="0.00%";
				}
				if (k == 'selPorcentajeIR'){
					text = _porcentajeIR[text];
					if(typeof text == 'undefined') text="0.00%";
				}
				if (k == 'txtDescripcion'){				
				
					var valor = $('input:radio[name=rdoAnticipos]:checked').val(); 
					if(valor==0){		
						 if(text.indexOf("***Pago Anticipado***") == -1 && text.indexOf(" ***PAGO ANTICIPADO*** ") == -1)
						 text = $.trim(text) + " ***Pago Anticipado*** ";					
					}
				}				
			
                $('<td/>').html(text).appendTo($row);
            }
            $('<td/>').append($('<button/>').addClass('btn btn-danger btn-sm remover').append($('<i/>').addClass('glyphicon glyphicon-remove'))).appendTo($row);

            $row.appendTo(tbody);			
        }		
		
			
		 //$("#tabla-item").find('td').eq(2).attr({ 'class': 'descripcion' });		 
		 
 		 //$("#tabla-item").find('td').eq(5).attr({ 'class': 'descripcion' });		 
		
        $("#items-counter").text(_Items.length)
        $modalItem.find('.lista-errores').empty();
        $panelItems.find('.lista-errores').empty();
        $hiddenHelperItem.val(_Items.length);
        $tablaItem.trigger('footable_initialize');
		$btnItems.html("&Iacute;tems del comprobante ("+_Items.length+")");
		
		if(_Items.length==1){	
			$selMonedaSeleccionada = $selMoneda.val();
		}
		//console.log("selMonedaSeleccionada:"+$selMonedaSeleccionada);
		actualizarResumen();

		//$("#tabla-item").find('td').eq(4).attr({ 'class': 'descripcion' });	 			
		//$("#tabla-item").find('td').eq(4).addClass("descripcion");			
		
		$('#tabla-item tr').each(function(){			
			$(this).find('td').eq(4).attr({ 'class': 'descripcion' });	 							
		});	
		

		
    }	
	
    $selTipoIgv.on('change', function(e){
		calculaIGV();
    });		

    $selTipoAfectacionIR.on('change', function(e){											   
		//console.log("$selTipoAfectacionIR.val():"+$selTipoAfectacionIR.val());									   
		if($selTipoAfectacionIR.val()=="Gravado"){
			$selPorcentajeIR.removeAttr('disabled');
			//por defecto 4%
			$selPorcentajeIR.prop('selectedIndex',0);			
		}else if($selTipoAfectacionIR.val()=="No Gravado"){
			//$selPorcentajeIR.prop('selectedIndex',0);
			$selPorcentajeIR.val("0.00");
			$selPorcentajeIR.prop('disabled', 'disabled');	
		}		
		
		calculaIR();
		
    });		
	
    $selPorcentajeIR.on('change', function(e){
		calculaIR();
    });			
	
	//Chiche para el tema de la descripcion que se borra cuando se 
	//cambia de control
	
	var $descripcionItem  ="";
	
	$("input, select").on("click, focus", function(){ 
												   
	    $descripcionItem = $txtDescripcion.val();
		
		if($descripcionItem!="") {			
			
			  var valor = $('input:radio[name=rdoAnticipos]:checked').val(); 
			  if(valor==0){				  
					 if($descripcionItem.indexOf(" ***Pago Anticipado*** ") == -1 && $descripcionItem.indexOf("***PAGO ANTICIPADO*** ") == -1){
						 $descripcionItem = $.trim($descripcionItem) + " ***Pago Anticipado*** ";					  
					 }
			  }else if(valor==1){

			  }else{
				  
			  }		 
			 
			$txtDescripcion.val($descripcionItem);				
			
		}
    });
	
	/*
	
	$txtCodigo.blur(function() {
		$descripcionItem = $txtDescripcion.val();		
	});	
	
	$txtDescripcion.focus(function() {
		$descripcionItem = $txtDescripcion.val();		
	});	
	
	$txtDescripcion.blur(function() {
		$descripcionItem = $txtDescripcion.val();		
	});	*/
	
	//finb de chiche

	//Fin Pantalla flotante para agregar los items
	//***********************************************************************************	

		
		


	//***********************************************************************************
	//Pantalla flotante para visualizar los documentos relacionados
    $btnOpenModalDR.on('click', function (e) {									
        $formModalDocumentoRelacionado.find('.alert').remove();
        $formModalDocumentoRelacionado.find('.has-error').removeClass('has-error');
        $formModalDocumentoRelacionado.find(':input').val('');											  
		$modalDocumentoRelacionado.modal('show');				
    });		
	//Fin Pantalla flotante para visualizar los documentos relacionados
	//***********************************************************************************


	//***********************************************************************************
	//Pantalla flotante para agregar los documentos relacionados


    $selTipoDocumentoRelacionado.on('change', function (e) {
        //$txtSerie.parent().toggleClass('hidden', e.target.value == '99')
        $formModalDocumentoRelacionado.find('.alert').remove();
        $formModalDocumentoRelacionado.find('.has-error').removeClass('has-error');
		if(e.target.value == '99'){
			$txtSerie.prop('disabled', true);
					
		}else{
			$txtSerie.prop('disabled', false);
		}
		
		
    })

	
	$formModalDocumentoRelacionado.validate(_.extend(window._validatorWallSettings, {//frank
        debug: true,
        rules: {
            selTipoDocumentoRelacionado: {
                required: true,
            },
            txtSerie: {

				validSerieDocRel: { 
								param: ["#selTipoDocumentoRelacionado"],
								depends: 
								function(element){									
									if($selTipoDocumentoRelacionado.val() == "09" || $selTipoDocumentoRelacionado.val() == "31"  || $selTipoDocumentoRelacionado.val() == "G9" ){
										return true;
									}else{
										return false;
									}
								}
							},
							// PAS20221U210700224 se comento para el el pase
//				number: { depends:  se bloqueo para el pase
//							function(element){
//									if($selTipoDocumentoRelacionado.val() == "31"){
//										return true;
//									}else{
//										return false;
//									}
//							}	
//						},
				
                minlength:4,
                required: function () {
                    return $selTipoDocumentoRelacionado.val() != '99'
                },
            },
            txtNumero: {
                required: true,
                maxlength:10,
				number:true
            },
            txtDescripcion: {
                required: false,
            },
        },
        // estos mensajes estan aqui porque son d&iacute;n&aacute;micos respecto al html
        messages: {
            selTipoDocumentoRelacionado: {
                required: 'Ingrese un valor en el campo Tipo de documento'
            },
            txtSerie: {
                number:"Debe ingresar solo valores num&eacute;ricos para el campo Serie",
                required: 'Ingrese un valor en el campo Serie',
				validSerieDocRel:'La serie ingresada no est&aacute; permitida',
				minlength:"Ingrese 4 caracteres alfanum&eacute;ricos para la Serie"
            },
            txtNumero: {
                required: 'Ingrese un valor en el campo N&uacute;mero',
                maxlength: 'S&oacute;lo se permiten 10 caracteres de longitu',
                number:"Debe ingresar solo valores num&eacute;ricos para el campo N&uacute;mero",				
            },
            txtDescripcion: {
                required: 'Ingrese la Descripci&oacute;n'
            },
        },
       
       submitHandler: function(form) {
/// START eliminacion de duplicados //////
                var data = $(form).first().serializeObject();
                if(parseInt(data.txtNumero)<1){
                	bootbox.alert('Ingrese un valor en el campo N&uacute;mero');
                   return;
                }
                var criteria = {
                        selTipoDocumentoRelacionado: data.selTipoDocumentoRelacionado,
                        txtNumero: parseInt(data.txtNumero)
                };
                
                
               // PAS20221U210700224 JBM  go
                var docRelac = _DocumentosRelacionados.map(item => {
                 	let Numero = parseInt(item.txtNumero);
                 	return {...item, txtNumero: Numero };
                 	
                });
                // PAS20221U210700224 JBM end
 
            if(data.selTipoDocumentoRelacionado != '99'){
                criteria.txtSerie = data.txtSerie;
            }
           
            duplicated = !! _.findWhere(_DocumentosRelacionados, criteria);
            duplicated = !! _.findWhere(docRelac, criteria); 	// PAS20221U210700224 JBM 
            if(duplicated){
                bootbox.alert('El documento ingresado ya existe en la lista de documentos relacionados');
                return;
            }
           
/// END eliminacion de duplicados //////
            data.rowId = _.uniqueId('dr-');
            agregarDocumentoRelacionado(data);
            $modalDocumentoRelacionado.modal('hide');
        }
    }));	
	
    function agregarDocumentoRelacionado(data) {
        _DocumentosRelacionados.push(data);
        renderDocumentoRelacionado();
    }

    function eliminarDocumentoRelacionado(criteria) {
        _DocumentosRelacionados = _.reject(_DocumentosRelacionados, criteria)
        renderDocumentoRelacionado();
    }	
	
    $tablaDocumento.on('click', 'button.remover', function(e) {
        var rowId = $(e.target).closest('tr').attr('data-row-id');
        eliminarDocumentoRelacionado({
            rowId: rowId
        });
    })
	
	function renderDocumentoRelacionado() {
        var tbody = $tablaDocumento.find('tbody');
        tbody.empty();
		var filas = 1;
        for (var i in _DocumentosRelacionados) {
            var doc = _DocumentosRelacionados[i];
            var $row = $('<tr/>', {
                'data-row-id': doc.rowId
            });
			var columnas=1;
            for (var k in _DocumentosRelacionadosSchema) {
                
				var text = "";		
				if(columnas==1){				
					text = filas;
				}else{
					
				   if(typeof doc[k] != 'undefined'){ 
		               text = doc[k].toUpperCase();
				   }
				}	
				
                if (k == 'selTipoDocumentoRelacionado') {
                    text = _tipoDocumentoRelacionado[text];
                }
				
				
                $('<td/>').html(text).appendTo($row);
				columnas++;
            }
            $('<td/>').append($('<button/>').addClass('btn btn-danger btn-sm remover').append($('<i/>').addClass('glyphicon glyphicon-remove'))).appendTo($row);
            $row.appendTo(tbody);
			filas ++;
        }
        $("#documentos-relacionados-counter").text(_DocumentosRelacionados.length)
        $hiddenHelperDR.val(_DocumentosRelacionados.length);
        $tablaDocumento.trigger('footable_initialize');
		$btnDocumentos.html("Documentos Relacionados ("+_DocumentosRelacionados.length+")");
    }	

	//Fin Pantalla flotante para agregar los documentos relacionados
	//***********************************************************************************

	
	//***********************************************************************************	
	//Pantalla flotante para visualizar los vehiculos
    $btnOpenModalAgregarVehiculo.on('click', function (e) {									
        $formModalAgregarVehiculos.find('.alert').remove();
        $formModalAgregarVehiculos.find('.has-error').removeClass('has-error');
        $formModalAgregarVehiculos.find(':input').val('');														   
		$modalAgregarVehiculos.modal('show');				
    });		
	//Fin Pantalla flotante para visualizar los vehiculos
	//***********************************************************************************	


	//***********************************************************************************	
	//Pantalla flotante para agregar los vehiculos	
	
	function agregarVehiculos(data) {
        _Vehiculos.push(data);
        renderVehiculos();
    }
	

	 
    $tablaVehiculo.on('click', 'button.remover', function(e) {
        var rowId = $(e.target).closest('tr').attr('data-item-id');
        eliminarVehiculo({
            rowId: rowId
        });
        //refrescarResumen();
    })
	
    function eliminarVehiculo(criteria) {
        _Vehiculos = _.reject(_Vehiculos, criteria)
        renderVehiculos();
    }	 
	
	function renderVehiculos() {
        var tbody = $tablaVehiculo.find('tbody');
        tbody.empty();
		var filas = 1;
        for (var i in _Vehiculos) {
            var doc = _Vehiculos[i];		
            var $row = $('<tr/>', {
                'data-item-id': doc.rowId
            });
			var columnas = 1;
            for (var k in _VehiculosSchema) {
				var text = "";		
				if(columnas==1){				
					text = filas;
				}else{
	               text = doc[k];
				}
				//console.log("text:"+text);
                $('<td/>').html(text).appendTo($row);
				columnas++;
            }
			filas++;
            $('<td/>').append($('<button/>').addClass('btn btn-danger btn-sm remover').append($('<i/>').addClass('glyphicon glyphicon-remove'))).appendTo($row);
            $row.appendTo(tbody);
        }
        //$("#items-counter").text(_Items.length)
        $modalAgregarVehiculos.find('.lista-errores').empty();
        $hiddenHelperVehiculos.val(_Vehiculos.length);
        $tablaVehiculo.trigger('footable_initialize');
		
		$btnVehiculos.html("Veh&iacute;culos de transporte ("+_Vehiculos.length+")");
    }		

	$formModalAgregarVehiculos.validate(_.extend(window._validatorWallSettings, {//frank
        debug: true,
        rules: {
            txtPlaca: {
                required: true,
				validaPlaca: true
            }
        },
        // estos mensajes estan aqui porque son d&iacute;n&aacute;micos respecto al html
        messages: {
            txtPlaca: {
                required: 'Ingrese un valor en el campo N&uacute;mero de placa',
				validaPlaca:'Ingrese 7 caracteres alfanum&eacute;ricos incluido el gui&oacute;n para el n&uacute;mero de placa'
            }
        },
       
       submitHandler: function(form) {
/// START eliminacion de duplicados //////

                var data = $(form).first().serializeObject();
				
				data.txtPlaca = data.txtPlaca.toUpperCase();
                var criteria = {
                        txtPlaca: data.txtPlaca
                }; 
           
            duplicated = !! _.findWhere(_Vehiculos, criteria);
 
            if(duplicated){
                bootbox.alert('El n\u00FAmero de placa ingresado ya existe en la lista de veh\u00EDculos de transporte');
                return;
            }
           
/// END eliminacion de duplicados //////
            data.rowId = _.uniqueId('dr-');
            agregarVehiculos(data);
            $modalAgregarVehiculos.modal('hide');
        }
    }))	


	//Fin Pantalla flotante para agregar los vehiculos
	//***********************************************************************************	
	
	
	//***********************************************************************************	
	//Pantalla flotante de calendario
	
    var _CURR_DATE_PICKER = null;
    $('.datepicker').on('click', function(e) {
        _CURR_DATE_PICKER = $(e.target);
        $modalDatepicker.modal('show');
    });
	
	
	if($tipoComprobante.val()==1){//Eletronico		

	    var date1 = new Date();
    	date1.setDate(date1.getDate()-2);		
		 
		$datepicker.datepicker({
			// endDate: new Date(),
			endDate: '0d',
			startDate: date1
//			locale: moment.locale('es_PE.UTF-8'),
	//		language: 'es_PE.UTF-8'
			//maxDate:'1'
		}).on('changeDate', function(e) {
			$datepickerHidden.val(e.format());
			cerrandoCalendario();			
		});
		//$labelTituloEmision.text("Emisi\u00F3n de Liquidaci\u00F3n de Compra Electr\u00F3nica");
	}else{//fisico	
	
	
		var f1 = new Date();
		var dia1 = f1.getDate();
		var mes1 = f1.getMonth()+1; 	
		var tope = 0;
		
		//console.log("mes1:"+mes1);
		//console.log("dia1:"+dia1);
		
	    if(mes1==1 || mes1 == 3 || mes1==5 || mes1 == 7 || mes1==8 || mes1 == 10 || mes1 == 12)
		{  
			tope=31;
		}else if(mes1==2){
			tope=2;
		}else{
			tope=30
		}
		//console.log("tope:"+tope);			
		var dias = tope - dia1;
		
		//console.log("dias:"+dias);	
		
		dias = dias + 20;
	
		//console.log("dias+20:"+dias);	
		
		var diasstring = '+'+String(dias) + 'd';
		
		//console.log("diasstring:"+diasstring);	
		
		$datepicker.datepicker({
			// endDate: new Date(),
			//endDate: diasstring//,
			//startDate: '0d'
			//maxDate:'1'
		}).on('changeDate', function(e) {
			$datepickerHidden.val(e.format());
			cerrandoCalendario();			
		});
		//$labelTituloEmision.text("Registro de Liquidaci\u00F3n de Compra F\u00EDsica");
	}	
	
	
	function cerrandoCalendario(){	
											 
		//console.log("$datepickerHidden.val():"+$datepickerHidden.val());									 		
		if($datepickerHidden.val()!=""){
			var selectedDate = $datepickerHidden.val();
			_CURR_DATE_PICKER.val(selectedDate).trigger('change');
			$datepickerHidden.val('');
			_CURR_DATE_PICKER = null;
			$modalDatepicker.modal('hide');
		}else{
			bootbox.alert("Haga click en la fecha deseada");	
		}	
	
	}
	
	
    $btnCloseDatepicker.on('click', function(e) {
		cerrandoCalendario();
    });	
	
	//Fin Pantalla flotante de calendario
	//***********************************************************************************	
	
	//***********************************************************************************	
	//Pantalla de vista previa
	
	
	function emitirFactura(){
		

		$modalCondiciones.modal('hide');
		
 	/// quickfix 15-10-2015
	
		if($tipoComprobante.val()==3){
			//if(!confirm('\u00BFEsta seguro de registrar su comprobante?')){
			//	return;
			//}
		      bootbox.setLocale("es");  
			  bootbox.confirm({
				message: '\u00BFEsta seguro de registrar su comprobante?',
				closeButton: false,
				buttons: {
				  confirm: {
					label: 'Aceptar',
				  },
				  cancel: {
					label: 'Cancelar',
				  },
				},
				callback: function (result) {
				  if(result){
					//-------------------------------------------------------------------------------------------------------------------------------
					$btnEmitirFactura.prop('disabled', true);
					$modalPreloader.modal('show');

					 var url = $entornoApp+"?action=grabarComprobante";
					 $.ajax({
								data: { variable:JSON.stringify(_datosEnvio),					 
							 },
							method: 'post',
							//contentType: "application/text; charset=UTF-8",
							dataType: 'json',
							url: url,
						})
						 .done(function( data, textStatus, jqXHR ) {
							 if ( console && console.log ) {					 
							   // $modalPreloader.modal('show');			
								//window.location.href = "emitirliquidacion.do?action=mostrarFacturaGenerada";

							 $modalPreloader.modal('hide');		 
							 
								 if(data!="0"){
									 $("#serienumero").html(data);		 
									 $('#btnEmitirFactura').addClass('hidden');
									 $('#btnVolverFactura').addClass('hidden');				
									 $("#btnEnviarCorreo").removeClass('hidden');		
									 $("#btnEmitirNuevo").removeClass('hidden');	
									 
									 
									  var valor = $('input:radio[name=rdoAnticipos]:checked').val(); 
									  if(valor==0){
											$btnRegistroPagos.addClass('hidden');					  
									  }else if(valor==1){
											$btnRegistroPagos.removeClass('hidden');					  
									  }else{
											$btnRegistroPagos.removeClass('hidden');					  
									  }
									 
									 
									if(!isMobile.any() ) //si NO es movil
									{						 						 
										$("#btnDescargarPDF").removeClass('hidden');		
									 //$("#btnDescargarXML").removeClass('hidden');		
										if($tipoComprobante.val()==1){//Si es Eletronico		
											$btnDescargarXML.removeClass('hidden');	
										}else{
											$btnDescargarXML.addClass('hidden');	
										}

									 
									}
									 
									$tituloVista.text("  ");
									 
									 
								 }else{
									$btnEmitirFactura.prop('disabled', false);
									bootbox.alert("No se pudo emitir la Liquidaci\u00F3n de compra, int\u00E9ntelo nuevamente");					
								}
							 }
						 })
						 .fail(function( jqXHR, textStatus, errorThrown ) {
							 if ( console && console.log ) {
								 console.log( "La solicitud ha fallado: " +  textStatus);
							 }
						});
					//-------------------------------------------------------------------------------------------------------------------------------
				  }
				},
			  });
		} else {
			//if(!confirm('\u00BFEsta seguro de emitir su comprobante?')){
			//	return;
			//}
		      bootbox.setLocale("es");  
			  bootbox.confirm({
				message: '\u00BFEsta seguro de emitir su comprobante?',
				closeButton: false,
				buttons: {
				  confirm: {
					label: 'Aceptar',
				  },
				  cancel: {
					label: 'Cancelar',
				  },
				},
				callback: function (result) {
				  if(result){
					//-------------------------------------------------------------------------------------------------------------------------------
					$btnEmitirFactura.prop('disabled', true);
					$modalPreloader.modal('show');

					 var url = $entornoApp+"?action=grabarComprobante";
					 $.ajax({
								data: { variable:JSON.stringify(_datosEnvio),					 
							 },
							method: 'post',
							//contentType: "application/text; charset=UTF-8",
							dataType: 'json',
							url: url,
						})
						 .done(function( data, textStatus, jqXHR ) {
							 if ( console && console.log ) {					 
							   // $modalPreloader.modal('show');			
								//window.location.href = "emitirliquidacion.do?action=mostrarFacturaGenerada";

							 $modalPreloader.modal('hide');		 
							 
								 if(data!="0"){
									 $("#serienumero").html(data);		 
									 $('#btnEmitirFactura').addClass('hidden');
									 $('#btnVolverFactura').addClass('hidden');				
									 $("#btnEnviarCorreo").removeClass('hidden');		
									 $("#btnEmitirNuevo").removeClass('hidden');	
									 
									 
									  var valor = $('input:radio[name=rdoAnticipos]:checked').val(); 
									  if(valor==0){
											$btnRegistroPagos.addClass('hidden');					  
									  }else if(valor==1){
											$btnRegistroPagos.removeClass('hidden');					  
									  }else{
											$btnRegistroPagos.removeClass('hidden');					  
									  }
									 
									 
									if(!isMobile.any() ) //si NO es movil
									{						 						 
										$("#btnDescargarPDF").removeClass('hidden');		
									 //$("#btnDescargarXML").removeClass('hidden');		
										if($tipoComprobante.val()==1){//Si es Eletronico		
											$btnDescargarXML.removeClass('hidden');	
										}else{
											$btnDescargarXML.addClass('hidden');	
										}

									 
									}
									 
									$tituloVista.text("  ");
									 
									 
								 }else{
									$btnEmitirFactura.prop('disabled', false);
									bootbox.alert("No se pudo emitir la Liquidaci\u00F3n de compra, int\u00E9ntelo nuevamente");					
								}
							 }
						 })
						 .fail(function( jqXHR, textStatus, errorThrown ) {
							 if ( console && console.log ) {
								 console.log( "La solicitud ha fallado: " +  textStatus);
							 }
						});
					//-------------------------------------------------------------------------------------------------------------------------------
				  }
				},
			  });
		}
		
        /*
		$btnEmitirFactura.prop('disabled', true);
		$modalPreloader.modal('show');

         var url = $entornoApp+"?action=grabarComprobante";
		 $.ajax({
					data: { variable:JSON.stringify(_datosEnvio),					 
				 },
				method: 'post',
				//contentType: "application/text; charset=UTF-8",
				dataType: 'json',
				url: url,
			})
			 .done(function( data, textStatus, jqXHR ) {
				 if ( console && console.log ) {					 
				   // $modalPreloader.modal('show');			
					//window.location.href = "emitirliquidacion.do?action=mostrarFacturaGenerada";

				 $modalPreloader.modal('hide');		 
				 
					 if(data!="0"){
		 				 $("#serienumero").html(data);		 
						 $('#btnEmitirFactura').addClass('hidden');
						 $('#btnVolverFactura').addClass('hidden');				
						 $("#btnEnviarCorreo").removeClass('hidden');		
						 $("#btnEmitirNuevo").removeClass('hidden');	
						 
						 
						  var valor = $('input:radio[name=rdoAnticipos]:checked').val(); 
						  if(valor==0){
								$btnRegistroPagos.addClass('hidden');					  
						  }else if(valor==1){
							    $btnRegistroPagos.removeClass('hidden');					  
						  }else{
							    $btnRegistroPagos.removeClass('hidden');					  
						  }
						 
						 
						if(!isMobile.any() ) //si NO es movil
						{						 						 
							$("#btnDescargarPDF").removeClass('hidden');		
						 //$("#btnDescargarXML").removeClass('hidden');		
							if($tipoComprobante.val()==1){//Si es Eletronico		
								$btnDescargarXML.removeClass('hidden');	
							}else{
								$btnDescargarXML.addClass('hidden');	
							}

						 
						}
						 
						$tituloVista.text("  ");
						 
						 
					 }else{
						$btnEmitirFactura.prop('disabled', false);
						alert("No se pudo emitir la Liquidaci\u00F3n de compra, int\u00E9ntelo nuevamente");					
					}
				 }
			 })
			 .fail(function( jqXHR, textStatus, errorThrown ) {
				 if ( console && console.log ) {
					 console.log( "La solicitud ha fallado: " +  textStatus);
				 }
			});
		*/
	
	}	
	
  $btnEmitirFactura.on('click', function(e){		
										 
						//restaFechas	obtenerFecha(0);
/*  	var dias = restaFechas(obtenerFecha(0),$fechaMensaje);						
	
	console.log("dias:"+dias);
		if(dias>=0){
			$modalCondiciones.modal('show');			
		}else{		
			emitirFactura();
		}*/
		
		
		//PAS20191U210300032
		
			//validarMontoUIT();
			/*
			console.log('LUEGO DE validarMontoUIT:');
			console.log('montoNetoLC:'+$montoNetoLC);
			console.log('monto_uit:'+$monto_uit);
			console.log('monto_emitido 1:'+$monto_emitido);
			console.log('montoVentaLC:'+$montoVentaLC);
			console.log('valorActualDolar:'+valorActualDolar);
		*/
		
			if($selMoneda.val()!="PEN"){
				//$montoVentaLC = $montoVentaLC * ;
				//$montoVentaLC =  $montoVentaLC * valorActualDolar;
			}	
			
			if($chkGratuita.prop('checked')){
				$montoVentaLC = 0;
			}			
			
			//console.log('montoVentaLC:'+$montoVentaLC);
			var $monto_final = $monto_emitido; // + $montoVentaLC;// parseFloat($montoNetoLC.replace(/,/g, '')) || 0;
			
			//console.log('monto_final sumado:'+$monto_final);		

		if($tipoComprobante.val()==1){//Eletronico				
						
			//console.log('monto_emitido 2:'+$monto_emitido);
			if(!$chkGratuita.prop('checked')){			
				if(parseFloat($monto_uit)<=parseFloat($monto_final)){
					bootbox.alert('El vendedor ha superado la venta anual de liquidaci\u00F3n de compra por un monto mayor a '+numeroUIT+' UITs contadas desde enero del presente a\u00F1o');					
					return;
				}
			}
			emitirFactura();				
			
		}else{		

		//console.log('monto_emitido 2:'+$monto_emitido);
			if(parseFloat($monto_uit)<=parseFloat($monto_final)){
				bootbox.alert('Estimado Contribuyente, El vendedor super\u00F3 las 75 UIT');
			}			
			
			if($fec_fall_pnat.length>1){
			
				//var fec = values[2]+"/"+values[1]+"/"+values[0];
				
				//console.log("fec"+fec);	
							
				if(!comparaSiFechaInicioMenorIgualFechaFin($txtFechaEmision.val(),$fec_fall_pnat))
				{
					 bootbox.alert('El vendedor debe estar no fallecido');
					 return;
				}else{
					emitirFactura();	
				}			
			}else{
					emitirFactura();	
			}
			

		}
	
   });	
	
	
	
    $btnVolverFactura.on('click', function (e) {
        $('#root-panels').removeClass('hidden')
        $("#panel-preview").addClass('hidden');
    });
	
    $btnEnviarCorreo.on('click', function (e) {
	   $txtEmail.val("");										   
	   $modalCorreo.modal('show');	
    });
	
	function volverInicio(){
		
			$('#root-panels').removeClass('hidden')
			$("#panel-preview").addClass('hidden');
			$panelLiquidacionDireccion.addClass('hidden').find('.panel-collapse').collapse('hide');			
			$panelLiquidacionOperacion.addClass('hidden').find('.panel-collapse').collapse('hide');						
			$panelLiquidacionItems.addClass('hidden').find('.panel-collapse').collapse('hide');			
			$panelLiquidacionComplementarios.addClass('hidden').find('.panel-collapse').collapse('hide');						
			$panelLiquidacionAnticipos.addClass('hidden').find('.panel-collapse').collapse('hide');						
			$btnValidarDatosVendedor.removeClass('hidden');
			
			$btnContinuarPaso.addClass('hidden');			
			$txtDocumento.prop('disabled', false);	
			$selTipoDocumento.prop('disabled', false);	
			$txtDocumento.val("");
			$txtRazonSocial.val("");
	
			$("#buttons").addClass('hidden');			
			
	
			//if(_DireccionesEmisor!=null) _DireccionesEmisor.length=0;
			if(_Items!=null) _Items.length=0;
			if(_DocumentosRelacionados!=null) _DocumentosRelacionados.length=0;
			if(_Vehiculos!=null) _Vehiculos.length=0;
			if(_Productos!=null) _Productos.length=0;
			if(_liquidaciones_seleccionadas!=null) _liquidaciones_seleccionadas.length=0;
			if(_deducciones_seleccionadas!=null) _deducciones_seleccionadas.length=0;		
			
			
			renderDocumentoRelacionado();
			renderVehiculos();
			renderItem();
			

			
			//location.href = "/ol-ti-itemisionliquidacion/"+$entornoApp+"?tipo="+$tipoComprobante.val();								  
			//window.location.href = "/ol-ti-itemisionliquidacion/"+$entornoApp+"?tipo="+$tipoComprobante.val();
			
			
			
		 $('#btnEmitirFactura').removeClass('hidden');
		 $btnEmitirFactura.prop('disabled', false);
		 $('#btnVolverFactura').removeClass('hidden');				
		 $("#btnEnviarCorreo").addClass('hidden');		
		 $("#btnEmitirNuevo").addClass('hidden');	
		 $btnRegistroPagos.addClass('hidden');					  
		 
		 
		if(!isMobile.any() ) //si NO es movil
		{						 						 
			 $("#btnDescargarPDF").addClass('hidden');		
			 $("#btnDescargarXML").addClass('hidden');	
		}else{
		}		
		
		if(isMobile.any() && $esAPP=="1" ) //si es movil
		{
		}else{// si no es movil
			$btnvolver.addClass('hidden');	
		}			
			
		establecerValoresIniciales();
	}
	
	
	var fecha = "";
	function establecerValoresIniciales(){

		var f = new Date();
		var dia = f.getDate();
		var mes = f.getMonth()+1; 		
		var anio= f.getFullYear();	
		if(dia<10) dia = "0"+dia;
		if(mes<10) mes = "0"+mes;		
		fecha = dia + "/" + mes + "/" + anio;
		$txtFechaEmision.val(fecha);	
		
		$hiddenHelperItem.val(0);
		$hiddenHelperDeduccionesAnticipos.val(0);
		$hiddenHelperDR.val(0);
		$hiddenHelperVehiculos.val(0);				
		opcionDireccion = 0;
		
		cargarSelectoresInicio();
		
		$btnDocumentos.html("Documentos Relacionados ("+_DocumentosRelacionados.length+")");
		$btnItems.html("&Iacute;tems del comprobante ("+_Items.length+")");
    	$btnDeduccionesAnticipos.html("Deducciones de anticipos ("+_deducciones_seleccionadas.length+")");		
		$btnVehiculos.html("Veh&iacute;culos de transporte ("+_Vehiculos.length+")");		
		
		$txtDireccionVendedor.val('');
		if($desUbigeoVendedorDNI!='')
		 $txtDireccionVendedor.val($direccionVendedorDNI+"\n"+$desUbigeoVendedorDNI);
	 
		 $hidDireccionVendedor.val($direccionVendedorDNI);
		 $hidUbigeoVendedor.val($ubigeoVendedorDNI);
		 $hidDesUbigeoVendedor.val($desUbigeoVendedorDNI);		 
		 
		 //$("#opcvendedor_0").prop("checked", true);
		 $txtDireccionOperacion.val('');
		 if($hidDesUbigeoVendedor.val()!='')
		 $txtDireccionOperacion.val($hidDireccionVendedor.val()+"\n"+$hidDesUbigeoVendedor.val());
	 
		 $hidUbigeoOperacion.val($hidUbigeoVendedor.val());
		 $hidDireccionOperacion.val($hidDireccionVendedor.val());
		 $hidDesUbigeoOperacion.val($hidDesUbigeoVendedor.val());
		 $hidCodEstablecimiento.val("");		 
		 
		 $("#opciones_0").prop("checked", true);
		 $("#opcvendedor_0").prop("checked", true);
		 $divBloqueDireccionDNI.removeClass('hidden');	
		 
		 if($tipoComprobante.val() == "2" || $tipoComprobante.val() == "3"){
			 $txtSerieFisico.val("");
			 $txtNumeroFisico.val("");
		 }
		 
		 $("#chkGratuita").prop('checked', false);
		 
		 $("#rdoAnticipos_0").prop('checked', false);
		 $("#rdoAnticipos_1").prop('checked', false);		 
		 
		 $txtObservaciones.val("");
		 
		 $(".simbolo-moneda").html("S/");
		 
		//$txtFechaInicioBusqueda.val(obtenerFecha(-30));
		//$txtFechaFinBusqueda.val(obtenerFecha(0));
		$monedaFiltroAnticipo.val($selMoneda.val());
		
		actualizarResumen();
		inicializarDeducidos();
		$btnDeduccionesAnticipos.prop('disabled', true);
		
		
		
		
		
		 
	}		
	
	
    $btnEmitirNuevo.on('click', function (e) {										  
		volverInicio();
    });
	
	
    $btnDescargarPDF.on('click', function (e) {
	  var url = $entornoApp+'?action=descargarPDF'; 		
	  
		descarga.action=url;
		descarga.submit();								  
    });
	
	
    $btnDescargarXML.on('click', function (e) {
										   
	  var url = $entornoApp+'?action=descargaXML'; 		
	  
		descarga.action=url;
		descarga.submit();	  
			  
/*	$.ajax({
		url: 'emitirliquidacion.do?action=descargaComprobante',
		dataType: 'JSON',
		success: function(response){
			if(response.zip) {
				location.href = response.zip;
			}
		}
	});	  */
	

    });	
	
	//Fin Pantalla de vista previa	
	//***********************************************************************************		
	
	
	//***********************************************************************************			
	//Pantalla flotante de envio de correo	

	 $formModalCorreo.validate(_.extend(window._validatorWallSettings, {
        debug: false,
        rules: {
            txtEmail: {
                required: true,
                validaEmail: true
            }
        },
		
        // estos mensajes estan aqui porque son d&iacute;n&aacute;micos respecto al html
        messages: {
            txtEmail: {
                required: 'Verifique su email',
				validaEmail:'Verifique su email'
            }
        },		
       
        submitHandler: function(form) {
       	   //$btnEmitirFactura.prop('disabled', true);
		   $modalPreloader.modal('show');
           var formData=$(form).serializeObject();
           var url = $entornoApp+'?action=enviarCorreo';
           $.ajax({
              method: 'post',
              data: formData,
              url:url,
              success: function (data) {
				
				$modalPreloader.modal('hide');
				
				if(data.data=="1"){
				    bootbox.alert('Se ha enviado el correo electr\u00F3nico correctamente');	
					$modalCorreo.modal('hide');	
				}else{
					bootbox.alert('Ocurrio un error intentelo en unos minutos');	
				}
				
              },
			  error: function() {
				 $modalPreloader.modal('hide');
                bootbox.alert('Ocurrio un error intentelo en unos minutos');
              }
            });           
        }
    }));
	
	//FIn Pantalla flotante de envio de correo		
	//***********************************************************************************			
	
	
	//***********************************************************************************		
	//Otras funciones utiles	
	
	function calculaIGV(){		
		var igv = 0;	
		if($selTipoIgv.val()=="Gravado" && $txtValorUnitario.val()!='' && $txtCantidad.val()!=''){
			igv = $igvPorcentajeGlobal*(parseFloat($txtValorUnitario.val().replace(/,/g, '')) *parseFloat($txtCantidad.val().replace(/,/g, '')));			
		}				
		$txtIGV.val(formatoMoneda(igv.toFixed(2)));		
	}	 
	
	function calculaIR(){			
		var ir = 0;	
		if($selTipoAfectacionIR.val()=="Gravado" && $txtValorUnitario.val()!='' && $txtCantidad.val()!='' && $selPorcentajeIR.val()!=''){
			ir = parseFloat($selPorcentajeIR.val().replace(/,/g, ''))*(parseFloat($txtValorUnitario.val().replace(/,/g, ''))*parseFloat($txtCantidad.val().replace(/,/g, '')));			
		}		
		$txtRetencion.val(formatoMoneda(ir.toFixed(2)));		
		calculaImporteItem();
	}
	
	function calculaImporteItem(){
		var importe = 0;
		if($txtValorUnitario.val()!='' && $txtCantidad.val()!=''){		
			importe = parseFloat($txtValorUnitario.val().replace(/,/g, ''))*parseFloat($txtCantidad.val().replace(/,/g, '')) - parseFloat($txtRetencion.val().replace(/,/g, ''));					
		}
		$txtImporte.val(formatoMoneda(importe.toFixed(2)));		
	}

   		
	
	
			
	//Fin Otras funciones utiles	
	//***********************************************************************************		
	

    var _Productos = [];
    var _ProductoSchema = {
            txtCodigo: "C&oacute;digo",
            txtDescripcion: "Descripci&oacute;n",
            selTipo: "Tipo",
            selUnidadMedida: "Unidad de Medida",
            selMoneda: "Moneda",
            txtValorUnitario: "Precio de Venta"
        }

	/*
    $txtCodigo.add($txtDescripcion).on('typeahead:select', function(e, s) {
        var producto = _.find(_Productos, {
            txtCodigo: s.txtCodigo
        });
		
		//console.log("producto:"+producto);
        if (producto) popularModalItem(producto, true, false);
    });*/
	
    function popularModalItem(data, triggerChange, ignoreCodigo) {
		
        for (var i in _itemSchema) {
			
            if (!data.hasOwnProperty(i) || ignoreCodigo && i == 'txtCodigo') continue;			
			if(i == 'txtCodigo' || i == 'txtDescripcion'){	
			
/*			console.log("i:"+i);
			console.log("data[i]:"+data[i]);*/
			
				var el = $formModalItem.find('#' + i);
				el.val(data[i]);
				if (triggerChange) el.trigger('keyup').trigger('change');
			}
        }
       if(data.hasOwnProperty('selMoneda')){
            var totales = data.selMoneda;
            var divisa = $selMoneda.val()
            if(totales.hasOwnProperty(divisa)){
              $formModalItem.find('#txtValorUnitario').val(totales[divisa]);
              if (triggerChange)
                $formModalItem.find('#txtValorUnitario').trigger('keyup').trigger('change');
            }
        }
    }	
	
    var ProductoCodigoBH = new Bloodhound({
        datumTokenizer: Bloodhound.tokenizers.obj.whitespace('txtCodigo', 'txtDescripcion'),
        queryTokenizer: Bloodhound.tokenizers.whitespace,
        local: [],
        identify: function(obj) {
            return obj.txtCodigo;
        },
    });
	
	
	/*
 $txtCodigo.typeahead({
            hint: true,
            highlight: true,
            minLength: 4
        }, {
          name: 'codigos',
          source: ProductoCodigoBH,
          templates: {
              suggestion: function(e) {
                  var par = $('<div/>')
                  $('<em/>').text(e.txtCodigo).appendTo(par);
                  par.append(' - ');
                  $('<span/>').text(e.txtDescripcion).appendTo(par);
                  return par;
              }
          },
        display: 'txtCodigo'
    });
 
  $('.tt-query').css('background-color', '#fff');
  
    $txtDescripcion.typeahead({
        hint: true,
        highlight: true,
        minLength: 5
    }, {
        name: 'codigos',
        source: ProductoCodigoBH,
        templates: {
            suggestion: function(e) {
				
				//console.log("entra aqui");
				
                var par = $('<div/>')
                $('<em/>').text(e.txtCodigo).appendTo(par);
                par.append(' - ');
                $('<span/>').text(e.txtDescripcion).appendTo(par);
                return par;
            }
        },
        display: 'txtDescripcion'
    });	
	*/

	var $selCodigo = $("#selCodigo");
	
	
    function prefetchProductos() {
		
		//ProductoCodigoBH.clear();
		
       $.getJSON($entornoApp+'?action=getCatalogoProductos', function(data) {																			  
            _Productos = data;	

		   $.each(_Productos, function(i, item) {
				//console.log(item);
			});

		$txtCodigo.empty();
		var tOption="<option value=''>Seleccione c&oacute;digo bien SUNAT</option>";		
		$.each(_Productos, function( index, value ) {										   
			tOption = tOption + " <option value='"+$.trim(value.txtCodigo) +"'>"+$.trim(value.txtDescripcion)+"</option>";
		});	
		if(tOption != ""){
			$txtCodigo.append(tOption);
		}  	

		   //ProductoCodigoBH.add(_Productos);		   
           //$selMoneda.trigger('focus').trigger('change')						   
        });
    }
	
	
	$txtCodigo.on('change', function (e) {
		
		var valor = $("#txtCodigo option:selected" ).text();
		//console.log("valor:"+valor);		
		//var arr = valor.split("-");

		//console.log("0:"+arr[0]);
		//console.log("1:"+arr[1]);		
				
		$txtDescripcion.val(valor);
	});	
	
	
	
	
	 $selMoneda.on('change', function (evt) {
        var prev = $(this).attr('data-previous')
        
        if(_Items.length > 0 && this.value != prev){

			//console.log("selMonedaSeleccionada change:"+$selMonedaSeleccionada);
			$selMoneda.val($selMonedaSeleccionada);
            bootbox.alert('No puede cambiar de moneda, existen items agregados');
            //this.value = prev;
            return;
			
        }else {

			  $(".simbolo-moneda").html(_moneda[this.value] );
			  $monedaFiltroAnticipo.val($selMoneda.val());
	  		  inicializarDeducidos();	  
			  actualizarListaDeducciones();
/*			  ProductoCodigoBH.clear();
				var filtered = _.filter(_Productos, function(e){
					return _.has(e.selMoneda, evt.target.value)
				})
			  ProductoCodigoBH.add(filtered);*/
	    }
    });


function inicializarDeducidos(){
	
	deducido_importeneto = 0;
	deducido_suma = 0;
	deducido_saldo = deducido_importeneto - deducido_suma;		
    _deducciones_seleccionadas.length=0;
	actualizarSaldoDeducciones();		  
	$btnDeduccionesAnticipos.html("Deducciones de anticipos ("+_deducciones_seleccionadas.length+")");
    $hiddenHelperDeduccionesAnticipos.val(0);
	actualizarListaDeducciones();
	//oTableDeducciones.dataTable().fnDestroy();	
	//cargarDeduccionesSeleccionadas(null);
	//$btnDeduccionesAnticipos.prop('disabled', true);
	
}

///**********************************************************************************************//
///**********************************************************************************************//
///***********************SEGUNDA FASE DE LA LIQUIDACI�N ELETR�NIOCA ASOCIAR LIQUIDACION DE PAGO CON ANTICIPO*****************************//
///**********************************************************************************************//
///**********************************************************************************************//
///**********************************************************************************************//

var $hiddenHelperDeduccionesAnticipos = $("#hiddenHelperDeduccionesAnticipos");
var $btnDeduccionesAnticipos = $("#btnDeduccionesAnticipos");
var $panelLiquidacionAnticipos = $("#panel-liquidacion-anticipos");
var $formModalDeduccionesAnticipos = $("#form-modal-deduccionesAnticipos");
var $modalDeduccionesAnticipos = $("#modal-deduccionesAnticipos");
var $openModalLiquidacionesAnticipos = $("#open-modal-liquidacionesAnticipos");
var $modalLiquidacionesAnticipos = $("#modal-liquidacionesAnticipos");


var $txtSerieBusqueda = $("#txtSerieBusqueda");
var $txtNumeroBusqueda = $("#txtNumeroBusqueda");
var $selTipoDocumentoBusqueda = $("#selTipoDocumentoBusqueda");
var $txtDocumentoBusqueda = $("#txtDocumentoBusqueda");
var $txtFechaInicioBusqueda = $("#txtFechaInicioBusqueda");
var $txtFechaFinBusqueda = $("#txtFechaFinBusqueda");
var $btnValidarBusqueda = $("#btnValidarBusqueda");
var $btnVolverBusqueda = $("#btnVolverBusqueda");	
var $formModalLiquidacionesAnticipos = $("#form-modal-liquidacionesAnticipos");	
var $btnIncluirLiquidaciones = $("#btnIncluirLiquidaciones");	


var $tblLiquidacionesAnticipo = $("#tblLiquidacionesAnticipo");
var $tblDeduccionesAnticipo = $("#tblDeduccionesAnticipo");

var _liquidaciones_seleccionadas = [];
var _deducciones_seleccionadas = [];


var oTableDeducciones=null;
var oTableLiquidaciones = null;


var deducido_importeneto_html = $("#deducido_importeneto");
var deducido_suma_html = $("#deducido_suma");
var deducido_saldo_html = $("#deducido_saldo");


var $rdoAnticipos = $("#rdoAnticipos");
var $btnRegistroPagos = $("#btnRegistroPagos");

var deducido_importeneto = 0;
var deducido_suma = 0;
var deducido_saldo = deducido_importeneto - deducido_suma;

deducido_importeneto_html.text(deducido_importeneto);
deducido_suma_html.text(deducido_suma);
deducido_saldo_html.text(deducido_saldo);


var $mto_canc_pagoEmision=0;
var $mto_canc_deducEmision = 0;

var	$monedaFiltroAnticipo = $("#monedaFiltroAnticipo");
var	$dniFiltroAnticipo = $("#dniFiltroAnticipo");
var $montoNetoLC = 0;
var $montoNetoLCSinAnticipos = 0;
var $montoVentaLC = 0;



$btnRegistroPagos.on('click', function (e) {


        //if(!confirm('\u00BFDesea registrar pagos ?')){
        //    return;
        //}

		      bootbox.setLocale("es");  
			  bootbox.confirm({
				message: '\u00BFDesea registrar pagos ?',
				closeButton: false,
				buttons: {
				  confirm: {
					label: 'Aceptar',
				  },
				  cancel: {
					label: 'Cancelar',
				  },
				},
				callback: function (result) {
				  if(result){
					//var id = row.nroruc+"_"+row.numseriegre+"_"+row.numgre+"_"+row.numdociderecep+"_"+row.nombreDestinatario+"_"+row.codmoneda+"_"+row.mtototalventa+row.fecemision;	
					var serienumero = $("#serienumero").html();	
					var ser = serienumero.split("-")	
					var serietmp =  $.trim(ser[0]);
					var numtmp =  $.trim(ser[1]);
					
					var id = $hiddenRucEmisor.val()+"_"+serietmp+"_"+numtmp+"_"+$txtDocumento.val()+"_"+$txtRazonSocial.val()+"_"+$selMoneda.val()+"_"+$montoNetoLC+"_"+$txtFechaEmision.val() + "_"+$selTipoDocumento.val();			
					//console.log("id:"+id);
					var lista = null;
					
					
					if(_deducciones_seleccionadas.length>0){
						$saldoInicial = deducido_saldo;							
					}else{
						$saldoInicial = $montoNetoLC;			
					}
					
					
					//console.log("saldoInicial:"+$saldoInicial);
					
					
					if( isMobile.any() && $esAPPPagos=="1" ) //si es movil
					{
						$entornoAppPagos = "emitirliquidacion.htm";
						
					}else{// si no es movil
						$entornoAppPagos = "emitirliquidacion.do";
					}

					//console.log("$esAPPPagos:"+$esAPPPagos);
					obtenerPagos(id);
				  
				  
				  }
				},
			  });
										

});	

$btnDeduccionesAnticipos.on('click', function (e) {
	
	//var importeNeto = $hiddenimporteNeto.val();
	
    //var importeNeto = $montoNetoLC + "";
	var importeNeto = $montoNetoLCSinAnticipos + ""; 
	
	//console.log("importeNeto = $montoNetoLC + :" + importeNeto);
	
	var monto = parseFloat(importeNeto.replace(/,/g, ''));
	
	
	//console.log("float:"+monto);
	
	
	 if(_Items.length==0){
		deducido_importeneto = 0;	
		deducido_suma = 0;		
		bootbox.alert("No ha ingresado ningun item");	
		inicializarDeducidos();
		//$btnDeduccionesAnticipos.prop('disabled', false);
	 }/*else if(monto==0){
		deducido_importeneto = 0;	
		deducido_suma = 0;		
		alert("El comprobante es gratuito, no hay monto que deducir");	
		inicializarDeducidos();
	 }*/else{
		deducido_importeneto = monto;		
		
		//console.log("deducido_importeneto:" + deducido_importeneto);
		
		if(_deducciones_seleccionadas.length==0){
			deducido_suma = 0;
		}		
		$modalDeduccionesAnticipos.modal('show');			 
		 
	}
	
	/*
	if(monto>0){			
		deducido_importeneto = monto;				
		console.log("deducido_importeneto:" + deducido_importeneto);		
		if(_deducciones_seleccionadas.length==0){
			deducido_suma = 0;
		}		
		$modalDeduccionesAnticipos.modal('show');					
	}else{
		deducido_importeneto = 0;	
		deducido_suma = 0;		
		alert("No ha ingresado ningun item");	
		inicializarDeducidos();
	}*/
	
	
	actualizarSaldoDeducciones();

});	

function actualizarSaldoDeducciones(){

	//console.log("valores que llegan");
	//console.log("deducido_importeneto:"+deducido_importeneto);
	//console.log("deducido_suma:"+deducido_suma);
	//console.log("deducido_saldo:"+deducido_saldo);	
	
	
	deducido_importeneto_html.text(parseFloat(deducido_importeneto).toMoney(2));	
	
	deducido_suma_html.text(parseFloat(deducido_suma).toMoney(2));
	
	var tmp_deducido_importeneto = deducido_importeneto + "";
	var tmp_deducido_suma = deducido_suma + "";
	
	deducido_saldo = parseFloat(tmp_deducido_importeneto.replace(/,/g, ''))  - parseFloat(tmp_deducido_suma.replace(/,/g, '')) || 0 ;	
	
	deducido_saldo_html.text(parseFloat(deducido_saldo).toMoney(2));			

	//anticipos = deducido_suma;
	$hiddenanticipos.val(formatoMoneda(deducido_suma));
	
	actualizarResumen();
	
	//console.log("valores que salen");
	//console.log("deducido_importeneto:"+deducido_importeneto);
	//console.log("deducido_suma:"+deducido_suma);
	//console.log("deducido_saldo:"+deducido_saldo);	
	
	
}


$btnVolverBusqueda.on('click', function (e) {
	$modalLiquidacionesAnticipos.modal('hide');			
	//$modalCorreo.modal('show');
});		

var $cerrar = $("#cerrar");

$cerrar.on('click', function (e) {
							  
		var tempSumaItems = $montoNetoLC + "";
		tempSumaItems = parseFloat(tempSumaItems.replace(/,/g, ''));		
		//console.log("tempSumaItems cerrar:"+tempSumaItems);
		//console.log("deducido_suma cerrar:"+deducido_suma);
		
		if(deducido_suma>tempSumaItems){
			
		}else{
			$divListaErroresComplementarios.addClass('hidden');	
		}	
		
		var resultado = validarSiHayDeduccionesCero();
		
		//console.log("resultado:"+resultado);
		if(resultado==0){
			$modalDeduccionesAnticipos.modal('hide');	
		}else{
			bootbox.alert("No se puede agregar anticipos con importe deducido 0");
		}

});		




$openModalLiquidacionesAnticipos.on('click', function (e) {
	oTableLiquidaciones.fnClearTable();
    _liquidaciones_seleccionadas.length=0;
	_temporal.length=0;	
	$modalLiquidacionesAnticipos.modal('show');			
});		


cargarDeduccionesSeleccionadas(null);
function cargarDeduccionesSeleccionadas(data){

	//oTableDeducciones = $tblDeduccionesAnticipo.dataTable( {
	var config_deducciones = {
			responsive: true,
			bProcessing: false,
			bFilter: false,
			bSort: false,
			bAutoWidth: false,
		    retrieve: true, 			
			bLengthChange: false, 
			iDisplayLength: 6,  
			aaData: data,
			language: {
			processing: "Procesando...",
			lengthMenu: "Mostrar _MENU_ registros",
			emptyTable: 'No se encontraron registros',
			zeroRecords: 'No se encontraron registros',
			search: "Buscar:",
			sLoadingRecords: "Cargando...",
			infoFiltered: "(filtrado de un total de _MAX_ registros)",
			info: "Mostrando registros del _START_ al _END_ de un total de _TOTAL_ registros",
			infoEmpty: "Registros del 0 al 0 de un total de 0 registros",
			paginate: {
				"first": "Primero",
				"last": "�ltimo",
				"next": "Siguiente >",
				"previous": "< Anterior"
						}
			},			
			aoColumns: [
						  { "sTitle": "#" },
						  { "sTitle": "serie"},		
						  { "sTitle": "numero"},
						  { "sTitle": "Importe<br>Neto",
						    "mRender": function (data, type, row) {														
								return formatoMoneda(row[3]);
							}
						  },
						  { "sTitle": "Importe<br>Deducido",
						    "mRender": function (data, type, row) {	

							var num_deduccion = row[0];
							var serie = row[1];
							var numero = row[2];							
							var importeneto = row[3];
							var importededucido = row[4];
							var id = row[1]+"_"+row[2];
		
							//ValidarMonto(num_deduccion,serie,numero,neto, deducido)
							  var tTable = "<input id='importededucido_" + id + "' type='text' name='importededucido' value='"+formatoMoneda(importededucido)+"' onkeypress='return SoloNumeroDecimal(event, this);' style='width: 90px; text-align: center;' onChange='ValidarMonto("+num_deduccion+",\""+serie+"\","+numero +","+importeneto+","+importededucido +",this.value)'/'>";					
							  return tTable;
							  }
						  }, 		
						  { "mRender": function (data, type, row) {	
							  var id = row[1]+"_"+row[2];
							  var tTable = "<img class='eliminar' src='/a/imagenes/delete.gif' alt='Eliminar Liquidaci�n con Anticipo' title='Eliminar Liquidaci�n con Anticipo' value='"+id+"'/>";					
							  return tTable;
						  	  }
						  }
						  ]/*,
				 select: {
					style:    'os',
					selector: 'td:first-child'
				},*/
		};
	
	
	//oTableDeducciones = $tblDeduccionesAnticipo.dataTable( {	
	oTableDeducciones = $tblDeduccionesAnticipo.dataTable(config_deducciones);

}


function ValidarMonto(num_deduccion,serie,numero,neto, deducido,valor){

	/*console.log("ValidarMonto");
	console.log("num_deduccion:"+num_deduccion);
	console.log("serie:"+serie);
	console.log("numero:"+numero);
	console.log("neto:"+neto);
	console.log("deducido:"+deducido);	
	console.log("valor:"+valor);		
	*/
	
	if(valor=="") valor = 0;
	
	//console.log("valor:"+valor);	
	var id = serie+"_"+numero;	
	/*console.log("id:"+id);		
	
		
	
	console.log("deducido_importeneto:"+deducido_importeneto);		
	console.log("deducido_suma:"+deducido_suma);
	console.log("deducido_saldo:"+deducido_saldo);	
    */
	
	var sumaTemporal = 0;
	sumaTemporal = parseFloat(deducido_suma) - parseFloat(deducido);
	sumaTemporal = sumaTemporal + parseFloat(valor);
	//console.log("sumaTemporal:"+sumaTemporal);
	
	if(valor>neto){
//		alert("No se puede modificar el monto de esta liquidaci\u00F3n de compra con Anticipo con Serie: "+serie+" y N\u00FAmero: "+numero+", porque supera el importe neto de la Liquidaci\u00F3n de Compra con Anticipo");			
		bootbox.alert("Importe considerado excede el valor del importe de la LC");
		$("#importededucido_"+id).val(formatoMoneda(deducido));	
		$("#importededucido_"+id).focus();
		
		actualizarSaldoDeducciones();
		
		
		
		return;	
	}
	

	if(sumaTemporal>deducido_importeneto){
		
		//alert("No se puede modificar el monto de esta liquidaci\u00F3n de compra con Anticipo con Serie: "+serie+" y N\u00FAmero: "+numero+", porque supera el importe neto de la Liquidaci\u00F3n de Compra");			
		
		bootbox.alert("No puede excederse  del importe en saldo de la LC");
		$("#importededucido_"+id).val(formatoMoneda(deducido));	
		$("#importededucido_"+id).focus();
		
		actualizarSaldoDeducciones();
		return;
	}
	else{
			
		$("#importededucido_"+id).val(formatoMoneda(valor));	
		
		var suma = 0;
		
		//console.log("_deducciones_seleccionadas:")
		$.each(_deducciones_seleccionadas, function( key, obj ) {			  			  
			var _rowArray = [];			
			_rowArray['num_deduccion'] = obj.num_deduccion;
			_rowArray['serie'] = obj.serie;
			_rowArray['numero'] = obj.numero;		
			_rowArray['importeneto'] = obj.importeneto;		
			_rowArray['importededucido'] = obj.importededucido;	
			
			//console.log("serie:"+obj.serie);
			//console.log("numero:"+obj.numero);			
		   
			if(obj.serie==serie && obj.numero == numero){
			  _rowArray['importededucido'] = valor;			
			  //console.log("Entro");
			}	  			  
			//console.log("key:"+key);
			
			_deducciones_seleccionadas.splice(key, 1);
			_deducciones_seleccionadas.splice(key, 0, _rowArray );
			
			//console.log("_rowArray['importededucido']:"+_rowArray['importededucido'])
			
			suma = suma+ parseFloat(_rowArray['importededucido']);
			//console.log("suma:"+suma);
			
		});		
		
		//console.log("suma total:"+suma);

		deducido_suma = parseFloat(suma);
		actualizarSaldoDeducciones();
		actualizarListaDeducciones();
		/*
		console.log("deducido_suma:"+deducido_suma);
		console.log("deducido_saldo:"+deducido_saldo);
		console.log("_deducciones_seleccionadas");
		*/
		
		$.each(_deducciones_seleccionadas, function( key, obj ) {
/*		  console.log( key + ".: " + obj.serie );
		  console.log( key + ".: " + obj.numero );	
		  console.log( key + ".: " + obj.importeneto );
		  console.log( key + ".: " + obj.importededucido );	*/	  
		});	
			
	}//fin else	
	
	
	
}


$formModalLiquidacionesAnticipos.validate(_.extend(window._validatorWallSettings, {
	rules: {
		txtSerieBusqueda: {
		minlength: 4
		},
		txtNumeroBusqueda: {
			number: true,
			maxlength: 8
		},
		selTipoDocumentoBusqueda: {
			required: true
		},
		txtDocumentoBusqueda: {
			number: true,
			minlength: 8
		},
		txtFechaInicioBusqueda: {
			comparaSiFechaInicioMenorIgualFechaFin: ["#txtFechaInicioBusqueda", "#txtFechaFinBusqueda"]
					//restaFechas: ["#txtFechaInicioBusqueda", "#txtFechaFinBusqueda"]
		}
	},
	messages: {
		txtSerieBusqueda: {
		minlength: "La serie ingresada no tiene el formato correcto, solo 4 caracteres"
	},
		txtNumeroBusqueda: {
			number: "El n&uacute;mero de liquidaci&oacute;n de compra debe ser num&eacute;rico de hasta 8 d&iacute;gitos",
			maxlength: "El n&uacute;mero de liquidaci&oacute;n de compra debe ser num&eacute;rico de hasta 8 d&iacute;gitos"
		},
		txtDocumentoBusqueda: {
			number: "El DNI debe ser num&eacute;rico de 8 d&iacute;gitos",
			minlength: "El DNI debe ser num&eacute;rico de 8 d&iacute;gitos"
		},
		selTipoDocumentoBusqueda: {
			required: "Debe seleccionar el tipo de documento del emisor"
		},
		txtFechaInicioBusqueda: {
			comparaSiFechaInicioMenorIgualFechaFin: "La fecha de Inicio debe ser menor o igual que la fecha Fin"
				//restaFechas: "El rango de consulta excede el plazo m&aacute;ximo permitido de 6 meses, seleccione otro rango de consulta"
		}
	},
	submitHandler: function(form) {
		cargarBusquedaLiquidacionesEmitir();
	},invalidHandler: function(event, validator) {
		
		oTableLiquidaciones.fnClearTable();
	    _liquidaciones_seleccionadas.length=0;
		_temporal.length=0;			
	}
}));	



$formModalDeduccionesAnticipos.validate(_.extend(window._validatorWallSettings, {
	rules: {
	},
	messages: {

	},
	submitHandler: function(form) {
		guardarDeducciones();
	}
}));


var $btnGuardarDeducciones = $("#btnGuardarDeducciones");

_.each(_tipoDocumentoIdentidad, function (v, k) {
	$('<option/>', {
		value: k,
		 selected:(k=='1') //1=DNI
	}).html(v).appendTo($selTipoDocumentoBusqueda);
});


function cargarBusquedaLiquidacionesEmitir() {
	var url = $entornoApp+"?action=buscarLiquidacionesAnticipo";
	$modalPreloader.modal('show');

	var data = $formModalLiquidacionesAnticipos.serializeObject();

	$.post(url, data).success(function(response) {
		var data = response.retorno;
		var lista = data.lista;
		$tblLiquidacionesAnticipo.DataTable().clear();
		$tblLiquidacionesAnticipo.DataTable().destroy();
		//console.log("lista.length:"+lista.length)
		if (lista.length != 0) {
			
			cargarLiquidacionesAnticipoEmitir(lista);
			$tblLiquidacionesAnticipo.DataTable().columns.adjust().responsive.recalc();
			if(isMobile.Android() ){
				$tblLiquidacionesAnticipo.css({"width": "350px"});
			}
		} else {
			bootbox.alert("No se encontraron resultados");
		}
		$modalPreloader.modal('hide');
	}).error(function(reason) {
		$modalPreloader.modal('hide');
		bootbox.alert('Disculpe, su producto no ha podido ser eliminado, intentelo nuevamente.');
	});
}	


cargarLiquidacionesAnticipoEmitir(null);
function cargarLiquidacionesAnticipoEmitir(lista) {
	
/*	console.log("cargarLiquidacionesAnticipoEmitir: _deducciones_seleccionadas");	
		$.each(_deducciones_seleccionadas, function( key, obj ) {
		  console.log( key + ".: " + obj.serie );
		  console.log( key + ".: " + obj.numero );	
		  console.log( key + ".: " + obj.importeneto );
		  console.log( key + ".: " + obj.importededucido );		  
		});	*/	

/*	console.log("cargarLiquidacionesAnticipoEmitirlista");
	
	//valida que no se vuelvea a repetir las ya seleccionads
	if (_deducciones_seleccionadas != null) {		
		$.each(_deducciones_seleccionadas, function( key2, obj ) {
		  console.log("_deducciones_seleccionadas "+ key2 + ".: " + obj.serie );
		  console.log("_deducciones_seleccionadas "+ key2 + ".: " + obj.numero );			  
		  
			if (lista != null) {
				var sw =0 ;
				var posicion = 0;
				$.each(lista, function( key, objeto ) {					  
					  if(objeto.numseriegre==obj.serie && objeto.numgre==obj.numero){
						sw = 1;
						posicion = key;
						return true;
					  }											
				});		
				
				if(sw==1){					
					lista.splice(posicion, 1);						
				}								
			}
		  
		});	
	}*/


	

	var config_liquidaciones = {	
		responsive: true,
		bProcessing: false,
		bFilter: false,
		bSort: false,
		bAutoWidth: false,
		retrieve: true,		
		order: [],
		language: {
		processing: "Procesando...",
		lengthMenu: "Mostrar _MENU_ registros",
		emptyTable: 'No se encontraron registros',
		zeroRecords: 'No se encontraron registros',
		search: "Buscar:",
		sLoadingRecords: "Cargando...",
		infoFiltered: "(filtrado de un total de _MAX_ registros)",
		info: "Mostrando registros del _START_ al _END_ de un total de _TOTAL_ registros",
		infoEmpty: "Registros del 0 al 0 de un total de 0 registros",
		paginate: {
			"first": "Primero",
			"last": "�ltimo",
			"next": "Siguiente >",
			"previous": "< Anterior"
		}
	},
	data: lista,
	columns: [

	          {
	        	  data: function(row, type, val, meta) {
					//onclick='incluir(" + nombreCheck + ");'
	        	  var nombreCheck = row.numseriegre+row.numgre;
	        	  return "<input id='"+nombreCheck+"' name='checkLiquidaciones'  value='"+nombreCheck+"' type='checkbox' />";
	          },
	          sClass: 'text-center'
	          },				  
	          {
	        	  data: function(row, type, val, meta) {
	        	  return row.numseriegre;
	          },
	          sClass: 'text-center'
	          },
	          {
	        	  data: function(row, type, val, meta) {
	        	  return row.numgre;
	          },
	          sClass: 'text-left'
	          },
	          {
	        	  data: function(row, type, val, meta) {
	        	  return row.codmoneda;
	          },
	          sClass: 'text-left'
	          },			
	          {
	        	  data: function(row, type, val, meta) {
	        	  return formatoMoneda(row.mtosaldo);
	          },
	          sClass: 'text-left',
	          sTitle: "Importe<br>Neto"
	          },			
	          {
	        	  data: function(row, type, val, meta) {
	        	  return (row.fecemision.substr(8, 2) + "/" + row.fecemision.substr(5, 2) + "/" + row.fecemision.substr(0, 4));
	          },
	          sClass: 'text-left',
	          sTitle: "Fecha<br>Emisi&oacute;n"
	          }
	          ],
	          searching: false,
	          bLengthChange: false,
	          "pageLength": 5
	};										 

    oTableLiquidaciones = $tblLiquidacionesAnticipo.dataTable(config_liquidaciones);
	
}


$(document).on('click', '.eliminar',function (e) {
//		console.log("eliminando 4:"+$(this).attr("value"));		
		
		var id = $(this).attr("value");
		var array =id.split("_");
		serie = array[0];
		numero = array[1];

		//console.log("serie a elimnar:"+serie);
		//console.log("numero a elimnar:"+numero);
		
		//console.log("_deducciones_seleccionadas:")
		var sw = 0;
		$.each(_deducciones_seleccionadas, function( key, obj ) {			  			  
			var _rowArray = [];			
			_rowArray['num_deduccion'] = obj.num_deduccion;			
			_rowArray['serie'] = obj.serie;
			_rowArray['numero'] = obj.numero;		
			_rowArray['importeneto'] = obj.importeneto;		
			_rowArray['importededucido'] = obj.importededucido;	
			
			//console.log("serie:"+obj.serie);
			//console.log("numero:"+obj.numero);			
		   
			if(obj.serie==serie && obj.numero == numero){
	
			    //console.log("Entro");
			  
				_deducciones_seleccionadas.splice(key, 1);			  
			
				deducido_suma = parseFloat(deducido_suma) - parseFloat(obj.importededucido);				
				actualizarSaldoDeducciones();
				
				sw=1;
				
			}	  	
			if(sw==1) return false;
			
		});		

		actualizarListaDeducciones()				
 });	


 function actualizarListaDeducciones(){	 
 
 	//$btnDeduccionesAnticipos.html("Deducciones de anticipos ("+_deducciones_seleccionadas.length+")");	 
	var cadena = "";
	var i = 1;
	
	$btnDeduccionesAnticipos.html("Deducciones de anticipos ("+_deducciones_seleccionadas.length+")");
	$hiddenHelperDeduccionesAnticipos.val(_deducciones_seleccionadas.length);
	
	//console.log("_deducciones_seleccionadas");
/*	$.each(_deducciones_seleccionadas, function( key, obj ) {
	  console.log( key + "num_deduccion: " + obj.num_deduccion );												
	  console.log( key + "serie:" + obj.serie );
	  console.log( key + "numero: " + obj.numero );	
	  console.log( key + "importeneto: " + obj.importeneto );
	  console.log( key + "importededucido: " + obj.importededucido );		  
	});	*/
		
		
	$.each( _deducciones_seleccionadas, function( key, obj ) {																			
		cadena = cadena + '{ "num_deduccion": "'+ obj.num_deduccion +'", "serie": "'+obj.serie+'", "numero": "'+obj.numero+'", "importeneto": "'+obj.importeneto+'", "importededucido":"'+obj.importededucido+'" },';
		i++;	  
	});	
	
	cadena = cadena.substring(0, cadena.length-1);			
	cadena = "["+ cadena + "]";	
	
	//console.log("cadena:"+cadena);

	var obj = jQuery.parseJSON(cadena);
	
	var data = jQuery.map(obj, function(el, i) {
	  return [[el.num_deduccion, el.serie, el.numero, el.importeneto,el.importededucido]];
	});	
	
	if(oTableDeducciones!=null){
		oTableDeducciones.dataTable().fnDestroy();
	}
	
	cargarDeduccionesSeleccionadas(data);
	 
 }





var _temporal= [];	
$('#tblLiquidacionesAnticipo tbody').on('click', 'input[type="checkbox"]', function(e){
																							
	//console.log("clikando")																					
	var $row = $(this).closest('tr');

	//get data de la fila
	var data = oTableLiquidaciones.api().row($row).data();
	//get id de la fila
	
	var id = data.numseriegre+"_"+data.numgre+"_"+data.mtosaldo;
//	console.log("id:"+id);
	var rowId = id; //var rowId = data[0]; (el rowid tiene el num_opcion)
	
	
	var _rowArray = [];
	
	_rowArray['serie'] = data.numseriegre;
	_rowArray['numero'] = data.numgre;		
	_rowArray['importeneto'] = data.mtosaldo;				
	_rowArray['importededucido'] = data.mtosaldo;						
	

	//Determinar si la fila de identificaci�n se encuentra en la lista de ID de fila seleccionados	  
	var index = $.inArray(rowId, _temporal);
	//console.log("index:"+index);
	//Si la casilla est� marcada y la fila ID no est� en la lista de los ID de fila seleccionados
	if(this.checked && index === -1){
		_temporal.push(rowId);
		_liquidaciones_seleccionadas.push(_rowArray);
		//verificaCpDuplicadoOpcion(rowId); //le envio el num_opcion
		//alert ("1"); //la selecciono por primera vez
		//si la casilla de verificaci�n no est� marcada y la fila de identificaci�n se encuentra en la lista de los ID de fila seleccionados
	} else if (!this.checked && index !== -1){			
		_liquidaciones_seleccionadas.splice(index, 1);
		_temporal.splice(index, 1);
		//alert ("2"); //la selecciono por segunda vez para deseleccionar
	}

	if(this.checked){
		$row.addClass('selected');			
	} else {
		$row.removeClass('selected');
	}
	
	// Prevent click event from propagating to parent
	e.stopPropagation();
});		


function validarSiEstaListaDeducciones(serie,numero){

	  //console.log("validarSiEstaListaDeducciones serie "+ serie );
	  //console.log("validarSiEstaListaDeducciones numero "+ numero );	

	var sw = 0;
	//valida que no se vuelvea a repetir las ya seleccionads
	if (_deducciones_seleccionadas != null) {		
	
		$.each(_deducciones_seleccionadas, function( key2, obj ) {
													
		  //console.log("_deducciones_seleccionadas "+ key2 + ".: " + obj.serie );
		  //console.log("_deducciones_seleccionadas "+ key2 + ".: " + obj.numero );		
		  
		  if($.trim(obj.serie)==$.trim(serie) && $.trim(obj.numero)==$.trim(numero)){			  
			  //console.log("retorno1");
			  sw = 1;
		  }		
		  
		 if(sw==1) return false;
		  
		});
	}
	
	 if(sw==1) { return true;}
	 else{ 	return false; } 

}


$btnIncluirLiquidaciones.on('click', function (e) {					   

	jsonObj = [];
	var i = 1;
	var cadena = "";
	
		//console.log("_liquidaciones_seleccionadas");
		
		var mensajeError= "";
		$.each( _liquidaciones_seleccionadas, function( key, obj ) {
/*		  console.log( key + ".: " + obj.serie );
		  console.log( key + ".: " + obj.numero );	
		  console.log( key + ".: " + obj.importeneto );
		  console.log( key + ".: " + obj.importededucido );		*/
		  
		  var encuentra = validarSiEstaListaDeducciones(obj.serie,obj.numero);
		  
//		  console.log("encuentra:"+encuentra);
		  if(!encuentra){
			  
				var _rowArray = [];			
				_rowArray['num_deduccion'] = _deducciones_seleccionadas.length + 1;			
				_rowArray['serie'] = obj.serie;
				_rowArray['numero'] = obj.numero;		
				_rowArray['importeneto'] = obj.importeneto;			
				
				
				//console.log("deducido_saldo:"+deducido_saldo);
				//console.log("obj.importededucido:"+obj.importededucido);				
				if(deducido_saldo>obj.importededucido){				
					_rowArray['importededucido'] = obj.importededucido;		
				}else{
					_rowArray['importededucido'] = deducido_saldo;		
				}
				
				//console.log("_rowArray['importededucido']:"+_rowArray['importededucido']);				
				
	
				//var suma = 0;			
				//suma = parseFloat(deducido_suma) + parseFloat(_rowArray['importededucido']);
				
				//if(suma>deducido_importeneto){
					//mensajeError = mensajeError + "No se puede agregar la Liquidaci\u00F3n de compra con Anticipo con Serie: "+obj.serie+" con N\u00FAmero: "+obj.numero+", porque supera el importe neto de la Liquidaci\u00F3n de Compra\n";
				//}else{
					_deducciones_seleccionadas.push(_rowArray);							
					deducido_suma = parseFloat(deducido_suma) + parseFloat(_rowArray['importededucido']);					
				//}	
				
				//console.log("deducido_suma:"+deducido_suma);
				
				actualizarSaldoDeducciones();
			  
		   }else{
			   mensajeError = mensajeError + "La deducci\u00F3n de anticipo con Serie: "+obj.serie+" con N\u00FAmero: "+obj.numero+" ya fue agregada\n";
		   }


		});	
		
		
		if(mensajeError!=""){
			bootbox.alert(mensajeError);
		}
		
		//console.log("deducido_suma btnIncluirLiquidaciones:"+deducido_suma);
		//console.log("deducido_saldo btnIncluirLiquidaciones:"+deducido_saldo);
		
		//actualizarSaldoDeducciones();
		
		//deducido_suma_html.text(formatoMoneda(deducido_suma));
		//deducido_saldo_html.text(formatoMoneda(deducido_saldo));	
		
		actualizarListaDeducciones();
		$modalLiquidacionesAnticipos.modal('hide');	
		
});



function actualizarItemsAnticipo(accion){	

	var tempo = _Items;
	//console.log("accion:"+accion);
	
	_.each(tempo, function (obj, key) {					 
			
		var _rowArray = [];		
		_rowArray['txtCantidad'] = obj.txtCantidad;
		_rowArray['selUnidadMedida'] = obj.selUnidadMedida;
		_rowArray['txtCodigo'] = obj.txtCodigo;		
		_rowArray['txtCodigoUsuario'] = obj.txtCodigoUsuario;		
		_rowArray['txtValorUnitario'] = obj.txtValorUnitario;
		_rowArray['selTipoIgv'] = obj.selTipoIgv;
		_rowArray['txtIGV'] = obj.txtIGV;		
		_rowArray['selTipoAfectacionIR'] = obj.selTipoAfectacionIR;		
		_rowArray['selPorcentajeIR'] = obj.selPorcentajeIR;	
		_rowArray['txtRetencion'] = obj.txtRetencion;		
		_rowArray['txtImporte'] = obj.txtImporte;
		
		var descripcion = obj.txtDescripcion;		
		
		//console.log("actualizarItemsAnticipo Descripcion:"+descripcion);
		
		if(accion=="agregar"){		
		
			//console.log("actualizarItemsAnticipo indexof 1:"+descripcion.indexOf("***Pago Anticipado***"));
			//console.log("actualizarItemsAnticipo indexof 2:"+descripcion.indexOf("***PAGO ANTICIPADO***"));
			
			 if(descripcion.indexOf("***Pago Anticipado***") == -1 && descripcion.indexOf("***PAGO ANTICIPADO*** ") == -1){
				 descripcion = $.trim(descripcion) + " ***Pago Anticipado***";								 
			 }
		}else if(accion=="quitar"){
			descripcion = descripcion.replace(" ***Pago Anticipado***","");
		}
		
		_rowArray['txtDescripcion'] = descripcion;	
			
		_Items.splice(key, 1);
		_Items.splice(key, 0, _rowArray);		


	});		
	
	
	
	recorrerItems();

}


$btnDeduccionesAnticipos.prop('disabled', true);
$('input[type=radio][name=rdoAnticipos]').on('change, click', function() {
	//console.log("cambiando");	
																	   
		 switch($(this).val()) {
			 case '0':			 
				 
				 if(_Items.length>0){ actualizarItemsAnticipo("agregar"); }
				 
				 
				 if(_deducciones_seleccionadas.length>0){
					 
						if(!confirm('Ya tiene liquidaciones de Anticipos cargados para esta LC. \u00BFEsta seguro de eliminarlos?')){
							//$("#rdoAnticipos_1").attr('checked', 'checked');
							$("#rdoAnticipos_1").prop("checked", true)
							 $btnDeduccionesAnticipos.prop('disabled', false);
							return;
						}else{			//si elige eliminar
							$btnDeduccionesAnticipos.prop('disabled', true);
							inicializarDeducidos();							
							actualizarResumen();							 														
							//$btnDeduccionesAnticipos.html("Deducciones de anticipos ("+_deducciones_seleccionadas.length+")");
						}						
				 }else{
					 $btnDeduccionesAnticipos.prop('disabled', true);
				 }
				 
				 break;
			 case '1':				 
 				 if(_Items.length>0){ actualizarItemsAnticipo("quitar"); }
 				 $btnDeduccionesAnticipos.prop('disabled', false);
				 break;
		 }
});	



//Pantalla flotante de calendario de busqueda de inicio
var $modalDatepickerInicio = $('#modal-datepickerInicio');
var $datepickerInicio = $modalDatepickerInicio.find("#datepickerInicio-placeholder");
var $datepickerHiddenInicio = $modalDatepickerInicio.find("#datepickerInicio-value");
var $btnCloseDatepickerInicio = $modalDatepickerInicio.find('#modal-datepickerInicio-close')

var _CURR_DATE_PICKERInicio = null;
$('.datepickerInicio').on('click', function(e) {
	_CURR_DATE_PICKERInicio = $(e.target);
	$modalDatepickerInicio.modal('show');
});

$datepickerInicio.datepicker({
	// endDate: new Date(),
	endDate: '0d'//,
		//startDate: '-2d'
		//maxDate:'1'
}).on('changeDate', function(e) {
	$datepickerHiddenInicio.val(e.format());
	cerrandoCalendarioInicio();
});

function cerrandoCalendarioInicio(){
	//console.log("$datepickerHidden.val():"+$datepickerHidden.val());									 		
	if($datepickerHiddenInicio.val()!=""){
		var selectedDate = $datepickerHiddenInicio.val();
		_CURR_DATE_PICKERInicio.val(selectedDate).trigger('change');
		$datepickerHiddenInicio.val('');
		_CURR_DATE_PICKERInicio = null;
		$modalDatepickerInicio.modal('hide');
	}else{
		bootbox.alert("Haga click en la fecha deseada");	
	}
}


$btnCloseDatepickerInicio.on('click', function(e) {
	cerrandoCalendarioInicio();											   
});		

$('#butoncalendar1').on('click', function(e) {
	_CURR_DATE_PICKERInicio = $(".datepickerInicio");
	$modalDatepickerInicio.modal('show');
});	




//Pantalla flotante de calendario de busqueda de fin
var $modalDatepickerFin = $('#modal-datepickerFin');
var $datepickerFin = $modalDatepickerFin.find("#datepickerFin-placeholder");
var $datepickerHiddenFin = $modalDatepickerFin.find("#datepickerFin-value");
var $btnCloseDatepickerFin = $modalDatepickerFin.find('#modal-datepickerFin-close')

var _CURR_DATE_PICKERFin = null;
$('.datepickerFin').on('click', function(e) {
	_CURR_DATE_PICKERFin = $(e.target);
	$modalDatepickerFin.modal('show');
});

$datepickerFin.datepicker({
	// endDate: new Date(),
	endDate: '0d'//,
		//startDate: '-2d'
		//maxDate:'1'
}).on('changeDate', function(e) {
	$datepickerHiddenFin.val(e.format());
	cerrandoCalendarioFin();
});

function cerrandoCalendarioFin(){
	

	//console.log("$datepickerHidden.val():"+$datepickerHidden.val());									 		
	if($datepickerHiddenFin.val()!=""){
		var selectedDate = $datepickerHiddenFin.val();
		_CURR_DATE_PICKERFin.val(selectedDate).trigger('change');
		$datepickerHiddenFin.val('');
		_CURR_DATE_PICKERFin = null;
		$modalDatepickerFin.modal('hide');
	}else{
		bootbox.alert("Haga click en la fecha deseada");	
	}	
	
}


$btnCloseDatepickerFin.on('click', function(e) {
	cerrandoCalendarioFin();											
});		

$('#butoncalendar2').on('click', function(e) {
	_CURR_DATE_PICKERFin = $(".datepickerFin");
	$modalDatepickerFin.modal('show');
});	


function validarSiHayDeduccionesCero(){

	var sw = 0;
	$.each(_deducciones_seleccionadas, function( key, obj ) {			  
												
		var id = obj.serie+"_"+obj.numero;	

		//console.log("validarSiHayDeduccionesCero id:"+id);																							
		//console.log("validarSiHayDeduccionesCero monto:"+obj.importededucido);												
		if(obj.importededucido==0 && sw==0){
			sw = 1;
			$("#importededucido_"+id).focus();																										
		}				
		//console.log("sw:"+sw);														
	});		
	
	return sw;
}



///**********************************************************************************************//
///**********************************************************************************************//
///***********************FIN SEGUNDA FASE DE LA LIQUIDACI�N ELETR�NIOCA ASOCIAR LIQUIDACION DE PAGO CON ANTICIPO*****************************//
///**********************************************************************************************//
///**********************************************************************************************//
///**********************************************************************************************//





///**********************************************************************************************//
///**********************************************************************************************//
///***********************TERCERA FASE DE LA LIQUIDACI�N ELETR�NIOCA ASOCIAR LIQUIDACION DE PAGO CON ANTICIPO*****************************//
///**********************************************************************************************//
///**********************************************************************************************//
///**********************************************************************************************//


//Emision Electr�nica = 1
//Registro de pagos Fisica  = 2

var $RegistroFisico = $("#RegistroFisico");
var $txtSerieFisico = $("#txtSerieFisico");
var $txtNumeroFisico = $("#txtNumeroFisico");
var $labelTituloEmision = $("#labelTituloEmision");
var $errorSerie = $("#errorSerie");
var $errorNumero = $("#errorNumero");

	//console.log("tipoEmision:"+$tipoComprobante.val());	
	
	if($tipoComprobante.val()==1){//Eletronico		
		$RegistroFisico.addClass('hidden');			
		$labelTituloEmision.text("Emisi\u00F3n de Liquidaci\u00F3n de Compra Electr\u00F3nica");
                $btnEmitirFactura.text("Emitir Liquidaci\u00F3n de Compra");
		$btnEmitirNuevo.text("Emitir Nuevo");
	}else if($tipoComprobante.val()==2){//fisico	
		$RegistroFisico.removeClass('hidden');			
		$labelTituloEmision.text("Registro de Liquidaci\u00F3n de Compra F\u00EDsica");
                $btnEmitirFactura.text("Registrar Liquidaci\u00F3n de Compra");
		$btnEmitirNuevo.text("Registrar Nuevo");
	}else{
		$RegistroFisico.removeClass('hidden');			
		$labelTituloEmision.text("Registro de Liquidaci\u00F3n de Compra");
                $btnEmitirFactura.text("Registrar Liquidaci\u00F3n de Compra");
		$btnEmitirNuevo.text("Registrar Nuevo");
	}


	$errorSerie.addClass('hidden');	
	$errorNumero.addClass('hidden');	

	$txtSerieFisico.blur(function() {
/*		console.log("$txtSerieFisico.val():"+$txtSerieFisico.val());
		
		console.log("$txtSerieFisico.val().length:"+$txtSerieFisico.val().length);
		if($txtSerieFisico.val().length<4){
			$errorSerie.removeClass('hidden');
			$errorSerie.text("Serie del la LC F\u00EDsica es de 4 d\u00EDgitos");
		}else{
			$errorSerie.text("");
			$errorSerie.addClass('hidden');	
		}
			
*/	});
	
	$txtNumeroFisico.blur(function() {
		//console.log("$txtNumeroFisico.val():"+$txtNumeroFisico.val());
		//validarSerieNumero();
		$txtNumeroFisico.val(completarPatron ($txtNumeroFisico.val(), 8, 0));
	});	

 var $divListaErroresOperacion = $("#div-lista-errores-operacion");
 
 function validarSerieNumero(){
		 
		//console.log("$entornoApp:"+$entornoApp);		 
        var url = $entornoApp+'?action=validarSerieNumero'; 			
		var formData = {	txtSerieFisico: $txtSerieFisico.val(),
							txtNumeroFisico: $txtNumeroFisico.val()
		};
		
		var estado = 1;
		
      $.ajax({
        url: url,
        type: "POST",
        data: formData,
        dataType: 'json',
        success: function(data) {			
		
		$divListaErroresOperacion.addClass('hidden');
		
         if (data.estado == '1') {
			//$errorNumero.removeClass('hidden');
			//$errorNumero.text("El par Serie n\u00FAmero no est\u00E1 dentro de un rango autorizado");				
			$txtSerieFisico.focus();
			//alert("El par serie n\u00FAmero no est\u00E1 dentro de un rango autorizado");		
			
			$divListaErroresOperacion.removeClass('hidden');
			$divListaErroresOperacion.html('<div class="alert alert-danger"><li><span class="error" style="display: inline;">El par Serie n\u00FAmero no est\u00E1 dentro de un rango autorizado</span></li></div>');			
			
			estado =  0;
			return;
         }
		 
         if (data.estado == '2') {
			//$errorNumero.removeClass('hidden');
			//$errorNumero.text("El comprobante fue previamente registrado");				
			$txtSerieFisico.focus();
			//alert("El comprobante fue previamente registrado");				
			$divListaErroresOperacion.removeClass('hidden');
			$divListaErroresOperacion.html('<div class="alert alert-danger"><li><span class="error" style="display: inline;">El comprobante fue previamente registrado</span></li></div>');						
			
			estado = 0;
			return;
         }
		 

         if (data.estado == '3') {		
			$txtSerieFisico.focus();			
			$divListaErroresOperacion.removeClass('hidden');
			$divListaErroresOperacion.html('<div class="alert alert-danger"><li><span class="error" style="display: inline;">El par Serie n\u00FAmero no est\u00E1 dentro de un rango disponible</span></li></div>');						
			
			estado = 0;
			return;
         }			 
		 
         if (data.estado == '4') {		
			$txtSerieFisico.focus();			
			$divListaErroresOperacion.removeClass('hidden');
			$divListaErroresOperacion.html('<div class="alert alert-danger"><li><span class="error" style="display: inline;">El par Serie n\u00FAmero ha sido dado de baja por la opci\u00F3n de contingencia</span></li></div>');						
			
			estado = 0;
			return;
         }
		 
		 if (data.estado == '5') {		
			$txtSerieFisico.focus();			
			$divListaErroresOperacion.removeClass('hidden');
			$divListaErroresOperacion.html('<div class="alert alert-danger"><li><span class="error" style="display: inline;">El comprobante contiene pagos registrados</span></li></div>');						
			
			estado = 0;
			return;
         }
				
			//console.log("$fechaLimiteEmitir.val():"+$fechaLimiteEmitir.val());
			//console.log("$$txtFechaEmision.val().val():"+$txtFechaEmision.val());			
			
			var d = new Date();
			var strDate = d.getDate() + "/" + (d.getMonth()+1) + "/" + d.getFullYear();
			//var d = new Date($txtFechaEmision.val());
		     //alert(sumarDias(d, 6));
			var fechaLimite = sumaFecha(7, $txtFechaEmision.val())
			
			//console.log("strDate:"+strDate);
			//console.log("fechaLimite:"+fechaLimite);
			
			if(!comparaSiFechaInicioMenorIgualFechaFin(strDate, fechaLimite))
			{
					if(!confirm('Recuerde que el registro se podr\u00E1 realizar como plazo m\u00E1ximo hasta el s\u00E9timo d\u00EDa calendario siguiente de la fecha de emisi\u00F3n, \u00BFEsta seguro de continuar con la fecha seleccionada?')){	
					$txtFechaEmision.val(fecha);
					return;
					}
					showPreview();	
			}else{
					showPreview();		
			}
			

		  
		//$errorNumero.text("");
		//$errorNumero.addClass('hidden');	
		//	return 1;

        },
		
        error: function () {
          bootbox.alert('error');		  
  		  $txtDocumento.val("");
        },
        complete: function () {
			//console.log("complete:"+estado)
			
			if(estado==1){
				//return "1";//showPreview();
			}
        }
      });
	  
	  //console.log("al salir:"+estado)
	  
	  //return estado;
	  
    }	
	
	
	
	


//	$txtDocumentoBusqueda.val("06017889");
//	$txtFechaInicioBusqueda.val("01/09/2017");
//	$txtFechaFinBusqueda.val("13/11/2017");
//	$txtDocumento.val("04023429");
//	$txtValorUnitario.val(100);

establecerValoresIniciales();

if(isMobile.iOS() ){
	//$("#container2").css({"width": "100%"});
	
	   $("#modal-deduccionesAnticipos").css({"width": window.screen.width});
	   $("#modal-liquidacionesAnticipos").css({"width": window.screen.width});	   
	   $("#modal-pagos").css({"width": window.screen.width});	   	   
	   
	   
	   //$(".modal").css({"width": window.screen.width});        
	   //$(".th").css({"width": "10%"});  
	   
	   //$(".wrapper-content").css({"padding": "20px 10px 20px 0px"});              
	   //$(".wrapper").css({"padding": "0px 20px 0px 0px"});
	
}




function recorrerItems(){
	
	/*console.log("recorrerItems");
	
		$.each(_Items, function( key, obj ) {		
								
			console.log("txtCantidad:"+obj.txtCantidad);
			console.log("selUnidadMedida:"+obj.selUnidadMedida);
			console.log("txtCodigo:"+obj.txtCodigo);			
			console.log("txtCodigoUsuario:"+obj.txtCodigoUsuario);
			console.log("txtValorUnitario:"+obj.txtValorUnitario);
			console.log("selTipoIgv:"+obj.selTipoIgv);			
			console.log("txtIGV:"+obj.txtIGV);
			console.log("selTipoAfectacionIR:"+obj.selTipoAfectacionIR);
			console.log("selPorcentajeIR:"+obj.selPorcentajeIR);			
			console.log("txtRetencion:"+obj.txtRetencion);
			console.log("txtImporte:"+obj.txtImporte);
			console.log("txtDescripcion:"+obj.txtDescripcion);			
			
		 });	*/	
	
}



///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
	////10/10/2019
	$txtDocumento.attr('class','form-control input-number');	
	$txtRazonSocial.attr('disabled', 'disabled');	
	$txtDocumento.attr('maxlength','8');
	$("#opcvendedor_0").prop("checked", true);
	$divBloqueDireccionDNI.removeClass('hidden');	
	
	
	

	$selTipoDocumento.on('change', function(e){											   
		//console.log("$selTipoDocumento.val():"+$selTipoDocumento.val());	
		$txtDocumento.val("");	
		$txtRazonSocial.val("");	
		
		if($selTipoDocumento.val()=="1"){
			//console.log("aqui 1");
			$txtDocumento.attr('maxlength','8');
			$txtRazonSocial.attr('disabled','disabled');
			$("#opcvendedor_0").prop("checked", true);				
			$divBloqueDireccionDNI.removeClass('hidden');	
						
		}else if($selTipoDocumento.val()=="4"){
			//console.log("aqui 4");
			$txtDocumento.attr('maxlength','12');
			$txtRazonSocial.attr("disabled",false);
			$("#opcvendedor_1").prop("checked", true);
			$divBloqueDireccionDNI.addClass('hidden');
		
		}else if($selTipoDocumento.val()=="7"){
			//console.log("aqui 7");
			$txtDocumento.attr('maxlength','12');
			$txtRazonSocial.attr("disabled",false);
			$("#opcvendedor_1").prop("checked", true);
			$divBloqueDireccionDNI.addClass('hidden');
			
		}				
		
    });	
	
	$('.input-number').on('input', function () { 
	
		if($selTipoDocumento.val()=="1"){
			//console.log("en metodo 1");
			this.value = this.value.replace(/[^0-9]/g,'');
		}else{
			var regex = new RegExp("^[a-zA-Z0-9 ]+$");
			//console.log("en metodo 2");
		    var key = String.fromCharCode(!event.charCode ? event.which : event.charCode);
		    if (!regex.test(key)) {
			  event.preventDefault();
			 return false;
		 }
			
		}	
    });
	
	
		
	
	
function validarMontoUIT(){
		 
		//console.log("$entornoApp:"+$entornoApp);		 
        var url = $entornoApp+'?action=validarMontoUIT'; 			
		var formData = {	tipoDocumento: $selTipoDocumento.val(),
							numeroDocumento: $txtDocumento.val(),
							fechaEmision: $txtFechaEmision.val()
		};
		
		var estado = 1;
		
      $.ajax({
        url: url,
        type: "POST",
        data: formData,
        dataType: 'json',
        success: function(data) {			
		
			$monto_uit = data.monto_uit;
			$monto_emitido = data.monto_emitido;
			numeroUIT = data.numeroUIT;
			valorActualDolar = data.valorActualDolar;	
			
			/*
			console.log("en metodo ajax")
			console.log('montoNetoLC:'+$montoNetoLC);
			console.log('monto_uit:'+$monto_uit);
			console.log('monto_emitido 1:'+$monto_emitido);
			console.log('montoVentaLC:'+$montoVentaLC);
			console.log('valorActualDolar:'+valorActualDolar);			
			*/
			

        },
		
        error: function () {
          bootbox.alert('error');		  
  		  $txtDocumento.val("");
        },
        complete: function () {
			//console.log("complete:"+estado)			
			if(estado==1){
				//return "1";//showPreview();
			}
        }
      });
	  
	  //console.log("al salir:"+estado)	  
	  //return estado;
	  
    }	
	