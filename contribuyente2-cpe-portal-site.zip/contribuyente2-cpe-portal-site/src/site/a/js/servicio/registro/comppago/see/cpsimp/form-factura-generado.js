// (function(window, $, _) {
    /*
     * :::: CONTAINERS :::: START
     */


 var $form = $("#form-email");

var $email=$("#txtEmail");



    /*
   	*  :::: CONTAINERS :::: END
   	*/

   	/*
   	*  :::: HELPERS :::: START
   	*/

   	/*
   	*  :::: HELPERS :::: END
   	*/

   	/*
   	*  :::: FUNCTION :::: START
   	*/

   $('.footable').footable();
   	/*
   	*  :::: FUNCTION :::: END
   	*/

   	/*
   	*  :::: SETUP :::: START
   	*/

    $form.validate(_.extend(window._validatorWallSettings, {
        debug: false,
        rules: {
            txtEmail: {
                required: true,
                email: true
            }
        },
       
        submitHandler: function(form) {
           
          var formData=$(form).serializeObject();
          var url = 'emitirfesimp.do?action=enviarCorreo';
            $.ajax({
              method: 'post',
              data: formData,
              url:url,
              success: function (data) {
              alert('Envio Satisfactorio');
              },

              error: function() {

                alert('Ocurrio un error intentelo en unos minutos');

              }



            })

            
        }
    }));




// })(window, jQuery, _);