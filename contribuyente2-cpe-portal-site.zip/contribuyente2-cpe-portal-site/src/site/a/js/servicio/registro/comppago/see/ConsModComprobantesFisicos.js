/**
 * ConsModComprobantesFisicos.js - JavaScript de consultas, modificaciones y bajas de comprobates de pago f�sico.
 * Author: Patricia Chacaliaza
 * Fecha: 20-11-2011
 * ResponseBean : codeError; messageError; data;
 */
if (!dojo._hasResource["servicio.registro.comppago.see.ConsModComprobantesFisicos"]) {
    dojo._hasResource["servicio.registro.comppago.see.ConsModComprobantesFisicos"] = true;
    dojo.provide("servicio.registro.comppago.see.ConsModComprobantesFisicos");
    
    dojo.require("dojo.data.ItemFileWriteStore");
    dojo.require("dojo.io.iframe");
    
    dojo.declare("servicio.registro.comppago.see.ConsModComprobantesFisicos", null, {
    	store: null,       
        controller: "mantcpfisicos.do",
		beanCPFisico: null,
		bModificando : false,
        
        constructor: function(){
        },
        
        initialize: function(){
    		this.content = dijit.byId("content");    		
            this.waitMessage = dijit.byId("waitMessage");
            this.dialogCP = dijit.byId("dialogCP");
        },
        
        startup: function(){
            dojo.parser.parse(dojo.byId('container'));
            setTimeout(dojo.hitch(this, function(){
                this.hideLoader();
            }), 250);
        },
        
        hideLoader: function(){
            this.initialize();
            var loader = dojo.byId('loader');
            var _this = this;
            dojo.fadeOut({
                node: loader,
                duration: 250,
                onEnd: function(){
                	dijit.byId('content').domNode.style.visibility = "visible";            	
                    loader.style.display = "none";
                }
            }).play();
        },
         
        initContent: function(){
            /*Nada al cargar el formulario*/
        	this.store = null;
			//art
		this.initialize();
			//dijit.byId("criterio.periodo").focus();
        },  	
    	

		
		// MPCR Inicio
    	showDialogItem: function(rowIndex) {
              dijit.byId("itemCP.idCP").setValue( "");
              dijit.byId("itemCP.ultimoDiaPeriodo").setValue( "");
              
  						dijit.byId("itemCP.periodoRegistroVentas").setValue("");
  						dijit.byId("itemCP.periodoAjuste").setValue("");
  						dijit.byId("itemCP.cuo").setValue("");
              dijit.byId("itemCP.numeroCorrelativo").setValue("");
  						dijit.byId("itemCP.numeroDocRecepCP").setValue("");
  						dijit.byId("itemCP.razonSocialRecepCP").setValue("");
  						dijit.byId("itemCP.razonSocialRecepCP2").setValue("");
      				dijit.byId("itemCP.fechaEmisionCP").setValue("");
      				dijit.byId("itemCP.fechaVencimientoPago").setValue("");
  						dijit.byId("itemCP.numeroSerieCP").setValue("");
  						dijit.byId("itemCP.numeroCP").setValue("");
  						//dijit.byId("itemCP.numeroSerieMaqRegistra").setValue("");
  						dijit.byId("itemCP.numeroInicialCP").setValue("");
  						dijit.byId("itemCP.numeroFinalCP").setValue("");
      				//dijit.byId("itemCP.fechaTC").setValue("");
	
  						dijit.byId("itemCP.tc").setValue("");
  						dijit.byId("itemCP.valorFacturadoExportacion").setValue("");
  						dijit.byId("itemCP.valorEmbarcadoExportacion").setValue("");
  						dijit.byId("itemCP.baseImpOperacGrav").setValue("");
  						dijit.byId("itemCP.importeOperacionExonerada").setValue("");
  						dijit.byId("itemCP.importeOperacionInafecta").setValue("");
  						dijit.byId("itemCP.isc").setValue("");
              dijit.byId("itemCP.igvoipm").setValue("");
              dijit.byId("itemCP.baseImponibleIvap").setValue("");
              dijit.byId("itemCP.ivap").setValue("");
              dijit.byId("itemCP.tributosCargosNoBaseImp").setValue("");
              dijit.byId("itemCP.importeTotalCP").setValue("");
              dijit.byId("itemCP.grabadoPremio").setValue("");
              dijit.byId("itemCP.grabadoDonacion").setValue("");
              dijit.byId("itemCP.grabadoEntregaTrabajadores").setValue("");
              dijit.byId("itemCP.grabadoPublicidad").setValue("");
              dijit.byId("itemCP.grabadoBonificacion").setValue("");
              dijit.byId("itemCP.grabadoRetiroOtros").setValue("");
              dijit.byId("itemCP.valorFacturaExportaNoOnerosa").setValue("");
              dijit.byId("itemCP.importeOperacionNoOnerosaExo").setValue("");
              dijit.byId("itemCP.inafectoPremio").setValue("");
              dijit.byId("itemCP.inafectoPublicidad").setValue("");
              dijit.byId("itemCP.inafectoBonificacion").setValue("");
              dijit.byId("itemCP.inafectoRetiroConvenioColectivo").setValue("");
              dijit.byId("itemCP.inafectoMuestrasMedicas").setValue("");
              dijit.byId("itemCP.inafectoRetiroOtros").setValue("");
   						dijit.byId("itemCP.fechaEmisionCPModificado").setValue("");

              dijit.byId("itemCP.numeroSerieCPModificado").setValue(""); 
              dijit.byId("itemCP.numeroCPModificado").setValue("");
              
              dojo.byId("itemCP.tipoMoneda").value = "-"
              dijit.byId("itemCP.descBaseImponible").setValue("");

              dijit.byId("itemCP.descuentoIgvoipm").setValue("");
              dijit.byId("itemCP.contratoColaboracion").setValue("");
                                          
              this.beanCPFisico = null;	
			  var grilla =dijit.byId("fisico.fisicosGrid");
		    var row = dijit.byId("fisico.fisicosGrid").getItem(rowIndex);
	        
        var valorIdCP = grilla.store.getValue(row, "num_id_cp");
                     
  			var handler = dojo.xhrGet({
                  url: this.controller + "?action=verCPFisico&valorIdCP=" + valorIdCP ,
                  handleAs: "json",
  			         	preventCache: true,
                  sync: true,
                  timeout: 10000
              });
      		
  			handler.addCallback(dojo.hitch(this, function(res){
  				this.waitMessage.hide();
  				if(res.codeError == 0) {
  				try
  {

            var fecHoy = new Date();
            var mesAnterior = fecHoy.setMonth(fecHoy.getMonth()-1);
            var periodoAnterior = dojo.date.locale.format(new Date(mesAnterior), {datePattern: "yyyyMM", selector: "date"});
           

  					if (res.data != null &&  res.data  != "") {
  						this.beanCPFisico = eval("(" + res.data + ")");
  						if (this.beanCPFisico.ind_regven == "1" || this.beanCPFisico.indPrico == "1" ){
  						    this.showHiddenDiv(document.getElementById("itemCP.botonesRVI.show"),false);
  						    this.showHiddenDiv(document.getElementById("itemCP.botonesRVI2.show"),false);
  						}else{
  						    this.showHiddenDiv(document.getElementById("itemCP.botonesRVI.show"),true);
  						    this.showHiddenDiv(document.getElementById("itemCP.botonesRVI2.show"),true);
              }
              dijit.byId("itemCP.idCP").setValue( this.beanCPFisico.num_id_cp);
              dijit.byId("itemCP.ultimoDiaPeriodo").setValue( this.beanCPFisico.ultimoDia);
  						//dijit.byId("itemCP.periodoRegistroVentas").setValue(this.beanCPFisico.num_per_regven);
  						dijit.byId("itemCP.periodoRegistroVentas").setValue(this.beanCPFisico.num_per_regven.substring(4,6) + "/" + this.beanCPFisico.num_per_regven.substring(0,4));
  						dijit.byId("itemCP.tipoCP").setValue(this.beanCPFisico.cod_cp);
  						dijit.byId("itemCP.estadoCP").setValue(this.beanCPFisico.ind_estado);
  						//dijit.byId("itemCP.periodoAjuste").setValue(this.beanCPFisico.periodoAjuste);
  						if (this.beanCPFisico.periodoAjuste!= null && this.beanCPFisico.periodoAjuste != "" && this.beanCPFisico.periodoAjuste != "-"){
  						    dijit.byId("itemCP.periodoAjuste").setValue(this.beanCPFisico.periodoAjuste.substring(4,6) + "/" + this.beanCPFisico.periodoAjuste.substring(0,4));
  						}
  						if (this.beanCPFisico.num_cuo == -1){
  						    dijit.byId("itemCP.cuo").setValue("RER");
              }else{
  						    dijit.byId("itemCP.cuo").setValue(this.beanCPFisico.num_cuo);
  						}
  						dijit.byId("itemCP.numeroCorrelativo").setValue(this.beanCPFisico.num_correlativo);
  						dijit.byId("itemCP.tipoDocRecepCP").setValue(this.beanCPFisico.cod_docide_recep);
  						if (this.beanCPFisico.num_docide_recep != null && this.beanCPFisico.num_docide_recep != "-"){
  						    dijit.byId("itemCP.numeroDocRecepCP").setValue(this.beanCPFisico.num_docide_recep);
  						}
  						dijit.byId("itemCP.razonSocialRecepCP").setValue(this.beanCPFisico.des_nombre_recep);
  						dijit.byId("itemCP.razonSocialRecepCP2").setValue(this.beanCPFisico.des_nombre_recep);
  						if (this.beanCPFisico.fec_emision != null && this.beanCPFisico.fec_emision != "" && this.beanCPFisico.fec_emision != "01/01/0001" ) {
      						dijit.byId("itemCP.fechaEmisionCP").setValue(new Date(this.beanCPFisico.fec_emision.substring(3,6) + this.beanCPFisico.fec_emision.substring(0,3) + this.beanCPFisico.fec_emision.substring(6,10)  ));
  						}
  						if (this.beanCPFisico.fec_vencimiento_pago != null  && this.beanCPFisico.fec_vencimiento_pago != "01/01/0001") {
      						dijit.byId("itemCP.fechaVencimientoPago").setValue(new Date(this.beanCPFisico.fec_vencimiento_pago.substring(3,6) + this.beanCPFisico.fec_vencimiento_pago.substring(0,3) + this.beanCPFisico.fec_vencimiento_pago.substring(6,10)  ));
  						}

  						dijit.byId("itemCP.numeroSerieCP").setValue(this.beanCPFisico.num_serie_cp);
  						dijit.byId("itemCP.numeroCP").setValue(this.beanCPFisico.num_cp);
  					//dijit.byId("itemCP.numeroSerieMaqRegistra").setValue(this.beanCPFisico.num_serie_maq);
  						dijit.byId("itemCP.numeroInicialCP").setValue(this.beanCPFisico.num_inicial);
  						dijit.byId("itemCP.numeroFinalCP").setValue(this.beanCPFisico.num_final);
  						if (this.beanCPFisico.cod_moneda != "PEN"){
  						    dijit.byId("itemCP.tipoMoneda").setValue(this.beanCPFisico.cod_moneda);
  						}
  					//if (this.beanCPFisico.fec_tipo_cambio != null && this.beanCPFisico.fec_tipo_cambio != "" &&  this.beanCPFisico.fec_tipo_cambio != "01/01/0001") {
      			//			dijit.byId("itemCP.fechaTC").setValue(new Date(this.beanCPFisico.fec_tipo_cambio.substring(3,6) + this.beanCPFisico.fec_tipo_cambio.substring(0,3) + this.beanCPFisico.fec_tipo_cambio.substring(6,10)  ));
  					//	}  
		
  				    dijit.byId("itemCP.tc").setValue(dojo.number.format(this.beanCPFisico.tipo_cambio,{places:3} ));
              if (this.beanCPFisico.error_tipo1 != null && this.beanCPFisico.error_tipo1 != ""  ) {
                  if (this.beanCPFisico.error_tipo1 == "1") {
                      dijit.byId("itemCP.tcDiferenteSunat1").setChecked("checked");
                    }else{
                      dijit.byId("itemCP.tcDiferenteSunat0").setChecked("checked");
                    }
                
                }   				    
  						dijit.byId("itemCP.valorFacturadoExportacion").setValue(this.beanCPFisico.valor_facturado_exportacion);
  						dijit.byId("itemCP.valorEmbarcadoExportacion").setValue(this.beanCPFisico.valor_embarcado_exportacion);
  						dijit.byId("itemCP.baseImpOperacGrav").setValue(this.beanCPFisico.base_imponible_operacion_gravada);
  						dijit.byId("itemCP.importeOperacionExonerada").setValue(this.beanCPFisico.importe_total_operacion_exonerada);
  						dijit.byId("itemCP.importeOperacionInafecta").setValue(this.beanCPFisico.importe_total_operacion_inafecta);
  						dijit.byId("itemCP.isc").setValue(this.beanCPFisico.isc);
  						if (this.beanCPFisico.tasa_igv_ipm != null){
  						    if (this.beanCPFisico.tasa_igv_ipm =="0"){
  						        dijit.byId("itemCP.tasasIgvIpm").setValue("00");
                  }else{
                      dijit.byId("itemCP.tasasIgvIpm").setValue(this.beanCPFisico.tasa_igv_ipm);
                  }
              }else{
                  dijit.byId("itemCP.tasasIgvIpm").setValue("");
              }
              dijit.byId("itemCP.igvoipm").setValue(this.beanCPFisico.igv_ipm); 
              dijit.byId("itemCP.baseImponibleIvap").setValue(this.beanCPFisico.base_imponible_operacion_gravada_ivap);
              dijit.byId("itemCP.ivap").setValue(this.beanCPFisico.ivap);
              dijit.byId("itemCP.tributosCargosNoBaseImp").setValue(this.beanCPFisico.otros_tributos_cargos);
              dijit.byId("itemCP.importeTotalCP").setValue(this.beanCPFisico.mto_importe_total);
              
              dijit.byId("itemCP.descBaseImponible").setValue(this.beanCPFisico.descuento_base_imponible);
              dijit.byId("itemCP.descuentoIgvoipm").setValue(this.beanCPFisico.descuento_igv_ipm);
              dijit.byId("itemCP.contratoColaboracion").setValue(this.beanCPFisico.contrato_colaboracion);
              
             if (this.beanCPFisico.medio_de_pago != null && this.beanCPFisico.medio_de_pago != ""  ) {
                if (this.beanCPFisico.medio_de_pago == "1") {
                    dijit.byId("itemCP.medioDePago1").setChecked("checked");
                  }else{
                    dijit.byId("itemCP.medioDePago0").setChecked("checked");
                  }
              
              }           

  						if (this.beanCPFisico.fec_emision_cp_modif != null  && this.beanCPFisico.fec_emision_cp_modif != ""  && this.beanCPFisico.fec_emision_cp_modif != "01/01/0001") {  						
      						dijit.byId("itemCP.fechaEmisionCPModificado").setValue(new Date(this.beanCPFisico.fec_emision_cp_modif.substring(3,6) + this.beanCPFisico.fec_emision_cp_modif.substring(0,3) + this.beanCPFisico.fec_emision_cp_modif.substring(6,10)  ));
  						}         
              if (this.beanCPFisico.cod_cp_modif != null ){      
                dijit.byId("itemCP.tipoCPModificado").setValue(this.beanCPFisico.cod_cp_modif);   
                if ( this.beanCPFisico.cod_cp_modif =="01" ||  this.beanCPFisico.cod_cp_modif =="03" ){
                   dijit.byId("itemCP.numeroSerieCPModificado").attr('maxLength',4);
                   dijit.byId("itemCP.numeroSerieCPModificado").attr('regExp','[E-Fe-f0-9]+');
                }else{
                    if ( this.beanCPFisico.cod_cp_modif =="04" ){
                       dijit.byId("itemCP.numeroSerieCPModificado").attr('maxLength',4);
                       dijit.byId("itemCP.numeroSerieCPModificado").attr('regExp','[0-9]+');
                    }else{
                       dijit.byId("itemCP.numeroSerieCPModificado").attr('maxLength',20);
                       dijit.byId("itemCP.numeroSerieCPModificado").attr('regExp','[A-Z0-9]+[-]{0,1}[A-Z0-9]+');
                    }	
                }	                
              }     
              if (this.beanCPFisico.num_serie_cp_modif ==null || this.beanCPFisico.num_serie_cp_modif =="-"){
                  dijit.byId("itemCP.numeroSerieCPModificado").setValue(""); 
              }else{
                  dijit.byId("itemCP.numeroSerieCPModificado").setValue(dojo.trim(this.beanCPFisico.num_serie_cp_modif));    
              }
              if (this.beanCPFisico.num_cp_modif =="-"){
                  dijit.byId("itemCP.numeroCPModificado").setValue(""); 
              }else{
                  dijit.byId("itemCP.numeroCPModificado").setValue(this.beanCPFisico.num_cp_modif);   
              }
               
              dijit.byId("itemCP.tipoDocRecepCP").attr('disabled', true) ;  
              dijit.byId("itemCP.numeroDocRecepCP").attr('disabled', true) ;  
              dijit.byId("itemCP.razonSocialRecepCP").attr('disabled', true) ;  
              dijit.byId("itemCP.fechaEmisionCPModificado").attr('disabled', true) ;  
              dijit.byId("itemCP.tipoCPModificado").attr('disabled', true) ;  
              dijit.byId("itemCP.numeroSerieCPModificado").attr('disabled', true) ; 
              dijit.byId("itemCP.numeroCPModificado").attr('disabled', true) ; 
              dijit.byId("itemCP.descBaseImponible").attr('disabled', true) ;   
              dijit.byId("itemCP.descuentoIgvoipm").attr('disabled', true) ;
              dijit.byId("itemCP.contratoColaboracion").attr('disabled', true) ;
              dijit.byId("itemCP.medioDePago1").attr('disabled', true) ;
              dijit.byId("itemCP.medioDePago0").attr('disabled', true) ;               
        			  this.mostrarDatosItem(); 
        
                this.dialogCP.show();
                dojo.style(this.dialogCP.closeButtonNode,"display","none"); 


  					}
  }
catch(err)
  {
  txt="There was an error on this page.\n\n";
  txt+="Error description: " + err.message + "\n\n";
  txt+="Click OK to continue.\n\n";
  alert(txt);
  }  					
  				} else {
  					alert(res.messageError);
  				}
  			}));
			
  			handler.addErrback(dojo.hitch(this, function(res) {
      			this.waitMessage.hide();
  				alert("Ocurrio un error al momento de ejecutar la consulta");
  			}));
      },

	mostrarDatosItem: function() {
    //Seteamos pantalla
	  var estadoCP = dijit.byId("itemCP.estadoCP").getValue();
	  var tipoMoneda = dijit.byId("itemCP.tipoMoneda").getValue();
	  
    if (estadoCP !="02"){
          
          
            var fecHoy = new Date();
            var mesAnterior = fecHoy.setMonth(fecHoy.getMonth()-1);
            var periodoAnterior = dojo.date.locale.format(new Date(mesAnterior), {datePattern: "yyyyMM", selector: "date"});
           
          if (this.beanCPFisico.ind_regven == "1" || this.beanCPFisico.indPrico == "1"  || (this.beanCPFisico.num_per_regven < periodoAnterior)){
          //if (this.beanCPFisico.ind_regven == "1" || this.beanCPFisico.indPrico == "1"  ){   //OJO
              this.showHiddenDiv(document.getElementById("itemCP.botonesRVI.show"),false);
          }else{
              this.showHiddenDiv(document.getElementById("itemCP.botonesRVI.show"),true);
          }
          this.showHiddenDiv(document.getElementById("itemCP.fechaEmisionCP.show"),true);
          this.showHiddenDiv(document.getElementById("itemCP.importeTotalCP.show"),true);
          this.showHiddenDiv(document.getElementById("itemCP.tipoMoneda.show"),true);
          this.showHiddenDiv(document.getElementById("itemCP.tipoCambio.show"),true);   
          //if (tipoMoneda != "USD" && tipoMoneda != "CAD" && tipoMoneda != "GBP" && tipoMoneda != "JPY" && tipoMoneda != "SEK" && tipoMoneda != "CHF" && tipoMoneda != "EUR"){
          //   this.showHiddenDiv(document.getElementById("itemCP.tipoCambio.show"),true);
          //}else{
             //this.showHiddenDiv(document.getElementById("itemCP.tipoCambio.show"),false);
          //}         
          this.showHiddenDiv(document.getElementById("itemCP.fechaVencimPago.show"),true);
          this.showHiddenDiv(document.getElementById("itemCP.valorFacturadoExportacion.show"),true);
          this.showHiddenDiv(document.getElementById("itemCP.baseOperacGrav.show"),true);
          this.showHiddenDiv(document.getElementById("itemCP.IgvIpm.show"),true);
          this.showHiddenDiv(document.getElementById("itemCP.importeOperacExo.show"),true);
          this.showHiddenDiv(document.getElementById("itemCP.importeOperacInaf.show"),true);
          this.showHiddenDiv(document.getElementById("itemCP.Isc.show"),true);		   
          this.showHiddenDiv(document.getElementById("itemCP.Ivap.show"),true);
          this.showHiddenDiv(document.getElementById("itemCP.tribCargosNoBaseImp.show"),true);
          this.showHiddenDiv(document.getElementById("itemCP.CPQueModifica.show"),true);     
               
    }else{
      		this.showHiddenDiv(document.getElementById("itemCP.botonesRVI.show"),false);
          this.showHiddenDiv(document.getElementById("itemCP.fechaEmisionCP.show"),false);
          this.showHiddenDiv(document.getElementById("itemCP.importeTotalCP.show"),false);
          dojo.byId("itemCP.importeTotalCP").value = "";  
          this.showHiddenDiv(document.getElementById("itemCP.tipoMoneda.show"),false);
          this.showHiddenDiv(document.getElementById("itemCP.tipoCambio.show"),false);    
  		    dijit.byId("itemCP.tipoDocRecepCP").setValue("- - ");
  		    dijit.byId("itemCP.numeroDocRecepCP").setValue("");
  		    dijit.byId("itemCP.razonSocialRecepCP").setValue("");
  		    dijit.byId("itemCP.razonSocialRecepCP2").setValue("");
  		    this.showHiddenDiv(document.getElementById("itemCP.fechaVencimPago.show"),false);
  		    this.showHiddenDiv(document.getElementById("itemCP.valorFacturadoExportacion.show"),false);
          this.showHiddenDiv(document.getElementById("itemCP.baseOperacGrav.show"),false);
          this.showHiddenDiv(document.getElementById("itemCP.IgvIpm.show"),false);  
          
          this.showHiddenDiv(document.getElementById("itemCP.importeOperacExo.show"),false);
          this.showHiddenDiv(document.getElementById("itemCP.importeOperacInaf.show"),false);
          this.showHiddenDiv(document.getElementById("itemCP.Isc.show"),false);		   
          this.showHiddenDiv(document.getElementById("itemCP.Ivap.show"),false);
          this.showHiddenDiv(document.getElementById("itemCP.tribCargosNoBaseImp.show"),false);
          this.showHiddenDiv(document.getElementById("itemCP.CPQueModifica.show"),false);
    }
                var bOcultar= true;

                  this.showHiddenDiv(document.getElementById("itemCP.operacionesGratuitas.show"),false);

          var tieneExportacion = this.beanCPFisico.ind_exportacion ;
          /*if (tieneExportacion==1 ){
          
      		   dijit.byId("itemCP.tipoDocRecepCP").setValue("- - ");
      		   dijit.byId("itemCP.tipoDocRecepCP").attr('disabled', true) ;  
      		   dijit.byId("itemCP.numeroDocRecepCP").setValue("");
      		   dijit.byId("itemCP.numeroDocRecepCP").attr('disabled', true) ;  
      		   dijit.byId("itemCP.razonSocialRecepCP").setValue("");
      		   dijit.byId("itemCP.razonSocialRecepCP2").setValue("");
      		   dijit.byId("itemCP.razonSocialRecepCP").attr('disabled', true) ;  		   
          }*/
         /*if (this.beanCPFisico.num_serie_maq != null && this.beanCPFisico.num_serie_maq != "" && this.beanCPFisico.num_serie_maq !="-")
         {  this.showHiddenDiv(document.getElementById("itemCP.nroSerieRegistradora.show"),true);}  
         else {this.showHiddenDiv(document.getElementById("itemCP.nroSerieRegistradora.show"),false); }    
         */      
         if (this.beanCPFisico.valor_facturado_exportacion != null && this.beanCPFisico.valor_facturado_exportacion != "" && this.beanCPFisico.valor_facturado_exportacion !="-")
         {  this.showHiddenDiv(document.getElementById("itemCP.valorFacturadoExportacion.show"),true); }   
         else{  this.showHiddenDiv(document.getElementById("itemCP.valorFacturadoExportacion.show"),false); }  
         if (this.beanCPFisico.base_imponible_operacion_gravada != null && this.beanCPFisico.base_imponible_operacion_gravada != "" && this.beanCPFisico.base_imponible_operacion_gravada !="-")
         {  
            this.showHiddenDiv(document.getElementById("itemCP.baseOperacGrav.show"),true); 
         }   
         else{  
             this.showHiddenDiv(document.getElementById("itemCP.baseOperacGrav.show"),false); 
          }  
         
         if (this.beanCPFisico.descuento_base_imponible != null && this.beanCPFisico.descuento_base_imponible != "" && this.beanCPFisico.descuento_base_imponible !="-")
         {  
            this.showHiddenDiv(document.getElementById("itemCP.descBaseImponible.show"),true); 
         }   
         else{  
             this.showHiddenDiv(document.getElementById("itemCP.descBaseImponible.show"),false); 
          } 

         if ((this.beanCPFisico.tasa_igv_ipm != null) && (this.beanCPFisico.tasa_igv_ipm !="-"))
         {  
            
         } else 
         {  
            if (this.beanCPFisico.igv_ipm!= null && this.beanCPFisico.igv_ipm!="" && this.beanCPFisico.igv_ipm!="-"){
                this.showHiddenDiv(document.getElementById("itemCP.IgvIpm.show"),true); 
                dijit.byId("itemCP.tasasIgvIpm").setValue("");            
            }else{
            
                this.showHiddenDiv(document.getElementById("itemCP.IgvIpm.show"),false); 
                dijit.byId("itemCP.tasasIgvIpm").setValue("");
            }
            
         }     
         if (this.beanCPFisico.descuento_igv_ipm != null && this.beanCPFisico.descuento_igv_ipm != "" && this.beanCPFisico.descuento_igv_ipm !="-")
         {  
            this.showHiddenDiv(document.getElementById("itemCP.descuentoIgvIpm.show"),true); 
         }   
         else{  
             this.showHiddenDiv(document.getElementById("itemCP.descuentoIgvIpm.show"),false); 
          }              
         if (this.beanCPFisico.importe_total_operacion_exonerada != null && this.beanCPFisico.importe_total_operacion_exonerada != "" && this.beanCPFisico.importe_total_operacion_exonerada !="-")
         {  this.showHiddenDiv(document.getElementById("itemCP.importeOperacExo.show"),true); }   
         else{  this.showHiddenDiv(document.getElementById("itemCP.importeOperacExo.show"),false); }   
         if (this.beanCPFisico.importe_total_operacion_inafecta != null && this.beanCPFisico.importe_total_operacion_inafecta != "" && this.beanCPFisico.importe_total_operacion_inafecta !="-")
         {  this.showHiddenDiv(document.getElementById("itemCP.importeOperacInaf.show"),true); }   
         else{  this.showHiddenDiv(document.getElementById("itemCP.importeOperacInaf.show"),false); }       
         if (this.beanCPFisico.isc != null && this.beanCPFisico.isc != "" && this.beanCPFisico.isc !="-")
         {  this.showHiddenDiv(document.getElementById("itemCP.Isc.show"),true); }   
         else{  this.showHiddenDiv(document.getElementById("itemCP.Isc.show"),false); } 
         if (this.beanCPFisico.base_imponible_operacion_gravada_ivap != null && this.beanCPFisico.base_imponible_operacion_gravada_ivap != "" && this.beanCPFisico.base_imponible_operacion_gravada_ivap !="-")
         {  this.showHiddenDiv(document.getElementById("itemCP.Ivap.show"),true); }   
         else{  this.showHiddenDiv(document.getElementById("itemCP.Ivap.show"),false); }   
         if (this.beanCPFisico.otros_tributos_cargos != null && this.beanCPFisico.otros_tributos_cargos != "" && this.beanCPFisico.otros_tributos_cargos !="-")
         {  this.showHiddenDiv(document.getElementById("itemCP.tribCargosNoBaseImp.show"),true); }   
         else{  this.showHiddenDiv(document.getElementById("itemCP.tribCargosNoBaseImp.show"),false); }   
         if (this.beanCPFisico.num_cp_modif != null && this.beanCPFisico.num_cp_modif != "" && this.beanCPFisico.num_cp_modif !="-")
         {  this.showHiddenDiv(document.getElementById("itemCP.CPQueModifica.show"),true); }   
         else{  this.showHiddenDiv(document.getElementById("itemCP.CPQueModifica.show"),false); }
            	   
         this.showHiddenDiv(document.getElementById("itemCP.tipoMoneda.show"),true);            	   
				 if (this.beanCPFisico.cod_moneda != "PEN"){
  				 if (this.beanCPFisico.tipo_cambio!=null){
  				       
  					    
  					    //if (this.beanCPFisico.cod_moneda != "USD" && this.beanCPFisico.cod_moneda != "CAD" && this.beanCPFisico.cod_moneda != "GBP" && this.beanCPFisico.cod_moneda != "JPY" && this.beanCPFisico.cod_moneda != "SEK" && this.beanCPFisico.cod_moneda != "CHF" && this.beanCPFisico.cod_moneda != "EUR"){
                    this.showHiddenDiv(document.getElementById("itemCP.tipoCambio.show"),true);
               //}else{
                //  this.showHiddenDiv(document.getElementById("itemCP.tipoCambio.show"),false);
                  //dojo.byId("itemCP.fechaTC").value = "";  
                 // dojo.byId("itemCP.tc").value = "";           
            
               //}
              }
				 }else{
				      dijit.byId("itemCP.tipoMoneda").setValue("-");
				      this.showHiddenDiv(document.getElementById("itemCP.tipoMoneda.show"),false); 
				      this.showHiddenDiv(document.getElementById("itemCP.tipoCambio.show"),false); 
         }
         
     		 if (this.beanCPFisico.fec_vencimiento_pago != null  && this.beanCPFisico.fec_vencimiento_pago != "01/01/0001") {
     		     this.showHiddenDiv(document.getElementById("itemCP.fechaVencimPago.show"),true);
				 }  else{
				      this.showHiddenDiv(document.getElementById("itemCP.fechaVencimPago.show"),false);
         }
  },
	

    	realizarConsulta: function(){
      		if(!dijit.byId("criterio.form").validate()) return;
  
      		if(dojo.byId("criterio.periodo").value == "") {
      			alert("Tiene que ingresar un periodo con formato MM/YYYY.");
      			return;
      		}
      		
      		this.cargarValoresGlobales();
      		
      		this.wait("Consultando", "110px");
      		
      		var handler = dojo.io.iframe.send({
      			url: this.controller,
      			handleAs: "json",
      			sync: true,
      			timeout: 90000,
      			preventCache: true,
      			form: "criterio.form"
      		});
    		
    			handler.addCallback(dojo.hitch(this, function(res){
    				this.waitMessage.hide();
    				if(res.codeError == 0) {
    					this.content.onLoad = dojo.hitch(this, function(){
    						var data = eval("(" + res.data + ")");						
    						this.store = new dojo.data.ItemFileWriteStore({data: {identifier: 'id', items: data}});
    			    		var periodo = dijit.byId("fisico.periodoDesc");
    			    		periodo.setValue(dojo.byId("global.periodoDesc").value)
    			    		var fecha = dojo.byId("global.periodo").value.substring(4,6) + "/01/" + dojo.byId("global.periodo").value.substring(0,4);
                  dijit.byId("generales.fechaEmisionCPDesde").setValue (new Date(fecha));   			 
                  dijit.byId("generales.fechaEmisionCPHasta").setValue (new Date(fecha));   		
    			    		var grid = dijit.byId("fisico.fisicosGrid");
    						grid.setStore(this.store);
    						grid.startup();
    					});
    					this.content.setHref(this.controller + "?action=mostrarListado" + "&preventCache=" + this.preventCache());		
            			
    				} else {
    					alert(res.messageError);
    				}
    			}));
    			handler.addErrback(dojo.hitch(this, function(res) {
        			this.waitMessage.hide();
    				alert("Ocurrio un error al momento de ejecutar la consulta.");
    			}));
    	}, 	
    	
      realizarConsultaFiltro: function(){

      		
      		//this.wait("Consultando", "110px");
      		var tipoCP = dijit.byId("generales.tipoCP").getValue().substring(0,2);
      		var serieCP = dijit.byId("generales.numeroSerieCP").getValue();
      		var numeroCP = dijit.byId("generales.numeroCP").getValue();
      		var fecEmisionDesde;
          if (dijit.byId('generales.fechaEmisionCPDesde').getValue() != null && dijit.byId('generales.fechaEmisionCPDesde').getValue() !=""){
              fecEmisionDesde = dojo.date.locale.format(dijit.byId('generales.fechaEmisionCPDesde').getValue(), {datePattern: "dd/MM/yyyy", selector: "date"});
          }else{
              fecEmisionDesde = "";
          } 
          var fecEmisionHasta ;
          if (dijit.byId('generales.fechaEmisionCPHasta').getValue() != null && dijit.byId('generales.fechaEmisionCPHasta').getValue() !=""){
              fecEmisionHasta = dojo.date.locale.format(dijit.byId('generales.fechaEmisionCPHasta').getValue(), {datePattern: "dd/MM/yyyy", selector: "date"});
          }else{
              fecEmisionHasta = "";
          }           
     		
          var handler = dojo.xhrGet({
                    url: this.controller + "?action=realizarConsultaFiltro&tipoCP=" + tipoCP +"&serieCP=" + serieCP +"&numeroCP=" + numeroCP +"&fecEmisionDesde=" + fecEmisionDesde +"&fecEmisionHasta=" + fecEmisionHasta ,
                    handleAs: "json",
                    sync: true,
                    timeout: 10000
               });    		
    			handler.addCallback(dojo.hitch(this, function(res){
    				//this.waitMessage.hide();
    				if(res.codeError == 0) {

    						var data = eval("(" + res.data + ")");						
    						this.store = new dojo.data.ItemFileWriteStore({data: {identifier: 'id', items: data}});
    			    		var grid = dijit.byId("fisico.fisicosGrid");
    						grid.setStore(this.store);
    						grid.startup();
					
    				} else {
    					alert(res.messageError);
    				}
    			}));
    			handler.addErrback(dojo.hitch(this, function(res) {
        			this.waitMessage.hide();
    				alert("Ocurrio un error al momento de ejecutar la consulta.");
    			}));
    	}, 
    	
    	limpiarFiltro: function(){
    		  dijit.byId("generales.tipoCP").setValue("-- - ");
      		dijit.byId("generales.numeroSerieCP").setValue("");
      		dijit.byId("generales.numeroCP").setValue("");
      		dijit.byId('generales.fechaEmisionCPDesde').setValue("");
      		dijit.byId('generales.fechaEmisionCPHasta').setValue("");
    	}, 
         	
    	//lo utiliza Arturo
    	imprimirListado: function(rowIndex){
    		window.open(this.controller + "?action=imprimirListado&periodoDesc=" + dojo.byId("global.periodoDesc").value + "&preventCache=" + this.preventCache(), "imprimeListado" , "toolbar=0,location=0,directories=0,status=no,menubar=0,scrollbars=yes,resizable=yes,width=1000,height=580,titlebar=no");    		
    	},    	
    	
      descargar: function(rowIndex){
    		var context = this.getContext();
	      var row = dijit.byId(context + ".facturasGrid").getItem(rowIndex);
			
  			dojo.byId("formArchivo.ruc").value = row.nroRucEmisor;
  			dojo.byId("formArchivo.tipo").value = row.codFactura;
  			dojo.byId("formArchivo.serie").value = row.nroSerie;
  			dojo.byId("formArchivo.numero").value = row.nroFactura;
  
  			dojo.byId("formArchivo").submit();			
    	},  	
    	//lo utiliza Arturo

    	
        messageBoxOKCancel: function(message, iconClass){
            var dialog = dijit.byId("dialogOkCancel");
            if (dialog) {
                dojo.byId("ok_cancelMessage").innerHTML = this.chunkString(message, 40);
                if (iconClass) {
                    dojo.addClass("ok_cancelIcon", iconClass);
                }
                else {
                    dojo.addClass("ok_cancelIcon", "icon-alert-info");
                }
                dijit.byId('dialogOkCancel').domNode.style.visibility = "visible";
                dialog.show();
            }
        },
        
    	cargarValoresGlobales: function() {
    		dojo.byId("global.periodo").value =dojo.byId("criterio.periodo").value.substring(3,7) + dojo.byId("criterio.periodo").value.substring(0,2);
    		dojo.byId("global.periodoDesc").value = dijit.byId("criterio.periodo").getValue();
    	},
    	


		checkAnotado: function(rowindex) {
			if (rowindex == "1") {
				return "<img src=\"/a/imagenes/see/icons/icon-complete.gif\" />";
			} else {
				return "";
			}
		},

		checkImportado: function(rowindex) {
			if (rowindex == "1") {
				return "<img src=\"/a/imagenes/see/icons/icon-complete.gif\" />";
			} else {
				return "";
			}
		},

    	linkView: function(value,rowindex) {
    		return "<a href=\"#\" onclick=\"consultaFisico.showDialogItem('" + rowindex +  "')\"> <img src=\"/a/imagenes/see/icons/viewdoc.gif\" /></a>"
    	},
    	
    closeDialogCP: function() {
                   dijit.byId("itemCP.idCP").setValue( "");
              dijit.byId("itemCP.ultimoDiaPeriodo").setValue( "");
              
  						dijit.byId("itemCP.periodoRegistroVentas").setValue("");
  						dijit.byId("itemCP.periodoAjuste").setValue("");
  						dijit.byId("itemCP.cuo").setValue("");
              dijit.byId("itemCP.numeroCorrelativo").setValue("");
  						dijit.byId("itemCP.numeroDocRecepCP").setValue("");
  						dijit.byId("itemCP.razonSocialRecepCP").setValue("");
  						dijit.byId("itemCP.razonSocialRecepCP2").setValue("");
      				dijit.byId("itemCP.fechaEmisionCP").setValue("");
      				dijit.byId("itemCP.fechaVencimientoPago").setValue("");
  						dijit.byId("itemCP.numeroSerieCP").setValue("");
  						dijit.byId("itemCP.numeroCP").setValue("");
  						//dijit.byId("itemCP.numeroSerieMaqRegistra").setValue("");
  						dijit.byId("itemCP.numeroInicialCP").setValue("");
  						dijit.byId("itemCP.numeroFinalCP").setValue("");
      				//dijit.byId("itemCP.fechaTC").setValue("");
	
  						dijit.byId("itemCP.tc").setValue("");
  						dijit.byId("itemCP.valorFacturadoExportacion").setValue("");
  						dijit.byId("itemCP.valorEmbarcadoExportacion").setValue("");
  						dijit.byId("itemCP.baseImpOperacGrav").setValue("");
  						dijit.byId("itemCP.importeOperacionExonerada").setValue("");
  						dijit.byId("itemCP.importeOperacionInafecta").setValue("");
  						dijit.byId("itemCP.isc").setValue("");
              dijit.byId("itemCP.igvoipm").setValue("");
              dijit.byId("itemCP.baseImponibleIvap").setValue("");
              dijit.byId("itemCP.ivap").setValue("");
              dijit.byId("itemCP.tributosCargosNoBaseImp").setValue("");
              dijit.byId("itemCP.importeTotalCP").setValue("");
              dijit.byId("itemCP.grabadoPremio").setValue("");
              dijit.byId("itemCP.grabadoDonacion").setValue("");
              dijit.byId("itemCP.grabadoEntregaTrabajadores").setValue("");
              dijit.byId("itemCP.grabadoPublicidad").setValue("");
              dijit.byId("itemCP.grabadoBonificacion").setValue("");
              dijit.byId("itemCP.grabadoRetiroOtros").setValue("");
              dijit.byId("itemCP.valorFacturaExportaNoOnerosa").setValue("");
              dijit.byId("itemCP.importeOperacionNoOnerosaExo").setValue("");
              dijit.byId("itemCP.inafectoPremio").setValue("");
              dijit.byId("itemCP.inafectoPublicidad").setValue("");
              dijit.byId("itemCP.inafectoBonificacion").setValue("");
              dijit.byId("itemCP.inafectoRetiroConvenioColectivo").setValue("");
              dijit.byId("itemCP.inafectoMuestrasMedicas").setValue("");
              dijit.byId("itemCP.inafectoRetiroOtros").setValue("");
   						dijit.byId("itemCP.fechaEmisionCPModificado").setValue("");
     
              dijit.byId("itemCP.numeroSerieCPModificado").setValue(""); 
              dijit.byId("itemCP.numeroCPModificado").setValue("");
              dojo.byId("itemCP.tipoMoneda").value = "-"
              dijit.byId("itemCP.descBaseImponible").setValue("");

              dijit.byId("itemCP.descuentoIgvoipm").setValue("");
              dijit.byId("itemCP.contratoColaboracion").setValue("");
                            
		 this.dialogCP.hide();
	  },	
   
    deleteCP: function() {
		 		if (confirm("Desea eliminar el Comprobante de Pago Fisico?")) {
    			
    			
      			var handler = dojo.xhrGet({
      				preventCache:  false,
      				url: this.controller + "?action=eliminarCP&valorIdCP=" +this.beanCPFisico.num_id_cp,
      				handleAs: "json",
      				sync: true,
      				timeout: 10000
      			});    		
          		
      			handler.addCallback(dojo.hitch(this, function(res){
      				//this.waitMessage.hide();
      				if(res.codeError == 0) {
      				     this.dialogCP.hide();
      				     alert("Comprobante de pago fisico eliminado satisfactoriamente");
      				     
                		handler2= dojo.xhrGet({
                        url: this.controller + "?action=getComprobantesFisicos&periodo=" + dojo.byId("global.periodo").value,
                        handleAs: "json",
        			         	preventCache: true,
                        sync: true,
                        timeout: 10000
                    });
                  		
                  	
              			handler2.addCallback(dojo.hitch(this, function(res2){
              				if(res2.codeError == 0) {
              					if (res2.data != null &&  res2.data  != "") {
                  					  	var data = eval("(" + res2.data + ")");		
                    						this.store = new dojo.data.ItemFileWriteStore({data: {identifier: 'id', items: data}});
                    			    	var grid = dijit.byId("fisico.fisicosGrid");
                    						grid.setStore(this.store);
                    						grid.startup(); 
              					}
              				} else {
              					  alert(res2.messageError);
              					  return;
              				}
              			}));
            			
              			handler2.addErrback(dojo.hitch(this, function(res2) {
                  			//this.waitMessage.hide();
              				  alert("Ocurrio un error al momento de ejecutar la consulta.");
              				  return
              			}));       				     
        				} else {
      					   alert(res.messageError);
      					   return;
      				}
      			}));
      			handler.addErrback(dojo.hitch(this, function(res) {
          			//this.waitMessage.hide();
      				  alert("Ocurrio un error al momento de ejecutar la eliminacion del CP.");
      				  return;
      			}));   
          
 
    		}
	  },	
    	 	
   salirEsc :function(){
      if (this.bModificando == true) {
        this.salirModif();
        
      }else{
         this.closeDialogCP();
      }
   },

   salirModif :function(){
     if (confirm("Desea salir de la opci�n de modificaci�n?")){
       	  dijit.hideTooltip(dojo.byId("itemCP.fechaEmisionCP"));
       dijit.hideTooltip(dojo.byId("itemCP.fechaVencimientoPago"));
       dijit.hideTooltip(dojo.byId("itemCP.numeroSerieCP"));
       dijit.hideTooltip(dojo.byId("itemCP.numeroDocRecepCP"));
       dijit.hideTooltip(dojo.byId("itemCP.numeroInicialCP"));
       dijit.hideTooltip(dojo.byId("itemCP.numeroFinalCP"));   
       dijit.hideTooltip(dojo.byId("itemCP.numeroCP")); 
       dijit.hideTooltip(dojo.byId("itemCP.numeroSerieCP"))
       dijit.hideTooltip(dojo.byId("itemCP.cuo")); 
       dijit.hideTooltip(dojo.byId("itemCP.numeroCorrelativo")); 
       dijit.hideTooltip(dojo.byId("itemCP.estadoCP")); 
	  	  //dijit.hideTooltip(dojo.byId("itemCP.fechaTC"));
	      dijit.hideTooltip(dojo.byId("itemCP.tc"));   
        dijit.hideTooltip(dojo.byId("itemCP.baseImpOperacGrav"));
        dijit.hideTooltip(dojo.byId("itemCP.igvoipm"));
        dijit.hideTooltip(dojo.byId("itemCP.valorFacturadoExportacion"));
        dijit.hideTooltip(dojo.byId("itemCP.valorEmbarcadoExportacion"));
        dijit.hideTooltip(dojo.byId("itemCP.importeOperacionExonerada"));
        dijit.hideTooltip(dojo.byId("itemCP.importeOperacionInafecta"));
        dijit.hideTooltip(dojo.byId("itemCP.tributosCargosNoBaseImp"));
        dijit.hideTooltip(dojo.byId("itemCP.isc"));   
        dijit.hideTooltip(dojo.byId("itemCP.baseImponibleIvap"));
        dijit.hideTooltip(dojo.byId("itemCP.ivap"));
	      dijit.hideTooltip(dojo.byId("itemCP.importeTotalCP"));
	      dijit.hideTooltip(dojo.byId("itemCP.numeroCPModificado"));
	      dijit.hideTooltip(dojo.byId("itemCP.numeroSerieCPModificado"));
        dijit.hideTooltip(dojo.byId("itemCP.tipoMoneda"));
        dijit.hideTooltip(dojo.byId("itemCP.tasasIgvIpm"));
        dijit.hideTooltip(dojo.byId("itemCP.importeTotalCP"));      
        dijit.hideTooltip(dojo.byId("itemCP.grabadoPremio"));
        dijit.hideTooltip(dojo.byId("itemCP.grabadoDonacion"));
        dijit.hideTooltip(dojo.byId("itemCP.grabadoEntregaTrabajadores")); 
        dijit.hideTooltip(dojo.byId("itemCP.grabadoPublicidad"));
        dijit.hideTooltip(dojo.byId("itemCP.grabadoBonificacion"));
        dijit.hideTooltip(dojo.byId("itemCP.grabadoRetiroOtros")); 
        dijit.hideTooltip(dojo.byId("itemCP.valorFacturaExportaNoOnerosa"));
        dijit.hideTooltip(dojo.byId("itemCP.importeOperacionNoOnerosaExo"));
        dijit.hideTooltip(dojo.byId("itemCP.inafectoPremio"));                 	      

        dijit.hideTooltip(dojo.byId("itemCP.inafectoPublicidad")); 
        dijit.hideTooltip(dojo.byId("itemCP.inafectoBonificacion"));
        dijit.hideTooltip(dojo.byId("itemCP.inafectoRetiroConvenioColectivo"));
        dijit.hideTooltip(dojo.byId("itemCP.inafectoMuestrasMedicas")); 

        dijit.hideTooltip(dojo.byId("itemCP.inafectoRetiroOtros")); 
        dijit.hideTooltip(dojo.byId("itemCP.fechaEmisionCPModificado"));
        dijit.hideTooltip(dojo.byId("itemCP.tipoCPModificado"));
        this.bModificando = false;
  						//dijit.byId("itemCP.periodoRegistroVentas").setValue(this.beanCPFisico.num_per_regven);
  						dijit.byId("itemCP.periodoRegistroVentas").setValue(this.beanCPFisico.num_per_regven.substring(4,6) + "/" + this.beanCPFisico.num_per_regven.substring(0,4));
  						dijit.byId("itemCP.tipoCP").setValue(this.beanCPFisico.cod_cp);
  						dijit.byId("itemCP.estadoCP").setValue(this.beanCPFisico.ind_estado);
  						//dijit.byId("itemCP.periodoAjuste").setValue(this.beanCPFisico.periodoAjuste);
  						if (this.beanCPFisico.periodoAjuste!= null && this.beanCPFisico.periodoAjuste != "" && this.beanCPFisico.periodoAjuste != "-"){
  						  dijit.byId("itemCP.periodoAjuste").setValue(this.beanCPFisico.periodoAjuste.substring(4,6) + "/" + this.beanCPFisico.periodoAjuste.substring(0,4));
  						}

  						//if (this.beanCPFisico.num_cuo == -1){
  						//7    dijit.byId("itemCP.cuo").setValue("RER");
              //}else{
  						    dijit.byId("itemCP.cuo").setValue(this.beanCPFisico.num_cuo);
  						//}  						
  						dijit.byId("itemCP.numeroCorrelativo").setValue(this.beanCPFisico.num_correlativo);
  						dijit.byId("itemCP.tipoDocRecepCP").setValue(this.beanCPFisico.cod_docide_recep);
  						dijit.byId("itemCP.numeroDocRecepCP").setValue(this.beanCPFisico.num_docide_recep);
  						dijit.byId("itemCP.razonSocialRecepCP").setValue(this.beanCPFisico.des_nombre_recep);
  						dijit.byId("itemCP.razonSocialRecepCP2").setValue(this.beanCPFisico.des_nombre_recep);
  						if (this.beanCPFisico.fec_emision != null && this.beanCPFisico.fec_emision != "" && this.beanCPFisico.fec_emision != "01/01/0001" ) {
      						var fecha = new Date(this.beanCPFisico.fec_emision.substring(3,6) + this.beanCPFisico.fec_emision.substring(0,3) + this.beanCPFisico.fec_emision.substring(6,10)  );
      						dijit.byId("itemCP.fechaEmisionCP").setValue(fecha);
  						}
  						if (this.beanCPFisico.fec_vencimiento_pago != null  && this.beanCPFisico.fec_vencimiento_pago != "01/01/0001") {  						
      						var fecha1 = new Date(this.beanCPFisico.fec_vencimiento_pago.substring(3,6) + this.beanCPFisico.fec_vencimiento_pago.substring(0,3) + this.beanCPFisico.fec_vencimiento_pago.substring(6,10)  );
      						dijit.byId("itemCP.fechaVencimientoPago").setValue(fecha1);
  						}
  						dijit.byId("itemCP.numeroSerieCP").setValue(this.beanCPFisico.num_serie_cp);
  						dijit.byId("itemCP.numeroCP").setValue(this.beanCPFisico.num_cp);
  						//dijit.byId("itemCP.numeroSerieMaqRegistra").setValue(this.beanCPFisico.num_serie_maq);
  						dijit.byId("itemCP.numeroInicialCP").setValue(this.beanCPFisico.num_inicial);
  						dijit.byId("itemCP.numeroFinalCP").setValue(this.beanCPFisico.num_final);
  						if (this.beanCPFisico.cod_moneda =="PEN"){
  						  dojo.byId("itemCP.tipoMoneda").value = "-"
  						}else{
  						  dijit.byId("itemCP.tipoMoneda").setValue(this.beanCPFisico.cod_moneda);
  						}
  						//if (this.beanCPFisico.fec_tipo_cambio != null && this.beanCPFisico.fec_tipo_cambio != "" &&  this.beanCPFisico.fec_tipo_cambio != "01/01/0001") {  						
      				//		var fecha2 = new Date(this.beanCPFisico.fec_tipo_cambio.substring(3,6) + this.beanCPFisico.fec_tipo_cambio.substring(0,3) + this.beanCPFisico.fec_tipo_cambio.substring(6,10)  );
      				//		dijit.byId("itemCP.fechaTC").setValue(fecha2);
  						//}  						
  						dijit.byId("itemCP.tc").setValue(dojo.number.format(this.beanCPFisico.tipo_cambio,{places:2} ));
              if (this.beanCPFisico.error_tipo1 != null && this.beanCPFisico.error_tipo1 != ""  ) {
                  if (this.beanCPFisico.error_tipo1 == "1") {
                      dijit.byId("itemCP.tcDiferenteSunat1").setChecked("checked");
                    }else{
                      dijit.byId("itemCP.tcDiferenteSunat0").setChecked("checked");
                    }
                
                }   						
  						dijit.byId("itemCP.valorFacturadoExportacion").setValue(this.beanCPFisico.valor_facturado_exportacion);
  						dijit.byId("itemCP.valorEmbarcadoExportacion").setValue(this.beanCPFisico.valor_embarcado_exportacion);
  						dijit.byId("itemCP.baseImpOperacGrav").setValue(this.beanCPFisico.base_imponible_operacion_gravada);
  						dijit.byId("itemCP.descBaseImponible").setValue(this.beanCPFisico.descuento_base_imponible);
  						dijit.byId("itemCP.importeOperacionExonerada").setValue(this.beanCPFisico.importe_total_operacion_exonerada);
  						dijit.byId("itemCP.importeOperacionInafecta").setValue(this.beanCPFisico.importe_total_operacion_inafecta);
  						dijit.byId("itemCP.isc").setValue(this.beanCPFisico.isc);
              //dijit.byId("itemCP.tasasIgvIpm").setValue(this.beanCPFisico.tasa_igv_ipm);
  						if (this.beanCPFisico.tasa_igv_ipm != null){
  						    if (this.beanCPFisico.tasa_igv_ipm =="0"){
  						        dijit.byId("itemCP.tasasIgvIpm").setValue("00");
                  }else{
                      dijit.byId("itemCP.tasasIgvIpm").setValue(this.beanCPFisico.tasa_igv_ipm);
                  }
              }else{
                  dijit.byId("itemCP.tasasIgvIpm").setValue("");
              } 
              
              dijit.byId("itemCP.descBaseImponible").setValue(this.beanCPFisico.descuento_base_imponible);
              dijit.byId("itemCP.descuentoIgvoipm").setValue(this.beanCPFisico.descuento_igv_ipm);
              dijit.byId("itemCP.contratoColaboracion").setValue(this.beanCPFisico.contrato_colaboracion);
             if (this.beanCPFisico.medio_de_pago != null && this.beanCPFisico.medio_de_pago != ""  ) {
                if (this.beanCPFisico.medio_de_pago == "1") {
                    dijit.byId("itemCP.medioDePago1").setChecked("checked");
                  }else{
                    dijit.byId("itemCP.medioDePago0").setChecked("checked");
                  }
              
              }                                           
              dijit.byId("itemCP.igvoipm").setValue(this.beanCPFisico.igv_ipm);
              dijit.byId("itemCP.baseImponibleIvap").setValue(this.beanCPFisico.base_imponible_operacion_gravada_ivap);
              dijit.byId("itemCP.ivap").setValue(this.beanCPFisico.ivap);
              dijit.byId("itemCP.tributosCargosNoBaseImp").setValue(this.beanCPFisico.otros_tributos_cargos);
              dijit.byId("itemCP.importeTotalCP").setValue(this.beanCPFisico.mto_importe_total);
              dijit.byId("itemCP.grabadoPremio").setValue(this.beanCPFisico.gravado_premio);
              dijit.byId("itemCP.grabadoDonacion").setValue(this.beanCPFisico.gravado_donacion);
              dijit.byId("itemCP.grabadoEntregaTrabajadores").setValue(this.beanCPFisico.gravado_entrega_trabajadores);
              dijit.byId("itemCP.grabadoPublicidad").setValue(this.beanCPFisico.gravado_publicidad);
              dijit.byId("itemCP.grabadoBonificacion").setValue(this.beanCPFisico.gravado_bonificacion);
              dijit.byId("itemCP.grabadoRetiroOtros").setValue(this.beanCPFisico.gravado_retiro_otros);
              dijit.byId("itemCP.valorFacturaExportaNoOnerosa").setValue(this.beanCPFisico.valor_facturado_exportacion_no_onerosa);
              dijit.byId("itemCP.importeOperacionNoOnerosaExo").setValue(this.beanCPFisico.importe_total_operacion_no_onerosa);
              dijit.byId("itemCP.inafectoPremio").setValue(this.beanCPFisico.inafecto_premio);
              dijit.byId("itemCP.inafectoPublicidad").setValue(this.beanCPFisico.inafecto_publicidad);
              dijit.byId("itemCP.inafectoBonificacion").setValue(this.beanCPFisico.inafecto_bonificacion);
              dijit.byId("itemCP.inafectoRetiroConvenioColectivo").setValue(this.beanCPFisico.inafecto_retiro_convenio_colectivo);
              dijit.byId("itemCP.inafectoMuestrasMedicas").setValue(this.beanCPFisico.inafecto_muestras_medicas);
              dijit.byId("itemCP.inafectoRetiroOtros").setValue(this.beanCPFisico.inafecto_retiro_otros);
  						if (this.beanCPFisico.fec_emision_cp_modif != null  && this.beanCPFisico.fec_emision_cp_modif != ""  && this.beanCPFisico.fec_emision_cp_modif != "01/01/0001") {  						
      						var fecha3 = new Date(this.beanCPFisico.fec_emision_cp_modif.substring(3,6) + this.beanCPFisico.fec_emision_cp_modif.substring(0,3) + this.beanCPFisico.fec_emision_cp_modif.substring(6,10)  );
      						dijit.byId("itemCP.fechaEmisionCPModificado").setValue(fecha3);
  						}               
   
              if (this.beanCPFisico.cod_cp_modif != null ){      
                dijit.byId("itemCP.tipoCPModificado").setValue(this.beanCPFisico.cod_cp_modif);   
              }                
              if (this.beanCPFisico.num_serie_cp_modif!= null) {      
                  dijit.byId("itemCP.numeroSerieCPModificado").setValue(dojo.trim(this.beanCPFisico.num_serie_cp_modif));   
              } 
              if (this.beanCPFisico.num_cp_modif != null) {  
                  dijit.byId("itemCP.numeroCPModificado").setValue(this.beanCPFisico.num_cp_modif);         
              }
              dijit.byId("itemCP.tipoDocRecepCP").attr('disabled', true) ;  
              dijit.byId("itemCP.numeroDocRecepCP").attr('disabled', true) ;  
              dijit.byId("itemCP.razonSocialRecepCP").attr('disabled', true) ;
              dijit.byId("itemCP.fechaEmisionCP").attr('disabled', true) ;
              dijit.byId("itemCP.fechaVencimientoPago").attr('disabled', true) ;
              //dijit.byId("itemCP.numeroSerieMaqRegistra").attr('disabled', true) ;
              dijit.byId("itemCP.tipoMoneda").attr('disabled', true) ;
              //dijit.byId("itemCP.fechaTC").attr('disabled', true) ;       
              dijit.byId("itemCP.tc").attr('disabled', true) ;
              dijit.byId("itemCP.valorFacturadoExportacion").attr('disabled', true) ;
              dijit.byId("itemCP.valorEmbarcadoExportacion").attr('disabled', true) ;
              dijit.byId("itemCP.baseImpOperacGrav").attr('disabled', true) ;
              dijit.byId("itemCP.importeOperacionExonerada").attr('disabled', true) ;
              dijit.byId("itemCP.importeOperacionInafecta").attr('disabled', true) ;
              dijit.byId("itemCP.isc").attr('disabled', true) ;              
              dijit.byId("itemCP.tasasIgvIpm").attr('disabled', true) ;
              dijit.byId("itemCP.igvoipm").attr('disabled', true) ;
              dijit.byId("itemCP.baseImponibleIvap").attr('disabled', true) ;
              dijit.byId("itemCP.ivap").attr('disabled', true) ;
              dijit.byId("itemCP.tributosCargosNoBaseImp").attr('disabled', true) ;
              dijit.byId("itemCP.importeTotalCP").attr('disabled', true) ; 
              dijit.byId("itemCP.grabadoPremio").attr('disabled', true) ; 
              dijit.byId("itemCP.grabadoDonacion").attr('disabled', true) ; 
              dijit.byId("itemCP.grabadoEntregaTrabajadores").attr('disabled', true) ; 
              dijit.byId("itemCP.grabadoPublicidad").attr('disabled', true) ; 
              dijit.byId("itemCP.grabadoBonificacion").attr('disabled', true) ; 
              dijit.byId("itemCP.grabadoRetiroOtros").attr('disabled', true) ; 
              dijit.byId("itemCP.valorFacturaExportaNoOnerosa").attr('disabled', true) ; 
              dijit.byId("itemCP.importeOperacionNoOnerosaExo").attr('disabled', true) ; 
              dijit.byId("itemCP.inafectoPremio").attr('disabled', true) ; 
              dijit.byId("itemCP.inafectoPublicidad").attr('disabled', true) ; 
              dijit.byId("itemCP.inafectoBonificacion").attr('disabled', true) ; 
              dijit.byId("itemCP.inafectoRetiroConvenioColectivo").attr('disabled', true) ; 
              dijit.byId("itemCP.inafectoMuestrasMedicas").attr('disabled', true) ; 
              dijit.byId("itemCP.inafectoRetiroOtros").attr('disabled', true) ; 
              dijit.byId("itemCP.fechaEmisionCPModificado").attr('disabled', true) ;  
              dijit.byId("itemCP.tipoCPModificado").attr('disabled', true) ;  
              dijit.byId("itemCP.numeroSerieCPModificado").attr('disabled', true) ; 
              dijit.byId("itemCP.numeroCPModificado").attr('disabled', true) ; 
                var bOcultar= true;
               if ((this.beanCPFisico.gravado_premio != null && this.beanCPFisico.gravado_premio != "") || (this.beanCPFisico.ind_importacion =="1") )
               {
                    bOcultar= false;
               }     
               if ((this.beanCPFisico.gravado_donacion != null && this.beanCPFisico.gravado_donacion != "") || (this.beanCPFisico.ind_importacion =="1") )
               {
                    bOcultar= false;
               }        
               if ((this.beanCPFisico.gravado_entrega_trabajadores != null && this.beanCPFisico.gravado_entrega_trabajadores != "") || (this.beanCPFisico.ind_importacion =="1") )
               {
                    bOcultar= false;
               }        
               if ((this.beanCPFisico.gravado_publicidad != null && this.beanCPFisico.gravado_publicidad != "") || (this.beanCPFisico.ind_importacion =="1") )
               {
                    bOcultar= false;
               } 
               if ((this.beanCPFisico.gravado_bonificacion != null && this.beanCPFisico.gravado_bonificacion != "") || (this.beanCPFisico.ind_importacion =="1") )
               {
                    bOcultar= false;
               }     
               if ((this.beanCPFisico.gravado_retiro_otros != null && this.beanCPFisico.gravado_retiro_otros != "") || (this.beanCPFisico.ind_importacion =="1") )
               {
                    bOcultar= false;
               }        
               if ((this.beanCPFisico.valor_facturado_exportacion_no_onerosa != null && this.beanCPFisico.valor_facturado_exportacion_no_onerosa != "") || (this.beanCPFisico.ind_importacion =="1") )
               {
                    bOcultar= false;
               }        
               if ((this.beanCPFisico.importe_total_operacion_no_onerosa != null && this.beanCPFisico.importe_total_operacion_no_onerosa != "") || (this.beanCPFisico.ind_importacion =="1") )
               {
                    bOcultar= false;
               } 
              if ((this.beanCPFisico.inafecto_premio != null && this.beanCPFisico.inafecto_premio != "") || (this.beanCPFisico.ind_importacion =="1") )
               {
                    bOcultar= false;
               }     
               if ((this.beanCPFisico.inafecto_publicidad != null && this.beanCPFisico.inafecto_publicidad != "") || (this.beanCPFisico.ind_importacion =="1") )
               {
                    bOcultar= false;
               }        
               if ((this.beanCPFisico.inafecto_bonificacion != null && this.beanCPFisico.inafecto_bonificacion != "") || (this.beanCPFisico.ind_importacion =="1") )
               {
                    bOcultar= false;
               }        
               if ((this.beanCPFisico.inafecto_retiro_convenio_colectivo != null && this.beanCPFisico.inafecto_retiro_convenio_colectivo != "") || (this.beanCPFisico.ind_importacion =="1") )
               {
                    bOcultar= false;
               } 
               if ((this.beanCPFisico.inafecto_muestras_medicas != null && this.beanCPFisico.inafecto_muestras_medicas != "") || (this.beanCPFisico.ind_importacion =="1") )
               {
                    bOcultar= false;
               }     
               if ((this.beanCPFisico.inafecto_retiro_otros != null && this.beanCPFisico.inafecto_retiro_otros != "") || (this.beanCPFisico.ind_importacion =="1") )
               {
                    bOcultar= false;
               }  
               //if (bOcultar){
                  this.showHiddenDiv(document.getElementById("itemCP.operacionesGratuitas.show"),false);
               //} else{
               //    this.showHiddenDiv(document.getElementById("itemCP.operacionesGratuitas.show"),true);
               //}          
              this.showHiddenDiv(document.getElementById("itemCP.botonesRVI.show"),true);
              this.showHiddenDiv(document.getElementById("itemCP.botonesRVI2.show"),true);
              this.showHiddenDiv(document.getElementById("itemCP.botonRVISalir.show"),true);
              this.showHiddenDiv(document.getElementById("itemCP.botonesRVIModif.show"),false);
     }
   
   },
   
   
   updateCP:function(){
       this.showHiddenDiv(document.getElementById("itemCP.botonesRVI.show"),false);
       this.showHiddenDiv(document.getElementById("itemCP.botonesRVI2.show"),false);
       this.showHiddenDiv(document.getElementById("itemCP.botonRVISalir.show"),false);
       this.showHiddenDiv(document.getElementById("itemCP.botonesRVIModif.show"),true);
       this.bModificando = true;

    	  var estadoCP = dijit.byId("itemCP.estadoCP").getValue();
    	  var tipoMoneda = dijit.byId("itemCP.tipoMoneda").getValue();
    	  var tieneExportacion = this.beanCPFisico.ind_exportacion ;
        if ( estadoCP !="02"){
              dijit.byId("itemCP.tipoDocRecepCP").attr('disabled', false) ;  
              dijit.byId("itemCP.numeroDocRecepCP").attr('disabled', false) ;  
              var tipoDocSel = dijit.byId("itemCP.tipoDocRecepCP").getValue().substring(0,1);
              if (tipoDocSel !="6"){
                  dijit.byId("itemCP.razonSocialRecepCP").attr('disabled', false) ;  
              }
        }
       
       dijit.byId("itemCP.fechaEmisionCP").attr('disabled', false) ;
       dijit.byId("itemCP.fechaVencimientoPago").attr('disabled', false) ;
       //dijit.byId("itemCP.numeroSerieMaqRegistra").attr('disabled', false) ;
       dijit.byId("itemCP.tipoMoneda").attr('disabled', false) ;
       //dijit.byId("itemCP.fechaTC").attr('disabled', false) ;       
       dijit.byId("itemCP.tc").attr('disabled', false) ;
       dijit.byId("itemCP.valorFacturadoExportacion").attr('disabled', false) ;
       //dijit.byId("itemCP.valorEmbarcadoExportacion").attr('disabled', false) ;
       dijit.byId("itemCP.baseImpOperacGrav").attr('disabled', false) ;
       dijit.byId("itemCP.importeOperacionExonerada").attr('disabled', false) ;
       dijit.byId("itemCP.importeOperacionInafecta").attr('disabled', false) ;
       dijit.byId("itemCP.isc").attr('disabled', false) ;              
       dijit.byId("itemCP.tasasIgvIpm").attr('disabled', false) ;
       dijit.byId("itemCP.igvoipm").attr('disabled', false) ;
       dijit.byId("itemCP.baseImponibleIvap").attr('disabled', false) ;
       dijit.byId("itemCP.ivap").attr('disabled', false) ;
       dijit.byId("itemCP.tributosCargosNoBaseImp").attr('disabled', false) ;
       dijit.byId("itemCP.importeTotalCP").attr('disabled', false) ; 
              dijit.byId("itemCP.fechaEmisionCPModificado").attr('disabled', false) ;  
              dijit.byId("itemCP.tipoCPModificado").attr('disabled', false) ;  
              dijit.byId("itemCP.numeroSerieCPModificado").attr('disabled', false) ; 
              dijit.byId("itemCP.numeroCPModificado").attr('disabled', false) ;  
              
        dijit.byId("itemCP.descBaseImponible").attr('disabled', false) ;   
        dijit.byId("itemCP.descuentoIgvoipm").attr('disabled', false) ;
        dijit.byId("itemCP.contratoColaboracion").attr('disabled', false) ;
        dijit.byId("itemCP.medioDePago1").attr('disabled', false) ;
        dijit.byId("itemCP.medioDePago0").attr('disabled', false) ;
                                      
       var bOcultar= true;
       if ((this.beanCPFisico.gravado_premio != null && this.beanCPFisico.gravado_premio != "") || (this.beanCPFisico.ind_importacion =="1") )
       {
            dijit.byId("itemCP.grabadoPremio").attr('disabled', false) ; 
            bOcultar= false;
       }     
       if ((this.beanCPFisico.gravado_donacion != null && this.beanCPFisico.gravado_donacion != "") || (this.beanCPFisico.ind_importacion =="1") )
       {
            dijit.byId("itemCP.grabadoDonacion").attr('disabled', false) ; 
            bOcultar= false;
       }        
       if ((this.beanCPFisico.gravado_entrega_trabajadores != null && this.beanCPFisico.gravado_entrega_trabajadores != "") || (this.beanCPFisico.ind_importacion =="1") )
       {
            dijit.byId("itemCP.grabadoEntregaTrabajadores").attr('disabled', false) ; 
            bOcultar= false;
       }        
       if ((this.beanCPFisico.gravado_publicidad != null && this.beanCPFisico.gravado_publicidad != "") || (this.beanCPFisico.ind_importacion =="1") )
       {
            dijit.byId("itemCP.grabadoPublicidad").attr('disabled', false) ; 
            bOcultar= false;
       } 
       if ((this.beanCPFisico.gravado_bonificacion != null && this.beanCPFisico.gravado_bonificacion != "") || (this.beanCPFisico.ind_importacion =="1") )
       {
            dijit.byId("itemCP.grabadoBonificacion").attr('disabled', false) ; 
            bOcultar= false;
       }     
       if ((this.beanCPFisico.gravado_retiro_otros != null && this.beanCPFisico.gravado_retiro_otros != "") || (this.beanCPFisico.ind_importacion =="1") )
       {
            dijit.byId("itemCP.grabadoRetiroOtros").attr('disabled', false) ; 
            bOcultar= false;
       }        
       if ((this.beanCPFisico.valor_facturado_exportacion_no_onerosa != null && this.beanCPFisico.valor_facturado_exportacion_no_onerosa != "") || (this.beanCPFisico.ind_importacion =="1") )
       {
            dijit.byId("itemCP.valorFacturaExportaNoOnerosa").attr('disabled', false) ; 
            bOcultar= false;
       }        
       if ((this.beanCPFisico.importe_total_operacion_no_onerosa != null && this.beanCPFisico.importe_total_operacion_no_onerosa != "") || (this.beanCPFisico.ind_importacion =="1") )
       {
            dijit.byId("itemCP.importeOperacionNoOnerosaExo").attr('disabled', false) ; 
            bOcultar= false;
       } 
      if ((this.beanCPFisico.inafecto_premio != null && this.beanCPFisico.inafecto_premio != "") || (this.beanCPFisico.ind_importacion =="1") )
       {
            dijit.byId("itemCP.inafectoPremio").attr('disabled', false) ; 
            bOcultar= false;
       }     
       if ((this.beanCPFisico.inafecto_publicidad != null && this.beanCPFisico.inafecto_publicidad != "") || (this.beanCPFisico.ind_importacion =="1") )
       {
            dijit.byId("itemCP.inafectoPublicidad").attr('disabled', false) ; 
            bOcultar= false;
       }        
       if ((this.beanCPFisico.inafecto_bonificacion != null && this.beanCPFisico.inafecto_bonificacion != "") || (this.beanCPFisico.ind_importacion =="1") )
       {
            dijit.byId("itemCP.inafectoBonificacion").attr('disabled', false) ; 
            bOcultar= false;
       }        
       if ((this.beanCPFisico.inafecto_retiro_convenio_colectivo != null && this.beanCPFisico.inafecto_retiro_convenio_colectivo != "") || (this.beanCPFisico.ind_importacion =="1") )
       {
            dijit.byId("itemCP.inafectoRetiroConvenioColectivo").attr('disabled', false) ; 
            bOcultar= false;
       } 
       if ((this.beanCPFisico.inafecto_muestras_medicas != null && this.beanCPFisico.inafecto_muestras_medicas != "") || (this.beanCPFisico.ind_importacion =="1") )
       {
            dijit.byId("itemCP.inafectoMuestrasMedicas").attr('disabled', false) ; 
            bOcultar= false;
       }     
       if ((this.beanCPFisico.inafecto_retiro_otros != null && this.beanCPFisico.inafecto_retiro_otros != "") || (this.beanCPFisico.ind_importacion =="1") )
       {
            dijit.byId("itemCP.inafectoRetiroOtros").attr('disabled', false) ; 
            bOcultar= false;
       }  
               //if (bOcultar){
                  this.showHiddenDiv(document.getElementById("itemCP.operacionesGratuitas.show"),false);
               //} else{
               //    this.showHiddenDiv(document.getElementById("itemCP.operacionesGratuitas.show"),true);
               //}
               
            var valor = dijit.byId("itemCP.igvoipm").getValue();
            var porcentaje = dojo.byId("itemCP.tasasIgvIpm").value;
            var base = dojo.byId("itemCP.baseImpOperacGrav").value;
            var total = 0;
             if (porcentaje != "" && base != ""){
                porcentaje = dijit.byId("itemCP.tasasIgvIpm").getValue();
                base = dijit.byId("itemCP.baseImpOperacGrav").getValue();
                total = porcentaje * base;
                if (total > 0 ) { total = total / 100;}
                total = this.roundNumber(total,2);

             }   

             if (porcentaje != "" || base != ""){
                  if (total != valor){
                      this.iconTooltipMessage("itemCP.igvoipm", "icon-ok-tooltip", "Valor consignado no corresponde a la tasa de IGV y/o IPM seleccionada.");
    
                  } 
              }              
                  
                  
/////////////////////
        var valorTotal = dojo.byId("itemCP.importeTotalCP").value;
        if(valorTotal != "" && estadoCP!="02"){   
            var valorFactExporta = dojo.byId("itemCP.valorFacturadoExportacion").value;
          var baseImpOperacGrav = dojo.byId("itemCP.baseImpOperacGrav").value;
          var importOperacExonerada= dojo.byId("itemCP.importeOperacionExonerada").value;
          var importOperacInafecta = dojo.byId("itemCP.importeOperacionInafecta").value;
          var mtoISC = dojo.byId("itemCP.isc").value;                              
          var mtoIGV = dojo.byId("itemCP.igvoipm").value;
          var baseImpIvap = dojo.byId("itemCP.baseImponibleIvap").value;                              
          var mtoIvap = dojo.byId("itemCP.ivap").value;
          var otroTributosNoFormanBaseImp = dojo.byId("itemCP.tributosCargosNoBaseImp").value;                              
          if (valorFactExporta!=""){ 
              valorFactExporta = dijit.byId("itemCP.valorFacturadoExportacion").getValue();}
          else {valorFactExporta = 0;}  
          if (baseImpOperacGrav!=""){ 
              baseImpOperacGrav = dijit.byId("itemCP.baseImpOperacGrav").getValue();}
          else {baseImpOperacGrav = 0;}  
          if (importOperacExonerada!=""){ 
              importOperacExonerada = dijit.byId("itemCP.importeOperacionExonerada").getValue();}
          else {importOperacExonerada = 0;}  
          if (importOperacInafecta!=""){ 
              importOperacInafecta = dijit.byId("itemCP.importeOperacionInafecta").getValue();}
          else {importOperacInafecta = 0;}  
          if (mtoISC!=""){ 
              mtoISC = dijit.byId("itemCP.isc").getValue();}
          else {mtoISC = 0;} 
          if (mtoIGV!=""){ 
              mtoIGV = dijit.byId("itemCP.igvoipm").getValue();}
          else {mtoIGV = 0;}  
          if (baseImpIvap!=""){ 
              baseImpIvap = dijit.byId("itemCP.baseImponibleIvap").getValue();}
          else {baseImpIvap = 0;}  
          if (mtoIvap!=""){ 
              mtoIvap = dijit.byId("itemCP.ivap").getValue();}
          else {mtoIvap = 0;}  
          if (otroTributosNoFormanBaseImp!=""){ 
              otroTributosNoFormanBaseImp = dijit.byId("itemCP.tributosCargosNoBaseImp").getValue();}
          else {otroTributosNoFormanBaseImp = 0;}  
           valorTotal = dijit.byId("itemCP.importeTotalCP").getValue();                                         
          var total = 0;
          total =  valorFactExporta + baseImpOperacGrav+ importOperacExonerada+ importOperacInafecta+ mtoISC+    mtoIGV + baseImpIvap +   mtoIvap+otroTributosNoFormanBaseImp;
          total = this.roundNumber(total,2);
          if (total != 0  ){
             if (total != valorTotal){
                alert("Valor consignado en el importe total no corresponde a la suma de los montos registrados.");
             }   
          }
        }
        
        this.validaNumDoc();
/////////////////////777                          
   },
    	
	
	valoresNumDoc: function(){
	  if (!this.bModificando) {return;}
  	var tipoDocSel = dijit.byId("itemCP.tipoDocRecepCP").getValue().substring(0,1);
  
    switch (tipoDocSel) { 
        case "-": 
    	     dijit.byId("itemCP.numeroDocRecepCP").attr('maxLength',8);
    	     dijit.byId("itemCP.numeroDocRecepCP").attr('regExp','[0-9]+');  
    		   dijit.byId("itemCP.numeroDocRecepCP").setValue("");
    		   dijit.byId("itemCP.numeroDocRecepCP").attr('disabled', true) ; 
    		   break
        case "1": 
    	     dijit.byId("itemCP.numeroDocRecepCP").attr('maxLength',8);
    	     dijit.byId("itemCP.numeroDocRecepCP").attr('regExp','[0-9]+');
    	     dijit.byId("itemCP.numeroDocRecepCP").attr('disabled', false) ; 
    	     if (dijit.byId("itemCP.numeroDocRecepCP").getValue().length > 8 ){
                dijit.byId("itemCP.numeroDocRecepCP").setValue("");
                dijit.byId("itemCP.razonSocialRecepCP").setValue("");
                dijit.byId("itemCP.razonSocialRecepCP2").setValue("");
           }
           break 
        case "6": 
    	     dijit.byId("itemCP.numeroDocRecepCP").attr('maxLength',11);
    	     dijit.byId("itemCP.numeroDocRecepCP").attr('regExp','[0-9]+');
    	     dijit.byId("itemCP.numeroDocRecepCP").attr('disabled', false) ; 
    	     if (dijit.byId("itemCP.numeroDocRecepCP").getValue().length > 11 ){
                dijit.byId("itemCP.numeroDocRecepCP").setValue("");
                dijit.byId("itemCP.razonSocialRecepCP").setValue("");
                dijit.byId("itemCP.razonSocialRecepCP2").setValue("");
           }
           break 
        default: 
           dijit.byId("itemCP.numeroDocRecepCP").attr('maxLength',16);
           dijit.byId("itemCP.numeroDocRecepCP").attr('regExp','[a-zA-Z0-9]+[-]{0,1}[a-zA-Z0-9]+[-]{0,1}[a-zA-Z0-9]+[-]{0,1}[a-zA-Z0-9]+');
           dijit.byId("itemCP.numeroDocRecepCP").attr('disabled', false) ; 
           dijit.byId("itemCP.razonSocialRecepCP").attr('disabled', false) ; 
           break
    } 
    
    dijit.hideTooltip(dojo.byId("itemCP.numeroDocRecepCP"));
    dijit.hideTooltip(dojo.byId("itemCP.tipoDocRecepCP"));
    
	},
      
	validaNumDoc: function(){
  	//if (!this.bModificando) {return;}
  	  dijit.hideTooltip(dojo.byId("itemCP.razonSocialRecepCP"));
  	  dijit.hideTooltip(dojo.byId("itemCP.numeroDocRecepCP"));
  	  
  	  
  	  var tipoDoc = dijit.byId("itemCP.tipoDocRecepCP").getValue().substring(0,1);
    	var numDoc = dijit.byId("itemCP.numeroDocRecepCP").getValue();
      var lenDoc = numDoc.length;
    
      switch (tipoDoc) { 
          case "1": 
             if (lenDoc != 8){return; }
             break 
          case "6": 
             if (lenDoc != 11){return; }
             break 
          case "-": 
             dijit.byId("itemCP.numeroDocRecepCP").setValue("");
             dijit.byId("itemCP.numeroDocRecepCP").attr('disabled', true) ;  
             return;
             break 
          default: 
             return;
             break                    
      } 
    
    
        var handler = dojo.xhrGet({
              url: this.controller + "?action=validarDocumento&tipoDoc=" +tipoDoc + "&numeroDoc=" + numDoc,
              handleAs: "json",
              sync: true,
              timeout: 10000
        });        
        handler.addCallback(dojo.hitch(this, function(res){
           tipoDoc = dijit.byId("itemCP.tipoDocRecepCP").getValue().substring(0,1);
           tipoDoc = dijit.byId("itemCP.tipoDocRecepCP").getValue().substring(0,1);
    		   if (res.codeError == 0) {
    		       switch (tipoDoc) { 
                    case "1": 
                       if (res.data != null && res.data  != ""){
                          dijit.byId("itemCP.razonSocialRecepCP").setValue(res.data);
                          dijit.byId("itemCP.razonSocialRecepCP2").setValue(res.data);
                          dijit.byId("itemCP.razonSocialRecepCP").attr('disabled', true);
                       }else{
                           dijit.byId("itemCP.razonSocialRecepCP").setValue("");
                           dijit.byId("itemCP.razonSocialRecepCP2").setValue("");
                           dijit.byId("itemCP.razonSocialRecepCP").attr('disabled', false);
                           this.iconTooltipMessage("itemCP.numeroDocRecepCP", "icon-ok-tooltip", "N�mero de DNI no existe!");
                       }
                       break 
                    case "6": 
                       if (res.data != null &&  res.data  != ""){
                          dijit.byId("itemCP.razonSocialRecepCP").setValue(res.data);
                          dijit.byId("itemCP.razonSocialRecepCP2").setValue(res.data);
                          dijit.byId("itemCP.razonSocialRecepCP").attr('disabled', true)
                       }else{
                          dijit.byId("itemCP.razonSocialRecepCP").setValue("");
                          dijit.byId("itemCP.razonSocialRecepCP2").setValue("");
                          dijit.byId("itemCP.numeroDocRecepCP").focus();
                          this.iconTooltipMessage("itemCP.numeroDocRecepCP", "icon-ok-tooltip", "N�mero de RUC no existe!");

                       }
                       break 
               } 
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                              
    			 } else {                                 
    				  alert(res.messageError);
    				  return;
    			 }
    		}));
    		handler.addErrback(function(res){
    	   	this.waitMessage.hide();
    			alert("Problemas al conectarse con el servidor");
    		});
	 },   
   
  registrarCP: function() {
	try{
	     var grabar = true;
  	   dijit.hideTooltip(dojo.byId("itemCP.fechaEmisionCP"));
       dijit.hideTooltip(dojo.byId("itemCP.fechaVencimientoPago"));
       dijit.hideTooltip(dojo.byId("itemCP.numeroSerieCP"));
       dijit.hideTooltip(dojo.byId("itemCP.numeroDocRecepCP"));
       dijit.hideTooltip(dojo.byId("itemCP.numeroInicialCP"));
       dijit.hideTooltip(dojo.byId("itemCP.numeroFinalCP"));   
       dijit.hideTooltip(dojo.byId("itemCP.numeroCP")); 
       dijit.hideTooltip(dojo.byId("itemCP.numeroSerieCP"))
       dijit.hideTooltip(dojo.byId("itemCP.cuo")); 
       dijit.hideTooltip(dojo.byId("itemCP.numeroCorrelativo")); 
       dijit.hideTooltip(dojo.byId("itemCP.estadoCP")); 
	  	  //dijit.hideTooltip(dojo.byId("itemCP.fechaTC"));
	      dijit.hideTooltip(dojo.byId("itemCP.tc"));   
        dijit.hideTooltip(dojo.byId("itemCP.baseImpOperacGrav"));
        dijit.hideTooltip(dojo.byId("itemCP.igvoipm"));
        dijit.hideTooltip(dojo.byId("itemCP.valorFacturadoExportacion"));
        dijit.hideTooltip(dojo.byId("itemCP.valorEmbarcadoExportacion"));
        dijit.hideTooltip(dojo.byId("itemCP.importeOperacionExonerada"));
        dijit.hideTooltip(dojo.byId("itemCP.importeOperacionInafecta"));
        dijit.hideTooltip(dojo.byId("itemCP.tributosCargosNoBaseImp"));
        dijit.hideTooltip(dojo.byId("itemCP.isc"));   
        dijit.hideTooltip(dojo.byId("itemCP.baseImponibleIvap"));
        dijit.hideTooltip(dojo.byId("itemCP.ivap"));
	      dijit.hideTooltip(dojo.byId("itemCP.importeTotalCP"));
	      dijit.hideTooltip(dojo.byId("itemCP.numeroCPModificado"));
	      dijit.hideTooltip(dojo.byId("itemCP.numeroSerieCPModificado"));
        dijit.hideTooltip(dojo.byId("itemCP.tipoMoneda"));
        dijit.hideTooltip(dojo.byId("itemCP.tasasIgvIpm"));
        dijit.hideTooltip(dojo.byId("itemCP.importeTotalCP"));      
        dijit.hideTooltip(dojo.byId("itemCP.grabadoPremio"));
        dijit.hideTooltip(dojo.byId("itemCP.grabadoDonacion"));
        dijit.hideTooltip(dojo.byId("itemCP.grabadoEntregaTrabajadores")); 
        dijit.hideTooltip(dojo.byId("itemCP.grabadoPublicidad"));
        dijit.hideTooltip(dojo.byId("itemCP.grabadoBonificacion"));
        dijit.hideTooltip(dojo.byId("itemCP.grabadoRetiroOtros")); 
        dijit.hideTooltip(dojo.byId("itemCP.valorFacturaExportaNoOnerosa"));
        dijit.hideTooltip(dojo.byId("itemCP.importeOperacionNoOnerosaExo"));
        dijit.hideTooltip(dojo.byId("itemCP.inafectoPremio"));                 	      

        dijit.hideTooltip(dojo.byId("itemCP.inafectoPublicidad")); 
        dijit.hideTooltip(dojo.byId("itemCP.inafectoBonificacion"));
        dijit.hideTooltip(dojo.byId("itemCP.inafectoRetiroConvenioColectivo"));
        dijit.hideTooltip(dojo.byId("itemCP.inafectoMuestrasMedicas")); 

        dijit.hideTooltip(dojo.byId("itemCP.inafectoRetiroOtros")); 
        dijit.hideTooltip(dojo.byId("itemCP.fechaEmisionCPModificado"));
        dijit.hideTooltip(dojo.byId("itemCP.tipoCPModificado"));
                
	   if(!dijit.byId("itemCP.form").validate()) return;
	   
	   var tipoDoc = dijit.byId("itemCP.tipoDocRecepCP").getValue().substring(0,1);
	   var estadoCP = dijit.byId("itemCP.estadoCP").getValue();
     var tieneExportacion = this.beanCPFisico.ind_exportacion ;
     var tipoCP   = dijit.byId("itemCP.tipoCP").getValue().substring(0,2);
     var tipoCPModif = dijit.byId("itemCP.tipoCPModificado").getValue();
         var nroSerieCP = dijit.byId("itemCP.numeroSerieCP").getValue();
     /*if (  tipoCP =="01" &&  tipoDoc !="6"){
          if (tieneExportacion!=1){
              if (estadoCP !="02"){
                  this.iconTooltipMessage("itemCP.tipoDocRecepCP", "icon-ok-tooltip", "El tipo de documento solo puede ser RUC.");
                  return;
              }
          }
     }*/
    //Valida ingreso del tipo de documento
    
    if (  (tipoCP =="00" ||  tipoCP =="03" ||  tipoCP =="05" ||  tipoCP =="06"||  tipoCP =="11" ||
          tipoCP =="12" ||  tipoCP =="13" ||  tipoCP =="14" ||  tipoCP =="15"||  tipoCP =="16"||  tipoCP =="18" || 
          tipoCP =="19" ||  tipoCP =="23" ||  tipoCP =="26" ||  tipoCP =="28"||  tipoCP =="30"||  tipoCP =="34" ||
          tipoCP =="35" ||  tipoCP =="36" ||  tipoCP =="37" ||  tipoCP =="49" || tipoCP =="55"||  tipoCP =="56" ) ||  
          tieneExportacion==1 || ( ( tipoCP =="07" ||  tipoCP =="08" ) && 
                                    (tipoCPModif =="03" || tipoCPModif =="12" || tipoCPModif =="13" || tipoCPModif =="14" || tipoCPModif =="36") )) {
         	 	    

          if (tipoDoc!="-" ) { 
              var numeroDoc = dijit.byId("itemCP.numeroDocRecepCP").getValue();
              if (numeroDoc=="" ) { 
                  this.iconTooltipMessage("itemCP.numeroDocRecepCP", "icon-ok-tooltip", "Debe registrar el n�mero de documento.");
                  return;
              }  
              var lenDoc = numeroDoc.length;  
              if  (tipoDoc =="1") { 
                     if (lenDoc != 8){
                        this.iconTooltipMessage("itemCP.numeroDocRecepCP", "icon-ok-tooltip", "N�mero de documento inv�lido.");
                        return;
                     }
                     if (dijit.byId("itemCP.razonSocialRecepCP").getValue()==""){
                        this.iconTooltipMessage("itemCP.razonSocialRecepCP", "icon-ok-tooltip", "Debe registrar nombre.");
                        return;                  
                     } 
                     
               }    
              if  (tipoDoc =="6") {            
                     if (lenDoc != 11){
                        this.iconTooltipMessage("itemCP.numeroDocRecepCP", "icon-ok-tooltip", "N�mero de documento inv�lido.");
                        return;
                     }
                     if (dijit.byId("itemCP.razonSocialRecepCP").getValue()==""){
                        this.iconTooltipMessage("itemCP.numeroDocRecepCP", "icon-ok-tooltip", "N�mero de RUC no existe.");
                        return;                  
                     }
              }      
              if  (tipoDoc =="0" || tipoDoc =="4" || tipoDoc =="7" || tipoDoc =="A" ) {            
                     if (dijit.byId("itemCP.razonSocialRecepCP").getValue()==""){
                        this.iconTooltipMessage("itemCP.razonSocialRecepCP", "icon-ok-tooltip", "Nombre o raz�n social inconsistente");
                        return;                  
                     }
              }  
              //
              //if  (tipoCP =="03"  && tipoDoc =="6") {   
              //    this.iconTooltipMessage("itemCP.tipoDocRecepCP", "icon-ok-tooltip", "Para una BOLETA DE VENTA el tipo de documento del cliente no puede ser RUC.");
              //    return;               
              //}              
          } 
      
    }else{
          var tieneExportacion = this.beanCPFisico.ind_exportacion ;
          if ( tieneExportacion==1  || estadoCP=="02" ){
          }else{
            if (tipoDoc=="-" ) { 
                this.iconTooltipMessage("itemCP.tipoDocRecepCP", "icon-ok-tooltip", "Debe seleccionar el tipo de documento.");
                return;
            } 
            var numeroDoc = dijit.byId("itemCP.numeroDocRecepCP").getValue();
            if (numeroDoc=="" ) { 
                this.iconTooltipMessage("itemCP.numeroDocRecepCP", "icon-ok-tooltip", "Debe registrar el n�mero de documento.");
                return;
            }  
            var lenDoc = numeroDoc.length;  
            if  (tipoDoc =="1") { 
                   if (lenDoc != 8){
                      this.iconTooltipMessage("itemCP.numeroDocRecepCP", "icon-ok-tooltip", "N�mero de documento inv�lido.");
                      return;
                   }
                   if (dijit.byId("itemCP.razonSocialRecepCP").getValue()==""){
                      this.iconTooltipMessage("itemCP.razonSocialRecepCP", "icon-ok-tooltip", "Debe registrar nombre.");
                      return;                  
                   }  
             }    
            if  (tipoDoc =="6") {            
                   if (lenDoc != 11){
                      this.iconTooltipMessage("itemCP.numeroDocRecepCP", "icon-ok-tooltip", "N�mero de documento inv�lido.");
                      return;
                   }
                   if (dijit.byId("itemCP.razonSocialRecepCP").getValue()==""){
                      this.iconTooltipMessage("itemCP.numeroDocRecepCP", "icon-ok-tooltip", "N�mero de RUC no existe.");
                      return;                  
                   }
            }      
            if  (tipoDoc =="0" || tipoDoc =="4" || tipoDoc =="7" || tipoDoc =="A" ) {            
                   if (dijit.byId("itemCP.razonSocialRecepCP").getValue()==""){
                      this.iconTooltipMessage("itemCP.razonSocialRecepCP", "icon-ok-tooltip", "Nombre o raz�n social inconsistente");
                      return;                  
                   }
            }      
         }          
    }	

     if (  tipoCP =="87" ||  tipoCP =="88" ){
          if (tipoCPModif =="01" || tipoCPModif =="03" || tipoCPModif =="04" || tipoCPModif =="12"){
                alert("Para Nota de cr�dito especial o Nota de d�bito especial no puede seleccionar este tipo de comprobante a modificar.")
                return;     
          } 
     }
    //Validamos las fechas
    var fechaEmision = dojo.byId("itemCP.fechaEmisionCP").value.substring(6,10) +  dojo.byId("itemCP.fechaEmisionCP").value.substring(3,5)+  dojo.byId("itemCP.fechaEmisionCP").value.substring(0,2) ;
    var ultimoDiaPeriodo = dojo.byId("itemCP.ultimoDiaPeriodo").value;
    
    if (estadoCP !="02"){
        if(fechaEmision == ""){
           this.iconTooltipMessage("itemCP.fechaEmisionCP", "icon-ok-tooltip", "Debe registrar la fecha de emisi�n.");
           return;
        }
        if(fechaEmision > ultimoDiaPeriodo){
               this.iconTooltipMessage("itemCP.fechaEmisionCP", "icon-ok-tooltip", "Fecha de emisi�n inconsistente.");
               return;
        }          
        if (estadoCP !="08" && estadoCP !="09"  ){
            if(fechaEmision > ultimoDiaPeriodo){
               this.iconTooltipMessage("itemCP.fechaEmisionCP", "icon-ok-tooltip", "Fecha de emisi�n  debe ser menor o igual al periodo informado.");
               return;
            }
            
            var periodoactual = dojo.byId("itemCP.periodoRegistroVentas").value.substring(3,7) + dojo.byId("itemCP.periodoRegistroVentas").value.substring(0,2) + "01"; 
            if(fechaEmision < periodoactual){
               this.iconTooltipMessage("itemCP.fechaEmisionCP", "icon-ok-tooltip", "Fecha de emisi�n debe estar dentro del periodo informado.");
               return;
            }             
        }else{
            var fecAjuste = new Date(dojo.byId("itemCP.periodoAjuste").value.substring(0,2) + "/01/"+dojo.byId("itemCP.periodoAjuste").value.substring(3,7));
            var mesSiguiente = fecAjuste.setMonth(fecAjuste.getMonth()+1);
            mesSiguiente = fecAjuste.setDate(1);
            mesSiguiente = fecAjuste.setDate(fecAjuste.getDate() -1);
            var fecSiguiente = new Date(mesSiguiente);
            ultimoDiaPeriodo = dojo.date.locale.format(fecSiguiente, {datePattern: "yyyyMMdd", selector: "date"});
            if(fechaEmision > ultimoDiaPeriodo){
               this.iconTooltipMessage("itemCP.fechaEmisionCP", "icon-ok-tooltip", "Fecha de emisi�n  debe ser menor o igual al periodo al que corresponde el ajuste.");
               return;
            }   
            //var periodoajust = dojo.byId("itemCP.periodoAjuste").value + "01";
            var periodoajust = dojo.byId("itemCP.periodoAjuste").value.substring(3,7) + dojo.byId("itemCP.periodoAjuste").value.substring(0,2) + "01";
            if(fechaEmision < periodoajust){
               this.iconTooltipMessage("itemCP.fechaEmisionCP", "icon-ok-tooltip", "Fecha de emisi�n debe estar dentro del periodo al que corresponde el ajuste.");
               return;
            } 
             
        }    
    }
        var fechaVencimiento = dojo.byId("itemCP.fechaVencimientoPago").value.substring(6,10) +  dojo.byId("itemCP.fechaVencimientoPago").value.substring(3,5)+  dojo.byId("itemCP.fechaVencimientoPago").value.substring(0,2) ;
        ultimoDiaPeriodo = dojo.byId("itemCP.ultimoDiaPeriodo").value;
       if (tipoCP =="14" ){
            if(fechaVencimiento == ""){
               this.iconTooltipMessage("itemCP.fechaVencimientoPago", "icon-ok-tooltip", "Debe registrar la fecha de vencimiento.");
               return;
            }
            if(fechaVencimiento < fechaEmision){
               this.iconTooltipMessage("itemCP.fechaVencimientoPago", "icon-ok-tooltip", "Fecha de vencimiento debe ser mayor o igual a la fecha de emision.");
               return;
            }   
            var fecEmisionMas10 = new Date(dojo.byId("itemCP.fechaEmisionCP").value.substring(3,5) + "/" + dojo.byId("itemCP.fechaEmisionCP").value.substring(0,2) + "/" + dojo.byId("itemCP.fechaEmisionCP").value.substring(6,10));
            var TenAniosSiguientes = fecEmisionMas10.setFullYear(fecEmisionMas10.getFullYear()+10);
            var fecSiguiente = new Date(TenAniosSiguientes);
            ultimoDiaPeriodo = dojo.date.locale.format(fecSiguiente, {datePattern: "yyyyMMdd", selector: "date"});
            if(fechaVencimiento > ultimoDiaPeriodo){
               this.iconTooltipMessage("itemCP.fechaVencimientoPago", "icon-ok-tooltip", "Fecha de vencimiento no puede ser mayor a 10 a�os despues de la fecha de emisi�n.");
               return;
            }             
       }else{
            if(fechaVencimiento != ""){
                /*if(fechaVencimiento > ultimoDiaPeriodo){
                   this.iconTooltipMessage("itemCP.fechaVencimientoPago", "icon-ok-tooltip", "Fecha de vencimiento debe ser menor o igual al periodo informado.");
                   return;
                }*/
                if(fechaVencimiento < fechaEmision){
                   this.iconTooltipMessage("itemCP.fechaVencimientoPago", "icon-ok-tooltip", "Fecha de vencimiento debe ser mayor o igual a la fecha de emision.");
                   return;
                }   
                var fecEmisionMas10 = new Date(dojo.byId("itemCP.fechaEmisionCP").value.substring(3,5) + "/" + dojo.byId("itemCP.fechaEmisionCP").value.substring(0,2) + "/" + dojo.byId("itemCP.fechaEmisionCP").value.substring(6,10));
                var TenAniosSiguientes = fecEmisionMas10.setFullYear(fecEmisionMas10.getFullYear()+10);
                var fecSiguiente = new Date(TenAniosSiguientes);
                ultimoDiaPeriodo = dojo.date.locale.format(fecSiguiente, {datePattern: "yyyyMMdd", selector: "date"});
                if(fechaVencimiento > ultimoDiaPeriodo){
                   this.iconTooltipMessage("itemCP.fechaVencimientoPago", "icon-ok-tooltip", "Fecha de vencimiento no puede ser mayor a 10 a�os despues de la fecha de emisi�n.");
                   return;
                }                               
            }
       }


        if (estadoCP !="02"){
             var tipoMoneda =dijit.byId("itemCP.tipoMoneda").getValue(); 
    				 if (this.beanCPFisico.cod_moneda != "PEN"){
    				     if (tipoMoneda == "-" ||   tipoMoneda == "-"){
                     this.iconTooltipMessage("itemCP.tipoMoneda", "icon-ok-tooltip", "Debe seleccionar el tipo de moneda.");
                     return;
              
                 }
    				 }            
             //if (tipoMoneda != "-"  && tipoMoneda != "USD" && tipoMoneda != "CAD" && tipoMoneda != "GBP" && tipoMoneda != "JPY" && tipoMoneda != "SEK" && tipoMoneda != "CHF" && tipoMoneda != "EUR"){
                  /*var valor = dojo.byId("itemCP.fechaTC").value;
                  if(valor == ""){
                     this.iconTooltipMessage("itemCP.fechaTC", "icon-ok-tooltip", "Debe registrar la fecha del tipo de cambio.");
                     return;
                  }   
                  valor = dijit.byId("itemCP.fechaTC").getValue();
                  var fechaHoy  = new Date();
                  var fechaTC  = new Date(valor); 
 
                   if (fechaTC > fechaHoy){
                      this.iconTooltipMessage("itemCP.fechaTC", "icon-ok-tooltip", "Fecha de tipo de cambio inconsistente");
                      return;
                   }*/   
                  var valor = dojo.byId("itemCP.tc").value;
                  if(valor == ""){
                     this.iconTooltipMessage("itemCP.tc", "icon-ok-tooltip", "Debe registrar tipo de cambio.");
                     return;
                  }
                  valor = dijit.byId("itemCP.tc").getValue();
                  if(valor <= 0 ){
                     this.iconTooltipMessage("itemCP.tc", "icon-ok-tooltip", "Tipo de cambio inconsistente, debe ser mayor a 0.");
                     return;
                  }
                  
                  if(valor > 99.994 ){
                     this.iconTooltipMessage("itemCP.tc", "icon-ok-tooltip", "Tipo de cambio inconsistente, debe ser menor a 99.995.");
                     return;
                  }
                  /////////////////////////////
                  /*fechaTC = dojo.byId("itemCP.fechaTC").value.substring(6,10) +  dojo.byId("itemCP.fechaTC").value.substring(3,5)+  dojo.byId("itemCP.fechaTC").value.substring(0,2) ;
                  if (estadoCP !="08" && estadoCP !="09"  ){
                      var emisionCP = dojo.byId("itemCP.fechaEmisionCP").value.substring(6,10) +  dojo.byId("itemCP.fechaEmisionCP").value.substring(3,5)+  "01";
                      if(fechaTC < emisionCP){
                         this.iconTooltipMessage("itemCP.fechaTC", "icon-ok-tooltip", "Fecha de Tipo de cambio no puede ser menor al periodo de la fecha de emision del comprobante.");
                         return;
                      }             
                  }else{
                      var fecAjuste =dojo.byId("itemCP.periodoAjuste").value + "01";
                      if(fechaTC < fecAjuste){
                         this.iconTooltipMessage("itemCP.fechaTC", "icon-ok-tooltip", "Fecha de Tipo de cambio no puede ser menor al periodo de la fecha de emision del comprobante.");
                         return;
                      }   
                  }                  */   
                  /////////////////////////////7777                                    
             //}            
        }

        //if (dojo.byId("itemCP.fechaEmisionCPModificado").value!=""){
            var ultimoDiaPeriodo = dojo.byId("itemCP.ultimoDiaPeriodo").value;
          
            if ( tipoCP =="07" ||  tipoCP =="08" || tipoCP =="87" ||  tipoCP =="88" || tipoCP =="97" ||  tipoCP =="98"){
               
               var nroSerieCPModif = dijit.byId("itemCP.numeroSerieCPModificado").getValue();
               var fechaEmisionModif =dijit.byId("itemCP.fechaEmisionCPModificado").getValue();
               
               if ( tipoCPModif =="--"){
                      this.iconTooltipMessage("itemCP.tipoCPModificado", "icon-ok-tooltip", "Debe registrar el tipo de CP a modificar.");
                     return;
               } 
                var fechaEmision = dojo.byId("itemCP.fechaEmisionCPModificado").value.substring(6,10) +  dojo.byId("itemCP.fechaEmisionCPModificado").value.substring(3,5)+  dojo.byId("itemCP.fechaEmisionCPModificado").value.substring(0,2) ;
                 if ( tipoCPModif =="01" ||  tipoCPModif =="03" || tipoCPModif =="04" ||  tipoCPModif =="06" || tipoCPModif =="16" || tipoCPModif =="23" || tipoCPModif =="07" ||  tipoCPModif =="08" || tipoCPModif =="87" ||  tipoCPModif =="88" || tipoCPModif =="97" ||  tipoCPModif =="98"){
                  if(fechaEmisionModif== null || fechaEmisionModif == ""){
                     this.iconTooltipMessage("itemCP.fechaEmisionCPModificado", "icon-ok-tooltip", "Debe registrar la fecha de emisi�n.");
                     return;
                  }
                  
                  var valor = dojo.byId("itemCP.numeroSerieCPModificado").value;
                  if(valor == ""){
                     this.iconTooltipMessage("itemCP.numeroSerieCPModificado", "icon-ok-tooltip", "N�mero de serie del CP inconsistente");
                     return;
                  }
              
                  var valorNumCP = dojo.byId("itemCP.numeroCPModificado").value;
                  if(valorNumCP == ""){
                     this.iconTooltipMessage("itemCP.numeroCPModificado", "icon-ok-tooltip", "N�mero de CP modificado inconsistente");
                     return;
                  }   
                  if (dojo.byId("itemCP.numeroSerieCPModificado").value.length != 4) { 
                     this.iconTooltipMessage("itemCP.numeroSerieCPModificado", "icon-ok-tooltip", "N�mero de serie del CP modificado inconsistente. Debe tener 4 posiciones");
                     return;
                  }
                   
                    //Validamos que exista la serie del CP que se modifica
                    if (  (nroSerieCP != "E001" && nroSerieCP != "EB01" && nroSerieCP.substring(0,1) != "F" && nroSerieCP.substring(0,1) != "B") && (tipoCP =="01" ||  tipoCP =="03" || tipoCP =="07" ||  tipoCP =="08") ){
                           var flagSalida = 0;
                           handler = dojo.xhrGet({
                                url: this.controller + "?action=validarSerieCP&nroSerieCP=" + nroSerieCPModif + "&tipoDoc=" + tipoCPModif,
                                handleAs: "json",
                                sync: true,
                                timeout: 10000
                           });       
                      
                           handler.addCallback(dojo.hitch(this, function(res){
                        		   if (res.codeError != 0) {
                                  this.iconTooltipMessage("itemCP.numeroSerieCPModificado", "icon-ok-tooltip", "N�mero de Serie no ha sido autorizada por el contribuyente.");
                                  flagSalida = 1;
                        			 }
                        		 }));
                           handler.addErrback(function(res){
                            			this.waitMessage.hide();
                            			alert("Problemas al conectarse con el servidor");
                            			return;
                           }); 
                           if (flagSalida != 0) {return;}
                    }                               
              }else{
                  if ( tipoCPModif =="12" ){
                      if(nroSerieCPModif == ""){
                         this.iconTooltipMessage("itemCP.numeroSerieCP", "icon-ok-tooltip", "Debe registrar el n�mero de serie del CP.");
                         return;
                      }
                      var valorNumCP = dojo.byId("itemCP.numeroCPModificado").value;
                      if(valorNumCP == ""){
                         this.iconTooltipMessage("itemCP.numeroCPModificado", "icon-ok-tooltip", "N�mero de CP modificado inconsistente");
                         return;
                      }                         
                  }              
              }
              if(fechaEmisionModif !=  null && fechaEmisionModif != ""){
                  fechaEmisionModif = dojo.byId("detalle.fechaEmisionCPModificado").value.substring(6,10) +  dojo.byId("detalle.fechaEmisionCPModificado").value.substring(3,5)+  dojo.byId("detalle.fechaEmisionCPModificado").value.substring(0,2) ;
                  if(fechaEmisionModif > ultimoDiaPeriodo){
                     this.iconTooltipMessage("detalle.fechaEmisionCPModificado", "icon-ok-tooltip", "Fecha de emisi�n del CP a modificar debe ser menor o igual al periodo informado.");
                     return;
                  }
                  ///YYTYYY
                  var fechaEmision = dojo.byId("generales.fechaEmisionCP").value.substring(6,10) +  dojo.byId("generales.fechaEmisionCP").value.substring(3,5)+  dojo.byId("generales.fechaEmisionCP").value.substring(0,2) ;
                  if(fechaEmisionModif > fechaEmision){
                     this.iconTooltipMessage("detalle.fechaEmisionCPModificado", "icon-ok-tooltip", "La fecha de emisi�n debe ser menor o igual a la fecha de emisi�n del CP que se modifica.");
                     return;
                  }                   
              } 
                          
            }

        //}     

   
            var montoTotalCP = dijit.byId("itemCP.importeTotalCP").getValue();
            var valor = dojo.byId("itemCP.baseImpOperacGrav").value;
            if (this.beanCPFisico.base_imponible_operacion_gravada != null && valor ==""){
               this.iconTooltipMessage("itemCP.baseImpOperacGrav", "icon-ok-tooltip", "Debe registrar Base imponible de la operaci�n .");
               return;            
            }

            if(valor != ""){
            
                valor = dijit.byId("itemCP.baseImpOperacGrav").getValue();
                if (valor <= 0.00){
                   this.iconTooltipMessage("itemCP.baseImpOperacGrav", "icon-ok-tooltip", "Base imponible de la operaci�n es inconsistente.");
                   return;            
                }   
                valor = dijit.byId("itemCP.baseImpOperacGrav").getValue();
                if (this.beanCPFisico.ind_ope_gratuitas != "1")   {              
                    if (valor > montoTotalCP){
                       this.iconTooltipMessage("itemCP.baseImpOperacGrav", "icon-ok-tooltip", "Base imponible de la operaci�n es inconsistente.");
                       return;            
                    }
                }
            }
            


            valor = dojo.byId("itemCP.valorFacturadoExportacion").value;
            var tieneExportacion = this.beanCPFisico.ind_exportacion ;
            if (tieneExportacion==1 && valor ==""){
               this.iconTooltipMessage("itemCP.valorFacturadoExportacion", "icon-ok-tooltip", "Debe registrar  el valor facturado de la exportaci�n.");
               return;
            }  
            var valorEmb = dojo.byId("itemCP.valorEmbarcadoExportacion").value; 
            //if(tieneExportacion==1  && valorEmb == "" && (tipoCP == "51" || tipoCP == "52")){
            //   this.iconTooltipMessage("itemCP.valorEmbarcadoExportacion", "icon-ok-tooltip", "Debe registrar  el valor embarcado de la exportaci�n.");
            //   return;
            //}        
            if (valorEmb ==""){ valorEmb = 0;}               
            if(valor != ""){
                valor = dijit.byId("itemCP.valorFacturadoExportacion").getValue();
                if (valor <= 0.00){
                   this.iconTooltipMessage("itemCP.valorFacturadoExportacion", "icon-ok-tooltip", "Importe total del valor facturado de la exportaci�n debe ser mayor a 0.00");
                   return;            
                }   
                if (this.beanCPFisico.ind_ope_gratuitas != "1")   {              
                    if (valor > montoTotalCP){
                       this.iconTooltipMessage("itemCP.valorFacturadoExportacion", "icon-ok-tooltip", "Importe total del valor facturado de la exportaci�n es inconsistente.");
                       return;            
                    }
                    //if (valorEmb > montoTotalCP){
                    //   this.iconTooltipMessage("detalle.valorEmbarcadoExportacion", "icon-ok-tooltip", "Importe total del valor embarcado de la exportaci�n es inconsistente.");
                    //   return;            
                    //}                    
                }                                

            }

            //valor2 = dojo.byId("itemCP.valorEmbarcadoExportacion").value;
            //if (tieneExportacion==1 && valor2 ==""){
            //   this.iconTooltipMessage("itemCP.valorEmbarcadoExportacion", "icon-ok-tooltip", "Debe registrar  el valor embarcado de la exportaci�n.");
            //   return;
            //}  
            //if(valor2 != ""){
            //    valor2 = dijit.byId("itemCP.valorEmbarcadoExportacion").getValue();
            //    if (valor2 <= 0.00){
            //       this.iconTooltipMessage("itemCP.valorEmbarcadoExportacion", "icon-ok-tooltip", "Importe total del valor embarcado de la exportaci�n debe ser mayor a 0.00");
            //       return;            
            //    }   
            //    if (this.beanCPFisico.ind_ope_gratuitas != "1")   {              
            //        if (valor2 > montoTotalCP){
            //           this.iconTooltipMessage("itemCP.valorEmbarcadoExportacion", "icon-ok-tooltip", "Importe total del valor embarcado de la exportaci�n es inconsistente.");
            //           return;            
            //        }
            //    }                                

            //}
            valor = dojo.byId("itemCP.importeOperacionExonerada").value;
            if(valor != ""){
                valor = dijit.byId("itemCP.importeOperacionExonerada").getValue();
                if (this.beanCPFisico.ind_ope_gratuitas != "1")   {              
                    if (valor > montoTotalCP){
                       this.iconTooltipMessage("itemCP.importeOperacionExonerada", "icon-ok-tooltip", "Importe total de la operaci�n exonerada es inconsistente.");
                       return;            
                    }
                }                 

            }


            valor = dojo.byId("itemCP.importeOperacionInafecta").value;
            if(valor != ""){
                valor = dijit.byId("itemCP.importeOperacionInafecta").getValue();
 
                if (this.beanCPFisico.ind_ope_gratuitas != "1")   {              
                    if (valor > montoTotalCP){
                       this.iconTooltipMessage("itemCP.importeOperacionInafecta", "icon-ok-tooltip", "Importe total de la operaci�n inafecta es inconsistente.");
                       return;            
                    }  
                }                   
            }

            valor = dojo.byId("itemCP.isc").value;
            if(valor != ""){
                valor = dijit.byId("itemCP.isc").getValue();
  
                if (this.beanCPFisico.ind_ope_gratuitas != "1")   {              
                    if (valor > montoTotalCP){
                       this.iconTooltipMessage("itemCP.isc", "icon-ok-tooltip", "ISC es inconsistente.");
                       return;            
                    } 
                }                
            }
         
              valor = dojo.byId("itemCP.igvoipm").value;
              if(valor == "" && this.beanCPFisico.igv_ipm != null){
                 this.iconTooltipMessage("itemCP.igvoipm", "icon-ok-tooltip", "Debe seleccionar IGV y/o IPM .");
                 return;
              }  


            dijit.byId("itemCP.igvoipm").constraints = {min:0,places:2};
            dijit.byId("itemCP.baseImpOperacGrav").constraints = {min:0,places:2};
            valor = dojo.byId("itemCP.igvoipm").value;
////////////////
            var porcentaje = dojo.byId("itemCP.tasasIgvIpm").value;
            var base = dojo.byId("itemCP.baseImpOperacGrav").value;
            var total = 0;

  						if (this.beanCPFisico.tasa_igv_ipm != null){
  						    if (porcentaje==""){
                     this.iconTooltipMessage("itemCP.tasasIgvIpm", "icon-ok-tooltip", "Debe seleccionar porcentaje de IGV.");
                     return;      
                  }
              }
                          
             if (porcentaje != "" && base != ""){
                porcentaje = dijit.byId("itemCP.tasasIgvIpm").getValue();
                base = dijit.byId("itemCP.baseImpOperacGrav").getValue();
                total = porcentaje * base;
                if (total > 0 ) { total = total / 100;}
                total = this.roundNumber(total,2);

             }   

             if ((porcentaje == "" && valor != "") || (porcentaje != "" && valor == "") ){
                      if (!confirm("Valor consignado no corresponde a la tasa de IGV y/o IPM seleccionada. Desea grabar la modificaci�n?")){
                         grabar = false;
                        return;
                      }             
             }

             valor = dijit.byId("itemCP.igvoipm").getValue();
             if (porcentaje != "" || base != ""){
                  if (total != valor){
                      if (!confirm("Valor consignado no corresponde a la tasa de IGV y/o IPM seleccionada. Desea grabar la modificaci�n?")){
                         grabar = false;
                        return;
                      }
                  } 
              }  

          
            if(valor != ""){
                valor = dijit.byId("itemCP.igvoipm").getValue();

                if (this.beanCPFisico.ind_ope_gratuitas != "1")   {              
                    if (valor > montoTotalCP){
                       this.iconTooltipMessage("itemCP.igvoipm", "icon-ok-tooltip", "IGV y/o IPM es inconsistente");
                       return;            
                    } 
                }                  
            }   
            
            var tipoCP = dijit.byId("itemCP.tipoCP").getValue().substring(0,2);

            var valor = dojo.byId("itemCP.baseImponibleIvap").value;
            if (tipoCP == "40") {
                if(valor == ""){
                   this.iconTooltipMessage("itemCP.baseImponibleIvap", "icon-ok-tooltip", "Debe registrar Base imponible de la operaci�n gravada con el IVAP.");
                   return;
                }
                valor = dijit.byId("itemCP.baseImponibleIvap").getValue();

                if (this.beanCPFisico.ind_ope_gratuitas != "1")   {              
                    if (valor > montoTotalCP){
                       this.iconTooltipMessage("itemCP.baseImponibleIvap", "icon-ok-tooltip", "Base imponible de la operaci�n gravada con el IVAP es inconsistente");
                       return;            
                    }  
                }                                       
                valor = dojo.byId("itemCP.ivap").value;
                if(valor == ""){
                   this.iconTooltipMessage("itemCP.ivap", "icon-ok-tooltip", "Debe registrar IVAP.");
                   return;
                }
                valor = dijit.byId("itemCP.ivap").getValue();
  
                if (this.beanCPFisico.ind_ope_gratuitas != "1")   {              
                    if (valor > montoTotalCP){
                       this.iconTooltipMessage("itemCP.ivap", "icon-ok-tooltip", "IVAP es inconsistente.");
                       return;            
                    }   
                }                                
            }else{
                var valor2 =  dojo.byId("itemCP.ivap").value;
                if(valor != "" || valor2 != ""){
                    if(valor == ""){
                       this.iconTooltipMessage("itemCP.baseImponibleIvap", "icon-ok-tooltip", "Debe registrar Base imponible de la operaci�n gravada con el IVAP.");
                       return;
                    }       
                    valor = dijit.byId("itemCP.baseImponibleIvap").getValue();    

                    if (this.beanCPFisico.ind_ope_gratuitas != "1")   {              
                        if (valor > montoTotalCP){
                           this.iconTooltipMessage("itemCP.baseImponibleIvap", "icon-ok-tooltip", "Base imponible de la operaci�n gravada con el IVAP es inconsistente");
                           return;            
                        }      
                    }                                      
                    if(valor2 == ""){
                       this.iconTooltipMessage("itemCP.ivap", "icon-ok-tooltip", "Debe registrar IVAP.");
                       return;
                    }
                    valor2 = dijit.byId("itemCP.ivap").getValue();


                    if (this.beanCPFisico.ind_ope_gratuitas != "1")   {              
                      if (valor2 > montoTotalCP){
                         this.iconTooltipMessage("itemCP.ivap", "icon-ok-tooltip", "IVAP es inconsistente.");
                         return;            
                      }   
                    }                     
                }
            }

            if (estadoCP!="02"){
                if (dojo.style(dojo.byId("itemCP.operacionesGratuitas.show"), "display") == "none"){
                  
                }else{
                      var bTodoBlanco = true;
                      var bMayor0 = false;
                      var valor = dojo.byId("itemCP.grabadoPremio").value;
                      var monto = dijit.byId("itemCP.grabadoPremio").getValue();
                      if(valor != ""){
                          bTodoBlanco = false;
                          if (monto > 0){ bMayor0 = true;}
          
                      }
                      valor = dojo.byId("itemCP.grabadoDonacion").value;
                      monto = dijit.byId("itemCP.grabadoDonacion").getValue();
                      if(valor != ""){
                          bTodoBlanco = false;
                          if (monto > 0){ bMayor0 = true;}
          
                      }       
                      valor = dojo.byId("itemCP.grabadoEntregaTrabajadores").value;
                      monto = dijit.byId("itemCP.grabadoEntregaTrabajadores").getValue();
                      if(valor != ""){
                          bTodoBlanco = false;
                          if (monto > 0){ bMayor0 = true;}
          
                      }                  
                      valor = dojo.byId("itemCP.grabadoPublicidad").value;
                      monto = dijit.byId("itemCP.grabadoPublicidad").getValue();
                      if(valor != ""){
                          bTodoBlanco = false;
                          if (monto > 0){ bMayor0 = true;}
          
                      }  
                      valor = dojo.byId("itemCP.grabadoBonificacion").value;
                      monto = dijit.byId("itemCP.grabadoBonificacion").getValue();
                      if(valor != ""){
                          bTodoBlanco = false;
                          if (monto > 0){ bMayor0 = true;}
          
                      }       
                      valor = dojo.byId("itemCP.grabadoRetiroOtros").value;
                      monto = dijit.byId("itemCP.grabadoRetiroOtros").getValue();
                      if(valor != ""){
                          bTodoBlanco = false;
                          if (monto > 0){ bMayor0 = true;}
          
                      }  
                      valor = dojo.byId("itemCP.valorFacturaExportaNoOnerosa").value;
                      monto = dijit.byId("itemCP.valorFacturaExportaNoOnerosa").getValue();
                      if(valor != ""){
                          bTodoBlanco = false;
                          if (monto > 0){ bMayor0 = true;}
          
                      }                    
                      valor = dojo.byId("itemCP.importeOperacionNoOnerosaExo").value;
                      monto = dijit.byId("itemCP.importeOperacionNoOnerosaExo").getValue();
                      if(valor != ""){
                          bTodoBlanco = false;
                          if (monto > 0){ bMayor0 = true;}
          
                      } 
                      valor = dojo.byId("itemCP.inafectoPremio").value;
                      monto = dijit.byId("itemCP.inafectoPremio").getValue();
                      if(valor != ""){
                          bTodoBlanco = false;
                          if (monto > 0){ bMayor0 = true;}
          
                      } 
                      valor = dojo.byId("itemCP.inafectoPublicidad").value;
                      monto = dijit.byId("itemCP.inafectoPublicidad").getValue();
                      if(valor != ""){
                          bTodoBlanco = false;
                          if (monto > 0){ bMayor0 = true;}
          
                      }                         
                      valor = dojo.byId("itemCP.inafectoBonificacion").value;
                      monto = dijit.byId("itemCP.inafectoBonificacion").getValue();
                      if(valor != ""){
                          bTodoBlanco = false;
                          if (monto > 0){ bMayor0 = true;}
          
                      }   
                      valor = dojo.byId("itemCP.inafectoRetiroConvenioColectivo").value;
                      monto = dijit.byId("itemCP.inafectoRetiroConvenioColectivo").getValue();
                      if(valor != ""){
                          bTodoBlanco = false;
                          if (monto > 0){ bMayor0 = true;}
          
                      }   
                      valor = dojo.byId("itemCP.inafectoMuestrasMedicas").value;
                      monto = dijit.byId("itemCP.inafectoMuestrasMedicas").getValue();
                      if(valor != ""){
                          bTodoBlanco = false;
                          if (monto > 0){ bMayor0 = true;}
          
                      }                           
                      valor = dojo.byId("itemCP.inafectoRetiroOtros").value;
                      monto = dijit.byId("itemCP.inafectoRetiroOtros").getValue();
                      if(valor != ""){
                          bTodoBlanco = false;
                          if (monto > 0){ bMayor0 = true;}
          
                      }  
                      if (bTodoBlanco){
                          this.iconTooltipMessage("itemCP.grabadoPremio", "icon-ok-tooltip", "Debe registrar por lo menos unos de los montos.");
                         return;
                      }  
                      if (!bMayor0){
                          this.iconTooltipMessage("itemCP.grabadoPremio", "icon-ok-tooltip", "Por lo menos uno de los montos debe ser mayor a 0.");
                         return;
                      }    
                }                                                                
            }   

        var tipoCPModif = dijit.byId("itemCP.tipoCPModificado").getValue().substring(0,2);
        var tipoDoc = dijit.byId("itemCP.tipoDocRecepCP").getValue();
        if ( ( tipoCP =="00" || tipoCP =="03" ||  tipoCP =="05" ||  tipoCP =="06"||  tipoCP =="07"||  tipoCP =="08"||  tipoCP =="11" ||
              tipoCP =="12" ||  tipoCP =="13" ||  tipoCP =="14"||  tipoCP =="15"||  tipoCP =="16"||  tipoCP =="18" || 
              tipoCP =="19" ||  tipoCP =="23" ||  tipoCP =="26"||  tipoCP =="28"||  tipoCP =="30"||  tipoCP =="34" ||
              tipoCP =="35" ||  tipoCP =="36" ||  tipoCP =="37"|| tipoCP =="49" || tipoCP =="55"||  tipoCP =="56"||  tipoCP =="87" ||
              tipoCP =="88" ) ||  ( ( tipoCP =="97" ||  tipoCP =="98") && (tipoCPModif =="03" || tipoCPModif =="12" || tipoCPModif =="13" || tipoCPModif =="14" || tipoCPModif =="36") ) ){

              if (tipoDoc!="-" && tipoDoc!="" ) { 
                  var numeroDoc = dojo.byId("itemCP.numeroDocRecepCP").value;
                  if (numeroDoc=="" ) { 
                      alert("Debe registrar el numero de documento del cliente.")
                      return;
                  }  
                  var lenDoc = numeroDoc.length;  
                  if  (tipoDoc =="1") { 
                         if (lenDoc != 8){
                            alert("Numero de documento del cliente inv�lido")
                            return;
                         }
                         if (dojo.byId("itemCP.razonSocialRecepCP").value==""){
                            alert("Debe registrar nombre del cliente.")
                            return;                  
                         }  
                   }    
                  if  (tipoDoc =="6") {            
                         if (lenDoc != 11){
                            alert("Numero de documento del cliente inv�lido")
                            return;
                         }
                         if (dojo.byId("itemCP.razonSocialRecepCP").value==""){
                            alert("Numero de RUC del cliente no existe.")
                            return;                  
                         }
                  }      
                  if  (tipoDoc =="0" || tipoDoc =="4" || tipoDoc =="7" || tipoDoc =="A" ) {            
                         if (dojo.byId("itemCP.razonSocialRecepCP").value==""){
                            alert("Nombre o Razon Social del cliente es inconsistente.")
                            return;                  
                         }
                  }  
              } 
      
        } else{
           var tieneExportacion = this.beanCPFisico.ind_exportacion ;
           if ( tieneExportacion==1 || estadoCP=="02" ){
          }else{
                if (tipoDoc=="-" ) { 
                    alert("Debe seleccionar el tipo de documento del cliente.");
                    return;
                } 
                 var numeroDoc = dojo.byId("itemCP.numeroDocRecepCP").value;
                  if (numeroDoc=="" ) { 
                      alert("Debe registrar el numero de documento del cliente.")
                      return;
                  }  
                  var lenDoc = numeroDoc.length;  
                  if  (tipoDoc =="1") { 
                         if (lenDoc != 8){
                            alert("Numero de documento del cliente inv�lido")
                            return;
                         }
                         if (dojo.byId("itemCP.razonSocialRecepCP").value==""){
                            alert("Debe registrar nombre del cliente.")
                            return;                  
                         }  
                   }    
                  if  (tipoDoc =="6") {            
                         if (lenDoc != 11){
                            alert("Numero de documento del cliente inv�lido")
                            return;
                         }
                         if (dojo.byId("itemCP.razonSocialRecepCP").value==""){
                            alert("Numero de RUC del cliente no existe.")
                            return;                  
                         }
                  }      
                  if  (tipoDoc =="0" || tipoDoc =="4" || tipoDoc =="7" || tipoDoc =="A" ) {            
                         if (dojo.byId("itemCP.razonSocialRecepCP").value==""){
                            alert("Nombre o Razon Social del cliente es inconsistente.")
                            return;                  
                         }
                  }  
             }        
        }       
        
            valor = dojo.byId("itemCP.tributosCargosNoBaseImp").value;
            if(valor != ""){
            valor = dijit.byId("itemCP.tributosCargosNoBaseImp").getValue();

                if (this.beanCPFisico.ind_ope_gratuitas != "1")   {              
                    if (valor > montoTotalCP){
                       this.iconTooltipMessage("itemCP.tributosCargosNoBaseImp", "icon-ok-tooltip", "Otros tributos y cargos que no forman parte de la base imponible es inconsistente.");
                       return;            
                    }     
                }                 
            }


        var valorTotal = dojo.byId("itemCP.importeTotalCP").value;
        if(valorTotal == "" && estadoCP!="02"){
           this.iconTooltipMessage("itemCP.importeTotalCP", "icon-ok-tooltip", "Debe registrar Importe total del CP .");
           return;
        }
    ///////////////////////
         if(valorTotal != "" && estadoCP!="02"){   
            var valorFactExporta = dojo.byId("itemCP.valorFacturadoExportacion").value;
          var baseImpOperacGrav = dojo.byId("itemCP.baseImpOperacGrav").value;
          var importOperacExonerada= dojo.byId("itemCP.importeOperacionExonerada").value;
          var importOperacInafecta = dojo.byId("itemCP.importeOperacionInafecta").value;
          var mtoISC = dojo.byId("itemCP.isc").value;                              
          var mtoIGV = dojo.byId("itemCP.igvoipm").value;
          var baseImpIvap = dojo.byId("itemCP.baseImponibleIvap").value;                              
          var mtoIvap = dojo.byId("itemCP.ivap").value;
          var otroTributosNoFormanBaseImp = dojo.byId("itemCP.tributosCargosNoBaseImp").value;                              
          if (valorFactExporta!=""){ 
              valorFactExporta = dijit.byId("itemCP.valorFacturadoExportacion").getValue();}
          else {valorFactExporta = 0;}  
          if (baseImpOperacGrav!=""){ 
              baseImpOperacGrav = dijit.byId("itemCP.baseImpOperacGrav").getValue();}
          else {baseImpOperacGrav = 0;}  
          if (importOperacExonerada!=""){ 
              importOperacExonerada = dijit.byId("itemCP.importeOperacionExonerada").getValue();}
          else {importOperacExonerada = 0;}  
          if (importOperacInafecta!=""){ 
              importOperacInafecta = dijit.byId("itemCP.importeOperacionInafecta").getValue();}
          else {importOperacInafecta = 0;}  
          if (mtoISC!=""){ 
              mtoISC = dijit.byId("itemCP.isc").getValue();}
          else {mtoISC = 0;} 
          if (mtoIGV!=""){ 
              mtoIGV = dijit.byId("itemCP.igvoipm").getValue();}
          else {mtoIGV = 0;}  
          if (baseImpIvap!=""){ 
              baseImpIvap = dijit.byId("itemCP.baseImponibleIvap").getValue();}
          else {baseImpIvap = 0;}  
          if (mtoIvap!=""){ 
              mtoIvap = dijit.byId("itemCP.ivap").getValue();}
          else {mtoIvap = 0;}  
          if (otroTributosNoFormanBaseImp!=""){ 
              otroTributosNoFormanBaseImp = dijit.byId("itemCP.tributosCargosNoBaseImp").getValue();}
          else {otroTributosNoFormanBaseImp = 0;}  
         
          valorTotal = dijit.byId("itemCP.importeTotalCP").getValue();     
          if ((this.beanCPFisico.mto_importe_total > 0) && (valorTotal ==0)){
              this.iconTooltipMessage("itemCP.importeTotalCP", "icon-ok-tooltip", "Importe total del CP debe ser mayor a 0.");
              return;
          }                       
          var total = 0;
          total =  valorFactExporta + baseImpOperacGrav+ importOperacExonerada+ importOperacInafecta+ mtoISC+    mtoIGV + baseImpIvap +   mtoIvap+otroTributosNoFormanBaseImp;
          total =  valorFactExporta + baseImpOperacGrav+ importOperacExonerada+ importOperacInafecta+ mtoISC+    mtoIGV + baseImpIvap +   mtoIvap+otroTributosNoFormanBaseImp;
          total = this.roundNumber(total,2);
          if (total != 0  ){
             if (total != valorTotal){
                      if (!confirm("Valor consignado en el importe total no corresponde a la suma de los montos registrados. Desea grabar la modificaci�n?")){
                         grabar = false;
                        return;
                      } 
             }   
            
          }
        }    
    //////////////////////////77     
        if ( (tipoCP =="03" || tipoCP =="12") && valorTotal > 700){
           if (tipoDoc=="-" ) { 
                alert("Debe seleccionar el tipo de documento del cliente.");
                return;
            } 
             var numeroDoc = dojo.byId("itemCP.numeroDocRecepCP").value;
              if (numeroDoc=="" ) { 
                  alert("Debe registrar el numero de documento del cliente.")
                  return;
              }  
              var lenDoc = numeroDoc.length;  
              if  (tipoDoc =="1") { 
                     if (lenDoc != 8){
                        alert("Numero de documento del cliente inv�lido")
                        return;
                     }
                     if (dojo.byId("itemCP.razonSocialRecepCP").value==""){
                        alert("Debe registrar nombre del cliente.")
                        return;                  
                     }  
               }    
              if  (tipoDoc =="6") {            
                     if (lenDoc != 11){
                        alert("Numero de documento del cliente inv�lido")
                        return;
                     }
                     if (dojo.byId("itemCP.razonSocialRecepCP").value==""){
                        alert("Numero de RUC del cliente no existe.")
                        return;                  
                     }
              }      
              if  (tipoDoc =="0" || tipoDoc =="4" || tipoDoc =="7" || tipoDoc =="A" ) {            
                     if (dojo.byId("itemCP.razonSocialRecepCP").value==""){
                        alert("Nombre o Razon Social del cliente es inconsistente.")
                        return;                  
                     }
              }              
        }
        
        if (grabar == false){return;}
        
        dijit.byId("itemCP.razonSocialRecepCP2").setValue(dijit.byId("itemCP.razonSocialRecepCP").getValue());
        if (confirm("Confirme si desea registrar las modificaciones realizadas")){
        		var nbControl = dijit.byId("itemCP.botonRegistrar");
        		nbControl.setAttribute('disabled', true);
             	//this.wait("Modificacion en Proceso...", "95px", 200);
          		var handler = dojo.io.iframe.send({
          			url: this.controller,
          			handleAs: "json",
          			sync: true,
          			timeout: 10000,
          			preventCache: true,
          			form: "itemCP.form"
          		});
          		
          		handler.addCallback(dojo.hitch(this, function(res){
            		  this.waitMessage.hide();
            		  nbControl.setAttribute('disabled', false);
            			if(res.codeError == 0) {
                         dijit.byId("itemCP.tipoDocRecepCP").attr('disabled', true) ;  
                          dijit.byId("itemCP.numeroDocRecepCP").attr('disabled', true) ;  
                          dijit.byId("itemCP.razonSocialRecepCP").attr('disabled', true) ;
                          dijit.byId("itemCP.fechaEmisionCP").attr('disabled', true) ;
                          dijit.byId("itemCP.fechaVencimientoPago").attr('disabled', true) ;
                          //dijit.byId("itemCP.numeroSerieMaqRegistra").attr('disabled', true) ;
                          dijit.byId("itemCP.tipoMoneda").attr('disabled', true) ;
                          //dijit.byId("itemCP.fechaTC").attr('disabled', true) ;       
                          dijit.byId("itemCP.tc").attr('disabled', true) ;
                          dijit.byId("itemCP.valorFacturadoExportacion").attr('disabled', true) ;
                          dijit.byId("itemCP.valorEmbarcadoExportacion").attr('disabled', true) ;
                          dijit.byId("itemCP.baseImpOperacGrav").attr('disabled', true) ;
                          dijit.byId("itemCP.importeOperacionExonerada").attr('disabled', true) ;
                          dijit.byId("itemCP.importeOperacionInafecta").attr('disabled', true) ;
                          dijit.byId("itemCP.isc").attr('disabled', true) ;              
                          dijit.byId("itemCP.tasasIgvIpm").attr('disabled', true) ;
                          dijit.byId("itemCP.igvoipm").attr('disabled', true) ;
                          dijit.byId("itemCP.baseImponibleIvap").attr('disabled', true) ;
                          dijit.byId("itemCP.ivap").attr('disabled', true) ;
                          dijit.byId("itemCP.tributosCargosNoBaseImp").attr('disabled', true) ;
                          dijit.byId("itemCP.importeTotalCP").attr('disabled', true) ; 
                          dijit.byId("itemCP.grabadoPremio").attr('disabled', true) ; 
                          dijit.byId("itemCP.grabadoDonacion").attr('disabled', true) ; 
                          dijit.byId("itemCP.grabadoEntregaTrabajadores").attr('disabled', true) ; 
                          dijit.byId("itemCP.grabadoPublicidad").attr('disabled', true) ; 
                          dijit.byId("itemCP.grabadoBonificacion").attr('disabled', true) ; 
                          dijit.byId("itemCP.grabadoRetiroOtros").attr('disabled', true) ; 
                          dijit.byId("itemCP.valorFacturaExportaNoOnerosa").attr('disabled', true) ; 
                          dijit.byId("itemCP.importeOperacionNoOnerosaExo").attr('disabled', true) ; 
                          dijit.byId("itemCP.inafectoPremio").attr('disabled', true) ; 
                          dijit.byId("itemCP.inafectoPublicidad").attr('disabled', true) ; 
                          dijit.byId("itemCP.inafectoBonificacion").attr('disabled', true) ; 
                          dijit.byId("itemCP.inafectoRetiroConvenioColectivo").attr('disabled', true) ; 
                          dijit.byId("itemCP.inafectoMuestrasMedicas").attr('disabled', true) ; 
                          dijit.byId("itemCP.inafectoRetiroOtros").attr('disabled', true) ; 
                          dijit.byId("itemCP.fechaEmisionCPModificado").attr('disabled', true) ;  
                          dijit.byId("itemCP.tipoCPModificado").attr('disabled', true) ;  
                          dijit.byId("itemCP.numeroSerieCPModificado").attr('disabled', true) ; 
                          dijit.byId("itemCP.numeroCPModificado").attr('disabled', true) ;       
                          dijit.byId("itemCP.descBaseImponible").attr('disabled', true) ;   
                          dijit.byId("itemCP.descuentoIgvoipm").attr('disabled', true) ;
                          dijit.byId("itemCP.contratoColaboracion").attr('disabled', true) ;
                          dijit.byId("itemCP.medioDePago1").attr('disabled', true) ;
                          dijit.byId("itemCP.medioDePago0").attr('disabled', true) ;                              
                            var bOcultar= true;
                           if ((this.beanCPFisico.gravado_premio != null && this.beanCPFisico.gravado_premio != "") || (this.beanCPFisico.ind_importacion =="1") )
                           {
                                bOcultar= false;
                           }     
                           if ((this.beanCPFisico.gravado_donacion != null && this.beanCPFisico.gravado_donacion != "") || (this.beanCPFisico.ind_importacion =="1") )
                           {
                                bOcultar= false;
                           }        
                           if ((this.beanCPFisico.gravado_entrega_trabajadores != null && this.beanCPFisico.gravado_entrega_trabajadores != "") || (this.beanCPFisico.ind_importacion =="1") )
                           {
                                bOcultar= false;
                           }        
                           if ((this.beanCPFisico.gravado_publicidad != null && this.beanCPFisico.gravado_publicidad != "") || (this.beanCPFisico.ind_importacion =="1") )
                           {
                                bOcultar= false;
                           } 
                           if ((this.beanCPFisico.gravado_bonificacion != null && this.beanCPFisico.gravado_bonificacion != "") || (this.beanCPFisico.ind_importacion =="1") )
                           {
                                bOcultar= false;
                           }     
                           if ((this.beanCPFisico.gravado_retiro_otros != null && this.beanCPFisico.gravado_retiro_otros != "") || (this.beanCPFisico.ind_importacion =="1") )
                           {
                                bOcultar= false;
                           }        
                           if ((this.beanCPFisico.valor_facturado_exportacion_no_onerosa != null && this.beanCPFisico.valor_facturado_exportacion_no_onerosa != "") || (this.beanCPFisico.ind_importacion =="1") )
                           {
                                bOcultar= false;
                           }        
                           if ((this.beanCPFisico.importe_total_operacion_no_onerosa != null && this.beanCPFisico.importe_total_operacion_no_onerosa != "") || (this.beanCPFisico.ind_importacion =="1") )
                           {
                                bOcultar= false;
                           } 
                          if ((this.beanCPFisico.inafecto_premio != null && this.beanCPFisico.inafecto_premio != "") || (this.beanCPFisico.ind_importacion =="1") )
                           {
                                bOcultar= false;
                           }     
                           if ((this.beanCPFisico.inafecto_publicidad != null && this.beanCPFisico.inafecto_publicidad != "") || (this.beanCPFisico.ind_importacion =="1") )
                           {
                                bOcultar= false;
                           }        
                           if ((this.beanCPFisico.inafecto_bonificacion != null && this.beanCPFisico.inafecto_bonificacion != "") || (this.beanCPFisico.ind_importacion =="1") )
                           {
                                bOcultar= false;
                           }        
                           if ((this.beanCPFisico.inafecto_retiro_convenio_colectivo != null && this.beanCPFisico.inafecto_retiro_convenio_colectivo != "") || (this.beanCPFisico.ind_importacion =="1") )
                           {
                                bOcultar= false;
                           } 
                           if ((this.beanCPFisico.inafecto_muestras_medicas != null && this.beanCPFisico.inafecto_muestras_medicas != "") || (this.beanCPFisico.ind_importacion =="1") )
                           {
                                bOcultar= false;
                           }     
                           if ((this.beanCPFisico.inafecto_retiro_otros != null && this.beanCPFisico.inafecto_retiro_otros != "") || (this.beanCPFisico.ind_importacion =="1") )
                           {
                                bOcultar= false;
                           }  
                           if (bOcultar){
                              this.showHiddenDiv(document.getElementById("itemCP.operacionesGratuitas.show"),false);
                           } else{
                               this.showHiddenDiv(document.getElementById("itemCP.operacionesGratuitas.show"),true);
                           }          
                          this.showHiddenDiv(document.getElementById("itemCP.botonesRVI.show"),true);
                          this.showHiddenDiv(document.getElementById("itemCP.botonesRVI2.show"),true);
                          this.showHiddenDiv(document.getElementById("itemCP.botonRVISalir.show"),true);
                          this.showHiddenDiv(document.getElementById("itemCP.botonesRVIModif.show"),false);            			    
            			    this.dialogCP.hide();
            			    alert("Registro del CP actualizado se realiz� satisfactoriamente");
            			    
/////
                  		handler2= dojo.xhrGet({
                          url: this.controller + "?action=getComprobantesFisicos&periodo=" + dojo.byId("global.periodo").value,
                          handleAs: "json",
          			         	preventCache: true,
                          sync: true,
                          timeout: 10000
                      });
                    		
                    	
                			handler2.addCallback(dojo.hitch(this, function(res2){
                				if(res2.codeError == 0) {
                					if (res2.data != null &&  res2.data  != "") {
                    					  	var data = eval("(" + res2.data + ")");		
                      						this.store = new dojo.data.ItemFileWriteStore({data: {identifier: 'id', items: data}});
                      			    	var grid = dijit.byId("fisico.fisicosGrid");
                      						grid.setStore(this.store);
                      						grid.startup(); 
                					}
                				} else {
                					  alert(res.messageError);
                					  return;
                				}
                			}));
              			
                			handler2.addErrback(dojo.hitch(this, function(res2) {
                    			this.waitMessage.hide();
                				  alert("Ocurrio un error al momento de ejecutar la consulta.");
                				  return
                			}));
/////
		
            			}
            			else {
            				nbControl.attr('disabled', false);
            				this.messageBox(res.data);	
            			}
          		}));			
          			
          		handler.addErrback(function(res){
          			nbControl.attr('disabled', false);
          			this.waitMessage.hide();
          			this.messageBox("Problemas al conectarse con el servidor");
          		});
        
        
            
        }

   }catch(error){
  txt="There was an error on this page.\n\n";
  txt+="Error description: " + error.message + "\n\n";
  txt+="Click OK to continue.\n\n";
  alert(txt);
   }
//////////////////////////
	},
        	
      wait: function(message, width) {
    		dojo.byId("waitMessage").innerHTML="<div class='dijitInline box-message'></div><div class='dijitInline'>&nbsp;" + message + "...</div>";
    	    dojo.byId("waitMessage").style.width = width;
    	    this.waitMessage.show();
    	},
    	
    	
    	messageBoxError: function(message, iconClass) {
    		var dialog = dijit.byId("dialogError");
    		if(dialog) {
    			dojo.byId("alertMessage").innerHTML=this.chunkString(message, 40);
    			if(iconClass) dojo.addClass("alertIcon", iconClass);
    			else dojo.addClass("alertIcon", "icon-alert-error");
    			dijit.byId('dialogError').domNode.style.visibility = "visible";

    			dialog.show();
    		}
    	},    	
    	
    	chunkString: function(cad, size) {
    		var aCad = cad.split(" ");
    		for(i = 0; i < aCad.length; i++) {
    			if(aCad[i].length > size) {
    				return this.wordWrap(cad, size, "<br/>", 2);
    			}
    		}
    		return cad;
    	},

      mostrarFiltro: function(){
    			var handler = dojo.xhrGet({
    				preventCache:  false,
    				url: this.controller + "?action=dataCriterios",
    				handleAs: "json",
    				sync: true,
    				timeout: 10000
    			});    		
        		
    			handler.addCallback(dojo.hitch(this, function(res){
    				this.waitMessage.hide();
    				if(res.codeError == 0) {
    					this.content.onLoad = dojo.hitch(this, function(){
    
    					});
    					this.content.setHref(this.controller + "?action=backCriterios&preventCache=" + this.preventCache());					
    				} else {
    					alert(res.messageError);
    				}
    			}));
    			handler.addErrback(dojo.hitch(this, function(res) {
        			this.waitMessage.hide();
    				alert("Ocurrio un error al momento de ejecutar la consulta.");
    			}));    		
        },

        salirConsulta: function(){
        	if (confirm("\xbf Desea salir de la Aplicaci\xf3n?.")) {
        		this.cerrarConsulta();
        	}
        },

        salirListado: function(){
        	if (confirm("\xbf Desea salir del listado ?.")) {
        		this.cerrarConsulta();
        	}
        },        

        cerrarConsulta: function(){
            dijit.byId('dialogOkCancel').hide();
            this.mostrarFiltro();
         },
         
         
     	preventCache: function() {
     		return new Date().valueOf();
     	},
  
     showHiddenDiv: function(node,show) {
     	if (show == true) { //Mostrar
	       node.style.display = "";
      } else { //Ocultar
        	node.style.display = "none";
     	}
    },
   
    calcularIgvIpm: function() {
       var porcentaje = dijit.byId("itemCP.tasasIgvIpm").value;
       var valor = dijit.byId("itemCP.baseImpOperacGrav").value;
       var total = 0;
       if (porcentaje != "" && valor != ""){
          total = porcentaje * valor;
          if (total > 0 ) { total = total / 100;}
          dijit.byId("itemCP.igvoipm").setValue(total);
          dijit.byId("itemCP.igvoipm").constraints = {min:0,places:2};
       }else{
          return;
       }
       
    }, 
    
         calcularMontoTotalCP: function() {
          var valorFactExporta = dojo.byId("itemCP.valorFacturadoExportacion").value;
          var baseImpOperacGrav = dojo.byId("itemCP.baseImpOperacGrav").value;
          var importOperacExonerada= dojo.byId("itemCP.importeOperacionExonerada").value;
          var importOperacInafecta = dojo.byId("itemCP.importeOperacionInafecta").value;
          var mtoISC = dojo.byId("itemCP.isc").value;                              
          var mtoIGV = dojo.byId("itemCP.igvoipm").value;
          var baseImpIvap = dojo.byId("itemCP.baseImponibleIvap").value;                              
          var mtoIvap = dojo.byId("itemCP.ivap").value;
          var otroTributosNoFormanBaseImp = dojo.byId("itemCP.tributosCargosNoBaseImp").value;                              
          if (valorFactExporta!=""){ 
              valorFactExporta = dijit.byId("itemCP.valorFacturadoExportacion").getValue();}
          else {valorFactExporta = 0;}  
          if (baseImpOperacGrav!=""){ 
              baseImpOperacGrav = dijit.byId("itemCP.baseImpOperacGrav").getValue();}
          else {baseImpOperacGrav = 0;}  
          if (importOperacExonerada!=""){ 
              importOperacExonerada = dijit.byId("itemCP.importeOperacionExonerada").getValue();}
          else {importOperacExonerada = 0;}  
          if (importOperacInafecta!=""){ 
              importOperacInafecta = dijit.byId("itemCP.importeOperacionInafecta").getValue();}
          else {importOperacInafecta = 0;}  
          if (mtoISC!=""){ 
              mtoISC = dijit.byId("itemCP.isc").getValue();}
          else {mtoISC = 0;} 
          if (mtoIGV!=""){ 
              mtoIGV = dijit.byId("itemCP.igvoipm").getValue();}
          else {mtoIGV = 0;}  
          if (baseImpIvap!=""){ 
              baseImpIvap = dijit.byId("itemCP.baseImponibleIvap").getValue();}
          else {baseImpIvap = 0;}  
          if (mtoIvap!=""){ 
              mtoIvap = dijit.byId("itemCP.ivap").getValue();}
          else {mtoIvap = 0;}  
          if (otroTributosNoFormanBaseImp!=""){ 
              otroTributosNoFormanBaseImp = dijit.byId("itemCP.tributosCargosNoBaseImp").getValue();}
          else {otroTributosNoFormanBaseImp = 0;}  
                                                    
          var total = 0;
          total =  valorFactExporta + baseImpOperacGrav+ importOperacExonerada+ importOperacInafecta+ mtoISC+    mtoIGV + baseImpIvap +   mtoIvap+otroTributosNoFormanBaseImp;
          dijit.byId("itemCP.importeTotalCP").setValue(total);
          dijit.byId("itemCP.importeTotalCP").constraints = {min:0,places:2}; 
       
    },
    
    mostrarMoneda: function(id){
        var tipoMoneda = dijit.byId("itemCP.tipoMoneda").getValue();
        var estadoCP = dijit.byId("itemCP.estadoCP").getValue();
       if (estadoCP == "02"){
         this.showHiddenDiv(document.getElementById("itemCP.tipoMoneda.show"),false);
         this.showHiddenDiv(document.getElementById("itemCP.tipoCambio.show"),false);  
            //dojo.byId("itemCP.fechaTC").value = "";  
            dojo.byId("itemCP.tc").value = "";                  
       }else{
         this.showHiddenDiv(document.getElementById("itemCP.tipoMoneda.show"),true);
         
             if (tipoMoneda != "USD" && tipoMoneda != "CAD" && tipoMoneda != "GBP" && tipoMoneda != "JPY" && tipoMoneda != "SEK" && tipoMoneda != "CHF" && tipoMoneda != "EUR"){
                this.showHiddenDiv(document.getElementById("itemCP.tipoCambio.show"),true);
             }else{
                this.showHiddenDiv(document.getElementById("itemCP.tipoCambio.show"),false);
                //dojo.byId("itemCP.fechaTC").value = "";  
                dojo.byId("itemCP.tc").value = "";  
             }
       }
    },  
         
    onFocus: function(id){
     var dato = dojo.byId(id).value;
     dijit.byId(id).attr('value',"");	
     dijit.byId(id).attr('value',dojo.trim(dato));	
   },
  
    roundNumber: function(number, digits) {
                   var multiple = Math.pow(10, digits);
                   var rndedNum = Math.round(number * multiple) / multiple;

                   return rndedNum;
     } ,
     
  	iconTooltipMessage: function(node, iconClass, message) {
  		if(dojo.isString(node)) node = dojo.byId(node);
  		dijit.focus(node);
  		node.focus();
  		dijit.showTooltip('<div class="' + iconClass + '"><div>' + message + '</div></div>', node, []);
  		//node._refreshState();
  		var blur = dojo.connect(node, "onBlur", function() {
  			dijit.hideTooltip(node);
  			//node._refreshState();
  			dojo.disconnect(blur);
  		});
	  },  

  pause: function(milisec){
    var d = new Date();
    var begin = d.getTime();
    
    while ((d.getTime() - begin ) > milisec){
    // nothing... 
    } 
 } ,
	  
    	noSort: function(index){ 
    		 return false;
    	}    
    });
}
