/**
 * RegistroComprobantesFisicos.js - JavaScript de RVI.
 * Author: Patricia Chacaliaza
 * Since: 05-08-2011 
 * ResponseBean : codeError; messageError; data;
 */
if (!dojo._hasResource["servicio.registro.comppago.see.RegistroComprobantesFisicos"]) {
dojo._hasResource["servicio.registro.comppago.see.RegistroComprobantesFisicos"] = true;
dojo.provide("servicio.registro.comppago.see.RegistroComprobantesFisicos");

dojo.require("dojo.data.ItemFileWriteStore");
dojo.require("dojo.io.iframe");
dojo.require("dojox.validate.regexp");
dojo.declare("servicio.registro.comppago.see.RegistroComprobantesFisicos", null, {

	
	store: null,
	beanDatosCP: null,
	beanCuoCorrel: null,
	cuoSV: "",
	cuoIgualCorrel:"",
	controller: "registrarcpf.do",

	otherDocStore: null,
	ptoemiStore: null,	
	
	constructor: function() {},

	initialize: function() {
		this.content = dijit.byId("content");
		
		this.dialogItem =  dijit.byId("dialogItem");
		this.waitMessage = dijit.byId("waitMessage");
	},

		
	initContent: function() {
	    	this.store = null;
	    this.initialize();
	    dijit.byId("inicio.opcExportacion0").setChecked("checked");
      dijit.byId("inicio.opcMonedaNoNuevoSol0").setChecked("checked");
      dijit.byId("inicio.opcVentasGrabadas1").setChecked("checked");
      this.opcionesVtasGrabadas(1);
      dijit.byId("inicio.opcVentasExoneradas0").setChecked("checked");
		  dijit.byId("inicio.opcVentasInafectas0").setChecked("checked");
      dijit.byId("inicio.opcVentasGratuitas0").setChecked("checked");
      dijit.byId("inicio.operacSujetasIsc0").setChecked("checked");
      dijit.byId("inicio.operacSujetasIvap0").setChecked("checked");
		  dijit.byId("inicio.operacOtrosTribCargos0").setChecked("checked");
      //dijit.byId("inicio.fechaVencimPago0").setChecked("checked");
      //dijit.byId("inicio.emisionMaquinaRegis0").setChecked("checked");
      //dijit.byId("inicio.cpModifCpOriginal0").setChecked("checked");
		  //dijit.byId("inicio.capturarCpXRangos0").setChecked("checked");  //OJO
      //dijit.byId("inicio.anotadosRegistroAnterior0").setChecked("checked");  
      dojo.byId("global.cuoEncontrado").value = "0";        
       
		  dijit.focus(dojo.byId("factura.numeroDocumento"));
		
	},
	
	mostrarDatosGenerales: function() {
    //Seteamos pantalla
	  var tipoCP = dijit.byId("generales.tipoCP").getValue().substring(0,2);
	  dijit.hideTooltip(dojo.byId("generales.tipoCP"));
     dijit.hideTooltip(dojo.byId("generales.cuo")); 
     dijit.hideTooltip(dojo.byId("generales.numeroDocRecepCP")); 
     dijit.hideTooltip(dojo.byId("generales.numeroSerieCP")); 
     dijit.hideTooltip(dojo.byId("generales.periodoAjuste"));
    	   dijit.hideTooltip(dojo.byId("generales.fechaEmisionCP"));
   dijit.hideTooltip(dojo.byId("generales.fechaVencimientoPago"));
   dijit.hideTooltip(dojo.byId("generales.numeroSerieCP"));
   dijit.hideTooltip(dojo.byId("generales.numeroDocRecepCP"));
   dijit.hideTooltip(dojo.byId("generales.numeroInicialCP"));
   dijit.hideTooltip(dojo.byId("generales.numeroFinalCP"));   
      dijit.hideTooltip(dojo.byId("generales.numeroCorrelativo"));   
   dijit.hideTooltip(dojo.byId("generales.numeroCP")); 
   dijit.hideTooltip(dojo.byId("generales.numeroSerieCP"))
    dijit.hideTooltip(dojo.byId("generales.estadoCP")); 
    dijit.hideTooltip(dojo.byId("generales.periodoAjuste"));
    dijit.hideTooltip(dojo.byId("generales.razonSocialRecepCP"));
          dijit.hideTooltip(dojo.byId("detalle.fechaEmisionCPModificado"));
        dijit.hideTooltip(dojo.byId("detalle.tipoCPModificado")); 
        dijit.hideTooltip(dojo.byId("detalle.numeroCPModificado")); 
        dijit.hideTooltip(dojo.byId("detalle.numeroSerieCPModificado")); 
     
    if (tipoCP =="X1" || tipoCP =="X2"  ){

           this.content.setHref(this.controller + "?action=verMasTiposCP&tipo=" + tipoCP ); 
           return;
           
    }      
    
	  var tipoCPMod = dijit.byId("detalle.tipoCPModificado").getValue().substring(0,2);
    if (tipoCPMod =="X1" || tipoCPMod =="X2"  ){
           this.content.setHref(this.controller + "?action=verMasTiposCPModif&tipo=" + tipoCPMod ); 
           return;
           
    }      
    dojo.byId("generales.periodoRegVenta").value  = dojo.byId("global.periodoComprobantesFormat").value;
        
    var estadoCP = dijit.byId("generales.estadoCP").getValue();

    if (estadoCP !="02"){
          this.showHiddenDiv(document.getElementById("generales.fechaEmisionCP.show"),true);
    }else{
       this.showHiddenDiv(document.getElementById("generales.fechaEmisionCP.show"),false);
       dojo.byId("generales.fechaEmisionCP").value = "";  
    }
            
   
    tipoCP = dijit.byId("generales.tipoCP").getValue().substring(0,2);

	
	  var tieneNrosRango = this.getValorOpcionCapturarCPPorRangos(); //dojo.byId("global.capturarCpXRangos").value;

    //if (tieneNrosRango != 1) {tieneNrosRango = dojo.byId("global.capturarCpXRangos").value;}
    //if (tipoCP =="03" ||  tipoCP =="12" || tipoCP =="15" ||  tipoCP =="19"  ){  // Se modifico para la version 5
    var periodoRangos = dijit.byId("generales.periodoRegVenta").getValue().substring(3,7) + dijit.byId("generales.periodoRegVenta").getValue().substring(0,2)  ;
    if ((tipoCP =="03" && periodoRangos < 201607 )||  tipoCP =="12" || tipoCP =="00" ||  tipoCP =="13" || tipoCP =="87"){
      
        this.showHiddenDiv(document.getElementById("generales.nrosRangoCP00.show"),true);
        dijit.byId("inicio.capturarCpXRangos0").attr("disabled", false);   
        dijit.byId("inicio.capturarCpXRangos1").attr("disabled", false);         
        if (tieneNrosRango==1 ){
              this.showHiddenDiv(document.getElementById("generales.nrosRangoCP.show"),true);
              this.showHiddenDiv(document.getElementById("generales.numeroCP.show"),false);
              dojo.byId("generales.numeroCP").value = "";
        }  else{
              this.showHiddenDiv(document.getElementById("generales.numeroCP.show"),true);
              this.showHiddenDiv(document.getElementById("generales.nrosRangoCP.show"),false);
              dojo.byId("generales.numeroInicialCP").value = "";
              dojo.byId("generales.numeroFinalCP").value = "";         
        }
    }else{
        this.showHiddenDiv(document.getElementById("generales.nrosRangoCP00.show"),false);
        this.showHiddenDiv(document.getElementById("generales.numeroCP.show"),true);
        this.showHiddenDiv(document.getElementById("generales.nrosRangoCP.show"),false);
        dojo.byId("generales.numeroInicialCP").value = "";
        dojo.byId("generales.numeroFinalCP").value = "";      
        dijit.byId("inicio.capturarCpXRangos0").setChecked("checked");
        dijit.byId("inicio.capturarCpXRangos0").attr("disabled", true)   
        dijit.byId("inicio.capturarCpXRangos1").attr("disabled", true)         
    }	
	

	  //var tieneFecVenc = dojo.byId("global.fechaVencimPago").value;
    var tieneFecVenc = 0
		if (tipoCP =="14"){
		 tieneFecVenc = 1;
    }
    /*if (tieneFecVenc==1 && estadoCP !="02"){
          this.showHiddenDiv(document.getElementById("generales.fechaVencimPago.show"),true);
    }else{
       this.showHiddenDiv(document.getElementById("generales.fechaVencimPago.show"),false);
       dojo.byId("generales.fechaVencimientoPago").value = "";  
    }*/
    if (estadoCP !="02"){
          this.showHiddenDiv(document.getElementById("generales.fechaVencimPago.show"),true);
    }else{
          this.showHiddenDiv(document.getElementById("generales.fechaVencimPago.show"),false);
    }
    
    if (dojo.byId("global.esRetroceso").value!="1"){
        if (estadoCP =="01" || estadoCP =="02"){
           if ( dijit.byId("generales.fechaEmisionCP").getValue() == null || dijit.byId("generales.fechaEmisionCP").getValue() == ""){ 
           
              dijit.byId("generales.fechaEmisionCP").setValue(new Date(dojo.byId("global.periodoComprobantes").value.substring(4,6) + "/01/" + dojo.byId("global.periodoComprobantes").value.substring(0,4)));
           }
        }else{
          if(dojo.byId("generales.periodoAjuste").value != ""){
            dijit.byId("generales.fechaEmisionCP").setValue(new Date(dojo.byId("generales.periodoAjuste").value.substring(0,2) + "/01/" + dojo.byId("generales.periodoAjuste").value.substring(3,7)));
          } 
        }      
    }else{
          if (estadoCP =="01" || estadoCP =="02"){
            dijit.byId("generales.fechaEmisionCP").setValue(new Date(dojo.byId("global.fechaEmisionCP").value));
          }else{
            if(dojo.byId("generales.periodoAjuste").value != ""){
              dijit.byId("generales.fechaEmisionCP").setValue(new Date(dojo.byId("global.fechaEmisionCP").value));
            } 
          }   
    } 
    /*
	  var tieneEmisionMaqReg = dojo.byId("global.emisionMaquinaRegis").value;
    if (tieneEmisionMaqReg==1 && tipoCP=="12" ){
       this.showHiddenDiv(document.getElementById("generales.nroSerieRegistradora.show"),true);
       dijit.byId("generales.numeroSerieMaqRegistra").setValue(dojo.byId("global.numeroSerieMaqRegistra").value);
    }else{
      
       this.showHiddenDiv(document.getElementById("generales.nroSerieRegistradora.show"),false);
       dojo.byId("generales.numeroSerieMaqRegistra").value = "";  
       if (dojo.byId("global.esRetroceso").value!="1"){
          dojo.byId("global.numeroSerieMaqRegistra").value = "";
       }  
    }*/

	  var anotadosRegAnterior =  0; //dojo.byId("global.opcAnotadosRegistroAnterior").value;
	  if ( estadoCP =="09"){
	       anotadosRegAnterior=1;
    }

    if (anotadosRegAnterior==1){
       this.showHiddenDiv(document.getElementById("generales.periodoCorrespondeAjuste.show"),true);
    }else{
       if ( estadoCP =="08"){
          this.showHiddenDiv(document.getElementById("generales.periodoCorrespondeAjuste.show"),true);
       }else{
          this.showHiddenDiv(document.getElementById("generales.periodoCorrespondeAjuste.show"),false);
          dojo.byId("generales.periodoAjuste").value = "";  

       }
    }
    
    var tieneExportacion  = dojo.byId("global.opcExportacion").value;
    if (estadoCP=="02" ){
		   dijit.byId("generales.tipoDocRecepCP").setValue("- - SIN DOCUMENTO");
		   dijit.byId("generales.tipoDocRecepCP").attr("disabled", true) ;    
		   dijit.byId("generales.numeroDocRecepCP").setValue("");
		   dijit.byId("generales.numeroDocRecepCP").attr("disabled", true );  
		   dijit.byId("generales.razonSocialRecepCP").setValue("");
		   dijit.byId("generales.razonSocialRecepCP").attr("disabled",true) ;   		   
    }else{
         dijit.byId("generales.tipoDocRecepCP").attr("disabled", false) ;  
         dijit.byId("generales.numeroDocRecepCP").attr("disabled", false) ;  
         dijit.byId("generales.razonSocialRecepCP").attr("disabled", false) ;  
          //if ( tipoCP =="03" ||  tipoCP =="15" || tipoCP =="19" || tipoCP =="00"){ //Se cambio para ple 5
          if ( tipoCP =="00" ||  tipoCP =="03" || tipoCP =="05" || tipoCP =="06" || tipoCP =="07" ||  tipoCP =="08" || tipoCP =="11" || tipoCP =="12" ||
               tipoCP =="13" ||  tipoCP =="14" || tipoCP =="15" || tipoCP =="16" || tipoCP =="18" ||  tipoCP =="19" || tipoCP =="23" || tipoCP =="26" || 
               tipoCP =="28" ||  tipoCP =="30" || tipoCP =="34" || tipoCP =="35" || tipoCP =="36" ||  tipoCP =="37" || tipoCP =="55" || tipoCP =="56" ||
               tipoCP =="87" ||  tipoCP =="88" ){
      		   dijit.byId("generales.tipoDocRecepCP").setValue("- - SIN DOCUMENTO");
      		   dijit.byId("generales.razonSocialRecepCP").setValue("");
          }else{
              if (tipoCP =="07" || tipoCP == "08" || tipoCP =="87" || tipoCP == "88"){
                  dijit.byId("generales.tipoDocRecepCP").setValue("6 - REG. UNICO DE CONTRIBUYENTES");
                  dijit.byId("generales.razonSocialRecepCP").attr("disabled", true) ;
              }else{

                      dijit.byId("generales.tipoDocRecepCP").setValue("6 - REG. UNICO DE CONTRIBUYENTES");
                      dijit.byId("generales.razonSocialRecepCP").attr("disabled", true) ;
              }
          }         
    }



    if ( tipoCP =="01" ||  tipoCP =="03" || tipoCP =="04" || tipoCP =="07" || tipoCP =="08"){
       if (dojo.byId("generales.numeroSerieCP").value.length != 4) { dojo.byId("generales.numeroSerieCP").value=""; }
       dojo.byId("generales.numeroSerieCP").maxLength = 4;
       
       if ( tipoCP =="01"){
           dijit.byId("generales.numeroSerieCP").attr("regExp", "E001|[Ff][0-9a-z-A-Z]+|[Ff][0-9]+|[0-9]+"); 
       }else{
           if ( tipoCP =="07" || tipoCP =="08"){
               dijit.byId("generales.numeroSerieCP").attr("regExp", "EB01|E001|[Ff0-9]+|[Bb0-9]+|[Ff][0-9a-z-A-Z]+|[Bb][0-9a-zA-z]+|[0-9]+"); 
           }else{
               if (tipoCP =="04"){
                    dijit.byId("generales.numeroSerieCP").attr("regExp", "[Ee0-9]+"); 
               }else{
                    dijit.byId("generales.numeroSerieCP").attr("regExp", "EB01|[Bb][A-Z-a-z0-9]+|[0-9]+");  //[EeBb0-9]+
               }
           }
       }

    }else{
        if (  tipoCP =="06" || tipoCP =="23" || tipoCP =="25" ||  tipoCP =="34" || tipoCP =="35" || tipoCP =="36" ||  tipoCP =="48" ||tipoCP =="56" ){
           if (dojo.byId("generales.numeroSerieCP").value.length != 4) { dojo.byId("generales.numeroSerieCP").value=""; }
           dojo.byId("generales.numeroSerieCP").maxLength = 4;
           dijit.byId("generales.numeroSerieCP").attr("regExp", "[0-9]+");   
        }else{
              if (  tipoCP =="05"  ){
                 if (dojo.byId("generales.numeroSerieCP").value.length != 1) { dojo.byId("generales.numeroSerieCP").value=""; }
                 dojo.byId("generales.numeroSerieCP").maxLength = 1;
                 dijit.byId("generales.numeroSerieCP").attr("regExp", "[1-5]+");   
                 this.iconTooltipMessage("generales.numeroSerieCP", "icon-ok-tooltip", "Tipo de Boleto: 1= Boleto Manual, 2= Boleto Autom�tico, 3= Boleto Electr�nico, 4= Otros, 5= Anulado");  
              }else{
                    if (  tipoCP =="55"  ){
                       if (dojo.byId("generales.numeroSerieCP").value.length != 1) { dojo.byId("generales.numeroSerieCP").value=""; }
                       dojo.byId("generales.numeroSerieCP").maxLength = 1;
                       dijit.byId("generales.numeroSerieCP").attr("regExp", "[125]+");  
                       this.iconTooltipMessage("generales.numeroSerieCP", "icon-ok-tooltip", "Tipo de Boleto: 1= Boleto Pre-Impreso, 2= Boleto Electr�nico, 5= Anulado"); 
                    }else{
                         dojo.byId("generales.numeroSerieCP").maxLength = 20;
                         dijit.byId("generales.numeroSerieCP").attr("regExp",  "[A-Za-z0-9]+[-]{0,1}[A-Za-z0-9]+");
                    }
              }
        }
    }	
    
    
    if ( tipoCP =="01" ||  tipoCP =="03" || tipoCP =="04" ||  tipoCP =="06" || tipoCP =="07" || tipoCP =="08" ){
       if (dojo.byId("generales.numeroCP").value.length != 8) { dojo.byId("generales.numeroCP").value=""; }
       dojo.byId("generales.numeroCP").maxLength = 8;
       dijit.byId("generales.numeroCP").attr("regExp", "[0-9]+"); 
 
    }else{
        if ( tipoCP =="23" ||  tipoCP =="25" || tipoCP =="34" ||  tipoCP =="35" || tipoCP =="49"){
           if (dojo.byId("generales.numeroCP").value.length != 7) { dojo.byId("generales.numeroCP").value=""; }
           dojo.byId("generales.numeroCP").maxLength = 7;
           dijit.byId("generales.numeroCP").attr("regExp", "[0-9]+"); 
     
        }else{
            if ( tipoCP =="05" ||  tipoCP =="55"   || tipoCP =="56" ){
               if (dojo.byId("generales.numeroCP").value.length > 11) { dojo.byId("generales.numeroCP").value=""; }
               dojo.byId("generales.numeroCP").maxLength = 11;
               dijit.byId("generales.numeroCP").attr("regExp", "[0-9]+"); 
            }else{
                  if (  tipoCP =="11"  ){
                     if (dojo.byId("generales.numeroCP").value.length != 15) { dojo.byId("generales.numeroCP").value=""; }
                     dojo.byId("generales.numeroCP").maxLength = 15;
                     dijit.byId("generales.numeroCP").attr("regExp", "[0-9]+"); 
                  }else{
                        if (  tipoCP =="36"  ){
                             if (dojo.byId("generales.numeroCP").value.length != 8) { dojo.byId("generales.numeroCP").value=""; }
                             dojo.byId("generales.numeroCP").maxLength = 8;
                             dijit.byId("generales.numeroCP").attr("regExp", "[0-9]+");  
                        }else{
                            if (  tipoCP =="00"  ){
                                 if (dojo.byId("generales.numeroCP").value.length != 20) { dojo.byId("generales.numeroCP").value=""; }
                                 dojo.byId("generales.numeroCP").maxLength = 20;
                                 dijit.byId("generales.numeroCP").attr("regExp", "[A-Za-z0-9]+");  
                            }else{
                                 if (dojo.byId("generales.numeroCP").value.length != 20) { dojo.byId("generales.numeroCP").value=""; }
                                 dojo.byId("generales.numeroCP").maxLength = 20;
                                 dijit.byId("generales.numeroCP").attr("regExp", "[0-9]+");  
                            }
                        }
                  }
            }
        }	
    }	
    
    var modificaCPOriginal = 0; //    dojo.byId("global.cpModifCpOriginal").value;
    if (tipoCP =="07" || tipoCP == "08" || tipoCP =="87" || tipoCP == "88"){
        modificaCPOriginal=1; 
    }
    
    if (modificaCPOriginal==1 && estadoCP!= "02"){
        this.showHiddenDiv(document.getElementById("detalle.CPQueModifica.show"),true);
    }else{
       this.showHiddenDiv(document.getElementById("detalle.CPQueModifica.show"),false);
       if (dojo.byId("global.esRetroceso").value!="1"){
           dojo.byId("global.fechaEmisionCPModificado").value = "";  
           dojo.byId("global.tipoCPModificado").value = "";  
           dojo.byId("global.numeroSerieCPModificado").value = "";  
           dojo.byId("global.numeroCPModificado").value = "";  
       }
    }    
   
  /*
    if ( tipoCPMod =="01" ||  tipoCPMod =="03" ||  tipoCPMod =="07" ||  tipoCPMod =="08" ){
       if (dojo.byId("detalle.numeroSerieCPModificado").value.length != 4) { dojo.byId("detalle.numeroSerieCPModificado").value =""; }
       dojo.byId("detalle.numeroSerieCPModificado").maxLength =4;
       dijit.byId("detalle.numeroSerieCPModificado").attr("regExp", "[E-Fe-f0-9]+");
    }else{
        if ( tipoCPMod =="04" ||  tipoCPMod =="06" || tipoCPMod =="16" || tipoCPMod =="23" || tipoCPMod =="35"  ){
           if (dojo.byId("detalle.numeroSerieCPModificado").value.length != 4) { dojo.byId("detalle.numeroSerieCPModificado").value =""; }
           dojo.byId("detalle.numeroSerieCPModificado").maxLength =4;
           dijit.byId("detalle.numeroSerieCPModificado").attr("regExp", "[0-9]+");
        }else{
           dojo.byId("detalle.numeroSerieCPModificado").maxLength =20;
           dijit.byId("detalle.numeroSerieCPModificado").attr("regExp", "[A-Za-z0-9]+[-]{0,1}[A-Za-z0-9]+");
        }	 
    }	  
      */
      
    if ( tipoCPMod =="01" ||  tipoCPMod =="03" || tipoCPMod =="04" || tipoCPMod =="07" || tipoCPMod =="08"){
       if (dojo.byId("detalle.numeroSerieCPModificado").value.length != 4) { dojo.byId("detalle.numeroSerieCPModificado").value=""; }
       dojo.byId("detalle.numeroSerieCPModificado").maxLength = 4;
       dijit.byId("detalle.numeroSerieCPModificado").attr("regExp", "[E-Fe-f0-9]+"); 

       
       if ( tipoCPMod =="01"){
           dijit.byId("detalle.numeroSerieCPModificado").attr("regExp", "E001|[Ff][0-9a-z-A-Z]+|[Ff][0-9]+|[0-9]+"); 
       }else{
           if ( tipoCPMod =="07" || tipoCP =="08"){
               dijit.byId("detalle.numeroSerieCPModificado").attr("regExp", "EB01|E001|[Ff0-9]+|[Bb0-9]+|[Ff][0-9a-z-A-Z]+|[Bb][0-9a-zA-z]+|[0-9]+"); 
           }else{
               if (tipoCPMod =="04"){
                    dijit.byId("detalle.numeroSerieCPModificado").attr("regExp", "[Ee0-9]+"); 
               }else{
                    dijit.byId("detalle.numeroSerieCPModificado").attr("regExp", "EB01|[Bb][A-Z-a-z0-9]+|[0-9]+"); 
               }
           }  
       }       

    }else{
        if (  tipoCPMod =="06" ||  tipoCPMod =="23" || tipoCPMod =="36" || tipoCPMod =="56" ){
           if (dojo.byId("detalle.numeroSerieCPModificado").value.length != 4) { dojo.byId("detalle.numeroSerieCPModificado").value=""; }
           dojo.byId("detalle.numeroSerieCPModificado").maxLength = 4;
           dijit.byId("detalle.numeroSerieCPModificado").attr("regExp", "[0-9]+");   
        }else{
              if (  tipoCPMod =="05"  ){
                 if (dojo.byId("detalle.numeroSerieCPModificado").value.length != 1) { dojo.byId("detalle.numeroSerieCPModificado").value=""; }
                 dojo.byId("detalle.numeroSerieCPModificado").maxLength = 1;
                 dijit.byId("detalle.numeroSerieCPModificado").attr("regExp", "[1-5]+");   
              }else{
                    if (  tipoCPMod =="55"  ){
                       if (dojo.byId("detalle.numeroSerieCPModificado").value.length != 1) { dojo.byId("detalle.numeroSerieCPModificado").value=""; }
                       dojo.byId("detalle.numeroSerieCPModificado").maxLength = 1;
                       dijit.byId("detalle.numeroSerieCPModificado").attr("regExp", "[125]+");   
                    }else{
                         dojo.byId("detalle.numeroSerieCPModificado").maxLength = 20;
                         dijit.byId("detalle.numeroSerieCPModificado").attr("regExp",  "[A-Za-z0-9]+[-]{0,1}[A-Za-z0-9]+");
                    }
              }
        }
    }	      
    
   //A solicitud de JR para TK que son NC
   if ( tipoCP =="07" && tipoCPMod =="12"){
            dojo.byId("generales.numeroSerieCP").maxLength =20;
           dijit.byId("generales.numeroSerieCP").attr("regExp", "[A-Za-z0-9]+[-]{0,1}[A-Za-z0-9]+");
   }
      
    var esRER = dojo.byId("generales.esRER").value;
    var periodoSeleccionado = dijit.byId("generales.periodoAjuste").getValue().substring(3,7) + dijit.byId("generales.periodoAjuste").getValue().substring(0,2)  ;// dojo.byId("global.periodoComprobantes").value; 
    var cuo = dojo.byId("generales.cuo").value;
    var correlativo = dojo.byId("generales.numeroCorrelativo").value; 
    var handler = null;
     
     //if (esRER == "RER"){
     //     dijit.byId("generales.cuo").setValue("RER");
     //     dijit.byId("generales.cuo").attr('disabled', true);
     //     dijit.byId("generales.numeroCorrelativo").attr("regExp", "[M][A-Za-z0-9]+");
     //}else{
          dijit.byId("generales.numeroCorrelativo").attr("regExp", "([AMC][A-Za-z0-9]+|-)");
          if ((estadoCP =="08" ) || (estadoCP =="09" && cuo !="")){
            if (periodoSeleccionado =="" ) {
             }else{
               this.beanDatosCP = null;
               if (estadoCP =="08" ){
                   handler = dojo.xhrGet({
                        url: this.controller + "?action=obtenerNumCuoCorrelativo&estadoCP=" + estadoCP +"&periodo=" + periodoSeleccionado ,
                        handleAs: "json",
                        sync: true,
                        timeout: 10000
                   });    
               }else{
                    periodoSeleccionado = dojo.byId("generales.periodoAjuste").value.substring(3,7) + dojo.byId("generales.periodoAjuste").value.substring(0,2)  ; //dojo.byId("generales.periodoAjuste").value; 
                    handler = dojo.xhrGet({
                        url: this.controller + "?action=validarCuoCorrelativo&estadoCP=" + estadoCP +"&periodo=" + periodoSeleccionado +"&cuo=" + cuo  + "&correlativo=" + correlativo,
                        handleAs: "json",
                        sync: true,
                        timeout: 10000
                   });    
               }
               handler.addCallback(dojo.hitch(this, function(res){
            		   if (res.codeError == 0) {
          		       switch (estadoCP) { 
                          case "08": 
                             if (res.data != null && res.data  != ""  ){
                                this.beanCuoCorrel = eval("(" + res.data + ")");
                                if (this.beanCuoCorrel.cuo!=""){
                                    dijit.byId("generales.cuo").setValue(this.beanCuoCorrel.cuo);
                                    dijit.byId("generales.cuo").attr('disabled', true);
                                    this.cuoSV="";
                                    this.cuoIgualCorrelativo="";                                
                                }else{
                                     //dijit.byId("generales.cuo").setValue(res.data.substring(2,res.data.length));
                                     dijit.byId("generales.cuo").attr('disabled', false);
                                     this.cuoSV="";                                
                        
                                } 
                                if (this.beanCuoCorrel.correlativo=="-"){
                                    dijit.byId("generales.numeroCorrelativo").setValue("-");
                                    dijit.byId("generales.numeroCorrelativo").attr('disabled', true);
                                }else{
                                    if (this.beanCuoCorrel.correlativo==""){
                                        
                                        dijit.byId("generales.numeroCorrelativo").attr('disabled', false);
                                    }else{
                                        dijit.byId("generales.numeroCorrelativo").setValue(this.beanCuoCorrel.correlativo);
                                        dijit.byId("generales.numeroCorrelativo").attr('disabled', true);
                                    }
                                }          
                                

                             }else{
                                 dijit.byId("generales.numeroCorrelativo").attr('disabled', false);
                             }
                             break 
                          case "09": 
                             if (res.data != null &&  res.data  != ""){
                                this.cuoSV="";
                                this.cuoIgualCorrelativo="";
                                
                                this.beanDatosCP = eval("(" + res.data + ")");
                                //cargar datos recuperados de t4602cpfisicos en las pantallas de dato generales y de detalle
                                //Generales
                                if (this.beanDatosCP.num_correlativo=="-"){
                                    dijit.byId("generales.numeroCorrelativo").setValue("-");
                                    dijit.byId("generales.numeroCorrelativo").attr('disabled', true);
                                }else{
                                    if (this.beanDatosCP.num_correlativo==""){
                                        
                                        dijit.byId("generales.numeroCorrelativo").attr('disabled', false);
                                    }else{
                                        dijit.byId("generales.numeroCorrelativo").setValue(this.beanDatosCP.num_correlativo);
                                        dijit.byId("generales.numeroCorrelativo").attr('disabled', true);
                                    }
                                } 
                                if (this.beanDatosCP.cod_cp != null){
                                  dojo.byId("global.cuoEncontrado").value = "1";
                                  dijit.byId("generales.tipoDocRecepCP").setValue(this.beanDatosCP.cod_docide_recep + " - " + this.beanDatosCP.desc_cod_docide_recep);
                                  dijit.byId("generales.numeroDocRecepCP").setValue(this.beanDatosCP.num_docide_recep);
                                  dijit.byId("generales.razonSocialRecepCP").setValue(this.beanDatosCP.des_nombre_recep);
                                 if (this.beanDatosCP.fec_emision != null && this.beanDatosCP.fec_emision != "") {dijit.byId("generales.fechaEmisionCP").setValue(new Date(this.beanDatosCP.fec_emision));}
                                 //if (this.beanDatosCP.fec_emision != "") {dijit.byId("generales.fechaEmisionCP").setValue(this.beanDatosCP.fec_emision);}
                                  if (this.beanDatosCP.fec_vencimiento_pago != null && this.beanDatosCP.fec_vencimiento_pago != "") {dijit.byId("generales.fechaVencimientoPago").setValue(new Date(this.beanDatosCP.fec_vencimiento_pago));} 
                                  dijit.byId("generales.numeroSerieCP").setValue(this.beanDatosCP.num_serie_cp);
                                  if (this.beanDatosCP.num_cp != null && this.beanDatosCP.num_cp != "") {dijit.byId("generales.numeroCP").setValue(this.beanDatosCP.num_cp  );}
                                  if (this.beanDatosCP.num_correlativo != null && this.beanDatosCP.num_correlativo != "") {dijit.byId("generales.numeroCorrelativo").setValue(this.beanDatosCP.num_correlativo  );}
                                  if (this.beanDatosCP.num_inicial != null && this.beanDatosCP.num_inicial != "") {dijit.byId("generales.numeroInicialCP").setValue(this.beanDatosCP.num_inicial );}
                                  if (this.beanDatosCP.num_final  != null && this.beanDatosCP.num_final  != "") {dijit.byId("generales.numeroFinalCP").setValue(this.beanDatosCP.num_final );}
                                  //dijit.byId("generales.numeroSerieMaqRegistra").setValue(this.beanDatosCP.num_serie_maq);      
                                  //Detalle     
                                  if (this.beanDatosCP.cod_moneda != null && this.beanDatosCP.cod_moneda != "" && this.beanDatosCP.cod_moneda != "PEN" ) {dojo.byId("global.tipoMoneda").value=this.beanDatosCP.cod_moneda;}
                                  if (this.beanDatosCP.fec_tipo_cambio != null && this.beanDatosCP.fec_tipo_cambio != "") {dijit.byId("global.fechaTC").setValue(new Date(this.beanDatosCP.fec_tipo_cambio));}  
                                  if (this.beanDatosCP.tipo_cambio != null && this.beanDatosCP.tipo_cambio != "") {dojo.byId("global.tc").value=this.beanDatosCP.tipo_cambio;}                             
                                  if (this.beanDatosCP.valor_facturado_exportacion != null && this.beanDatosCP.valor_facturado_exportacion != "") { dojo.byId("global.valorFacturadoExportacion").value=this.beanDatosCP.valor_facturado_exportacion;}
                                  //if (this.beanDatosCP.valor_embarcado_exportacion != null && this.beanDatosCP.valor_embarcado_exportacion != "") { dojo.byId("global.valorEmbarcadoExportacion").value=this.beanDatosCP.valor_facturado_exportacion;}
                                  if (this.beanDatosCP.base_imponible_operacion_gravada != null && this.beanDatosCP.base_imponible_operacion_gravada != "") {dojo.byId("global.baseImpOperacGrav").value=this.beanDatosCP.base_imponible_operacion_gravada;}  
                                  if (this.beanDatosCP.descuento_base_imponible != null && this.beanDatosCP.descuento_base_imponible != "") {dojo.byId("global.descBaseImponible").value=this.beanDatosCP.descuento_base_imponible;}
                                  if (this.beanDatosCP.importe_total_operacion_exonerada != null && this.beanDatosCP.importe_total_operacion_exonerada != "") {dojo.byId("global.importeOperacionExonerada").value=this.beanDatosCP.importe_total_operacion_exonerada;}
                                  if (this.beanDatosCP.importe_total_operacion_inafecta != null && this.beanDatosCP.importe_total_operacion_inafecta != "") {dojo.byId("global.importeOperacionInafecta").value=this.beanDatosCP.importe_total_operacion_inafecta;}
                                  if (this.beanDatosCP.isc != null && this.beanDatosCP.isc != "") {dojo.byId("global.isc").value=this.beanDatosCP.isc;}
                                  if (this.beanDatosCP.tasa_igv_ipm != null && this.beanDatosCP.tasa_igv_ipm != "") {dojo.byId("global.tasaIgvoipm").value=this.beanDatosCP.tasa_igv_ipm;}
                                  if (this.beanDatosCP.igv_ipm != null && this.beanDatosCP.igv_ipm != "") {dojo.byId("global.igvoipm").value=this.beanDatosCP.igv_ipm;}
                                  if (this.beanDatosCP.descuento_igv_ipm != null && this.beanDatosCP.descuento_igv_ipm != "") {dojo.byId("global.descuentoIgvoipm").value=this.beanDatosCP.descuento_igv_ipm;}
                                  if (this.beanDatosCP.base_imponible_operacion_gravada_ivap != null && this.beanDatosCP.base_imponible_operacion_gravada_ivap != "") {dojo.byId("global.baseImponibleIvap").value=this.beanDatosCP.base_imponible_operacion_gravada_ivap;}
                                  if (this.beanDatosCP.ivap != null && this.beanDatosCP.ivap != "") {dojo.byId("global.ivap").value=this.beanDatosCP.ivap;}
                                  if (this.beanDatosCP.otros_tributos_cargos != null && this.beanDatosCP.otros_tributos_cargos != "") {dojo.byId("global.tributosCargosNoBaseImp").value=this.beanDatosCP.otros_tributos_cargos;}
                                  if (this.beanDatosCP.mto_importe_total != null && this.beanDatosCP.mto_importe_total != "") {dojo.byId("global.importeTotalCP").value=this.beanDatosCP.mto_importe_total;}
                                  if (this.beanDatosCP.gravado_premio != null && this.beanDatosCP.gravado_premio != "") {dojo.byId("global.grabadoPremio").value=this.beanDatosCP.gravado_premio;}
                                  if (this.beanDatosCP.gravado_donacion != null && this.beanDatosCP.gravado_donacion != "") {dojo.byId("global.grabadoDonacion").value=this.beanDatosCP.gravado_donacion;}
                                  if (this.beanDatosCP.gravado_entrega_trabajadores != null && this.beanDatosCP.gravado_entrega_trabajadores != "") {dojo.byId("global.grabadoEntregaTrabajadores").value=this.beanDatosCP.gravado_entrega_trabajadores;}
                                  if (this.beanDatosCP.gravado_publicidad != null && this.beanDatosCP.gravado_publicidad != "") {dojo.byId("global.grabadoPublicidad").value=this.beanDatosCP.gravado_publicidad;}
                                  if (this.beanDatosCP.gravado_bonificacion != null && this.beanDatosCP.gravado_bonificacion != "") {dojo.byId("global.grabadoBonificacion").value=this.beanDatosCP.gravado_bonificacion;}
                                  if (this.beanDatosCP.gravado_retiro_otros != null && this.beanDatosCP.gravado_retiro_otros != "") {dojo.byId("global.grabadoRetiroOtros").value=this.beanDatosCP.gravado_retiro_otros;}
                                  if (this.beanDatosCP.valor_facturado_exportacion_no_onerosa != null && this.beanDatosCP.valor_facturado_exportacion_no_onerosa != "") {dojo.byId("global.valorFacturaExportaNoOnerosa").value=this.beanDatosCP.valor_facturado_exportacion_no_onerosa;}
                                  if (this.beanDatosCP.importe_total_operacion_no_onerosa != null && this.beanDatosCP.importe_total_operacion_no_onerosa != "") {dojo.byId("global.importeOperacionNoOnerosaExo").value=this.beanDatosCP.importe_total_operacion_no_onerosa;}
                                  if (this.beanDatosCP.inafecto_premio != null && this.beanDatosCP.inafecto_premio != "") {dojo.byId("global.inafectoPremio").value=this.beanDatosCP.inafecto_premio;}
                                  if (this.beanDatosCP.inafecto_retiro_convenio_colectivo != null && this.beanDatosCP.inafecto_retiro_convenio_colectivo != "") {dojo.byId("global.inafectoRetiroConvenioColectivo").value=this.beanDatosCP.inafecto_retiro_convenio_colectivo;}
                                  if (this.beanDatosCP.inafecto_muestras_medicas != null && this.beanDatosCP.inafecto_muestras_medicas != "") {dojo.byId("global.inafectoMuestrasMedicas").value=this.beanDatosCP.inafecto_muestras_medicas;}
                                  if (this.beanDatosCP.inafecto_publicidad != null && this.beanDatosCP.inafecto_publicidad != "") {dojo.byId("global.inafectoPublicidad").value=this.beanDatosCP.inafecto_publicidad;}
                                  if (this.beanDatosCP.inafecto_bonificacion != null && this.beanDatosCP.inafecto_bonificacion != "") {dojo.byId("global.inafectoBonificacion").value=this.beanDatosCP.inafecto_bonificacion;}
                                  if (this.beanDatosCP.inafecto_retiro_otros != null && this.beanDatosCP.inafecto_retiro_otros != "") {dojo.byId("global.inafectoRetiroOtros").value=this.beanDatosCP.inafecto_retiro_otros;}
                                  if (this.beanDatosCP.fec_emision_cp_modif != null && this.beanDatosCP.fec_emision_cp_modif != "") {dijit.byId("global.fechaEmisionCPModificado").setValue(new Date(this.beanDatosCP.fec_emision_cp_modif));}  
                                  if (this.beanDatosCP.cod_cp_modif != null && this.beanDatosCP.cod_cp_modif != "") {dojo.byId("global.tipoCPModificado").value=this.beanDatosCP.cod_cp_modif;}
                                  if (this.beanDatosCP.num_serie_cp_modif != null && this.beanDatosCP.num_serie_cp_modif != "") {dojo.byId("global.numeroSerieCPModificado").value=this.beanDatosCP.num_serie_cp_modif;}
                                  if (this.beanDatosCP.num_cp_modif != null && this.beanDatosCP.num_cp_modif != "") {dojo.byId("global.numeroCPModificado").value=this.beanDatosCP.num_cp_modif;}
                                  if (this.beanDatosCP.contrato_colaboracion != null && this.beanDatosCP.contrato_colaboracion != "") {dojo.byId("global.contratoColaboracion").value=this.beanDatosCP.contrato_colaboracion;}
                                  if (this.beanDatosCP.error_tipo1 != null && this.beanDatosCP.error_tipo1 != "") {dojo.byId("global.errorTipo1").value=this.beanDatosCP.error_tipo1;}
                                  if (this.beanDatosCP.medio_de_pago != null && this.beanDatosCP.medio_de_pago != "") {dojo.byId("global.indicadorMedioPago").value=this.beanDatosCP.medio_de_pago;}
                                  dojo.byId("global.cuoEncontrado").value = "1";
                                }else{
                                    dijit.byId("generales.cuo").attr('disabled', false)
                                    dojo.byId("global.cuoEncontrado").value = "1";   
                                    //this.iconTooltipMessage("generales.cuo", "icon-ok-tooltip", "No ha sido encontrado el CP Fisico con el CUO consignado.");     
                                                    
                                }
    
                             }else{
                                dijit.byId("generales.cuo").attr('disabled', false)
                                dojo.byId("global.cuoEncontrado").value = "0";
                                //this.iconTooltipMessage("generales.cuo", "icon-ok-tooltip", "No ha sido encontrado el CP Fisico con el CUO consignado.");
                                  
                             }
                             break 
                     } 
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                    
          			 } else {                                 
          				  alert(res.messageError);
          				  dojo.byId("global.cuoEncontrado").value = "0";
          				  return;
          			 }
          		 }));
               handler.addErrback(function(res){
              			this.waitMessage.hide();
              			dojo.byId("global.cuoEncontrado").value = "0";
              			alert("Problemas al conectarse con el servidor");
               }); 
             }
         }
     //}
       
      var correlativo = dijit.byId("generales.numeroCorrelativo").getValue() ;
     if (estadoCP =="00" || estadoCP =="01" || estadoCP =="02"  || estadoCP =="08" ){
          periodoSeleccionado = dijit.byId("generales.periodoRegVenta").getValue().substring(3,7) + dijit.byId("generales.periodoRegVenta").getValue().substring(0,2)  ;
          if (estadoCP =="08" ){
               periodoSeleccionado = dijit.byId("generales.periodoAjuste").getValue().substring(3,7) + dijit.byId("generales.periodoAjuste").getValue().substring(0,2)  ;
          }
          cuo = dojo.byId("generales.cuo").value; 
          
          if (dijit.byId("generales.numeroCorrelativo").getValue() != ""){
          
                   handler = dojo.xhrGet({
                        url: this.controller + "?action=validarExisteCuoCorrelativo&estadoCP=" + estadoCP +"&periodo=" + periodoSeleccionado +"&cuo=" + cuo  + "&correlativo=" + correlativo,
                        handleAs: "json",
                        sync: true,
                        timeout: 20000
                   });  
               handler.addCallback(dojo.hitch(this, function(res){
            		   if (res.codeError == 0) {
 
                       if (res.data != null && res.data == "1" ){
                          if (estadoCP =="08" ){
                              alert("Ya existe un registro previo con el mismo CUO y Numero Correlativo en el periodo que corresponde al ajuste.");
                          }else{
                              alert("Ya existe un registro previo con el mismo CUO y Numero Correlativo en el periodo.");
                          }
                          dojo.byId("global.cuoEncontrado").value = "1"; 
                          return;
                       }else{
                          dojo.byId("global.cuoEncontrado").value = "0";
                       }
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                   
          			 } else {                                 
          				  alert(res.messageError);
          				  dojo.byId("global.cuoEncontrado").value = "0";
          				  return;
          			 }
          		 }));
               handler.addErrback(function(res){
              			this.waitMessage.hide();
              			dojo.byId("global.cuoEncontrado").value = "0";
              			alert("Problemas al conectarse con el servidor");
               }); 
          }
          
     } else{
          periodoSeleccionado = dijit.byId("generales.periodoAjuste").getValue().substring(3,7) + dijit.byId("generales.periodoAjuste").getValue().substring(0,2)  ;
          if (dijit.byId("generales.numeroCorrelativo").getValue() != ""){
                    
                   handler = dojo.xhrGet({
                        url: this.controller + "?action=validarCuoCorrelativo&estadoCP=" + estadoCP +"&periodo=" + periodoSeleccionado +"&cuo=" + cuo  + "&correlativo=" + correlativo,
                        handleAs: "json",
                        sync: true,
                        timeout: 20000
                   });  
               handler.addCallback(dojo.hitch(this, function(res){
            		   if (res.codeError == 0) {
 
                             if (res.data != null &&  res.data  != ""){
                                this.cuoSV="";
                                this.cuoSV="";
                                this.beanDatosCP = eval("(" + res.data + ")");
                                //cargar datos recuperados de t4602cpfisicos en las pantallas de dato generales y de detalle
                                //Generales
                                if (this.beanDatosCP.cod_cp != null){
                                  dojo.byId("global.cuoEncontrado").value = "1";
                                  dijit.byId("generales.tipoDocRecepCP").setValue(this.beanDatosCP.cod_docide_recep + " - " + this.beanDatosCP.desc_cod_docide_recep);
                                  dijit.byId("generales.numeroDocRecepCP").setValue(this.beanDatosCP.num_docide_recep);
                                  dijit.byId("generales.razonSocialRecepCP").setValue(this.beanDatosCP.des_nombre_recep);
                                 if (this.beanDatosCP.fec_emision != null && this.beanDatosCP.fec_emision != "") {dijit.byId("generales.fechaEmisionCP").setValue(new Date(this.beanDatosCP.fec_emision));}
                                 //if (this.beanDatosCP.fec_emision != "") {dijit.byId("generales.fechaEmisionCP").setValue(this.beanDatosCP.fec_emision);}
                                  if (this.beanDatosCP.fec_vencimiento_pago != null && this.beanDatosCP.fec_vencimiento_pago != "") {dijit.byId("generales.fechaVencimientoPago").setValue(new Date(this.beanDatosCP.fec_vencimiento_pago));} 
                                  dijit.byId("generales.numeroSerieCP").setValue(this.beanDatosCP.num_serie_cp);
                                  if (this.beanDatosCP.num_cp != null && this.beanDatosCP.num_cp != "") {dijit.byId("generales.numeroCP").setValue(this.beanDatosCP.num_cp  );}
                                  if (this.beanDatosCP.num_correlativo != null && this.beanDatosCP.num_correlativo != "") {dijit.byId("generales.numeroCorrelativo").setValue(this.beanDatosCP.num_correlativo  );}
                                  if (this.beanDatosCP.num_correlativo != null && this.beanDatosCP.num_correlativo == "") {
                                      dijit.byId("generales.numeroCorrelativo").attr('disabled', true);
                                  }else{
                                      dijit.byId("generales.numeroCorrelativo").attr('disabled', false);
                                  }                                  
                                  if (this.beanDatosCP.num_inicial != null && this.beanDatosCP.num_inicial != "") {dijit.byId("generales.numeroInicialCP").setValue(this.beanDatosCP.num_inicial );}
                                  if (this.beanDatosCP.num_final  != null && this.beanDatosCP.num_final  != "" && this.beanDatosCP.num_final  != "-") {dijit.byId("generales.numeroFinalCP").setValue(this.beanDatosCP.num_final );}
                                  //dijit.byId("generales.numeroSerieMaqRegistra").setValue(this.beanDatosCP.num_serie_maq);      
                                  //Detalle     
                                  if (this.beanDatosCP.cod_moneda != null && this.beanDatosCP.cod_moneda != "" && this.beanDatosCP.cod_moneda != "PEN" ) {dojo.byId("global.tipoMoneda").value=this.beanDatosCP.cod_moneda;}
                                  if (this.beanDatosCP.fec_tipo_cambio != null && this.beanDatosCP.fec_tipo_cambio != "") {dijit.byId("global.fechaTC").setValue(new Date(this.beanDatosCP.fec_tipo_cambio));}  
                                  if (this.beanDatosCP.tipo_cambio != null && this.beanDatosCP.tipo_cambio != "") {dojo.byId("global.tc").value=this.beanDatosCP.tipo_cambio;}                             
                                  if (this.beanDatosCP.valor_facturado_exportacion != null && this.beanDatosCP.valor_facturado_exportacion != "") { dojo.byId("global.valorFacturadoExportacion").value=this.beanDatosCP.valor_facturado_exportacion;}
                                  //if (this.beanDatosCP.valor_embarcado_exportacion != null && this.beanDatosCP.valor_embarcado_exportacion != "") { dojo.byId("global.valorEmbarcadoExportacion").value=this.beanDatosCP.valor_facturado_exportacion;}
                                  if (this.beanDatosCP.base_imponible_operacion_gravada != null && this.beanDatosCP.base_imponible_operacion_gravada != "") {dojo.byId("global.baseImpOperacGrav").value=this.beanDatosCP.base_imponible_operacion_gravada;}
                                  if (this.beanDatosCP.descuento_base_imponible != null && this.beanDatosCP.descuento_base_imponible != "") {dojo.byId("global.descBaseImponible").value=this.beanDatosCP.descuento_base_imponible;}  
                                  if (this.beanDatosCP.importe_total_operacion_exonerada != null && this.beanDatosCP.importe_total_operacion_exonerada != "") {dojo.byId("global.importeOperacionExonerada").value=this.beanDatosCP.importe_total_operacion_exonerada;}
                                  if (this.beanDatosCP.importe_total_operacion_inafecta != null && this.beanDatosCP.importe_total_operacion_inafecta != "") {dojo.byId("global.importeOperacionInafecta").value=this.beanDatosCP.importe_total_operacion_inafecta;}
                                  if (this.beanDatosCP.isc != null && this.beanDatosCP.isc != "") {dojo.byId("global.isc").value=this.beanDatosCP.isc;}
                                  if (this.beanDatosCP.tasa_igv_ipm != null && this.beanDatosCP.tasa_igv_ipm != "") {dojo.byId("global.tasaIgvoipm").value=this.beanDatosCP.tasa_igv_ipm;}
                                  if (this.beanDatosCP.igv_ipm != null && this.beanDatosCP.igv_ipm != "") {dojo.byId("global.igvoipm").value=this.beanDatosCP.igv_ipm;}
                                  if (this.beanDatosCP.descuento_igv_ipm != null && this.beanDatosCP.descuento_igv_ipm != "") {dojo.byId("global.descuentoIgvoipm").value=this.beanDatosCP.descuento_igv_ipm;}                                  
                                  if (this.beanDatosCP.base_imponible_operacion_gravada_ivap != null && this.beanDatosCP.base_imponible_operacion_gravada_ivap != "") {dojo.byId("global.baseImponibleIvap").value=this.beanDatosCP.base_imponible_operacion_gravada_ivap;}
                                  if (this.beanDatosCP.ivap != null && this.beanDatosCP.ivap != "") {dojo.byId("global.ivap").value=this.beanDatosCP.ivap;}
                                  if (this.beanDatosCP.otros_tributos_cargos != null && this.beanDatosCP.otros_tributos_cargos != "") {dojo.byId("global.tributosCargosNoBaseImp").value=this.beanDatosCP.otros_tributos_cargos;}
                                  if (this.beanDatosCP.mto_importe_total != null && this.beanDatosCP.mto_importe_total != "") {dojo.byId("global.importeTotalCP").value=this.beanDatosCP.mto_importe_total;}
                                  if (this.beanDatosCP.gravado_premio != null && this.beanDatosCP.gravado_premio != "") {dojo.byId("global.grabadoPremio").value=this.beanDatosCP.gravado_premio;}
                                  if (this.beanDatosCP.gravado_donacion != null && this.beanDatosCP.gravado_donacion != "") {dojo.byId("global.grabadoDonacion").value=this.beanDatosCP.gravado_donacion;}
                                  if (this.beanDatosCP.gravado_entrega_trabajadores != null && this.beanDatosCP.gravado_entrega_trabajadores != "") {dojo.byId("global.grabadoEntregaTrabajadores").value=this.beanDatosCP.gravado_entrega_trabajadores;}
                                  if (this.beanDatosCP.gravado_publicidad != null && this.beanDatosCP.gravado_publicidad != "") {dojo.byId("global.grabadoPublicidad").value=this.beanDatosCP.gravado_publicidad;}
                                  if (this.beanDatosCP.gravado_bonificacion != null && this.beanDatosCP.gravado_bonificacion != "") {dojo.byId("global.grabadoBonificacion").value=this.beanDatosCP.gravado_bonificacion;}
                                  if (this.beanDatosCP.gravado_retiro_otros != null && this.beanDatosCP.gravado_retiro_otros != "") {dojo.byId("global.grabadoRetiroOtros").value=this.beanDatosCP.gravado_retiro_otros;}
                                  if (this.beanDatosCP.valor_facturado_exportacion_no_onerosa != null && this.beanDatosCP.valor_facturado_exportacion_no_onerosa != "") {dojo.byId("global.valorFacturaExportaNoOnerosa").value=this.beanDatosCP.valor_facturado_exportacion_no_onerosa;}
                                  if (this.beanDatosCP.importe_total_operacion_no_onerosa != null && this.beanDatosCP.importe_total_operacion_no_onerosa != "") {dojo.byId("global.importeOperacionNoOnerosaExo").value=this.beanDatosCP.importe_total_operacion_no_onerosa;}
                                  if (this.beanDatosCP.inafecto_premio != null && this.beanDatosCP.inafecto_premio != "") {dojo.byId("global.inafectoPremio").value=this.beanDatosCP.inafecto_premio;}
                                  if (this.beanDatosCP.inafecto_retiro_convenio_colectivo != null && this.beanDatosCP.inafecto_retiro_convenio_colectivo != "") {dojo.byId("global.inafectoRetiroConvenioColectivo").value=this.beanDatosCP.inafecto_retiro_convenio_colectivo;}
                                  if (this.beanDatosCP.inafecto_muestras_medicas != null && this.beanDatosCP.inafecto_muestras_medicas != "") {dojo.byId("global.inafectoMuestrasMedicas").value=this.beanDatosCP.inafecto_muestras_medicas;}
                                  if (this.beanDatosCP.inafecto_publicidad != null && this.beanDatosCP.inafecto_publicidad != "") {dojo.byId("global.inafectoPublicidad").value=this.beanDatosCP.inafecto_publicidad;}
                                  if (this.beanDatosCP.inafecto_bonificacion != null && this.beanDatosCP.inafecto_bonificacion != "") {dojo.byId("global.inafectoBonificacion").value=this.beanDatosCP.inafecto_bonificacion;}
                                  if (this.beanDatosCP.inafecto_retiro_otros != null && this.beanDatosCP.inafecto_retiro_otros != "") {dojo.byId("global.inafectoRetiroOtros").value=this.beanDatosCP.inafecto_retiro_otros;}
                                  if (this.beanDatosCP.fec_emision_cp_modif != null && this.beanDatosCP.fec_emision_cp_modif != "") {dijit.byId("global.fechaEmisionCPModificado").setValue(new Date(this.beanDatosCP.fec_emision_cp_modif));}  
                                  if (this.beanDatosCP.cod_cp_modif != null && this.beanDatosCP.cod_cp_modif != "") {dojo.byId("global.tipoCPModificado").value=this.beanDatosCP.cod_cp_modif;}
                                  if (this.beanDatosCP.num_serie_cp_modif != null && this.beanDatosCP.num_serie_cp_modif != "") {dojo.byId("global.numeroSerieCPModificado").value=this.beanDatosCP.num_serie_cp_modif;}
                                  if (this.beanDatosCP.num_cp_modif != null && this.beanDatosCP.num_cp_modif != "") {dojo.byId("global.numeroCPModificado").value=this.beanDatosCP.num_cp_modif;}
                                  if (this.beanDatosCP.contrato_colaboracion != null && this.beanDatosCP.contrato_colaboracion != "") {dojo.byId("global.contratoColaboracion").value=this.beanDatosCP.contrato_colaboracion;}
                                  if (this.beanDatosCP.error_tipo1 != null && this.beanDatosCP.error_tipo1 != "") {dojo.byId("global.errorTipo1").value=this.beanDatosCP.error_tipo1;}
                                  if (this.beanDatosCP.medio_de_pago != null && this.beanDatosCP.medio_de_pago != "") {dojo.byId("global.indicadorMedioPago").value=this.beanDatosCP.medio_de_pago;}                                  
                                  dojo.byId("global.cuoEncontrado").value = "1";
                                }else{
                                    dijit.byId("generales.cuo").attr('disabled', false)
                                    dojo.byId("global.cuoEncontrado").value = "1";   
                                    //this.iconTooltipMessage("generales.cuo", "icon-ok-tooltip", "No ha sido encontrado el CP Fisico con el CUO consignado.");     
                                                    
                                }
    
                             }else{
                                dijit.byId("generales.cuo").attr('disabled', false)
                                dojo.byId("global.cuoEncontrado").value = "0";
                                //this.iconTooltipMessage("generales.cuo", "icon-ok-tooltip", "No ha sido encontrado el CP Fisico con el CUO consignado.");
                                  
                             }
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                   
          			 } else {                                 
          				  alert(res.messageError);
          				  dojo.byId("global.cuoEncontrado").value = "0";
          				  return;
          			 }
          		 }));
               handler.addErrback(function(res){
              			this.waitMessage.hide();
              			dojo.byId("global.cuoEncontrado").value = "0";
              			alert("Problemas al conectarse con el servidor");
               }); 
          
          }
     }
     
    this.cargarDatosIngresados();
  },
  
	mostrarDatosdeCuo: function(){
	var estadoCP = dijit.byId("generales.estadoCP").getValue();
	  var esRER = dojo.byId("generales.esRER").value;
	  if (dojo.byId("generales.periodoAjuste").value.length != 7) {return;}
    var periodoSeleccionado = dijit.byId("generales.periodoAjuste").getValue().substring(3,7) + dijit.byId("generales.periodoAjuste").getValue().substring(0,2)  ;// dojo.byId("global.periodoComprobantes").value;
    /*Inicio SAU20156E811200022*/
    var periodoRegVenta = dijit.byId("generales.periodoRegVenta").getValue().substring(3,7) + dijit.byId("generales.periodoRegVenta").getValue().substring(0,2)  ;// dojo.byId("global.periodoComprobantes").value;
    /*Fin SAU20156E811200022*/      
    var cuo = dojo.byId("generales.cuo").value; 
    var correlativo = dojo.byId("generales.numeroCorrelativo").value; 
    var handler = null;
     
    if (estadoCP =="08" || estadoCP =="09"){
      if(dojo.byId("generales.periodoAjuste").value != "" &&  dojo.byId("generales.periodoAjuste").value.length == 7  ){ 
        dijit.byId("generales.fechaEmisionCP").setValue(new Date(dojo.byId("generales.periodoAjuste").value.substring(0,2) + "/01/" + dojo.byId("generales.periodoAjuste").value.substring(3,7)));
      } 
    } 
     //if (esRER == "RER"){
     //     dijit.byId("generales.cuo").setValue("RER");
     //     dijit.byId("generales.cuo").attr('disabled', true);
     //     dijit.byId("generales.numeroCorrelativo").attr("regExp", "[M][A-Za-z0-9]+");
     //}else{
          dijit.byId("generales.numeroCorrelativo").attr("regExp", "([AMC][A-Za-z0-9]+|-)");
          if ((estadoCP =="08" ) || (estadoCP =="09"  && cuo !="" )){
            if (periodoSeleccionado =="" ) {
             }else{
             
               this.beanDatosCP = null;
               if (estadoCP =="08" ){
                   handler = dojo.xhrGet({
                        
                        /*Inicio SAU20156E811200022*/
                        //url: this.controller + "?action=obtenerNumCuoCorrelativo&estadoCP=" + estadoCP +"&periodo=" + periodoSeleccionado ,
                        url: this.controller + "?action=obtenerNumCuoCorrelativo&estadoCP=" + estadoCP +"&periodo=" + periodoSeleccionado +"&periodoRegVenta=" + periodoRegVenta ,
                        /*Fin SAU20156E811200022*/                        
                        handleAs: "json",
                        sync: true,
                        timeout: 10000
                   });    
               }else{
                    periodoSeleccionado = dojo.byId("generales.periodoAjuste").value.substring(3,7) + dojo.byId("generales.periodoAjuste").value.substring(0,2)  ; //dojo.byId("generales.periodoAjuste").value; 
                    handler = dojo.xhrGet({
                        url: this.controller + "?action=validarCuoCorrelativo&estadoCP=" + estadoCP +"&periodo=" + periodoSeleccionado +"&cuo=" + cuo + "&correlativo=" + correlativo,
                        handleAs: "json",
                        sync: true,
                        timeout: 10000
                   });    
               }
               handler.addCallback(dojo.hitch(this, function(res){
            		   if (res.codeError == 0) {
          		       switch (estadoCP) { 
                          case "08": 
                             if (res.data != null && res.data  != ""  ){
                                this.beanCuoCorrel = eval("(" + res.data + ")");
                                if (this.beanCuoCorrel.cuo!=""){
                                    dijit.byId("generales.cuo").setValue(this.beanCuoCorrel.cuo);
                                    dijit.byId("generales.cuo").attr('disabled', true);
                                    this.cuoSV="";
                                    this.cuoIgualCorrelativo="";                                
                                }else{
                                     //dijit.byId("generales.cuo").setValue(res.data.substring(2,res.data.length));
                                     dijit.byId("generales.cuo").attr('disabled', false);
                                     this.cuoSV="";                                
                        
                                } 
                                if (this.beanCuoCorrel.correlativo=="-"){
                                    dijit.byId("generales.numeroCorrelativo").setValue("-");
                                    dijit.byId("generales.numeroCorrelativo").attr('disabled', true);
                                }else{
                                    if (this.beanCuoCorrel.correlativo==""){
                                        
                                        dijit.byId("generales.numeroCorrelativo").attr('disabled', false);
                                    }else{
                                        dijit.byId("generales.numeroCorrelativo").setValue(this.beanCuoCorrel.correlativo);
                                        dijit.byId("generales.numeroCorrelativo").attr('disabled', true);
                                    }
                                }          
                                

                             }else{
                                 dijit.byId("generales.numeroCorrelativo").attr('disabled', false);
                             }
                             break 
                          case "09": 
                             if (res.data != null &&  res.data  != ""){
                                this.cuoSV="";
                                this.beanDatosCP = eval("(" + res.data + ")");
                                //cargar datos recuperados de t4602cpfisicos en las pantallas de dato generales y de detalle
                                //Generales
                                if (this.beanDatosCP.num_correlativo=="-"){
                                    dijit.byId("generales.numeroCorrelativo").setValue("-");
                                    dijit.byId("generales.numeroCorrelativo").attr('disabled', true);
                                }else{
                                    if (this.beanDatosCP.num_correlativo==""){
                                        
                                        dijit.byId("generales.numeroCorrelativo").attr('disabled', false);
                                    }else{
                                        dijit.byId("generales.numeroCorrelativo").setValue(this.beanDatosCP.num_correlativo);
                                        dijit.byId("generales.numeroCorrelativo").attr('disabled', true);
                                    }
                                }                                 
                                if (this.beanDatosCP.cod_cp != null){
                                  dojo.byId("global.cuoEncontrado").value = "1";
                                  dijit.byId("generales.tipoDocRecepCP").setValue(this.beanDatosCP.cod_docide_recep + " - " + this.beanDatosCP.desc_cod_docide_recep);
                                  dijit.byId("generales.numeroDocRecepCP").setValue(this.beanDatosCP.num_docide_recep);
                                  dijit.byId("generales.razonSocialRecepCP").setValue(this.beanDatosCP.des_nombre_recep);
                                 if (this.beanDatosCP.fec_emision != null && this.beanDatosCP.fec_emision != "") {dijit.byId("generales.fechaEmisionCP").setValue(new Date(this.beanDatosCP.fec_emision));}
                                 //if (this.beanDatosCP.fec_emision != "") {dijit.byId("generales.fechaEmisionCP").setValue(this.beanDatosCP.fec_emision);}
                                  if (this.beanDatosCP.fec_vencimiento_pago != null && this.beanDatosCP.fec_vencimiento_pago != "") {dijit.byId("generales.fechaVencimientoPago").setValue(new Date(this.beanDatosCP.fec_vencimiento_pago));} 
                                  dijit.byId("generales.numeroSerieCP").setValue(this.beanDatosCP.num_serie_cp);
                                  if (this.beanDatosCP.num_cp != null && this.beanDatosCP.num_cp != "") {dijit.byId("generales.numeroCP").setValue(this.beanDatosCP.num_cp  );}
                                  if (this.beanDatosCP.num_correlativo != null && this.beanDatosCP.num_correlativo != "") {dijit.byId("generales.numeroCorrelativo").setValue(this.beanDatosCP.num_correlativo  );}
                                  if (this.beanDatosCP.num_correlativo != null && this.beanDatosCP.num_correlativo == "") {
                                      dijit.byId("generales.numeroCorrelativo").attr('disabled', true);
                                  }else{
                                      dijit.byId("generales.numeroCorrelativo").attr('disabled', false);
                                  }
                                  if (this.beanDatosCP.num_inicial != null && this.beanDatosCP.num_inicial != "") {dijit.byId("generales.numeroInicialCP").setValue(this.beanDatosCP.num_inicial );}
                                  if (this.beanDatosCP.num_final  != null && this.beanDatosCP.num_final  != "" && this.beanDatosCP.num_final  != "-") {dijit.byId("generales.numeroFinalCP").setValue(this.beanDatosCP.num_final );}
                                  //dijit.byId("generales.numeroSerieMaqRegistra").setValue(this.beanDatosCP.num_serie_maq);      
                                  //Detalle     
                                  if (this.beanDatosCP.cod_moneda != null && this.beanDatosCP.cod_moneda != "" && this.beanDatosCP.cod_moneda != "PEN" ) {dojo.byId("global.tipoMoneda").value=this.beanDatosCP.cod_moneda;}
                                  if (this.beanDatosCP.fec_tipo_cambio != null && this.beanDatosCP.fec_tipo_cambio != "") {dijit.byId("global.fechaTC").setValue(new Date(this.beanDatosCP.fec_tipo_cambio));}  
                                  if (this.beanDatosCP.tipo_cambio != null && this.beanDatosCP.tipo_cambio != "") {dojo.byId("global.tc").value=this.beanDatosCP.tipo_cambio;}                             
                                  if (this.beanDatosCP.valor_facturado_exportacion != null && this.beanDatosCP.valor_facturado_exportacion != "") { dojo.byId("global.valorFacturadoExportacion").value=this.beanDatosCP.valor_facturado_exportacion;}
                                  //if (this.beanDatosCP.valor_embarcado_exportacion != null && this.beanDatosCP.valor_embarcado_exportacion != "") { dojo.byId("global.valorEmbarcadoExportacion").value=this.beanDatosCP.valor_facturado_exportacion;}
                                  if (this.beanDatosCP.base_imponible_operacion_gravada != null && this.beanDatosCP.base_imponible_operacion_gravada != "") {dojo.byId("global.baseImpOperacGrav").value=this.beanDatosCP.base_imponible_operacion_gravada;} 
                                  if (this.beanDatosCP.descuento_base_imponible != null && this.beanDatosCP.descuento_base_imponible != "") {dojo.byId("global.descBaseImponible").value=this.beanDatosCP.descuento_base_imponible;} 
                                  if (this.beanDatosCP.importe_total_operacion_exonerada != null && this.beanDatosCP.importe_total_operacion_exonerada != "") {dojo.byId("global.importeOperacionExonerada").value=this.beanDatosCP.importe_total_operacion_exonerada;}
                                  if (this.beanDatosCP.importe_total_operacion_inafecta != null && this.beanDatosCP.importe_total_operacion_inafecta != "") {dojo.byId("global.importeOperacionInafecta").value=this.beanDatosCP.importe_total_operacion_inafecta;}
                                  if (this.beanDatosCP.isc != null && this.beanDatosCP.isc != "") {dojo.byId("global.isc").value=this.beanDatosCP.isc;}
                                  if (this.beanDatosCP.tasa_igv_ipm != null && this.beanDatosCP.tasa_igv_ipm != "") {dojo.byId("global.tasaIgvoipm").value=this.beanDatosCP.tasa_igv_ipm;}
                                  if (this.beanDatosCP.igv_ipm != null && this.beanDatosCP.igv_ipm != "") {dojo.byId("global.igvoipm").value=this.beanDatosCP.igv_ipm;}
                                  if (this.beanDatosCP.descuento_igv_ipm != null && this.beanDatosCP.descuento_igv_ipm != "") {dojo.byId("global.descuentoIgvoipm").value=this.beanDatosCP.descuento_igv_ipm;}
                                  if (this.beanDatosCP.base_imponible_operacion_gravada_ivap != null && this.beanDatosCP.base_imponible_operacion_gravada_ivap != "") {dojo.byId("global.baseImponibleIvap").value=this.beanDatosCP.base_imponible_operacion_gravada_ivap;}
                                  if (this.beanDatosCP.ivap != null && this.beanDatosCP.ivap != "") {dojo.byId("global.ivap").value=this.beanDatosCP.ivap;}
                                  if (this.beanDatosCP.otros_tributos_cargos != null && this.beanDatosCP.otros_tributos_cargos != "") {dojo.byId("global.tributosCargosNoBaseImp").value=this.beanDatosCP.otros_tributos_cargos;}
                                  if (this.beanDatosCP.mto_importe_total != null && this.beanDatosCP.mto_importe_total != "") {dojo.byId("global.importeTotalCP").value=this.beanDatosCP.mto_importe_total;}
                                  if (this.beanDatosCP.gravado_premio != null && this.beanDatosCP.gravado_premio != "") {dojo.byId("global.grabadoPremio").value=this.beanDatosCP.gravado_premio;}
                                  if (this.beanDatosCP.gravado_donacion != null && this.beanDatosCP.gravado_donacion != "") {dojo.byId("global.grabadoDonacion").value=this.beanDatosCP.gravado_donacion;}
                                  if (this.beanDatosCP.gravado_entrega_trabajadores != null && this.beanDatosCP.gravado_entrega_trabajadores != "") {dojo.byId("global.grabadoEntregaTrabajadores").value=this.beanDatosCP.gravado_entrega_trabajadores;}
                                  if (this.beanDatosCP.gravado_publicidad != null && this.beanDatosCP.gravado_publicidad != "") {dojo.byId("global.grabadoPublicidad").value=this.beanDatosCP.gravado_publicidad;}
                                  if (this.beanDatosCP.gravado_bonificacion != null && this.beanDatosCP.gravado_bonificacion != "") {dojo.byId("global.grabadoBonificacion").value=this.beanDatosCP.gravado_bonificacion;}
                                  if (this.beanDatosCP.gravado_retiro_otros != null && this.beanDatosCP.gravado_retiro_otros != "") {dojo.byId("global.grabadoRetiroOtros").value=this.beanDatosCP.gravado_retiro_otros;}
                                  if (this.beanDatosCP.valor_facturado_exportacion_no_onerosa != null && this.beanDatosCP.valor_facturado_exportacion_no_onerosa != "") {dojo.byId("global.valorFacturaExportaNoOnerosa").value=this.beanDatosCP.valor_facturado_exportacion_no_onerosa;}
                                  if (this.beanDatosCP.importe_total_operacion_no_onerosa != null && this.beanDatosCP.importe_total_operacion_no_onerosa != "") {dojo.byId("global.importeOperacionNoOnerosaExo").value=this.beanDatosCP.importe_total_operacion_no_onerosa;}
                                  if (this.beanDatosCP.inafecto_premio != null && this.beanDatosCP.inafecto_premio != "") {dojo.byId("global.inafectoPremio").value=this.beanDatosCP.inafecto_premio;}
                                  if (this.beanDatosCP.inafecto_retiro_convenio_colectivo != null && this.beanDatosCP.inafecto_retiro_convenio_colectivo != "") {dojo.byId("global.inafectoRetiroConvenioColectivo").value=this.beanDatosCP.inafecto_retiro_convenio_colectivo;}
                                  if (this.beanDatosCP.inafecto_muestras_medicas != null && this.beanDatosCP.inafecto_muestras_medicas != "") {dojo.byId("global.inafectoMuestrasMedicas").value=this.beanDatosCP.inafecto_muestras_medicas;}
                                  if (this.beanDatosCP.inafecto_publicidad != null && this.beanDatosCP.inafecto_publicidad != "") {dojo.byId("global.inafectoPublicidad").value=this.beanDatosCP.inafecto_publicidad;}
                                  if (this.beanDatosCP.inafecto_bonificacion != null && this.beanDatosCP.inafecto_bonificacion != "") {dojo.byId("global.inafectoBonificacion").value=this.beanDatosCP.inafecto_bonificacion;}
                                  if (this.beanDatosCP.inafecto_retiro_otros != null && this.beanDatosCP.inafecto_retiro_otros != "") {dojo.byId("global.inafectoRetiroOtros").value=this.beanDatosCP.inafecto_retiro_otros;}
                                  if (this.beanDatosCP.fec_emision_cp_modif != null && this.beanDatosCP.fec_emision_cp_modif != "") {dijit.byId("global.fechaEmisionCPModificado").setValue(new Date(this.beanDatosCP.fec_emision_cp_modif));}  
                                  if (this.beanDatosCP.cod_cp_modif != null && this.beanDatosCP.cod_cp_modif != "") {dojo.byId("global.tipoCPModificado").value=this.beanDatosCP.cod_cp_modif;}
                                  if (this.beanDatosCP.num_serie_cp_modif != null && this.beanDatosCP.num_serie_cp_modif != "") {dojo.byId("global.numeroSerieCPModificado").value=this.beanDatosCP.num_serie_cp_modif;}
                                  if (this.beanDatosCP.num_cp_modif != null && this.beanDatosCP.num_cp_modif != "") {dojo.byId("global.numeroCPModificado").value=this.beanDatosCP.num_cp_modif;}
                                  if (this.beanDatosCP.contrato_colaboracion != null && this.beanDatosCP.contrato_colaboracion != "") {dojo.byId("global.contratoColaboracion").value=this.beanDatosCP.contrato_colaboracion;}
                                  if (this.beanDatosCP.error_tipo1 != null && this.beanDatosCP.error_tipo1 != "") {dojo.byId("global.errorTipo1").value=this.beanDatosCP.error_tipo1;}
                                  if (this.beanDatosCP.medio_de_pago != null && this.beanDatosCP.medio_de_pago != "") {dojo.byId("global.indicadorMedioPago").value=this.beanDatosCP.medio_de_pago;}                                  
                                  dojo.byId("global.cuoEncontrado").value = "1";
                                }else{
                                    dijit.byId("generales.cuo").attr('disabled', false)
                                    dojo.byId("global.cuoEncontrado").value = "1";   
                                    //this.iconTooltipMessage("generales.cuo", "icon-ok-tooltip", "No ha sido encontrado el CP Fisico con el CUO consignado.");     
                                                    
                                }
    
                             }else{
                                dijit.byId("generales.cuo").attr('disabled', false)
                                dojo.byId("global.cuoEncontrado").value = "0";
                                //this.iconTooltipMessage("generales.cuo", "icon-ok-tooltip", "No ha sido encontrado el CP Fisico con el CUO consignado.");
                                  
                             }
                             break 
                     } 
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                    
          			 } else {                                 
          				  alert(res.messageError);
          				  dojo.byId("global.cuoEncontrado").value = "0";
          				  return;
          			 }
          		 }));
               handler.addErrback(function(res){
              			this.waitMessage.hide();
              			dojo.byId("global.cuoEncontrado").value = "0";
              			alert("Problemas al conectarse con el servidor");
               }); 
             }
         }
     //}
       
      var correlativo = dijit.byId("generales.numeroCorrelativo").getValue() ;
     if (estadoCP =="08" ){
          //periodoSeleccionado = dijit.byId("generales.periodoRegVenta").getValue().substring(3,7) + dijit.byId("generales.periodoRegVenta").getValue().substring(0,2)  ;
          //if (estadoCP =="08" ){
               periodoSeleccionado = dijit.byId("generales.periodoAjuste").getValue().substring(3,7) + dijit.byId("generales.periodoAjuste").getValue().substring(0,2)  ;
          //}
          cuo = dojo.byId("generales.cuo").value; 
          
          if (dijit.byId("generales.numeroCorrelativo").getValue() != ""){
          
                   handler = dojo.xhrGet({
                        url: this.controller + "?action=validarExisteCuoCorrelativo&estadoCP=" + estadoCP +"&periodo=" + periodoSeleccionado +"&cuo=" + cuo  + "&correlativo=" + correlativo,
                        handleAs: "json",
                        sync: true,
                        timeout: 20000
                   });  
               handler.addCallback(dojo.hitch(this, function(res){
            		   if (res.codeError == 0) {
 
                       if (res.data != null && res.data == "1" ){
                          if (estadoCP =="08" ){
                              alert("Ya existe un registro previo con el mismo CUO y Numero Correlativo en el periodo que corresponde al ajuste.");
                          }else{
                              alert("Ya existe un registro previo con el mismo CUO y Numero Correlativo en el periodo.");
                          }
                          dojo.byId("global.cuoEncontrado").value = "1"; 
                          return;
                       }else{
                          dojo.byId("global.cuoEncontrado").value = "0";
                       }
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                   
          			 } else {                                 
          				  alert(res.messageError);
          				  dojo.byId("global.cuoEncontrado").value = "0";
          				  return;
          			 }
          		 }));
               handler.addErrback(function(res){
              			this.waitMessage.hide();
              			dojo.byId("global.cuoEncontrado").value = "0";
              			alert("Problemas al conectarse con el servidor");
               }); 
          }
          
     } else{
          periodoSeleccionado = dijit.byId("generales.periodoAjuste").getValue().substring(3,7) + dijit.byId("generales.periodoAjuste").getValue().substring(0,2)  ;
          if (dijit.byId("generales.numeroCorrelativo").getValue() != ""){
                    
                   handler = dojo.xhrGet({
                        url: this.controller + "?action=validarCuoCorrelativo&estadoCP=" + estadoCP +"&periodo=" + periodoSeleccionado +"&cuo=" + cuo  + "&correlativo=" + correlativo,
                        handleAs: "json",
                        sync: true,
                        timeout: 20000
                   });  
               handler.addCallback(dojo.hitch(this, function(res){
            		   if (res.codeError == 0) {
 
                             if (res.data != null &&  res.data  != ""){
                                this.cuoSV="";
                                this.beanDatosCP = eval("(" + res.data + ")");
                                //cargar datos recuperados de t4602cpfisicos en las pantallas de dato generales y de detalle
                                //Generales
                                if (this.beanDatosCP.cod_cp != null){
                                  dojo.byId("global.cuoEncontrado").value = "1";
                                  dijit.byId("generales.tipoDocRecepCP").setValue(this.beanDatosCP.cod_docide_recep + " - " + this.beanDatosCP.desc_cod_docide_recep);
                                  dijit.byId("generales.numeroDocRecepCP").setValue(this.beanDatosCP.num_docide_recep);
                                  dijit.byId("generales.razonSocialRecepCP").setValue(this.beanDatosCP.des_nombre_recep);
                                 if (this.beanDatosCP.fec_emision != null && this.beanDatosCP.fec_emision != "") {dijit.byId("generales.fechaEmisionCP").setValue(new Date(this.beanDatosCP.fec_emision));}
                                 //if (this.beanDatosCP.fec_emision != "") {dijit.byId("generales.fechaEmisionCP").setValue(this.beanDatosCP.fec_emision);}
                                  if (this.beanDatosCP.fec_vencimiento_pago != null && this.beanDatosCP.fec_vencimiento_pago != "") {dijit.byId("generales.fechaVencimientoPago").setValue(new Date(this.beanDatosCP.fec_vencimiento_pago));} 
                                  dijit.byId("generales.numeroSerieCP").setValue(this.beanDatosCP.num_serie_cp);
                                  if (this.beanDatosCP.num_cp != null && this.beanDatosCP.num_cp != "") {dijit.byId("generales.numeroCP").setValue(this.beanDatosCP.num_cp  );}
                                  if (this.beanDatosCP.num_correlativo != null && this.beanDatosCP.num_correlativo != "") {dijit.byId("generales.numeroCorrelativo").setValue(this.beanDatosCP.num_correlativo  );}
                                  if (this.beanDatosCP.num_correlativo != null && this.beanDatosCP.num_correlativo == "") {
                                      dijit.byId("generales.numeroCorrelativo").attr('disabled', true);
                                  }else{
                                      dijit.byId("generales.numeroCorrelativo").attr('disabled', false);
                                  }                                  
                                  if (this.beanDatosCP.num_inicial != null && this.beanDatosCP.num_inicial != "") {dijit.byId("generales.numeroInicialCP").setValue(this.beanDatosCP.num_inicial );}
                                  if (this.beanDatosCP.num_final  != null && this.beanDatosCP.num_final  != "") {dijit.byId("generales.numeroFinalCP").setValue(this.beanDatosCP.num_final );}
                                  //dijit.byId("generales.numeroSerieMaqRegistra").setValue(this.beanDatosCP.num_serie_maq);      
                                  //Detalle     
                                  if (this.beanDatosCP.cod_moneda != null && this.beanDatosCP.cod_moneda != "" && this.beanDatosCP.cod_moneda != "PEN" ) {dojo.byId("global.tipoMoneda").value=this.beanDatosCP.cod_moneda;}
                                  if (this.beanDatosCP.fec_tipo_cambio != null && this.beanDatosCP.fec_tipo_cambio != "") {dijit.byId("global.fechaTC").setValue(new Date(this.beanDatosCP.fec_tipo_cambio));}  
                                  if (this.beanDatosCP.tipo_cambio != null && this.beanDatosCP.tipo_cambio != "") {dojo.byId("global.tc").value=this.beanDatosCP.tipo_cambio;}                             
                                  if (this.beanDatosCP.valor_facturado_exportacion != null && this.beanDatosCP.valor_facturado_exportacion != "") { dojo.byId("global.valorFacturadoExportacion").value=this.beanDatosCP.valor_facturado_exportacion;}
                                  //if (this.beanDatosCP.valor_embarcado_exportacion != null && this.beanDatosCP.valor_embarcado_exportacion != "") { dojo.byId("global.valorEmbarcadoExportacion").value=this.beanDatosCP.valor_facturado_exportacion;}
                                  if (this.beanDatosCP.base_imponible_operacion_gravada != null && this.beanDatosCP.base_imponible_operacion_gravada != "") {dojo.byId("global.baseImpOperacGrav").value=this.beanDatosCP.base_imponible_operacion_gravada;}
                                  if (this.beanDatosCP.descuento_base_imponible != null && this.beanDatosCP.descuento_base_imponible != "") {dojo.byId("global.descBaseImponible").value=this.beanDatosCP.descuento_base_imponible;}  
                                  if (this.beanDatosCP.importe_total_operacion_exonerada != null && this.beanDatosCP.importe_total_operacion_exonerada != "") {dojo.byId("global.importeOperacionExonerada").value=this.beanDatosCP.importe_total_operacion_exonerada;}
                                  if (this.beanDatosCP.importe_total_operacion_inafecta != null && this.beanDatosCP.importe_total_operacion_inafecta != "") {dojo.byId("global.importeOperacionInafecta").value=this.beanDatosCP.importe_total_operacion_inafecta;}
                                  if (this.beanDatosCP.isc != null && this.beanDatosCP.isc != "") {dojo.byId("global.isc").value=this.beanDatosCP.isc;}
                                  if (this.beanDatosCP.tasa_igv_ipm != null && this.beanDatosCP.tasa_igv_ipm != "") {dojo.byId("global.tasaIgvoipm").value=this.beanDatosCP.tasa_igv_ipm;}
                                  if (this.beanDatosCP.igv_ipm != null && this.beanDatosCP.igv_ipm != "") {dojo.byId("global.igvoipm").value=this.beanDatosCP.igv_ipm;}
                                  if (this.beanDatosCP.descuento_igv_ipm != null && this.beanDatosCP.descuento_igv_ipm != "") {dojo.byId("global.descuentoIgvoipm").value=this.beanDatosCP.descuento_igv_ipm;}
                                  if (this.beanDatosCP.base_imponible_operacion_gravada_ivap != null && this.beanDatosCP.base_imponible_operacion_gravada_ivap != "") {dojo.byId("global.baseImponibleIvap").value=this.beanDatosCP.base_imponible_operacion_gravada_ivap;}
                                  if (this.beanDatosCP.ivap != null && this.beanDatosCP.ivap != "") {dojo.byId("global.ivap").value=this.beanDatosCP.ivap;}
                                  if (this.beanDatosCP.otros_tributos_cargos != null && this.beanDatosCP.otros_tributos_cargos != "") {dojo.byId("global.tributosCargosNoBaseImp").value=this.beanDatosCP.otros_tributos_cargos;}
                                  if (this.beanDatosCP.mto_importe_total != null && this.beanDatosCP.mto_importe_total != "") {dojo.byId("global.importeTotalCP").value=this.beanDatosCP.mto_importe_total;}
                                  if (this.beanDatosCP.gravado_premio != null && this.beanDatosCP.gravado_premio != "") {dojo.byId("global.grabadoPremio").value=this.beanDatosCP.gravado_premio;}
                                  if (this.beanDatosCP.gravado_donacion != null && this.beanDatosCP.gravado_donacion != "") {dojo.byId("global.grabadoDonacion").value=this.beanDatosCP.gravado_donacion;}
                                  if (this.beanDatosCP.gravado_entrega_trabajadores != null && this.beanDatosCP.gravado_entrega_trabajadores != "") {dojo.byId("global.grabadoEntregaTrabajadores").value=this.beanDatosCP.gravado_entrega_trabajadores;}
                                  if (this.beanDatosCP.gravado_publicidad != null && this.beanDatosCP.gravado_publicidad != "") {dojo.byId("global.grabadoPublicidad").value=this.beanDatosCP.gravado_publicidad;}
                                  if (this.beanDatosCP.gravado_bonificacion != null && this.beanDatosCP.gravado_bonificacion != "") {dojo.byId("global.grabadoBonificacion").value=this.beanDatosCP.gravado_bonificacion;}
                                  if (this.beanDatosCP.gravado_retiro_otros != null && this.beanDatosCP.gravado_retiro_otros != "") {dojo.byId("global.grabadoRetiroOtros").value=this.beanDatosCP.gravado_retiro_otros;}
                                  if (this.beanDatosCP.valor_facturado_exportacion_no_onerosa != null && this.beanDatosCP.valor_facturado_exportacion_no_onerosa != "") {dojo.byId("global.valorFacturaExportaNoOnerosa").value=this.beanDatosCP.valor_facturado_exportacion_no_onerosa;}
                                  if (this.beanDatosCP.importe_total_operacion_no_onerosa != null && this.beanDatosCP.importe_total_operacion_no_onerosa != "") {dojo.byId("global.importeOperacionNoOnerosaExo").value=this.beanDatosCP.importe_total_operacion_no_onerosa;}
                                  if (this.beanDatosCP.inafecto_premio != null && this.beanDatosCP.inafecto_premio != "") {dojo.byId("global.inafectoPremio").value=this.beanDatosCP.inafecto_premio;}
                                  if (this.beanDatosCP.inafecto_retiro_convenio_colectivo != null && this.beanDatosCP.inafecto_retiro_convenio_colectivo != "") {dojo.byId("global.inafectoRetiroConvenioColectivo").value=this.beanDatosCP.inafecto_retiro_convenio_colectivo;}
                                  if (this.beanDatosCP.inafecto_muestras_medicas != null && this.beanDatosCP.inafecto_muestras_medicas != "") {dojo.byId("global.inafectoMuestrasMedicas").value=this.beanDatosCP.inafecto_muestras_medicas;}
                                  if (this.beanDatosCP.inafecto_publicidad != null && this.beanDatosCP.inafecto_publicidad != "") {dojo.byId("global.inafectoPublicidad").value=this.beanDatosCP.inafecto_publicidad;}
                                  if (this.beanDatosCP.inafecto_bonificacion != null && this.beanDatosCP.inafecto_bonificacion != "") {dojo.byId("global.inafectoBonificacion").value=this.beanDatosCP.inafecto_bonificacion;}
                                  if (this.beanDatosCP.inafecto_retiro_otros != null && this.beanDatosCP.inafecto_retiro_otros != "") {dojo.byId("global.inafectoRetiroOtros").value=this.beanDatosCP.inafecto_retiro_otros;}
                                  if (this.beanDatosCP.fec_emision_cp_modif != null && this.beanDatosCP.fec_emision_cp_modif != "") {dijit.byId("global.fechaEmisionCPModificado").setValue(new Date(this.beanDatosCP.fec_emision_cp_modif));}  
                                  if (this.beanDatosCP.cod_cp_modif != null && this.beanDatosCP.cod_cp_modif != "") {dojo.byId("global.tipoCPModificado").value=this.beanDatosCP.cod_cp_modif;}
                                  if (this.beanDatosCP.num_serie_cp_modif != null && this.beanDatosCP.num_serie_cp_modif != "") {dojo.byId("global.numeroSerieCPModificado").value=this.beanDatosCP.num_serie_cp_modif;}
                                  if (this.beanDatosCP.num_cp_modif != null && this.beanDatosCP.num_cp_modif != "") {dojo.byId("global.numeroCPModificado").value=this.beanDatosCP.num_cp_modif;}
                                  if (this.beanDatosCP.contrato_colaboracion != null && this.beanDatosCP.contrato_colaboracion != "") {dojo.byId("global.contratoColaboracion").value=this.beanDatosCP.contrato_colaboracion;}
                                  if (this.beanDatosCP.error_tipo1 != null && this.beanDatosCP.error_tipo1 != "") {dojo.byId("global.errorTipo1").value=this.beanDatosCP.error_tipo1;}
                                  if (this.beanDatosCP.medio_de_pago != null && this.beanDatosCP.medio_de_pago != "") {dojo.byId("global.indicadorMedioPago").value=this.beanDatosCP.medio_de_pago;}                                  
                                  dojo.byId("global.cuoEncontrado").value = "1";
                                }else{
                                    dijit.byId("generales.cuo").attr('disabled', false)
                                    dojo.byId("global.cuoEncontrado").value = "1";   
                                    //this.iconTooltipMessage("generales.cuo", "icon-ok-tooltip", "No ha sido encontrado el CP Fisico con el CUO consignado.");     
                                                    
                                }
    
                             }else{
                                dijit.byId("generales.cuo").attr('disabled', false)
                                dojo.byId("global.cuoEncontrado").value = "0";
                                //this.iconTooltipMessage("generales.cuo", "icon-ok-tooltip", "No ha sido encontrado el CP Fisico con el CUO consignado.");
                                  
                             }
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                   
          			 } else {                                 
          				  alert(res.messageError);
          				  dojo.byId("global.cuoEncontrado").value = "0";
          				  return;
          			 }
          		 }));
               handler.addErrback(function(res){
              			this.waitMessage.hide();
              			dojo.byId("global.cuoEncontrado").value = "0";
              			alert("Problemas al conectarse con el servidor");
               }); 
          
          }
     }
     
  },
  /*
	mostrarDatosdeCuo: function() {
    var estadoCP = dijit.byId("generales.estadoCP").getValue();
	  var periodoSeleccionado = dojo.byId("generales.periodoAjuste").value.substring(3,7) + dojo.byId("generales.periodoAjuste").value.substring(0,2)  ;//dojo.byId("generales.periodoAjuste").value; // dojo.byId("global.periodoComprobantes").value; 
    var cuo = dojo.byId("generales.cuo").value; 
    if (estadoCP =="08" || estadoCP =="09"){
      if(dojo.byId("generales.periodoAjuste").value != ""){
        dijit.byId("generales.fechaEmisionCP").setValue(new Date(dojo.byId("generales.periodoAjuste").value.substring(0,2) + "/01/" + dojo.byId("generales.periodoAjuste").value.substring(3,7)));
      } 
    } 
    var handler = null;
    var esRER = dojo.byId("generales.esRER").value;
    if (esRER == "RER"){
          dijit.byId("generales.cuo").setValue("RER");
          dijit.byId("generales.cuo").attr('disabled', true);
          return;
     }
      if ((estadoCP =="09" ) && cuo!=""){
              this.beanDatosCP = null;
                handler = dojo.xhrGet({
                    url: this.controller + "?action=verificarNumCuo&estadoCP=" + estadoCP +"&periodo=" + periodoSeleccionado +"&cuo=" + cuo  ,
                    handleAs: "json",
                    preventCache:  true,
                    sync: true,
                    timeout: 10000
               });    

               handler.addCallback(dojo.hitch(this, function(res){
        		   if (res.codeError == 0) {
                     if (res.data != null &&  res.data  != ""){
                         this.cuoSV="";
                        this.beanDatosCP = eval("(" + res.data + ")");
                        if (this.beanDatosCP.cod_cp != null){
                             //cargar datos recuperados de t4602cpfisicos en las pantallas de dato generales y de detalle
                            //Generales
                            dojo.byId("global.cuoEncontrado").value = "1";
                            dijit.byId("generales.tipoDocRecepCP").setValue(this.beanDatosCP.cod_docide_recep + " - " + this.beanDatosCP.desc_cod_docide_recep);
                            dijit.byId("generales.numeroDocRecepCP").setValue(this.beanDatosCP.num_docide_recep);
                            dijit.byId("generales.razonSocialRecepCP").setValue(this.beanDatosCP.des_nombre_recep);
                            if (this.beanDatosCP.fec_emision != "") {dijit.byId("generales.fechaEmisionCP").setValue(new Date(this.beanDatosCP.fec_emision));}
                            if (this.beanDatosCP.fec_vencimiento_pago != null && this.beanDatosCP.fec_vencimiento_pago != "") {dijit.byId("generales.fechaVencimientoPago").setValue(new Date(this.beanDatosCP.fec_vencimiento_pago));} 
                            dijit.byId("generales.numeroSerieCP").setValue(this.beanDatosCP.num_serie_cp);
                            if (this.beanDatosCP.num_correlativo != null && this.beanDatosCP.num_correlativo != "") {dijit.byId("generales.numeroCorrelativo").setValue(this.beanDatosCP.num_correlativo  );}
                            if (this.beanDatosCP.num_cp != null && this.beanDatosCP.num_cp != "") {dijit.byId("generales.numeroCP").setValue(this.beanDatosCP.num_cp  );}
                            if (this.beanDatosCP.num_inicial != null && this.beanDatosCP.num_inicial != "") {dijit.byId("generales.numeroInicialCP").setValue(this.beanDatosCP.num_inicial );}
                            if (this.beanDatosCP.num_final  != null && this.beanDatosCP.num_final  != "") {dijit.byId("generales.numeroFinalCP").setValue(this.beanDatosCP.num_final );}
                            //dijit.byId("generales.numeroSerieMaqRegistra").setValue(this.beanDatosCP.num_serie_maq);      
                            //Detalle     
                            if (this.beanDatosCP.cod_moneda != null && this.beanDatosCP.cod_moneda != "" && this.beanDatosCP.cod_moneda != "PEN" ) {dojo.byId("global.tipoMoneda").value=this.beanDatosCP.cod_moneda;}
                            if (this.beanDatosCP.fec_tipo_cambio != null && this.beanDatosCP.fec_tipo_cambio != "") {dijit.byId("global.fechaTC").setValue(new Date(this.beanDatosCP.fec_tipo_cambio));}
                            if (this.beanDatosCP.tipo_cambio != null && this.beanDatosCP.tipo_cambio != "") {dojo.byId("global.tc").value=this.beanDatosCP.tipo_cambio;}                             
                            if (this.beanDatosCP.valor_facturado_exportacion != null && this.beanDatosCP.valor_facturado_exportacion != "") { dojo.byId("global.valorFacturadoExportacion").value=this.beanDatosCP.valor_facturado_exportacion;}
                            if (this.beanDatosCP.valor_embarcado_exportacion != null && this.beanDatosCP.valor_embarcado_exportacion != "") { dojo.byId("global.valorEmbarcadoExportacion").value=this.beanDatosCP.valor_facturado_exportacion;}
                            if (this.beanDatosCP.base_imponible_operacion_gravada != null && this.beanDatosCP.base_imponible_operacion_gravada != "") {dojo.byId("global.baseImpOperacGrav").value=this.beanDatosCP.base_imponible_operacion_gravada;}
                            if (this.beanDatosCP.importe_total_operacion_exonerada != null && this.beanDatosCP.importe_total_operacion_exonerada != "") {dojo.byId("global.importeOperacionExonerada").value=this.beanDatosCP.importe_total_operacion_exonerada;}
                            if (this.beanDatosCP.importe_total_operacion_inafecta != null && this.beanDatosCP.importe_total_operacion_inafecta != "") {dojo.byId("global.importeOperacionInafecta").value=this.beanDatosCP.importe_total_operacion_inafecta;}
                            if (this.beanDatosCP.isc != null && this.beanDatosCP.isc != "") {dojo.byId("global.isc").value=this.beanDatosCP.isc;}
                            if (this.beanDatosCP.tasa_igv_ipm != null && this.beanDatosCP.tasa_igv_ipm != "") {dojo.byId("global.tasaIgvoipm").value=this.beanDatosCP.tasa_igv_ipm;}
                            if (this.beanDatosCP.igv_ipm != null && this.beanDatosCP.igv_ipm != "") {dojo.byId("global.igvoipm").value=this.beanDatosCP.igv_ipm;}
                            if (this.beanDatosCP.base_imponible_operacion_gravada_ivap != null && this.beanDatosCP.base_imponible_operacion_gravada_ivap != "") {dojo.byId("global.baseImponibleIvap").value=this.beanDatosCP.base_imponible_operacion_gravada_ivap;}
                            if (this.beanDatosCP.ivap != null && this.beanDatosCP.ivap != "") {dojo.byId("global.ivap").value=this.beanDatosCP.ivap;}
                            if (this.beanDatosCP.otros_tributos_cargos != null && this.beanDatosCP.otros_tributos_cargos != "") {dojo.byId("global.tributosCargosNoBaseImp").value=this.beanDatosCP.otros_tributos_cargos;}
                            if (this.beanDatosCP.mto_importe_total != null && this.beanDatosCP.mto_importe_total != "") {dojo.byId("global.importeTotalCP").value=this.beanDatosCP.mto_importe_total;}
                            if (this.beanDatosCP.gravado_premio != null && this.beanDatosCP.gravado_premio != "") {dojo.byId("global.grabadoPremio").value=this.beanDatosCP.gravado_premio;}
                            if (this.beanDatosCP.gravado_donacion != null && this.beanDatosCP.gravado_donacion != "") {dojo.byId("global.grabadoDonacion").value=this.beanDatosCP.gravado_donacion;}
                            if (this.beanDatosCP.gravado_entrega_trabajadores != null && this.beanDatosCP.gravado_entrega_trabajadores != "") {dojo.byId("global.grabadoEntregaTrabajadores").value=this.beanDatosCP.gravado_entrega_trabajadores;}
                            if (this.beanDatosCP.gravado_publicidad != null && this.beanDatosCP.gravado_publicidad != "") {dojo.byId("global.grabadoPublicidad").value=this.beanDatosCP.gravado_publicidad;}
                            if (this.beanDatosCP.gravado_bonificacion != null && this.beanDatosCP.gravado_bonificacion != "") {dojo.byId("global.grabadoBonificacion").value=this.beanDatosCP.gravado_bonificacion;}
                            if (this.beanDatosCP.gravado_retiro_otros != null && this.beanDatosCP.gravado_retiro_otros != "") {dojo.byId("global.grabadoRetiroOtros").value=this.beanDatosCP.gravado_retiro_otros;}
                            if (this.beanDatosCP.valor_facturado_exportacion_no_onerosa != null && this.beanDatosCP.valor_facturado_exportacion_no_onerosa != "") {dojo.byId("global.valorFacturaExportaNoOnerosa").value=this.beanDatosCP.valor_facturado_exportacion_no_onerosa;}
                            if (this.beanDatosCP.importe_total_operacion_no_onerosa != null && this.beanDatosCP.importe_total_operacion_no_onerosa != "") {dojo.byId("global.importeOperacionNoOnerosaExo").value=this.beanDatosCP.importe_total_operacion_no_onerosa;}
                            if (this.beanDatosCP.inafecto_premio != null && this.beanDatosCP.inafecto_premio != "") {dojo.byId("global.inafectoPremio").value=this.beanDatosCP.inafecto_premio;}
                            if (this.beanDatosCP.inafecto_retiro_convenio_colectivo != null && this.beanDatosCP.inafecto_retiro_convenio_colectivo != "") {dojo.byId("global.inafectoRetiroConvenioColectivo").value=this.beanDatosCP.inafecto_retiro_convenio_colectivo;}
                            if (this.beanDatosCP.inafecto_muestras_medicas != null && this.beanDatosCP.inafecto_muestras_medicas != "") {dojo.byId("global.inafectoMuestrasMedicas").value=this.beanDatosCP.inafecto_muestras_medicas;}
                            if (this.beanDatosCP.inafecto_publicidad != null && this.beanDatosCP.inafecto_publicidad != "") {dojo.byId("global.inafectoPublicidad").value=this.beanDatosCP.inafecto_publicidad;}
                            if (this.beanDatosCP.inafecto_bonificacion != null && this.beanDatosCP.inafecto_bonificacion != "") {dojo.byId("global.inafectoBonificacion").value=this.beanDatosCP.inafecto_bonificacion;}
                            if (this.beanDatosCP.inafecto_retiro_otros != null && this.beanDatosCP.inafecto_retiro_otros != "") {dojo.byId("global.inafectoRetiroOtros").value=this.beanDatosCP.inafecto_retiro_otros;}
                            if (this.beanDatosCP.fec_emision_cp_modif != null && this.beanDatosCP.fec_emision_cp_modif != "") {dijit.byId("global.fechaEmisionCPModificado").setValue(new Date(this.beanDatosCP.fec_emision_cp_modif));}  
                            if (this.beanDatosCP.cod_cp_modif != null && this.beanDatosCP.cod_cp_modif != "") {dojo.byId("global.tipoCPModificado").value=this.beanDatosCP.cod_cp_modif;}
                            if (this.beanDatosCP.num_serie_cp_modif != null && this.beanDatosCP.num_serie_cp_modif != "") {dojo.byId("global.numeroSerieCPModificado").value=this.beanDatosCP.num_serie_cp_modif;}
                            if (this.beanDatosCP.num_cp_modif != null && this.beanDatosCP.num_cp_modif != "") {dojo.byId("global.numeroCPModificado").value=this.beanDatosCP.num_cp_modif;}
                            dojo.byId("global.cuoEncontrado").value = "1";
                            dijit.hideTooltip(dojo.byId("generales.cuo")); 
                          }
                          else{
                            dijit.byId("generales.cuo").attr('disabled', false);
                            dojo.byId("global.cuoEncontrado").value = "1"; //en este caso no hay nada   ue validar
                            //this.iconTooltipMessage("generales.cuo", "icon-ok-tooltip", "No ha sido encontrado el CP Fisico con el CUO consignado.");  
                            
                          }
                      }else{
                            dijit.byId("generales.cuo").attr('disabled', false);
                            dojo.byId("global.cuoEncontrado").value = "0";
                            //this.iconTooltipMessage("generales.cuo", "icon-ok-tooltip", "No ha sido encontrado el CP Fisico con el CUO consignado.");
                     }
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                          
      			 } else {       
                 dojo.byId("global.cuoEncontrado").value = "0";                          
      				  alert(res.messageError);
      				    				  
      			 }
      		 }));
           handler.addErrback(function(res){
          			this.waitMessage.hide();
          			dojo.byId("global.cuoEncontrado").value = "0";
          			alert("Problemas al conectarse con el servidor");
           }); 

     }
     
     if (estadoCP =="08" && cuo==""){
            handler = dojo.xhrGet({
                    url: this.controller + "?action=obtenerNumCuo&estadoCP=" + estadoCP +"&periodo=" + periodoSeleccionado ,
                    handleAs: "json",
                    sync: true,
                    timeout: 10000
               });

           handler.addCallback(dojo.hitch(this, function(res){

        		  if (res.codeError == 0) {
                         if (res.data != null && res.data  != "" && res.data.substring(0,2)!="SV" ){
                            dijit.byId("generales.cuo").setValue(res.data);
                            dijit.byId("generales.cuo").attr('disabled', true);
                            this.cuoSV="";
                         }else{
                             //dijit.byId("generales.cuo").setValue("");
                             this.cuoSV=res.data.substring(2,res.data.length);
                             dijit.byId("generales.cuo").attr('disabled', false);
                         }

      			 } else {                                 
      				  alert(res.messageError);
      				  dojo.byId("global.cuoEncontrado").value = "0";
      				  return;
      			 } 

 
      		 }));
           handler.addErrback(function(res){
          			this.waitMessage.hide();
          			dojo.byId("global.cuoEncontrado").value = "0";
          			alert("Problemas al conectarse con el servidor");
           });                       
     }
	
	},
	*/
	showSeteo: function() {
			this.store = null;
			this.otherDocStore = null;
			
			this.resetValoresGlobales();
			
			this.content.onLoad = dojo.hitch(this, function(){
				this.initContent();
			});
			this.content.setHref(this.controller + "?action=mostrarInicial&mode=hidden");
	},
	
  showIngreso: function() {
		
  		if(!dijit.byId("inicio.form").validate()) return;
  				
  		this.cargarValoresGlobales();
  		
  		var periodoRVI = dijit.byId("inicio.periodoRegistroVentas" ).getValue();
  		    if (periodoRVI.length != 7){
                this.iconTooltipMessage("inicio.periodoRegistroVentas", "icon-ok-tooltip", "El periodo debe tener el formato MM/YYYY.");
                return;
          }
          if (periodoRVI.substring(0,2) != "01" && periodoRVI.substring(0,2) != "02" && periodoRVI.substring(0,2) != "03" &&
              periodoRVI.substring(0,2) != "04" && periodoRVI.substring(0,2) != "05" && periodoRVI.substring(0,2) != "06" &&
              periodoRVI.substring(0,2) != "07" && periodoRVI.substring(0,2) != "08" && periodoRVI.substring(0,2) != "09" &&
              periodoRVI.substring(0,2) != "10" && periodoRVI.substring(0,2) != "11" && periodoRVI.substring(0,2) != "12" ){
                this.iconTooltipMessage("inicio.periodoRegistroVentas", "icon-ok-tooltip", "El mes del periodo es inv�lido.");
                return;
          } 
      var periodoActual  = dojo.date.locale.format(new Date(), {datePattern: "yyyyMM", selector: "date"});
      if (dojo.byId("global.periodoComprobantes").value  > periodoActual){
          this.iconTooltipMessage("inicio.periodoRegistroVentas", "icon-ok-tooltip", "Periodo no puede ser mayor al actual.");
          return;
      }  		
      var handler = dojo.xhrGet({
        url: this.controller + "?action=validaExisteRVIGenerados&perIni=" + dojo.byId("global.periodoComprobantes").value + "&perFin=" + dojo.byId("global.periodoComprobantes").value,
        handleAs: "json",
       	preventCache: true,
        sync: true,
        timeout: 10000
      }); 

			handler.addCallback(dojo.hitch(this, function(res){
				this.waitMessage.hide();
				if(res.codeError == 0) {
  		
                    dojo.byId("action").value = "datosInicial";
                		this.wait("Procesando", "95px", 200);
                		
                		handler = dojo.io.iframe.send({
                			url: this.controller,
                			handleAs: "json",
                			sync: true,
                			timeout: 10000,
                			preventCache: true,
                			form: "global.form"
                		});
                		
                		handler.addCallback(dojo.hitch(this, function(res1){
                			this.waitMessage.hide();
                			if(res1.codeError == 0) {
                			   
                			    var tieneExportacion   = dojo.byId("global.opcExportacion").value;
                			    //var anotadoRegAnterior = dojo.byId("global.opcAnotadosRegistroAnterior").value ;
                			    var periodoSeleccionado = dojo.byId("global.periodoComprobantes").value;
                			    dojo.byId("global.ruc").value =  dojo.byId("inicio.ruc").value;  
                					this.content.setHref(this.controller + "?action=showIngreso&periodoSeleccionado=" + periodoSeleccionado + "&tieneExportacion=" + tieneExportacion +"&preventCache=" + this.preventCache());
                					this.content.onLoad = dojo.hitch(this, function(){
                					dojo.byId("global.capturarCpXRangos").value ="";
                					this.mostrarDatosGenerales();});
                			}
                			else {
                				nbControl.attr('disabled', false);
                				this.messageBox(res1.messageError);	
                			}
                		}));			
                			
                			handler.addErrback(function(res1){
                			nbControl.attr('disabled', false);
                			this.waitMessage.hide();
                			this.messageBox("Problemas al conectarse con el servidor");
                			});
    				} else {
    					alert(res.messageError);
    					return;
    				}
    			}));
    			handler.addErrback(dojo.hitch(this, function(res) {
        			this.waitMessage.hide();
    				alert("Ocurrio un error al momento de ejecutar la consulta.");
    				return;
    			}));                			
	},
	
	cargarDatosIngresados: function() {
	    	    
    //Cargar datos ingresados

    if (dojo.byId("global.esRetroceso").value == 0) {return;}
    if (dojo.byId("global.tipoCP").value !=""){
        dijit.byId("generales.tipoCP").setValue(dojo.byId("global.tipoCP").value + " - " + dojo.byId("global.tipoCPDescripcion").value );
    }
		dijit.byId("generales.estadoCP").setValue(dojo.byId("global.estadoCP").value);
		if (dojo.byId("global.tipoDocRecepCP").value != ""){
		    dijit.byId("generales.tipoDocRecepCP").setValue(dojo.byId("global.tipoDocRecepCP").value + " - " + dojo.byId("global.tipoDocRecepCPDescripcion").value);
    }
    if (dojo.byId("global.periodoAjuste").value != "") {dijit.byId("generales.periodoAjuste").setValue(dojo.byId("global.periodoAjuste").value.substring(4,6) + "/"+  dojo.byId("global.periodoAjuste").value.substring(0,4));}
    if (dojo.byId("global.cuo").value != "") {dijit.byId("generales.cuo").setValue(dojo.byId("global.cuo").value);}
    dojo.byId("generales.numeroDocRecepCP").value = dojo.byId("global.numeroDocRecepCP").value;
    dojo.byId("generales.numeroCorrelativo").value = dojo.byId("global.numeroCorrelativo").value;
    dojo.byId("generales.razonSocialRecepCP").value =dojo.byId("global.razonSocialRecepCP").value;
    
    dojo.byId("generales.numeroSerieCP").value = dojo.byId("global.numeroSerieCP").value;
    if (dojo.byId("global.numeroCP").value != "") {dojo.byId("generales.numeroCP").value =dojo.byId("global.numeroCP").value;}
		if (dojo.byId("global.capturarCpXRangos").value == "1") {
	    dijit.byId("inicio.capturarCpXRangos1").setChecked("checked");
              this.showHiddenDiv(document.getElementById("generales.nrosRangoCP.show"),true);
              this.showHiddenDiv(document.getElementById("generales.numeroCP.show"),false);
              dojo.byId("generales.numeroCP").value = "";
	  }else{
	    dijit.byId("inicio.capturarCpXRangos0").setChecked("checked");
	                  this.showHiddenDiv(document.getElementById("generales.numeroCP.show"),true);
              this.showHiddenDiv(document.getElementById("generales.nrosRangoCP.show"),false);
              dojo.byId("generales.numeroInicialCP").value = "";
              dojo.byId("generales.numeroFinalCP").value = "";  
    }      
    if (dojo.byId("global.numeroInicialCP").value != "") {dojo.byId("generales.numeroInicialCP").value =dojo.byId("global.numeroInicialCP").value;}
    if (dojo.byId("global.numeroFinalCP").value != "") {dojo.byId("generales.numeroFinalCP").value =dojo.byId("global.numeroFinalCP").value;}
    //dijit.byId("generales.numeroSerieMaqRegistra").setValue(dojo.byId("global.numeroSerieMaqRegistra").value);
    if (dojo.byId("global.fechaEmisionCP").value != "") {dijit.byId("generales.fechaEmisionCP").setValue(new Date(dojo.byId("global.fechaEmisionCP").value));}
    if (dojo.byId("global.fechaVencimientoPago").value != "") {dijit.byId("generales.fechaVencimientoPago").setValue(new Date(dojo.byId("global.fechaVencimientoPago").value));}
    
    var tieneExportacion  = dojo.byId("global.opcExportacion").value;
    if (dojo.byId("global.estadoCP").value=="02" ){
		   dijit.byId("generales.tipoDocRecepCP").setValue("- - SIN DOCUMENTO");
		   dijit.byId("generales.tipoDocRecepCP").attr('disabled', true) ;  
		   dijit.byId("generales.numeroDocRecepCP").setValue("");
		   dijit.byId("generales.numeroDocRecepCP").attr("disabled", true) ;  
		   dijit.byId("generales.razonSocialRecepCP").setValue("");
		   dijit.byId("generales.razonSocialRecepCP").attr("disabled", true) ; 		   
    }else{
         dijit.byId("generales.tipoDocRecepCP").attr("disabled", false) ;  
         dijit.byId("generales.numeroDocRecepCP").attr("disabled", false) ;  
         dijit.byId("generales.razonSocialRecepCP").attr("disabled", false) ; 
    }

    
    if (dojo.byId("global.fechaEmisionCPModificado").value != "" ) { dijit.byId("detalle.fechaEmisionCPModificado").setValue(new Date(dojo.byId("global.fechaEmisionCPModificado").value));}
    if (dojo.byId("global.tipoCPModificado").value != ""){dijit.byId("detalle.tipoCPModificado").setValue(dojo.byId("global.tipoCPModificado").value);}    
    dojo.byId("detalle.numeroSerieCPModificado").value = dojo.byId("global.numeroSerieCPModificado").value;
    if (dojo.byId("global.numeroCPModificado").value != "" && dojo.byId("global.numeroCPModificado").value != "NaN") {dojo.byId("detalle.numeroCPModificado").value = (dojo.byId("global.numeroCPModificado").value);}


    this.validaNumDoc();
    dojo.byId("global.esRetroceso").value = "0";
    
	},

	registrarDatos: function() {
	
		//if (!confirm("Sr. Contribuyente, ud. no ha ingresado informaci�n por los conceptos que no se muestran en pantalla, por lo que se consignara el valor por default. Confirme el registro del CP Fisico capturado.")){
		if (!confirm("Sr. Contribuyente, se guardar�n los datos ingresados. Confirme la informacion del CP Fisico capturado.")){
			return;
		}
		var nbControl = dijit.byId("preliminar.botonContinuar");
		nbControl.setAttribute('disabled', true);
     	this.wait("Grabando...", "95px", 200);
  		dojo.byId("action").value = "grabarDatos";
  		var handler = dojo.io.iframe.send({
  			url: this.controller,
  			handleAs: "json",
  			sync: true,
  			timeout: 10000,
  			preventCache: true,
  			form: "global.form"
  		});
  		
  		handler.addCallback(dojo.hitch(this, function(res){
    		  this.waitMessage.hide();
    		  nbControl.attr('disabled', false);
    			if(res.codeError == 0) {
    			    alert("Informacion del Comprobante guardado satisfactoriamente");
    			    this.resetDatos();
    					//this.content.setHref(this.controller + "?action=backSeteoInicial&preventCache=" + this.preventCache());
        			//this.content.onLoad = dojo.hitch(this, function(){
        			//   this.cargaDatosSeteo();
        
              //});  			
              this.content.setHref(this.controller + "?action=backDatosGenerales&preventCache=" + this.preventCache());
        			this.content.onLoad = dojo.hitch(this, function(){
        			   this.mostrarDatosGenerales();
        
              });  			
    			}
    			else {
    				nbControl.attr('disabled', false);
    				this.messageBox(res.messageError);	
    			}
  		}));			
  			
  		handler.addErrback(function(res){
  			nbControl.attr('disabled', false);
  			this.waitMessage.hide();
  			this.messageBox("Problemas al conectarse con el servidor");
  		});

	},
	
	cargarDatosIngresadosDetalle: function() {

           	    
    //Cargar datos ingresados
    if (dojo.byId("global.esRetrocesoDetalle").value == 0 && dojo.byId("global.cuoEncontrado").value == 0) {return;}
    if (dojo.byId("global.tipoMoneda").value !="" && dojo.byId("global.tipoMoneda").value !="-" ){
        //dijit.byId("detalle.tipoMoneda").setValue(dojo.byId("global.tipoMoneda").value + " - " + dojo.byId("global.tipoMonedaDescripcion").value );
        dijit.byId("detalle.tipoMoneda").setValue(dojo.byId("global.tipoMoneda").value );
    }

    //if (dojo.byId("global.fechaTC").value != "" ) { dijit.byId("detalle.fechaTC").setValue(new Date(dojo.byId("global.fechaTC").value));}
    if (dojo.byId("global.tc").value != "" && dojo.byId("global.tc").value != "NaN") {dijit.byId("detalle.tc").setValue(dojo.byId("global.tc").value );}
    if (dojo.byId("global.valorFacturadoExportacion").value != "" && dojo.byId("global.valorFacturadoExportacion").value != "NaN") {dijit.byId("detalle.valorFacturadoExportacion").setValue(dojo.byId("global.valorFacturadoExportacion").value);}
    //if (dojo.byId("global.valorEmbarcadoExportacion").value != "" && dojo.byId("global.valorEmbarcadoExportacion").value != "NaN") {dijit.byId("detalle.valorEmbarcadoExportacion").setValue(dojo.byId("global.valorEmbarcadoExportacion").value);}
 		if (dojo.byId("global.baseImpOperacGrav").value != "" && dojo.byId("global.baseImpOperacGrav").value != "NaN") {dijit.byId("detalle.baseImpOperacGrav").setValue(dojo.byId("global.baseImpOperacGrav").value);}
 		if (dojo.byId("global.descBaseImponible").value != "" && dojo.byId("global.descBaseImponible").value != "NaN") {dijit.byId("detalle.descBaseImponible").setValue(dojo.byId("global.descBaseImponible").value);}
		if (dojo.byId("global.importeOperacionExonerada").value != "" && dojo.byId("global.importeOperacionExonerada").value != "NaN") {dijit.byId("detalle.importeOperacionExonerada").setValue(dojo.byId("global.importeOperacionExonerada").value);}
    if (dojo.byId("global.importeOperacionInafecta").value != "" && dojo.byId("global.importeOperacionInafecta").value != "NaN") {dijit.byId("detalle.importeOperacionInafecta").setValue(dojo.byId("global.importeOperacionInafecta").value);}
    if (dojo.byId("global.isc" && dojo.byId("global.isc").value != "NaN")) {dijit.byId("detalle.isc").setValue(dojo.byId("global.isc").value );}
    if (dojo.byId("global.tasaIgvoipm").value !=""){
        dijit.byId("detalle.tasasIgvIpm").setValue(dojo.byId("global.tasaIgvoipm").value );
    }    
    if (dojo.byId("global.igvoipm").value != "" && dojo.byId("global.igvoipm").value != "NaN" ) {
             dijit.byId("detalle.igvoipm").setValue(dojo.byId("global.igvoipm").value );
    }else{
          var porcentaje = dojo.byId("detalle.tasasIgvIpm").value;
          var base = dojo.byId("detalle.baseImpOperacGrav").value;
          var total = 0;
           if (porcentaje != "" && base != ""){
              porcentaje = dijit.byId("detalle.tasasIgvIpm").getValue();
              base = dijit.byId("detalle.baseImpOperacGrav").getValue();
              var mtoISC = dojo.byId("detalle.isc").value;   
              if (mtoISC!=""){ 
                  mtoISC = dijit.byId("detalle.isc").getValue();
              }else{
                  mtoISC = 0;
              }
              
              total = porcentaje * (base + mtoISC);
              if (total > 0 ) { total = total / 100;}
              dijit.byId("detalle.igvoipm").setValue(total);
              dijit.byId("detalle.igvoipm").constraints = {min:0,places:2};              
           }  
    }
    if (dojo.byId("global.descuentoIgvoipm").value != "" && dojo.byId("global.descuentoIgvoipm").value != "NaN") {dijit.byId("detalle.descuentoIgvoipm").setValue(dojo.byId("global.descuentoIgvoipm").value);}
    if (dojo.byId("global.baseImponibleIvap").value != "" && dojo.byId("global.baseImponibleIvap").value != "NaN" ) {dijit.byId("detalle.baseImponibleIvap").setValue(dojo.byId("global.baseImponibleIvap").value);}
 
    if (dojo.byId("global.ivap").value != "" && dojo.byId("global.ivap").value != "NaN") {dijit.byId("detalle.ivap").setValue(dojo.byId("global.ivap").value );}
    if (dojo.byId("global.tributosCargosNoBaseImp").value != "" && dojo.byId("global.tributosCargosNoBaseImp").value != "NaN") {dijit.byId("detalle.tributosCargosNoBaseImp").setValue(dojo.byId("global.tributosCargosNoBaseImp").value);}
    if (dojo.byId("global.importeTotalCP").value != "" && dojo.byId("global.importeTotalCP").value != "NaN") {
        dijit.byId("detalle.importeTotalCP").setValue(dojo.byId("global.importeTotalCP").value);
      }else{
          var valorFactExporta = dojo.byId("detalle.valorFacturadoExportacion").value;
          //var valorEmbExporta = dojo.byId("detalle.valorEmbarcadoExportacion").value;
          var baseImpOperacGrav = dojo.byId("detalle.baseImpOperacGrav").value;
          var importOperacExonerada= dojo.byId("detalle.importeOperacionExonerada").value;
          var importOperacInafecta = dojo.byId("detalle.importeOperacionInafecta").value;
          var mtoISC = dojo.byId("detalle.isc").value;                              
          var mtoIGV = dojo.byId("detalle.igvoipm").value;
          var baseImpIvap = dojo.byId("detalle.baseImponibleIvap").value;                              
          var mtoIvap = dojo.byId("detalle.ivap").value;
          var otroTributosNoFormanBaseImp = dojo.byId("detalle.tributosCargosNoBaseImp").value;                              
          if (valorFactExporta!=""){ 
              valorFactExporta = dijit.byId("detalle.valorFacturadoExportacion").getValue();}
          else {valorFactExporta = 0;}  
          //if (valorEmbExporta!=""){ 
          //    valorEmbExporta = dijit.byId("detalle.valorEmbarcadoExportacion").getValue();}
          //else {valorEmbExporta = 0;}            
          if (baseImpOperacGrav!=""){ 
              baseImpOperacGrav = dijit.byId("detalle.baseImpOperacGrav").getValue();}
          else {baseImpOperacGrav = 0;}  
          if (importOperacExonerada!=""){ 
              importOperacExonerada = dijit.byId("detalle.importeOperacionExonerada").getValue();}
          else {importOperacExonerada = 0;}  
          if (importOperacInafecta!=""){ 
              importOperacInafecta = dijit.byId("detalle.importeOperacionInafecta").getValue();}
          else {importOperacInafecta = 0;}  
          if (mtoISC!=""){ 
              mtoISC = dijit.byId("detalle.isc").getValue();}
          else {mtoISC = 0;} 
          if (mtoIGV!=""){ 
              mtoIGV = dijit.byId("detalle.igvoipm").getValue();}
          else {mtoIGV = 0;}  
          if (baseImpIvap!=""){ 
              baseImpIvap = dijit.byId("detalle.baseImponibleIvap").getValue();}
          else {baseImpIvap = 0;}  
          if (mtoIvap!=""){ 
              mtoIvap = dijit.byId("detalle.ivap").getValue();}
          else {mtoIvap = 0;}  
          if (otroTributosNoFormanBaseImp!=""){ 
              otroTributosNoFormanBaseImp = dijit.byId("detalle.tributosCargosNoBaseImp").getValue();}
          else {otroTributosNoFormanBaseImp = 0;}  
                                                    
          var total = 0;
          total =  valorFactExporta + baseImpOperacGrav+ importOperacExonerada+ importOperacInafecta+ mtoISC+    mtoIGV + baseImpIvap +   mtoIvap+otroTributosNoFormanBaseImp;
          dijit.byId("detalle.importeTotalCP").setValue(total);
          dijit.byId("detalle.importeTotalCP").constraints = {min:0,places:2};              
 
      }
      
    if (dojo.byId("global.contratoColaboracion").value != ""  ) {dijit.byId("detalle.contratoColaboracion").setValue(dojo.byId("global.contratoColaboracion").value);}
    if (dojo.byId("global.errorTipo1").value != ""  ) {
        if (dojo.byId("global.errorTipo1").value == "1") {
            dijit.byId("detalle.tcDiferenteSunat1").setChecked("checked");
          }else{
            dijit.byId("detalle.tcDiferenteSunat0").setChecked("checked");
          }
      
      }   
 
     if (dojo.byId("global.indicadorMedioPago").value != ""  ) {
        if (dojo.byId("global.indicadorMedioPago").value == "1") {
            dijit.byId("detalle.medioDePago1").setChecked("checked");
          }else{
            dijit.byId("detalle.medioDePago0").setChecked("checked");
          }
      
      }       
    if (dojo.byId("global.grabadoPremio").value != "" && dojo.byId("global.grabadoPremio").value != "NaN") {dijit.byId("detalle.grabadoPremio").setValue(dojo.byId("global.grabadoPremio").value);}
    if (dojo.byId("global.grabadoDonacion").value != "" && dojo.byId("global.grabadoDonacion").value != "NaN") {dijit.byId("detalle.grabadoDonacion").setValue(dojo.byId("global.grabadoDonacion").value);}
    if (dojo.byId("global.grabadoEntregaTrabajadores").value != "" && dojo.byId("global.grabadoEntregaTrabajadores").value != "NaN") {dijit.byId("detalle.grabadoEntregaTrabajadores").setValue(dojo.byId("global.grabadoEntregaTrabajadores").value);}
    if (dojo.byId("global.grabadoPublicidad").value   != "" && dojo.byId("global.grabadoPublicidad").value != "NaN") {dijit.byId("detalle.grabadoPublicidad").setValue(dojo.byId("global.grabadoPublicidad").value);}
    if (dojo.byId("global.grabadoBonificacion").value != "" && dojo.byId("global.grabadoBonificacion").value != "NaN") {dijit.byId("detalle.grabadoBonificacion").setValue(dojo.byId("global.grabadoBonificacion").value);}
    if (dojo.byId("global.grabadoRetiroOtros").value  != "" && dojo.byId("global.grabadoRetiroOtros").value  != "NaN") {dijit.byId("detalle.grabadoRetiroOtros").setValue(dojo.byId("global.grabadoRetiroOtros").value);}
    if (dojo.byId("global.valorFacturaExportaNoOnerosa").value != "" && dojo.byId("global.valorFacturaExportaNoOnerosa").value != "NaN") {dijit.byId("detalle.valorFacturaExportaNoOnerosa").setValue(dojo.byId("global.valorFacturaExportaNoOnerosa").value);}
    if (dojo.byId("global.importeOperacionNoOnerosaExo").value != "" && dojo.byId("global.importeOperacionNoOnerosaExo").value != "NaN") {dijit.byId("detalle.importeOperacionNoOnerosaExo").setValue(dojo.byId("global.importeOperacionNoOnerosaExo").value);}
    if (dojo.byId("global.inafectoPremio").value != "" && dojo.byId("global.inafectoPremio").value != "NaN") {dijit.byId("detalle.inafectoPremio").setValue(dojo.byId("global.inafectoPremio").value);}
    if (dojo.byId("global.inafectoPublicidad").value != "" && dojo.byId("global.inafectoPublicidad").value != "NaN") {dijit.byId("detalle.inafectoPublicidad").setValue(dojo.byId("global.inafectoPublicidad").value);}
    if (dojo.byId("global.inafectoBonificacion").value != "" && dojo.byId("global.inafectoBonificacion").value != "NaN") {dijit.byId("detalle.inafectoBonificacion").setValue(dojo.byId("global.inafectoBonificacion").value);}
    if (dojo.byId("global.inafectoRetiroConvenioColectivo").value != "" && dojo.byId("global.inafectoRetiroConvenioColectivo").value != "NaN") {dijit.byId("detalle.inafectoRetiroConvenioColectivo").setValue(dojo.byId("global.inafectoRetiroConvenioColectivo").value);}
    if (dojo.byId("global.inafectoMuestrasMedicas").value != "" && dojo.byId("global.inafectoMuestrasMedicas").value != "NaN") {dijit.byId("detalle.inafectoMuestrasMedicas").setValue(dojo.byId("global.inafectoMuestrasMedicas").value);}
    if (dojo.byId("global.inafectoRetiroOtros").value != "" && dojo.byId("global.inafectoRetiroOtros").value != "NaN") {dijit.byId("detalle.inafectoRetiroOtros").setValue(dojo.byId("global.inafectoRetiroOtros").value);}

    dojo.byId("global.esRetrocesoDetalle").value = "0";    
    
	},
	
	buscarTC: function(){
	

	 var fecha= "";
	 var tipoCP = dojo.byId("global.tipoCP").value;
	 if (tipoCP =="14" ){
	     fecha = dojo.byId("global.fechaVencimPago").value;
   } else{
       fecha = dojo.byId("global.fechaEmisionCP").value;
   } 	 
	 
	 fecha =  fecha.substring(3,5)+ "/" + fecha.substring(0,2) +  "/"  + fecha.substring(6,10) ;
	 
	 var tipoMoneda = dijit.byId("detalle.tipoMoneda").getValue(); 
	 if (tipoMoneda != "USD" && tipoMoneda != "CAD" && tipoMoneda != "GBP" 
    && tipoMoneda != "JPY" && tipoMoneda != "SEK" && tipoMoneda != "CHF" && tipoMoneda != "EUR" && tipoMoneda != "XEU"){
    return;
    }
	 
	 var handler = null;

                                 handler = dojo.xhrGet({
                                      url: this.controller + "?action=buscarTC&fecha=" + fecha + "&tipoMoneda=" + tipoMoneda,
                                      handleAs: "json",
                                      sync: true,
                                      timeout: 10000
                                 });       
                            
                                 handler.addCallback(dojo.hitch(this, function(res){
                                 try{
                              		   if (res.codeError == 0 ) {
                              		       dojo.byId("global.tcSUNAT").value = res.data;
                                         dijit.byId("detalle.tc").setValue(res.data);
                                         
                              			 }else{
                                         dojo.byId("global.tcSUNAT").value = "";
                                        dijit.byId("detalle.tc").setValue("");
                                     }
                              		 //
                              		}
catch(err)
  {
  txt="There was an error on this page.\n\n";
  txt+="Error description: " + err.message + "\n\n";
  txt+="Click OK to continue.\n\n";
  alert(txt);
  }  
                              		 //                                     
                              		 }));

                                 handler.addErrback(function(res){
                                  			alert("Problemas al conectarse con el servidor");
                                  			return;
                                 }); 

                          
  },
  
	showDetalle: function() {
	
	   dijit.hideTooltip(dojo.byId("generales.fechaEmisionCP"));
   dijit.hideTooltip(dojo.byId("generales.fechaVencimientoPago"));
   dijit.hideTooltip(dojo.byId("generales.numeroSerieCP"));
   dijit.hideTooltip(dojo.byId("generales.numeroDocRecepCP"));
   dijit.hideTooltip(dojo.byId("generales.numeroInicialCP"));
   dijit.hideTooltip(dojo.byId("generales.numeroFinalCP"));   
   dijit.hideTooltip(dojo.byId("generales.numeroCP")); 
    dijit.hideTooltip(dojo.byId("generales.tipoCP")); 

   dijit.hideTooltip(dojo.byId("generales.numeroCorrelativo")); 
   dijit.hideTooltip(dojo.byId("generales.numeroSerieCP"))
    dijit.hideTooltip(dojo.byId("generales.cuo")); 
    dijit.hideTooltip(dojo.byId("generales.estadoCP")); 
    dijit.hideTooltip(dojo.byId("generales.periodoAjuste"));
    //dijit.hideTooltip(dojo.byId("generales.numeroSerieMaqRegistra"));
    dijit.hideTooltip(dojo.byId("generales.razonSocialRecepCP"));
          dijit.hideTooltip(dojo.byId("detalle.fechaEmisionCPModificado"));
        dijit.hideTooltip(dojo.byId("detalle.tipoCPModificado")); 
        dijit.hideTooltip(dojo.byId("detalle.numeroCPModificado")); 
        dijit.hideTooltip(dojo.byId("detalle.numeroSerieCPModificado")); 
        
	  if(!dijit.byId("generales.form").validate()) return;
	  
	  ///
	  //if (  dijit.byId("generales.tipoDocRecepCP").getValue().substring(0,1) =="6" && (dijit.byId("generales.numeroDocRecepCP").getValue() == dojo.byId("global.ruc").value) ){
    //    this.iconTooltipMessage("generales.numeroDocRecepCP", "icon-ok-tooltip", "El documento del cliente no puede ser el mismo que el del emisor.");
    //    return;	
    //}
	  /////
	  
	  dojo.byId("global.capturarCpXRangos").value = this.getValorOpcionCapturarCPPorRangos();
	  
	  var tipoCP   = dijit.byId("generales.tipoCP").getValue().substring(0,2);
	  var tipoCPModif = dijit.byId("detalle.tipoCPModificado").getValue().substring(0,2);
	  if (tipoCP ==""){
        this.iconTooltipMessage("generales.tipoCP", "icon-ok-tooltip", "Debe seleccionar el tipo de comprobante.");
        return;	  
    } 
	  
	  var estadoCP = dijit.byId("generales.estadoCP").getValue();
	  if (estadoCP =="" ){
        this.iconTooltipMessage("generales.estadoCP", "icon-ok-tooltip", "Debe seleccionar el estado del comprobante.");
        return;	  
    } 
    	  
	  var anotadosRegAnterior =  0; //dojo.byId("global.opcAnotadosRegistroAnterior").value;
	  if ( estadoCP =="09"){
	       anotadosRegAnterior=1;
    }
    if (anotadosRegAnterior==1 || estadoCP =="08" || estadoCP =="09"){

          var periodoAjuste = dojo.byId("generales.periodoAjuste").value;  
          var periodoAjuste2 = dojo.byId("generales.periodoAjuste").value.substring(3,7) + dojo.byId("generales.periodoAjuste").value.substring(0,2) ;
          if (periodoAjuste == ""){
                this.iconTooltipMessage("generales.periodoAjuste", "icon-ok-tooltip", "Debe registrar el periodo de ajuste.");
                return;
          }
          if (periodoAjuste.length != 7){
                this.iconTooltipMessage("generales.periodoAjuste", "icon-ok-tooltip", "El periodo de ajuste debe tener el formato MM/YYYY.");
                return;
          }
          if (periodoAjuste.substring(0,2) != "01" && periodoAjuste.substring(0,2) != "02" && periodoAjuste.substring(0,2) != "03" &&
              periodoAjuste.substring(0,2) != "04" && periodoAjuste.substring(0,2) != "05" && periodoAjuste.substring(0,2) != "06" &&
              periodoAjuste.substring(0,2) != "07" && periodoAjuste.substring(0,2) != "08" && periodoAjuste.substring(0,2) != "09" &&
              periodoAjuste.substring(0,2) != "10" && periodoAjuste.substring(0,2) != "11" && periodoAjuste.substring(0,2) != "12" ){
                this.iconTooltipMessage("generales.periodoAjuste", "icon-ok-tooltip", "El mes del periodo es inv�lido.");
                return;
          }     
          var periodo1rapantalla = dojo.byId("global.periodoComprobantes").value;
          if ( periodo1rapantalla > periodoAjuste2){
          }else{
                this.iconTooltipMessage("generales.periodoAjuste", "icon-ok-tooltip", "El periodo de ajuste debe ser menor al periodo del registro de ventas.");
                return;
          }
          if ( (periodoAjuste2 *1) <= 200001){
                this.iconTooltipMessage("generales.periodoAjuste", "icon-ok-tooltip", "El periodo de ajuste debe ser mayor al periodo 200001.");
                return;
          }          
          var cuo = dojo.byId("generales.cuo").value;  
          if (cuo == ""){
                this.iconTooltipMessage("generales.cuo", "icon-ok-tooltip", "Debe registrar el cuo.");
                return;
          } else{
          
              if (estadoCP =="08" ) {
                  if (this.cuoSV != ""){
                      if ((cuo *1) <= (this.cuoSV*1) ){
                            this.iconTooltipMessage("generales.cuo", "icon-ok-tooltip", "CUO debe ser mayor a " + this.cuoSV);
                            return;
                      }
                  }
              }
          }
    }	  else{
          //var cuo = dojo.byId("generales.cuo").value;  
          //if (cuo == ""){
          //      this.iconTooltipMessage("generales.cuo", "icon-ok-tooltip", "Debe registrar el cuo.");
          //      return;
          //}
    }
    
    if (estadoCP =="00" ) {
        if ( tipoCP !="23" &&  tipoCP !="25" &&  tipoCP !="27" &&  tipoCP !="28"  &&  tipoCP !="29" &&  tipoCP !="30"  && 
             tipoCP !="32" &&  tipoCP !="56" &&  tipoCP !="34" &&  tipoCP !="35"  &&  tipoCP !="42" &&  tipoCP !="44"  && 
             tipoCP !="48" &&  tipoCP !="49" &&  tipoCP !="56" &&  tipoCP !="00"  ){
             this.iconTooltipMessage("generales.tipoCP", "icon-ok-tooltip", "No puede seleccionar este tipo de comprobante para el estado 0.");
             return;
        }
    }

    
    if (estadoCP =="02" ) {
        if ( tipoCP =="06" || tipoCP =="49"){
             this.iconTooltipMessage("generales.tipoCP", "icon-ok-tooltip", "No puede seleccionar este tipo de comprobante para el estado 2.");
             return;
        }
    }
    	  
	  var tieneExportacion = dojo.byId("global.opcExportacion").value;
    var tipoDoc = dijit.byId("generales.tipoDocRecepCP").getValue().substring(0,1);
    if (  tipoCP =="01" &&  tipoDoc !="6"){
        if (tieneExportacion!=1){
            if (estadoCP !="02"){
                this.iconTooltipMessage("generales.tipoDocRecepCP", "icon-ok-tooltip", "El tipo de documento solo puede ser RUC.");
                return;
            }
        }
    }
    //Valida ingreso del tipo de documento

    if (  (tipoCP =="00" ||  tipoCP =="03" ||  tipoCP =="05" ||  tipoCP =="06"||  tipoCP =="11" ||
          tipoCP =="12" ||  tipoCP =="13" ||  tipoCP =="14" ||  tipoCP =="15"||  tipoCP =="16"||  tipoCP =="18" || 
          tipoCP =="19" ||  tipoCP =="23" ||  tipoCP =="26" ||  tipoCP =="28"||  tipoCP =="30"||  tipoCP =="34" ||
          tipoCP =="35" ||  tipoCP =="36" ||  tipoCP =="37" ||  tipoCP =="49" || tipoCP =="55"||  tipoCP =="56" ) ||  
          tieneExportacion==1 || ( ( tipoCP =="07" ||  tipoCP =="08" || tipoCP =="87"||  tipoCP =="88") && 
                                    (tipoCPModif =="03" || tipoCPModif =="12" || tipoCPModif =="13" || tipoCPModif =="14" || tipoCPModif =="36") )) {
         	
          if (tipoDoc!="-" && estadoCP !="02") { 
              var numeroDoc = dijit.byId("generales.numeroDocRecepCP").getValue();
              if (numeroDoc=="" ) { 
                  this.iconTooltipMessage("generales.numeroDocRecepCP", "icon-ok-tooltip", "Debe registrar el n�mero de documento.");
                  return;
              }  
              var lenDoc = numeroDoc.length;  
              if  (tipoDoc =="1") { 
                     if (lenDoc != 8){
                        this.iconTooltipMessage("generales.numeroDocRecepCP", "icon-ok-tooltip", "N�mero de documento inv�lido.");
                        return;
                     }
                     if (dojo.byId("generales.razonSocialRecepCP").value==""){
                        this.iconTooltipMessage("generales.razonSocialRecepCP", "icon-ok-tooltip", "Debe registrar nombre.");
                        return;                  
                     }  
              }    
              if  (tipoDoc =="6") {            
                     if (lenDoc != 11){
                        this.iconTooltipMessage("generales.numeroDocRecepCP", "icon-ok-tooltip", "N�mero de documento inv�lido.");
                        return;
                     }
                     if (dojo.byId("generales.razonSocialRecepCP").value==""){
                        this.iconTooltipMessage("generales.numeroDocRecepCP", "icon-ok-tooltip", "N�mero de RUC no existe.");
                        return;                  
                     }
              }      
              if  (tipoDoc =="0" || tipoDoc =="4" || tipoDoc =="7" || tipoDoc =="A" ) {            
                     if (dijit.byId("generales.razonSocialRecepCP").getValue()==""){
                        this.iconTooltipMessage("generales.razonSocialRecepCP", "icon-ok-tooltip", "Nombre o raz�n social inconsistente");
                        return;                  
                     }
              }  
              //Se comenta a solictud del nuevo enfoque de juridica
              /*
              if  (tipoCP =="03"  && tipoDoc =="6") {   
                  this.iconTooltipMessage("generales.tipoDocRecepCP", "icon-ok-tooltip", "Para una BOLETA DE VENTA el tipo de documento del cliente no puede ser RUC.");
                  return;               
              }
              */
         } 
      
    }else{
          if (tieneExportacion==1 || estadoCP=="02" ){
          }else{
            if (tipoDoc=="-" ) { 
                this.iconTooltipMessage("generales.tipoDocRecepCP", "icon-ok-tooltip", "Debe seleccionar el tipo de documento.");
                return;
            } 
            var numeroDoc = dojo.byId("generales.numeroDocRecepCP").value;
            if (numeroDoc=="" ) { 
                this.iconTooltipMessage("generales.numeroDocRecepCP", "icon-ok-tooltip", "Debe registrar el n�mero de documento.");
                return;
            }  
            var lenDoc = numeroDoc.length;  
            if  (tipoDoc =="1") { 
                   if (lenDoc != 8){
                      this.iconTooltipMessage("generales.numeroDocRecepCP", "icon-ok-tooltip", "N�mero de documento inv�lido.");
                      return;
                   }
                   if (dijit.byId("generales.razonSocialRecepCP").getValue()==""){
                      this.iconTooltipMessage("generales.razonSocialRecepCP", "icon-ok-tooltip", "Debe registrar nombre.");
                      return;                  
                   }  
             }    
            if  (tipoDoc =="6") {            
                   if (lenDoc != 11){
                      this.iconTooltipMessage("generales.numeroDocRecepCP", "icon-ok-tooltip", "N�mero de documento inv�lido.");
                      return;
                   }
                   if (dojo.byId("generales.razonSocialRecepCP").value==""){
                      this.iconTooltipMessage("generales.numeroDocRecepCP", "icon-ok-tooltip", "N�mero de RUC no existe.");
                      return;                  
                   }
            }      
            if  (tipoDoc =="0" || tipoDoc =="4" || tipoDoc =="7" || tipoDoc =="A" ) {            
                   if (dojo.byId("generales.razonSocialRecepCP").value==""){
                      this.iconTooltipMessage("generales.razonSocialRecepCP", "icon-ok-tooltip", "Nombre o raz�n social inconsistente");
                      return;                  
                   }
            }      
         }          
    }	

       var tipoCPModif = dijit.byId("detalle.tipoCPModificado").getValue().substring(0,2);
        var tipoDoc = dojo.trim(dijit.byId("generales.tipoDocRecepCP").getValue().substring(0,2));
        if ( (  tipoCP =="00" || tipoCP =="03" ||  tipoCP =="05" ||  tipoCP =="06"||  tipoCP =="07"||  tipoCP =="08"||  tipoCP =="11" ||
              tipoCP =="12" ||  tipoCP =="13" ||  tipoCP =="14"||  tipoCP =="15"||  tipoCP =="16"||  tipoCP =="18" || 
              tipoCP =="19" ||  tipoCP =="23" ||  tipoCP =="26"||  tipoCP =="28"||  tipoCP =="30"||  tipoCP =="34" ||
              tipoCP =="35" ||  tipoCP =="36" ||  tipoCP =="37"||   tipoCP =="49"||  tipoCP =="55"||  tipoCP =="56"||  tipoCP =="87" ||
              tipoCP =="88" ) ||  ( ( tipoCP =="97" ||  tipoCP =="98") 
              && (tipoCPModif =="03" || tipoCPModif =="12" || tipoCPModif =="13" || tipoCPModif =="14" || tipoCPModif =="36") ) ){
             	/////////////////////
              if (tieneExportacion==1 || estadoCP=="02" ){
              }else{
                  if (tipoDoc!="-" ) { 
                      var numeroDoc = dojo.byId("generales.numeroDocRecepCP").value;
                      if (numeroDoc=="" ) { 
                          alert("Debe registrar el numero de documento del cliente.")
                          return;
                      }  
                      var lenDoc = numeroDoc.length;  
                      if  (tipoDoc =="1") { 
                             if (lenDoc != 8){
                                alert("Numero de documento del cliente inv�lido")
                                return;
                             }
                             if (dijit.byId("generales.razonSocialRecepCP").getValue()==""){
                                alert("Debe registrar nombre del cliente.")
                                return;                  
                             }  
                       }    
                      if  (tipoDoc =="6") {            
                             if (lenDoc != 11){
                                alert("Numero de documento del cliente inv�lido")
                                return;
                             }
                             if (dijit.byId("generales.razonSocialRecepCP").getValue()==""){
                                alert("Numero de RUC del cliente no existe.")
                                return;                  
                             }
                      }      
                      if  (tipoDoc =="0" || tipoDoc =="4" || tipoDoc =="7" || tipoDoc =="A" ) {            
                             if (dijit.byId("generales.razonSocialRecepCP").getValue()==""){
                                alert("Nombre o Razon Social del cliente es inconsistente.")
                                return;                  
                             }
                      }  
                  } 
             }              	
             	///////////////////7777

      
        } else{
           if (tieneExportacion==1 || estadoCP=="02" ){
          }else{
          
                if (tipoDoc=="-" ) { 
                    alert("Debe seleccionar el tipo de documento del cliente.");
                    return;
                } 
                 var numeroDoc = dojo.byId("generales.numeroDocRecepCP").value;
                  if (numeroDoc=="" ) { 
                      alert("Debe registrar el numero de documento del cliente.")
                      return;
                  }  
                  var lenDoc = numeroDoc.length;  
                  if  (tipoDoc =="1") { 
                         if (lenDoc != 8){
                            alert("Numero de documento del cliente inv�lido")
                            return;
                         }
                         if (dijit.byId("generales.razonSocialRecepCP").getValue()==""){
                            alert("Debe registrar nombre del cliente.")
                            return;                  
                         }  
                   }    
                  if  (tipoDoc =="6") {            
                         if (lenDoc != 11){
                            alert("Numero de documento del cliente inv�lido")
                            return;
                         }
                         if (dijit.byId("generales.razonSocialRecepCP").getValue()==""){
                            alert("Numero de RUC del cliente no existe.")
                            return;                  
                         }
                  }      
                  if  (tipoDoc =="0" || tipoDoc =="4" || tipoDoc =="7" || tipoDoc =="A" ) {            
                         if (dijit.byId("generales.razonSocialRecepCP").getValue()==""){
                            alert("Nombre o Razon Social del cliente es inconsistente.")
                            return;                  
                         }
                  }  
             }        
        }   

///

     if (  tipoCP =="87" ||  tipoCP =="88" ){
          if (tipoCPModif =="01" || tipoCPModif =="03" || tipoCPModif =="04" || tipoCPModif =="12"){
                alert("Para Nota de cr�dito especial o Nota de d�bito especial no puede seleccionar este tipo de comprobante a modificar.")
                return;     
          } 
     }
    //Validamos las fechas
    var fechaEmision = dojo.byId("generales.fechaEmisionCP").value.substring(6,10) +  dojo.byId("generales.fechaEmisionCP").value.substring(3,5)+  dojo.byId("generales.fechaEmisionCP").value.substring(0,2) ;
    var ultimoDiaPeriodo = dojo.byId("generales.ultimoDiaPeriodo").value;
    if (estadoCP !="02"){
        if(fechaEmision == ""){
           this.iconTooltipMessage("generales.fechaEmisionCP", "icon-ok-tooltip", "Debe registrar la fecha de emisi�n.");
           return;
        }
        if(fechaEmision > ultimoDiaPeriodo){
               this.iconTooltipMessage("generales.fechaEmisionCP", "icon-ok-tooltip", "Fecha de emisi�n inconsistente.");
               return;
        }  
        if (estadoCP !="08" && estadoCP !="09"  ){
            if(fechaEmision > ultimoDiaPeriodo){
               this.iconTooltipMessage("generales.fechaEmisionCP", "icon-ok-tooltip", "Fecha de emisi�n debe estar dentro del periodo informado.");
               return;
            }
            var periodoactual = dojo.byId("global.periodoComprobantes").value + "01"; 
            if(fechaEmision < periodoactual){
               this.iconTooltipMessage("generales.fechaEmisionCP", "icon-ok-tooltip", "Fecha de emisi�n debe estar dentro del periodo informado.");
               return;
            }        
        }else{
            var fecAjuste = new Date(dijit.byId("generales.periodoAjuste").getValue().substring(0,2) + "/01/"+dijit.byId("generales.periodoAjuste").getValue().substring(3,7));
            var mesSiguiente = fecAjuste.setMonth(fecAjuste.getMonth()+1);
            mesSiguiente = fecAjuste.setDate(1);
            mesSiguiente = fecAjuste.setDate(fecAjuste.getDate() -1);
            var fecSiguiente = new Date(mesSiguiente);
            ultimoDiaPeriodo = dojo.date.locale.format(fecSiguiente, {datePattern: "yyyyMMdd", selector: "date"});
            console.log (fechaEmision);
            console.log(ultimoDiaPeriodo);
            if(fechaEmision > ultimoDiaPeriodo){
               this.iconTooltipMessage("generales.fechaEmisionCP", "icon-ok-tooltip", "Fecha de emisi�n debe estar dentro del periodo al que corresponde el ajuste.");
               return;
            }   
            var periodoajust = dijit.byId("generales.periodoAjuste").getValue().substring(3,7) + dijit.byId("generales.periodoAjuste").getValue().substring(0,2) + "01";
            if(fechaEmision < periodoajust){
               this.iconTooltipMessage("generales.fechaEmisionCP", "icon-ok-tooltip", "Fecha de emisi�n debe estar dentro del periodo al que corresponde el ajuste.");
               return;
            }             
        }
        if(fechaEmision < "19880101"){
                 this.iconTooltipMessage("generales.fechaEmisionCP", "icon-ok-tooltip", "Fecha de emisi�n no puede ser menor a 01/1988.");
                 return;
        } 
    }
    //var tieneFecVenc = dojo.byId("global.fechaVencimPago").value;
    var tieneFecVenc = 0
		if (tipoCP =="14"){
		 tieneFecVenc = 1;
    }
    ultimoDiaPeriodo = dojo.byId("generales.ultimoDiaPeriodo").value;
    //if (tieneFecVenc==1){
       var fechaVencimiento = dojo.byId("generales.fechaVencimientoPago").value.substring(6,10) +  dojo.byId("generales.fechaVencimientoPago").value.substring(3,5)+  dojo.byId("generales.fechaVencimientoPago").value.substring(0,2) ;
       if (tipoCP =="14" ){
            if(fechaVencimiento == ""){
               this.iconTooltipMessage("generales.fechaVencimientoPago", "icon-ok-tooltip", "Debe registrar la fecha de vencimiento.");
               return;
            }
            /*if(fechaVencimiento > ultimoDiaPeriodo){
               this.iconTooltipMessage("generales.fechaVencimientoPago", "icon-ok-tooltip", "Fecha de vencimiento debe ser menor o igual al periodo informado.");
               return;
            }*/
            if(fechaVencimiento < fechaEmision){
               this.iconTooltipMessage("generales.fechaVencimientoPago", "icon-ok-tooltip", "Fecha de vencimiento debe ser mayor o igual a la fecha de emision.");
               return;
            }       
             ////
            var fecEmisionMas10 = new Date(dojo.byId("generales.fechaEmisionCP").value.substring(3,5) + "/" + dojo.byId("generales.fechaEmisionCP").value.substring(0,2) + "/" + dojo.byId("generales.fechaEmisionCP").value.substring(6,10));
            var TenAniosSiguientes = fecEmisionMas10.setFullYear(fecEmisionMas10.getFullYear()+10);
            var fecSiguiente = new Date(TenAniosSiguientes);
            ultimoDiaPeriodo = dojo.date.locale.format(fecSiguiente, {datePattern: "yyyyMMdd", selector: "date"});
            if(fechaVencimiento > ultimoDiaPeriodo){
               this.iconTooltipMessage("generales.fechaVencimientoPago", "icon-ok-tooltip", "Fecha de vencimiento no puede ser mayor a 10 a�os despues de la fecha de emisi�n.");
               return;
            } 
          
             /////
       }else{
            if(fechaVencimiento != ""){
                /*if(fechaVencimiento > ultimoDiaPeriodo){
                   this.iconTooltipMessage("generales.fechaVencimientoPago", "icon-ok-tooltip", "Fecha de vencimiento debe ser menor o igual al periodo informado.");
                   return;
                }*/
                if(fechaVencimiento < fechaEmision){
                   this.iconTooltipMessage("generales.fechaVencimientoPago", "icon-ok-tooltip", "Fecha de vencimiento debe ser mayor o igual a la fecha de emision.");
                   return;
                }    
                var fecEmisionMas10 = new Date(dojo.byId("generales.fechaEmisionCP").value.substring(3,5) + "/" + dojo.byId("generales.fechaEmisionCP").value.substring(0,2) + "/" + dojo.byId("generales.fechaEmisionCP").value.substring(6,10));
                var TenAniosSiguientes = fecEmisionMas10.setFullYear(fecEmisionMas10.getFullYear()+10);
                var fecSiguiente = new Date(TenAniosSiguientes);
                ultimoDiaPeriodo = dojo.date.locale.format(fecSiguiente, {datePattern: "yyyyMMdd", selector: "date"});
                if(fechaVencimiento > ultimoDiaPeriodo){
                   this.iconTooltipMessage("generales.fechaVencimientoPago", "icon-ok-tooltip", "Fecha de vencimiento no puede ser mayor a 10 a�os despues de la fecha de emisi�n.");
                   return;
                } 
                                      
            }
       }
    //}  
    
    var handler = null;
    var tipoCP = dijit.byId("generales.tipoCP").getValue().substring(0,2);
    //Validamos Serie del CP
    var nroSerieCP = dijit.byId("generales.numeroSerieCP").getValue();
    if ( tipoCP =="01" ||  tipoCP =="03" || tipoCP =="07" || tipoCP =="08" || tipoCP =="04" ||  tipoCP =="05" ||  tipoCP =="06" || tipoCP =="23" || 
         tipoCP =="55" || tipoCP =="56" ){
        if(nroSerieCP == ""){
           this.iconTooltipMessage("generales.numeroSerieCP", "icon-ok-tooltip", "Debe registrar el n�mero de serie del CP.");
           return;
        }else{
             /*if (tipoCP =="01"  ){
                 if(nroSerieCP == "E001"){
                     this.iconTooltipMessage("generales.numeroSerieCP", "icon-ok-tooltip", "N�mero de serie del CP inconsistente.");
                     return;                
                 }
             }*/
             if (  tipoCP =="05" || tipoCP =="55" ){
                if (dojo.byId("generales.numeroSerieCP").value.length != 1) { 
                     this.iconTooltipMessage("generales.numeroSerieCP", "icon-ok-tooltip", "N�mero de serie del CP inconsistente. Debe tener 1 posicion");
                     return;
               }
             }else{
               if (dojo.byId("generales.numeroSerieCP").value.length != 4) { 
                     this.iconTooltipMessage("generales.numeroSerieCP", "icon-ok-tooltip", "N�mero de serie del CP inconsistente. Debe tener 4 posiciones");
                     return;
               }
             }
            //Validamos que exista la serie del CP
            if (  (nroSerieCP != "E001" && nroSerieCP != "EB01" && nroSerieCP.substring(0,1) != "F" && nroSerieCP.substring(0,1) != "B" ) && (tipoCP =="01" ||  tipoCP =="03" || tipoCP =="04" || tipoCP =="06" || tipoCP =="07" ||  tipoCP =="08" || tipoCP =="16" ||  tipoCP =="23") ){
                   var flagSalida = 0;
                   handler = dojo.xhrGet({
                        url: this.controller + "?action=validarSerieCP&nroSerieCP=" + nroSerieCP + "&tipoDoc=" + tipoCP,
                        handleAs: "json",
                        sync: true,
                        timeout: 10000
                   });       
              
                   handler.addCallback(dojo.hitch(this, function(res){
                		   if (res.codeError != 0) {
                          this.iconTooltipMessage("generales.numeroSerieCP", "icon-ok-tooltip", "Nro. de serie no ha sido autorizada por el contribuyente.");
                          flagSalida = 1;
                			 }
                		 }));
                   handler.addErrback(function(res){
                    			this.waitMessage.hide();
                    			alert("Problemas al conectarse con el servidor");
                    			return;
                   }); 
                   if (flagSalida != 0) {return;}
            }        
        }
    }else{
        if ( tipoCP =="12" ){
            if(nroSerieCP == ""){
               this.iconTooltipMessage("generales.numeroSerieCP", "icon-ok-tooltip", "Debe registrar el n�mero de serie del CP.");
               return;
            }
        }else{
            if(nroSerieCP != ""){
                //Validamos que exista la serie del CP
                if (  (nroSerieCP != "E001" && nroSerieCP != "EB01" && nroSerieCP.substring(0,1) != "F" && nroSerieCP.substring(0,1) != "B" ) && (  tipoCP =="01" ||  tipoCP =="03" ||  tipoCP =="04" || tipoCP =="06" ||  tipoCP =="07" ||  tipoCP =="08" ||  tipoCP =="16" ||  tipoCP =="23" || tipoCP =="55" ||  tipoCP =="56") ){
                       var flagSalida = 0;
                       if (tipoCP =="07" &&  dojo.byId("generales.numeroSerieCP").value.length != 4) {
                       
                       }else{
                             handler = dojo.xhrGet({
                                  url: this.controller + "?action=validarSerieCP&nroSerieCP=" + nroSerieCP + "&tipoDoc=" + tipoCP,
                                  handleAs: "json",
                                  sync: true,
                                  timeout: 10000
                             });       
                        
                             handler.addCallback(dojo.hitch(this, function(res){
                          		   if (res.codeError != 0) {
                                    this.iconTooltipMessage("generales.numeroSerieCP", "icon-ok-tooltip", "N�mero de Serie no ha sido autorizada por el contribuyente.");
                                    flagSalida = 1;
                          			 }
                          		 }));
                             handler.addErrback(function(res){
                              			this.waitMessage.hide();
                              			alert("Problemas al conectarse con el servidor");
                              			return;
                             }); 
                       }
                       if (flagSalida != 0) {return;}
                }     

            }
                  
        }
      
    }
    //Validamos Rango
    var tieneNrosRango = this.getValorOpcionCapturarCPPorRangos();//dojo.byId("global.capturarCpXRangos").value;

    //if (tieneNrosRango==1 && ( tipoCP =="03" ||  tipoCP =="12" || tipoCP =="15" ||  tipoCP =="19" ) ){ // Se cambio para ple 5
    if (tieneNrosRango==1 && ( tipoCP =="03" ||  tipoCP =="12" || tipoCP =="00" ||  tipoCP =="13" || tipoCP =="87") ){
       var numeroInicial = dijit.byId("generales.numeroInicialCP").getValue();
       var numeroFinal   = dijit.byId("generales.numeroFinalCP").getValue();
       if (numeroInicial =="" ){
           this.iconTooltipMessage("generales.numeroInicialCP", "icon-ok-tooltip", "Debe ingresar n�mero inicial.");
           return;
       }
       if (numeroFinal==""){
           this.iconTooltipMessage("generales.numeroFinalCP", "icon-ok-tooltip", "Debe ingresar n�mero final.");
           return;
       }       
       if ((numeroFinal*1) <=  (numeroInicial*1)){
           this.iconTooltipMessage("generales.numeroInicialCP", "icon-ok-tooltip", "N�mero inicial debe ser menor que el n�mero final.");
           return;       
       }
    }	else{
       var numeroCP = dojo.byId("generales.numeroCP").value;
       if (numeroCP =="" ){
           this.iconTooltipMessage("generales.numeroCP", "icon-ok-tooltip", "Debe ingresar n�mero del CP.");
           return;
       }
    }
    if (estadoCP =="08" || estadoCP =="09"  ){
       var numeroCorrelativo = dojo.byId("generales.numeroCorrelativo").value;
       if (numeroCorrelativo =="" ){
           this.iconTooltipMessage("generales.numeroCorrelativo", "icon-ok-tooltip", "Debe ingresar n�mero correlativo.");
           return;
       }
    } 
    //Validamos serie de maquina registradora
    /*
    var tieneEmisionMaqReg = dojo.byId("global.emisionMaquinaRegis").value;
    if (tieneEmisionMaqReg==1){
        if (tipoCP=="12"){  // estadoCP !="02" 
           if (dijit.byId("generales.numeroSerieMaqRegistra").getValue() == "") {
             this.iconTooltipMessage("generales.numeroSerieMaqRegistra", "icon-ok-tooltip", "Debe registrar el n�mero de serie.");
             return; 
           }
        }	 
    }
*/

    //Validamos numeraci�n de los comprobantes

    var periodoSeleccionado = dojo.byId("global.periodoComprobantes").value; 
    if (estadoCP =="09"){
        if (dojo.byId("global.cuoEncontrado").value != "1"){
             this.iconTooltipMessage("generales.cuo", "icon-ok-tooltip", "Error en el numero de CUO");
             return;
         }
         
          var numeroCP   = dijit.byId("generales.numeroCP").getValue();

         handler = null;
         handler = dojo.xhrGet({
              url: this.controller + "?action=validarNumeroCP&tipoCP=" + tipoCP + "&nroSerieCP=" + nroSerieCP + "&nroCP=" +numeroCP + "&periodo="+ periodoSeleccionado,
              handleAs: "json",
              sync: true,
              timeout: 10000
         });       
    
         handler.addCallback(dojo.hitch(this, function(res){
      		   if (res.codeError == 0) {
      		      this.guardarDatosGenerales();
      		      dojo.byId("global.esRetroceso").value = "0";
                this.content.setHref(this.controller + "?action=showDetalle"); 
                this.content.onLoad = dojo.hitch(this, function(){
        					   this.mostrarDatosDetalle();});                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                              
      			 } else {      
                var mensaje = "Existe el siguiente CP ya registrado: " 
                mensaje = mensaje + "RUC: " + res.data +  '\n'
                mensaje = mensaje + "Tipo Documento: " + dojo.trim(dijit.byId("generales.tipoCP").getValue().substring(5)) +  '\n'
                mensaje = mensaje + "Serie: " + nroSerieCP+  '\n'
                mensaje = mensaje + res.messageError;
                //if (tieneNrosRango==1 && ( tipoCP =="03" ||  tipoCP =="12" || tipoCP =="15" ||  tipoCP =="19" )){  //Se cambio para ple
                if (tieneNrosRango==1 && ( tipoCP =="03" ||  tipoCP =="12" || tipoCP =="00" ||  tipoCP =="13" || tipoCP =="87")){
                    this.iconTooltipMessage("generales.numeroInicialCP", "icon-ok-tooltip", mensaje);
                }else{
                    this.iconTooltipMessage("generales.numeroCP", "icon-ok-tooltip", mensaje);
                }
                return;
      			 }
      		 }));
           handler.addErrback(function(res){
          			this.waitMessage.hide();
          			alert("Problemas al conectarse con el servidor");
          }); 
    }else
    {
          var modificaCPOriginal = 0; //    dojo.byId("global.cpModifCpOriginal").value;
          if (tipoCP =="07" || tipoCP == "08" || tipoCP =="87" || tipoCP == "88"){
              modificaCPOriginal=1; 
          }
          if (modificaCPOriginal==1 && estadoCP!="02"){
              var tipoCPModif = dijit.byId("detalle.tipoCPModificado").getValue().substring(0,2);
              var nroSerieCPModif = dijit.byId("detalle.numeroSerieCPModificado").getValue();
              var fechaEmisionModif =dijit.byId("detalle.fechaEmisionCPModificado").getValue();
              if (tipoCPModif =="07" || tipoCPModif == "08" || tipoCPModif =="87" || tipoCPModif == "88"){
                      this.iconTooltipMessage("detalle.tipoCPModificado", "icon-ok-tooltip", "No se puede modificar ese tipo de CP.");
                      return;
              }
              if (tipoCPModif == "-" && nroSerieCPModif=="" && (fechaEmisionModif =="" || fechaEmisionModif ==null) && dojo.byId("detalle.numeroCPModificado").value ==""){
                    if ((tipoCP =="07" || tipoCP == "08") && (nroSerieCP =="E001" || nroSerieCP =="EB01" )){
                           this.iconTooltipMessage("detalle.tipoCPModificado", "icon-ok-tooltip", "Debe registrar el CP que se modifica para una NC electr�nica o una ND electr�nica");
                           return;
                    }              
              }else{
                    if (tipoCPModif == "-" ){
                          this.iconTooltipMessage("detalle.tipoCPModificado", "icon-ok-tooltip", "Debe seleccionar el tipo de CP modificado.");
                          return;
                    }
                    
                    var ultimoDiaPeriodo = dojo.byId("generales.ultimoDiaPeriodo").value;
                    if ( tipoCPModif =="01" ||  tipoCPModif =="03" || tipoCPModif =="04" ||  tipoCPModif =="06" || tipoCPModif =="16" || tipoCPModif =="23" || tipoCPModif =="07" ||  tipoCPModif =="08" || tipoCPModif =="87" ||  tipoCPModif =="88" || tipoCPModif =="97" ||  tipoCPModif =="98"){
                        if(fechaEmisionModif== null || fechaEmisionModif == ""){
                           this.iconTooltipMessage("detalle.fechaEmisionCPModificado", "icon-ok-tooltip", "Debe registrar la fecha de emisi�n.");
                           return;
                        }
                        
                        var valor = dojo.byId("detalle.numeroSerieCPModificado").value;
                        if(valor == ""){
                           this.iconTooltipMessage("detalle.numeroSerieCPModificado", "icon-ok-tooltip", "N�mero de serie del CP inconsistente");
                           return;
                        }
                    
                        var valorNumCP = dojo.byId("detalle.numeroCPModificado").value;
                        if(valorNumCP == ""){
                           this.iconTooltipMessage("detalle.numeroCPModificado", "icon-ok-tooltip", "N�mero de CP modificado inconsistente");
                           return;
                        }   
                        if (dojo.byId("detalle.numeroSerieCPModificado").value.length != 4) { 
                           this.iconTooltipMessage("detalle.numeroSerieCPModificado", "icon-ok-tooltip", "N�mero de serie del CP modificado inconsistente. Debe tener 4 posiciones");
                           return;
                        }
                         
                          //Validamos que exista la serie del CP que se modifica
                          if (  (nroSerieCP != "E001" && nroSerieCP != "EB01" && nroSerieCP.substring(0,1) != "F" && nroSerieCP.substring(0,1) != "B" ) && (tipoCP =="01" ||  tipoCP =="03" || tipoCP =="07" ||  tipoCP =="08") ){
                                 var flagSalida = 0;
                                 handler = dojo.xhrGet({
                                      url: this.controller + "?action=validarSerieCP&nroSerieCP=" + nroSerieCPModif + "&tipoDoc=" + tipoCPModif,
                                      handleAs: "json",
                                      sync: true,
                                      timeout: 10000
                                 });       
                            
                                 handler.addCallback(dojo.hitch(this, function(res){
                              		   if (res.codeError != 0) {
                                        this.iconTooltipMessage("detalle.numeroSerieCPModificado", "icon-ok-tooltip", "N�mero de Serie no ha sido autorizada por el contribuyente.");
                                        flagSalida = 1;
                              			 }
                              		 }));
                                 handler.addErrback(function(res){
                                  			this.waitMessage.hide();
                                  			alert("Problemas al conectarse con el servidor");
                                  			return;
                                 }); 
                                 if (flagSalida != 0) {return;}
                          }                               
                    }else{
                        if ( tipoCPModif =="12" ){
                            if(nroSerieCPModif == ""){
                               this.iconTooltipMessage("detalle.numeroSerieCPModificado", "icon-ok-tooltip", "Debe registrar el n�mero de serie del CP.");
                               return;
                            }
                            var valorNumCP = dojo.byId("detalle.numeroCPModificado").value;
                            if(valorNumCP == ""){
                               this.iconTooltipMessage("detalle.numeroCPModificado", "icon-ok-tooltip", "N�mero de CP modificado inconsistente");
                               return;
                            }                         
                        }              
                    }
                    if(fechaEmisionModif !=  null && fechaEmisionModif != ""){
                        fechaEmisionModif = dojo.byId("detalle.fechaEmisionCPModificado").value.substring(6,10) +  dojo.byId("detalle.fechaEmisionCPModificado").value.substring(3,5)+  dojo.byId("detalle.fechaEmisionCPModificado").value.substring(0,2) ;
                        if(fechaEmisionModif > ultimoDiaPeriodo){
                           this.iconTooltipMessage("detalle.fechaEmisionCPModificado", "icon-ok-tooltip", "Fecha de emisi�n del CP a modificar debe ser menor o igual al periodo informado.");
                           return;
                        }
                        ///YYTYYY
                        var fechaEmision = dojo.byId("generales.fechaEmisionCP").value.substring(6,10) +  dojo.byId("generales.fechaEmisionCP").value.substring(3,5)+  dojo.byId("generales.fechaEmisionCP").value.substring(0,2) ;
                        if(fechaEmisionModif > fechaEmision){
                           this.iconTooltipMessage("detalle.fechaEmisionCPModificado", "icon-ok-tooltip", "La fecha de emisi�n debe ser menor o igual a la fecha de emisi�n del CP que se modifica.");
                           return;
                        }                   
                    } 
                    
                        /*if (estadoCP !="08" && estadoCP !="09"  ){
                          if(fechaEmision > ultimoDiaPeriodo){
                             this.iconTooltipMessage("detalle.fechaEmisionCPModificado", "icon-ok-tooltip", "Fecha de emisi�n debe estar dentro del periodo informado.");
                             return;
                          }
                          var periodoactual = dojo.byId("global.periodoComprobantes").value + "01"; 
                          if(fechaEmision < periodoactual){
                             this.iconTooltipMessage("detalle.fechaEmisionCPModificado", "icon-ok-tooltip", "Fecha de emisi�n debe estar dentro del periodo informado.");
                             return;
                          }               
                        }else{
                              var fecAjuste = new Date(dojo.byId("global.periodoAjuste").value.substring(4,8) + "/01/"+dojo.byId("global.periodoAjuste").value.substring(0,4));
                              var mesSiguiente = fecAjuste.setMonth(fecAjuste.getMonth()+1);
                              mesSiguiente = fecAjuste.setDate(1);
                              mesSiguiente = fecAjuste.setDate(fecAjuste.getDate() -1);
                              var fecSiguiente = new Date(mesSiguiente);
                              ultimoDiaPeriodo = dojo.date.locale.format(fecSiguiente, {datePattern: "yyyyMMdd", selector: "date"});
                              if(fechaEmision > ultimoDiaPeriodo){
                                 this.iconTooltipMessage("detalle.fechaEmisionCPModificado", "icon-ok-tooltip", "Fecha de emisi�n no debe ser mayor al periodo al que corresponde el ajuste.");
                                 return;
                              }   
                              var periodoajust = dojo.byId("global.periodoAjuste").value + "01";
                              //if(fechaEmision < periodoajust){
                              //   this.iconTooltipMessage("detalle.fechaEmisionCPModificado", "icon-ok-tooltip", "Fecha de emisi�n debe estar dentro del periodo al que corresponde el ajuste.");
                              //   return;
                              //} 
                              if(fechaEmision < "19920101"){
                                 this.iconTooltipMessage("detalle.fechaEmisionCPModificado", "icon-ok-tooltip", "Fecha de emisi�n no puede ser menor a 01/1992.");
                                 return;
                              }                   
                        }*/
                        
                        if(fechaEmision < "19880101"){
                                 this.iconTooltipMessage("detalle.fechaEmisionCPModificado", "icon-ok-tooltip", "Fecha de emisi�n no puede ser menor a 01/1988.");
                                 return;
                        }  
               }
          }  
    
          var bContinuar = true;
          var numeroInicial = dojo.byId("generales.numeroInicialCP").value;
          var numeroFinal   = dojo.byId("generales.numeroFinalCP").value;
          var numeroCP   = dojo.byId("generales.numeroCP").value;
          var tieneNrosRango = this.getValorOpcionCapturarCPPorRangos();
          if ( tipoCP =="04"  ){
              if ( nroSerieCP.substring(0,1)!= "E" && nroSerieCP.substring(0,1)!= "F"  && nroSerieCP.substring(0,1)!= "B"  ){
                  if (numeroCP.length >7){
                         this.iconTooltipMessage("generales.numeroCP", "icon-ok-tooltip", "Si el comprobante es f�sico la longitud debe ser m�ximo de 7 posiciones");
                         return;                       
                  }
              }
          }
          
          if (   (nroSerieCP.substring(0,1)!= "E" && nroSerieCP.substring(0,1)!= "F"  && nroSerieCP.substring(0,1)!= "B"  ) 
              && (tipoCP =="01" ||  tipoCP =="03" || tipoCP =="07" ||  tipoCP =="08" || tipoCP =="04" ||  tipoCP =="06" || tipoCP =="16" || tipoCP =="23") ){
              if (tieneNrosRango==1 && tipoCP =="03"){
              }else{
                  numeroInicial = numeroCP;
                  numeroFinal = numeroCP;
              } 

                 handler = dojo.xhrGet({
                      url: this.controller + "?action=validarRangosCPAutorizados&tipoCP=" + tipoCP +"&nroSerieCP=" + nroSerieCP + "&nroInicial=" +numeroInicial + "&nroFinal=" +numeroFinal ,
                      handleAs: "json",
                      sync: true,
                      timeout: 20000
                 });  
                  handler.addCallback(dojo.hitch(this, function(res){
                  		if (res.codeError == 0) {
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                           
                  		} else {  
                             if (tieneNrosRango==1 && ( tipoCP =="03") ){
                                    this.iconTooltipMessage("generales.numeroInicialCP", "icon-ok-tooltip", res.messageError);
                             }else{
                                    this.iconTooltipMessage("generales.numeroCP", "icon-ok-tooltip", res.messageError);
                             }    
                            bContinuar = false;
                  		}
              		 }));
                   handler.addErrback(function(res){
                  			//this.waitMessage.hide();
                  			alert("Problemas al conectarse con el servidor");
                  			bContinuar = false;
                  });              
              /////
          }
          
          if (bContinuar == false) { return;}
          
          if (  (nroSerieCP.substring(0,1)== "E" || nroSerieCP.substring(0,1)== "F"  || nroSerieCP.substring(0,1)== "B"  ) && (tipoCP =="01" ||  tipoCP =="03" || tipoCP =="07" ||  tipoCP =="08") ){

              if (tieneNrosRango==1 && ( tipoCP =="03" )){

                 handler = dojo.xhrGet({
                      url: this.controller + "?action=validarRangoNumerosCPE&tipoCP=" + tipoCP +"&nroSerieCP=" + nroSerieCP + "&nroInicial=" +numeroInicial + "&nroFinal=" +numeroFinal ,
                      handleAs: "json",
                      sync: true,
                      timeout: 10000
                 });  
                      handler.addCallback(dojo.hitch(this, function(res){
              		   if (res.codeError == 0) {
              		      this.guardarDatosGenerales();
              		      
              		      if (estadoCP =="02"){
                            dojo.byId("global.esRetrocesoDetalle").value = "0";
                  					this.content.setHref(this.controller + "?action=showPreliminar&preventCache=" + this.preventCache());
                  					this.content.onLoad = dojo.hitch(this, function(){
                  					     this.mostrarDatosPreliminar();});      		      
                        }else{
                            dojo.byId("global.esRetroceso").value = "0";
                            this.content.setHref(this.controller + "?action=showDetalle"); 
                            this.content.onLoad = dojo.hitch(this, function(){
                    					   this.mostrarDatosDetalle();});     
                        }                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                         
              			 } else {      
              			    if (  (nroSerieCP.substring(0,1)== "E" || nroSerieCP.substring(0,1)== "F"  || nroSerieCP.substring(0,1)== "B") && (tipoCP =="01" ||  tipoCP =="03" || tipoCP =="07" ||  tipoCP =="08") ){
                            if (res.codeError = 1){
                  			        var mensaje = "No existe el siguiente CPE ya registrado: " 
                                mensaje = mensaje + "RUC: " + res.data +  '\n'
                                mensaje = mensaje + "Tipo Documento: " + dojo.trim(dijit.byId("generales.tipoCP").getValue().substring(5)) +  '\n'
                                mensaje = mensaje + "Serie: " + nroSerieCP+  '\n'
                                mensaje = mensaje + "Numero: " + numeroCP;
                                if (tieneNrosRango==1 && ( tipoCP =="03") ){
                                    this.iconTooltipMessage("generales.numeroInicialCP", "icon-ok-tooltip", mensaje);
                                }else{
                                    this.iconTooltipMessage("generales.numeroCP", "icon-ok-tooltip", mensaje);
                                }
                            }else{
                  			        var mensaje = "Existe un CPE emitido en el mismo periodo." 
                                if (tieneNrosRango==1 && ( tipoCP =="03") ){
                                    this.iconTooltipMessage("generales.numeroInicialCP", "icon-ok-tooltip", mensaje);
                                }else{
                                    this.iconTooltipMessage("generales.numeroCP", "icon-ok-tooltip", mensaje);
                                }                  
                            }
              			    }else{
                            var mensaje = "Existe el siguiente CP ya registrado: " 
                            mensaje = mensaje + "RUC: " + res.data +  '\n'
                            mensaje = mensaje + "Tipo Documento: " + dojo.trim(dijit.byId("generales.tipoCP").getValue().substring(5)) +  '\n'
                            mensaje = mensaje + "Serie: " + nroSerieCP+  '\n'
                            mensaje = mensaje + res.messageError;
                            //if (tieneNrosRango==1 && ( tipoCP =="03" ||  tipoCP =="12" || tipoCP =="15" ||  tipoCP =="19" ) ){  //Se cambio para ple 5
                            if (tieneNrosRango==1 && ( tipoCP =="03" ||  tipoCP =="12" || tipoCP =="00" ) ){
                                this.iconTooltipMessage("generales.numeroInicialCP", "icon-ok-tooltip", mensaje);
                            }else{
                                this.iconTooltipMessage("generales.numeroCP", "icon-ok-tooltip", mensaje);
                            }
                        }
                        return;
              			 }
              		 }));
                   handler.addErrback(function(res){
                  			//this.waitMessage.hide();
                  			alert("Problemas al conectarse con el servidor");
                  });  
             }else{

                 handler = dojo.xhrGet({
                      url: this.controller + "?action=validarNumeroCPE&tipoCP=" + tipoCP + "&nroSerieCP=" + nroSerieCP + "&nroCP=" +numeroCP + "&periodo=" +periodoSeleccionado,
                      handleAs: "json",
                      sync: true,
                      timeout: 10000
                 });    
                  handler.addCallback(dojo.hitch(this, function(res){

              		   if (res.codeError == 0) {
              		      this.guardarDatosGenerales();
              		      
              		      if (estadoCP =="02"){
                            dojo.byId("global.esRetrocesoDetalle").value = "0";
                  					this.content.setHref(this.controller + "?action=showPreliminar&preventCache=" + this.preventCache());
                  					this.content.onLoad = dojo.hitch(this, function(){
                  					     this.mostrarDatosPreliminar();});      		      
                        }else{
                            dojo.byId("global.esRetroceso").value = "0";
                            this.content.setHref(this.controller + "?action=showDetalle"); 
                            this.content.onLoad = dojo.hitch(this, function(){
                    					   this.mostrarDatosDetalle();});     
                        }                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                         
              			 } else {      
              			    if (  (nroSerieCP.substring(0,1)== "E" || nroSerieCP.substring(0,1)== "F"  || nroSerieCP.substring(0,1)== "B" ) && (tipoCP =="01" ||  tipoCP =="03" || tipoCP =="07" ||  tipoCP =="08") ){
                            if (res.codeError == 1){
                  			        var mensaje = "No existe el siguiente CPE ya registrado: " 
                                mensaje = mensaje + "RUC: " + res.data +  '\n'
                                mensaje = mensaje + "Tipo Documento: " + dojo.trim(dijit.byId("generales.tipoCP").getValue().substring(5)) +  '\n'
                                mensaje = mensaje + "Serie: " + nroSerieCP+  '\n'
                                mensaje = mensaje + "Numero: " + numeroCP;
                                if (tieneNrosRango==1 && ( tipoCP =="03") ){
                                    this.iconTooltipMessage("generales.numeroInicialCP", "icon-ok-tooltip", mensaje);
                                }else{
                                    this.iconTooltipMessage("generales.numeroCP", "icon-ok-tooltip", mensaje);
                                }
                            }else{
                  			        var mensaje = "Existe un CPE emitido en el mismo periodo con igual serie y numero." 
                                if (tieneNrosRango==1 && ( tipoCP =="03") ){
                                    this.iconTooltipMessage("generales.numeroInicialCP", "icon-ok-tooltip", mensaje);
                                }else{
                                    this.iconTooltipMessage("generales.numeroCP", "icon-ok-tooltip", mensaje);
                                }                  
                            }
              			    }else{
                            var mensaje = "Existe el siguiente CP ya registrado: " 
                            mensaje = mensaje + "RUC: " + res.data +  '\n'
                            mensaje = mensaje + "Tipo Documento: " + dojo.trim(dijit.byId("generales.tipoCP").getValue().substring(5)) +  '\n'
                            mensaje = mensaje + "Serie: " + nroSerieCP+  '\n'
                            mensaje = mensaje + res.messageError;
                            //if (tieneNrosRango==1 && ( tipoCP =="03" ||  tipoCP =="12" || tipoCP =="15" ||  tipoCP =="19" ) ){  //Se cambio para ple 5
                            if (tieneNrosRango==1 && ( tipoCP =="03" ||  tipoCP =="12" || tipoCP =="00" ||  tipoCP =="13" || tipoCP =="87") ){
                                this.iconTooltipMessage("generales.numeroInicialCP", "icon-ok-tooltip", mensaje);
                            }else{
                                this.iconTooltipMessage("generales.numeroCP", "icon-ok-tooltip", mensaje);
                            }
                        }
                        return;
              			 }
              			 
              		 }));
                   handler.addErrback(function(res){
                  			this.waitMessage.hide();
                  			alert("Problemas al conectarse con el servidor");
                  });  
                    
             }
         }else{
             //if (tieneNrosRango==1 && (tipoCP == "03" || tipoCP =="12" || tipoCP =="15" ||  tipoCP =="19" )){  //Se cambio para ple5
             if (tieneNrosRango==1 && (tipoCP == "03" || tipoCP =="12" || tipoCP =="00" ||  tipoCP =="13" || tipoCP =="87")){
            
                 handler = dojo.xhrGet({
                      url: this.controller + "?action=validarRangoNumerosCP&tipoCP=" + tipoCP +"&nroSerieCP=" + nroSerieCP + "&nroInicial=" +numeroInicial + "&nroFinal=" +numeroFinal ,
                      handleAs: "json",
                      sync: true,
                      timeout: 10000
                 });    
                  handler.addCallback(dojo.hitch(this, function(res){
              		   if (res.codeError == 0) {
              		      this.guardarDatosGenerales();
              		      
              		      if (estadoCP =="02"){
                            dojo.byId("global.esRetrocesoDetalle").value = "0";
                  					this.content.setHref(this.controller + "?action=showPreliminar&preventCache=" + this.preventCache());
                  					this.content.onLoad = dojo.hitch(this, function(){
                  					     this.mostrarDatosPreliminar();});      		      
                        }else{
                            dojo.byId("global.esRetroceso").value = "0";
                            this.content.setHref(this.controller + "?action=showDetalle"); 
                            this.content.onLoad = dojo.hitch(this, function(){
                    					   this.mostrarDatosDetalle();});     
                        }                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                         
              			 } else {      
              			    if (  (nroSerieCP.substring(0,1)== "E" || nroSerieCP.substring(0,1)== "F"  || nroSerieCP.substring(0,1)== "B") && (tipoCP =="01" ||  tipoCP =="03" || tipoCP =="07" ||  tipoCP =="08") ){
                            if (res.codeError = 1){
                  			        var mensaje = "No existe el siguiente CPE ya registrado: " 
                                mensaje = mensaje + "RUC: " + res.data +  '\n'
                                mensaje = mensaje + "Tipo Documento: " + dojo.trim(dijit.byId("generales.tipoCP").getValue().substring(5)) +  '\n'
                                mensaje = mensaje + "Serie: " + nroSerieCP+  '\n'
                                mensaje = mensaje + "Numero: " + numeroCP;
                                if (tieneNrosRango==1 && ( tipoCP =="03") ){
                                    this.iconTooltipMessage("generales.numeroInicialCP", "icon-ok-tooltip", mensaje);
                                }else{
                                    this.iconTooltipMessage("generales.numeroCP", "icon-ok-tooltip", mensaje);
                                }
                            }else{
                  			        var mensaje = "Existe un CPE emitido en el mismo periodo." 
                                if (tieneNrosRango==1 && ( tipoCP =="03") ){
                                    this.iconTooltipMessage("generales.numeroInicialCP", "icon-ok-tooltip", mensaje);
                                }else{
                                    this.iconTooltipMessage("generales.numeroCP", "icon-ok-tooltip", mensaje);
                                }                  
                            }
              			    }else{
                            var mensaje = "Existe el siguiente CP ya registrado: " 
                            mensaje = mensaje + "RUC: " + res.data +  '\n'
                            mensaje = mensaje + "Tipo Documento: " + dojo.trim(dijit.byId("generales.tipoCP").getValue().substring(5)) +  '\n'
                            mensaje = mensaje + "Serie: " + nroSerieCP+  '\n'
                            mensaje = mensaje + res.messageError;
                            //if (tieneNrosRango==1 && ( tipoCP =="03" ||  tipoCP =="12" || tipoCP =="15" ||  tipoCP =="19" ) ){  //Se cambio para ple5
                            if (tieneNrosRango==1 && ( tipoCP =="03" ||  tipoCP =="12" || tipoCP =="00" ||  tipoCP =="13" || tipoCP =="87") ){
                                this.iconTooltipMessage("generales.numeroInicialCP", "icon-ok-tooltip", mensaje);
                            }else{
                                this.iconTooltipMessage("generales.numeroCP", "icon-ok-tooltip", mensaje);
                            }
                        }
                        return;
              			 }
              		 }));
                   handler.addErrback(function(res){
                  			//this.waitMessage.hide();
                  			alert("Problemas al conectarse con el servidor");
                  });  
                 
             }else{
                 handler = dojo.xhrGet({
                      url: this.controller + "?action=validarNumeroCP&tipoCP=" + tipoCP + "&nroSerieCP=" + nroSerieCP + "&nroCP=" +numeroCP,
                      handleAs: "json",
                      sync: true,
                      timeout: 10000
                 });     
                  handler.addCallback(dojo.hitch(this, function(res){
              		   if (res.codeError == 0) {
              		      this.guardarDatosGenerales();
              		      
              		      if (estadoCP =="02"){
                            dojo.byId("global.esRetrocesoDetalle").value = "0";
                  					this.content.setHref(this.controller + "?action=showPreliminar&preventCache=" + this.preventCache());
                  					this.content.onLoad = dojo.hitch(this, function(){
                  					     this.mostrarDatosPreliminar();});      		      
                        }else{
                            dojo.byId("global.esRetroceso").value = "0";
                            this.content.setHref(this.controller + "?action=showDetalle"); 
                            this.content.onLoad = dojo.hitch(this, function(){
                    					   this.mostrarDatosDetalle();});     
                        }                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                         
              			 } else {      
              			    if (  (nroSerieCP.substring(0,1)== "E" || nroSerieCP.substring(0,1)== "F"  || nroSerieCP.substring(0,1)== "B") && (tipoCP =="01" ||  tipoCP =="03" || tipoCP =="07" ||  tipoCP =="08") ){
                            if (res.codeError = 1){
                  			        var mensaje = "No existe el siguiente CPE ya registrado: " 
                                mensaje = mensaje + "RUC: " + res.data +  '\n'
                                mensaje = mensaje + "Tipo Documento: " + dojo.trim(dijit.byId("generales.tipoCP").getValue().substring(5)) +  '\n'
                                mensaje = mensaje + "Serie: " + nroSerieCP+  '\n'
                                mensaje = mensaje + "Numero: " + numeroCP;
                                if (tieneNrosRango==1 && ( tipoCP =="03") ){
                                    this.iconTooltipMessage("generales.numeroInicialCP", "icon-ok-tooltip", mensaje);
                                }else{
                                    this.iconTooltipMessage("generales.numeroCP", "icon-ok-tooltip", mensaje);
                                }
                            }else{
                  			        var mensaje = "Existe un CPE emitido en el mismo periodo." 
                                if (tieneNrosRango==1 && ( tipoCP =="03") ){
                                    this.iconTooltipMessage("generales.numeroInicialCP", "icon-ok-tooltip", mensaje);
                                }else{
                                    this.iconTooltipMessage("generales.numeroCP", "icon-ok-tooltip", mensaje);
                                }                  
                            }
              			    }else{
                            var mensaje = "Existe el siguiente CP ya registrado: " 
                            mensaje = mensaje + "RUC: " + res.data +  '\n'
                            mensaje = mensaje + "Tipo Documento: " + dojo.trim(dijit.byId("generales.tipoCP").getValue().substring(5)) +  '\n'
                            mensaje = mensaje + "Serie: " + nroSerieCP+  '\n'
                            mensaje = mensaje + res.messageError;
                            //if (tieneNrosRango==1 && ( tipoCP =="03" ||  tipoCP =="12" || tipoCP =="15" ||  tipoCP =="19" ) ){ //se cambio para ple5
                            if (tieneNrosRango==1 && ( tipoCP =="03" ||  tipoCP =="12" || tipoCP =="00" ||  tipoCP =="13" || tipoCP =="87") ){
                                this.iconTooltipMessage("generales.numeroInicialCP", "icon-ok-tooltip", mensaje);
                            }else{
                                this.iconTooltipMessage("generales.numeroCP", "icon-ok-tooltip", mensaje);
                            }
                        }
                        return;
              			 }
              		 }));
                   handler.addErrback(function(res){
                  			//this.waitMessage.hide();
                  			alert("Problemas al conectarse con el servidor");
                  });  
                   
             }
         }
 
    }


	},
	
	mostrarDatosDetalle: function() {
	
      
	  var tipoMoneda = dijit.byId("detalle.tipoMoneda").getValue(); 
    //dijit.byId("detalle.tipoMoneda").getValue().substring(0,3); 
	  if (tipoMoneda =="XX1" ){
         this.content.setHref(this.controller + "?action=verMasTiposMoneda" ); 
         return;
           
    }
   
	  //Seteamos pantalla
	  var estadoCP = dojo.byId("global.estadoCP").value;
	  var tieneNoNuevoSol = dojo.byId("global.opcMonedaNoNuevoSol").value;
    if (tieneNoNuevoSol==1){
       if (estadoCP == "02"){
         this.showHiddenDiv(document.getElementById("detalle.tipoMoneda.show"),false);
         this.showHiddenDiv(document.getElementById("detalle.tipoCambio.show"),false);       
         dojo.byId("detalle.tipoMoneda").value = "-"; 
         //dojo.byId("detalle.fechaTC").value = "";  
         dijit.byId("detalle.tc").setValue("");  
          dojo.byId("global.tc").value =""; 
        
       }else{
         this.showHiddenDiv(document.getElementById("detalle.tipoMoneda.show"),true);
         
         //if (tipoMoneda != "USD" && tipoMoneda != "CAD" && tipoMoneda != "GBP" && tipoMoneda != "JPY" && tipoMoneda != "SEK" && tipoMoneda != "CHF" && tipoMoneda != "EUR"){
            this.showHiddenDiv(document.getElementById("detalle.tipoCambio.show"),true);
            //this.showHiddenDiv(document.getElementById("detalle.tipoCambio.show"),false);
         //}else{
           // this.showHiddenDiv(document.getElementById("detalle.tipoCambio.show"),false);
            //dojo.byId("detalle.fechaTC").value = "";  
            //dojo.byId("detalle.tc").value = "";           
      
         //}
       }
    }else{
       this.showHiddenDiv(document.getElementById("detalle.tipoMoneda.show"),false);
       this.showHiddenDiv(document.getElementById("detalle.tipoCambio.show"),false);
       dojo.byId("detalle.tipoMoneda").value = "-"; 
       //dojo.byId("detalle.fechaTC").value = "";  
       dijit.byId("detalle.tc").setValue("");  
       dojo.byId("global.tc").value="";  
    }
    
    if (estadoCP == "00"){
       this.showHiddenDiv(document.getElementById("detalle.tipoCambio.show"),false);
       dijit.byId("detalle.tc").setValue("");  
       dojo.byId("global.tc").value = ""    ;
    }
    dojo.byId("detalle.periodoRegVenta").value  = dojo.byId("global.periodoComprobantesFormat").value;
    var tieneExportacion = dojo.byId("global.opcExportacion").value;
    if (tieneExportacion==1 && estadoCP != "02"){
       this.showHiddenDiv(document.getElementById("detalle.valorFacturadoExportacion.show"),true);
    }else{
       this.showHiddenDiv(document.getElementById("detalle.valorFacturadoExportacion.show"),false);
       dojo.byId("global.valorFacturadoExportacion").value = "";  
       //dojo.byId("global.valorEmbarcadoExportacion").value = "";  
    }
	
	    if (estadoCP == "00"){
         this.showHiddenDiv(document.getElementById("detalle.valorFacturadoExportacion.show"),false);
         dojo.byId("global.valorFacturadoExportacion").value = "";  
         //dojo.byId("global.valorEmbarcadoExportacion").value = "";  	    
	    }
	  var tieneVentasGrabadas = dojo.byId("global.opcVentasGrabadas").value;
    if (tieneVentasGrabadas==1 && estadoCP != "02" ){
          this.showHiddenDiv(document.getElementById("detalle.baseOperacGrav.show"),true);
          this.showHiddenDiv(document.getElementById("detalle.descBaseImponible.show"),true);
          this.showHiddenDiv(document.getElementById("detalle.IgvIpm.show"),true);
          this.showHiddenDiv(document.getElementById("detalle.descuentoIgvIpm.show"),true);
          
          
    }else{
       this.showHiddenDiv(document.getElementById("detalle.baseOperacGrav.show"),false);
       this.showHiddenDiv(document.getElementById("detalle.descBaseImponible.show"),false);
       this.showHiddenDiv(document.getElementById("detalle.IgvIpm.show"),false);
       this.showHiddenDiv(document.getElementById("detalle.descuentoIgvIpm.show"),false);
       dojo.byId("global.baseImpOperacGrav").value = "";  
       dojo.byId("global.descBaseImponible").value = "";  
       dojo.byId("global.tasaIgvoipm").value = "";
       
       dojo.byId("global.igvoipm").value = "";   
       dojo.byId("global.descuentoIgvoipm").value = "";  
       dojo.byId("detalle.baseImpOperacGrav").value = "";  
       dojo.byId("detalle.igvoipm").value = "";     
       dojo.byId("detalle.tasasIgvIpm").value = "";           
    }	

	    if (estadoCP == "00"){
         this.showHiddenDiv(document.getElementById("detalle.baseOperacGrav.show"),false);
         this.showHiddenDiv(document.getElementById("detalle.descBaseImponible.show"),false);
         this.showHiddenDiv(document.getElementById("detalle.IgvIpm.show"),false);
         this.showHiddenDiv(document.getElementById("detalle.descuentoIgvIpm.show"),false);
         dojo.byId("global.baseImpOperacGrav").value = ""; 
         dojo.byId("global.descBaseImponible").value = ""; 
         dojo.byId("global.tasaIgvoipm").value = "";
         
         dojo.byId("global.igvoipm").value = "";   
         dojo.byId("global.descuentoIgvoipm").value = "";   
         dojo.byId("detalle.baseImpOperacGrav").value = "";  
         dojo.byId("detalle.descBaseImponible").value = "";  
         dojo.byId("detalle.igvoipm").value = "";     
         dojo.byId("detalle.descuentoIgvoipm").value = "";
         dojo.byId("detalle.tasasIgvIpm").value = "";          
	    }
	    
	  var tieneVentasExoneradas = dojo.byId("global.opcVentasExoneradas").value;
    if (tieneVentasExoneradas==1 && estadoCP != "02" ){
        this.showHiddenDiv(document.getElementById("detalle.importeOperacExo.show"),true);
    }else{
       this.showHiddenDiv(document.getElementById("detalle.importeOperacExo.show"),false);
       dojo.byId("global.importeOperacionExonerada").value = "";  
       dojo.byId("detalle.importeOperacionExonerada").value = "";  
    } 
    
    if (estadoCP == "00"){
       this.showHiddenDiv(document.getElementById("detalle.importeOperacExo.show"),false);
       dojo.byId("global.importeOperacionExonerada").value = "";  
       dojo.byId("detalle.importeOperacionExonerada").value = "";      	    
    }
    
	  var tieneOperacInafectas = dojo.byId("global.opcVentasInafectas").value;
    if (tieneOperacInafectas==1 && estadoCP != "02"){
        this.showHiddenDiv(document.getElementById("detalle.importeOperacInaf.show"),true);
    }else{
       this.showHiddenDiv(document.getElementById("detalle.importeOperacInaf.show"),false);
       dojo.byId("global.importeOperacionInafecta").value = "";  
       dojo.byId("detalle.importeOperacionInafecta").value = "";  
    }

    if (estadoCP == "00"){
       this.showHiddenDiv(document.getElementById("detalle.importeOperacInaf.show"),false);
       dojo.byId("global.importeOperacionInafecta").value = "";  
       dojo.byId("detalle.importeOperacionInafecta").value = "";     
    }
    
    var tieneISC = dojo.byId("global.operacSujetasIsc").value;
    if (tieneISC==1 && estadoCP != "02"){
        this.showHiddenDiv(document.getElementById("detalle.Isc.show"),true);
    }else{
       this.showHiddenDiv(document.getElementById("detalle.Isc.show"),false);
       dojo.byId("detalle.isc").value = "";  
       dojo.byId("global.isc").value = "";  
    }  

    if (estadoCP == "00"){
       this.showHiddenDiv(document.getElementById("detalle.Isc.show"),false);
       dojo.byId("detalle.isc").value = "";  
       dojo.byId("global.isc").value = "";   
    }
            
    var tieneIvap = dojo.byId("global.operacSujetasIvap").value;
    //if (tieneIvap==1 && (dojo.byId("global.tipoCP").value == "49") && estadoCP != "02"){
    if (tieneIvap==1 && estadoCP != "02"){
       this.showHiddenDiv(document.getElementById("detalle.Ivap.show"),true);
    }else{
       this.showHiddenDiv(document.getElementById("detalle.Ivap.show"),false);
       dojo.byId("global.baseImponibleIvap").value = "";  
       dojo.byId("global.ivap").value = "";  
       dojo.byId("detalle.baseImponibleIvap").value = "";  
       dojo.byId("detalle.ivap").value = "";         
    }  
 
     if (estadoCP == "00"){
       this.showHiddenDiv(document.getElementById("detalle.Ivap.show"),false);
       dojo.byId("global.baseImponibleIvap").value = "";  
       dojo.byId("global.ivap").value = "";  
       dojo.byId("detalle.baseImponibleIvap").value = "";  
       dojo.byId("detalle.ivap").value = "";   
    }
        
    var tieneOtrosTribCargos = dojo.byId("global.operacOtrosTribCargos").value;
    if (tieneOtrosTribCargos==1  && estadoCP!= "02"){
       this.showHiddenDiv(document.getElementById("detalle.tribCargosNoBaseImp.show"),true);
    }else{
       this.showHiddenDiv(document.getElementById("detalle.tribCargosNoBaseImp.show"),false);
       dojo.byId("global.tributosCargosNoBaseImp").value = "";  
       dojo.byId("detalle.tributosCargosNoBaseImp").value = "";  
    }   

     if (estadoCP == "00"){
       this.showHiddenDiv(document.getElementById("detalle.tribCargosNoBaseImp.show"),false);
       dojo.byId("global.tributosCargosNoBaseImp").value = "";  
       dojo.byId("detalle.tributosCargosNoBaseImp").value = "";   
    }
    
     if (estadoCP == "02"){
         this.showHiddenDiv(document.getElementById("detalle.importeTotalCP.show"),false);
         dojo.byId("global.importeTotalCP").value = "";  
         dojo.byId("detalle.importeTotalCP").value = "";  
     }else{
        this.showHiddenDiv(document.getElementById("detalle.importeTotalCP.show"),true);
     }   
     
     var tieneVtasGratuitas = dojo.byId("global.opcVentasGratuitas").value;
      if (tieneVtasGratuitas==1 && estadoCP!= "02"){
          this.showHiddenDiv(document.getElementById("detalle.operacionesGratuitas.show"),true);
      }else{
         this.showHiddenDiv(document.getElementById("detalle.operacionesGratuitas.show"),false);
         dojo.byId("global.grabadoPremio").value = "";  
         dojo.byId("global.grabadoDonacion").value = "";  
         dojo.byId("global.grabadoEntregaTrabajadores").value = "";  
         dojo.byId("global.grabadoPublicidad").value = "";  
         dojo.byId("global.grabadoBonificacion").value = "";  
         dojo.byId("global.grabadoRetiroOtros").value = "";  
         dojo.byId("global.valorFacturaExportaNoOnerosa").value = "";  
         dojo.byId("global.importeOperacionNoOnerosaExo").value = "";  
         dojo.byId("global.inafectoPremio").value = "";  
         dojo.byId("global.inafectoPublicidad").value = "";  
         dojo.byId("global.inafectoBonificacion").value = "";  
         dojo.byId("global.inafectoRetiroConvenioColectivo").value = "";  
         dojo.byId("global.inafectoMuestrasMedicas").value = "";  
         dojo.byId("global.inafectoRetiroOtros").value = "";  
      }      
     if (estadoCP == "00"){
         this.showHiddenDiv(document.getElementById("detalle.operacionesGratuitas.show"),false);
         dojo.byId("global.grabadoPremio").value = "";  
         dojo.byId("global.grabadoDonacion").value = "";  
         dojo.byId("global.grabadoEntregaTrabajadores").value = "";  
         dojo.byId("global.grabadoPublicidad").value = "";  
         dojo.byId("global.grabadoBonificacion").value = "";  
         dojo.byId("global.grabadoRetiroOtros").value = "";  
         dojo.byId("global.valorFacturaExportaNoOnerosa").value = "";  
         dojo.byId("global.importeOperacionNoOnerosaExo").value = "";  
         dojo.byId("global.inafectoPremio").value = "";  
         dojo.byId("global.inafectoPublicidad").value = "";  
         dojo.byId("global.inafectoBonificacion").value = "";  
         dojo.byId("global.inafectoRetiroConvenioColectivo").value = "";  
         dojo.byId("global.inafectoMuestrasMedicas").value = "";  
         dojo.byId("global.inafectoRetiroOtros").value = "";    
    }

    
    this.cargarDatosIngresadosDetalle();
	},
	
		mostrarDatosPreliminar: function() {
    //Seteamos pantalla
	  var estadoCP = dojo.byId("global.estadoCP").value;
	  
	  //var anotadosRegAnterior = dojo.byId("global.opcAnotadosRegistroAnterior").value;
	  var anotadosRegAnterior =  0; //dojo.byId("global.opcAnotadosRegistroAnterior").value;
	   dojo.byId("preliminar.periodoRegistroVentas").value  = dojo.byId("global.periodoComprobantesFormat").value;
	  if ( estadoCP =="09"){
	       anotadosRegAnterior=1;
    }	  
    if (anotadosRegAnterior==1 || estadoCP =="08"){
       this.showHiddenDiv(document.getElementById("preliminar.periodoCorrespondeAjuste.show"),true);
    }else{
       this.showHiddenDiv(document.getElementById("preliminar.periodoCorrespondeAjuste.show"),false);
    }

    if (estadoCP !="02"){
          this.showHiddenDiv(document.getElementById("preliminar.fechaEmisionCP.show"),true);
    }else{
       this.showHiddenDiv(document.getElementById("preliminar.fechaEmisionCP.show"),false);
    }
    
    //var tieneFecVenc = dojo.byId("global.fechaVencimPago").value;
    var tieneFecVenc = 0
		if (tipoCP =="14"){
		 tieneFecVenc = 1;
    }    
    /*if (tieneFecVenc==1 && estadoCP!="02" ){
       this.showHiddenDiv(document.getElementById("preliminar.fechaVencimPago.show"),true);
    }else{
       this.showHiddenDiv(document.getElementById("preliminar.fechaVencimPago.show"),false);
    }*/
    if (estadoCP!="02" ){
       this.showHiddenDiv(document.getElementById("preliminar.fechaVencimPago.show"),true);
    }else{
    
      this.showHiddenDiv(document.getElementById("preliminar.fechaVencimPago.show"),false);
    }
	
	  var tieneNrosRango = dojo.byId("global.capturarCpXRangos").value;
	  var tipoCP = dojo.byId("global.tipoCP").value;
	  
    //if (tieneNrosRango==1 && ( tipoCP =="03" ||  tipoCP =="12" || tipoCP =="15" ||  tipoCP =="19" ) ){  //Se cambio para ple5
    if (tieneNrosRango==1 && ( tipoCP =="03" ||  tipoCP =="12" || tipoCP =="00" ||  tipoCP =="13" || tipoCP =="87") ){
       this.showHiddenDiv(document.getElementById("preliminar.nrosRangoCP.show"),true);
       this.showHiddenDiv(document.getElementById("preliminar.numeroCP.show"),false);
       
    }else{
       this.showHiddenDiv(document.getElementById("preliminar.numeroCP.show"),true);
       this.showHiddenDiv(document.getElementById("preliminar.nrosRangoCP.show"),false);
    }	
	  
	  /*
	  var tieneEmisionMaqReg = dojo.byId("global.emisionMaquinaRegis").value;
    if (tieneEmisionMaqReg==1 && tipoCP =="12"  ){ //estadoCP!="02" 
       this.showHiddenDiv(document.getElementById("preliminar.nroSerieRegistradora.show"),true);
    }else{
       this.showHiddenDiv(document.getElementById("preliminar.nroSerieRegistradora.show"),false);
    }
    */
    var tipoMoneda = dojo.byId("global.tipoMoneda").value;
	  var tieneNoNuevoSol = dojo.byId("global.opcMonedaNoNuevoSol").value;
    if (tieneNoNuevoSol==1){
       if (estadoCP == "02"){
         this.showHiddenDiv(document.getElementById("preliminar.tipoMoneda.show"),false);
         //this.showHiddenDiv(document.getElementById("preliminar.tipoCambio.show"),false);       
       }else{
         this.showHiddenDiv(document.getElementById("preliminar.tipoMoneda.show"),true);
         
         /*if (tipoMoneda != "USD" && tipoMoneda != "CAD" && tipoMoneda != "GBP" && tipoMoneda != "JPY" && tipoMoneda != "SEK" && tipoMoneda != "CHF" && tipoMoneda != "EUR"){
            this.showHiddenDiv(document.getElementById("preliminar.tipoCambio.show"),true);
         }else{
            this.showHiddenDiv(document.getElementById("preliminar.tipoCambio.show"),false);
         }*/
       }
    }else{
       this.showHiddenDiv(document.getElementById("preliminar.tipoMoneda.show"),false);
       //this.showHiddenDiv(document.getElementById("preliminar.tipoCambio.show"),false);
    }
      
	  var tieneVentasGrabadas = dojo.byId("global.opcVentasGrabadas").value;
    if (tieneVentasGrabadas==1 && (estadoCP !="02" && estadoCP !="00" )){
       this.showHiddenDiv(document.getElementById("preliminar.baseOperacGrav.show"),true);
       this.showHiddenDiv(document.getElementById("preliminar.descBaseImponible.show"),true);
       this.showHiddenDiv(document.getElementById("preliminar.IgvIpm.show"),true);
       this.showHiddenDiv(document.getElementById("preliminar.descuentoIgvIpm.show"),true);
    }else{
       this.showHiddenDiv(document.getElementById("preliminar.baseOperacGrav.show"),false);
       this.showHiddenDiv(document.getElementById("preliminar.descBaseImponible.show"),false);       
       this.showHiddenDiv(document.getElementById("preliminar.IgvIpm.show"),false);
       this.showHiddenDiv(document.getElementById("preliminar.descuentoIgvIpm.show"),false);
       dojo.byId("global.baseImpOperacGrav").value = "";  
       dojo.byId("global.descBaseImponible").value = ""; 
       
       dojo.byId("global.tasaIgvoipm").value = "";
       dojo.byId("global.igvoipm").value = "";  
       dojo.byId("global.descuentoIgvoipm").value = "";  
       
       dojo.byId("preliminar.baseImpOperacGrav").value = ""; 
       dojo.byId("preliminar.descBaseImponible").value = "";  
       dojo.byId("preliminar.igvoipm").value = "";   
       dojo.byId("global.descBaseImponible").value = ""; 
       dojo.byId("preliminar.descuentoIgvoipm").value = ""; 
       dojo.byId("preliminar.tasasIgvIpm").value = "";     
    }	
      
	  var tieneVentasExoneradas = dojo.byId("global.opcVentasExoneradas").value;
    if (tieneVentasExoneradas==1  && (estadoCP !="02" && estadoCP !="00" )){
       this.showHiddenDiv(document.getElementById("preliminar.importeOperacExo.show"),true);
    }else{
       this.showHiddenDiv(document.getElementById("preliminar.importeOperacExo.show"),false);
    } 
    
	  var tieneOperacInafectas = dojo.byId("global.opcVentasInafectas").value;
    if (tieneOperacInafectas==1 && (estadoCP !="02" && estadoCP !="00" )){
       this.showHiddenDiv(document.getElementById("preliminar.importeOperacInaf.show"),true);
    }else{
       this.showHiddenDiv(document.getElementById("preliminar.importeOperacInaf.show"),false);
    }
    
	  var tieneISC = dojo.byId("global.operacSujetasIsc").value;
    if (tieneISC==1  && (estadoCP !="02" && estadoCP !="00" )){
       this.showHiddenDiv(document.getElementById("preliminar.Isc.show"),true);
    }else{
       this.showHiddenDiv(document.getElementById("preliminar.Isc.show"),false);
    }     

  	var tieneIvap = dojo.byId("global.operacSujetasIvap").value;
    if (tieneIvap==1  && (estadoCP !="02" && estadoCP !="00")){
       this.showHiddenDiv(document.getElementById("preliminar.Ivap.show"),true);
    }else{
       this.showHiddenDiv(document.getElementById("preliminar.Ivap.show"),false);
    }  
      
    var tieneOtrosTribCargos = dojo.byId("global.operacOtrosTribCargos").value;
    if (tieneOtrosTribCargos==1  && (estadoCP !="02" && estadoCP !="00" )){
       this.showHiddenDiv(document.getElementById("preliminar.tribCargosNoBaseImp.show"),true);
    }else{
       this.showHiddenDiv(document.getElementById("preliminar.tribCargosNoBaseImp.show"),false);
    }    

    var tieneExportacion = dojo.byId("global.opcExportacion").value;
    if (tieneExportacion==1 && (estadoCP !="02" && estadoCP !="00" )){
       this.showHiddenDiv(document.getElementById("preliminar.valorFacturadoExportacion.show"),true);
    }else{
       this.showHiddenDiv(document.getElementById("preliminar.valorFacturadoExportacion.show"),false);
       dojo.byId("global.valorFacturadoExportacion").value = "";  
       // dojo.byId("global.valorEmbarcadoExportacion").value = "";  
    }
    
     if (estadoCP == "02"){
         this.showHiddenDiv(document.getElementById("preliminar.importeTotalCP.show"),false);
     }else{
        this.showHiddenDiv(document.getElementById("preliminar.importeTotalCP.show"),true);
     }       
       
     var tieneVtasGratuitas = dojo.byId("global.opcVentasGratuitas").value;
      if (tieneVtasGratuitas==1 && (estadoCP !="02" && estadoCP !="00" )){
            this.showHiddenDiv(document.getElementById("preliminar.operacionesGratuitas.show"),true);
      }else{
         this.showHiddenDiv(document.getElementById("preliminar.operacionesGratuitas.show"),false);
      }                   
    var modificaCPOriginal = 0; //    dojo.byId("global.cpModifCpOriginal").value;
    if (tipoCP =="07" || tipoCP == "08" || tipoCP =="87" || tipoCP == "88"){
        modificaCPOriginal=1; 
    }
    
    if (modificaCPOriginal==1 && (estadoCP !="02" && estadoCP !="00" )){
       this.showHiddenDiv(document.getElementById("preliminar.CPQueModifica.show"),true);
    }else{
       this.showHiddenDiv(document.getElementById("preliminar.CPQueModifica.show"),false);
    }    
   
    this.cargarDatosIngresadosPreliminar();
  },
  
  cargarDatosIngresadosPreliminar: function() {
	    	    
    //Cargar datos ingresados

    if (dojo.byId("global.tipoCP").value !=""){
        dijit.byId("preliminar.tipoCP").setValue(dojo.byId("global.tipoCP").value + " - " + dojo.byId("global.tipoCPDescripcion").value );
    }
		dijit.byId("preliminar.estadoCP").setValue(dojo.byId("global.estadoCP").value);
		dijit.byId("preliminar.periodoAjuste").setValue(dojo.byId("global.periodoAjuste").value.substring(4,6) + "/"+  dojo.byId("global.periodoAjuste").value.substring(0,4));
		dijit.byId("preliminar.cuo").setValue(dojo.byId("global.cuo").value);
		if (dojo.byId("global.tipoDocRecepCP").value != "" && dojo.byId("global.tipoDocRecepCP").value != "-"){
		    dijit.byId("preliminar.tipoDocRecepCP").setValue(dojo.byId("global.tipoDocRecepCP").value + " - " + dojo.byId("global.tipoDocRecepCPDescripcion").value);
    }else{
        dijit.byId("preliminar.tipoDocRecepCP").setValue("- - SIN DOCUMENTO" );
    }
    dijit.byId("preliminar.numeroDocRecepCP").setValue(dojo.byId("global.numeroDocRecepCP").value);
    dijit.byId("preliminar.razonSocialRecepCP").setValue(dojo.byId("global.razonSocialRecepCP").value);
    dijit.byId("preliminar.fechaEmisionCP").setValue(new Date(dojo.byId("global.fechaEmisionCP").value));
    if (dojo.byId("global.fechaVencimientoPago").value != "") {dijit.byId("preliminar.fechaVencimientoPago").setValue(new Date(dojo.byId("global.fechaVencimientoPago").value));}
        
    dijit.byId("preliminar.numeroSerieCP").setValue(dojo.byId("global.numeroSerieCP").value);
    if (dojo.byId("global.numeroCP").value != "") {dijit.byId("preliminar.numeroCP").setValue(dojo.byId("global.numeroCP").value );}
    if (dojo.byId("global.numeroCorrelativo").value != "") {dijit.byId("preliminar.numeroCorrelativo").setValue(dojo.byId("global.numeroCorrelativo").value );}
    //dijit.byId("preliminar.numeroSerieMaqRegistra").setValue(dojo.byId("global.numeroSerieMaqRegistra").value);    
    if (dojo.byId("global.numeroInicialCP").value != "") {dijit.byId("preliminar.numeroInicialCP").setValue(dojo.byId("global.numeroInicialCP").value);}
    if (dojo.byId("global.numeroFinalCP").value != "") {dijit.byId("preliminar.numeroFinalCP").setValue(dojo.byId("global.numeroFinalCP").value);}
		if (dojo.byId("global.tipoMoneda").value != ""){
		    //dijit.byId("preliminar.tipoMoneda").setValue(dojo.byId("global.tipoMoneda").value + " - " + dojo.byId("global.tipoMonedaDescripcion").value);
		    dijit.byId("preliminar.tipoMoneda").setValue(dojo.byId("global.tipoMoneda").value);
    }

    dijit.byId("preliminar.tc").setValue(dojo.number.format(dojo.byId("global.tc").value,{places:3} ));
    dijit.byId("preliminar.valorFacturadoExportacion").setValue(dojo.number.format(dojo.byId("global.valorFacturadoExportacion").value,{places:2} ));
    //dijit.byId("preliminar.valorEmbarcadoExportacion").setValue(dojo.number.format(dojo.byId("global.valorEmbarcadoExportacion").value,{places:2} ));
		dijit.byId("preliminar.baseImpOperacGrav").setValue(dojo.number.format(dojo.byId("global.baseImpOperacGrav").value,{places:2} ));
		dijit.byId("preliminar.descBaseImponible").setValue(dojo.number.format(dojo.byId("global.descBaseImponible").value,{places:2} ));
		dijit.byId("preliminar.importeOperacionExonerada").setValue(dojo.number.format(dojo.byId("global.importeOperacionExonerada").value,{places:2} ));
    dijit.byId("preliminar.importeOperacionInafecta").setValue(dojo.number.format(dojo.byId("global.importeOperacionInafecta").value,{places:2} ));
    dijit.byId("preliminar.isc").setValue(dojo.number.format(dojo.byId("global.isc").value,{places:2} ));
    if (dojo.byId("global.tasaIgvoipm").value != ""){
		    dijit.byId("preliminar.tasasIgvIpm").setValue(dojo.byId("global.tasaIgvoipm").value);
    }
    dijit.byId("preliminar.igvoipm").setValue(dojo.number.format(dojo.byId("global.igvoipm").value,{places:2} ));
    dijit.byId("preliminar.descuentoIgvoipm").setValue(dojo.number.format(dojo.byId("global.descuentoIgvoipm").value,{places:2} ));
    dijit.byId("preliminar.baseImponibleIvap").setValue(dojo.number.format(dojo.byId("global.baseImponibleIvap").value,{places:2} ));
    dijit.byId("preliminar.ivap").setValue(dojo.number.format(dojo.byId("global.ivap").value,{places:2} ));
    dijit.byId("preliminar.tributosCargosNoBaseImp").setValue(dojo.number.format(dojo.byId("global.tributosCargosNoBaseImp").value,{places:2} ));
    
    dijit.byId("preliminar.importeTotalCP").setValue(dojo.number.format(dojo.byId("global.importeTotalCP").value,{places:2} ));
    dijit.byId("preliminar.contratoColaboracion").setValue(dojo.byId("global.contratoColaboracion").value); 

    if (dojo.byId("global.errorTipo1").value != ""  ) {
        if (dojo.byId("global.errorTipo1").value == "1") {
            dijit.byId("preliminar.tcDiferenteSunat1").setChecked("checked");
          }else{
            dijit.byId("preliminar.tcDiferenteSunat0").setChecked("checked");
          }
      
      }   
 
     if (dojo.byId("global.indicadorMedioPago").value != ""  ) {
        if (dojo.byId("global.indicadorMedioPago").value == "1") {
            dijit.byId("preliminar.medioDePago1").setChecked("checked");
          }else{
            dijit.byId("preliminar.medioDePago0").setChecked("checked");
          }
      
      }  
            
    dijit.byId("preliminar.grabadoPremio").setValue(dojo.number.format(dojo.byId("global.grabadoPremio").value,{places:2} ));
    dijit.byId("preliminar.grabadoDonacion").setValue(dojo.number.format(dojo.byId("global.grabadoDonacion").value,{places:2} ));
    dijit.byId("preliminar.grabadoEntregaTrabajadores").setValue(dojo.number.format(dojo.byId("global.grabadoEntregaTrabajadores").value,{places:2} ));
    dijit.byId("preliminar.grabadoPublicidad").setValue(dojo.number.format(dojo.byId("global.grabadoPublicidad").value,{places:2} ));
    dijit.byId("preliminar.grabadoBonificacion").setValue(dojo.number.format(dojo.byId("global.grabadoBonificacion").value,{places:2} ));
    dijit.byId("preliminar.grabadoRetiroOtros").setValue(dojo.number.format(dojo.byId("global.grabadoRetiroOtros").value,{places:2} ));
    dijit.byId("preliminar.valorFacturaExportaNoOnerosa").setValue(dojo.number.format(dojo.byId("global.valorFacturaExportaNoOnerosa").value,{places:2} ));
    dijit.byId("preliminar.importeOperacionNoOnerosaExo").setValue(dojo.number.format(dojo.byId("global.importeOperacionNoOnerosaExo").value,{places:2} ));
    dijit.byId("preliminar.inafectoPremio").setValue(dojo.number.format(dojo.byId("global.inafectoPremio").value,{places:2} ));
    dijit.byId("preliminar.inafectoPublicidad").setValue(dojo.number.format(dojo.byId("global.inafectoPublicidad").value,{places:2} ));
    dijit.byId("preliminar.inafectoBonificacion").setValue(dojo.number.format(dojo.byId("global.inafectoBonificacion").value,{places:2} ));
    dijit.byId("preliminar.inafectoRetiroConvenioColectivo").setValue(dojo.number.format(dojo.byId("global.inafectoRetiroConvenioColectivo").value,{places:2} ));
    dijit.byId("preliminar.inafectoMuestrasMedicas").setValue(dojo.number.format(dojo.byId("global.inafectoMuestrasMedicas").value,{places:2} ));
    dijit.byId("preliminar.inafectoRetiroOtros").setValue(dojo.number.format(dojo.byId("global.inafectoRetiroOtros").value,{places:2} ));
    if (dojo.byId("global.fechaEmisionCPModificado").value != "") {
        dijit.byId("preliminar.fechaEmisionCPModificado").setValue(new Date(dojo.byId("global.fechaEmisionCPModificado").value));
    }
    if (dojo.byId("global.tipoCPModificado").value != ""){
		    dijit.byId("preliminar.tipoCPModificado").setValue(dojo.byId("global.tipoCPModificado").value );
    }    
    dijit.byId("preliminar.numeroSerieCPModificado").setValue(dojo.byId("global.numeroSerieCPModificado").value);
    dijit.byId("preliminar.numeroCPModificado").setValue(dojo.byId("global.numeroCPModificado").value);
    
	},
  
	  showPreliminar: function() {
	  
	  	  //dijit.hideTooltip(dojo.byId("detalle.fechaTC"));
	      dijit.hideTooltip(dojo.byId("detalle.tc"));   
        dijit.hideTooltip(dojo.byId("detalle.baseImpOperacGrav"));
        dijit.hideTooltip(dojo.byId("detalle.igvoipm"));
        dijit.hideTooltip(dojo.byId("detalle.valorFacturadoExportacion"));
        //dijit.hideTooltip(dojo.byId("detalle.valorEmbarcadoExportacion"));
        dijit.hideTooltip(dojo.byId("detalle.importeOperacionExonerada"));
        dijit.hideTooltip(dojo.byId("detalle.importeOperacionInafecta"));
        dijit.hideTooltip(dojo.byId("detalle.tributosCargosNoBaseImp"));
        dijit.hideTooltip(dojo.byId("detalle.isc"));   
        dijit.hideTooltip(dojo.byId("detalle.baseImponibleIvap"));
        dijit.hideTooltip(dojo.byId("detalle.ivap"));
	      dijit.hideTooltip(dojo.byId("detalle.importeTotalCP"));
	      dijit.hideTooltip(dojo.byId("detalle.numeroCPModificado"));
	      dijit.hideTooltip(dojo.byId("detalle.numeroSerieCPModificado"));
        dijit.hideTooltip(dojo.byId("detalle.tipoMoneda"));
        dijit.hideTooltip(dojo.byId("detalle.tasasIgvIpm"));
        dijit.hideTooltip(dojo.byId("detalle.importeTotalCP"));      
        dijit.hideTooltip(dojo.byId("detalle.grabadoPremio"));
        dijit.hideTooltip(dojo.byId("detalle.grabadoDonacion"));
        dijit.hideTooltip(dojo.byId("detalle.grabadoEntregaTrabajadores")); 
        dijit.hideTooltip(dojo.byId("detalle.grabadoPublicidad"));
        dijit.hideTooltip(dojo.byId("detalle.grabadoBonificacion"));
        dijit.hideTooltip(dojo.byId("detalle.grabadoRetiroOtros")); 
        dijit.hideTooltip(dojo.byId("detalle.valorFacturaExportaNoOnerosa"));
        dijit.hideTooltip(dojo.byId("detalle.importeOperacionNoOnerosaExo"));
        dijit.hideTooltip(dojo.byId("detalle.inafectoPremio"));                 	      

        dijit.hideTooltip(dojo.byId("detalle.inafectoPublicidad")); 
        dijit.hideTooltip(dojo.byId("detalle.inafectoBonificacion"));
        dijit.hideTooltip(dojo.byId("detalle.inafectoRetiroConvenioColectivo"));
        dijit.hideTooltip(dojo.byId("detalle.inafectoMuestrasMedicas")); 

        dijit.hideTooltip(dojo.byId("detalle.inafectoRetiroOtros")); 


        if(!dijit.byId("detalle.form").validate()) return;
        
	      var estadoCP = dojo.byId("global.estadoCP").value;
	      var tieneNoNuevoSol = dojo.byId("global.opcMonedaNoNuevoSol").value;
        if (tieneNoNuevoSol==1 && (estadoCP !="02" && estadoCP !="00" )){
              var tipoMoneda =dijit.byId("detalle.tipoMoneda").getValue(); 
              if(tipoMoneda == "" || tipoMoneda == "-" || tipoMoneda == "XX1"){
                 this.iconTooltipMessage("detalle.tipoMoneda", "icon-ok-tooltip", "Debe seleccionar el tipo de Moneda.");
                 return;
              }           
              //if (tipoMoneda != "USD" && tipoMoneda != "CAD" && tipoMoneda != "GBP" && tipoMoneda != "JPY" && tipoMoneda != "SEK" && tipoMoneda != "CHF" && tipoMoneda != "EUR"){
                  /*var valor = dojo.byId("detalle.fechaTC").value;
                  if(valor == ""){
                     this.iconTooltipMessage("detalle.fechaTC", "icon-ok-tooltip", "Debe registrar la fecha del tipo de cambio.");
                     return;
                  }   
                  valor = dijit.byId("detalle.fechaTC").getValue();
                  var fechaHoy  = new Date();
                  var fechaTC  = new Date(valor); 

                  if (fechaTC > fechaHoy){
                      this.iconTooltipMessage("detalle.fechaTC", "icon-ok-tooltip", "Fecha de tipo de cambio inconsistente");
                      return;
                  } */  
                  var valor = dojo.byId("detalle.tc").value;
                  if(valor == ""){
                     this.iconTooltipMessage("detalle.tc", "icon-ok-tooltip", "Debe registrar tipo de cambio.");
                     return;
                  }
                  valor = dijit.byId("detalle.tc").getValue();
                  if(valor <= 0 ){
                     this.iconTooltipMessage("detalle.tc", "icon-ok-tooltip", "Tipo de cambio inconsistente, debe ser mayor a 0.");
                     return;
                  }
                  
                  if(valor > 99.994 ){
                     this.iconTooltipMessage("detalle.tc", "icon-ok-tooltip", "Tipo de cambio inconsistente, debe ser menor a 99.995.");
                     return;
                  }
                  /////////////////////////////
                  /*fechaTC = dojo.byId("detalle.fechaTC").value.substring(6,10) +  dojo.byId("detalle.fechaTC").value.substring(3,5)+  dojo.byId("detalle.fechaTC").value.substring(0,2) ;
                  if (estadoCP !="08" && estadoCP !="09"  ){
                      var emisionCP = dojo.byId("global.fechaEmisionCP").value.substring(6,10) +  dojo.byId("global.fechaEmisionCP").value.substring(0,2)+  "01"; 
                      if(fechaTC < emisionCP){
                         this.iconTooltipMessage("detalle.fechaTC", "icon-ok-tooltip", "Fecha de Tipo de cambio no puede ser menor al periodo de la fecha de emision del comprobante.");
                         return;
                      }             
                  }else{
                      var fecAjuste =dojo.byId("global.periodoAjuste").value + "01";
                      if(fechaTC < fecAjuste){
                         this.iconTooltipMessage("detalle.fechaTC", "icon-ok-tooltip", "Fecha de Tipo de cambio no puede ser menor al periodo de la fecha de emision del comprobante.");
                         return;
                      }   
                  } */                    
                  /////////////////////////////7777                  
             //}            
        }

        var montoTotalCP = dijit.byId("detalle.importeTotalCP").getValue();
    	  var tieneVentasGrabadas = dojo.byId("global.opcVentasGrabadas").value;
        if (tieneVentasGrabadas==1 && (estadoCP !="02" && estadoCP !="00" )){
            var valor = dojo.byId("detalle.baseImpOperacGrav").value;
            if(valor == ""){
               this.iconTooltipMessage("detalle.baseImpOperacGrav", "icon-ok-tooltip", "Debe registrar Base imponible de la operaci�n .");
               return;
            }

            valor = dijit.byId("detalle.baseImpOperacGrav").getValue();
            if (valor <= 0.00){
               this.iconTooltipMessage("detalle.baseImpOperacGrav", "icon-ok-tooltip", "Base imponible de la operaci�n es inconsistente.");
               return;            
            }              
            var tieneVtasGratuitas = dojo.byId("global.opcVentasGratuitasRec").value;
            if (tieneVtasGratuitas!=1 ){
                if (valor > montoTotalCP){
                   this.iconTooltipMessage("detalle.baseImpOperacGrav", "icon-ok-tooltip", "Base imponible de la operaci�n es inconsistente.");
                   return;            
                }
            }
            var tasaigv = dojo.byId("detalle.tasasIgvIpm").value;
            if(tasaigv ==""){
               this.iconTooltipMessage("detalle.tasasIgvIpm", "icon-ok-tooltip", "Debe seleccionar IGV.");
               return;             
            }            
            //
            valor = dojo.byId("detalle.igvoipm").value;
            if(valor == ""){
               this.iconTooltipMessage("detalle.igvoipm", "icon-ok-tooltip", "Debe registrar IGV y/o IPM .");
               return;
            }            
        }	

        var tipoCP = dojo.byId("global.tipoCP").value;
        var tieneExportacion = dojo.byId("global.opcExportacion").value;
        if (tieneExportacion==1 && (estadoCP !="02" && estadoCP !="00" )){
            var valor = dojo.byId("detalle.valorFacturadoExportacion").value;
            if(valor == ""){
               this.iconTooltipMessage("detalle.valorFacturadoExportacion", "icon-ok-tooltip", "Debe registrar  el valor facturado de la exportaci�n.");
               return;
            }
            //var valorEmb = dojo.byId("detalle.valorEmbarcadoExportacion").value;
            //if (valorEmb ==""){ valorEmb = 0;}    
            valor = dijit.byId("detalle.valorFacturadoExportacion").getValue();
            var tieneVtasGratuitas = dojo.byId("global.opcVentasGratuitasRec").value;
            if (tieneVtasGratuitas!=1 ){
                if (valor > montoTotalCP){
                   this.iconTooltipMessage("detalle.valorFacturadoExportacion", "icon-ok-tooltip", "Importe total del valor facturado de la exportaci�n es inconsistente.");
                   return;            
                }
                //if (valorEmb > montoTotalCP){
                //   this.iconTooltipMessage("detalle.valorEmbarcadoExportacion", "icon-ok-tooltip", "Importe total del valor embarcado de la exportaci�n es inconsistente.");
                //   return;            
                //}
            }            

        }
    	
    	  var tieneVentasExoneradas = dojo.byId("global.opcVentasExoneradas").value;
        if (tieneVentasExoneradas==1 && (estadoCP !="02" && estadoCP !="00" )){
            var valor = dojo.byId("detalle.importeOperacionExonerada").value;
            if(valor == ""){
               this.iconTooltipMessage("detalle.importeOperacionExonerada", "icon-ok-tooltip", "Debe registrar Importe total de la operaci�n exonerada .");
               return;
            }
            valor = dijit.byId("detalle.importeOperacionExonerada").getValue();
            var tieneVtasGratuitas = dojo.byId("global.opcVentasGratuitasRec").value;
            if (tieneVtasGratuitas!=1 ){
                if (valor > montoTotalCP){
                   this.iconTooltipMessage("detalle.importeOperacionExonerada", "icon-ok-tooltip", "Importe total de la operaci�n exonerada es inconsistente.");
                   return;         
                }
            }              

        } 
   
       	var tieneOperacInafectas = dojo.byId("global.opcVentasInafectas").value;
        if (tieneOperacInafectas==1 && (estadoCP !="02" && estadoCP !="00" )){
            var valor = dojo.byId("detalle.importeOperacionInafecta").value;
            if(valor == ""){
               this.iconTooltipMessage("detalle.importeOperacionInafecta", "icon-ok-tooltip", "Debe registrar Importe total de la operaci�n inafecta .");
               return;
            }
            valor = dijit.byId("detalle.importeOperacionInafecta").getValue();
            var tieneVtasGratuitas = dojo.byId("global.opcVentasGratuitasRec").value;
            if (tieneVtasGratuitas!=1 ){
                if (valor > montoTotalCP){
                   this.iconTooltipMessage("detalle.importeOperacionInafecta", "icon-ok-tooltip", "Importe total de la operaci�n inafecta es inconsistente.");
                   return;            
                }   
            }             
         
        }
   
    	  var tieneISC = dojo.byId("global.operacSujetasIsc").value;
        if (tieneISC==1 && (estadoCP !="02" && estadoCP !="00" )){
            var valor = dojo.byId("detalle.isc").value;
            if(valor == ""){
               this.iconTooltipMessage("detalle.isc", "icon-ok-tooltip", "Debe registrar Importe de ISC.");
               return;
            }
            valor = dijit.byId("detalle.isc").getValue();
            if (valor <= 0 ){
               this.iconTooltipMessage("detalle.isc", "icon-ok-tooltip", "ISC debe ser mayor a 0.");
               return;            
            }  
            var tieneVtasGratuitas = dojo.byId("global.opcVentasGratuitasRec").value;
            if (tieneVtasGratuitas!=1 ){
                if (valor > montoTotalCP){
                   this.iconTooltipMessage("detalle.isc", "icon-ok-tooltip", "ISC es inconsistente.");
                   return;            
                } 
            }             
                 
        }  
        
        if (tieneVentasGrabadas==1 && (estadoCP !="02" && estadoCP !="00" )){
            dijit.byId("detalle.igvoipm").constraints = {min:0,places:2};
            dijit.byId("detalle.baseImpOperacGrav").constraints = {min:0,places:2};
            var valor = dojo.byId("detalle.igvoipm").value;
            if(valor == ""){
               this.iconTooltipMessage("detalle.igvoipm", "icon-ok-tooltip", "Debe registrar IGV y/o IPM .");
               return;
            }   
            valor = dijit.byId("detalle.igvoipm").getValue();
           
            var tieneVtasGratuitas = dojo.byId("global.opcVentasGratuitasRec").value;
            if (tieneVtasGratuitas!=1 ){
                if (valor > montoTotalCP){
                   this.iconTooltipMessage("detalle.igvoipm", "icon-ok-tooltip", "IGV y/o IPM es inconsistente");
                   return;            
                }  
            }             
            var porcentaje = dojo.byId("detalle.tasasIgvIpm").value;
            var base = dojo.byId("detalle.baseImpOperacGrav").value;
            var total = 0;
             if (porcentaje != "" && base != ""){
                porcentaje = dijit.byId("detalle.tasasIgvIpm").getValue();
                base = dijit.byId("detalle.baseImpOperacGrav").getValue();
              var mtoISC = dojo.byId("detalle.isc").value;   
              if (mtoISC!=""){ 
                  mtoISC = dijit.byId("detalle.isc").getValue();
              }else{
                  mtoISC = 0;
              }
              
              total = porcentaje * (base + mtoISC);                
                //total = porcentaje * base;
                if (total > 0 ) { total = total / 100;}
                total = this.roundNumber(total,2);
             }   

             if (total != valor){
                //this.iconTooltipMessage("detalle.igvoipm", "icon-ok-tooltip", "Valor consignado no corresponde a la tasa de IGV y/o IPM seleccionada.");
                alert("Valor consignado no corresponde a la tasa de IGV y/o IPM seleccionada.");
             }      
             

        }	
        
         tipoCP = dojo.byId("global.tipoCP").value;
      	var tieneIvap = dojo.byId("global.operacSujetasIvap").value;
        //if (tieneIvap==1 && (dojo.byId("global.tipoCP").value == "49") && estadoCP!="02"){
        if (tieneIvap==1 && (estadoCP !="02" && estadoCP !="00" )){
            var valor = dojo.byId("detalle.baseImponibleIvap").value;
            if (tipoCP == "49") {
                if(valor == ""){
                   this.iconTooltipMessage("detalle.baseImponibleIvap", "icon-ok-tooltip", "Debe registrar Base imponible de la operaci�n gravada con el IVAP.");
                   return;
                }
                valor = dijit.byId("detalle.baseImponibleIvap").getValue();
                if (valor > montoTotalCP){
                   this.iconTooltipMessage("detalle.baseImponibleIvap", "icon-ok-tooltip", "Base imponible de la operaci�n gravada con el IVAP es inconsistente");
                   return;            
                }                      
                valor = dojo.byId("detalle.ivap").value;
                if(valor == ""){
                   this.iconTooltipMessage("detalle.ivap", "icon-ok-tooltip", "Debe registrar IVAP.");
                   return;
                }
                valor = dijit.byId("detalle.ivap").getValue();
    
                var tieneVtasGratuitas = dojo.byId("global.opcVentasGratuitasRec").value;
                if (tieneVtasGratuitas!=1 ){
                    if (valor > montoTotalCP){
                       this.iconTooltipMessage("detalle.ivap", "icon-ok-tooltip", "IVAP es inconsistente.");
                       return;            
                    }     
                }                            
            }else{
                var valor2 =  dojo.byId("detalle.ivap").value;
                if(valor != "" || valor2 != ""){
                    if(valor == ""){
                       this.iconTooltipMessage("detalle.baseImponibleIvap", "icon-ok-tooltip", "Debe registrar Base imponible de la operaci�n gravada con el IVAP.");
                       return;
                    }       
                    valor = dijit.byId("detalle.baseImponibleIvap").getValue();    

                    if (valor > montoTotalCP){
                       this.iconTooltipMessage("detalle.baseImponibleIvap", "icon-ok-tooltip", "Base imponible de la operaci�n gravada con el IVAP es inconsistente");
                       return;            
                    }                      
                    if(valor2 == ""){
                       this.iconTooltipMessage("detalle.ivap", "icon-ok-tooltip", "Debe registrar IVAP.");
                       return;
                    }
                    valor2 = dijit.byId("detalle.ivap").getValue();


                    var tieneVtasGratuitas = dojo.byId("global.opcVentasGratuitasRec").value;
                    if (tieneVtasGratuitas!=1 ){
                        if (valor2 > montoTotalCP){
                           this.iconTooltipMessage("detalle.ivap", "icon-ok-tooltip", "IVAP es inconsistente.");
                           return;            
                        }     
                    }                     
                }
            }
        }    

     
        
        
        var tieneOtrosTribCargos = dojo.byId("global.operacOtrosTribCargos").value;
        if (tieneOtrosTribCargos==1 && (estadoCP !="02" && estadoCP !="00" )){
            var valor = dojo.byId("detalle.tributosCargosNoBaseImp").value;
            if(valor == ""){
               this.iconTooltipMessage("detalle.tributosCargosNoBaseImp", "icon-ok-tooltip", "Debe registrar Otros tributos y cargos que no forman parte de la base imponible.");
               return;
            }
            valor = dijit.byId("detalle.tributosCargosNoBaseImp").getValue();

            var tieneVtasGratuitas = dojo.byId("global.opcVentasGratuitasRec").value;
            if (tieneVtasGratuitas!=1 ){
                if (valor > montoTotalCP){
                   this.iconTooltipMessage("detalle.tributosCargosNoBaseImp", "icon-ok-tooltip", "Otros tributos y cargos que no forman parte de la base imponible es inconsistente.");
                   return;            
                }  
            }                           
        } 

        var valorTotal = dojo.byId("detalle.importeTotalCP").value;
        if(valorTotal == "" && estadoCP!="02"){
           this.iconTooltipMessage("detalle.importeTotalCP", "icon-ok-tooltip", "Debe registrar Importe total del CP .");
           return;
        }
        if(valorTotal != "" && (estadoCP !="02" && estadoCP !="00" )){   
            var valorFactExporta = dojo.byId("detalle.valorFacturadoExportacion").value;
          //  var valorEmbExporta = dojo.byId("detalle.valorEmbarcadoExportacion").value;
          var baseImpOperacGrav = dojo.byId("detalle.baseImpOperacGrav").value;
          var importOperacExonerada= dojo.byId("detalle.importeOperacionExonerada").value;
          var importOperacInafecta = dojo.byId("detalle.importeOperacionInafecta").value;
          var mtoISC = dojo.byId("detalle.isc").value;                              
          var mtoIGV = dojo.byId("detalle.igvoipm").value;
          var baseImpIvap = dojo.byId("detalle.baseImponibleIvap").value;                              
          var mtoIvap = dojo.byId("detalle.ivap").value;
          var otroTributosNoFormanBaseImp = dojo.byId("detalle.tributosCargosNoBaseImp").value;                              
          if (valorFactExporta!=""){ 
              valorFactExporta = dijit.byId("detalle.valorFacturadoExportacion").getValue();}
          else {valorFactExporta = 0;}  
          //if (valorEmbExporta!=""){ 
          //    valorEmbExporta = dijit.byId("detalle.valorEmbarcadoExportacion").getValue();}
          //else {valorEmbExporta = 0;}             
          if (baseImpOperacGrav!=""){ 
              baseImpOperacGrav = dijit.byId("detalle.baseImpOperacGrav").getValue();}
          else {baseImpOperacGrav = 0;}  
          if (importOperacExonerada!=""){ 
              importOperacExonerada = dijit.byId("detalle.importeOperacionExonerada").getValue();}
          else {importOperacExonerada = 0;}  
          if (importOperacInafecta!=""){ 
              importOperacInafecta = dijit.byId("detalle.importeOperacionInafecta").getValue();}
          else {importOperacInafecta = 0;}  
          if (mtoISC!=""){ 
              mtoISC = dijit.byId("detalle.isc").getValue();}
          else {mtoISC = 0;} 
          if (mtoIGV!=""){ 
              mtoIGV = dijit.byId("detalle.igvoipm").getValue();}
          else {mtoIGV = 0;}  
          if (baseImpIvap!=""){ 
              baseImpIvap = dijit.byId("detalle.baseImponibleIvap").getValue();}
          else {baseImpIvap = 0;}  
          if (mtoIvap!=""){ 
              mtoIvap = dijit.byId("detalle.ivap").getValue();}
          else {mtoIvap = 0;}  
          if (otroTributosNoFormanBaseImp!=""){ 
              otroTributosNoFormanBaseImp = dijit.byId("detalle.tributosCargosNoBaseImp").getValue();}
          else {otroTributosNoFormanBaseImp = 0;}  
                                                    
          var total = 0;
          valorTotal = dijit.byId("detalle.importeTotalCP").getValue();
          valorTotal = dijit.byId("detalle.importeTotalCP").getValue();
          total =  valorFactExporta + baseImpOperacGrav+ importOperacExonerada+ importOperacInafecta+ mtoISC+    mtoIGV + baseImpIvap +   mtoIvap+otroTributosNoFormanBaseImp;
          if (tieneExportacion==1  || tieneVentasGrabadas==1 || tieneVentasExoneradas==1  || tieneOperacInafectas==1 || tieneISC==1 || tieneIvap==1  || tieneOtrosTribCargos==1 ){
              total = this.roundNumber(total,2);
             if (total != valorTotal){
                alert("Valor consignado en el importe total no corresponde a la suma de los montos registrados.");
             }   
          }
        }
         
        if ( (tipoCP =="03" || tipoCP =="12") && valorTotal > 700){
        
              var tipoDoc = dojo.byId("global.tipoDocRecepCP").value;
               var tieneNrosRango = dojo.byId("global.capturarCpXRangos").value;
              if (tieneExportacion==1 || estadoCP=="02" || tieneNrosRango==1 ){
              }else{        
                   if (tipoDoc=="-" ) { 
                        alert("Debe seleccionar el tipo de documento del cliente.");
                        return;
                    } 
                     var numeroDoc = dojo.byId("global.numeroDocRecepCP").value;
                      if (numeroDoc=="" ) { 
                          alert("Debe registrar el numero de documento del cliente.")
                          return;
                      }  
                      var lenDoc = numeroDoc.length;  
                      if  (tipoDoc =="1") { 
                             if (lenDoc != 8){
                                alert("Numero de documento del cliente inv�lido")
                                return;
                             }
                             if (dojo.byId("global.razonSocialRecepCP").value==""){
                                alert("Debe registrar nombre del cliente.")
                                return;                  
                             }  
                       }    
                      if  (tipoDoc =="6") {            
                             if (lenDoc != 11){
                                alert("Numero de documento del cliente inv�lido")
                                return;
                             }
                             if (dojo.byId("global.razonSocialRecepCP").value==""){
                                alert("Numero de RUC del cliente no existe.")
                                return;                  
                             }
                      }      
                      if  (tipoDoc =="0" || tipoDoc =="4" || tipoDoc =="7" || tipoDoc =="A" ) {            
                             if (dojo.byId("global.razonSocialRecepCP").value==""){
                                alert("Nombre o Razon Social del cliente es inconsistente.")
                                return;                  
                             }
                      }      
              }        
        }
        var tieneVtasGratuitas = dojo.byId("global.opcVentasGratuitas").value;
        if (tieneVtasGratuitas==1 && (estadoCP !="02" && estadoCP !="00" )){
            var bTodoBlanco = true;
            var bMayor0 = false;
            var valor = dojo.byId("detalle.grabadoPremio").value;
            var monto = dijit.byId("detalle.grabadoPremio").getValue();
            if(valor != ""){
                bTodoBlanco = false;
                if (monto > 0){ bMayor0 = true;}

            }
            valor = dojo.byId("detalle.grabadoDonacion").value;
            monto = dijit.byId("detalle.grabadoDonacion").getValue();
            if(valor != ""){
                bTodoBlanco = false;
                if (monto > 0){ bMayor0 = true;}

            }       
            valor = dojo.byId("detalle.grabadoEntregaTrabajadores").value;
            monto = dijit.byId("detalle.grabadoEntregaTrabajadores").getValue();
            if(valor != ""){
                bTodoBlanco = false;
                if (monto > 0){ bMayor0 = true;}

            }                  
            valor = dojo.byId("detalle.grabadoPublicidad").value;
            monto = dijit.byId("detalle.grabadoPublicidad").getValue();
            if(valor != ""){
                bTodoBlanco = false;
                if (monto > 0){ bMayor0 = true;}

            }  
            valor = dojo.byId("detalle.grabadoBonificacion").value;
            monto = dijit.byId("detalle.grabadoBonificacion").getValue();
            if(valor != ""){
                bTodoBlanco = false;
                if (monto > 0){ bMayor0 = true;}

            }       
            valor = dojo.byId("detalle.grabadoRetiroOtros").value;
            monto = dijit.byId("detalle.grabadoRetiroOtros").getValue();
            if(valor != ""){
                bTodoBlanco = false;
                if (monto > 0){ bMayor0 = true;}

            }  
            valor = dojo.byId("detalle.valorFacturaExportaNoOnerosa").value;
            monto = dijit.byId("detalle.valorFacturaExportaNoOnerosa").getValue();
            if(valor != ""){
                bTodoBlanco = false;
                if (monto > 0){ bMayor0 = true;}

            }                    
            valor = dojo.byId("detalle.importeOperacionNoOnerosaExo").value;
            monto = dijit.byId("detalle.importeOperacionNoOnerosaExo").getValue();
            if(valor != ""){
                bTodoBlanco = false;
                if (monto > 0){ bMayor0 = true;}

            } 
            valor = dojo.byId("detalle.inafectoPremio").value;
            monto = dijit.byId("detalle.inafectoPremio").getValue();
            if(valor != ""){
                bTodoBlanco = false;
                if (monto > 0){ bMayor0 = true;}

            } 
            valor = dojo.byId("detalle.inafectoPublicidad").value;
            monto = dijit.byId("detalle.inafectoPublicidad").getValue();
            if(valor != ""){
                bTodoBlanco = false;
                if (monto > 0){ bMayor0 = true;}

            }                         
            valor = dojo.byId("detalle.inafectoBonificacion").value;
            monto = dijit.byId("detalle.inafectoBonificacion").getValue();
            if(valor != ""){
                bTodoBlanco = false;
                if (monto > 0){ bMayor0 = true;}

            }   
            valor = dojo.byId("detalle.inafectoRetiroConvenioColectivo").value;
            monto = dijit.byId("detalle.inafectoRetiroConvenioColectivo").getValue();
            if(valor != ""){
                bTodoBlanco = false;
                if (monto > 0){ bMayor0 = true;}

            }   
            valor = dojo.byId("detalle.inafectoMuestrasMedicas").value;
            monto = dijit.byId("detalle.inafectoMuestrasMedicas").getValue();
            if(valor != ""){
                bTodoBlanco = false;
                if (monto > 0){ bMayor0 = true;}

            }                           
            valor = dojo.byId("detalle.inafectoRetiroOtros").value;
            monto = dijit.byId("detalle.inafectoRetiroOtros").getValue();
            if(valor != ""){
                bTodoBlanco = false;
                if (monto > 0){ bMayor0 = true;}

            }  
            if (bTodoBlanco){
                this.iconTooltipMessage("detalle.grabadoPremio", "icon-ok-tooltip", "Si seleccion� Ventas Gratuitas, debe registrar por lo menos unos de los montos.");
               return;
            }  
            if (!bMayor0){
                this.iconTooltipMessage("detalle.grabadoPremio", "icon-ok-tooltip", "Si seleccion� Ventas Gratuitas, por lo menos uno de los montos debe ser mayor a 0.");
               return;
            }                                                                    
        }   
                      

        this.guardarDatosDetalle();
        dojo.byId("global.esRetrocesoDetalle").value = "0";
        
        //Mostramos pantalla Preliminar
  					this.content.setHref(this.controller + "?action=showPreliminar&preventCache=" + this.preventCache());
  					this.content.onLoad = dojo.hitch(this, function(){
  					   this.mostrarDatosPreliminar();});
        
    },
    
    backDatosDetalleoGeneral: function() {
       var estadoCP = dojo.byId("global.estadoCP").value;
       if (estadoCP == "02"){
          this.backDatosGenerales();
       }else{
          this.backDatosDetalle();
       }
    },
    
    calcularIgvIpm: function() {
       var porcentaje = dijit.byId("detalle.tasasIgvIpm").value;
       var valor = dijit.byId("detalle.baseImpOperacGrav").value;
       var total = 0;
       if (porcentaje != "" && valor != ""){
              var mtoISC = dojo.byId("detalle.isc").value;   
              if (mtoISC!=""){ 
                  mtoISC = dijit.byId("detalle.isc").getValue();
              }else{
                  mtoISC = 0;
              }
              
              total = porcentaje * (valor + mtoISC);       
          //total = porcentaje * valor;
          if (total > 0 ) { total = total / 100;}
          dijit.byId("detalle.igvoipm").setValue(total);
          dijit.byId("detalle.igvoipm").constraints = {min:0,places:2};
       }else{
          return;
       }
       
    },

          calcularMontoTotalCP_CambioIGV: function() {
          var valorFactExporta = dojo.byId("detalle.valorFacturadoExportacion").value;
          //var valorEmbExporta = dojo.byId("detalle.valorEmbarcadoExportacion").value;
          var baseImpOperacGrav = dojo.byId("detalle.baseImpOperacGrav").value;
          var importOperacExonerada= dojo.byId("detalle.importeOperacionExonerada").value;
          var importOperacInafecta = dojo.byId("detalle.importeOperacionInafecta").value;
          var mtoISC = dojo.byId("detalle.isc").value;                              
          var mtoIGV = dojo.byId("detalle.igvoipm").value;
          var baseImpIvap = dojo.byId("detalle.baseImponibleIvap").value;                              
          var mtoIvap = dojo.byId("detalle.ivap").value;
          var otroTributosNoFormanBaseImp = dojo.byId("detalle.tributosCargosNoBaseImp").value;   
                      
          if (valorFactExporta!=""){ 
              valorFactExporta = dijit.byId("detalle.valorFacturadoExportacion").getValue();}
          else {valorFactExporta = 0;}  
          //if (valorEmbExporta!=""){ 
          //    valorEmbExporta = dijit.byId("detalle.valorEmbarcadoExportacion").getValue();}
          //else {valorEmbExporta = 0;}            
          if (baseImpOperacGrav!=""){ 
              baseImpOperacGrav = dijit.byId("detalle.baseImpOperacGrav").getValue();}
          else {baseImpOperacGrav = 0;}  
          if (importOperacExonerada!=""){ 
              importOperacExonerada = dijit.byId("detalle.importeOperacionExonerada").getValue();}
          else {importOperacExonerada = 0;}  
          if (importOperacInafecta!=""){ 
              importOperacInafecta = dijit.byId("detalle.importeOperacionInafecta").getValue();}
          else {importOperacInafecta = 0;}  
          if (mtoISC!=""){ 
              mtoISC = dijit.byId("detalle.isc").getValue();}
          else {mtoISC = 0;} 
          if (mtoIGV!=""){ 
              mtoIGV = dijit.byId("detalle.igvoipm").getValue();}
          else {mtoIGV = 0;}  
          if (baseImpIvap!=""){ 
              baseImpIvap = dijit.byId("detalle.baseImponibleIvap").getValue();}
          else {baseImpIvap = 0;}  
          if (mtoIvap!=""){ 
              mtoIvap = dijit.byId("detalle.ivap").getValue();}
          else {mtoIvap = 0;}  
          if (otroTributosNoFormanBaseImp!=""){ 
              otroTributosNoFormanBaseImp = dijit.byId("detalle.tributosCargosNoBaseImp").getValue();}
          else {otroTributosNoFormanBaseImp = 0;}  
                                                    
          var total = 0;
          total =  valorFactExporta + baseImpOperacGrav+ importOperacExonerada+ importOperacInafecta+ mtoISC+    mtoIGV + baseImpIvap +   mtoIvap+otroTributosNoFormanBaseImp;
          dijit.byId("detalle.importeTotalCP").setValue(total);
          dijit.byId("detalle.importeTotalCP").constraints = {min:0,places:2}; 
       
    },

      calcularMontoTotalCP: function() {
          var valorFactExporta = dojo.byId("detalle.valorFacturadoExportacion").value;
          //var valorEmbExporta = dojo.byId("detalle.valorEmbarcadoExportacion").value;
          var baseImpOperacGrav = dojo.byId("detalle.baseImpOperacGrav").value;
          var importOperacExonerada= dojo.byId("detalle.importeOperacionExonerada").value;
          var importOperacInafecta = dojo.byId("detalle.importeOperacionInafecta").value;
          var mtoISC = dojo.byId("detalle.isc").value;                              
          var mtoIGV = dojo.byId("detalle.igvoipm").value;
          var baseImpIvap = dojo.byId("detalle.baseImponibleIvap").value;                              
          var mtoIvap = dojo.byId("detalle.ivap").value;
          var otroTributosNoFormanBaseImp = dojo.byId("detalle.tributosCargosNoBaseImp").value;   
          this.calcularIgvIpm();                           
          if (valorFactExporta!=""){ 
              valorFactExporta = dijit.byId("detalle.valorFacturadoExportacion").getValue();}
          else {valorFactExporta = 0;}  
          //if (valorEmbExporta!=""){ 
          //    valorEmbExporta = dijit.byId("detalle.valorEmbarcadoExportacion").getValue();}
          //else {valorEmbExporta = 0;}            
          if (baseImpOperacGrav!=""){ 
              baseImpOperacGrav = dijit.byId("detalle.baseImpOperacGrav").getValue();}
          else {baseImpOperacGrav = 0;}  
          if (importOperacExonerada!=""){ 
              importOperacExonerada = dijit.byId("detalle.importeOperacionExonerada").getValue();}
          else {importOperacExonerada = 0;}  
          if (importOperacInafecta!=""){ 
              importOperacInafecta = dijit.byId("detalle.importeOperacionInafecta").getValue();}
          else {importOperacInafecta = 0;}  
          if (mtoISC!=""){ 
              mtoISC = dijit.byId("detalle.isc").getValue();}
          else {mtoISC = 0;} 
          if (mtoIGV!=""){ 
              mtoIGV = dijit.byId("detalle.igvoipm").getValue();}
          else {mtoIGV = 0;}  
          if (baseImpIvap!=""){ 
              baseImpIvap = dijit.byId("detalle.baseImponibleIvap").getValue();}
          else {baseImpIvap = 0;}  
          if (mtoIvap!=""){ 
              mtoIvap = dijit.byId("detalle.ivap").getValue();}
          else {mtoIvap = 0;}  
          if (otroTributosNoFormanBaseImp!=""){ 
              otroTributosNoFormanBaseImp = dijit.byId("detalle.tributosCargosNoBaseImp").getValue();}
          else {otroTributosNoFormanBaseImp = 0;}  
                                                    
          var total = 0;
          total =  valorFactExporta + baseImpOperacGrav+ importOperacExonerada+ importOperacInafecta+ mtoISC+    mtoIGV + baseImpIvap +   mtoIvap+otroTributosNoFormanBaseImp;
          dijit.byId("detalle.importeTotalCP").setValue(total);
          dijit.byId("detalle.importeTotalCP").constraints = {min:0,places:2}; 
       
    },
    
		cargarValoresGlobales: function() {
    dojo.byId("global.periodoComprobantes").value = dijit.byId("inicio.periodoRegistroVentas" ).getValue().substring(3,7) + dijit.byId("inicio.periodoRegistroVentas" ).getValue().substring(0,2);
    //alert(dijit.byId("inicio.periodoRegistroVentas" ).getValue().substring(3,7) + dijit.byId("inicio.periodoRegistroVentas" ).getValue().substring(0,2));
    dojo.byId("global.periodoComprobantesFormat").value =  dijit.byId("inicio.periodoRegistroVentas").getValue();    
		dojo.byId("global.opcExportacion").value = this.getValorOpcionExportacion();
    dojo.byId("global.opcMonedaNoNuevoSol").value = this.getValorOpcionNoNuevoSol();
    dojo.byId("global.opcVentasGrabadas").value = this.getValorOpcionVentasGrabadas();
    dojo.byId("global.opcVentasExoneradas").value = this.getValorOpcionVentasExoneradas();
    dojo.byId("global.opcVentasInafectas").value = this.getValorOpcionVentasInafectas();
    dojo.byId("global.opcVentasGratuitas").value = 0;
    dojo.byId("global.opcVentasGratuitasRec").value = this.getValorOpcionVentasGratuitas();
    dojo.byId("global.operacSujetasIsc").value = this.getValorOpcionOperacSujetasISC();
    dojo.byId("global.operacSujetasIvap").value = this.getValorOpcionOperacSujetasIvap();
    dojo.byId("global.operacOtrosTribCargos").value = this.getValorOpcionOperacOtrosTribCargos();
    //dojo.byId("global.fechaVencimPago").value = this.getValorOpcionFechaVencimPago();
    //dojo.byId("global.emisionMaquinaRegis").value = this.getValorOpcionEmisionMaquinaRegis();
    //dojo.byId("global.cpModifCpOriginal").value = this.getValorOpcionCPModisCPOriginal();
    //dojo.byId("global.capturarCpXRangos").value = this.getValorOpcionCapturarCPPorRangos();
    //dojo.byId("global.opcAnotadosRegistroAnterior").value = this.getValorOpcionAnotadosRegistroAnterior();
          	  
	},
	
	resetValoresGlobales: function() {

    dojo.byId("global.periodoComprobantes").value = "";
		dojo.byId("global.opcExportacion").value = "";
    dojo.byId("global.opcMonedaNoNuevoSol").value = "";
    dojo.byId("global.opcVentasGrabadas").value = "";
    dojo.byId("global.opcVentasExoneradas").value = "";
    dojo.byId("global.opcVentasInafectas").value = "";
    dojo.byId("global.opcVentasGratuitas").value = "";
    dojo.byId("global.opcVentasGratuitasRec").value = "";
    dojo.byId("global.operacSujetasIsc").value = "";
    dojo.byId("global.operacSujetasIvap").value = "";
    dojo.byId("global.operacOtrosTribCargos").value = "";
    //dojo.byId("global.fechaVencimPago").value = "";
    //dojo.byId("global.emisionMaquinaRegis").value = "";
    //dojo.byId("global.cpModifCpOriginal").value = "";
    //dojo.byId("global.capturarCpXRangos").value ="";
    //dojo.byId("global.opcAnotadosRegistroAnterior").value ="";
    dojo.byId("global.cuoEncontrado").value = "0";
     this.resetDatos();
	},
	
	
	resetDatos: function() {

		dojo.byId("global.esRetroceso").value = "0";
    dojo.byId("global.tipoCP").value = "";
    dojo.byId("global.tipoCPDescripcion").value = "";
    dojo.byId("global.estadoCP").value = "";
    dojo.byId("global.tipoDocRecepCP").value = "";
    dojo.byId("global.tipoDocRecepCPDescripcion").value = "";
    dojo.byId("global.numeroDocRecepCP").value = "";
    dojo.byId("global.razonSocialRecepCP").value = "";
    dojo.byId("global.fechaEmisionCP").value = "";
    dojo.byId("global.fechaVencimientoPago").value = "";
    dojo.byId("global.numeroSerieCP").value = "";
    dojo.byId("global.numeroCP").value = "";
    dojo.byId("global.numeroCorrelativo").value = "";
    dojo.byId("global.numeroInicialCP").value ="";
    dojo.byId("global.numeroFinalCP").value ="";
    dojo.byId("global.numeroSerieMaqRegistra").value =""; 
    dojo.byId("global.periodoAjuste").value ="";  
    dojo.byId("global.cuo").value ="";     
    dojo.byId("global.esRetrocesoDetalle").value ="0";
    dojo.byId("global.tipoMoneda").value ="-"; 
    dojo.byId("global.fechaTC").value ="";
    dojo.byId("global.tc").value ="";         
    dojo.byId("global.valorFacturadoExportacion").value ="";  
    // dojo.byId("global.valorEmbarcadoExportacion").value ="";              
    dojo.byId("global.baseImpOperacGrav").value ="";
    dojo.byId("global.descBaseImponible").value = ""; 
    dojo.byId("global.importeOperacionExonerada").value ="";
    dojo.byId("global.importeOperacionInafecta").value =""; 
    dojo.byId("global.isc").value ="";
    dojo.byId("global.tasaIgvoipm").value ="";
    dojo.byId("global.igvoipm").value ="";
    dojo.byId("global.descuentoIgvoipm").value = "";  
    dojo.byId("global.baseImponibleIvap").value ="";
    dojo.byId("global.ivap").value ="";
    dojo.byId("global.tributosCargosNoBaseImp").value ="";
    dojo.byId("global.importeTotalCP").value ="";
    dojo.byId("global.grabadoPremio").value ="";
    dojo.byId("global.grabadoDonacion").value ="";
    dojo.byId("global.grabadoEntregaTrabajadores").value ="";
    dojo.byId("global.grabadoPublicidad").value ="";
    dojo.byId("global.grabadoBonificacion").value ="";
    dojo.byId("global.grabadoRetiroOtros").value ="";
    dojo.byId("global.valorFacturaExportaNoOnerosa").value ="";
    dojo.byId("global.importeOperacionNoOnerosaExo").value ="";
    dojo.byId("global.inafectoPremio").value ="";
    dojo.byId("global.inafectoPublicidad").value ="";
    dojo.byId("global.inafectoBonificacion").value ="";
    dojo.byId("global.inafectoRetiroConvenioColectivo").value ="";
    dojo.byId("global.inafectoMuestrasMedicas").value ="";
    dojo.byId("global.inafectoRetiroOtros").value ="";
    dojo.byId("global.fechaEmisionCPModificado").value ="";
    dojo.byId("global.tipoCPModificado").value ="";
    dojo.byId("global.numeroSerieCPModificado").value ="";
    dojo.byId("global.numeroCPModificado").value ="";
    dojo.byId("global.contratoColaboracion").value="";
    dojo.byId("global.errorTipo1").value="";
    dojo.byId("global.indicadorMedioPago").value="";
    dojo.byId("global.cuoEncontrado").value = "0";
	},
	
	getValorOpcionExportacion: function() {
		var valRet="";		
		for(i = 0; i < 2; i++) {
			if(dijit.byId("inicio.opcExportacion" + i).getValue() != false) {
				valRet = dijit.byId("inicio.opcExportacion" + i).getValue();
			}
		}
		return valRet;
	},
	
	getValorOpcionNoNuevoSol: function() {
		var valRet="";		
		for(i = 0; i < 2; i++) {
			if(dijit.byId("inicio.opcMonedaNoNuevoSol" + i).getValue() != false) {
				valRet = dijit.byId("inicio.opcMonedaNoNuevoSol" + i).getValue()
			}
		}
		return valRet;
	},
	
	getValorOpcionVentasGrabadas: function() {
		var valRet="";		
		for(i = 0; i < 2; i++) {
			if(dijit.byId("inicio.opcVentasGrabadas" + i).getValue() != false) {
				valRet = dijit.byId("inicio.opcVentasGrabadas" + i).getValue()
			}
		}
		return valRet;
	},
	
	getValorOpcionVentasExoneradas: function() {
		var valRet="";		
		for(i = 0; i < 2; i++) {
			if(dijit.byId("inicio.opcVentasExoneradas" + i).getValue() != false) {
				valRet = dijit.byId("inicio.opcVentasExoneradas" + i).getValue()
			}
		}
		return valRet;
	},
	
	getValorOpcionVentasInafectas: function() {
		var valRet="";		
		for(i = 0; i < 2; i++) {
			if(dijit.byId("inicio.opcVentasInafectas" + i).getValue() != false) {
				valRet = dijit.byId("inicio.opcVentasInafectas" + i).getValue()
			}
		}
		return valRet;
	},

	getValorErrorTipo1: function() {
		var valErr1="";		
		for(i = 0; i < 2; i++) {
		  if(dojo.byId("detalle.tcDiferenteSunat" + i).checked == true) {
			//if(dijit.byId("detalle.tcDiferenteSunat" + i).getValue() != false) {
				valErr1 = dijit.byId("detalle.tcDiferenteSunat" + i).getValue()
			}
		}
		return valErr1;
	},
	
	getValorIndicadorMedioPago: function() {
		var valMePag="";		
		for(i = 0; i < 2; i++) {
			//if(dijit.byId("detalle.medioDePago" + i).getValue() != false) {
			if(dojo.byId("detalle.medioDePago" + i).checked == true) {
				valMePag = dijit.byId("detalle.medioDePago" + i).getValue()
			}
		}
		return valMePag;
	},
	
	getValorOpcionVentasGratuitas: function() {
		var valRet="";		
		for(i = 0; i < 2; i++) {
			if(dijit.byId("inicio.opcVentasGratuitas" + i).getValue() != false) {
				valRet = dijit.byId("inicio.opcVentasGratuitas" + i).getValue()
			}
		}
		return valRet;
	},

	getValorOpcionOperacSujetasISC: function() {
		var valRet="";		
		for(i = 0; i < 2; i++) {
			if(dijit.byId("inicio.operacSujetasIsc" + i).getValue() != false) {
				valRet = dijit.byId("inicio.operacSujetasIsc" + i).getValue()
			}
		}
		return valRet;
	},
  	
    
	getValorOpcionOperacSujetasIvap: function() {
		var valRet="";		
		for(i = 0; i < 2; i++) {
			if(dijit.byId("inicio.operacSujetasIvap" + i).getValue() != false) {
				valRet = dijit.byId("inicio.operacSujetasIvap" + i).getValue()
			}
		}
		return valRet;
	},

	getValorOpcionOperacOtrosTribCargos: function() {
		var valRet="";		
		for(i = 0; i < 2; i++) {
			if(dijit.byId("inicio.operacOtrosTribCargos" + i).getValue() != false) {
				valRet = dijit.byId("inicio.operacOtrosTribCargos" + i).getValue()
			}
		}
		return valRet;
	},
  	
	getValorOpcionFechaVencimPago: function() {
		var valRet="";		
		for(i = 0; i < 2; i++) {
			if(dijit.byId("inicio.fechaVencimPago" + i).getValue() != false) {
				valRet = dijit.byId("inicio.fechaVencimPago" + i).getValue()
			}
		}
		return valRet;
	},
  	   
  /*      
 	getValorOpcionEmisionMaquinaRegis: function() {
		var valRet="";		
		for(i = 0; i < 2; i++) {
			if(dijit.byId("inicio.emisionMaquinaRegis" + i).getValue() != false) {
				valRet = dijit.byId("inicio.emisionMaquinaRegis" + i).getValue()
			}
		}
		return valRet;
	},
  */
  /*	
	getValorOpcionCPModisCPOriginal: function() {
		var valRet="";		
		for(i = 0; i < 2; i++) {
			if(dijit.byId("inicio.cpModifCpOriginal" + i).getValue() != false) {
				valRet = dijit.byId("inicio.cpModifCpOriginal" + i).getValue()
			}
		}
		return valRet;
	},     	
*/
  	
	getValorOpcionCapturarCPPorRangos: function() {
		var valRet="";		
		for(i = 0; i < 2; i++) {
			if(dijit.byId("inicio.capturarCpXRangos" + i).getValue() != false) {
			valRet = dijit.byId("inicio.capturarCpXRangos" + i).getValue();
			}
		}
		//if (dojo.byId("inicio.capturarCpXRangos0").checked == true) return 0;
		//if (dojo.byId("inicio.capturarCpXRangos1").checked == true) return 1;
		return valRet;
	},    

/*
	getValorOpcionAnotadosRegistroAnterior: function() {
		var valRet="";		
		for(i = 0; i < 2; i++) {
			if(dijit.byId("inicio.anotadosRegistroAnterior" + i).getValue() != false) {
				valRet = dijit.byId("inicio.anotadosRegistroAnterior" + i).getValue()
			}
		}
		return valRet;
	}, 
 */             	
	closeDocument: function() {
			this.store = null;
			this.otherDocStore = null;
			
			this.resetValoresGlobales();
			
			this.content.onLoad = dojo.hitch(this, function(){
				this.initContent();
			});
			this.content.setHref(this.controller + "?action=mostrarInicial0&mode=hidden");
	},

	closeDocumentInicial: function() {
		if (confirm("Desea salir del aplicativo?")) {
			this.closeDocument();
		}
	},      
  
  
	
	valoresNumDoc: function(){
	
  	var tipoDocSel = dijit.byId("generales.tipoDocRecepCP").getValue().substring(0,1);
  
    switch (tipoDocSel) { 
        case "-": 
    	     dojo.byId("generales.numeroDocRecepCP").maxLength = 8;
    	     dijit.byId("generales.numeroDocRecepCP").attr("regExp", "[0-9]+");  
    		   dijit.byId("generales.numeroDocRecepCP").setValue("");
    		   dijit.byId("generales.numeroDocRecepCP").attr("disabled" ,true) ; 
    		   break
        case "1": 
    	     dojo.byId("generales.numeroDocRecepCP").maxLength = 8;
    	     dijit.byId("generales.numeroDocRecepCP").attr("regExp", "[0-9]+"); 
    	     dijit.byId("generales.numeroDocRecepCP").attr("disabled", false) ; 
    	     if (dojo.byId("generales.numeroDocRecepCP").value.length > 8 ){
                dojo.byId("generales.numeroDocRecepCP").value = "";
                dojo.byId("generales.razonSocialRecepCP").value = "";
           }
           break 
        case "6": 
    	     dojo.byId("generales.numeroDocRecepCP").maxLength = 11;
    	     dijit.byId("generales.numeroDocRecepCP").attr("regExp", "[0-9]+"); 
    	     dijit.byId("generales.numeroDocRecepCP").attr("disabled",false) ;  
    	     if (dojo.byId("generales.numeroDocRecepCP").value.length > 11 ){
                dojo.byId("generales.numeroDocRecepCP").value = "";
                dojo.byId("generales.razonSocialRecepCP").value = "";
           }
           break 
        default: 
           dojo.byId("generales.numeroDocRecepCP").maxLength = 16;
           dijit.byId("generales.numeroDocRecepCP").attr("regExp", "[a-zA-Z0-9]+[-]{0,1}[a-zA-Z0-9]+[-]{0,1}[a-zA-Z0-9]+[-]{0,1}[a-zA-Z0-9]+");
           dijit.byId("generales.numeroDocRecepCP").attr("disabled", false) ; 
           dijit.byId("generales.razonSocialRecepCP").attr("disabled",false) ; 
           break;
    } 
    
    dijit.hideTooltip(dojo.byId("generales.numeroDocRecepCP"));
    dijit.hideTooltip(dojo.byId("generales.tipoDocRecepCP"));
    dijit.hideTooltip(dojo.byId("generales.periodoAjuste"));

	},
	
	valoresNumDocModif: function(){
	
  	var tipoDocSel = dijit.byId("detalle.tipoCPModificado").getValue().substring(0,1);
  
    switch (tipoDocSel) { 
        case "1": 
    	     dijit.byId("detalle.numeroCPModificado").attr('maxLength',8);
    	     dijit.byId("detalle.numeroCPModificado").attr('regExp','[0-9]+');
           break 
        case "6": 
    	     dijit.byId("detalle.numeroCPModificado").attr('maxLength',11);
    	     dijit.byId("detalle.numeroCPModificado").attr('regExp','[0-9]+');
           break 
        default: 
           dijit.byId("detalle.numeroCPModificado").attr('maxLength',16);
           dijit.byId("detalle.numeroCPModificado").attr('regExp','[A-Z0-9]+[-]{0,1}[A-Z0-9]+');
    } 
	},
	
	
	validaNumDoc: function(){
	
	  dijit.hideTooltip(dojo.byId("generales.razonSocialRecepCP"));
	  dijit.hideTooltip(dojo.byId("generales.numeroDocRecepCP"));
	  
	  
	  var tipoDoc = dijit.byId("generales.tipoDocRecepCP").getValue().substring(0,1);
  	var numDoc = dijit.byId("generales.numeroDocRecepCP").getValue();
    var lenDoc = numDoc.length;
  
    switch (tipoDoc) { 
        case "1": 
           if (lenDoc != 8){return; }
           break 
        case "6": 
           if (lenDoc != 11){return; }
           break 
        case "-": 
           dijit.byId("generales.numeroDocRecepCP").setValue("");
           dijit.byId("generales.numeroDocRecepCP").attr("disabled", true) ; 
           return;
           break 
        default: 
           return;
           break                    
    } 
    
    	  ///
	  //if (  dijit.byId("generales.tipoDocRecepCP").getValue().substring(0,1) =="6" && (dijit.byId("generales.numeroDocRecepCP").getValue() == dojo.byId("global.ruc").value) ){
    //    this.iconTooltipMessage("generales.numeroDocRecepCP", "icon-ok-tooltip", "El documento del cliente no puede ser el mismo que el del emisor.");
    //    return;	
    //}
	  /////
    
    
        var handler = dojo.xhrGet({
              url: this.controller + "?action=validarDocumento&tipoDoc=" +tipoDoc + "&numeroDoc=" + numDoc,
              handleAs: "json",
              sync: true,
              timeout: 10000
        });        
        handler.addCallback(dojo.hitch(this, function(res){
           
           tipoDoc = dijit.byId("generales.tipoDocRecepCP").getValue().substring(0,1);
    		   if (res.codeError == 0) {
    		       switch (tipoDoc) { 
                    case "1": 
                       if (res.data != null && res.data  != ""){
                          dijit.byId("generales.razonSocialRecepCP").setValue(res.data);
                          dijit.byId("generales.razonSocialRecepCP").attr('disabled', true);
                       }else{
                           dijit.byId("generales.razonSocialRecepCP").setValue("");
                           dijit.byId("generales.razonSocialRecepCP").attr('disabled', false);
                           this.iconTooltipMessage("generales.numeroDocRecepCP", "icon-ok-tooltip", "N�mero de DNI no existe!");
                       }
                       break 
                    case "6": 
                       if (res.data != null &&  res.data  != ""){
                          dijit.byId("generales.razonSocialRecepCP").setValue(res.data);
                          dijit.byId("generales.razonSocialRecepCP").attr("disabled", true) ; 
                       }else{
                          dijit.byId("generales.razonSocialRecepCP").setValue("");
                          dijit.byId("generales.razonSocialRecepCP").attr("disabled", true) ; 
                          dijit.byId("generales.numeroDocRecepCP").focus();
                          this.iconTooltipMessage("generales.numeroDocRecepCP", "icon-ok-tooltip", "N�mero de RUC no existe!");

                       }
                       break 
               } 
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                              
    			 } else {                                 
    				  alert(res.messageError);
    				  
    				  return;
    			 }
    		}));
    		handler.addErrback(function(res){
    	   	this.waitMessage.hide();
    			alert("Problemas al conectarse con el servidor");
    		});
             //dijit.byId("generales.numeroDocRecepCP").attr('regExp','[^|\~���"]+');
	},          	


	guardarDatosGenerales: function() {
    dojo.byId("global.esRetroceso").value = "1";
		dojo.byId("global.tipoCP").value = dijit.byId("generales.tipoCP").getValue().substring(0,2);
		dojo.byId("global.tipoCPDescripcion").value = dojo.trim(dijit.byId("generales.tipoCP").getValue().substring(5));
		dojo.byId("global.estadoCP").value = dijit.byId("generales.estadoCP").getValue();
    dojo.byId("global.tipoDocRecepCP").value = dijit.byId("generales.tipoDocRecepCP").getValue().substring(0,1);
    dojo.byId("global.tipoDocRecepCPDescripcion").value = dojo.trim(dijit.byId("generales.tipoDocRecepCP").getValue().substr(4));
    dojo.byId("global.numeroDocRecepCP").value = dijit.byId("generales.numeroDocRecepCP").getValue();
    dojo.byId("global.razonSocialRecepCP").value = dijit.byId("generales.razonSocialRecepCP").getValue();
  
    if (dijit.byId('generales.fechaEmisionCP').getValue() != null && dijit.byId('generales.fechaEmisionCP').getValue()!= "" ) {dojo.byId("global.fechaEmisionCP").value =dojo.date.locale.format(dijit.byId('generales.fechaEmisionCP').getValue(), {datePattern: "MM/dd/yyyy", selector: "date"}); }
    
    //if (dojo.byId('generales.fechaEmisionCP').value != null && dojo.byId('generales.fechaEmisionCP').value!= "" ) {dojo.byId("global.fechaEmisionCP").value =  dojo.date.locale.format(new Date(dojo.byId('generales.fechaEmisionCP').value.substring(3,6) + dojo.byId('generales.fechaEmisionCP').value.substring(0,3) + dojo.byId('generales.fechaEmisionCP').value.substring(6,10) ), {datePattern: "MM/dd/yyyy", selector: "date"}); }
    
    if (dijit.byId('generales.fechaVencimientoPago').getValue() != null && dijit.byId('generales.fechaVencimientoPago').getValue() != "" ) { dojo.byId("global.fechaVencimientoPago").value = dojo.date.locale.format(dijit.byId('generales.fechaVencimientoPago').getValue(), {datePattern: "MM/dd/yyyy", selector: "date"});}
    //if (dojo.byId('generales.fechaVencimientoPago').value != null && dojo.byId('generales.fechaVencimientoPago').value!= "" ) {dojo.byId("global.fechaVencimientoPago").value =  dojo.date.locale.format(new Date(dojo.byId('generales.fechaVencimientoPago').value.substring(3,6) + dojo.byId('generales.fechaVencimientoPago').value.substring(0,3) + dojo.byId('generales.fechaVencimientoPago').value.substring(6,10) ), {datePattern: "MM/dd/yyyy", selector: "date"}); }
    dojo.byId("global.numeroSerieCP").value = dojo.byId("generales.numeroSerieCP").value;
    	  
    var tieneNrosRango = this.getValorOpcionCapturarCPPorRangos(); //dojo.byId("global.capturarCpXRangos").value;
    var tipoCP = dijit.byId("generales.tipoCP").getValue().substring(0,2);
    //if (tieneNrosRango==1 && ( tipoCP =="03" ||  tipoCP =="12" || tipoCP =="15" ||  tipoCP =="19" ) ){  //Se cambio por ple5
    if (tieneNrosRango==1 && ( tipoCP =="03" ||  tipoCP =="12" || tipoCP =="00" ||  tipoCP =="13" || tipoCP =="87") ){
        dojo.byId("global.numeroCP").value = "";
       
    }else{
       dojo.byId("global.numeroInicialCP").value = "";
       dojo.byId("global.numeroFinalCP").value = "";       
    }	
    var estadoCP = dijit.byId("generales.estadoCP").getValue();
    if (dojo.byId("generales.cuo").value != "") {dojo.byId("global.cuo").value = dojo.byId("generales.cuo").value;}
    if (dojo.byId("generales.numeroCorrelativo").value != "") {dojo.byId("global.numeroCorrelativo").value = dijit.byId("generales.numeroCorrelativo").getValue();}
    
    if (!(estadoCP =="08") && !(estadoCP =="09")){
       dojo.byId("global.cuo").value ="";
       dojo.byId("global.numeroCorrelativo").value ="";
    }
    if (dojo.byId("generales.numeroCP").value != "") {dojo.byId("global.numeroCP").value = dijit.byId("generales.numeroCP").getValue();}
    if (dojo.byId("generales.numeroInicialCP").value != "") {dojo.byId("global.numeroInicialCP").value = dijit.byId("generales.numeroInicialCP").getValue();}
    if (dojo.byId("generales.numeroFinalCP").value != "") {dojo.byId("global.numeroFinalCP").value = dojo.byId("generales.numeroFinalCP").value;}
    //dojo.byId("global.numeroSerieMaqRegistra").value = dojo.byId("generales.numeroSerieMaqRegistra").value;
    if (dojo.byId("generales.periodoAjuste").value != "") {dojo.byId("global.periodoAjuste").value = dojo.byId("generales.periodoAjuste").value.substring(3,7) + dojo.byId("generales.periodoAjuste").value.substring(0,2) ;}
    
    if (dojo.byId('detalle.fechaEmisionCPModificado').value != null && dojo.byId('detalle.fechaEmisionCPModificado').value != "" ) {dojo.byId("global.fechaEmisionCPModificado").value =  dojo.date.locale.format(dijit.byId('detalle.fechaEmisionCPModificado').getValue(), {datePattern: "MM/dd/yyyy", selector: "date"});}
    //if (dojo.byId('detalle.fechaEmisionCPModificado').value != null && dojo.byId('detalle.fechaEmisionCPModificado').value!= "" ) {dojo.byId("global.fechaEmisionCPModificado").value =  dojo.date.locale.format(new Date(dojo.byId('detalle.fechaEmisionCPModificado').value.substring(3,6) + dojo.byId('detalle.fechaEmisionCPModificado').value.substring(0,3) + dojo.byId('detalle.fechaEmisionCPModificado').value.substring(6,10) ), {datePattern: "MM/dd/yyyy", selector: "date"}); }
    dojo.byId("global.tipoCPModificado").value = dijit.byId("detalle.tipoCPModificado").getValue().substring(0,2);
    //var modificaCPOriginal = dojo.byId("global.cpModifCpOriginal").value;
    var modificaCPOriginal = 0; //    dojo.byId("global.cpModifCpOriginal").value;
    if (tipoCP =="07" || tipoCP == "08" || tipoCP =="87" || tipoCP == "88"){
        modificaCPOriginal=1; 
    }
      
     var estadoCP = dijit.byId("generales.estadoCP").getValue(); 
    if (modificaCPOriginal==1 && estadoCP!= "02"){
    
    }else{
       dojo.byId("global.fechaEmisionCPModificado").value = "";  
       dojo.byId("global.tipoCPModificado").value = "";  
       dojo.byId("global.numeroSerieCPModificado").value = "";  
       dojo.byId("global.numeroCPModificado").value = "";  
    }       
    
    dojo.byId("global.numeroSerieCPModificado").value = dojo.byId("detalle.numeroSerieCPModificado").value;
    dojo.byId("global.numeroCPModificado").value = dojo.byId("detalle.numeroCPModificado").value;    
	},
 			
	guardarDatosDetalle: function() {
    dojo.byId("global.esRetrocesoDetalle").value = "1";
    var tieneNoNuevoSol = dojo.byId("global.opcMonedaNoNuevoSol").value;
    var estadoCP = dojo.byId("global.estadoCP").value;
    if (tieneNoNuevoSol==1){
       if (estadoCP == "02"){
            dojo.byId("global.tipoMoneda").value = "-";
            dojo.byId("global.tc").value = "";
       }else{
            dojo.byId("global.tipoMoneda").value = dijit.byId("detalle.tipoMoneda").getValue();
            dojo.byId("global.tc").value = dijit.byId("detalle.tc").getValue();
        }
    }else{
        dojo.byId("global.tipoMoneda").value = "-";
        dojo.byId("global.tc").value = "";
    }

    //if (dijit.byId('detalle.fechaTC').getValue() != null && dijit.byId('detalle.fechaTC').getValue() != "" ) {dojo.byId("global.fechaTC").value =  dojo.date.locale.format(dijit.byId('detalle.fechaTC').getValue(), {datePattern: "MM/dd/yyyy", selector: "date"});}

    dojo.byId("global.errorTipo1").value = this.getValorErrorTipo1();
    dojo.byId("global.valorFacturadoExportacion").value = dijit.byId("detalle.valorFacturadoExportacion").getValue();
    //dojo.byId("global.valorEmbarcadoExportacion").value = dijit.byId("detalle.valorEmbarcadoExportacion").getValue();
		dojo.byId("global.baseImpOperacGrav").value = dijit.byId("detalle.baseImpOperacGrav").getValue();
		dojo.byId("global.descBaseImponible").value = dijit.byId("detalle.descBaseImponible").getValue();
		dojo.byId("global.importeOperacionExonerada").value = dijit.byId("detalle.importeOperacionExonerada").getValue();
    dojo.byId("global.importeOperacionInafecta").value = dijit.byId("detalle.importeOperacionInafecta").getValue();
    dojo.byId("global.isc").value = dijit.byId("detalle.isc").getValue();
    dojo.byId("global.tasaIgvoipm").value = dijit.byId("detalle.tasasIgvIpm").getValue();
    dojo.byId("global.igvoipm").value = dijit.byId("detalle.igvoipm").getValue();
    dojo.byId("global.descuentoIgvoipm").value = dijit.byId("detalle.descuentoIgvoipm").getValue();
    dojo.byId("global.baseImponibleIvap").value = dijit.byId("detalle.baseImponibleIvap").getValue();
    dojo.byId("global.ivap").value = dijit.byId("detalle.ivap").getValue();
    dojo.byId("global.tributosCargosNoBaseImp").value = dijit.byId("detalle.tributosCargosNoBaseImp").getValue();
    dojo.byId("global.importeTotalCP").value = dijit.byId("detalle.importeTotalCP").getValue();
    dojo.byId("global.indicadorMedioPago").value = this.getValorIndicadorMedioPago(); 
    dojo.byId("global.contratoColaboracion").value = dijit.byId("detalle.contratoColaboracion").getValue();
    dojo.byId("global.grabadoPremio").value = dijit.byId("detalle.grabadoPremio").getValue();
    dojo.byId("global.grabadoDonacion").value = dijit.byId("detalle.grabadoDonacion").getValue();
    dojo.byId("global.grabadoEntregaTrabajadores").value = dijit.byId("detalle.grabadoEntregaTrabajadores").getValue();      
    dojo.byId("global.grabadoPublicidad").value = dijit.byId("detalle.grabadoPublicidad").getValue();
    dojo.byId("global.grabadoBonificacion").value = dijit.byId("detalle.grabadoBonificacion").getValue();
    dojo.byId("global.grabadoRetiroOtros").value = dijit.byId("detalle.grabadoRetiroOtros").getValue(); 
    dojo.byId("global.valorFacturaExportaNoOnerosa").value = dijit.byId("detalle.valorFacturaExportaNoOnerosa").getValue();
    dojo.byId("global.importeOperacionNoOnerosaExo").value = dijit.byId("detalle.importeOperacionNoOnerosaExo").getValue();
    dojo.byId("global.inafectoPremio").value = dijit.byId("detalle.inafectoPremio").getValue(); 
    dojo.byId("global.inafectoPublicidad").value = dijit.byId("detalle.inafectoPublicidad").getValue();
    dojo.byId("global.inafectoBonificacion").value = dijit.byId("detalle.inafectoBonificacion").getValue();
    dojo.byId("global.inafectoRetiroConvenioColectivo").value = dijit.byId("detalle.inafectoRetiroConvenioColectivo").getValue(); 
    dojo.byId("global.inafectoMuestrasMedicas").value = dijit.byId("detalle.inafectoMuestrasMedicas").getValue();
    dojo.byId("global.inafectoRetiroOtros").value = dijit.byId("detalle.inafectoRetiroOtros").getValue();
 
	},
   			
	backInicioSeteo: function() {
	   dojo.byId("action").value = "datosInicial";
	        
     dijit.hideTooltip(dojo.byId("generales.fechaEmisionCP"));
     dijit.hideTooltip(dojo.byId("generales.fechaVencimientoPago"));
     dijit.hideTooltip(dojo.byId("generales.numeroSerieCP"));
     dijit.hideTooltip(dojo.byId("generales.numeroDocRecepCP"));
      dijit.hideTooltip(dojo.byId("generales.numeroDocRecepCP"));
     dijit.hideTooltip(dojo.byId("generales.numeroInicialCP"));
     dijit.hideTooltip(dojo.byId("generales.numeroFinalCP"));   
     dijit.hideTooltip(dojo.byId("generales.numeroCP")); 
     dijit.hideTooltip(dojo.byId("generales.numeroSerieCP"))
      dijit.hideTooltip(dojo.byId("generales.numeroCorrelativo"))
      dijit.hideTooltip(dojo.byId("generales.cuo"));   
       dijit.hideTooltip(dojo.byId("generales.estadoCP"));
       dijit.hideTooltip(dojo.byId("generales.periodoAjuste"));
      //dijit.hideTooltip(dojo.byId("generales.numeroSerieMaqRegistra"));
      dijit.hideTooltip(dojo.byId("generales.razonSocialRecepCP"));
  
	   this.guardarDatosGenerales();
	   
			this.content.setHref(this.controller + "?action=backSeteoInicial&preventCache=" + this.preventCache());
			this.content.onLoad = dojo.hitch(this, function(){
			   this.cargaDatosSeteo();
      });
	},
		
	backDatosGenerales: function() {
		 	   	  //dijit.hideTooltip(dojo.byId("detalle.fechaTC"));
	      dijit.hideTooltip(dojo.byId("detalle.tc"));   
        dijit.hideTooltip(dojo.byId("detalle.baseImpOperacGrav"));
        dijit.hideTooltip(dojo.byId("detalle.igvoipm"));
        dijit.hideTooltip(dojo.byId("detalle.valorFacturadoExportacion"));
        //dijit.hideTooltip(dojo.byId("detalle.valorEmbarcadoExportacion"));
        dijit.hideTooltip(dojo.byId("detalle.importeOperacionExonerada"));
        dijit.hideTooltip(dojo.byId("detalle.importeOperacionInafecta"));
        dijit.hideTooltip(dojo.byId("detalle.tributosCargosNoBaseImp"));
         dijit.hideTooltip(dojo.byId("detalle.fechaEmisionCPModificado"));
        dijit.hideTooltip(dojo.byId("detalle.isc"));   
        dijit.hideTooltip(dojo.byId("detalle.baseImponibleIvap"));
        dijit.hideTooltip(dojo.byId("detalle.ivap"));
	   var estadoCP = dojo.byId("global.estadoCP").value;
     if (estadoCP != "02"){  this.guardarDatosDetalle();}
	   
			this.content.setHref(this.controller + "?action=backDatosGenerales&preventCache=" + this.preventCache());
			this.content.onLoad = dojo.hitch(this, function(){
			   dojo.byId("global.esRetroceso").value = "1";
			   this.mostrarDatosGenerales();

      });
	},
  
  backDatosDetalle: function() {
	   
			this.content.setHref(this.controller + "?action=backDatosDetalle&preventCache=" + this.preventCache());
			this.content.onLoad = dojo.hitch(this, function(){
			   dojo.byId("global.esRetrocesoDetalle").value = "1";
			   this.mostrarDatosDetalle();

      });
	},
  		
	cargaDatosSeteo : function() {
		if (dojo.byId("global.periodoComprobantes").value != "") {
		  var periodotemp = dojo.byId("global.periodoComprobantes").value;
	    dijit.byId("inicio.periodoRegistroVentas").setValue(periodotemp.substring(4,6) + "/" + periodotemp.substring(0,4));
    }
    
		if (dojo.byId("global.opcExportacion").value == "1") {
	    dijit.byId("inicio.opcExportacion1").setChecked("checked");
	    this.opcionesExportacion(1);
	  }else{
	    dijit.byId("inicio.opcExportacion0").setChecked("checked");
	    this.opcionesExportacion(0);
    }

		if (dojo.byId("global.opcMonedaNoNuevoSol").value == "1") {
	    dijit.byId("inicio.opcMonedaNoNuevoSol1").setChecked("checked");
	  }else{
	    dijit.byId("inicio.opcMonedaNoNuevoSol0").setChecked("checked");
    }
    	
		if (dojo.byId("global.opcVentasGrabadas").value == "1") {
	    dijit.byId("inicio.opcVentasGrabadas1").setChecked("checked");
	    this.opcionesVtasGrabadas(1);
	  }else{
	    dijit.byId("inicio.opcVentasGrabadas0").setChecked("checked");
	    this.opcionesVtasGrabadas(0);
    }

		if (dojo.byId("global.opcVentasExoneradas").value == "1") {
	    dijit.byId("inicio.opcVentasExoneradas1").setChecked("checked");
	    this.opcionesVtasExoneradas(1);
	  }else{
	    dijit.byId("inicio.opcVentasExoneradas0").setChecked("checked");
	    this.opcionesVtasExoneradas(0);
    }
  
  	if (dojo.byId("global.opcVentasInafectas").value == "1") {
	    dijit.byId("inicio.opcVentasInafectas1").setChecked("checked");
	    this.opcionesVtasInafectas(1);
	  }else{
	    dijit.byId("inicio.opcVentasInafectas0").setChecked("checked");
	    this.opcionesVtasInafectas(0);
    }

		if (dojo.byId("global.opcVentasGratuitasRec").value == "1") {
	    dijit.byId("inicio.opcVentasGratuitas1").setChecked("checked");
	    this.opcionesVtasGratuitas(1);
	  }else{
	    dijit.byId("inicio.opcVentasGratuitas0").setChecked("checked");
	    this.opcionesVtasGratuitas(0);
    }  

  	if (dojo.byId("global.operacSujetasIsc").value == "1") {
	    dijit.byId("inicio.operacSujetasIsc1").setChecked("checked");
	  }else{
	    dijit.byId("inicio.operacSujetasIsc0").setChecked("checked");
    }

		if (dojo.byId("global.operacSujetasIvap").value == "1") {
	    dijit.byId("inicio.operacSujetasIvap1").setChecked("checked");
	  }else{
	    dijit.byId("inicio.operacSujetasIvap0").setChecked("checked");
    }  
    
    if (dojo.byId("global.operacOtrosTribCargos").value == "1") {
	    dijit.byId("inicio.operacOtrosTribCargos1").setChecked("checked");
	  }else{
	    dijit.byId("inicio.operacOtrosTribCargos0").setChecked("checked");
    }

    /*
		if (dojo.byId("global.fechaVencimPago").value == "1") {
	    dijit.byId("inicio.fechaVencimPago1").setChecked("checked");
	  }else{
	    dijit.byId("inicio.fechaVencimPago0").setChecked("checked");
    }  
     */
    /* 
    if (dojo.byId("global.emisionMaquinaRegis").value == "1") {
	    dijit.byId("inicio.emisionMaquinaRegis1").setChecked("checked");
	  }else{
	    dijit.byId("inicio.emisionMaquinaRegis0").setChecked("checked");
    }
    */

/*
		if (dojo.byId("global.cpModifCpOriginal").value == "1") {
	    dijit.byId("inicio.cpModifCpOriginal1").setChecked("checked");
	  }else{
	    dijit.byId("inicio.cpModifCpOriginal0").setChecked("checked");
    }  
  */      

/*    
 		if (dojo.byId("global.opcAnotadosRegistroAnterior").value == "1") {
	    dijit.byId("inicio.anotadosRegistroAnterior1").setChecked("checked");
	    this.opcionesCPRegistradosAnterior(1);
	  }else{
	    dijit.byId("inicio.anotadosRegistroAnterior0").setChecked("checked");
	    this.opcionesCPRegistradosAnterior(0);
    }         
*/
		if (dojo.byId("global.opcExportacion").value == "1") {
	    dijit.byId("inicio.opcExportacion1").setChecked("checked");
	    this.opcionesExportacion(1);
	  }else{
	    dijit.byId("inicio.opcExportacion0").setChecked("checked");
	    this.opcionesExportacion(0);
    }


	},
	
	opcionesExportacion: function(opcion){

    if (opcion ==1 ){
        dijit.byId("inicio.opcVentasGrabadas0").setChecked("checked");
        dijit.byId("inicio.opcVentasExoneradas0").setChecked("checked");
		    dijit.byId("inicio.opcVentasInafectas0").setChecked("checked");
		    dijit.byId("inicio.operacSujetasIsc0").setChecked("checked");
        dijit.byId("inicio.operacSujetasIvap0").setChecked("checked");
 
          
        dijit.byId("inicio.opcVentasGrabadas0").setAttribute('disabled', true);     
        dijit.byId("inicio.opcVentasExoneradas0").setAttribute('disabled', true);  
        dijit.byId("inicio.opcVentasInafectas0").setAttribute('disabled', true);  
        dijit.byId("inicio.operacSujetasIsc0").setAttribute('disabled', true);  
        dijit.byId("inicio.operacSujetasIvap0").setAttribute('disabled', true);  
 
        dijit.byId("inicio.opcVentasGrabadas1").setAttribute('disabled', true);     
        dijit.byId("inicio.opcVentasExoneradas1").setAttribute('disabled', true);  
        dijit.byId("inicio.opcVentasInafectas1").setAttribute('disabled', true);  
        dijit.byId("inicio.operacSujetasIsc1").setAttribute('disabled', true);  
        dijit.byId("inicio.operacSujetasIvap1").setAttribute('disabled', true);  
    
          
    }else{
    
    
        if (this.getValorOpcionVentasGratuitas() != "1"){
            dijit.byId("inicio.opcVentasGrabadas0").setAttribute('disabled', false);     
            dijit.byId("inicio.opcVentasExoneradas0").setAttribute('disabled', false);  
            dijit.byId("inicio.opcVentasInafectas0").setAttribute('disabled', false); 
            dijit.byId("inicio.opcVentasGrabadas1").setAttribute('disabled', false);     
            dijit.byId("inicio.opcVentasExoneradas1").setAttribute('disabled', false);  
            dijit.byId("inicio.opcVentasInafectas1").setAttribute('disabled', false);              
        } 
        //if (this.getValorOpcionAnotadosRegistroAnterior()!= "1"){
            dijit.byId("inicio.operacSujetasIsc0").setAttribute('disabled', false);  
            dijit.byId("inicio.operacSujetasIsc1").setAttribute('disabled', false); 
        //}
        
       
        dijit.byId("inicio.operacSujetasIvap0").setAttribute('disabled', false);  
        dijit.byId("inicio.operacSujetasIvap1").setAttribute('disabled', false);  
        
    }
    
   },  
    
    
	opcionesVtasGrabadas: function(opcion){

    if (opcion ==1 ){
        //dijit.byId("inicio.opcVentasExoneradas0").setChecked("checked");
		    //dijit.byId("inicio.opcVentasInafectas0").setChecked("checked");
		    dijit.byId("inicio.operacSujetasIvap0").setChecked("checked");
          
        //dijit.byId("inicio.opcVentasExoneradas0").setAttribute('disabled', true);  
        //dijit.byId("inicio.opcVentasInafectas0").setAttribute('disabled', true);  

        dijit.byId("inicio.operacSujetasIvap0").setAttribute('disabled', true);  
        //dijit.byId("inicio.opcVentasExoneradas1").setAttribute('disabled', true);  
        //dijit.byId("inicio.opcVentasInafectas1").setAttribute('disabled', true);  
        dijit.byId("inicio.operacSujetasIvap1").setAttribute('disabled', true);          
          
    }else{
        //dijit.byId("inicio.opcVentasExoneradas0").setAttribute('disabled', false);  
        //dijit.byId("inicio.opcVentasInafectas0").setAttribute('disabled', false);  
        dijit.byId("inicio.operacSujetasIvap0").setAttribute('disabled', false);  
        //dijit.byId("inicio.opcVentasExoneradas1").setAttribute('disabled', false);  
        //dijit.byId("inicio.opcVentasInafectas1").setAttribute('disabled', false);  
        dijit.byId("inicio.operacSujetasIvap1").setAttribute('disabled', false);      
        if (this.getValorOpcionVentasExoneradas()=="1" || this.getValorOpcionVentasInafectas()=="1"){
           dijit.byId("inicio.operacSujetasIvap0").setAttribute('disabled', true);  
           dijit.byId("inicio.operacSujetasIvap1").setAttribute('disabled', true);            
        }else{
          dijit.byId("inicio.operacSujetasIvap0").setAttribute('disabled', false);  
          dijit.byId("inicio.operacSujetasIvap1").setAttribute('disabled', false);
        }    
    }
    
   },   
   
   opcionesVtasExoneradas: function(opcion){
    if (opcion ==1 ){
        //dijit.byId("inicio.opcVentasGrabadas0").setChecked("checked");
		    //dijit.byId("inicio.opcVentasInafectas0").setChecked("checked");
		    dijit.byId("inicio.operacSujetasIvap0").setChecked("checked");
         
        //dijit.byId("inicio.opcVentasGrabadas0").setAttribute('disabled', true);     
        //dijit.byId("inicio.opcVentasInafectas0").setAttribute('disabled', true);  
        dijit.byId("inicio.operacSujetasIvap0").setAttribute('disabled', true);  
        //dijit.byId("inicio.opcVentasGrabadas1").setAttribute('disabled', true);     
        //dijit.byId("inicio.opcVentasInafectas1").setAttribute('disabled', true);  
        dijit.byId("inicio.operacSujetasIvap1").setAttribute('disabled', true);         
          
    }else{
      
        if (this.getValorOpcionVentasGrabadas()=="1" || this.getValorOpcionVentasInafectas()=="1"){
           dijit.byId("inicio.operacSujetasIvap0").setAttribute('disabled', true);  
           dijit.byId("inicio.operacSujetasIvap1").setAttribute('disabled', true);            
        }else{
          dijit.byId("inicio.operacSujetasIvap0").setAttribute('disabled', false);  
          dijit.byId("inicio.operacSujetasIvap1").setAttribute('disabled', false);
        }               

    }
   },   
 
    opcionesVtasInafectas: function(opcion){
    if (opcion ==1 ){
        //dijit.byId("inicio.opcVentasGrabadas0").setChecked("checked");
		    //dijit.byId("inicio.opcVentasExoneradas0").setChecked("checked");
		    //dijit.byId("inicio.opcVentasGratuitas0").setChecked("checked");
         
        //dijit.byId("inicio.opcVentasGrabadas0").setAttribute('disabled', true);     
        //dijit.byId("inicio.opcVentasExoneradas0").setAttribute('disabled', true);  
        //dijit.byId("inicio.opcVentasGratuitas0").setAttribute('disabled', true);  
        //dijit.byId("inicio.opcVentasGrabadas1").setAttribute('disabled', true);     
        //dijit.byId("inicio.opcVentasExoneradas1").setAttribute('disabled', true);  
        //dijit.byId("inicio.opcVentasGratuitas1").setAttribute('disabled', true);          
          dijit.byId("inicio.operacSujetasIvap0").setChecked("checked");
          dijit.byId("inicio.operacSujetasIvap0").setAttribute('disabled', true); 
          dijit.byId("inicio.operacSujetasIvap1").setAttribute('disabled', true); 
    }else{
        /*dijit.byId("inicio.opcVentasGrabadas0").setAttribute('disabled', false);     
        dijit.byId("inicio.opcVentasExoneradas0").setAttribute('disabled', false);  
        dijit.byId("inicio.opcVentasGratuitas0").setAttribute('disabled', false);  
        dijit.byId("inicio.opcVentasGrabadas1").setAttribute('disabled', false);     
        dijit.byId("inicio.opcVentasExoneradas1").setAttribute('disabled', false);  
        dijit.byId("inicio.opcVentasGratuitas1").setAttribute('disabled', false);         
        */
        if (this.getValorOpcionVentasGrabadas()=="1" || this.getValorOpcionVentasExoneradas()=="1"){
           dijit.byId("inicio.operacSujetasIvap0").setAttribute('disabled', true);  
           dijit.byId("inicio.operacSujetasIvap1").setAttribute('disabled', true);            
        }else{
          dijit.byId("inicio.operacSujetasIvap0").setAttribute('disabled', false);  
          dijit.byId("inicio.operacSujetasIvap1").setAttribute('disabled', false);
        } 
    }
   },     

   opcionesVtasGratuitas: function(opcion){
      if (opcion ==1 ){
          /*dijit.byId("inicio.opcVentasGrabadas0").setChecked("checked");
  		    dijit.byId("inicio.opcVentasExoneradas0").setChecked("checked");
  		    dijit.byId("inicio.opcVentasInafectas0").setChecked("checked");
           
          dijit.byId("inicio.opcVentasGrabadas0").setAttribute('disabled', true);     
          dijit.byId("inicio.opcVentasExoneradas0").setAttribute('disabled', true);  
          dijit.byId("inicio.opcVentasInafectas0").setAttribute('disabled', true);  
          dijit.byId("inicio.opcVentasGrabadas1").setAttribute('disabled', true);     
          dijit.byId("inicio.opcVentasExoneradas1").setAttribute('disabled', true);  
          dijit.byId("inicio.opcVentasInafectas1").setAttribute('disabled', true);            
            */
          dijit.byId("inicio.operacSujetasIvap0").setChecked("checked");
          dijit.byId("inicio.operacSujetasIvap0").setAttribute('disabled', true); 
          dijit.byId("inicio.operacSujetasIvap1").setAttribute('disabled', true);         
      }else{
          if (this.getValorOpcionExportacion() != "1"){
              dijit.byId("inicio.opcVentasGrabadas0").setAttribute('disabled', false);     
              dijit.byId("inicio.opcVentasExoneradas0").setAttribute('disabled', false);  
              dijit.byId("inicio.opcVentasInafectas0").setAttribute('disabled', false);  
              dijit.byId("inicio.opcVentasGrabadas1").setAttribute('disabled', false);     
              dijit.byId("inicio.opcVentasExoneradas1").setAttribute('disabled', false);  
              dijit.byId("inicio.opcVentasInafectas1").setAttribute('disabled', false); 
              dijit.byId("inicio.operacSujetasIvap0").setAttribute('disabled', false); 
              dijit.byId("inicio.operacSujetasIvap1").setAttribute('disabled', false);                
          }   
      }
   },      
 
    opcionesIVAP: function(opcion){
      if (opcion ==1 ){
          dijit.byId("inicio.operacSujetasIsc0").setChecked("checked");
          dijit.byId("inicio.opcVentasGrabadas0").setChecked("checked");
  		    dijit.byId("inicio.opcVentasExoneradas0").setChecked("checked");
  		    dijit.byId("inicio.opcVentasInafectas0").setChecked("checked");
  		    dijit.byId("inicio.opcExportacion0").setChecked("checked");
            
          dijit.byId("inicio.operacSujetasIsc0").setAttribute('disabled', true);  
          dijit.byId("inicio.opcVentasGrabadas0").setAttribute('disabled', true);     
          dijit.byId("inicio.opcVentasExoneradas0").setAttribute('disabled', true);  
          dijit.byId("inicio.opcVentasInafectas0").setAttribute('disabled', true);  
          dijit.byId("inicio.opcExportacion0").setAttribute('disabled', true);  
          dijit.byId("inicio.operacSujetasIsc1").setAttribute('disabled', true);  
          dijit.byId("inicio.opcVentasGrabadas1").setAttribute('disabled', true);     
          dijit.byId("inicio.opcVentasExoneradas1").setAttribute('disabled', true);  
          dijit.byId("inicio.opcVentasInafectas1").setAttribute('disabled', true);  
          dijit.byId("inicio.opcExportacion1").setAttribute('disabled', true);           
            
      }else{
          //if (this.getValorOpcionAnotadosRegistroAnterior()!= "1"){
              dijit.byId("inicio.operacSujetasIsc0").setAttribute('disabled', false); 
          //}
          //
          dijit.byId("inicio.opcVentasGrabadas0").setAttribute('disabled', false);     
          dijit.byId("inicio.opcVentasExoneradas0").setAttribute('disabled', false);  
          dijit.byId("inicio.opcVentasInafectas0").setAttribute('disabled', false);  
          dijit.byId("inicio.opcExportacion0").setAttribute('disabled', false); 
          //if (this.getValorOpcionAnotadosRegistroAnterior()!= "1"){
              dijit.byId("inicio.operacSujetasIsc1").setAttribute('disabled', false); 
          //}
          dijit.byId("inicio.opcVentasGrabadas1").setAttribute('disabled', false);     
          dijit.byId("inicio.opcVentasExoneradas1").setAttribute('disabled', false);  
          dijit.byId("inicio.opcVentasInafectas1").setAttribute('disabled', false);  
          dijit.byId("inicio.opcExportacion1").setAttribute('disabled', false);            
  
      }
   }, 
   
    opcionesISC: function(opcion){
      if (opcion ==1 ){
          dijit.byId("inicio.operacSujetasIvap0").setChecked("checked");
            
          dijit.byId("inicio.operacSujetasIvap0").setAttribute('disabled', true);  
          dijit.byId("inicio.operacSujetasIvap1").setAttribute('disabled', true);  
      }else{
          dijit.byId("inicio.operacSujetasIvap0").setAttribute('disabled', false); 
          dijit.byId("inicio.operacSujetasIvap1").setAttribute('disabled', false); 
      }
   },
   
  opcionesCPRegistradosAnterior: function(opcion){
      if (opcion ==1 ){
          /*dijit.byId("inicio.operacSujetasIsc0").setChecked("checked");
          dijit.byId("inicio.capturarCpXRangos0").setChecked("checked");
          dijit.byId("inicio.operacSujetasIsc0").setAttribute('disabled', true); 
          dijit.byId("inicio.capturarCpXRangos0").setAttribute('disabled', true);   
          dijit.byId("inicio.operacSujetasIsc1").setAttribute('disabled', true); 
          dijit.byId("inicio.capturarCpXRangos1").setAttribute('disabled', true);
          */   
      }else{
          /*
          dijit.byId("inicio.capturarCpXRangos0").setAttribute('disabled', false); 
          dijit.byId("inicio.capturarCpXRangos1").setAttribute('disabled', false);   
          if (this.getValorOpcionOperacSujetasIvap()!= "1" && this.getValorOpcionExportacion()!="1"){
              dijit.byId("inicio.operacSujetasIsc0").setAttribute('disabled', false);   
              dijit.byId("inicio.operacSujetasIsc1").setAttribute('disabled', false);  
          } 
          */          
      }
   },   
   
	//funciones para eventos
    startup: function(){
    	  dojo.parser.parse(dojo.byId('container'));
    	  setTimeout(dojo.hitch(this, function(){
		   this.initialize();
    	  }), 250);

    },    

	preventCache: function() {
		return new Date().valueOf();
	},
	
  	wait: function(message, width) {
		dojo.byId("waitMessage").innerHTML="<div class='dijitInline box-message'></div><div class='dijitInline'>&nbsp;" + message + "...</div>";
	    dojo.byId("waitMessage").style.width = width;
	    this.waitMessage.show();
	},
	
	/*
	iconTooltipMessage: function(node, iconClass, message) {
		if(dojo.isString(node)) node = dojo.byId(node);
		dijit.focus(node);
		node.focus();
		dijit.showTooltip('<div class="' + iconClass + '"><div>' + message + '</div></div>', node, []);
		var blur = dojo.connect(node, "onblur", function() {
			dijit.hideTooltip(node);
			dojo.disconnect(blur);
		});
	},
	*/
	iconTooltipMessage: function(node, iconClass, message) {
		if(dojo.isString(node)) node = dojo.byId(node);
		dijit.focus(node);
		node.focus();
		dijit.showTooltip('<div class="' + iconClass + '"><div>' + message + '</div></div>', node, []);
		var blur = dojo.connect(node, "onBlur", function() {
			dijit.hideTooltip(node);
			dojo.disconnect(blur);
		});
	}, 
  
  hideToolTip: function(id) {
    // console.log (id);
    dijit.hideTooltip(dojo.byId(id));
  },

  
	warnTooltipMessage: function(node, message) {
		this.iconTooltipMessage(node, "icon-warn-tooltip", message);
	},
	
	noSort: function(index){ 
		 return false;
	},
	
	onFocus: function(id){
    var dato = dojo.byId(id).value;
     dijit.byId(id).attr('value',"");	
     dijit.byId(id).attr('value',dojo.trim(dato));	
  },

   
	onKeyUpNumber: function(val){
    var dato = dojo.byId(val.id).value;
//    event = event || window.event; 
//    if (typeof (event) == "undefined"){
          if (dojo.trim(dato).length >10){
              if (dojo.trim(dato).indexOf('.') > 0){
              }else{
               dijit.byId(val.id).attr('value',"");	
               dijit.byId(val.id).attr('value',dojo.trim(dato).substring(0,10));
               }	
              return;	        
          }
//    }else{
/*      if (!(190== event.keyCode) ){
          if (dojo.trim(dato).length >10){
              if (dojo.trim(dato).indexOf('.') > 0){
              }else{
               dijit.byId(val.id).attr('value',"");	
               dijit.byId(val.id).attr('value',dojo.trim(dato).substring(0,10));
               }	
              return;	        
          }
      }
    }
*/
  },

      roundNumber: function(number, digits) {
                   var multiple = Math.pow(10, digits);
                   var rndedNum = Math.round(number * multiple) / multiple;

                   return rndedNum;
     } ,
  
     showHiddenDiv: function(node,show) {
     	if (show == true) { //Mostrar
	       node.style.display = "";
      } else { //Ocultar
        	node.style.display = "none";
     	}
    }
          
});
}
