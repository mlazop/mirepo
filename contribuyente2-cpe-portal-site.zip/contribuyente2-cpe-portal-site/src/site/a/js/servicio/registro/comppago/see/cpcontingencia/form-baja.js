
	var $selTipoComprobante = $('#selTipoComprobante');	
	var $txtSerie = $("#txtSerie");
	var $txtNumero = $("#txtNumero");
	var $btnValidarBaja = $("#btnValidarBaja");		
	var $formBaja = $("#form-baja");	
	
	
	$('text,select').bind('change', function() {$('#mensajeRetorno').text(''); });	
	$('text,select').bind('click', function() { $('#mensajeRetorno').text(''); });	
	$('#txtSerie').on('change', function(){ $('#mensajeRetorno').text(''); });	
	$('#txtNumero').on('change', function(){ $('#mensajeRetorno').text(''); });	
	
/*$('#txtSerie, #txtNumero').click(function() { 

alert('clik2');
});	
*/	
	
	$formBaja.validate({
        rules: {
            txtSerie: { required: true}, 
            txtNumero: { required: true} 			
        },
        messages: {
			txtSerie: {
				required: "Debe ingresar un valor para la serie"
			},
			txtNumero: {
				required: "Debe ingresar un valor para el n\u00FAmero"
			}
        },
        submitHandler: function(form){
            $modalPreloader.modal('show');
			validarBaja(form);		
		}
			
    });		
	
	

	 function validarBaja(form){
       	 
		 
		//console.log("$entornoApp:"+$entornoApp);
		 
        var url = 'baja.do?action=validar'; 	
		var formData=$(form).serializeObject();
	
		
      $.ajax({
        url: url,
        type: "POST",
        data: formData,
        dataType: 'json',
        success: function(data) {
			
			//alert("retornado");
			
			

          if(data.estado == '0'){ 
//            alert(data.mensaje);           
			$('#mensajeRetorno').text(data.mensaje);
            return; 
          }
/*
         if (data.estado == '2') {
				alert('El vendedor debe ser mayor de edad');
				 return;
         }

	  
		  
		  if (typeof data.estado == 'undefined'){
				$txtDocumento.data('pivot-valid', '0');
				$txtDocumento.val("");
				alert('El DNI ingresado no es v\u00E1lido');
            return;
          } */
		  


        },
		
        error: function () {
          alert('error');
        },
        complete: function () {	
			$modalPreloader.modal('hide');		  
        }
      });
    }		
	