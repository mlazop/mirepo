(function(window, $, _) {
	
	
			$(document).ready(function() { 
    $('#mostrar-factura').click(function (e) {
        //prevents re-size from happening before tab shown
        e.preventDefault();
          
        //fire re-size of footable
        $('.footable').trigger('footable_resize'); 
    });
	
	
	
});
	
	
	
    /*
     * :::: CONTAINERS :::: END
     */
    // Notese como se reciclan los selectores para hacer el menor
    // numero de consultas al DOM.
 
    var $containerBusqueda = $("#paso-1");
    var $containerPreview = $("#preliminar-factura");
 
    var $formEmail = $("#email-send");
    var $formBusqueda = $containerBusqueda.find('form');
    var $formByPass = $("#bypassForm");
    var $formNotaDebito = $("#formNotaDebito");
    var $formNotaDebitoDetalles = $("#formNotaDebitoDetalles");
    var $btnMostrarFactura = $("#mostrar-factura");
    var $btnVolverFactura = $("#btnVolverFactura");
    var $modalPreloader = $('#modalPreloader');
    var $modalMensajes = $('#modalMensajes');
 



    $btnMostrarFactura.on('click', function (e) {
        $containerPreview.removeClass('hidden')
        $containerBusqueda.addClass('hidden');
    })

       $btnVolverFactura.on('click', function (e) {
        $containerBusqueda.removeClass('hidden')
        $containerPreview.addClass('hidden');
    })

	var $txtBoleta = $('#txtBoleta');
	$txtBoleta.change(function() {
		$txtBoleta.val($txtBoleta.val().replace(/^0+/, ''));
	});
   
    $formNotaDebito.validate({
        debug: true,

        rules: {
           
            txtBoleta: {
                 required: true,
                 number: true,
                 minlength: 1
            }
        },
        /*** FIX ATTEMPT **/
        invalidHandler: function (event, validator) {
            var offset = $(validator.errorList[0].element).offset();
            $(window).scrollTop(offset.top - 30);
        },
        /*** END / FIX ATTEMPT **/


         submitHandler: function (form) {
                
              $modalPreloader.modal('show');
                var formData = $(form).serializeObject();
                var url = 'emitirNCBVEResp.do?action=validarComprobante';
				var url_redirigir='emitirNCBVEResp.do?action=verDatosIngreso';
            $.ajax({
                method: 'post',
                url: url,
                data: formData,
                dataType: 'json',
                success: function (data) {
                               
                             
                             var msj=data.messageError;
								$('#divMensaje').text(msj);
									
                              
                                 if ( (data.codeError == 1) && (!!msj) )
								
								{
                                    $modalMensajes.modal('show');
									
									
								}
								
								
                               else if ( (data.codeError == 4) && (!!msj) )
									
									{
									
										 $modalMensajes.modal('show');
									
									}
									

                               else if ( (data.codeError == 9) && (!!msj) )
                                    {
                                        $modalMensajes.modal('show');
						
										$('#btnSistema').click(function(){
												 
												window.location.href = url_redirigir;
											});
                                    }
                                else if ( data.codeError == 0)
                                    
									{
                                         
													 
													window.location.href = url_redirigir;
												
                                    }
                                 
                                else
								
									{
										   console.log(msj);
                                    } 

								
                                     


                              
                               
                              
                },
                error: function () {
                                
                                alert('Ha ocurrido un error por favor intentelo dentro de unos minutos.');
                },

                 complete: function () 

                                       {
                                          $modalPreloader.modal('hide');
                                         
                                       }
            });
        }
    });

    

    $formNotaDebitoDetalles.validate({
        debug: true,
        rules: {
           
            txtMotivo: {
                 required: true,
                 minlength: 5
            }
        },
        /*** FIX ATTEMPT **/
        invalidHandler: function (event, validator) {
            var offset = $(validator.errorList[0].element).offset();
            $(window).scrollTop(offset.top - 30);
        },
        /*** END / FIX ATTEMPT **/
         submitHandler: function (form) {
          form.submit();
        }
    });







    /*
     * :::: FORM VALIDATE :::: / END
     */
 
    $formEmail.validate(_.extend(window._validatorWallSettings, {
        rules: {
            txtEmail: {
                required: true,
                email: true,
                regex: /\b[A-Z0-9._%+-]+@[A-Z0-9.-]+\.[A-Z]{2,4}\b/i
            }
        },
        submitHandler: function(form) {
            var formData = $(form).serializeObject();
            var url = 'emitirNCBVEResp.do?action=enviarCorreo';
            $.ajax({
                method: 'post',
                url: url,
                data: formData,
                success: function() {
 
                   var msj='El correo ha sido enviado.';
				   $('#divMensaje').text(msj);
				   $modalMensajes.modal('show');
                   $("#txtEmail").val();
                },
                error: function() {
                    alert('Se presento un problema, por favor intentelo luego de  unos minutos.');
                }
            });
        }
    }));
 
    /*
     * :::: SETUP :::: START
     */
 
    $modalPreloader.modal({
        backdrop: 'static',
        keyboard: false,
        show: false
    });
 
   // $containerGenerar.find('[data-toggle="popover"]').popover()
 
    
  
$(".number").keydown(function (e) {
           // Permite: backspace, delete, tab, escape, enter and . (190)
           if ($.inArray(e.keyCode, [46, 8, 9, 27, 13, 110]) !== -1 ||
               // Permite: Ctrl+A
               (e.keyCode == 65 && e.ctrlKey === true) ||
               // Permite: home, end, left, right
               (e.keyCode >= 35 && e.keyCode <= 39)) {
               // solo permitir lo que no este dentro de estas condiciones es un return false
               return;
           }
           // Aseguramos que son numeros
           if ((e.shiftKey || (e.keyCode < 48 || e.keyCode > 57)) && (e.keyCode < 96 || e.keyCode > 105)) {
               e.preventDefault();
           }
       });



var $tabla = $("#table");

   $tabla.footable();

    //$btnBuscar.hide();
    //$btnValidar.hide();
 
    /*
     * :::: SETUP :::: / END
     */
    
    $("[data-toggle]").on('click', function (e) {
        e.preventDefault();
    });
 
})(window, jQuery, _);
