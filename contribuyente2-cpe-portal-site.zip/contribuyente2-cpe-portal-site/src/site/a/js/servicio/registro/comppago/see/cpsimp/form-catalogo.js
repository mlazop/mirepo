//(function(window, $, _){
/*
 * <!-- 30/10/2015 03:48 -->

 */
    var $formCatalogo = $("#form-catalogo");

    

    
    var $txtCodigo = $formCatalogo.find("#txtCodigo");
    var $txtDescripcion = $formCatalogo.find("#txtDescripcion");



  




    

    

    var $_ambosValido = $formCatalogo.find("#ambosValido");




    var $formRegistroProductos = $("#form-modal-registro-productos");


    var $txtCodigo_prod =$formRegistroProductos.find("#txtCodigo");
    var $txtDescripcion_prod = $formRegistroProductos.find("#txtDescripcion");
    var $selTipo_prod = $formRegistroProductos.find("#selTipo");
    var $selUnidad_prod = $formRegistroProductos.find("#selUnidad");
    var $txtPen_prod = $formRegistroProductos.find("#txtPen");
    var $txtUsd_prod = $formRegistroProductos.find("#txtUsd");
    var $txtEur_prod = $formRegistroProductos.find("#txtEur");
    var $txtGbp_prod = $formRegistroProductos.find("#txtGbp");
    var $txtYen_prod = $formRegistroProductos.find("#txtJpy");
    var $txtChf_prod = $formRegistroProductos.find("#txtChf");
    var $txtSec_prod = $formRegistroProductos.find("#txtSek");
    var $txtCad_prod = $formRegistroProductos.find("#txtCad");


    var $btnNuevoProducto=$("#btnNuevoProducto");



    var $formEditarProductos = $("#form-modal-editar-productos");
    var $txtCodigo_edit =$formEditarProductos.find("#txtCodigo");
    var $txtDescripcion_edit = $formEditarProductos.find("#txtDescripcion");
    var $selTipo_edit = $formEditarProductos.find("#selTipo");
    var $selUnidad_edit = $formEditarProductos.find("#selUnidad");
    var $txtPen_edit = $formEditarProductos.find("#txtPen");
    var $txtUsd_edit = $formEditarProductos.find("#txtUsd");
    var $txtEur_edit = $formEditarProductos.find("#txtEur");
    var $txtGbp_edit = $formEditarProductos.find("#txtGbp");
    var $txtYen_edit = $formEditarProductos.find("#txtJpy");
    var $txtChf_edit = $formEditarProductos.find("#txtChf");
    var $txtSec_edit = $formEditarProductos.find("#txtSek");
    var $txtCad_edit = $formEditarProductos.find("#txtCad");








    var $seccionOtrasMonedas = $('.otras-monedas');

    var $btnEliminar = $(".remover");

     var $btnEditar = $(".editar");

    var $modalEditarProducto = $("#modal-editar-producto");
    var $modalRegistroProducto = $("#modal-registro-productos");


 /// quickfix 14-10-2015
    function algunInputMonedaMenos (self) {
        var moneyInputs = $(".square-addon").parent().find('input');
        if(self)
            moneyInputs = moneyInputs.not(self);
        return [].some.call(moneyInputs, function(e){ return !!e.value });
    }
    /// end - quickfix 14-10-2015

    var _validateRegistroEditarSetup = {
        rules: {
            txtCodigo: {
                required: true,
                maxlength: 15,
                validStr: true
            },
            txtDescripcion: {
                required: true,
                maxlength: 200,
                validStr: true
            },
            selTipo: {
                required: true,
            },
            selUnidad: {
                required: true,
            },
            /// quickfix 14-10-2015
            txtPen: {
                required: function () {
                    return !algunInputMonedaMenos('#txtPen');
                },
                number: true,
                lessThan: function () {
                    return !algunInputMonedaMenos('#txtPen') ? 999999999999.9999999999 : false;
                },
                moreThan: function () {
                    return !algunInputMonedaMenos('#txtPen') ? 0 : false;
                }
            },
            txtUsd: {
                number: true,
            },
            txtEur: {
                number: true,
            },
            txtCad: {
                number: true,
            },
            txtGbp: {
                number: true,
            },

            txtJpy: {
                number: true,
            },

             txtSek: {
                number: true,
            },

             txtChf: {
                number: true,
            },
            /// end - quickfix 14-10-2015




        },
        messages: {
            txtCodigo: {
                required: "Ingrese el c&oacute;digo",
                maxlenght: "S&oacute;lo se permiten 15 caracteres para el c&oacute;digo",
                validStr: "El formato del c&oacute;digo no es v&aacute;lido",
                
                   
            },

            txtDescripcion: {
                required: "Ingrese la descripci&oacute;n",
                maxlenght: "S&oacute;lo se permiten 200 caracteres para la descripci&oacute;n",
                validStr: "El formato de la descripci&oacute;n no es v&aacute;lido",
                
                   
            },


            selTipo: {
                required: "Seleccione el tipo de servicio"
                   
            },

            selUnidad: {
                required: "Seleccione la unidad de medida"
                   
            },

            txtPen: {
                required: "Ingrese un valor en el campo moneda",
                moreThan: "El monto ingresado es incorrecto",
                number: "Verifique el valor de la moneda PEN",
                
                   
            },

            txtUsd: {
                number: "Verifique el valor de la moneda USD"
            },
            txtEur: {
                number: "Verifique el valor de la moneda EUR"
            },
            txtCad: {
                number: "Verifique el valor de la moneda CAD"
            },
            txtGbp: {
                 number: "Verifique el valor de la moneda GBP"
            },

            txtJpy: {
                 number: "Verifique el valor de la moneda JPY"
            },

             txtSek: {
                 number: "Verifique el valor de la moneda SEK"
            },

             txtChf: {
                 number: "Verifique el valor de la moneda CHF"
            },

            





        }
    }

    $('.square-addon').on('click', function (e) {
      $(e.target).removeClass('disabled');
    })
    $('.disable-currency').on('click', function (e) {
      $(e.target).closest('.btn').parent().find('.square-addon').addClass('disabled');
    })
    
    $txtCodigo.add($txtDescripcion).on('change keyup', function (e) {
        $_ambosValido.val((!!$txtCodigo.val() | !!$txtDescripcion.val()) ? "valid" : "").trigger('change');
    })


    $btnEliminar.on('click', function  (e) {
        if(!confirm('�Seguro de eliminar el registro seleccionado?')){
            e.preventDefault();
            return;
        }

        
        id=$(this).closest('tr').attr('id');
        $(this).closest('tr').remove();
        var url = "catalogo.do?action=eliminarCatalogo";
        var data = {txtCodigo:id}
        $.post(url, data).success(function (data) {
            
             window.location.href = "catalogo.do";

        }).error(function (reason) {
           
           alert('Disculpe, su producto no ha podido ser eliminado, intentelo nuevamente.');
        });
    })





    	$btnNuevoProducto.on('click',function(e) {


    		
    	$modalRegistroProducto.find(':input').val('');
        $selTipo_prod.val('TI01');




    	})


        $btnEditar.on('click', function  (e) {
        




        codigo=$(this).attr('data-codigo');

       

        descripcion=$(this).attr('data-descripcion');
        tipo=$(this).attr('data-tipo');
        unidad=$(this).attr('data-unidad');
        
        pen=$(this).attr('data-pen');
        eur=$(this).attr('data-eur');
        
        usd=$(this).attr('data-usd');
        gbp=$(this).attr('data-lib');

        jpy=$(this).attr('data-yen');
        chf=$(this).attr('data-cor');
        sec=$(this).attr('data-fra');

        
        cad=$(this).attr('data-cad');        
        


        $txtCodigo_edit.val(codigo);
        $txtDescripcion_edit.val(descripcion);
        $selTipo_edit.val(tipo);
        $selUnidad_edit.val(unidad);
        $txtPen_edit.val(pen);
        $txtEur_edit.val(eur);
        $txtUsd_edit.val(usd);
        $txtGbp_edit.val(gbp);   
        $txtYen_edit.val(jpy);
        $txtChf_edit.val(chf);
        $txtSec_edit.val(sec);
        $txtCad_edit.val(cad);        

                     

     



    })












    $('.footable').footable();


    $('.mostrar-monedas').on('click', function (e) {
        var $self = $(this).closest('.btn'); // .parent().parent().addClass('hidden');
        var $icon = $self.find('i')
        if($icon.hasClass('glyphicon-chevron-down'))
            $icon.addClass('glyphicon-chevron-up').removeClass('glyphicon-chevron-down')
        else
            $icon.addClass('glyphicon-chevron-down').removeClass('glyphicon-chevron-up')

        $seccionOtrasMonedas.toggleClass('hidden');
    })


    $formCatalogo.validate(_.extend(window._validatorWallSettings, {
        debug: true,
        ignore: 'button',
        rules: {
            txtCodigo: {
                maxlength: 15,
                minlength: 1,
                validStr: true
            },
            txtDescripcion: {
                maxlength: 200,
                minlength: 3,
                validStr: true
            },
            ambosValido: {
                required: true
            }
        },
        // el minlength de codigo es 1  y del de descripcion es 3 
        // estos mensajes estan aqui porque son d&iacute;n&aacute;micos respecto al html
        messages: {
            ambosValido: {
                required: "Por favor ingrese un criterio de b&uacute;squeda",
            },
            txtCodigo: {
                maxlength: "El n&uacute;mero m&aacute;ximo de caracteres es 15",
                minlength: "El n&uacute;mero m&iiacute;nimo de caracteres es 1",
                validStr: "Verifique el c&oacute;digo",
            },
            txtDescripcion: {
                maxlength: "El n&uacute;mero m&aacute;ximo de caracteres ingresados es 200",
                minlength: "El n&uacute;mero m&iacute;nimo de caracteres es 3",
                validStr: "Verifique la descripci&oacute;n"
            }
        },
        submitHandler: function(form) {
            console.log('valid-consulta-catalogo')
            form.submit();
        }
    }));

     $formRegistroProductos.validate(_.extend(window._validatorWallSettings, _validateRegistroEditarSetup, {
        debug: false,
       







        submitHandler: function (form) {
            console.log('valid-registrar-producto')
            
            $modalRegistroProducto.modal('toggle');
            //$modalRegistroProducto.find(':input').val('');


            var codigo= $txtCodigo_prod.val();
            var descripcion=$txtDescripcion_prod.val();


            var selTipo=$selTipo_prod.val();
            var selUnidad=$selUnidad_prod.val();


            var txtPen=$txtPen_prod.val();
            var txtUsd=$txtUsd_prod.val();
            var txtEur=$txtEur_prod.val();
            var txtGbp=$txtGbp_prod.val();
            var txtYen=$txtYen_prod.val();
            var txtChf=$txtChf_prod.val();
            var txtSec=$txtSec_prod.val();
            var txtCad=$txtCad_prod.val()






             $.ajax({
                url: 'catalogo.do?action=agregarCatalogo',
              
                method: 'post',
                dataType: 'json',
               
                  data:{ txtCodigo:codigo,txtDescripcion:descripcion,selTipo:selTipo, selUnidad:selUnidad, txtPen:txtPen, txtUsd:txtUsd, txtEur:txtEur, txtGbp:txtGbp,txtJpy:txtYen,
                       txtChf:txtChf, txtCad:txtCad,txtSec:txtSec  },

                success: function(data){
                    
                  alert(data.success);
              

                  
                  

                },
                error: function( jqXhr, textStatus, errorThrown ){
                    alert('Disculpe, su producto no ha podido ser registrado, intentelo nuevamente.');
                }
            });


           
        }
    }));

    $formEditarProductos.validate(_.extend(window._validatorWallSettings, _validateRegistroEditarSetup, {
        debug: true,
        submitHandler: function (form) {
            console.log('valid-editar-producto')
            $modalEditarProducto.modal('hide');
           

            var txtcodigo=$txtCodigo_edit.val();
            var descripcion=$txtDescripcion_edit.val();


            var selTipo=$selTipo_edit.val();
            var selUnidad=$selUnidad_edit.val();


            var txtPen=$txtPen_edit.val();
            var txtUsd=$txtUsd_edit.val();
            var txtEur=$txtEur_edit.val();
            var txtGbp=$txtGbp_edit.val();
            var txtYen=$txtYen_edit.val();
            var txtChf=$txtChf_edit.val();
            var txtSec=$txtSec_edit.val();
            var txtCad=$txtCad_edit.val();



            $.ajax({
                url: 'catalogo.do?action=modificarCatalogo',
              
                  method: 'post',
                dataType: 'json',
                
                   data:{ txtCodigo:txtcodigo,txtDescripcion:descripcion,selTipo:selTipo, selUnidad:selUnidad, txtPen:txtPen, txtUsd:txtUsd, txtEur:txtEur, txtGbp:txtGbp,txtJpy:txtYen,
                       txtChf:txtChf, txtCad:txtCad,txtSec:txtSec  },


                success: function( data, textStatus, jQxhr ){
                    
                  alert(data.success);

                   window.location.href = "catalogo.do";

                  

                },
                   
                error: function(xhr, textStatus, error){
                  
                       alert('Disculpe, su producto no ha podido ser registrado, intentelo nuevamente.');
              }
                
                   
            });




        }
    }));




          function soloNumeros(e){
        var key = window.Event ? e.which : e.keyCode
        return (key >= 48 && key <= 57)
}


 function soloLetrasNumerosEspacios(e){
       key = e.keyCode || e.which;
       tecla = String.fromCharCode(key).toLowerCase();
       letras = " �����abcdefghijklmn�opqrstuvwxyz1234567890";
       especiales = "8-37-39-46";

       tecla_especial = false
       for(var i in especiales){
            if(key == especiales[i]){
                tecla_especial = true;
                break;
            }
        }

        if(letras.indexOf(tecla)==-1 && !tecla_especial){
            return false;
        }
    }

     

function SoloNumeroDecimal(e, field) {
    key = e.keyCode ? e.keyCode : e.which
    // backspace
    if (key == 8) return true
 
    // 0-9 a partir del .decimal  
    if (field.value != "") {
        if ((field.value.indexOf(".")) > 0) {
            //si tiene un punto valida dos digitos en la parte decimal
            if (key > 47 && key < 58) {
                if (field.value == "") return true
                //regexp = /[0-9]{1,10}[\.][0-9]{1,3}$/
                // INI PAS20211U210100041 AHUISA 
                //regexp = /[0-9]{2}$/
                regexp = /[0-9]{10}$/
                // FIN PAS20211U210100041 AHUISA 
                return !(regexp.test(field.value))
            }
        }
    }
    // 0-9 
    if (key > 47 && key < 58) {
        if (field.value == "") return true
        regexp = /[0-9]{10}/
        return !(regexp.test(field.value))
    }
    // .
    if (key == 46) {
        if (field.value == "") return false
        regexp = /^[0-9]+$/
        return regexp.test(field.value)
    }
    // other key
    return false
}


    //03:08 27/09/2015

//})(window, jQuery, _);