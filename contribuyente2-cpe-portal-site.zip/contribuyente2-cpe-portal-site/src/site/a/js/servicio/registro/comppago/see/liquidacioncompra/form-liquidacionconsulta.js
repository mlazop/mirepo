var tblLista = $("#tblLista");
var $txtFechaInicio = $("#txtFechaInicio");
var $txtFechaFin = $("#txtFechaFin");
var $formConsulta = $("#form-consulta");
var $selTipoDocumentoEmisor = $("#selTipoDocumentoEmisor");
var $txtDocumentoEmisor = $("#txtDocumentoEmisor");
var $txtSerie = $("#txtSerie");
var $txtNumero = $("#txtNumero");
var $selTipoDocumentoVendedor = $("#selTipoDocumentoVendedor");
var $txtDocumentoVendedor = $("#txtDocumentoVendedor");
var $btnVolver = $("#btnVolver");
var $btnVolverMenu = $("#btnVolverMenu");
var $modalPreloader = $('#modalPreloader');
var $hiddenNumSerie = $('#numSerie');
var $hiddenNumComp = $('#numComp');
var $hiddenNumArchivo = $('#numArchivo');
var $usuarioSunat = $("#usuarioSunat");
var usuarioSunat = parseInt($usuarioSunat.val());
var pagina ;
var $esAPP = $("#esAPP").val();

//console.log("$usuarioSunat:"+usuarioSunat);
//console.log("usuarioSunat:"+usuarioSunat);

var $fechaSimulacion = $("#fechaSimulacion").val();

//console.log("fechaSimulacion:"+$fechaSimulacion);


//var f = new Date();

var arrayfechaSimulacion = $fechaSimulacion.split("-");
/*

var dia = f.getDate();
if(dia<10) dia = "0"+dia;
var mes = (f.getMonth() +1);
if(mes<10) mes = "0"+mes;
*/

var fechaActual = arrayfechaSimulacion[0]+""+arrayfechaSimulacion[1]+""+arrayfechaSimulacion[2];
var fechaActual = parseInt(fechaActual);
var fechaInicio = 20200301;
var habilitarFisico = 0;

//console.log("fechaActual:"+fechaActual);
//console.log("fechaInicio:"+fechaInicio);
//console.log("habilitarFisico:"+habilitarFisico);

if(fechaActual<fechaInicio)
{
habilitarFisico = 1;	
}

//console.log("habilitarFisico:"+habilitarFisico);




	
	if( isMobile.any() ){ //si es movil
	}else{// si no es movil
        
	}
	
	
	if( isMobile.any()  && $esAPP=="1"){ //si es movil
		pagina = 'consultaliquidacion.htm';
	}else{// si no es movil
		pagina = 'consultaliquidacion.do';
		$btnVolverMenu.addClass('hidden');		
	}	
	
	//console.log("$esAPP:"+$esAPP);
	
	if(isMobile.iOS() ){
	//$("#container2").css({"width": "380px"});
	}
	
	

$divSelTipoDocumentoEmisorLabel = $("#div-selTipoDocumentoEmisor-label");

if (usuarioSunat == 1) {
    $divSelTipoDocumentoEmisorLabel.show();
} else {
    $divSelTipoDocumentoEmisorLabel.hide();	
	
	if(habilitarFisico==0){
		$txtSerie.attr("readonly","readonly");
		$txtSerie.val("E001");				
	}
	
}


var _tipoDocumentoEmisor = {
    "4": "RUC"
};

_.each(_tipoDocumentoEmisor, function(v, k) {
    $('<option/>', {
        value: k,
        selected: (k == '4')
    }).html(v).appendTo($selTipoDocumentoEmisor);
});

var _tipoDocumentoVendedor = {
	"1": "DNI",
	"4": "CARNET DE EXTRANJERIA",
	"7": "PASAPORTE"
	/*,
    	"4": "RUC"*/
}

_.each(_tipoDocumentoVendedor, function(v, k) {
    $('<option/>', {
        value: k,
        //selected: (k == '1')
    }).html(v).appendTo($selTipoDocumentoVendedor);
});


$btnVolver.on('click', function(e) {
    $('#root-panels').removeClass('hidden')
    $("#panel-liquidacion-consulta").addClass('hidden');
	
	if(habilitarFisico==0)	$txtSerie.val("E001");
	
	
	$txtNumero.val("");	
	$txtDocumentoVendedor.val("");
	$txtDocumentoEmisor.val("");
});




$formConsulta.validate(_.extend(window._validatorWallSettings, {
    rules: {
        selTipoDocumentoEmisor: {
            required: {
                depends: function(element) {
                    if (usuarioSunat == 1) {
                        return true;
                    } else {
                        return false;
                    }
                }
            }
        },
        txtDocumentoEmisor: {
            required: {
                depends: function(element) {
                    if (usuarioSunat == 1) {
                        return true;
                    } else {
                        return false;
                    }
                }
            },

            validRUC: {
                depends: function(element) {
                    if (usuarioSunat == 1) {
                        return true;
                    } else {
                        return false;
                    }
                }
            }
        },
        txtSerie: {
            minlength: 4
        },
        txtNumero: {
            number: true,
            maxlength: 8
        },
        selTipoDocumentoVendedor: {
            required: false
        },
        txtDocumentoVendedor: { 
					required: function () {
							var tipo = $selTipoDocumentoVendedor.val();
							if (tipo == '1'||tipo == '4' || tipo == '7') {
								return true;
							} else {
								return false;
							}
						}, 
					minlength: function () {
							var tipo = $selTipoDocumentoVendedor.val();
							if (tipo == '1') {
								return 8;
							} else if (tipo == '4' || tipo == '7') {
								return 1;
							} else {
								return 0;
								
							}
						}, 
					maxlength: function () {
							var tipo = $selTipoDocumentoVendedor.val();
							if (tipo == '1') {
								return 8;
							} else if (tipo == '4' || tipo == '7') {
								return 12;
							} else {
								return 0;
								
							}
						}, 
					number: false
					},
        txtFechaInicio: {
            comparaSiFechaInicioMenorIgualFechaFin: ["#txtFechaInicio", "#txtFechaFin"],
            restaFechas: ["#txtFechaInicio", "#txtFechaFin"]
        }
    },
    messages: {
        selTipoDocumentoEmisor: {
            required: "Debe seleccionar el tipo de documento del emisor"
        },

        txtDocumentoEmisor: {
            required: "Debe ingresar el RUC del emisor",
            validRUC: "El RUC debe ser num&eacute;rico de 11 d&iacute;gitos"
        },
        txtSerie: {
            minlength: "La serie ingresada no tiene el formato correcto, solo 4 caracteres"
        },
        txtNumero: {
            number: "El n&uacute;mero de liquidaci&oacute;n de compra debe ser num&eacute;rico de hasta 8 d&iacute;gitos",
            maxlength: "El n&uacute;mero de liquidaci&oacute;n de compra debe ser num&eacute;rico de hasta 8 d&iacute;gitos"
        },
		txtDocumentoVendedor: {
			number: "Debe ingresar solo valores num\u00e9ricos para el campo DNI",
			required: "Debe ingresar un valor para el campo n\u00FAmero de documento",
			minlength: function () {
						var tipo = $selTipoDocumentoVendedor.val();
						if (tipo == '1') {
							return "Debe ingresar 8 d&iacute;gitos para el campo n\u00FAmero de documento";
						} 
					}
		},
        selTipoDocumentoVendedor: {
            required: "Debe seleccionar el tipo de documento del emisor"
        },
        txtFechaInicio: {
            comparaSiFechaInicioMenorIgualFechaFin: "La fecha de Inicio debe ser menor o igual que la fecha Fin",
            restaFechas: "El rango de consulta excede el plazo m&aacute;ximo permitido de 6 meses, seleccione otro rango de consulta"
        }
    },
    submitHandler: function(form) {
        actualizarDataTable();
    }
}));


function descargarPdf(numIdXml, numSerie, numComp, numRuc)  {
     $hiddenNumArchivo.val(numIdXml);
    $hiddenNumSerie.val(numSerie);
    $hiddenNumComp.val(numComp);
    /*
    var url = 'consultaliquidacion.do?action=descargarPDF'; 	
    descarga.action=url;
    descarga.submit();	*/
	var nombre=numRuc +"-04-"+numSerie+"-"+numComp;
    var url2 = pagina+'?action=descargarPDF&numArchivo=' + $hiddenNumArchivo.val() + '&numRuc=' + $txtDocumentoEmisor.val() + '&nombrePdf=' + nombre +'.pdf'; //&=documentoDescarga.pdf'
	
	if( isMobile.any() ){
		visorPdfDescarga(url2);
	}else{
		window.open(url2, '_blank');
	}
	
    
    return false;
}


function descargarXml(numIdXml, numSerie, numComp, numRuc) {
 $hiddenNumArchivo.val(numIdXml);
    $hiddenNumSerie.val(numSerie);
    $hiddenNumComp.val(numComp);
	var nombre=numRuc +"-04-"+numSerie+"-"+numComp;
    /*var url = 'consultaliquidacion.do?action=descargaComprobante'; 	
    descarga.action=url;
    descarga.submit();	 */
    var url2 = pagina+'?action=descargaComprobante&numSerie=' + $hiddenNumSerie.val() + '&numComp=' + $hiddenNumComp.val() + '&numRuc=' + $txtDocumentoEmisor.val() + '&nombrePdf=LC' + nombre+'.xml'; 
    
	if( isMobile.any() ){
		visorPdfDescarga(url2);
	}else{
		window.open(url2, '_blank');
	}
    return false;
}




		
		
function actualizarDataTable() {
    var url = pagina+"?action=cargarTabla";
    $modalPreloader.modal('show');
    var data = $formConsulta.serializeObject();
    $.post(url, data).success(function(response) {
        var data = response.retorno;
        var lista = data.lista;
        tblLista.DataTable().clear();
        tblLista.DataTable().destroy();
        if (lista.length != 0) {
            cargarDataTable(lista);
            $('#root-panels').addClass('hidden')
            $("#panel-liquidacion-consulta").removeClass('hidden');
			tblLista.DataTable().columns.adjust().responsive.recalc();
				if(isMobile.Android() ){
						tblLista.css({"width": "350px"});
				}
        } else {
            bootbox.alert("No se encontraron resultados");
        }
        $modalPreloader.modal('hide');
    }).error(function(reason) {
        $modalPreloader.modal('hide');
        bootbox.alert('Disculpe, no se ha podido realizar su consulta, intentelo nuevamente.');
    });
}


		

function cargarDataTable(lista) {
    tblLista.DataTable({
		responsive: true,
		bProcessing: true,
		bFilter: false,
		bSort: false,
		bAutoWidth: false,
		retrieve: true,		
		order: [],		
			language: {			
					processing: "Procesando...",
					lengthMenu: "Mostrar _MENU_ registros",
					emptyTable: 'No se encontraron registros',
					zeroRecords: 'No se encontraron registros',
					search: "Buscar:",
					sLoadingRecords: "Cargando...",
					infoFiltered: "(filtrado de un total de _MAX_ registros)",
					info: "Mostrando registros del _START_ al _END_ de un total de _TOTAL_ registros",
					infoEmpty: "Registros del 0 al 0 de un total de 0 registros",
					paginate: {
						"first": "Primero",
						"last": "�ltimo",
						"next": "Siguiente >",
						"previous": "< Anterior"
					}
				},
        data: lista,
        columns: [{
                data: function(row, type, val, meta) {
                    return row.nroruc;
                },
                sClass: 'text-left'
            },
            {
                data: function(row, type, val, meta) {
                    return row.numseriegre;
                },
                sClass: 'text-center'
            },
            {
                data: function(row, type, val, meta) {
                    return row.numgre;
                },
                sClass: 'text-left'
            },
            {
                data: function(row, type, val, meta) {
                    return (row.fecemision.substr(8, 2) + "/" + row.fecemision.substr(5, 2) + "/" + row.fecemision.substr(0, 4));
                },
                sClass: 'text-left',
				sTitle: "Fecha <br> Emisi&oacute;n"
            },            
			{
                data: function(row, type, val, meta) {
                    return buscarValorArray($.trim(row.coddociderecep),_tipoDocumentoIdentidad);
                },
                sClass: 'text-left',
				sTitle: "Tipo <br> documento"
            },
            {
                data: function(row, type, val, meta) {
                    return row.numdociderecep;
                },
                sClass: 'text-left',
				sTitle: "N&uacute;mero <br> documento"
            },
            {
                data: function(row, type, val, meta) {
                    return row.nombredestinatario;
                },
                sClass: 'text-left',
				sTitle: "Nombre <br> vendedor"
            },
            {
                data: function(row, type, val, meta) {
                    if (row.indestado == "0") {
                        return "ACEPTADA";
                    } else {
                        return "REVERTIDO";
                    }

                },
                sClass: 'text-left'
            },
            {
                data: function(row, type, val, meta) {
					var fecha = row.fecemision.substr(8, 2) + "/" + row.fecemision.substr(5, 2) + "/" + row.fecemision.substr(0, 4);
					var id = row.nroruc+"_"+row.numseriegre+"_"+row.numgre+"_"+row.numdociderecep+"_"+row.nombredestinatario+"_"+row.codmoneda+"_"+row.mtoimportetotal+"_"+fecha+"_"+row.coddociderecep;
					var tTable = "<img class='pagos' src='/a/imagenes/nuevo.gif' alt='Ver pagos' title='Ver pagos' value='"+id+"'/>";					
					return tTable;
                },
                sClass: 'text-center'
            },
            {
                data: function(row, type, val, meta) {
                    //return '<table><tr><td><button class="btn btn-danger btn-sm remover" onclick="descargarPdf(' + row.numidxml + ')">PDF</button></td><td><button class="btn btn-danger btn-sm remover" onclick="descargarXml(' + row.numidxml + ',\'' + row.numseriegre.trim().toUpperCase() + '\',' + row.numgre + ')">XML</button></td></tr></table>';
					
					var botonpdf = '<button class="btn btn-danger btn-sm remover" onclick="descargarPdf(\'' + row.numidxml + '\',\'' + row.numseriegre.trim().toUpperCase() + '\',\'' + row.numgre  + '\',\'' + row.nroruc + '\')">PDF</button>&nbsp;'
					
					var botonXML = '<button class="btn btn-danger btn-sm remover" onclick="descargarXml(\'' + row.numidxml + '\',\'' + row.numseriegre.trim().toUpperCase() + '\',\'' + row.numgre  + '\',\'' + row.nroruc + '\')">XML</button>';
					
					var boton = botonpdf;					
					if(!isMobile.any() ){
						var primeraLetra = row.numseriegre.charAt(0);
						//console.log("letra:"+primeraLetra);
						if(primeraLetra=='E' || primeraLetra == 'F' || primeraLetra == 'L'){
							boton = boton + botonXML;
						}	
					}else{
					
					}
					
					//console.log("boton:"+boton);					
					return boton;
/*					return '<button class="btn btn-danger btn-sm remover" onclick="descargarPdf(\'' + row.numidxml + '\',\'' + row.numseriegre.trim().toUpperCase() + '\',\'' + row.numgre  + '\',\'' + row.nroruc + '\')">PDF</button>&nbsp;<button class="btn btn-danger btn-sm remover" onclick="descargarXml(\'' + row.numidxml + '\',\'' + row.numseriegre.trim().toUpperCase() + '\',\'' + row.numgre  + '\',\'' + row.nroruc + '\')">XML</button>';*/
				       //return row.numdociderecep;
                },
                sClass: 'text-left',
				sTitle: "Descargar <br>PDF/XML"
            }
        ],
        searching: false,
        bLengthChange: false,
        "pageLength": 10
    });
}


$txtFechaFin.val(obtenerFecha(0));
$txtFechaInicio.val(obtenerFecha(-30));

var $modalDatepicker = $('#modal-datepicker');
var $datepicker = $modalDatepicker.find("#datepicker-placeholder");
var $datepickerHidden = $modalDatepicker.find("#datepicker-value");
var $btnCloseDatepicker = $modalDatepicker.find('#modal-datepicker-close');


var _CURR_DATE_PICKER = null;
$('.datepicker').on('click', function(e) {
    _CURR_DATE_PICKER = $(e.target);
    $modalDatepicker.modal('show');
});
$datepicker.datepicker({
    // endDate: new Date(),
    /*		showOn: "button",
    		endDate: '0d',
            startDate: '-2d'*/
    //maxDate:'1'
}).on('changeDate', function(e) {
    $datepickerHidden.val(e.format());
});
$btnCloseDatepicker.on('click', function(e) {
										 
	if($datepickerHidden.val()!=""){										 
		var selectedDate = $datepickerHidden.val();
		_CURR_DATE_PICKER.val(selectedDate).trigger('change');
		$datepickerHidden.val('');
		_CURR_DATE_PICKER = null;
		$modalDatepicker.modal('hide');
	}else{
		bootbox.alert("Haga click en la fecha deseada");	
	}
});

$('#butoncalendar1').on('click', function(e) {
    _CURR_DATE_PICKER = $(".datepicker");
    $modalDatepicker.modal('show');
});



var $modalDatepicker2 = $('#modal-datepicker2');
var $datepicker2 = $modalDatepicker2.find("#datepicker2-placeholder");
var $datepickerHidden2 = $modalDatepicker2.find("#datepicker2-value");
var $btnCloseDatepicker2 = $modalDatepicker2.find('#modal-datepicker2-close');

var _CURR_DATE_PICKER2 = null;

$datepicker2.datepicker({
    // endDate: new Date(),
    /*		endDate: '0d',
            startDate: '-2d'*/
    //maxDate:'1'
}).on('changeDate', function(e) {
    $datepickerHidden2.val(e.format());
});

$btnCloseDatepicker2.on('click', function(e) {
										  
	if($datepickerHidden2.val()!=""){											  
		var selectedDate = $datepickerHidden2.val();
		_CURR_DATE_PICKER2.val(selectedDate).trigger('change');
		$datepickerHidden2.val('');
		_CURR_DATE_PICKER2 = null;
		$modalDatepicker2.modal('hide');
	}else{
		bootbox.alert("Haga click en la fecha deseada");			
	}
});
$('#butoncalendar2').on('click', function(e) {
    _CURR_DATE_PICKER2 = $(".datepicker2");
    $modalDatepicker2.modal('show');
});


function visorPdfDescarga(url){
	creaDivBuzonDescarga();
	
	var metodo='GET';
	var param='';
	if(url.indexOf("&app=1")>-1){
		metodo='POST';
		url = url.replace("&app=1", "");
		param=url.substring(url.indexOf("?")+1, url.length);
		
		
		url = url.substring(0, url.indexOf("?"));
	}
	
	/////////			
	xhr = new XMLHttpRequest();
	xhr.open(metodo, url, true);
	
	if(metodo=='POST'){
		xhr.setRequestHeader("Content-type", "application/x-www-form-urlencoded");
	}

	xhr.responseType = 'blob';

	xhr.onload = function(e) {
	  if (this.status == 200) {
		blobBuzon = this.response;
		
		if(blobBuzon.size>500){
			//manda al workspace
			try{
				parent.postMessage("frameIniciadoBuzonWorkspace_"+url,'*');//*
			}catch(ex){
				try{
					window.parent.postMessage("frameIniciadoBuzonWorkspace_"+url,'*');//*
				}catch(ex){
				}
			}
			
		}else{
			bootbox.alert('[7.1] Error en la conectividad, tama�o del archivo incorrecto.');
			cierraDivBuzonDescarga();
		}
		
		
	  }else{
		  bootbox.alert('[1.'+this.status+'] Error en el servidor descargando archivo.');
		  cierraDivBuzonDescarga();
	  }
	};//fin onload
	
	
	
	xhr.onprogress = function(evt) {
		if (evt.lengthComputable){  
			var percentComplete = (evt.loaded / evt.total)*100;  
	   } 
	};//fin onprogress
	
	xhr.onabort = function(evt) {
	};//fin onabort
	
	

	xhr.onerror = function(e) {
	  bootbox.alert("[2." + e.target.status + "] Error en la conectividad.");
	  cierraDivBuzonDescarga();
	};//fin onerror

	
	if(metodo=='POST'){		
		xhr.send(param);
	}else{
		xhr.send();
	}
	
}
function creaDivBuzon(){
	//pdf
	divVisorPdr = document.createElement("div");
	divVisorPdr.setAttribute("id", "divBuzonVisorPdf"); 
	var u=window.location.href;	
	
	divVisorPdr.style.width = "100%";	
	divVisorPdr.style.height = "100%";	
	divVisorPdr.style.minWidth = "100%";	
	divVisorPdr.style.minHeight = "100%";	
	
	divVisorPdr.style.background = "white";
	divVisorPdr.style.color = "black";
	if(u.indexOf("cl-ti-iagenerador")>=0){	
		divVisorPdr.style.position = "fixed";
	}else{				
		divVisorPdr.style.position = "absolute";
	}
	divVisorPdr.style.left = "0px";
	divVisorPdr.style.top = "0px";
	divVisorPdr.style.zIndex = "999";
	divVisorPdr.style.border = "0px";
	divVisorPdr.style.textAlign = "center";
	divVisorPdr.style.overflow = "auto";
	
	//cerrar
	var divBuzonPdfCerrar = document.createElement("div");
	divBuzonPdfCerrar.setAttribute("id", "divBuzonPdfCerrar");
	divBuzonPdfCerrar.innerHTML= "<- Volver";
	divBuzonPdfCerrar.style.fontFamily  ="Arial";
	divBuzonPdfCerrar.style.fontSize ="15px";
	divBuzonPdfCerrar.style.fontWeight  ="bold";
	divBuzonPdfCerrar.style.textAlign  ="center";
	divBuzonPdfCerrar.style.backgroundColor="#CECECE";
	divBuzonPdfCerrar.style.color="#fff";
	divBuzonPdfCerrar.style.position = "fixed";
	divBuzonPdfCerrar.style.right = "5px";
	divBuzonPdfCerrar.style.top = "10px";	
	divBuzonPdfCerrar.style.padding = "10px 0px";	
	divBuzonPdfCerrar.style.width = "80px";
	divBuzonPdfCerrar.style.height = "20px";
	divBuzonPdfCerrar.style.boxSizing = "content-box";	
	divBuzonPdfCerrar.style.borderRadius  = "5px";
	divBuzonPdfCerrar.addEventListener('click', cierraDivBuzon);
	divBuzonPdfCerrar.addEventListener("touchstart", cierraDivBuzon);//ok//*
	divBuzonPdfCerrar.addEventListener("touchcancel", cierraDivBuzon);//ok//*
	divVisorPdr.appendChild(divBuzonPdfCerrar);
	
	
	//spinner	
	var imgSpinner = document.createElement("img");
	imgSpinner.src = "/a/imagenes/wait-big.gif";
	imgSpinner.style.display = "none";
	
	canvas = document.createElement("canvas");
	canvas.style.width = "100%";
	canvas.style.height = "100%";
	canvas.style.border = "0px";
	canvas.style.background="url(/a/imagenes/wait-big.gif) center center no-repeat";
		
	ctx = canvas.getContext('2d');
	divVisorPdr.appendChild(canvas);
	document.body.appendChild(divVisorPdr);
}


function creaDivBuzonDescarga(){
	//pdf descarga
	divVisorPdrDescarga = document.createElement("div");
	divVisorPdrDescarga.setAttribute("id", "divBuzonVisorPdfDescarga"); 
	var u=window.location.href;	
	
	divVisorPdrDescarga.style.width = "100%";	
	divVisorPdrDescarga.style.height = "100%";	
	divVisorPdrDescarga.style.minWidth = "100%";	
	divVisorPdrDescarga.style.minHeight = "100%";
	
	
	divVisorPdrDescarga.style.background = "white";
	divVisorPdrDescarga.style.color = "black";
	if(u.indexOf("cl-ti-iagenerador")>=0){	
		divVisorPdrDescarga.style.position = "fixed";
	}else{				
		divVisorPdrDescarga.style.position = "absolute";
	}
	divVisorPdrDescarga.style.left = "0px";
	divVisorPdrDescarga.style.top = "0px";
	divVisorPdrDescarga.style.zIndex = "999";
	divVisorPdrDescarga.style.border = "0px";
	divVisorPdrDescarga.style.textAlign = "center";
	divVisorPdrDescarga.style.overflow = "auto";
	
	//cerrar
	var divBuzonPdfCerrar = document.createElement("div");
	divBuzonPdfCerrar.setAttribute("id", "divBuzonPdfCerrar");
	divBuzonPdfCerrar.innerHTML= "Cancelar";
	divBuzonPdfCerrar.style.fontFamily  ="Arial";
	divBuzonPdfCerrar.style.fontSize ="15px";
	divBuzonPdfCerrar.style.fontWeight  ="bold";
	divBuzonPdfCerrar.style.textAlign  ="center";
	divBuzonPdfCerrar.style.backgroundColor="#CECECE";
	divBuzonPdfCerrar.style.color="#fff";
	divBuzonPdfCerrar.style.position = "fixed";
	divBuzonPdfCerrar.style.right = "5px";
	divBuzonPdfCerrar.style.top = "10px";	
	divBuzonPdfCerrar.style.padding = "10px 0px";	
	divBuzonPdfCerrar.style.width = "80px";
	divBuzonPdfCerrar.style.height = "20px";
	divBuzonPdfCerrar.style.boxSizing = "content-box";	
	divBuzonPdfCerrar.style.borderRadius  = "5px";
	divBuzonPdfCerrar.addEventListener('click', cierraDivBuzonDescarga);
	divBuzonPdfCerrar.addEventListener("touchstart", cierraDivBuzonDescarga);//ok//*
	divBuzonPdfCerrar.addEventListener("touchcancel", cierraDivBuzonDescarga);//ok//*
	divVisorPdrDescarga.appendChild(divBuzonPdfCerrar);
	
	var imgSpinner = document.createElement("img");
	imgSpinner.src = "/a/imagenes/wait-big.gif";
	imgSpinner.style.display = "none";
	
	canvas = document.createElement("canvas");
	canvas.style.width = "100%";
	canvas.style.height = "100%";
	canvas.style.border = "0px";
	canvas.style.background="url(/a/imagenes/wait-big.gif) center center no-repeat";		
		
	ctx = canvas.getContext('2d');
	divVisorPdrDescarga.appendChild(canvas);
	document.body.appendChild(divVisorPdrDescarga);
}
function cierraDivBuzon(){
	try{
		document.body.removeChild(document.getElementById("divBuzonVisorPdf"));
	}catch(err) {		
	}
}

function cierraDivBuzonDescarga(){
	try{
		document.body.removeChild(document.getElementById("divBuzonVisorPdfDescarga"));		
		try{
			xhr.abort();		
		}catch(err) {		
		}
	}catch(err) {		
	}
}

function listenerEventos(event){
	if (event.data == 'cerrarDescargaBuzon') {		
		cierraDivBuzonDescarga();
	}
}
if(window.addEventListener){
	addEventListener("message", listenerEventos, false);
}else{
	attachEvent("onmessage", listenerEventos);
}


var $modalPagos  = $("#modal-pagos");

var $tblPagos  = $("#tblPagos");


$(document).on('click', '.pagos',function (e) {
										   
										   
	$modalPagos.modal('show');										   
	
	//console.log("pagos:"+$(this).attr("value"));		
		
	var id = $(this).attr("value");

	
	var array =id.split("_");
	
	$ruc = array[0];
	$serie = array[1];
	$num_cp = array[2];
	$cod_cp = "04";	

	var url = pagina+"?action=obtenerPagos";
	$modalPreloader.modal('show');

    var data = {
        ruc: $ruc,
        serie: $serie,
        num_cp: $num_cp,
        cod_cp: $cod_cp		
    };	

	$.post(url, data).success(function(response) {
									   
		var data = response.retorno;
		var lista = data.lista;		
		
		$tblPagos.DataTable().clear();
		$tblPagos.DataTable().destroy();			
		cargarPagos(lista);
		if(isMobile.Android() ){
			$tblPagos.css({"width": "350px"});
		}
		$modalPreloader.modal('hide');
		
		}).error(function(reason) {
			$modalPreloader.modal('hide');
			bootbox.alert('Disculpe, No se puede obtener los pagos registrados anteriormente');
	});	

});
		

function cargarPagos(lista) {
	
	//console.log("cargarPagos");

	var config_pagos = {	
		responsive: true,
		bProcessing: false,
		bFilter: false,
		bSort: false,
		bAutoWidth: false,
		retrieve: true,		
		order: [],
		language: {
		processing: "Procesando...",
		lengthMenu: "Mostrar _MENU_ registros",
		emptyTable: 'No se encontraron registros',
		zeroRecords: 'No se encontraron registros',
		search: "Buscar:",
		sLoadingRecords: "Cargando...",
		infoFiltered: "(filtrado de un total de _MAX_ registros)",
		info: "Mostrando registros del _START_ al _END_ de un total de _TOTAL_ registros",
		infoEmpty: "Registros del 0 al 0 de un total de 0 registros",
		paginate: {
			"first": "Primero",
			"last": "�ltimo",
			"next": "Siguiente >",
			"previous": "< Anterior"
		}
	},
	data: lista,
	columns: [		  
			  
	          {
				  data: function(row, type, val, meta) {
					  return row.num_pago;
				  },
				  sClass: 'text-center',
			      sTitle: "Pago"
	          },
	          {
	        	  data: function(row, type, val, meta) {
					  //return (row.fechapago.substr(8, 2) + "/" + row.fechapago.substr(5, 2) + "/" + row.fechapago.substr(0, 4));
					  return row.fec_pago;				  
				  },
				  sClass: 'text-left',
				  sTitle: "Fecha"
	          },			  
	          {
	        	  data: function(row, type, val, meta) {
	        	  return buscarValorArray(row.cod_moneda,_monedaDescripcion);
				  },
				  sClass: 'text-left',
 				  sTitle: "Moneda"
				  },			
	          {
	        	  data: function(row, type, val, meta) {
	        	  return formatoMoneda(row.mto_pago);    
				  },
				  sClass: 'text-left',
				  sTitle: "Importe"
	          },
	          {
	        	  data: function(row, type, val, meta) {
	        	  return buscarValorArray(row.mdo_pago,_mediopago);
				  },
				  sClass: 'text-left',
				  sTitle: "Medio de<br> Pago"
	          }
	  
		  ],
		  searching: false,
		  bLengthChange: false,
		  "pageLength": 5
	};										 

    oTablePagos = $tblPagos.dataTable(config_pagos);
	
	   $('#tblPagos th').eq(4).css('white-space','normal'); //.addClass("formato_mediospago");
       $('#tblPagos td').eq(4).css('white-space','normal');//addClass("formato_mediospago");	
	
}




var $tipoComprobante = $("#tipoComprobante");	
var $labelTituloEmision = $("#labelTituloEmision");

//console.log("tipoEmision:"+$tipoComprobante.val());	

if($tipoComprobante.val()==1){//Eletronico		
	$labelTituloEmision.text("Reversi\u00F3n de Liquidaci\u00F3n de Compra");
}else{//fisico	
	$labelTituloEmision.text("Reversi\u00F3n de Liquidaci\u00F3n de Compra");
	//$labelTituloEmision.text("Eliminaci\u00F3n de Liquidaci\u00F3n de Compra F\u00EDsica");
}


if(isMobile.iOS() ){
	//$("#container2").css({"width": "100%"});
	
	   $("#container2").css({"width": window.screen.width});
	   $("#modal-pagos").css({"width": window.screen.width});	   
	   
	   $(".modal").css({"width": window.screen.width});        
	   $(".th").css({"width": "10%"});  
	   
	   //$(".wrapper-content").css({"padding": "20px 10px 20px 0px"});              
	   //$(".wrapper").css({"padding": "0px 20px 0px 0px"});
	
}


//////////////////////////////////////////////////////////////////////////////////////////////////////7777
//$txtDocumentoVendedor.val("514");
//$txtDocumentoEmisor.val("10215216409");

$selTipoDocumentoVendedor.on('change', function(e){											   
		//console.log("$selTipoDocumento.val():"+$selTipoDocumento.val());	
		$txtDocumentoVendedor.val("");	
		
		
		if($selTipoDocumentoVendedor.val()=="1"){
			//console.log("aqui 1");
			$txtDocumentoVendedor.attr('maxlength','8');
						
		}else if($selTipoDocumentoVendedor.val()=="4"){
			//console.log("aqui 4");
			$txtDocumentoVendedor.attr('maxlength','12');
		
		}else if($selTipoDocumentoVendedor.val()=="7"){
			//console.log("aqui 7");
			$txtDocumentoVendedor.attr('maxlength','12');
			
		}				
		
    });	
	
	$txtDocumentoVendedor.attr('class','form-control xput');	

	$txtDocumentoVendedor.attr('maxlength','8');
	
		$('.xput').on('input', function () { 
	
		if($selTipoDocumentoVendedor.val()=="1"){
			//console.log("en metodo 1");
			this.value = this.value.replace(/[^0-9]/g,'');
		}else{
			var regex = new RegExp("^[a-zA-Z0-9 ]+$");
			//console.log("en metodo 2");
		    var key = String.fromCharCode(!event.charCode ? event.which : event.charCode);
		    if (!regex.test(key)) {
			  event.preventDefault();
			 return false;
		 }
			
		}	
    });