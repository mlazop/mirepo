// Inicializando  Variables
var tblLista = $("#tblLista");
var $codBien = $("#codBien");
var $selGrupo = $("#selGrupo");
var $selSegmento = $("#selSegmento");
var $selFamilia = $("#selFamilia");
var $selClase = $("#selClase");
var $selProducto = $("#selProducto");
var $formModalBienes = $("#form-modal-bienes");
var $modalBienes = $("#modal-bienes");
var $btnModalBien = $("#open-modal-bien");
var $tablaBien = $("#tabla-bien");
var $txtDescripcion = $("#txtDescripcion");
var $btnVolver = $("#btnVolver");
var $codigoTemporal = "";

var isMobile = {
		Android: function() {
			return navigator.userAgent.match(/Android/i);
		},
		BlackBerry: function() {
			return navigator.userAgent.match(/BlackBerry/i);
		},
		iOS: function() {
			return navigator.userAgent.match(/iPhone|iPad|iPod/i);
		},
		Opera: function() {
			return navigator.userAgent.match(/Opera Mini/i);
		},
		Windows: function() {
			return navigator.userAgent.match(/IEMobile/i);
		},
		any: function() {
			return (isMobile.Android() || isMobile.BlackBerry() || isMobile.iOS() || isMobile.Opera() || isMobile.Windows());
		}
	};	
	
		if( isMobile.any() ) //si es movil
	{
	}else{// si no es movil
		//alert("ocultando boton");
        $btnVolver.addClass('hidden');		
	}
	
var _afectacionIGV = {
    "1": "Gravado",
    "2": "Exonerada",
    "3": "Inafecto"
}

// ==============================================================
var jsonGrupos = (function() {
    var json = null;
    $.ajax({
        async: false,
        global: false,
        url: '/a/js/servicio/registro/comppago/see/liquidacioncompra/json/Grupo.json',
        dataType: 'JSON',
        success: function(data) {
            json = data;
        }
    });
    return json;
})();

var jsonSegmentos = (function() {
    var json = null;
    $.ajax({
        async: false,
        global: false,
        url: '/a/js/servicio/registro/comppago/see/liquidacioncompra/json/Segmento.json',
        dataType: 'JSON',
        success: function(data) {
            json = data;
        }
    });
    return json;
})();

var jsonFamilias = (function() {
    var json = null;
    $.ajax({
        async: false,
        global: false,
        url: '/a/js/servicio/registro/comppago/see/liquidacioncompra/json/Familia.json',
        dataType: 'JSON',
        success: function(data) {
            json = data;
        }
    });
    return json;
})();

var jsonClases = (function() {
    var json = null;
    $.ajax({
        async: false,
        global: false,

        url: '/a/js/servicio/registro/comppago/see/liquidacioncompra/json/Clase.json',
        dataType: 'JSON',
        success: function(data) {
            json = data;
        }
    });
    return json;
})();

var jsonProductos = (function() {
    var json = null;
    $.ajax({
        async: false,
        global: false,

        url: '/a/js/servicio/registro/comppago/see/liquidacioncompra/json/Producto.json',
        dataType: 'JSON',
        success: function(data) {
            json = data;
        }
    });
    return json;
})();

inicializarElementos();

function inicializarElementos() {
    limpiarDataTable();
    limpiarModal();
    cargarGrupos("selGrupo", jsonGrupos);
    actualizarDataTable();
}


function limpiarModal() {
	$selGrupo.val("");
    $selSegmento.attr("disabled", "disabled");
    $selSegmento.val("");
    $selFamilia.attr("disabled", "disabled");
    $selFamilia.val("");
    $selClase.attr("disabled", "disabled");
    $selClase.val("");
    $selProducto.attr("disabled", "disabled");
    $selProducto.val("");
    $txtDescripcion.val("");
}

function eliminarBien(codBien) {
    //if (!confirm('\u00BFSeguro de eliminar el registro seleccionado?')) {
       // e.preventDefault();
    //    return;
    //}

	  bootbox.setLocale("es");  
      bootbox.confirm({
        message: '\u00BFSeguro de eliminar el registro seleccionado?',
        closeButton: false,
        buttons: {
          confirm: {
            label: 'Aceptar',
          },
          cancel: {
            label: 'Cancelar',
          },
        },
        callback: function (result) {
          if(result){
			    $(this).closest('tr').remove();
				var url = "catalogoliquidacion.do?action=eliminarCatalogo";
				var data = {
					txtCodBienEli: codBien
				}
				$.post(url, data).success(function(data) {
					var datos = data.success;
					bootbox.alert(datos.msj);
					if (datos.codError == "1") {
						actualizarDataTable();
					}

					actualizarDataTable();
				}).error(function(reason) {
					bootbox.alert('Disculpe, su producto no ha podido ser eliminado, intentelo nuevamente.');
				});
          }
        },
      });

}

$formModalBienes.validate(_.extend(window._validatorWallSettings, {
    rules: {
        selGrupo: {
            required: true
        },
        selSegmento: {
            required: true
        },
        selFamilia: {
            //required: true
        },
        selClase: {
            //required: true
        },
        selProducto: {
            //required: true
        }
    },
    messages: {
        selGrupo: {
            required: "Debe seleccionar una opci&oacute;n para el campo Grupo"
        },
        selSegmento: {
            required: "Debe seleccionar una opci&oacute;n para el campo Segmento"
        },
        selFamilia: {
            required: "Debe seleccionar una opci&oacute;n para el campo Familia"
        },
        selClase: {
            required: "Debe seleccionar una opci&oacute;n para el campo Clase"
        },
        selProducto: {
            required: "Debe seleccionar una opci&oacute;n para el campo Producto"
        }
    },
    submitHandler: function(form) {

        var codGrupo = $selGrupo.val();
        var codBien = $codBien.val();
		var txtDescripcion = $txtDescripcion.val();

        $.ajax({
            url: 'catalogoliquidacion.do?action=agregarCatalogo',
            method: 'post',
            dataType: 'json',
            data: {
                txtCodBien: codBien,
				txtDescripcion: txtDescripcion
            },
            success: function(data) {
                var datos = data.success;
                bootbox.alert(datos.msj);
                if (datos.codError == "1") {
                    $modalBienes.modal('hide');
                    actualizarDataTable();
                }
            },
            error: function(jqXhr, textStatus, errorThrown) {
                bootbox.alert('Disculpe, su producto no ha podido ser registrado, intentelo nuevamente.');
            }
        });

    }
}));

//Acciones botones e inputs

$btnModalBien.on('click', function(e) {
    limpiarModal();
    $modalBienes.modal('show');
});

$selGrupo.on('change', function(e) {
    cargarSegmentos("selSegmento", jsonSegmentos);
    if (this.value == "") {
        $selSegmento.attr("disabled", "disabled");
        $selSegmento.val("");
        $selFamilia.attr("disabled", "disabled");
        $selFamilia.val("");
        $selClase.attr("disabled", "disabled");
        $selClase.val("");
        $selProducto.attr("disabled", "disabled");
        $selProducto.val("");
    } else {
        $selSegmento.removeAttr("disabled");		
		$codigoTemporal = this.value+"0000000"
	 	console.log("codigoTemporal:"+$codigoTemporal);
    }
});


$selSegmento.on('change', function(e) {
    concatenaBien(cargarFamilias("selFamilia", jsonFamilias), this.value, 'selSegmento');
});

$selFamilia.on('change', function(e) {
    concatenaBien(cargarClases("selClase", jsonClases), this.value, 'selFamilia');
});

$selClase.on('change', function(e) {
    concatenaBien(cargarProductos("selProducto", jsonProductos), this.value, 'selClase');
});

$selProducto.on('change', function(e) {
    concatenaBien(0, this.value, 'selProducto');
});

function concatenaBien(cant, valor, id) {
	
	console.log("valor:"+valor);
	//var codigo = "";
	if(id=="selSegmento"){		
		$codigoTemporal = valor.substr(0, 2)+"000000";		
	}else if(id=="selFamilia"){
		$codigoTemporal = valor.substr(0, 4)+"0000";						
	}else if(id=="selClase"){
		$codigoTemporal = valor.substr(0,6)+"00";						
	}else if(id=="selProducto"){
		$codigoTemporal = valor;
	}
	
	
 	console.log("codigoTemporal:"+$codigoTemporal);
	
        var texto = $('#' + id + ' option:selected').html();
		$txtDescripcion.val($codigoTemporal + " - " + texto);
        //$codBien.val(valor + $selGrupo.val());
		$codBien.val($codigoTemporal);
	
	
/*    if (cant == 0 && valor != "") {
        var texto = $('#' + id + ' option:selected').html();
		$txtDescripcion.val(valor + " - " + texto);
        //$codBien.val(valor + $selGrupo.val());
		$codBien.val(valor);
    } else {
        $txtDescripcion.val("");
    }	
*/

}

//funciones carga combolist	
function cargarGrupos(id, lstGruposJson) {
    $("#" + id).empty();
    var tOption = "<option value=''>Grupo</option>";
    $.each(lstGruposJson, function(index, value) {
        tOption = tOption + " <option value='" + $.trim(value.id) + "'>" + $.trim(value.nombre) + "</option>";
    });
    if (tOption != "") {
        $("#" + id).append(tOption);
    }
    $selFamilia.attr("disabled", "disabled");
    $selFamilia.val("");
    $selClase.attr("disabled", "disabled");
    $selClase.val("");
    $selProducto.attr("disabled", "disabled");
    $selProducto.val("");
}

function cargarSegmentos(id, lstSegmentosJson) {
    $("#" + id).empty();
    var tOption = "<option value=''>Segmento</option>";
	 var selGrupo= $selGrupo.val();	 
	 var lista="";
	 var a;
	 var b;
	 switch (selGrupo) {
                case "A":
                    a = 10;
					b = 10;
                    break;
                case "B":
                    a = 11;
					b = 15;
                    break;
                case "C":
                    a = 20;
					b = 27;
                    break;
                case "D":
                    a = 30;
					b = 41;
                    break;
                case "E":
                    a = 42;
					b = 60;
                    break;
                case "F":
                    a = 70;
					b = 94;
                    break;
                case "G":
                    a = 95;
					b = 95;
                    break;
            }
    $.each(lstSegmentosJson, function(index, value) {
	
	 var codigo = $.trim(value.id);
        codigo = codigo.substr(0, 2);
		var valor = parseInt(codigo);
        if (a <= valor  && valor <= b)  {
            tOption = tOption + " <option value='" + $.trim(value.id) + "'>" + $.trim(value.nombre) + "</option>";            
        }        
    });
    if (tOption != "") {
        $("#" + id).append(tOption);
    }
    $selFamilia.attr("disabled", "disabled");
    $selFamilia.val("");
    $selClase.attr("disabled", "disabled");
    $selClase.val("");
    $selProducto.attr("disabled", "disabled");
    $selProducto.val("");

}

function cargarFamilias(id, lstFamiliasJson) {
    var cont = 0;
    $("#" + id).empty();
    var tOption = "<option value=''>Familia</option>";
    var selSegmento = $selSegmento.val().substr(0, 2);
    $.each(lstFamiliasJson, function(index, value) {
        var codigo = $.trim(value.id);
        codigo = codigo.substr(0, 2);
        if (selSegmento == codigo) {
            tOption = tOption + " <option value='" + $.trim(value.id) + "'>" + $.trim(value.nombre) + "</option>";
            cont++;
        }
    });
    if (tOption != "") {
        $("#" + id).append(tOption);
    }
    if (cont == 0) {
        $selFamilia.attr("disabled", "disabled");
        $selFamilia.val("");
    } else {
        $selFamilia.removeAttr("disabled");
    }
    $selClase.attr("disabled", "disabled");
    $selClase.val("");
    $selProducto.attr("disabled", "disabled");
    $selProducto.val("");
    return cont;
}

function cargarClases(id, lstClasesJson) {
    var cont = 0;
    $("#" + id).empty();
    var tOption = "<option value=''>Clase</option>";
    var selFamilia = $selFamilia.val().substr(0, 4);
    $.each(lstClasesJson, function(index, value) {
        var codigo = $.trim(value.id);
        codigo = codigo.substr(0, 4);
        if (selFamilia == codigo) {
            tOption = tOption + " <option value='" + $.trim(value.id) + "'>" + $.trim(value.nombre) + "</option>";
            cont++;
        }
    });
    if (tOption != "") {
        $("#" + id).append(tOption);
    }
    if (cont == 0) {
        $selClase.attr("disabled", "disabled");
        $selClase.val("");
    } else {
        $selClase.removeAttr("disabled");
    }
    $selProducto.attr("disabled", "disabled");
    $selProducto.val("");
    return cont;
}

function cargarProductos(id, lstProductosJson) {
    var cont = 0;
    $("#" + id).empty();
    var tOption = "<option value=''>Producto</option>";
    var selClase = $selClase.val().substr(0, 6);
    $.each(lstProductosJson, function(index, value) {
        var codigo = $.trim(value.id);
        codigo = codigo.substr(0, 6);
        if (selClase == codigo) {
            tOption = tOption + " <option value='" + $.trim(value.id) + "'>" + $.trim(value.nombre) + "</option>";
            cont++;
        }
    });
    if (tOption != "") {
        $("#" + id).append(tOption);
    }
    if (cont == 0) {
        $selProducto.attr("disabled", "disabled");
        $selProducto.val("");
    } else {
        $selProducto.removeAttr("disabled");
    }
    return cont;
}

function actualizarDataTable() {
    var url = "catalogoliquidacion.do?action=cargarTabla";
    var data = "";
    $.post(url, data).success(function(response) {
        var data = response.retorno;
        var lista = data.lista;
        tblLista.DataTable().clear();
        tblLista.DataTable().destroy();
        if (lista.length != 0) {
            cargarDataTable(lista);
        }
    }).error(function(reason) {

        bootbox.alert('Disculpe, su producto no ha podido ser eliminado, intentelo nuevamente.');
    });
}

function limpiarDataTable() {
    tblLista.DataTable().clear();
    tblLista.DataTable().destroy();
    tblLista.DataTable({
        searching: false,
        ordering: false,
        language: {
            processing: "Procesando...",
            emptyTable: 'No se encontraron registros',
            zeroRecords: 'No se encontraron registros',
            search: "Buscar:",
            sLoadingRecords: "Cargando...",
            infoFiltered: "(filtrado de un total de _MAX_ registros)",
            info: "Mostrando registros del _START_ al _END_ de un total de _TOTAL_ registros",
            infoEmpty: "Registros del 0 al 0 de un total de 0 registros",
            paginate: {
                "first": "Primero",
                "last": "Último",
                "next": "Siguiente >",
                "previous": "< Anterior"
            }
        }
    });
}

function obtenerDescripcion(codBien,desProducto, tipo) {
    var descripcion;
    var ceros;
    var limite;
    var jsonData;
	console.log("codBien="+codBien);	
	console.log("desProducto="+desProducto);
	console.log("tipo="+tipo);
	//var codbien2 = desProducto.substr(0, 8);
    if (tipo == 0) {
        ceros = "000000";
        limite = 2;
        jsonData = jsonGrupos;
    }
    if (tipo == 1) {
        ceros = "000000";
        limite = 2;
        jsonData = jsonSegmentos;
    }
    if (tipo == 2) {
        ceros = "0000";
        limite = 4;
        jsonData = jsonFamilias;
    }
    if (tipo == 3) {
        ceros = "00";
        limite = 6;
        jsonData = jsonClases;
    }
    if (tipo == 4) {
        ceros = "";
        limite = 8;
        jsonData = jsonProductos;
    }
    var idJson = codBien.substr(0, limite) + ceros;
    var resCodBien = codBien.substr(limite, 8 - limite);
	
	
	console.log("idJson="+idJson);
	console.log("resCodBien="+resCodBien);
	
	if (tipo == 0) {
		idJson = codBien.substr(0, limite) ;
		var valor = parseInt(idJson);
		if(10 <=valor && valor <= 10){
		idJson = "A";
		}
		if(11 <=valor && valor <= 15){
		idJson = "B";
		}
		if(20 <=valor && valor <= 27){
		idJson = "C";
		}
		if(30 <=valor && valor <= 41){
		idJson = "D";
		}
		if(42 <=valor && valor <= 60){
		idJson = "E";
		}
		if(70 <=valor && valor <= 94){
		idJson = "F";
		}
		if(95 <=valor && valor <= 95){
		idJson = "G";
		}
	}
	
    var dato = _.filter(jsonData, {
        id: idJson
    })[0];
	
	

	descripcion = "";
	
    if (dato === undefined ) {
        //descripcion = "";
		if(tipo==4){
			descripcion = desProducto;
		}
    } else {
		
		
		console.log("dato.nombre="+dato.nombre);	
/*		if(resCodBien != ceros){
		descripcion = dato.nombre;
		}else{
		descripcion = desProducto;
		}*/
		
		if(dato.nombre != ""){			
			descripcion = dato.nombre;
		}	
    }
	
	console.log("descripcion="+descripcion);	
    return descripcion;
}

function cargarDataTable(lista) {
    tblLista.DataTable({
        order: [],
        language: {
            processing: "Procesando...",
            lengthMenu: "Mostrar _MENU_ registros",
            emptyTable: 'No se encontraron registros',
            zeroRecords: 'No se encontraron registros',
            search: "Buscar:",
            sLoadingRecords: "Cargando...",
            infoFiltered: "(filtrado de un total de _MAX_ registros)",
            info: "Mostrando registros del _START_ al _END_ de un total de _TOTAL_ registros",
            infoEmpty: "Registros del 0 al 0 de un total de 0 registros",
            paginate: {
                "first": "Primero",
                "last": "Último",
                "next": "Siguiente >",
                "previous": "< Anterior"
            }
        },
        data: lista,
        columns: [{
                data: function(row, type, val, meta) {
                   /* var producto = _.filter(jsonGrupos, {
                       // id: row.codbien.substr(8, 2)
					    id: "01"
                    })[0];
                    return producto.nombre;*/
					//console.log("row.desproducto="+row.codbien);
					return obtenerDescripcion(row.codbien,row.desproducto, 0);
                },
                sClass: 'text-left'
            },
            {
                data: function(row, type, val, meta) {
                    return obtenerDescripcion(row.codbien,row.desproducto, 1);
                },
                sClass: 'text-left'
            },
            {
                data: function(row, type, val, meta) {
                    return obtenerDescripcion(row.codbien,row.desproducto, 2);
                },
                sClass: 'text-left'
            },
            {
                data: function(row, type, val, meta) {
                    return obtenerDescripcion(row.codbien,row.desproducto, 3);
                },
                sClass: 'text-left'
            },
            {
                data: function(row, type, val, meta) {
                    //return obtenerDescripcion(row.codbien,row.desproducto, 4);
                    return row.desproducto;
                },
                sClass: 'text-left descripcion'
            },
            {
                data: function(row, type, val, meta) {
                    return "<button class=\"btn btn-danger btn-sm remover\" onclick=\"eliminarBien('" + row.desproducto + "')\"><i class=\"glyphicon glyphicon-remove\"></i></button>";
                },
                sClass: 'text-center'
            }
        ],
        searching: false,
        bLengthChange: false,
        "pageLength": 10
    });
}