//(function(window, $, _){
	/*
	* :::: CONTAINERS :::: START
	*/
	
	var $btnEditar = $(".editar");

	var $btnEliminar = $(".remover");




	$btnEliminar.on('click', function  (e) {
		
		$(this).closest('tr').remove();
	})









//})(window, jQuery, _);