/**
 * GeneracionRegComprasPortal.js - JavaScript de RVI.
 * Author: Patricia Chacaliaza
 * Since: 19-12-2012
 * ResponseBean : codeError; messageError; data;
 */
if (!dojo._hasResource["servicio.registro.comppago.see.GeneracionRegComprasPortal"]) {
dojo._hasResource["servicio.registro.comppago.see.GeneracionRegComprasPortal"] = true;
dojo.provide("servicio.registro.comppago.see.GeneracionRegComprasPortal");

  dojo.require("dojox.grid.DataGrid");
  dojo.require("dojox.grid.cells.dijit");
dojo.require("dojo.data.ItemFileWriteStore");
dojo.require("dojo.data.ItemFileReadStore");
dojo.require("dojo.io.iframe");
    dojo.require("dijit.Dialog");

dojo.require("dijit.form.DateTextBox");
			dojo.require("dojox.widget.Standby");
dojo.declare("servicio.registro.comppago.see.GeneracionRegComprasPortal", null, {

	
	store: null,
	beanDatosCP: null,
	controller: "regcompras.do",
	otherDocStore: null,
	ptoemiStore: null,	
	flag_cp:"0",
	flag_cpDM:"0",
	flag_cpSP:"0",
	
	constructor: function() {},

	initialize: function() {
		this.content = dijit.byId("content");
		this.setContentPaneLoading(this.content);
		this.dialogHistorial =  dijit.byId("dialogHistorial");
		this.dialogTC =  dijit.byId("dialogTipoDeCambio");
		this.dialogError =  dijit.byId("dialogErrores");
		this.waitMessage = dijit.byId("waitMessage");

		var size = dojo.marginBox(this.content.domNode);
		x = Math.floor((size.w - 102)/2);
		y = Math.floor((size.h - 34)/2);

		this.content.loadingMessage = 
		'<div class="ext-el-mask-msg x-mask-loading" style="left: ' + x + 'px; top: ' + y + 'px;"><div>Cargando...</div></div>';		
	},

		
	initContent: function() {
	    this.initialize();
       
		 // dijit.focus(dojo.byId("inicio.periodo"));
		
	},
	
		mandar: function(form) {
	    //dojo.byId("criterios").submit();
      // this.content.setHref(this.controller + "?action=generaPreliminarRegComprasConMovim" );	
		 // dijit.focus(dojo.byId("inicio.periodo"));
		 
		 if (dojo.byId("archivo").value ==""){
		      alert("Debe seleccionar un archivo para cargar");
		      return;
     }
		 
		    	var handler = dojo.io.iframe.send({
    			url: this.controller,
    			handleAs: "json",
    			sync: true,
    			timeout: 999000,
    			preventCache: true,
    			form: "criterios"
    		});
    		
			handler.addCallback(dojo.hitch(this, function(res){

				if(res.codeError == 0) {
				
				  this.flag_cp="1";
				  //this.content.setHref(this.controller + "?action=mostrarPreliminarImportacion" );	
				  alert("Archivo cargado correctamente");
				} else {
    				if(res.codeError == 1) {
    					this.content.setHref(this.controller + "?action=mostrarErroresImportacion" );	
    				}else{
    				    alert(res.messageError);
            }
				}
			}));
			handler.addErrback(dojo.hitch(this, function(res) {
    			this.waitMessage.hide();
				alert("Ocurrio un error al momento de ejecutar la consulta.");
			}));
	},
	mandarRCNoDom: function(form) {
	    //dojo.byId("criterios").submit();
      // this.content.setHref(this.controller + "?action=generaPreliminarRegComprasConMovim" );	
		 // dijit.focus(dojo.byId("inicio.periodo"));
		 
		 if (dojo.byId("archivoND").value ==""){
		      alert("Debe seleccionar un archivo para cargar");
		      return;
     }
		 
		    	var handler = dojo.io.iframe.send({
    			url: this.controller,
    			handleAs: "json",
    			sync: true,
    			timeout: 999000,
    			preventCache: true,
    			form: "RCNormal"
    		});
    		
			handler.addCallback(dojo.hitch(this, function(res){

				if(res.codeError == 0) {
				   
				   this.flag_cpDM="1";
				  //this.content.setHref(this.controller + "?action=mostrarPreliminarImportacionCompraDomiciliado" );	
				  alert("Archivo cargado correctamente");
				} else {
    				if(res.codeError == 1) {
    					this.content.setHref(this.controller + "?action=mostrarErroresNoDomImportacion" );	
    				}else{
    				    alert(res.messageError);
            }
				}
			}));
			handler.addErrback(dojo.hitch(this, function(res) {
    			this.waitMessage.hide();
				alert("Ocurrio un error al momento de ejecutar la consulta.");
			}));
	},
	
	mandarRCSimpl: function(form) {
	    //dojo.byId("criterios").submit();
      // this.content.setHref(this.controller + "?action=generaPreliminarRegComprasConMovim" );	
		 // dijit.focus(dojo.byId("inicio.periodo"));
		 
		 if (dojo.byId("archivoCS").value ==""){
		      alert("Debe seleccionar un archivo para cargar");
		      return;
     }
		 
		    	var handler = dojo.io.iframe.send({
    			url: this.controller,
    			handleAs: "json",
    			sync: true,
    			timeout: 999000,
    			preventCache: true,
    			form: "RCSim"
    		});
    		
			handler.addCallback(dojo.hitch(this, function(res){

				if(res.codeError == 0) {
				  this.flag_cpSP="1";
				  //this.content.setHref(this.controller + "?action=mostrarPreliminarImportacionCS" );	
				  alert("Archivo cargado correctamente");
				} else {
    				if(res.codeError == 1) {
    					this.content.setHref(this.controller + "?action=mostrarErroresImportacion" );	
    				}else{
    				    alert(res.messageError);
            }
				}
			}));
			handler.addErrback(dojo.hitch(this, function(res) {
    			this.waitMessage.hide();
				alert("Ocurrio un error al momento de ejecutar la consulta.");
			}));
	},

	//funciones para eventos
    startup: function(){
    	  dojo.parser.parse(dojo.byId('container'));
    	  setTimeout(dojo.hitch(this, function(){
		   this.initialize();
    	  }), 250);

    },    

    validateAcceptTerminos: function(){
          var acepta = dijit.byId("condiciones.cbTerminos");
          if (!acepta.getValue()) {
              alert("Debe aceptar las condiciones.");

              return;
          }
                  this.content.setHref(this.controller + "?action=mostrarInicial2");
      },
      
   validacionRCLibre: function(){
   dijit.hideTooltip(dojo.byId("inicioRegComp.periodoRegistroComprasConMovim"));

     var periodo =  dijit.byId("inicioRegComp.periodoRegistroComprasConMovim" ).getValue().substring(3,7) + dijit.byId("inicioRegComp.periodoRegistroComprasConMovim" ).getValue().substring(0,2);
          		var periodoRVI = dijit.byId("inicioRegComp.periodoRegistroComprasConMovim" ).getValue();
          		    if (periodoRVI.length != 7){
                        this.iconTooltipMessage("inicioRegComp.periodoRegistroComprasConMovim", "icon-ok-tooltip", "El periodo debe tener el formato MM/YYYY.");
                        return;
                  }
                  if (periodoRVI.substring(0,2) != "01" && periodoRVI.substring(0,2) != "02" && periodoRVI.substring(0,2) != "03" &&
                      periodoRVI.substring(0,2) != "04" && periodoRVI.substring(0,2) != "05" && periodoRVI.substring(0,2) != "06" &&
                      periodoRVI.substring(0,2) != "07" && periodoRVI.substring(0,2) != "08" && periodoRVI.substring(0,2) != "09" &&
                      periodoRVI.substring(0,2) != "10" && periodoRVI.substring(0,2) != "11" && periodoRVI.substring(0,2) != "12" ){
                        this.iconTooltipMessage("inicioRegComp.periodoRegistroComprasConMovim", "icon-ok-tooltip", "El mes del periodo es inv�lido.");
                        return;
                  } 
              var periodoActual  = dojo.date.locale.format(new Date(), {datePattern: "yyyyMM", selector: "date"});
              if (periodo > periodoActual){
                  this.iconTooltipMessage("inicioRegComp.periodoRegistroComprasConMovim", "icon-ok-tooltip", "Periodo no puede ser mayor al actual.");
                  return;
              }      		
              if (periodo < 201304){
                  this.iconTooltipMessage("inicioRegComp.periodoRegistroComprasConMovim", "icon-ok-tooltip", "Periodo no puede ser menor a 04/2013.");
                  return;
              } 
              
            var handler = dojo.xhrGet({
              url: this.controller + "?action=validaExisteRCGenerados&perIni=" + periodo + "&perFin=" + periodo,
              handleAs: "json",
		         	preventCache: true,
              sync: true,
              timeout: 10000
            }); 

      		
    			handler.addCallback(dojo.hitch(this, function(res){
    				//this.waitMessage.hide();
    				if(res.codeError == 0) {
                var periodoSeleccionado = dojo.byId("inicioRegComp.periodoRegistroComprasConMovim").value.substring(3,7)+ dojo.byId("inicioRegComp.periodoRegistroComprasConMovim").value.substring(0,2);
      
                 this.content.setHref(this.controller + "?action=mostrarInicial3" + "&preventCache=" + this.preventCache() + "&periodoSeleccionado=" + periodoSeleccionado);	

    				} else {
    					alert(res.messageError);
    					return;
    				}
    			}));
    			handler.addErrback(dojo.hitch(this, function(res) {
        			//this.waitMessage.hide();
    				alert("Ocurrio un error al momento de ejecutar la consulta.");
    				return;
    			}));
  
  
    },
      
    generarRvi: function(){
    
        if(dojo.byId("inicio.periodoRegistroVentas").value == "") {
    			alert("Debe seleccionar un periodo.");
    			return;
    		}
        //var periodoSeleccionado = dojo.byId("inicio.periodoRegistroVentas").value;
        var periodoSeleccionado = dojo.byId("inicio.periodoRegistroVentas").value.substring(3,7)+ dojo.byId("inicio.periodoRegistroVentas").value.substring(0,2);
        this.content.setHref(this.controller + "?action=mostrarInicial2" + "&preventCache=" + this.preventCache() + "&periodoSeleccionado=" + periodoSeleccionado);	
    },
    
   getValorOpcionSinMovim: function() {
		var valRet="";		
		for(i = 0; i < 2; i++) {
			if(dijit.byId("inicioRegComp.opcRVIVacio" + i).getValue() != false) {
				valRet = dijit.byId("inicioRegComp.opcRVIVacio" + i).getValue()
			}
		}
		return valRet;
	},  
	
	   getValorOpcionSinMovimND: function() {
		var valRet="";		
		for(i = 0; i < 2; i++) {
			if(dijit.byId("inicioRegComp.opcRVINDVacio" + i).getValue() != false) {
				valRet = dijit.byId("inicioRegComp.opcRVINDVacio" + i).getValue()
			}
		}
		return valRet;
	},  
	
getValorOpcionTipLibro: function() {
		var valRet="";		
		for(i = 0; i < 2; i++) {
			if(dijit.byId("inicioRegComp.opcRC" + i).getValue() != false) {
				valRet = dijit.byId("inicioRegComp.opcRC" + i).getValue()
			}
		}
		return valRet;
	},  
    

    
    showMovim: function(){


    },
    
     showTipoRegCompras: function(){
      if (this.getValorOpcionTipLibro() =="1"){
            this.showHiddenDiv(document.getElementById("inicioRegComp.archivoConMovimientosCompleto.show"),false);
            this.showHiddenDiv(document.getElementById("inicioRegComp.GeneraRegComprasSimpl.show"),true);
            this.showHiddenDiv(document.getElementById("inicioRegComp.GeneraRegComprasDomi.show"),false);
            this.showHiddenDiv(document.getElementById("inicioRegComp.GeneraPreRegCompras.show"),true);
             
            if (this.getValorOpcionSinMovim() =="1"){
              		this.showHiddenDiv(document.getElementById("inicioRegComp.GeneraRegComprasSimpl.show"),false); 
            }else{
              		this.showHiddenDiv(document.getElementById("inicioRegComp.GeneraRegComprasSimpl.show"),true);
 
            }
        		//this.showHiddenDiv(document.getElementById("inicioRegComp.GeneraRegComprasSimpl.show"),true);
        		//this.showHiddenDiv(document.getElementById("inicioRegComp.periodoGeneraConMovimientos.show"),false); 
           	//this.showHiddenDiv(document.getElementById("inicioRegComp.GeneraRegComprasDomi.show"),false);
           	//this.showHiddenDiv(document.getElementById("inicioRegComp.GeneraPreRegComprasCompleto.show"),true);
        		this.flag_cSP ="0"
      }else{
        		this.showHiddenDiv(document.getElementById("inicioRegComp.opcSinMovimientos.show"),true);
            this.showHiddenDiv(document.getElementById("inicioRegComp.GeneraRegComprasSimpl.show"),false);
            this.showHiddenDiv(document.getElementById("inicioRegComp.GeneraRegComprasDomi.show"),true);   
             if (this.getValorOpcionSinMovim() =="1"){
              		this.showHiddenDiv(document.getElementById("inicioRegComp.archivoConMovimientosCompleto.show"),false);
     		
            }else{
              		this.showHiddenDiv(document.getElementById("inicioRegComp.archivoConMovimientosCompleto.show"),true);
            }       		
  
            if (this.getValorOpcionSinMovimND() =="1"){
              		this.showHiddenDiv(document.getElementById("inicioRegComp.archivoConMovimientosNoDomic.show"),false);
              
            		
            }else{
              		this.showHiddenDiv(document.getElementById("inicioRegComp.archivoConMovimientosNoDomic.show"),true);

 
            }      
        		this.showHiddenDiv(document.getElementById("inicioRegComp.GeneraPreRegCompras.show"),true);
           	this.flag_c ="0"
           	this.flag_cDM ="0"
      }

    },
    
    confirmarRegComprasSinMovim : function(){
    

         if(this.getValorOpcionTipLibro()=="" || this.getValorOpcionTipLibro()=="0"){
            if (confirm("�Desea la generacion del Registro de Compras Electronico Completo?")) {
            this.content.setHref(this.controller + "?action=confirmarRegComprasSinMovim&perIni=" + periodoDesde + "&perFin=" + periodoHasta+"&tipLibro="+0);
            } 
         } else{
           if (confirm("�Confirme la generacion del Registro de Compras Electronico Sin Operaciones Simplificado?")) {
            this.content.setHref(this.controller + "?action=confirmarRegComprasSinMovim&perIni=" + periodoDesde + "&perFin=" + periodoHasta+"&tipLibro="+1);
            }
         }
         
  
         
            
           
               
    },
    
    generarPreliminarRegComprasSinMovim : function(){
      if (confirm("Confirme la generacion del Registro de Compras Electronico Sin Operaciones")) {
            this.content.setHref(this.controller + "?action=generaPreliminarRegComprasSinMovim");  
      }  
    },
    
    cargarArchivo:function(){
        var periodo= dojo.byId("inicioRegComp.periodoRegistroComprasConMovim").value;
         this.content.setHref(this.controller + "?action=generaPreliminarRegComprasConMovim&periodo=" + periodo);
         /*   var handler = dojo.xhrGet({
                  url: this.controller + "?action=generaPreliminarRegComprasConMovim&periodo=" + periodo,
                  handleAs: "json",
    		         	preventCache: true,
                  sync: true,
                  timeout: 10000
            }); 

      		
      			handler.addCallback(dojo.hitch(this, function(res){
      				this.waitMessage.hide();
      				if(res.codeError == 0) {
		
      				} else {
      					    this.content.setHref(this.controller + "?action=showErroresImportacion"); 
      					    var dataResp = eval("(" + res.data + ")");						
                    
                    this.content.onLoad = dojo.hitch(this, function(){
                            this.store = new dojo.data.ItemFileWriteStore({data: {identifier: 'id', items: dataResp}});
                			    	var grid = dijit.byId("ErroresRegCompPresentadosGrid");
                						grid.setStore(this.store);
            					   grid.startup();});     
      				}
      			}));
      			handler.addErrback(dojo.hitch(this, function(res) {
          			this.waitMessage.hide();
      				alert("Ocurrio un error al momento de importar el archivo.");
      			}));
      			*/
    },
    
    
            sendMail: function(){
            var correo = dijit.byId("generada.correoUser");
            if (correo.getValue() == "") {
                alert("Debe consignar el Correo Electronico.");
                return;
            }
 
            var handler = dojo.xhrGet({
                url: this.controller + "?action=enviarCorreo&correoUser=" + correo.getValue(),
                handleAs: "json",
                preventCache: true,
                sync: true,
                timeout: 10000
            });
            handler.addCallback(dojo.hitch(this, function(res){
                if (res.codeError == 0) {
                    //this.messageBoxError("Se envio constancia al buz�n electr�nico.", "icon-alert-warn");
                    alert("Se envio correo electronico.");
                    return;
                }
                else {
                    alert(res.messageError);
                }
            }));
/*
            handler.addErrback(dojo.hitch(this, function(res){
                this.waitMessage.hide();
                alert("Problemas al enviar mail de afiliaci�n.");
            }));
*/
        },
    
    generarRegCompSinMovim: function(){
       if (confirm("Confirme que desea generar el Registro de Compras Electronico")) {
          //this.wait("Generaci�n del Registro de Compras Electr�nico en Proceso", "110px");
          
            var handler = dojo.xhrGet({
                  url: this.controller + "?action=generaRVISinMovimFinal",
                  handleAs: "json",
    		         	preventCache: true,
                  sync: true,
                  timeout: 10000
            }); 

      		
      			handler.addCallback(dojo.hitch(this, function(res){
      				this.waitMessage.hide();
      				if(res.codeError == 0) {
  			          //Generamos RVI sin Movimientos
                 		   this.content.setHref(this.controller + "?action=finalRVI&preventCache=" + this.preventCache());
        		        //
      				} else {
      					alert(res.messageError);
      				}
      			}));
      			handler.addErrback(dojo.hitch(this, function(res) {
          			this.waitMessage.hide();
      				alert("Ocurrio un error al momento de ejecutar la consulta.");
      			}));
       }
    },
    
  
    
  	showDialogHistorial: function(rowIndex) {
    		
    		this.wait("Consultando", "110px");
    		
        var handler = dojo.xhrGet({
              url: this.controller + "?action=getHistorial",
              handleAs: "json",
		         	preventCache: true,
              sync: true,
              timeout: 10000
        }); 
        
           		
  		
			handler.addCallback(dojo.hitch(this, function(res){
				this.waitMessage.hide();
				if(res.codeError == 0) {
      						var data = eval("(" + res.data + ")");			
      						this.store = new dojo.data.ItemFileWriteStore({data: {identifier: 'id', items: data}});
      			    	var grid = dijit.byId("historialRegCompPresentadosGrid");
      						grid.setStore(this.store);
      						grid.startup();
      					this.dialogHistorial.show();				
		
				} else {
					alert(res.messageError);
				}
			}));
			handler.addErrback(dojo.hitch(this, function(res) {
    			this.waitMessage.hide();
				alert("Ocurrio un error al momento de ejecutar la consulta del historial de presentaciones.");
			}));
			
  	      
  	},
  	
  	salirHistorico:function(){
  	   this.dialogHistorial.hide();
    },
  	
  	salirTC:function(){
  	   if (confirm("Desea salir de la captura de Tipo de Cambio?")){
  	     this.dialogTC.hide();
  	   }
    },
    
 
    
  	formatMedioPresenta: function(value) {
			if (value == "1") {
				return "PLE";
			} else {		
         	if (value == "2") {
				    return "SOL";
			    } else {
				    return "";
			    }
			}
		},
		
		formatFecNacOblig: function(value, rowindex) {
		//dd/MM/yyyy
		  if (value!= null){
            return dojo.date.locale.format(new Date(value), {datePattern: "dd/MM/yyyy", selector: "date"});
          }
		},
		
		workTipoDeCambio: function(rowindex,object) {
		   if (object!=null){
		          var grilla =dijit.byId('CPOtrasMonedasGrid');
              var fila = grilla.getItem(rowindex);
              var store = grilla.store;
              var tipoCambio =  grilla.store.getValue(fila, "tipo_cambio");
              var ind_confirma = grilla.store.getValue(fila, "ind_confirma");
              var tipoCambioOrig =  grilla.store.getValue(fila, "tipo_cambio_ref");
              //if (grilla.store._onFetchComplete) {return dojo.trim(tipoCambio);}
              if (tipoCambio != tipoCambioOrig){
                  store.setValue(fila, "ind_confirma", false);
                  store.setValue(fila, "tipo_cambio_ref", tipoCambio);
              }
              return tipoCambio ;
		   }
		},
		
		loadFecNacOblig: function(rowindex,object) {  //item, attribute, oldValue, newValue
       if (object!=null){

              var grilla =dijit.byId('CPOtrasMonedasGrid');
              var fila = grilla.getItem(rowindex);

				      var dato = grilla.store.getValue(fila, "fec_nacim_obliga");
          return dato;
        }
    },
    
    workFecNacOblig: function(rowindex,object) {  //item, attribute, oldValue, newValue
       if (object!=null){

              var grilla =dijit.byId('CPOtrasMonedasGrid');
              var fila = grilla.getItem(rowindex);
              var node = grilla.getCell(9).getHeaderNode(); 
              var store = grilla.store;
              var ind_confirma = grilla.store.getValue(fila, "ind_confirma");
              dijit.hideTooltip(node);  
              
				      var fec_nacim_obliga = grilla.store.getValue(fila, "fec_nacim_obliga");
				      var fec_nacim_obliga_orig = grilla.store.getValue(fila, "fec_nacim_obliga_ref");
              
				      var fec = dojo.date.locale.format(new Date(fec_nacim_obliga), {datePattern: "dd/MM/yyyy"});
				      var fec2 = dojo.date.locale.format(new Date(fec_nacim_obliga_orig), {datePattern: "dd/MM/yyyy"});

              //if(store._loadFinished != true) {return dato;}

              if (fec != fec2){
                  store.setValue(fila, "ind_confirma", false);
                  store.setValue(fila, "tipo_cambio", null);
                  store.setValue(fila, "fec_nacim_obliga_ref", fec_nacim_obliga);
                  //Tenemos que recuperar el tipo de cambio
                  var moneda = grilla.store.getValue(fila, "cod_moneda");
                   
                    var handler = dojo.xhrGet({
                          url: "regvtasing.do?action=obtieneTipoDeCambio&moneda=" + moneda + "&fechaNacObliga=" +  dojo.date.locale.format(new Date(fec_nacim_obliga), {datePattern: "MM-dd-yyyy", selector: "date"}),
                          handleAs: "json",
            		         	preventCache: true,
                          sync: true,
                          timeout: 10000
                    }); 
  		
              			handler.addCallback(dojo.hitch(this, function(res){

              				if(res.codeError == 0) {
                    						var data = eval("(" + res.data + ")");			
                                store.setValue(fila, "tipo_cambio", data);				
              		
              				} else {
              					alert(res.messageError);
              				}
              			}));
              			handler.addErrback(dojo.hitch(this, function(res) {

              				alert("Ocurrio un error al momento de ejecutar la consulta:" + res.messageError);
              			}));
                  /////////////////////////////////////////
              }
              return fec_nacim_obliga ;
        }
    },
    		setCheck: function(rowindex,object, oldValue, newValue){
    		  /* if (object!=null){
    		        alert(oldValue);
    		        alert(newValue);
    		   }*/
        },
   
    descargarTC : function(){
            window.open(this.controller + "?action=imprimirPDFTC" );
    },
    
    generarRegCompConMovimientos : function(periodo){

            var fecHoy = new Date();

            var periodoActual = dojo.date.locale.format(fecHoy, {datePattern: "yyyyMM", selector: "date"});
            if(periodo >= periodoActual){
              alert("No puede generarse aun el Preliminar del Registro de Compras Electronico")
              return;
            } 
            if (confirm("Est� Ud. conforme con la informaci�n contenida en el Preliminar del Registro de Compras Electr�nico.?")){  
              if (confirm("Confirme que desea generar el Preliminar del Registro de Compras electr�nico")){
                   this.wait(" Generaci�n del Registro de Compras Electr�nico en Proceso ", "500px");
                   var handler = dojo.xhrGet({
                        url: this.controller + "?action=generaRegCompConMovimFinal",
                        handleAs: "json",
                        sync: true,
                        timeout: 990000
                    });        
                    handler.addCallback(dojo.hitch(this, function(res){
                       this.waitMessage.hide();
                  			if (res.codeError == 0) {
                           this.content.setHref(this.controller + "?action=finalRVI&preventCache=" + this.preventCache());
                   			}
                  			else {
                  				alert("Problemas al grabar el registro de compras:" + res.messageError);
                  			}
                    }));
              			handler.addErrback(dojo.hitch(this, function(res) {
                  			this.waitMessage.hide();
              				alert("Ocurrio un error al momento de generar el Preliminar del registro de compras.");
              			}));
              }
            }
        
    },
    generarRegCompConMovimientosSim : function(periodo){

            var fecHoy = new Date();

            var periodoActual = dojo.date.locale.format(fecHoy, {datePattern: "yyyyMM", selector: "date"});
            if(periodo >= periodoActual){
              alert("No puede generarse aun el Registro de Compras Electronico")
              return;
            } 
            if (confirm("Est� Ud. conforme con la informaci�n contenida en el Preliminar del Registro de Compras Electr�nico.?")){  
              if (confirm("Confirme que desea generar el registro de Compras electr�nico")){
                   this.wait(" Generaci�n del Registro de Compras Electr�nico en Proceso ", "500px");
                   var handler = dojo.xhrGet({
                        url: this.controller + "?action=generaRegCompConMovimFinalSim",
                        handleAs: "json",
                        sync: true,
                        timeout: 990000
                    });        
                    handler.addCallback(dojo.hitch(this, function(res){
                       this.waitMessage.hide();
                  			if (res.codeError == 0) {
                          this.content.setHref(this.controller + "?action=finalRVI&preventCache=" + this.preventCache());
                   			}
                  			else {
                  				alert("Problemas al grabar el registro de compras:" + res.messageError);
                  			}
                    }));
              			handler.addErrback(dojo.hitch(this, function(res) {
                  			this.waitMessage.hide();
              				alert("Ocurrio un error al momento de generar el registro de compras.");
              			}));
              }
            }
        
    },
    
    descargarPrelimRegCompConMovim : function(){
      window.open(this.controller + "?action=descargarPrelimRegCompConMovim" );
      
      //if(this.flag_cp =="1" && this.flag_cpDM =="1"){
      //   window.open(this.controller + "?action=descargarPrelimRegCompConMovimDom" );
      //} 
    
    },
    
        
    descargarPrelimRegCompConMovimDomi : function(){

         window.open(this.controller + "?action=descargarPrelimRegCompConMovimDom" );
    
    },
    descargarPrelimRegCompConMovimSimpl : function(){
      window.open(this.controller + "?action=descargarPrelimRegCompConMovimSimpl" );
    
    },
    
    descargarErrores : function(){
      window.open(this.controller + "?action=descargarErrores" );
    
    },
         
    salirErrores : function(){
        this.content.setHref(this.controller + "?action=mostrarInicial" + "&preventCache=" + this.preventCache() );	
    
    },
    
        salirPrelimRegCompConMovim : function(){
        this.content.setHref(this.controller + "?action=mostrarInicial" + "&preventCache=" + this.preventCache() );	
        this.flag_cp="0";
        this.flag_cpDM="0";
        this.flag_cpSP="0";
    
    },
    
    salir : function(){
        this.content.setHref(this.controller + "?action=mostrarInicial" + "&preventCache=" + this.preventCache() );	
    
    },
    
    descargaZip: function(){
      window.open(this.controller + "?action=descargaZip" );
    },
    
    salirInicial: function(){
              this.content.setHref(this.controller + "?action=mostrarInicial" + "&preventCache=" + this.preventCache() );	
    },
    
    pause: function(milisec){
    var d = new Date();
    var begin = d.getTime();
    
    while ((d.getTime() - begin ) > milisec){
    // nothing... 
    } 
 } ,
  	preventCache: function() {
  		return new Date().valueOf();
  	},
	
  	wait: function(message, width) {
		dojo.byId("waitMessage").innerHTML="<div class='dijitInline box-message'></div><div class='dijitInline'>&nbsp;" + message + "...</div>";
	    dojo.byId("waitMessage").style.width = width;
	    this.waitMessage.show();
	},
	

	
	
	  iconTooltipMessage: function(node, iconClass, message) {
  		if(dojo.isString(node)) node = dojo.byId(node);
  		dijit.focus(node);
  		node.focus();
  		dijit.showTooltip('<div class="' + iconClass + '"><div>' + message + '</div></div>', node, []);
  		//node._refreshState();
  		var blur = dojo.connect(node, "onBlur", function() {
  			dijit.hideTooltip(node);
  			//node._refreshState();
  			dojo.disconnect(blur);
  		});
	  },   
  
	  warnTooltipMessage: function(node, message) {
		  this.iconTooltipMessage(node, "icon-warn-tooltip", message);
	  },
	
	  noSort: function(index){ 
		   return false;
	  },
	
	onFocus: function(id){
    var dato = dojo.byId(id).value;
     dijit.byId(id).attr('value',"");	
     dijit.byId(id).attr('value',dojo.trim(dato));	
  },

      roundNumber: function(number, digits) {
                   var multiple = Math.pow(10, digits);
                   var rndedNum = Math.round(number * multiple) / multiple;

                   return rndedNum;
     } ,
  
  	setContentPaneLoading: function(content) {
		this.setContentPaneLoadingBg(content, "ext-el-mask");
	},
	
	generarPreliminarVentasCompras: function(){
	    
	              //dijit.hideTooltip(dojo.byId("inicioRegComp.periodoRegistroComprasSinMovimHasta"));
          //var periodoDesde = dojo.byId("inicioRegComp.periodoRegistroComprasSinMovimDesde").value;
          //var periodoHasta = dojo.byId("inicioRegComp.periodoRegistroComprasSinMovimHasta").value;
        var periodoDesde = dojo.byId("inicioRegComp.periodoRegistroComprasConMovim").value.substring(3,7)+ dojo.byId("inicioRegComp.periodoRegistroComprasConMovim").value.substring(0,2);
        var periodoHasta = dojo.byId("inicioRegComp.periodoRegistroComprasConMovim").value.substring(3,7)+ dojo.byId("inicioRegComp.periodoRegistroComprasConMovim").value.substring(0,2);      
        var flag;         
          var fecHoy = new Date();
          var mesAnterior = fecHoy.setMonth(fecHoy.getMonth()-1);
          var periodoAnterior = dojo.date.locale.format(new Date(mesAnterior), {datePattern: "yyyyMM", selector: "date"});
          if(periodoDesde > periodoAnterior){
             this.iconTooltipMessage("inicioRegComp.periodoRegistroComprasConMovim", "icon-ok-tooltip", "El periodo final debe ser menor o igual al periodo anterior al actual.");
             return;
       }
     
    var handler = dojo.xhrGet({
      url: this.controller + "?action=validaExisteRCGenerados&perIni=" + periodoDesde + "&perFin=" + periodoDesde,
      handleAs: "json",
     	preventCache: true,
      sync: true,
      timeout: 100000
    }); 
			handler.addCallback(dojo.hitch(this, function(res){
				this.waitMessage.hide();
				if(res.codeError == 0) {

           if (this.getValorOpcionTipLibro() =="1"){
              	  if(this.flag_cpSP =="1"){
              		   this.content.setHref(this.controller + "?action=mostrarPreliminarImportacionCS&perIni=" + periodoDesde + "&perFin=" + periodoHasta+"&tipLibro=1&sinMovimientos=1" );
                  }
                  else{
                    if (this.getValorOpcionSinMovim() =="1"){
                        this.content.setHref(this.controller + "?action=generaPreliminarRegComprasSinMovim&perIni=" + periodoDesde + "&perFin=" + periodoHasta+"&tipLibro=1&sinMovimientosRC=1&sinMovimientosND=1" );
                    
                    }else{
                        alert("Debe realizar la carga del archivo Simplificado");
              		    	return;
          		    	}
                  }
            }else{
                  if (this.getValorOpcionSinMovim() =="1" && this.getValorOpcionSinMovimND() =="1" ){
                      this.content.setHref(this.controller + "?action=generaPreliminarRegComprasSinMovim&perIni=" + periodoDesde + "&perFin=" + periodoHasta+"&tipLibro=0&sinMovimientosRC=1&sinMovimientosND=1" );
                  
                  }else{
                    if (this.getValorOpcionSinMovim() =="1" && (this.getValorOpcionSinMovimND() =="0" || this.getValorOpcionSinMovimND() =="")){
                    	if(this.flag_cpDM =="1" ){
                          this.content.setHref(this.controller + "?action=mostrarPreliminarImportacion" );
                      } else {
                          alert("Debe realizar la carga del archivo Completo de No domiciliados");
                		    	return;
                      }                    
                      
                    }else{
                        if ((this.getValorOpcionSinMovim() =="0" || this.getValorOpcionSinMovim() =="" )&& this.getValorOpcionSinMovimND() =="1" ){
                        	if(this.flag_cp =="1" ){
                              this.content.setHref(this.controller + "?action=mostrarPreliminarImportacion" );
                          } else {
                              alert("Debe realizar la carga del archivo Completo");
                    		    	return;
                          }                    
                          
                        }else{
                        	if(this.flag_cp =="1" && this.flag_cpDM =="1" ){
                             this.content.setHref(this.controller + "?action=mostrarPreliminarImportacion" );
                          } else {
                            alert("Debe realizar la carga del archivo Completo o ambos libros");
                  		    	return;
                          }
              		    	}
          		    	}
        		    	}              		

            }
      } else {
    					alert(res.messageError);
    					return;
    				}
    			}));
      handler.addErrback(dojo.hitch(this, function(res) {
        			this.waitMessage.hide();
    				alert("Ocurrio un error al momento de ejecutar la consulta.");
    				return;
    			}));
     
  },
  
	setContentPaneLoadingBg: function(content, bg) {
		var size = dojo.marginBox(content.domNode);
		x = Math.floor((size.w - 102)/2);
		y = Math.floor((size.h - 34)/2);
		content.loadingMessage = 
		'<div class="' + bg + '"></div>' +
		'<div class="ext-el-mask-msg x-mask-loading" style="left: ' + x + 'px; top: ' + y + 'px;"><div>Cargando...</div></div>';
	},
     showHiddenDiv: function(node,show) {
     	if (show == true) { //Mostrar
	       node.style.display = "";
      } else { //Ocultar
        	node.style.display = "none";
     	}
    }
          
});
}
