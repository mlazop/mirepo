	function formateoNumero(obj)
{

 
 var numero=convertirNumero(obj.value)
  
  
  
 var num = new NumberFormat();

 num.setInputDecimal('.');
 num.setNumber(numero); 
 num.setPlaces('2', true);
  num.setCurrency(false);
  num.setCurrencyPosition(num.LEFT_OUTSIDE);
  num.setNegativeFormat(num.LEFT_DASH);
  num.setNegativeRed(false);
  num.setSeparators(false, ',', ',');
  obj.value = num.toFormatted();




}


function convertirNumero(num)

	{
			//numero tiene decimales
			
			if ( (num % 1 != 0)   && (num<=99999999.99) ){
				
				return num;
				
			}
			
			else{
			
					
					num=num.substring(0,8);
					
					return num;
			
			}




	}




(function(window, $, _) {
    
				$(document).ready(function() { 
    $('#mostrar-factura').click(function (e) {
        //prevents re-size from happening before tab shown
        e.preventDefault();
          
        //fire re-size of footable
        $('.footable').trigger('footable_resize'); 
    });
	
	
	
});
	
	
	/*
     * :::: CONTAINERS :::: END
     */
    // Notese como se reciclan los selectores para hacer el menor
    // numero de consultas al DOM.
 
    var $containerBusqueda = $("#paso-1");
    var $containerPreview = $("#preliminar-factura");
 
    var $formEmail = $("#email-send");
    var $formBusqueda = $containerBusqueda.find('form');
    var $formByPass = $("#bypassForm");
    var $formNotaDebito = $("#formNotaDebito");
    var $formNotaDebitoDetalles = $("#formNotaDebitoDetalles");
    var $btnMostrarFactura = $("#mostrar-factura");
    var $btnVolverFactura = $("#btnVolverFactura");
    var $modalPreloader = $('#modalPreloader');
    var $modalMensajes = $('#modalMensajes');
 



    $btnMostrarFactura.on('click', function (e) {
        $containerPreview.removeClass('hidden')
        $containerBusqueda.addClass('hidden');
    })

       $btnVolverFactura.on('click', function (e) {
        $containerBusqueda.removeClass('hidden')
        $containerPreview.addClass('hidden');
    })

	var $txtFactura = $('#txtNumFac');
	$txtFactura.change(function() {
		$txtFactura.val($txtFactura.val().replace(/^0+/, ''));		
	});
   
    $formNotaDebito.validate({
        debug: true,

        rules: {
           
            txtFactura: {
                 required: true,
                 digits: true,
                 minlength: 1
            }
        },
        /*** FIX ATTEMPT **/
        invalidHandler: function (event, validator) {
            var offset = $(validator.errorList[0].element).offset();
            $(window).scrollTop(offset.top - 30);
        },
        /*** END / FIX ATTEMPT **/


         submitHandler: function (form) {
                
              $modalPreloader.modal('show');
                var formData = $(form).serializeObject();
                var url = 'emitirNDFEResp.do?action=validarComprobante';
                
                var url_redirigir='emitirNDFEResp.do?action=verDatosIngreso';
                
            $.ajax({
                method: 'post',
                url: url,
                data: formData,
                dataType: 'json',
                success: function (data) {
                               
                             
                              var msj=data.messageError;
							  $('#divMensaje').text(msj);
                              
                                if ( (data.codeError == 1) && (!!msj) ) {
                                    $modalMensajes.modal('show');
								} 
                              else if ( (data.codeError == 4) && (!!msj) )
							   {
                                    $modalMensajes.modal('show');
							   }

                               else if ( (data.codeError == 9) && (!!msj) )
                                    {
                                          $modalMensajes.modal('show');
						
										$('#btnSistema').click(function(){
												 
												window.location.href = url_redirigir;
											});
                                    }
                                else if (data.codeError==0)
                                     {
                                       
                                          window.location.href = "emitirNDFEResp.do?action=verDatosIngreso";
                                    }
                                 
                                else
								{
									console.log(msj);
									
								}
								
                                     


                              
                               
                              
                },
                error: function () {
                                
                                alert('Ha ocurrido un error por favor intentelo dentro de unos minutos.');
                },

                 complete: function () 

                                       {
                                          $modalPreloader.modal('hide');
                                         
                                       }
            });
        }
    });

    

    $formNotaDebitoDetalles.validate({
         onkeyup: false,
		debug: true,
        rules: {
           
             txtMotivo: {
                required: {

                    depends: function() {
                        $(this).val($.trim($(this).val()));
                        return true;
                    }

                },
                minlength: 5

            },

             txtInteres: {
                 required: true,
                 number:true,
                 minimo:0
            }
        },
        /*** FIX ATTEMPT **/
        invalidHandler: function (event, validator) {
            var offset = $(validator.errorList[0].element).offset();
            $(window).scrollTop(offset.top - 30);
        },
        /*** END / FIX ATTEMPT **/
         submitHandler: function (form) {
          form.submit();
        }
    });







    /*
     * :::: FORM VALIDATE :::: / END
     */
 
    $formEmail.validate(_.extend(window._validatorWallSettings, {
        rules: {
            txtEmail: {
                required: true,
                email: true,
				regex: /\b[A-Z0-9._%+-]+@[A-Z0-9.-]+\.[A-Z]{2,4}\b/i 
            }
        },
        submitHandler: function(form) {
            var formData = $(form).serializeObject();
            var url = 'emitirNDFEResp.do?action=enviarCorreo';
			var mensaje_envio='El correo fue enviado.';
			var mensaje_error='Hubo un error por favor intentelo en unos minutos';
            $.ajax({
                method: 'post',
                url: url,
                data: formData,
                success: function() {
 
                     $('#divMensaje').text(mensaje_envio);
					$modalMensajes.modal('show');
 
                    $("#txtEmail").val();
                },
                error: function() {
                     $('#divMensaje').text(mensaje_error);
					$modalMensajes.modal('show');
                }
            });
        }
    }));
 
    /*
     * :::: SETUP :::: START
     */
 
    $modalPreloader.modal({
        backdrop: 'static',
        keyboard: false,
        show: false
    });
 
   // $containerGenerar.find('[data-toggle="popover"]').popover()
 
    
  
  $(".decimal").keydown(function(e) {
        // Permite: backspace, delete, tab, escape, enter and .(190 )
        if ($.inArray(e.keyCode, [46, 8, 9, 27, 13, 110, 190]) !== -1 ||
            // Permite: Ctrl+A
            (e.keyCode == 65 && e.ctrlKey === true) ||
            // Permite: home, end, left, right
            (e.keyCode >= 35 && e.keyCode <= 39)) {
            // solo permitir lo que no este dentro de estas condiciones es un return false
            return;
        }
        // Aseguramos que son numeros
        if ((e.shiftKey || (e.keyCode < 48 || e.keyCode > 57)) && (e.keyCode < 96 || e.keyCode > 105)) {
            e.preventDefault();
        }
    });


var $tabla = $("#table");

   $tabla.footable();

    //$btnBuscar.hide();
    //$btnValidar.hide();
 
    /*
     * :::: SETUP :::: / END
     */
    
    $("[data-toggle]").on('click', function (e) {
        e.preventDefault();
    });
 
})(window, jQuery, _);
