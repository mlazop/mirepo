
var $btnVolverPago = $('#btnVolverPago');	
var $btnVolverMenu = $("#btnVolverMenu");
var $txtSeriePagos = $("#txtSeriePagos");
var $txtNumeroPagos = $("#txtNumeroPagos");
var $txtFechaInicio = $("#txtFechaInicio");
var $txtFechaFin = $("#txtFechaFin");
var $formConsulta = $("#form-consulta");
var $tblLiquidacionesPagos = $("#tblLiquidacionesPagos");



var $formModalPagos = $("#form-modal-pagos");
var $modalPagos = $("#modal-pagos");
var $labelSerieNumero = $("#labelSerieNumero");
var $labeltipoDocReceptor = $("#labeltipoDocReceptor");
var $labelDniReceptor = $("#labelDniReceptor");
var $labelNombreReceptor = $("#labelNombreReceptor");
var $labelMoneda = $("#labelMoneda");
var $labelMonedaPago = $("#labelMonedaPago");
var $labelFechaEmision = $("#labelFechaEmision");
var $labelImporteNeto = $("#labelImporteNeto");
var $labelSaldo = $("#labelSaldo");
var $txtFechaPago = $("#txtFechaPago");
var $txtImportePago = $("#txtImportePago");
var $selMedioPago = $("#selMedioPago");
var $txtEmailPago = $("#txtEmailPago");
var $btnAgregaPago = $("#btnAgregaPago");
var $btnLimpiaPago = $("#btnLimpiaPago");
var $btnGuardar = $("#btnGuardar");
var $btnCerrarPagos = $("#btnCerrarPagos");
var $btnEliminar = $("#btnEliminar");
var $tblPagos = $("#tblPagos");
var $TablaTotalPagos = $("#TablaTotalPagos")

var $ruc;
var $serie;
var $num_cp;
var $cod_cp;
var $fechaEmision = $("#fechaEmision");
var $fechaActual = $("#fechaActual");
var $maxNumPago = 0;
var $fechaLimite = "";

var _arrayPagos= [];

var _arrayPagosParaInsertar= [];
var _arrayPagosParaEliminar= [];

var oTablePagos;

var $saldoInicial = 0;
var $importeNeto  = 0;
var $sumaMontos = 0;
var $saldoQueQueda = $("#saldoQueQueda");
var $mto_canc_pago = 0;
var $mto_canc_deduc = 0;

var $error = $("#div-lista-errores");			
var $entornoAppPagos;

var $esAPPPagos = $("#esAPPPagos").val();

if(!isMobile.any() ) //si no es movil
{	
	//$btnVolverMenu.addClass('hidden');		
}	 

if( isMobile.any() && $esAPPPagos=="1" ) //si es movil
{
	$entornoAppPagos = "pagosliquidacion.htm";
	
}else{// si no es movil
	//alert("ocultando boton");
	$entornoAppPagos = "pagosliquidacion.do";
	$btnVolverMenu.addClass('hidden');		
}	

	
_.each(_mediopago, function (v, k) {
	  $('<option/>', {
		  value: k,
		  selected:(k=='009')
	  }).html(v).appendTo($selMedioPago);
});


$formConsulta.validate(_.extend(window._validatorWallSettings, {
    rules: {
        txtSeriePagos: {
            minlength: 4
        },
        txtNumeroPagos: {
            number: true,
            maxlength: 8
        },
        txtFechaInicio: {
            comparaSiFechaInicioMenorIgualFechaFin: ["#txtFechaInicio", "#txtFechaFin"],
            restaFechas: ["#txtFechaInicio", "#txtFechaFin"]
        }
    },
    messages: {
        txtSeriePagos: {
            minlength: "La serie ingresada no tiene el formato correcto, solo 4 caracteres"
        },
        txtNumeroPagos: {
            number: "El n&uacute;mero de liquidaci&oacute;n de compra debe ser num&eacute;rico de hasta 8 d&iacute;gitos",
            maxlength: "El n&uacute;mero de liquidaci&oacute;n de compra debe ser num&eacute;rico de hasta 8 d&iacute;gitos"
        },
        txtFechaInicio: {
            comparaSiFechaInicioMenorIgualFechaFin: "El rango de fechas no es correcto la fecha desde debe ser menor a la fecha hasta",
            restaFechas: "El rango de consulta excede el plazo m&aacute;ximo permitido de 6 meses, seleccione otro rango de consulta"
        }
    },
    submitHandler: function(form) {
		
		if( ($txtSeriePagos.val()!=""  && $txtNumeroPagos.val()!="")  || ($txtFechaInicio.val()!="" && $txtFechaFin.val()!="")){			
			$error.addClass('hidden');
			cargarBusquedaLiquidaciones();	
		}else{
			//alert("Debe ingresar un criterio de b\u00FAsqueda: Serie y N\u00FAmero o Rango de fechas");				
			
			$error.removeClass('hidden');
			$error.html('<div class="alert alert-danger"><li><span class="error" style="display: inline;">Debe ingresar un criterio de b\u00FAsqueda: Serie y N\u00FAmero o Rango de fechas</span></li></div>');
		}
        
    }
}));

function cargarBusquedaLiquidaciones() {
	
    var url = $entornoAppPagos+"?action=buscarLiquidacionesAnticipo";
    $modalPreloader.modal('show');
    var data = $formConsulta.serializeObject();
	
    $.post(url, data).success(function(response) {
        var data = response.retorno;
        var lista = data.lista;
		
		$tblLiquidacionesPagos.DataTable().clear();
		$tblLiquidacionesPagos.DataTable().destroy();
		
        if (lista.length != 0) {
            cargarLiquidacionesAnticipo(lista);
            $('#root-panels').addClass('hidden')
            $("#panel-liquidacion-consulta").removeClass('hidden');
			$tblLiquidacionesPagos.DataTable().columns.adjust().responsive.recalc();
			if(isMobile.Android() ){
					$tblLiquidacionesPagos.css({"width": "350px"});
			}
        } else {
            bootbox.alert("No existen LC con el criterio solicitado");
        }
        $modalPreloader.modal('hide');
    }).error(function(reason) {
        $modalPreloader.modal('hide');
        bootbox.alert('No existen LC con el criterio solicitado.');
    });
}


function cargarLiquidacionesAnticipo(lista) {
	
	var config_liquidaciones = {	
		responsive: true,
		bProcessing: false,
		bFilter: false,
		bSort: false,
		bAutoWidth: false,
		retrieve: true,		
		order: [],
		language: {
		processing: "Procesando...",
		lengthMenu: "Mostrar _MENU_ registros",
		emptyTable: 'No se encontraron registros',
		zeroRecords: 'No se encontraron registros',
		search: "Buscar:",
		sLoadingRecords: "Cargando...",
		infoFiltered: "(filtrado de un total de _MAX_ registros)",
		info: "Mostrando registros del _START_ al _END_ de un total de _TOTAL_ registros",
		infoEmpty: "Registros del 0 al 0 de un total de 0 registros",
		paginate: {
			"first": "Primero",
			"last": "�ltimo",
			"next": "Siguiente >",
			"previous": "< Anterior"
		}
	},
	data: lista,
	columns: [{
                data: function(row, type, val, meta) {
                    return row.nroruc;
                },
                sClass: 'text-left'
            },
            {
                data: function(row, type, val, meta) {
                    return row.numseriegre;
                },
                sClass: 'text-center'
            },
            {
                data: function(row, type, val, meta) {
                    return row.numgre;
                },
                sClass: 'text-left'
            },
            {
                data: function(row, type, val, meta) {
                    return (row.fecemision.substr(8, 2) + "/" + row.fecemision.substr(5, 2) + "/" + row.fecemision.substr(0, 4));
                },
                sClass: 'text-left'
            },
            {
                data: function(row, type, val, meta) {
					//console.log("coddociderecep:"+row.coddociderecep);
                    return buscarValorArray($.trim(row.coddociderecep), _tipoDocumentoIdentidad);
					//console.log("x:"+x);
					
                },
                sClass: 'text-left'
            },			
            {
                data: function(row, type, val, meta) {
                    return row.numdociderecep;
                },
                sClass: 'text-left'
            },
            {
                data: function(row, type, val, meta) {
                    return row.nombredestinatario;
                },
                sClass: 'text-left'
            },
            {
                data: function(row, type, val, meta) {
                    if (row.mtosaldo>0) {
                        return "Pendiente de pago";
                    } else {
                        return "Cancelado";
                    }

                },
                sClass: 'text-left'
            },
            {
                data: function(row, type, val, meta) {
					var fecha = row.fecemision.substr(8, 2) + "/" + row.fecemision.substr(5, 2) + "/" + row.fecemision.substr(0, 4);
					var id = row.nroruc+"_"+row.numseriegre+"_"+row.numgre+"_"+row.numdociderecep+"_"+row.nombredestinatario+"_"+row.codmoneda+"_"+row.mtoimportetotal+"_"+fecha+"_"+row.coddociderecep;
					var tTable = "<img class='pagos' src='/a/imagenes/nuevo.gif' alt='Ver pagos' title='Ver pagos' value='"+id+"'/>";					
					return tTable;
                },
                sClass: 'text-center'
            }
        ],
		searching: false,
	    bLengthChange: false,
	    pageLength: 5
	};										 

    oTableLiquidaciones = $tblLiquidacionesPagos.dataTable(config_liquidaciones);	
}


$(document).on('click', '.pagos',function (e) {
										   
	//console.log("pagos:"+$(this).attr("value"));		
		
	var id = $(this).attr("value");
	
	obtenerPagos(id);
		
});

function obtenerPagos(id){
	
	var array =id.split("_");
	
	//console.log("id obtenerpagos:"+id);
	
	$ruc = array[0];
	$serie = array[1];
	$num_cp = array[2];
	$cod_cp = "04";	
	$importeNeto = array[6];	
	$fecha = array[7];
	//$tipoDocumento = array[8];

	var url = $entornoAppPagos+"?action=obtenerPagos";
	$modalPreloader.modal('show');

    var data = {
        ruc: $ruc,
        serie: $serie,
        num_cp: $num_cp,
        cod_cp: $cod_cp,
		fecha_emision: $fecha
    };	
	$modalPagos.modal('show');
	$.post(url, data).success(function(response) {
									   
		var data = response.retorno;
		var lista = data.lista;		
		var saldo = data.saldo;				
		
		$maxNumPago = data.maxNumPago;		
		
		//console.log("maxNumPago:"+$maxNumPago);
		
		
		$fechaLimite = data.fechaLimite;		
		//console.log("fechaLimite:"+$fechaLimite);
		
		$saldoInicial = 0;
		$mto_canc_pago = 0;
		$mto_canc_deduc = 0;
		
		if(saldo!=null){
			
			//console.log("saldo.mto_saldo:"+saldo.mto_saldo);
			//console.log("saldo.mto_canc_pago:"+saldo.mto_canc_pago);		
			
			$saldoInicial = saldo.mto_saldo;	   	
			$mto_canc_pago = saldo.mto_canc_pago;
			$mto_canc_deduc = saldo.mto_canc_deduc;		
		}else{
			
			if($saldoInicial==0){
				//console.log("entr�");
				$saldoInicial = $importeNeto;
			}
		}
		
		
		//console.log("$saldoInicial:"+$saldoInicial);
		//console.log("$mto_canc_pago:"+$mto_canc_pago);		
		
		$tblPagos.DataTable().clear();
		$tblPagos.DataTable().destroy();			
		mostrarPagos(lista,id);
		if(isMobile.Android() ){
			$tblPagos.css({"width": "350px"});
		}
		$modalPreloader.modal('hide');
		
	}).error(function(reason) {
		$modalPreloader.modal('hide');
		bootbox.alert('Disculpe, No se puede obtener los pagos registrados anteriormente');
	});	
	
}





function mostrarPagos(lista, id) {
	
	_arrayPagos.length=0;
	_arrayPagosParaInsertar.length=0;
	_arrayPagosParaEliminar.length=0;	
	
	$btnGuardar.prop('disabled', false);
	
	$formModalPagos.find('.alert').remove();
	$formModalPagos.find('.has-error').removeClass('has-error');
	$formModalPagos.find(':input').val('');	
	
	//var id = row.nroruc+"_"+row.numseriegre+"_"+row.numgre+"_"+row.numdociderecep+"_"+row.nombreDestinatario+"_"+row.codmoneda+"_"+row.mtototalventa+row.fecemision;	
	var array =id.split("_");		
	$labelSerieNumero.text(array[1]+"-"+array[2]);
	$labelDniReceptor.text(array[3]);
	$labelNombreReceptor.text(array[4]);
	$labelMoneda.text(buscarValorArray(array[5],_monedaDescripcion));
	
	//console.log("array[6]:"+array[6]);
	$labelImporteNeto.text(formatoMoneda(array[6]));
	
	//console.log("moneda:"+buscarValorArray(array[5],_moneda));
	//$labelMonedaPago.text(buscarValorArray(array[5],_moneda));	
	$labelMonedaPago.html(buscarValorArray(array[5],_moneda));	
	
	$fechaEmision.val(array[7]);	
	$labeltipoDocReceptor.text(buscarValorArray($.trim(array[8]),_tipoDocumentoIdentidad));
	$fechaActual.val(obtenerFecha(0));

	$labelFechaEmision.text(array[7]);
//	console.log("$fechaEmision:"+$fechaEmision.val());
	//console.log("$fechaActual:"+$fechaActual.val());

	
	//$fechaEmision = $fechaEmision.substr(8, 2) + "/" + $fechaEmision.substr(5, 2) + "/" + $fechaEmision.substr(0, 4);
	var dias = restaFechas($fechaEmision.val(),obtenerFecha(0));
	//console.log("dias:"+dias);
	
	var cad = "0d";
	if(dias>0)  cad = "-"+dias+"d";
	
	//console.log("cad:"+cad);	

	
	//$datepicker3.datepicker('setStartDate', cad);	

	///*********************solucion remove
	$datepicker3.datepicker('remove');
	$datepicker3.datepicker({
	}).on('changeDate', function(e) {
		$datepickerHidden3.val(e.format());
		cerrandoCalendario3();
	});	
/*
	$datepicker3.datepicker({
				endDate: '0d',
				startDate: cad
	}).on('changeDate', function(e) {
		$datepickerHidden3.val(e.format());
	});	*/
	
	///*********************fin  solucion remove	
	
	$sumaMontos = 0;

	
	if(lista!=null){	//Se agrega los pagos registrados al array que estara en memoria
		
	  	$.each(lista, function( key, obj ) {
							   
			//console.log("key:"+key);				   													
			var _rowArray = [];			
			_rowArray['basedatos'] = 1;					
			_rowArray['numpago'] = obj.num_pago;
			_rowArray['fechapago'] = obj.fec_pago;
			_rowArray['moneda'] = buscarValorArray(obj.cod_moneda,_monedaDescripcion);				
			_rowArray['importepago'] = obj.mto_pago;		
			_rowArray['mediopago'] = obj.mdo_pago;		
			
			_arrayPagos.push(_rowArray);			
			$sumaMontos	= parseFloat($sumaMontos) + parseFloat(obj.mto_pago);																										
													
		});	
	}
	
	//console.log("$sumaMontos al iniciar:" + $sumaMontos);	
	//console.log("$saldoInicial al iniciar:" + $saldoInicial);	
	//$saldoQueQueda.val(parseFloat($saldoInicial) - parseFloat($sumaMontos));	
	$saldoQueQueda.val(parseFloat($saldoInicial));	
	//console.log("$saldoQueQueda al iniciar:" + $saldoQueQueda.val());		
	
	actualizarListaPagos(lista);	
	//oTablePagos.fnClearTable();	
	limpiarPago();
	
}	


$formModalPagos.validate(_.extend(window._validatorWallSettings, {
    rules: {
        txtFechaPago: {
            required: true,
			comparaSiFechaInicioMenorIgualFechaFin: ["#txtFechaPago","#fechaActual"],
			comparaSiFechaInicioMenorIgualFechaFin2: ["#fechaEmision","#txtFechaPago"]			
			//comparaSiFechaInicioMenorIgualFechaFin: [$("#txtFechaPago").val(), $fechaEmision],
        },
        txtImportePago: {
            required: true,			
            number: true,
			lessThan2: "#saldoQueQueda",
			moreThan:0
        },
        selMedioPago: {
            required: true,			
        }
    },
    messages: {
        txtFechaPago: {
            required: "Seleccione una fecha de pago",
			comparaSiFechaInicioMenorIgualFechaFin: "No puede registrarse un pago con fecha futura",
			comparaSiFechaInicioMenorIgualFechaFin2: "No puede registrarse un pago con fecha menor a la de la emisi&oacute;n de la LC",			
        },
        txtImportePago: {
            number: "Ingrese un importe de pago",
            required: "Ingrese un importe de pago",
			lessThan2:"El importe m&aacute;ximo es el saldo pendiente de cancelar de la LC",
			moreThan:"El importe tiene que ser mayor a cero",
        },
        selMedioPago: {
			 required: "Ingrese un medio de pago"
        }
    },
    submitHandler: function(form) {
			//console.log("$saldoQueQueda :" + $saldoQueQueda.val());	
        agregarPago();
    }
}));	


									
function agregarPago(){
	console.log("agregarPago");	
	var criteria = {
				fechapago: $txtFechaPago.val(),
				importepago: $txtImportePago.val(),
				mediopago: $selMedioPago.val()
	 }; 
  
	duplicated = !! _.findWhere(_arrayPagos, criteria);

	if(duplicated){		
		//console.log("duplicado");
		bootbox.alert('El pago ya ha sido a�adido');
		return;
	}else{
		console.log("no duplicado");	
	}					
	
	
	var resultado = comparaSiFechaInicioMenorIgualFechaFin($txtFechaPago.val(),$fechaLimite);
	
	console.log("resultado:"+resultado);
	if(!resultado){
		
        //if(!confirm('Recuerde que el registro de pagos se podr\u00E1 realizar hasta el s\u00E9timo d\u00EDa calendario siguiente de la fecha de emisi\u00F3n o de la fecha de pago lo que ocurra primero \u00BFEsta seguro de agregar el pago?')){
        //    return;
        //}
		  bootbox.setLocale("es");  
		  bootbox.confirm({
			message: 'Recuerde que el registro de pagos se podr\u00E1 realizar hasta el s\u00E9timo d\u00EDa calendario siguiente de la fecha de emisi\u00F3n o de la fecha de pago lo que ocurra primero \u00BFEsta seguro de agregar el pago?',
			closeButton: false,
			buttons: {
			  confirm: {
				label: 'Aceptar',
			  },
			  cancel: {
				label: 'Cancelar',
			  },
			},
			callback: function (result) {
			  if(result){
				$maxNumPago = $maxNumPago + 1;	
				console.log("maxNumPago:"+$maxNumPago);
				
				var _rowArray = [];			
				_rowArray['numpago'] = $maxNumPago;
				_rowArray['fechapago'] = $txtFechaPago.val();
				_rowArray['moneda'] = $labelMoneda.text();				
				_rowArray['importepago'] = $txtImportePago.val();		
				_rowArray['mediopago'] = $selMedioPago.val();	
				_rowArray['basedatos'] = 0;				
				
				_arrayPagos.push(_rowArray);	
				_arrayPagosParaInsertar.push(_rowArray);	
				$sumaMontos	= parseFloat($sumaMontos) + parseFloat($txtImportePago.val());
				$saldoQueQueda.val(parseFloat($saldoQueQueda.val()) - parseFloat($txtImportePago.val()));
				actualizarListaPagos();
				
				limpiarPago();
			  }
			},
		  });
		
	}
	
	

			$maxNumPago = $maxNumPago + 1;	
			console.log("maxNumPago:"+$maxNumPago);
			
			var _rowArray = [];			
			_rowArray['numpago'] = $maxNumPago;
			_rowArray['fechapago'] = $txtFechaPago.val();
			_rowArray['moneda'] = $labelMoneda.text();				
			_rowArray['importepago'] = $txtImportePago.val();		
			_rowArray['mediopago'] = $selMedioPago.val();	
			_rowArray['basedatos'] = 0;				
			
			_arrayPagos.push(_rowArray);	
			_arrayPagosParaInsertar.push(_rowArray);	
			
			$sumaMontos	= parseFloat($sumaMontos) + parseFloat($txtImportePago.val());
			$saldoQueQueda.val(parseFloat($saldoQueQueda.val()) - parseFloat($txtImportePago.val()));
			actualizarListaPagos();
			
			limpiarPago();
		 
	
}
//});

function limpiarPago(){	
	$txtFechaPago.val("");									
	$txtImportePago.val("");
	$selMedioPago.val("009");		
}

$btnLimpiaPago.on('click', function(e) {										
	limpiarPago();							
});

//$btnAgregaPago.on('click', function(e) {	





function actualizarListaPagos(){

	//console.log("$saldoQueQueda.val():"+$saldoQueQueda.val());
	//console.log("formatoMoneda($saldoQueQueda.val()):"+formatoMoneda($saldoQueQueda.val()));
	
	$labelSaldo.text(formatoMoneda($saldoQueQueda.val()));
	$TablaTotalPagos.text(formatoMoneda($sumaMontos));

	var cadena = "";
	$.each( _arrayPagos, function( key, obj ) {																			
		cadena = cadena + '{ "numpago": "'+ obj.numpago +'", "fechapago": "'+obj.fechapago+'", "moneda": "'+obj.moneda+'", "importepago": "'+obj.importepago+'", "mediopago":"'+obj.mediopago+'" , "basedatos":"'+obj.basedatos+'" },';
	  
	});	
	
	cadena = cadena.substring(0, cadena.length-1);			
	cadena = "["+ cadena + "]";	
	
	//console.log("cadena:"+cadena);

	var obj = jQuery.parseJSON(cadena);
	
	var data = jQuery.map(obj, function(el, i) {
	  return [[el.numpago, el.fechapago, el.moneda, el.importepago,el.mediopago,el.basedatos]];
	});	
	
	if(oTablePagos!=null){
		oTablePagos.dataTable().fnDestroy();
	}
	//$tblPagos.DataTable().columns.adjust().responsive.recalc();	
	cargarPagos(data);
}



function cargarPagos(lista) {
	
	//console.log("cargarPagos");

	var config_pagos = {	
		responsive: true,
		bProcessing: false,
		bFilter: false,
		bSort: false,
		bAutoWidth: false,
		retrieve: true,		
		order: [],
		language: {
			processing: "Procesando...",
			lengthMenu: "Mostrar _MENU_ registros",
			emptyTable: 'No se encontraron registros',
			zeroRecords: 'No se encontraron registros',
			search: "Buscar:",
			sLoadingRecords: "Cargando...",
			infoFiltered: "(filtrado de un total de _MAX_ registros)",
			info: "Mostrando registros del _START_ al _END_ de un total de _TOTAL_ registros",
			infoEmpty: "Registros del 0 al 0 de un total de 0 registros",
			paginate: {
				"first": "Primero",
				"last": "�ltimo",
				"next": "Siguiente >",
				"previous": "< Anterior"
			}
		},
	data: lista,
	columns: [		  
			  
	          {
				  data: function(row, type, val, meta) {
					  return row[0];
				  },
				  sClass: 'text-center',
			      sTitle: "Nro"
	          },
	          {
	        	  data: function(row, type, val, meta) {
					  //return (row.fechapago.substr(8, 2) + "/" + row.fechapago.substr(5, 2) + "/" + row.fechapago.substr(0, 4));
					  return row[1];				  
				  },
				  sClass: 'text-left',
				  sTitle: "Fecha de<br> Pago"
	          },			  
	          {
	        	  data: function(row, type, val, meta) {
	        	  return row[2];
				  },
				  sClass: 'text-left',
 				  sTitle: "Moneda"
				  },			
	          {
	        	  data: function(row, type, val, meta) {
	        	  return formatoMoneda(row[3]);    
				  },
				  sClass: 'text-left',
				  sTitle: "Importe"
	          },
	          {
	        	  data: function(row, type, val, meta) {
	        	  return buscarValorArray(row[4],_mediopago);
				  },
				  sClass: 'text-left',
				  sTitle: "Medio de<br> Pago"
	          },
	          {
	        	  data: function(row, type, val, meta) {
					//onclick='incluir(" + nombreCheck + ");'
		        	  var id = row[0];
					  
					  
					  var basedatos = row[5];
					  //console.log("basede gatos:"+basedatos);
					  var tTable = "";
					  /*
					  if(basedatos==1){						  
						tTable = "<img class='noeliminarPagos' src='/a/imagenes/delete2.gif' alt='No se puede eliminar' title='No se puede eliminar' value='"+id+"' style='width: 16px; height: 16px;'/>";					    
					  }else{*/
						tTable = "<img class='eliminarPagos' src='/a/imagenes/delete.gif' alt='Eliminar Pago' title='Eliminar Pago' value='"+id+"'/>";					  
					  //}
					  
					  return tTable;				  
				  
				  }
	          }		  
		  ],
		  searching: false,
		  bLengthChange: false,
		  "pageLength": 5
	};										 

    oTablePagos = $tblPagos.dataTable(config_pagos);
	
	   $('#tblPagos th').eq(4).css('white-space','normal'); //.addClass("formato_mediospago");
       $('#tblPagos td').eq(4).css('white-space','normal');//addClass("formato_mediospago");	
	
}


$(document).on('click', '.noeliminarPagos',function (e) {
	bootbox.alert("El pago se encuentra en  el libro de compras por tanto no puede ser eliminado");												 
  });



$(document).on('click', '.eliminarPagos',function (e) {
	
	//if(!confirm('\u00BFEst\u00E1 seguro de eliminar el registro?')){
	//	return;
	//}	
	var id = $(this).attr('value');
	
	  bootbox.setLocale("es");
      bootbox.confirm({
        message: '\u00BFEst\u00E1 seguro de eliminar el registro?',
        closeButton: false,
        buttons: {
          confirm: {
            label: 'Aceptar',
          },
          cancel: {
            label: 'Cancelar',
          },
        },
        callback: function (result) {
          if(result){
			  //var id = $(this).attr('value');
			   console.log("id a elimnar:"+id);
			  
			  var sw = 0;	
			  var $montoRestar = 0;
			  
				$.each(_arrayPagos, function( key, obj ) {			  			  
					var _rowArray = [];			
					_rowArray['numpago'] = obj.numpago;
					_rowArray['fechapago'] = obj.fechapago;		
					_rowArray['moneda'] = obj.moneda;		
					_rowArray['importepago'] = obj.importepago;	
					_rowArray['mediopago'] = obj.mediopago;
					_rowArray['basedatos'] = obj.basedatos;
					
					//console.log("numpago:"+obj.numpago);
				   
					if(obj.numpago==id){	
					
						//console.log("Entro");
						
						$montoRestar = obj.importepago;
						_arrayPagos.splice(key, 1);			
						
						//Si esta registrado en BD, se agrega a una array de eliminados para enviar al controlador
						if(obj.basedatos==1){
							_arrayPagosParaEliminar.push(_rowArray);	
						}else{
							$maxNumPago = $maxNumPago - 1;				
						}
						
						$sumaMontos	= parseFloat($sumaMontos) - parseFloat(obj.importepago);				
						//$saldoInicial = parseFloat($saldoInicial) + parseFloat(obj.importepago);					
						sw=1;
						
					}	  	
					if(sw==1) return false;
					
				});		

				sw = 0;

				//Se retira del array para insertar, el registro elimado
				$.each(_arrayPagosParaInsertar, function( key, obj ) {			  			  
					if(obj.numpago==id){			
						//console.log("Entro a eliminar de insertar");					
						_arrayPagosParaInsertar.splice(key, 1);							
						sw=1;			
					}	  	
					if(sw==1) return false;		
				});

				//console.log("$saldoInicial al eliminar:" + $saldoInicial);				

				//console.log("$sumaMontos al eliminar:" + $sumaMontos);
				//console.log("$montoRestar al eliminar:" + $montoRestar);
				//console.log("$saldoQueQueda :" + $saldoQueQueda.val());			
				$saldoQueQueda.val(parseFloat($saldoQueQueda.val()) + parseFloat($montoRestar));
				//console.log("$saldoQueQueda al eliminar:" + $saldoQueQueda.val());		
				
				actualizarListaPagos();
		  
		  
          }
        },
      });
					
 });



$txtImportePago.on('change', function(e) {								  
									  
});


$btnCerrarPagos.on('click', function(e) {				
	//if(confirm('Se perder\u00E1n los cambios registrados, \u00BFdesea continuar?')){
	//	$modalPagos.modal('hide');
	//}
	
	  bootbox.setLocale("es");  
      bootbox.confirm({
        message: 'Se perder\u00E1n los cambios registrados, \u00BFdesea continuar?',
        closeButton: false,
        buttons: {
          confirm: {
            label: 'Aceptar',
          },
          cancel: {
            label: 'Cancelar',
          },
        },
        callback: function (result) {
          if(result){
			$modalPagos.modal('hide');
          }
        },
      });
								 
});

$btnGuardar.on('click', function(e) {
								 
	if(_arrayPagosParaInsertar.length>0){		
		if(!validaEmail($txtEmailPago.val())){
			if($txtEmailPago.val()==""){
				bootbox.alert("Se debe registrar el correo electr\u00F3nico donde enviar la Constancia de Pagos registrados");
				$txtEmailPago.focus();				
			}else{
				bootbox.alert("Verifique su email");
				$txtEmailPago.focus();				
			}			
			return;
		}	
	}
		
	//console.log("_arrayPagosParaInsertar.length:"+_arrayPagosParaInsertar.length);
		
	if(_arrayPagosParaInsertar.length==0 && _arrayPagosParaEliminar.length==0){
		bootbox.alert("Ingrese al menos un registro de pago");
		return;
	}
								 
								 
		//console.log("guardandooo....");								 
		$btnGuardar.prop('disabled', true);
		$modalPreloader.modal('show');
		
		var _arrayTempoInsertar = [];

		//console.log("_arrayPagosParaInsertar:"+_arrayPagosParaInsertar);
		$.each(_arrayPagosParaInsertar, function( key, obj ) {		
									 
/*			console.log("key:"+key)
			console.log("numpago:"+obj.numpago);
			console.log("fechapago:"+obj.fechapago);
			console.log("moneda:"+obj.moneda);
			console.log("importepago:"+obj.importepago);
			console.log("mediopago:"+obj.mediopago);*/	
			
			var tempo = {	numpago : obj.numpago+"",
							fechapago: obj.fechapago,
							moneda: buscarValorArray(obj.moneda,_monedaDescripcion2),
							importepago: obj.importepago,
							mediopago: obj.mediopago							
			}
			_arrayTempoInsertar.push(tempo);					
		 });
		
		
		var _arrayTempoEliminar = [];
		//console.log("_arrayPagosParaEliminar:"+_arrayPagosParaEliminar);
		$.each(_arrayPagosParaEliminar, function( key, obj ) {		
									 
/*			console.log("key:"+key)
			console.log("numpago:"+obj.numpago);
			console.log("fechapago:"+obj.fechapago);
			console.log("moneda:"+obj.moneda);
			console.log("importepago:"+obj.importepago);
			console.log("mediopago:"+obj.mediopago);	
			console.log("basedatos:"+obj.basedatos);	*/
		
			var tempo = {	numpago : obj.numpago+"",
							fechapago: obj.fechapago,
							moneda: buscarValorArray(obj.moneda,_monedaDescripcion2),
							importepago: obj.importepago,
							mediopago: obj.mediopago							
			}
			_arrayTempoEliminar.push(tempo);					

		 });		

		//var sum = parseFloat($importeNeto) - parseFloat($sumaMontos);
		//sum = sum - parseFloat($mto_canc_deduc);
		//$saldoQueQueda.val(sum);

	    var _datosEnvio = {		
			emisor: {
			  ruc: $ruc,
			  serie: $serie,
			  cod_cp: $cod_cp,
			  num_cp: $num_cp,
			  emailPago:$txtEmailPago.val(),
			  numdociderecep: $labelDniReceptor.text(),
			  nombreDestinatario:$labelNombreReceptor.text(),
			  desde:"pagos",
			  mto_saldo: parseFloat($saldoQueQueda.val()),			  
			  mto_canc_pago: $sumaMontos,
			  mto_canc_deduc: $mto_canc_deduc
			},		
			pagosInsertar: _arrayTempoInsertar,
			pagosEliminar: _arrayTempoEliminar			
	    };		
  
  		//console.log("$entornoAppPagos:"+$entornoAppPagos);
        var url = $entornoAppPagos+"?action=grabarPagos";
		 $.ajax({
						data: { variable:JSON.stringify(_datosEnvio),					 
				 },
				method: 'post',
				//contentType: "application/text; charset=UTF-8",
				dataType: 'json',
				url: url,
			})
			 .done(function( data, textStatus, jqXHR ) {
				 if ( console && console.log ) {					 
				 
				 $modalPreloader.modal('hide');						 
				 //console.log("data:"+data);				 
					 if(data!="0"){
						bootbox.alert("Se registraron los pagos");	
						$modalPagos.modal('hide');
					 }else{
						$btnGuardar.prop('disabled', false);
						bootbox.alert("No se pudo registrar los pagos, int\u00E9ntelo nuevamente");					
					}
				 }
			 })
			 .fail(function( jqXHR, textStatus, errorThrown ) {
				 if ( console && console.log ) {
					 //console.log( "La solicitud a fallado: " +  textStatus);
				 }
			});   
								 
								 

});


$btnVolverPago.on('click', function(e) {
    $('#root-panels').removeClass('hidden')
    $("#panel-liquidacion-consulta").addClass('hidden');
	$txtSeriePagos.val("");
	$txtNumeroPagos.val("");	
	$txtFechaInicio.val("");
	$txtFechaFin.val("");	
    $("#estados_0").prop("checked", true);
});

//$txtFechaInicio.val(obtenerPrimerDiaMes());
//$txtFechaInicio.val(obtenerFecha(-90));
//$txtFechaFin.val(obtenerFecha(0));

var $modalDatepicker1 = $('#modal-datepicker1');
var $datepicker1 = $modalDatepicker1.find("#datepicker1-placeholder");
var $datepicker1Hidden = $modalDatepicker1.find("#datepicker1-value");
var $btnCloseDatepicker1 = $modalDatepicker1.find('#modal-datepicker1-close');


var _CURR_DATE_PICKER1 = null;
$('.datepicker1').on('click', function(e) {
    _CURR_DATE_PICKER1 = $(e.target);
    $modalDatepicker1.modal('show');
});
$datepicker1.datepicker({
    // endDate: new Date(),
    /*		showOn: "button",
    		endDate: '0d',
            startDate: '-2d'*/
    //maxDate:'1'
}).on('changeDate', function(e) {
    $datepicker1Hidden.val(e.format());
	cerrandoCalendario1();
});

function cerrandoCalendario1(){	

	if($datepicker1Hidden.val()!=""){										 
		var selectedDate = $datepicker1Hidden.val();
		_CURR_DATE_PICKER1.val(selectedDate).trigger('change');
		$datepicker1Hidden.val('');
		_CURR_DATE_PICKER1 = null;
		$modalDatepicker1.modal('hide');
	}else{
		bootbox.alert("Haga click en la fecha deseada");	
	}
}

$btnCloseDatepicker1.on('click', function(e) {										 
	cerrandoCalendario1();
});

$('#butoncalendar1').on('click', function(e) {
    _CURR_DATE_PICKER1 = $(".datepicker1");
    $modalDatepicker1.modal('show');
});



var $modalDatepicker2 = $('#modal-datepicker2');
var $datepicker2 = $modalDatepicker2.find("#datepicker2-placeholder");
var $datepickerHidden2 = $modalDatepicker2.find("#datepicker2-value");
var $btnCloseDatepicker2 = $modalDatepicker2.find('#modal-datepicker2-close');

var _CURR_DATE_PICKER2 = null;
$('.datepicker2').on('click', function(e) {
    _CURR_DATE_PICKER2 = $(e.target);
    $modalDatepicker2.modal('show');
});
$datepicker2.datepicker({
    // endDate: new Date(),
    /*		endDate: '0d',
            startDate: '-2d'*/
    //maxDate:'1'
}).on('changeDate', function(e) {
    $datepickerHidden2.val(e.format());
	cerrandoCalendario2();
});

function cerrandoCalendario2(){										  
	if($datepickerHidden2.val()!=""){											  
		var selectedDate = $datepickerHidden2.val();
		_CURR_DATE_PICKER2.val(selectedDate).trigger('change');
		$datepickerHidden2.val('');
		_CURR_DATE_PICKER2 = null;
		$modalDatepicker2.modal('hide');
	}else{
		bootbox.alert("Haga click en la fecha deseada");			
	}	
}

$btnCloseDatepicker2.on('click', function(e) {
	cerrandoCalendario2();
});

$('#butoncalendar2').on('click', function(e) {
    _CURR_DATE_PICKER2 = $(".datepicker2");
    $modalDatepicker2.modal('show');
});	


var $modalDatepicker3 = $('#modal-datepicker3');
var $datepicker3 = $modalDatepicker3.find("#datepicker3-placeholder");	
var $datepickerHidden3 = $modalDatepicker3.find("#datepicker3-value");
var $btnCloseDatepicker3 = $modalDatepicker3.find('#modal-datepicker3-close');
var _CURR_DATE_PICKER3 = null;

$('.datepicker3').on('click', function(e) {
	_CURR_DATE_PICKER3 = $(e.target);
	$modalDatepicker3.modal('show');
});


function cerrandoCalendario3(){		
	if($datepickerHidden3.val()!=""){											  
		var selectedDate = $datepickerHidden3.val();
		_CURR_DATE_PICKER3.val(selectedDate).trigger('change');
		$datepickerHidden3.val('');
		_CURR_DATE_PICKER3 = null;
		$modalDatepicker3.modal('hide');
	}else{
		bootbox.alert("Haga click en la fecha deseada");			
	}
}



$btnCloseDatepicker3.on('click', function(e) {										  
	cerrandoCalendario3();
});

$('#butoncalendar3').on('click', function(e) {
	_CURR_DATE_PICKER3 = $(".datepicker3");
	$modalDatepicker3.modal('show');
});		


/*$datepicker3.datepicker({
	// endDate: new Date(),
			endDate: '0d',
			startDate: '-1d'
	//maxDate:'1'
}).on('changeDate', function(e) {
	$datepickerHidden3.val(e.format());
});	*/

//$txtEmailPago.val("ldanyruiz@hotmail.com");

if(isMobile.iOS() ){
	
	   $("#container2").css({"width": window.screen.width});
	   $("#modal-pagos").css({"width": window.screen.width});	   	   	      
   
	   
	   //$(".modal").css({"width": window.screen.width});        
	   //$(".th").css({"width": "10%"});  
	   
	   //$(".wrapper-content").css({"padding": "20px 10px 20px 0px"});              
	   //$(".wrapper").css({"padding": "0px 20px 0px 0px"});
	
}


//$txtSeriePagos.val("E001");
//$txtNumeroPagos.val("150");