
var $formTerminos = $('#form-terminos');	
var $chkacepto = $("#chkacepto");
var $btnvolver = $("#btnvolver");
var $esAPP = $("#esAPP").val();

if( isMobile.any() ) //si es movil
{	
}else{// si no es movil

}	


if( isMobile.any() && $esAPP=="1" ) //si es movil
{
	$entornoAppPagos = "emitirliquidacion.htm";	
}else{// si no es movil
	$entornoAppPagos = "emitirliquidacion.do";
    $btnvolver.addClass('hidden');	
}	

//console.log("$esAPP:"+$esAPP);




function irModulo() {
	
    var url = $entornoAppPagos+"?action=inicio2";
    var data = $formTerminos.serializeObject();
	
//	console.log("url:"+url);
	
	location.href = "/ol-ti-itemisionliquidacion/"+url;		
	
/*    $.post(url, data).success(function(response) {
									   
		alert("return");									   
    }).error(function(reason) {
        alert('No existen LC con el criterio solicitado.');
    });*/
}


$formTerminos.validate(_.extend(window._validatorWallSettings, {
    rules: {
        chkacepto: {
            required: true
        }
    },
    messages: {
        chkacepto: {
            required: "Debe leer y aceptar los t&eacute;rminos de las condiciones"
        }
    },
    submitHandler: function(form) {
        irModulo();
    }
}));	
