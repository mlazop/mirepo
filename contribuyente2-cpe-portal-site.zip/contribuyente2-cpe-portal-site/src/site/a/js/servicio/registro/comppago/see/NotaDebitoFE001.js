	function mostrarMensaje(msj, tipo = 1 )  {

			if ( dijit.byId('dlgMensaje') != undefined ) {
					require(["dojo/dom-construct"], function(domConstruct){
					  dijit.byId('dlgBtnAceptar').destroy();
					  dijit.byId('dlgMensaje').destroy();
					});
			}

			var aceptarDialog = new dijit.Dialog({ id: 'dlgMensaje', title: "Mensaje" });
			var respCallback = function(mouseEvent) {
					aceptarDialog.hide();
			};

			dojo.connect(aceptarDialog,"onCancel",function(){
					aceptarDialog.hide();
			});

			switch (tipo) {
					case 0: // OK
							questionDiv = dojo.create("div", {innerHTML:"<table><tr style='height:70px'><td><img src='/a/imagenes/pase_embarque.gif' border='0' alt=''></td><td style='padding-left: 5px;'>" + msj + "</td></tr></table>"});
							break;
					case 1: // INFO
							questionDiv = dojo.create("div", {innerHTML:"<table><tr style='height:70px'><td><img src='/a/imagenes/sigad/acciones/advertencia.gif' border='0' alt=''></td><td style='padding-left: 5px;'>" + msj + "</td></tr></table>"});
							break;
					case 2: // WARNING
							questionDiv = dojo.create("div", {innerHTML:"<table><tr style='height:70px'><td><img src='/a/imagenes/sigad/acciones/advertencia.gif' border='0' alt=''></td><td style='padding-left: 5px;'>" + msj + "</td></tr></table>"});
							break;
					case 3: // ERROR
							questionDiv = dojo.create("div", {innerHTML:"<table><tr style='height:70px'><td><img src='/a/imagenes/pase_no_embarque.gif' border='0' alt=''></td><td style='padding-left: 5px;'>" + msj + "</td></tr></table>"});
							break;
			}

			var aceptarButton = new dijit.form.Button( { label: 'Aceptar', id: 'dlgBtnAceptar', onClick: respCallback });
			var centroDiv = dojo.create('div', { style: { margin: "auto", textAlign: "center"} } );

			aceptarDialog.containerNode.appendChild(questionDiv);
			aceptarDialog.containerNode.appendChild(centroDiv);
			centroDiv.appendChild(aceptarButton.domNode);
			aceptarDialog.show();
	}

	//csanchezpe: se acrega accion cancelar para el caso de los else
	function mostrarMensajeConfirmacion ( msj, accionBtnAceptar, accionBtnCancelar = function() {} )  {

			if ( dijit.byId('dlgMensajeConfirmacion') != undefined ) {
					require(["dojo/dom-construct"], function(domConstruct){
					  dijit.byId('dlgBtnAceptarConfirm').destroy();
					  dijit.byId('dlgBtnCancelarConfirm').destroy();
					  dijit.byId('dlgMensajeConfirmacion').destroy();
					});
			}

			var dlgConfirmacion = new dijit.Dialog({ id: 'dlgMensajeConfirmacion', title: "Confirmar" });

			var respCallAceptar = function() {
				accionBtnAceptar();
				dlgConfirmacion.hide();
			};

			var respCallCancelar = function() {
				accionBtnCancelar();
				dlgConfirmacion.hide();
			};

			dojo.connect(dlgConfirmacion, "onCancel", function() {
				dlgConfirmacion.hide();
			});

			questionDiv = dojo.create("div", {innerHTML:"<table><tr style='height:70px'><td><img src='/a/imagenes/icons/questionMark32px.png' border='0' alt=''></td><td style='padding-left: 5px;'>" + msj + "</td></tr></table>"});

			var aceptarButton = new dijit.form.Button( { label: 'Aceptar', id: 'dlgBtnAceptarConfirm', onClick: respCallAceptar });
			var cancelarButton = new dijit.form.Button( { label: 'Cancelar', id: 'dlgBtnCancelarConfirm', onClick: respCallCancelar });

			var centroDiv = dojo.create('div', { style: { margin: "auto", textAlign: "center"} } );

			dlgConfirmacion.containerNode.appendChild(questionDiv);
			dlgConfirmacion.containerNode.appendChild(centroDiv);
			centroDiv.appendChild(aceptarButton.domNode);
			centroDiv.appendChild(cancelarButton.domNode);
			dlgConfirmacion.show();
	}
	
/**
 * NotaDebitoFE.js - JavaScript de la Emision de Notas de Cr\u00E9dito de Factura Electr\u00F3nica.
 * Author: Patricia Chacaliaza
 * Fecha: 13-01-2011
 * ResponseBean : codeError; messageError; data;
 */
if (!dojo._hasResource["servicio.registro.comppago.see.NotaDebitoFE"]) {
    dojo._hasResource["servicio.registro.comppago.see.NotaDebitoFE"] = true;
    dojo.provide("servicio.registro.comppago.see.NotaDebitoFE");
    
    dojo.require("dojo.data.ItemFileWriteStore");
    dojo.require("dojo.io.iframe");
    
    dojo.declare("servicio.registro.comppago.see.NotaDebitoFE", null, {
       store: null,   
       facturaBean: null,
       currentLine:null,
       bCargando:null,
       controller: "emitirNDFE.do",
        
       constructor: function(){ },
        
       initialize: function(){
			this.facturaBean = null;
			this.igvFE = null;
			this.content = dijit.byId("content");    		
			this.waitMessage = dijit.byId("waitMessage");
			this.dialogItem =  dijit.byId("dialogItem");        
        },
        
        startup: function(){
            dojo.parser.parse(dojo.byId('container'));
            setTimeout(dojo.hitch(this, function(){
                this.hideLoader();
            }), 250);
        },
        
        hideLoader: function(){
            this.initialize();
            var loader = dojo.byId('loader');
            var _this = this;
            dojo.fadeOut({
                node: loader,
                duration: 250,
                onEnd: function(){
                	dijit.byId('content').domNode.style.visibility = "visible";            	
                    loader.style.display = "none";
                }
            }).play();
        },
         
        initContent: function(){
            /*Nada al cargar el formulario*/
        	this.store = null;
        	//this.facturaBean = null;
        	dijit.hideTooltip(dojo.byId("numeroComprobante"));
        	dijit.focus(dojo.byId("pantallaInicial.tipoNotaDebito"));
        },  	
    	
         
      	preventCache: function() {
      		return new Date().valueOf();
      	} ,
	 
    //PAS20181U210300095
	inicializarDocumentosReceptorPenalidad: function(show){
		this.showHiddenDiv(document.getElementById("inicio.id.show"),show);
		this.showHiddenDiv(document.getElementById("inicio.leyendaNota43.show"),show);
		
		if (show){
			dojo.byId("pantallaInicial.feref.label").innerHTML="N&uacute;mero de FE respecto de la cual se emite la Nota de D&eacute;bito (*)";
		}else{
			dojo.byId("pantallaInicial.feref.label").innerHTML="N&uacute;mero de FE respecto de la cual se emite la Nota de D&eacute;bito";
		}
		
		dijit.byId("pantallaInicial.tipoId").setValue("");
		dijit.byId("pantallaInicial.tipoId").setAttribute('disabled', false);
		dijit.byId("pantallaInicial.nroId").setValue("");
		dijit.byId("pantallaInicial.nroId").setAttribute('disabled', true);
		dijit.byId("pantallaInicial.razonSocial").setValue("");
		dijit.byId("pantallaInicial.razonSocial").setAttribute('disabled', true);
	},
	
	showOpcionesPorTipoNDFE: function() {    
		valor = dijit.byId("pantallaInicial.tipoNotaDebito").value;
		
		//PAS20181U210300095
		this.inicializarDocumentosReceptorPenalidad(false);
		
		if (valor == "" ) {
			this.showHiddenDiv(document.getElementById("inicio.motivo.show"),true);
        	this.showHiddenDiv(document.getElementById("inicio.descuentosFE.show"),false);
        }	          
        
		if (valor == "41") {
			this.showHiddenDiv(document.getElementById("inicio.motivo.show"),true);
			this.showHiddenDiv(document.getElementById("inicio.descuentosFE.show"),true);
        }
        
		if (valor == "42") {
			this.showHiddenDiv(document.getElementById("inicio.motivo.show"),true);
        	dijit.byId("pantallaInicial.interesMoraND").setValue("");
        	this.showHiddenDiv(document.getElementById("inicio.descuentosFE.show"),false);
		}
		
		if (valor == "43") {
			this.showHiddenDiv(document.getElementById("inicio.motivo.show"),true);
        	this.showHiddenDiv(document.getElementById("inicio.descuentosFE.show"),true);
			this.showHiddenDiv(document.getElementById("inicio.leyendaNota43.show"),true);
			//PAS20181U210300095
			this.inicializarDocumentosReceptorPenalidad(true);
		}
		
		if (valor == ""){
			dijit.byId("pantallaInicial.tipoNotaDebito").focus();
		} else {
			dijit.byId("pantallaInicial.numeroFE").focus();
		}
	},
	
	showOpcionesPorTipoNDFEContin: function() {    
		valor = dijit.byId("pantallaInicial.tipoNotaDebito").value;
		
		//PAS20181U210300095
		this.inicializarDocumentosReceptorPenalidad(false);
		
		if (valor == "" ) {
			this.showHiddenDiv(document.getElementById("inicio.motivo.show"),true);
        	this.showHiddenDiv(document.getElementById("inicio.descuentosFE.show"),false);
        }	          
        
		if (valor == "41") {
			this.showHiddenDiv(document.getElementById("inicio.motivo.show"),true);
			this.showHiddenDiv(document.getElementById("inicio.descuentosFE.show"),true);
        }
        
		if (valor == "42") {
			this.showHiddenDiv(document.getElementById("inicio.motivo.show"),true);
        	dijit.byId("pantallaInicial.interesMoraND").setValue("");
        	this.showHiddenDiv(document.getElementById("inicio.descuentosFE.show"),false);
		}
		
		if (valor == "43") {
			this.showHiddenDiv(document.getElementById("inicio.motivo.show"),true);
        	this.showHiddenDiv(document.getElementById("inicio.descuentosFE.show"),true);
			this.showHiddenDiv(document.getElementById("inicio.leyendaNota43.show"),true);
			//PAS20181U210300095
			this.inicializarDocumentosReceptorPenalidad(true);
		}
		
		if (valor == ""){
			dijit.byId("pantallaInicial.tipoNotaDebito").focus();
		}  else {
			//dijit.byId("pantallaInicial.numeroFE").focus();
			document.getElementById("serie").focus();
		}
		
	},
	
       
	   
    verFacturaND: function() {
    	serieFE = dijit.byId("pantallaInicial.serieFE").value;
    	numeroFE = dijit.byId("pantallaInicial.numeroFE").value;
    	if (numeroFE == ""){
    		//alert("Debe registrar el n\xFAmero de la Factura Electr\xf3nica.");
    		mostrarMensaje("Para visualizar el comprobante debe de ingresar la serie y el n\xFAmero del comprobante Electr\xf3nico.");
    		return;
    	}
    	
    	var handler = dojo.xhrGet({
    		url: this.controller + "?action=obtenerXml&serie=" + serieFE + "&factura=" + numeroFE,
    		handleAs: "json",
    		sync: true,
    		timeout: 10000
    	});        
        
    	handler.addCallback(dojo.hitch(this, function(res){
    		if (res.codeError == 0) {
    			var xml = dijit.byId("facturaxml");
    			var dFactura = dijit.byId("dialogFactura");
    			if(dFactura) {      
    				dFactura.show();
    				xml.attr("href","FacturaGenerada.jsp");
    			}                                                   
    		} else {                                 
    			mostrarMensaje(res.messageError);
    			return;
    		}
    	}));
    	
    	handler.addErrback(function(res){
    		this.waitMessage.hide();
    		mostrarMensaje("Problemas al conectarse con el servidor");
    	});          
    },
	
	verFacturaNDContin: function() {
    	//serieFE = dijit.byId("pantallaInicial.numeroFE").value;
		var serieFE = document.getElementById("idSerie").value;
    	numeroFE = dijit.byId("pantallaInicial.numeroFE").value;
		
    	if (numeroFE == ""){
    		//alert("Debe registrar el n\xFAmero de la Factura Electr\xf3nica.");
    		mostrarMensaje("Para visualizar el comprobante debe de ingresar la serie y el n\xFAmero del comprobante por 	Contingencia.");
    		return;
    	}
    	
    	var handler = dojo.xhrGet({
    		url: this.controller + "?action=obtenerXmlContin&idSerie=" + serieFE + "&factura=" + numeroFE,
    		handleAs: "json",
    		sync: true,
    		timeout: 10000
    	});        
        
    	handler.addCallback(dojo.hitch(this, function(res){
    		if (res.codeError == 0) {
    			var xml = dijit.byId("facturaxml");
    			var dFactura = dijit.byId("dialogFactura");
    			if(dFactura) {      
    				dFactura.show();
    				xml.attr("href","FacturaGenerada.jsp");
    			}                                                   
    		} else {                                 
    			mostrarMensaje(res.messageError);
    			return;
    		}
    	}));
    	
    	handler.addErrback(function(res){
    		this.waitMessage.hide();
    		mostrarMensaje("Problemas al conectarse con el servidor");
    	});          
    },
	
	
	//PAS20181U210300095
	isValidRuc: function(ruc) {
		ruc = dojo.trim(ruc);
		if(!isNaN(ruc)) {
			if(ruc.length == 8) {
				suma = 0;
				for(i=0; i < ruc.length-1; i++) {
					digito = ruc.charAt(i) - '0';
					if(i == 0) suma += (digito * 2);
					else suma += (digito * (ruc.length - i));
				}
				resto = suma % 11;
				if(resto == 1) resto = 11;
				if(resto + (ruc.charAt(ruc.length - 1) - '0') == 11) {
					return true;
				}
			}
			else if(ruc.length == 11){
				suma = 0;
				x = 6;
				for(i=0; i < ruc.length - 1; i++) {
					if(i == 4) x = 8;
					digito = ruc.charAt(i) - '0';
					x--;
					if(i == 0) suma += (digito * x);
					else suma += (digito * x);
				}
				resto = suma % 11;
				resto = 11 - resto;
				if(resto >= 10) resto = resto - 10;
				if(resto == ruc.charAt(ruc.length - 1) - '0') {
					return true;
				}      
			}
		}
		return false;
	},
	
	//PAS20181U210300095
	validateDocument: function(){
		var td = dijit.byId("pantallaInicial.tipoId").getValue();
		var ndControl = dijit.byId("pantallaInicial.nroId");
		var ndLength = dojo.trim(ndControl.getValue()).length;
		
		if (td == "-" && ndLength == 0){
			return;
		}else{
			if (td == "1"){ //DNI
				if (ndLength != 8){
					mostrarMensaje("N\u00FAmero de documento de identidad inconsistente.");
					ndControl.attr('value', "");
					ndControl.focus();
					return;
				}
			}else{		
				if (td == "6") { //RUC
					this.self = this;
					if(!this.isValidRuc(dojo.trim(ndControl.getValue()))) {
						mostrarMensaje("Numero de RUC incorrecto.");
						ndControl.attr('value', "");
						ndControl.focus();
						return;
					}			
				}else{ //0, 4, 7 o A
					if (ndLength == 0){
						mostrarMensaje("N\u00FAmero de documento de identidad y/o nombre del cliente inconsistente.");
						ndControl.attr('value', "");
						ndControl.focus();
						return;
					}
					return;
				}
			}
		}
		
		this.wait("Consultando", "110px", 200);
		var handler = dojo.xhrGet({
			preventCache:  false,
			url: this.controller + "?action=validarAdquiriente&tipoDocumento=" + "0" + td + "&numeroDocumento=" + dojo.trim(ndControl.getValue()),
			handleAs: "json",
			sync: true,
			timeout: 10000
		});
		handler.addCallback(dojo.hitch(this, function(response){
			this.waitMessage.hide();
			if(response.codeError == 0) {
				rzControl.attr('value', response.data);
			} else {
				ndControl.attr('value', "");
				ndControl.focus();
				mostrarMensaje(response.messageError);
			}
		}));
		handler.addErrback(function(response){
			this.waitMessage.hide();
			mostrarMensaje("Ocurrio un error al validar el adquiriente");
		});
	},
	
	//PAS20181U210300095
	validateTypePenalidad: function (){
		var td = dijit.byId("pantallaInicial.tipoId").getValue();
		
		ndControl = dijit.byId("pantallaInicial.nroId");
		rzControl = dijit.byId("pantallaInicial.razonSocial");
		
		if (td == ""){
			ndControl.attr('disabled',true);
			rzControl.attr('disabled',true);
		} else {
			if (td == "-"){
				ndControl.attr('disabled',true);
				//rzControl.attr('disabled',true);
				ndControl.attr('regExp','[^|\~���"]+');
				ndControl.attr('maxLength','100');
				rzControl.attr('disabled',false);
				rzControl.focus();
			}else{			
				if (td == "1"){ //DNI
					ndControl.attr('disabled',false);
					ndControl.attr('regExp','[0-9]+');
					ndControl.attr('maxLength','8');
					rzControl.attr('disabled',true);
					ndControl.focus();
				}else{
					if (td == "6"){ //RUC
						ndControl.attr('disabled',false);
						ndControl.attr('regExp','[0-9]+');
						ndControl.attr('maxLength','11');
						rzControl.attr('disabled',true);
						ndControl.focus();
					}else{ //0, 4, 7 o A
						ndControl.attr('disabled',false);
						ndControl.attr('regExp','[A-Za-z0-9]+[-]{0,1}[A-Za-z0-9]+');
						ndControl.attr('maxLength','15');
						rzControl.attr('disabled',false);
						ndControl.focus();
					}
				}
			}
		}
	},
	
	//PAS20181U210300095
	estaVacioDocumentosReceptorPenalidad: function(){
		response = true;
		if ((dijit.byId("pantallaInicial.tipoId").getValue() != "") ||
		    (dijit.byId("pantallaInicial.nroId").getValue() != "") ||
			(dijit.byId("pantallaInicial.razonSocial").getValue() != "")){
			response = false;
		}
		return response;
	},
          
 	verPreliminar: function() {
 		if(!dijit.byId("criterio.form").validate()) return;
 		valor = dijit.byId("pantallaInicial.tipoNotaDebito").value;
 		if (valor == ""){
 			mostrarMensaje("Debe seleccionar el tipo de Nota de D\xE9bito a emitir.");
 			return;
 		}
 		if ((valor != "43") && (dijit.byId("pantallaInicial.numeroFE").value == "")){
 		//if ((dijit.byId("pantallaInicial.numeroFE").value == "")){
 			mostrarMensaje("Debe ingresar el n\xFAmero de Factura Electr\xf3nica respecto a la cual se emitir\xE1 la Nota de D\xE9bito.");
 			return;
 		}
            
 		valor = dijit.byId("pantallaInicial.tipoNotaDebito").getValue();
 		if (valor == "41") {
 			if (dijit.byId("pantallaInicial.motivoEmisionND").getValue() == ""){
 				mostrarMensaje("Debe ingresar el motivo o sustento por el cu\u00E1l se emitir\xE1 la Nota de D\xE9bito.");
 				return;
 			} 
 			if (dojo.byId("pantallaInicial.interesMoraND").value == "" ){
				dijit.byId("pantallaInicial.interesMoraND").focus();
 				mostrarMensaje("Debe consignarse Inter\xE9s por Mora.");
 				return;
 			} 
 			if (dijit.byId("pantallaInicial.interesMoraND").getValue() == 0){
 				mostrarMensaje("Inter\xE9s Moratorio debe ser mayor que cero.");
				dijit.byId("pantallaInicial.interesMoraND").focus();
 				return;
 			}                 
 		}
 		
 		if (valor == "42") {
 			if (dijit.byId("pantallaInicial.motivoEmisionND").value == ""){
 				mostrarMensaje("Debe ingresar el motivo o sustento por el cu\u00E1l se emitir\xE1 la Nota de D\xE9bito.");
				dijit.byId("pantallaInicial.motivoEmisionND").focus();
 				return;
 			} 
 		}
		
		//PAS20181U210300095
		if (valor == "43"){
			if (dijit.byId("pantallaInicial.numeroFE").value == ""){
				if (this.estaVacioDocumentosReceptorPenalidad()){
					mostrarMensaje("En caso de no ingresar factura de referencia, debe ingresar el tipo de documento y n\u00FAmero de documento del receptor.");
					return;
				}
			}
			
			if (dijit.byId("pantallaInicial.motivoEmisionND").getValue() == ""){
 				mostrarMensaje("Debe ingresar el motivo o sustento por el cu\u00E1l se emitir\xE1 la Nota de D\xE9bito.");
				dijit.byId("pantallaInicial.motivoEmisionND").focus();
 				return;
 			} 
 			if (dojo.byId("pantallaInicial.interesMoraND").value == "" ){
 				mostrarMensaje("Debe consignarse Inter\xE9s por Mora.");
				dijit.byId("pantallaInicial.interesMoraND").focus();
 				return;
 			} 
 			if (dijit.byId("pantallaInicial.interesMoraND").getValue() == 0){
 				mostrarMensaje("Inter\xE9s Moratorio debe ser mayor que cero.");
				dijit.byId("pantallaInicial.interesMoraND").focus();
 				return;
 			}
		}
 		
 		var tipoNotaDebito = dijit.byId("pantallaInicial.tipoNotaDebito").value;
 		var serieFE = dijit.byId("pantallaInicial.serieFE").value;
 		var numeroFE = dijit.byId("pantallaInicial.numeroFE").value;
 		var motivoEmisionND = dijit.byId("pantallaInicial.motivoEmisionND").value;
 		var interesMoraND = dijit.byId("pantallaInicial.interesMoraND").value;
		//PAS20181U210300095
		var tipoPenalidad = dijit.byId("pantallaInicial.tipoId").value;
		var idPenalidad = dijit.byId("pantallaInicial.nroId").value;
		var razonSocialPenalidad = dijit.byId("pantallaInicial.razonSocial").value;

 		var handler = dojo.xhrGet({
 			url: this.controller + "?action=validarComprobante&TipoNotaDebito=" + tipoNotaDebito
			                     + "&serie=" + serieFE
								 + "&factura=" + numeroFE
								 + "&tipoDoc=" + tipoPenalidad
								 + "&nroDoc=" + idPenalidad
								 + "&razonSocial=" + razonSocialPenalidad,
 			handleAs: "json",
 			sync: true,
 			preventCache: true,
 			timeout: 10000
        });        
        
 		handler.addCallback(dojo.hitch(this, function(res){
        	if (res.codeError == 0 || res.codeError == 9) {
        		if(res.codeError == 9){ 
        			//if (!confirm(res.messageError + " \u00BFDesea continuar?. Puede revisar las notas emitidas en la opci\u00F3n de consultas.")){
        			//	return;
        			//}
					mostrarMensajeConfirmacion(res.messageError + " \u00BFDesea continuar?. Puede revisar las notas emitidas en la opci\u00F3n de consultas.", 
						dojo.hitch(this, function(){
					})
					);
        		}
        		if (valor == "41" || valor == "43") {
        			this.content.setHref(this.controller + "?action=preliminarComprobante&TipoNotaDebito=" + tipoNotaDebito
                        					             + "&serie=" + serieFE 
														 + "&factura=" + numeroFE 
														 + "&motivo=" + motivoEmisionND 
														 + "&interes=" + interesMoraND);
        		}
        		if (valor == "42") {
        			this.content.setHref(this.controller + "?action=cambiarDetallesND&TipoNotaDebito=" + tipoNotaDebito 
					                                     + "&serie=" + serieFE 
														 + "&factura=" + numeroFE 
														 + "&motivo=" + motivoEmisionND 
														 + "&interes=" + interesMoraND);
        		}
        	} else {                                 
        		mostrarMensaje(res.messageError);
        		return;
        	}
        }));
    	
        handler.addErrback(function(res){
    		this.waitMessage.hide();
    		mostrarMensaje("Problemas al conectarse con el servidor");
    	});    			 
 	},    
	
	
	verPreliminarContin: function() {
		var numero = document.getElementById("numero").value;
		if(numero==""){
			mostrarMensaje("Ingrese el n\xFAmero de serie");
			document.getElementById("numero").focus();
			return;
		}
		
 		if(!dijit.byId("criterio.form").validate()) return;
 		valor = dijit.byId("pantallaInicial.tipoNotaDebito").value;
 		if (valor == ""){
 			mostrarMensaje("Debe seleccionar el tipo de Nota de D\xE9bito a emitir.");
 			return;
 		}
 		if ((valor != "43") && (dijit.byId("pantallaInicial.numeroFE").value == "")){
 		//if ((dijit.byId("pantallaInicial.numeroFE").value == "")){
 			mostrarMensaje("Debe ingresar el n\xFAmero de Factura por Contingencia respecto a la cual se emitir\xE1 la Nota de D\xE9bito.");
 			return;
 		}
            
 		valor = dijit.byId("pantallaInicial.tipoNotaDebito").getValue();
 		if (valor == "41") {
 			if (dijit.byId("pantallaInicial.motivoEmisionND").getValue() == ""){
 				mostrarMensaje("Debe ingresar el motivo o sustento por el cu\u00E1l se emitir\xE1 la Nota de D\xE9bito.");
 				return;
 			} 
 			if (dojo.byId("pantallaInicial.interesMoraND").value == "" ){
				dijit.byId("pantallaInicial.interesMoraND").focus();
 				mostrarMensaje("Debe consignarse Inter\xE9s por Mora.");
 				return;
 			} 
 			if (dijit.byId("pantallaInicial.interesMoraND").getValue() == 0){
 				mostrarMensaje("Inter\xE9s Moratorio debe ser mayor que cero.");
				dijit.byId("pantallaInicial.interesMoraND").focus();
 				return;
 			}                 
 		}
 		
 		if (valor == "42") {
 			if (dijit.byId("pantallaInicial.motivoEmisionND").value == ""){
 				mostrarMensaje("Debe ingresar el motivo o sustento por el cu\u00E1l se emitir\xE1 la Nota de D\xE9bito.");
				dijit.byId("pantallaInicial.motivoEmisionND").focus();
 				return;
 			} 
 		}
		
		//PAS20181U210300095
		if (valor == "43"){
			if (dijit.byId("pantallaInicial.numeroFE").value == ""){
				if (this.estaVacioDocumentosReceptorPenalidad()){
					mostrarMensaje("En caso de no ingresar factura de referencia, debe ingresar el tipo de documento y n\u00FAmero de documento del receptor.");
					return;
				}
			}
			
			if (dijit.byId("pantallaInicial.motivoEmisionND").getValue() == ""){
 				mostrarMensaje("Debe ingresar el motivo o sustento por el cu\u00E1l se emitir\xE1 la Nota de D\xE9bito.");
				dijit.byId("pantallaInicial.motivoEmisionND").focus();
 				return;
 			} 
 			if (dojo.byId("pantallaInicial.interesMoraND").value == "" ){
 				mostrarMensaje("Debe consignarse Inter\xE9s por Mora.");
				dijit.byId("pantallaInicial.interesMoraND").focus();
 				return;
 			} 
 			if (dijit.byId("pantallaInicial.interesMoraND").getValue() == 0){
 				mostrarMensaje("Inter\xE9s Moratorio debe ser mayor que cero.");
				dijit.byId("pantallaInicial.interesMoraND").focus();
 				return;
 			}
		}
 		
		var serie = document.getElementById("serie").value;
		var numero = document.getElementById("numero").value;
		
 		var tipoNotaDebito = dijit.byId("pantallaInicial.tipoNotaDebito").value;
 		//var serieFE = dijit.byId("pantallaInicial.serieFE").value;
		var serieFE = document.getElementById("idSerie").value;
 		var numeroFE = dijit.byId("pantallaInicial.numeroFE").value;
 		var motivoEmisionND = dijit.byId("pantallaInicial.motivoEmisionND").value;
 		var interesMoraND = dijit.byId("pantallaInicial.interesMoraND").value;
		//PAS20181U210300095
		var tipoPenalidad = dijit.byId("pantallaInicial.tipoId").value;
		var idPenalidad = dijit.byId("pantallaInicial.nroId").value;
		var razonSocialPenalidad = dijit.byId("pantallaInicial.razonSocial").value;

 		var handler = dojo.xhrGet({
 			url: this.controller + "?action=validarComprobanteContin&TipoNotaDebito=" + tipoNotaDebito
			                     + "&idSerie=" + serieFE
								 + "&factura=" + numeroFE
								 + "&tipoDoc=" + tipoPenalidad
								 + "&nroDoc=" + idPenalidad
								 + "&razonSocial=" + razonSocialPenalidad,
 			handleAs: "json",
 			sync: true,
 			preventCache: true,
 			timeout: 10000
        });        
        
 		handler.addCallback(dojo.hitch(this, function(res){
        	if (res.codeError == 0 || res.codeError == 9) {
        		if(res.codeError == 9){ 
        			//if (!confirm(res.messageError + " \u00BFDesea continuar?. Puede revisar las notas emitidas en la opci\u00F3n de consultas.")){
        			//	return;
        			//}
					mostrarMensajeConfirmacion(res.messageError + " \u00BFDesea continuar?. Puede revisar las notas emitidas en la opci\u00F3n de consultas.", 
						dojo.hitch(this, function(){
					})
					);
        		}
        		if (valor == "41" || valor == "43") {
        			this.content.setHref(this.controller + "?action=preliminarComprobanteContin&TipoNotaDebito=" + tipoNotaDebito
                        					             + "&idSerie=" + serieFE 
														 + "&factura=" + numeroFE 
														 + "&serie=" + serie 
														 + "&numero=" + numero 
														 + "&motivo=" + motivoEmisionND 
														 + "&interes=" + interesMoraND);
        		}
        		if (valor == "42") {
        			this.content.setHref(this.controller + "?action=cambiarDetallesNDContin&TipoNotaDebito=" + tipoNotaDebito 
					                                     + "&idSerie=" + serieFE 
														 + "&factura=" + numeroFE 
														 + "&serie=" + serie 
														 + "&numero=" + numero 
														 + "&motivo=" + motivoEmisionND 
														 + "&interes=" + interesMoraND);
        		}
        	} else {                                 
        		mostrarMensaje(res.messageError);
        		return;
        	}
        }));
    	
        handler.addErrback(function(res){
    		this.waitMessage.hide();
    		mostrarMensaje("Problemas al conectarse con el servidor");
    	});    			 
 	},    
	
  
  	saveDocument: function() {
		//if (!confirm("Desea emitir la Nota de D\xE9bito electronica?")){
		//	return;
		//}
	  var accionBtnAceptarQ2 = dojo.hitch(this, function () {
		var nbBack = dijit.byId("notaDebito-preliminar.botonBackDocumento");
		var nbSave = dijit.byId("notaDebito-preliminar.botonGrabarDocumento");
		var nbClose = dijit.byId("notaDebito-preliminar.botonCloseDocumento");
		
		nbBack.setAttribute('disabled', true);
		nbSave.setAttribute('disabled', true);
		nbClose.setAttribute('disabled', true);
		
		this.wait("Grabando", "95px", 800);
		
        var handler = dojo.xhrGet({
            url: this.controller + "?action=grabarComprobante",
            handleAs: "json",
            preventCache: true,
            sync: true,
            timeout: 10000
        });

				
        handler.addCallback(dojo.hitch(this, function(res){
            this.waitMessage.hide();
        if (res.codeError == 0) {
				    this.content.onLoad = dojo.hitch(this, function(){
				    this.iconTooltipMessage("numeroComprobante", "icon-ok-tooltip", "La nota de debito se emitio correctamente <br>Ha generado este n&uacute;mero.");
				    });            	
				    this.content.setHref(this.controller + "?action=mostrarComprobante&preventCache=" + this.preventCache());
        } else {
    				nbBack.setAttribute('disabled', false);
    				nbSave.setAttribute('disabled', false);
    				nbClose.setAttribute('disabled', false);
				
                mostrarMensaje(res.messageError);
            }
        }));
        handler.addErrback(dojo.hitch(this, function(res){
  			nbBack.setAttribute('disabled', false);
  			nbSave.setAttribute('disabled', false);
  			nbClose.setAttribute('disabled', false);
  			
            this.waitMessage.hide();
            mostrarMensaje("Problemas al emitir la Nota de D\xE9bito Electr\xf3nica.");
        }));
		
	  });
		
		mostrarMensajeConfirmacion("\u00BFDesea emitir la Nota de D\xE9bito electr\xf3nica?", accionBtnAceptarQ2 );
	},      
  
  
  saveDocumentContin: function() {
		//if (!confirm("Desea registrar la Nota de D\xE9bito por Contingencia?")){
		//	return;
		//}
		
	  var accionBtnAceptarQ2_ = dojo.hitch(this, function () {
		var nbBack = dijit.byId("notaDebito-preliminar.botonBackDocumento");
		var nbSave = dijit.byId("notaDebito-preliminar.botonGrabarDocumento");
		var nbClose = dijit.byId("notaDebito-preliminar.botonCloseDocumento");
		
		nbBack.setAttribute('disabled', true);
		nbSave.setAttribute('disabled', true);
		nbClose.setAttribute('disabled', true);
		
		this.wait("Grabando", "95px", 800);
		
        var handler = dojo.xhrGet({
            url: this.controller + "?action=grabarComprobanteContin",
            handleAs: "json",
            preventCache: true,
            sync: true,
            timeout: 10000
        });

				
        handler.addCallback(dojo.hitch(this, function(res){
            this.waitMessage.hide();
        if (res.codeError == 0) {
				    this.content.onLoad = dojo.hitch(this, function(){
				    this.iconTooltipMessage("numeroComprobante", "icon-ok-tooltip", "El registro de la presente informacion constituye una declaracion jurada, acorde con la RS 113-2018/SUNAT. <br>Ha generado este n&uacute;mero.");
				    });            	
				    this.content.setHref(this.controller + "?action=mostrarComprobante&preventCache=" + this.preventCache());
        } else {
    				nbBack.setAttribute('disabled', false);
    				nbSave.setAttribute('disabled', false);
    				nbClose.setAttribute('disabled', false);
				
                mostrarMensaje(res.messageError);
            }
        }));
        handler.addErrback(dojo.hitch(this, function(res){
  			nbBack.setAttribute('disabled', false);
  			nbSave.setAttribute('disabled', false);
  			nbClose.setAttribute('disabled', false);
  			
            this.waitMessage.hide();
            mostrarMensaje("Problemas al emitir la Nota de D\xE9bito Electr\xf3nica.");
        }));
	  });		
		mostrarMensajeConfirmacion("\u00BFDesea registrar la Nota de D\xE9bito por Contingencia?", accionBtnAceptarQ2_ );
		
	},     
	
	
	afterLoad:function(){
		if (this.facturaBean==null) return;
		//dijit.byId("pantallaInicial.interesMoraND").attr('value',dojo.trim(dijit.byId("pantallaInicial.interesMoraND").getValue()));
		//dijit.byId("pantallaInicial.interesMoraND").value = dojo.trim(dijit.byId("pantallaInicial.interesMoraND").getValue());
		this.formateaMontos();
		this.updateAmount();
	},
	
	//Antonio
	validateEstablecimiento: function(){
		var establecimiento = document.getElementById("establecimiento").value;
		var regexEstablecimiento=false;
		var digitoEstablecimiento="";
		var regex2 = /[0-9]|\./;
		for (i=0; i< establecimiento.length;i++){
		digitoEstablecimiento= establecimiento.charAt(i);
			if(!regex2.test(digitoEstablecimiento)) {//la serie debe ser numerica incluyendo 0
			regexEstablecimiento=true;
			}
      	 }
					if(establecimiento!==""){//el establecimiento debe ser diferente de vacio
						if(establecimiento.length<5){//el establecimiento debe ser de 4 digitos como maximo
							if(!regexEstablecimiento) {//el establecimiento debe ser de tipo numerico incluyendo 0

							}else{mostrarMensaje("El establecimeinto debe ser numerico"); 
							document.getElementById("establecimiento").value="";
							document.getElementById("establecimiento").focus();
							}
						}else{mostrarMensaje("El establecimiento debe ser menor a 5 digitos"); 
						document.getElementById("establecimiento").value="";
						document.getElementById("establecimiento").focus();
						}
					}

	},	
	
	//Antonio
	validateSerie: function(){
		var serie1 = document.getElementById("serie").value;
		var numero1 = document.getElementById("numero").value;
		var regexSerie1=false;
		var regexNumero1=false;
		var digitoSerie1="";
		var digitoNumero1="";
		var regex1 = /[0-9]|\./;
		for (i=0; i< serie1.length;i++){
		digitoSerie1= serie1.charAt(i);
			if(!regex1.test(digitoSerie1)) {//la serie debe ser numerica incluyendo 0
			regexSerie1=true;
			}
      	 }
		
		for (i=0; i< numero1.length;i++){
		digitoNumero1= numero1.charAt(i);
			if(!regex1.test(digitoNumero1)) {//el numero debe ser de tipo numerico incluyendo 0
			regexNumero1=true;
			}
      	 }

					if(serie1!==""){//la serie debe ser diferente de vacio
						if(serie1.length==4){//el numero debe ser de 9 digitos como maximo
							if(!regexSerie1) {//el numero debe ser de tipo numerico incluyendo 0
							document.getElementById("numero").value="";
							document.getElementById("numero").focus();
							}else{mostrarMensaje("La serie debe ser numerica"); 
							document.getElementById("serie").value="";
							document.getElementById("numero").value="";
							document.getElementById("serie").focus();}
						}else{mostrarMensaje("la serie debe tener 4 caracteres"); 
						document.getElementById("serie").value="";
						document.getElementById("numero").value="";
						document.getElementById("serie").focus();}
					}

	},	
	
	//Antonio
	validateSerieId: function(){
		var serie2 = document.getElementById("idSerie").value;
		var regexSerie2=false;
		var digitoSerie2="";
		//var regex2 = /[0-9]|\./;
		var regex2 = /(?=.*\b[eE]001\b)[eE]001|(?=.*\b[fF][A-Za-z0-9]{3}\b)[fF][A-Za-z0-9]{3}|(?=.*\b[0-9]{4}\b)[0-9]{3}/;
		/*for (i=0; i< serie2.length;i++){
		digitoSerie2= serie2.charAt(i);
			if(!regex2.test(digitoSerie2)) {//la serie debe ser numerica incluyendo 0
			regexSerie2=true;
			}
      	 }*/

      	 if(!regex2.test(serie2)) {
			regexSerie2=true;
      	 }
		
					if(serie2!==""){//la serie debe ser diferente de vacio
						if(serie2.length==4){//el numero debe ser de 9 digitos como maximo
							if(!regexSerie2) {//el numero debe ser de tipo numerico incluyendo 0
							}else{//alert("La serie debe ser numerica"); 
							mostrarMensaje("La serie debe ser numerica o con el siguiente formato E001 o FXXX");
							document.getElementById("idSerie").value="";
							document.getElementById("idSerie").focus();}
						}else{mostrarMensaje("la serie debe tener 4 caracteres"); 
						document.getElementById("idSerie").value="";
						document.getElementById("idSerie").focus();}
					}

	},	
	
	//Antonio
	validateNumero: function(){		
		var serie = document.getElementById("serie").value;
		var numero = document.getElementById("numero").value;
		var establecimiento = document.getElementById("establecimiento").value;
		var fechaEmision = document.getElementById("fechaEmision").value;

		if(fechaEmision!==""){
			
		if(establecimiento!==""){
			
		var regexSerie=false;
		var regexNumero=false;
		var digitoSerie="";
		var digitoNumero="";
		var regex = /[0-9]|\./;
		for (i=0; i< serie.length;i++){
		digitoSerie= serie.charAt(i);
			if(!regex.test(digitoSerie)) {//la serie debe ser numerica incluyendo 0
			regexSerie=true;
			}
      	 }
		for (i=0; i< numero.length;i++){
		digitoNumero= numero.charAt(i);
			if(!regex.test(digitoNumero)) {//el numero debe ser de tipo numerico incluyendo 0
			regexNumero=true;
			}
      	 }
		 if(numero!==""){//la serie debe ser diferente de vacio
			if(numero.length<=9){//el numero debe ser de 9 digitos como maximo
				if(!regexNumero) {//el numero debe ser de tipo numerico incluyendo 0
					if(serie!==""){//la serie debe ser diferente de vacio
						if(serie.length<=4){//el numero debe ser de 9 digitos como maximo
							if(!regexSerie) {//el numero debe ser de tipo numerico incluyendo 0
								var handler = dojo.xhrGet({
									preventCache:  false,
									url: this.controller + "?action=validadComprobante&serie=" + serie + "&numero=" + numero+"&establecimiento="+establecimiento+"&fechaEmision="+fechaEmision,
									handleAs: "json",
									sync: true,
									timeout: 10000
								});
								handler.addCallback(dojo.hitch(this, function(response){
									this.waitMessage.hide();
										if(response.codeError==1){
											
										}else if(response.codeError==7){
											//PAS20221U210700028 - Ajuste de foco
											document.getElementById("pantallaInicial.numeroFE").focus();
                                            document.getElementById('pantallaInicial.numeroFE').addEventListener('focus',document.getElementById("idSerie").focus(),false);
											//Fin ajuste de foco - PAS20221U210700028
											mostrarMensaje(""+response.data);
										}else {
										mostrarMensaje(response.data);
										document.getElementById("numero").value="";
										document.getElementById("numero").focus();
										}
								}));
								handler.addErrback(function(response){
									this.waitMessage.hide();
									mostrarMensaje("Ocurrio un error al validar datos del comprobante");
								});
							}else{mostrarMensaje("La serie debe ser numerica"); 
							document.getElementById("serie").value="";
							document.getElementById("numero").value="";
							document.getElementById("serie").focus();}
						}else{mostrarMensaje("la serie debe tener 4 caracteres"); 
						document.getElementById("serie").value="";
						document.getElementById("numero").value="";
						document.getElementById("serie").focus();}
					}else{mostrarMensaje("ingrese la serie"); 
					document.getElementById("serie").value="";
					 document.getElementById("numero").value="";
					 document.getElementById("serie").focus();}
				}else{ mostrarMensaje("El n\xFAmero debe ser de tipo numerico"); 
				document.getElementById("numero").value="";
				document.getElementById("numero").focus();}
			}else{	mostrarMensaje("El n\xFAmero maximo de caracteres es de 9 digitos");
			document.getElementById("numero").value="";
			document.getElementById("numero").focus();}
		 }
		}else{
			mostrarMensaje("Seleccione el establecimiento");
			document.getElementById("numero").value="";
		}
		
		}else{
			mostrarMensaje("Seleccione la fecha de emisi\xf3n");
			document.getElementById("numero").value="";
		}
		
	},	
	
        

	validarFacturaContin: function(){
		var factura= dijit.byId("pantallaInicial.numeroFE").value;
		var serieFE = document.getElementById("idSerie").value;
		
		if(serieFE!=""){
		factura = factura.replace(/^0+/, '');
		dijit.byId("pantallaInicial.numeroFE").attr('value',factura);
		
		dijit.hideTooltip(dojo.byId("pantallaInicial.numeroFE"));
		this.facturaBean = null;
		if ( factura!= ""){
			this.limpiaMontos();
      		this.wait("Consultando", "110px", 200);
      		
      		var tipoNotaDebito = dijit.byId("pantallaInicial.tipoNotaDebito").value;
      		//var serieFE = dijit.byId("pantallaInicial.serieFE").value;
			//PAS20181U210300095
			var tipoPenalidad = dijit.byId("pantallaInicial.tipoId").value;
			var idPenalidad = dijit.byId("pantallaInicial.nroId").value;
			var razonSocialPenalidad = dijit.byId("pantallaInicial.razonSocial").value;
      		
			var handler = dojo.xhrGet({
				url: this.controller + "?action=validarComprobanteContin&TipoNotaDebito=" + tipoNotaDebito 
				                     + "&idSerie=" + serieFE 
									 + "&factura=" + factura									 
								     + "&tipoDoc=" + tipoPenalidad
								     + "&nroDoc=" + idPenalidad
								     + "&razonSocial=" + razonSocialPenalidad,
    			handleAs: "json",
    			preventCache:  true,
    			sync: true,
    			timeout: 10000
    		});
			
    		handler.addCallback(dojo.hitch(this, function(res){
    		  	dijit.hideTooltip(dojo.byId("pantallaInicial.numeroFE"));
    			this.waitMessage.hide();
				if(res.codeError == 0 || res.codeError == 9) {
					this.facturaBean = eval("(" + res.data + ")");
					this.igvFE = this.facturaBean.igvPorcentaje;
					//PAS20175E210300011; corregido con el pase PAS20175E210300026
					if (this.igvFE < 1){
						this.igvFE = this.igvFE * 100;
					}
					
					//PAS20181U210300095
					if (tipoNotaDebito == "43"){
						dijit.byId("pantallaInicial.tipoId").setValue(this.facturaBean.tipoDocumentoCliente);
						dijit.byId("pantallaInicial.nroId").setValue(this.facturaBean.numeroDocumentoCliente);
						dijit.byId("pantallaInicial.razonSocial").setValue(this.facturaBean.nombreCliente);
					}

					this.formateaMontos();									
    			} else {
					this.iconTooltipMessage("pantallaInicial.numeroFE", "icon-ok-tooltip", res.messageError);
    			    dijit.byId("pantallaInicial.numeroFE").focus();
					return;
    			}
    		}));
			
    		handler.addErrback(function(res){
    			this.waitMessage.hide();
    			mostrarMensaje("Ocurrio un error al validar la factura ingresada");
    		});
    			
    		if (this.facturaBean1=null){
				var subTipo = this.facturaBean.subTipoComprobante;
				if (subTipo == "01"){
					this.limpiaMontos();
					this.iconTooltipMessage("pantallaInicial.numeroFE", "icon-ok-tooltip", "No corresponde una Nota de Debito de Intereses por Mora o aumento del Valor para una FE de Venta Gratuita.");
                
					return;   
				}
			 }
		  }
		}else{
			mostrarMensaje("Ingrese el n\xFAmero de serie");
			document.getElementById("idSerie").value="";
			document.getElementById("idSerie").focus();
		}
		
	},
	
	
	validarFactura: function(){
		var factura= dijit.byId("pantallaInicial.numeroFE").value;
		factura = factura.replace(/^0+/, '');
		dijit.byId("pantallaInicial.numeroFE").attr('value',factura);
		
		dijit.hideTooltip(dojo.byId("pantallaInicial.numeroFE"));
		this.facturaBean = null;
		if ( factura!= ""){
			this.limpiaMontos();
      		this.wait("Consultando", "110px", 200);
      		
      		var tipoNotaDebito = dijit.byId("pantallaInicial.tipoNotaDebito").value;
      		var serieFE = dijit.byId("pantallaInicial.serieFE").value;
			//PAS20181U210300095
			var tipoPenalidad = dijit.byId("pantallaInicial.tipoId").value;
			var idPenalidad = dijit.byId("pantallaInicial.nroId").value;
			var razonSocialPenalidad = dijit.byId("pantallaInicial.razonSocial").value;
      		
			var handler = dojo.xhrGet({
				url: this.controller + "?action=validarComprobante&TipoNotaDebito=" + tipoNotaDebito 
				                     + "&serie=" + serieFE 
									 + "&factura=" + factura									 
								     + "&tipoDoc=" + tipoPenalidad
								     + "&nroDoc=" + idPenalidad
								     + "&razonSocial=" + razonSocialPenalidad,
    			handleAs: "json",
    			preventCache:  true,
    			sync: true,
    			timeout: 10000
    		});
			
    		handler.addCallback(dojo.hitch(this, function(res){
    		  	dijit.hideTooltip(dojo.byId("pantallaInicial.numeroFE"));
    			this.waitMessage.hide();
				if(res.codeError == 0 || res.codeError == 9) {
					this.facturaBean = eval("(" + res.data + ")");
					this.igvFE = this.facturaBean.igvPorcentaje;
					//PAS20175E210300011; corregido con el pase PAS20175E210300026
					if (this.igvFE < 1){
						this.igvFE = this.igvFE * 100;
					}
					
					//PAS20181U210300095
					if (tipoNotaDebito == "43"){
						dijit.byId("pantallaInicial.tipoId").setValue(this.facturaBean.tipoDocumentoCliente);
						dijit.byId("pantallaInicial.nroId").setValue(this.facturaBean.numeroDocumentoCliente);
						dijit.byId("pantallaInicial.razonSocial").setValue(this.facturaBean.nombreCliente);
					}

					this.formateaMontos();									
    			} else {
					this.iconTooltipMessage("pantallaInicial.numeroFE", "icon-ok-tooltip", res.messageError);
    			    dijit.byId("pantallaInicial.numeroFE").focus();
					return;
    			}
    		}));
			
    		handler.addErrback(function(res){
    			this.waitMessage.hide();
    			mostrarMensaje("Ocurrio un error al validar la factura ingresada");
    		});
    			
    		if (this.facturaBean1=null){
				var subTipo = this.facturaBean.subTipoComprobante;
				if (subTipo == "01"){
					this.limpiaMontos();
					this.iconTooltipMessage("pantallaInicial.numeroFE", "icon-ok-tooltip", "No corresponde una Nota de D\xE9bito de Intereses por Mora o aumento del Valor para una FE de Venta Gratuita.");
                
					return;   
				}
			}
		}
	},
	

	iconTooltipMessage: function(node, iconClass, message) {
		if(dojo.isString(node)) node = dojo.byId(node);
		dijit.focus(node);
		node.focus();
		dijit.showTooltip('<div class="' + iconClass + '"><div>' + message + '</div></div>', node, []);
		var blur = dojo.connect(node, "onBlur", function() {
			dijit.hideTooltip(node);
			dojo.disconnect(blur);
		});
	},
	  
	sendDocument: function() {
		if(!dijit.byId("generada.form").validate()){
			mostrarMensaje("Debe registrar una direcci\xf3n de correo v\u00E1lida.");
			return;
		} 
  		if (dojo.trim(dijit.byId("generada.correoUser").getValue()) == "" ) {
  			mostrarMensaje("Por favor ingrese una direcci\xf3n de correo.");
  			return;
  		}
  		
  		this.wait("Enviando", "110px", 100);
  		var handler = dojo.xhrGet({
  			preventCache:  false,
  			url: this.controller + "?action=enviarCorreo&correoUser=" + dojo.trim(dijit.byId("generada.correoUser").getValue()),
  			handleAs: "json",
  			sync: true,
  			timeout: 10000
  		});
  		handler.addCallback(dojo.hitch(this, function(response){
  			this.waitMessage.hide();
  			if(response.codeError == 0) {
  				mostrarMensaje("Se envio correo a la siguiente direcci\xf3n: " + dijit.byId("generada.correoUser").getValue());
  				dijit.byId("generada.correoUser").focus();
  			}
  			else {
  				this.messageBox(res.messageError);
  			}
  		}));
  		handler.addErrback(function(response){
  			this.waitMessage.hide();
  			this.messageBox("Problemas al conectarse con el servidor");
  		});
	},
	 
	 sendDocumentContin: function() {
		if(!dijit.byId("generada.form").validate()){
			mostrarMensaje("Debe registrar una direcci\xf3n de correo v\u00E1lida.");
			return;
		} 
  		if (dojo.trim(dijit.byId("generada.correoUser").getValue()) == "" ) {
  			mostrarMensaje("Por favor ingrese una direcci\xf3n de correo.");
  			return;
  		}
  		
  		this.wait("Enviando", "110px", 100);
  		var handler = dojo.xhrGet({
  			preventCache:  false,
  			url: this.controller + "?action=enviarCorreoContin&correoUser=" + dojo.trim(dijit.byId("generada.correoUser").getValue()),
  			handleAs: "json",
  			sync: true,
  			timeout: 10000
  		});
  		handler.addCallback(dojo.hitch(this, function(response){
  			this.waitMessage.hide();
  			if(response.codeError == 0) {
  				mostrarMensaje("Se envio correo a la siguiente direcci\xf3n: " + dijit.byId("generada.correoUser").getValue());
  				dijit.byId("generada.correoUser").focus();
  			}
  			else {
  				this.messageBox(res.messageError);
  			}
  		}));
  		handler.addErrback(function(response){
  			this.waitMessage.hide();
  			this.messageBox("Problemas al conectarse con el servidor");
  		});
	},
	
	onFocus: function(id){
		var dato = dojo.byId(id).value;
		dijit.byId(id).attr('value',"");	
		dijit.byId(id).attr('value',dojo.trim(dato));	
	},
	
    updateAmount: function() {
    	//PAS20175E210300040 FacturaNotaDebito Penalidad
    	if (this.facturaBean == null){
    		if (dijit.byId("pantallaInicial.interesMoraND").value != "" &&
    			dijit.byId("pantallaInicial.numeroFE").value == "" &&
    			dijit.byId("pantallaInicial.tipoNotaDebito").value == "43") {
    			var monto = dijit.byId("pantallaInicial.interesMoraND").value;
    			this.limpiaMontos();
          		this.wait("Consultando", "110px", 200);
          		
    			var handler = dojo.xhrGet({
    				url: this.controller + "?action=recuperarSinReferenciaPenalidad",
        			handleAs: "json",
        			preventCache:  true,
        			sync: true,
        			timeout: 10000
        		});
        		handler.addCallback(dojo.hitch(this, function(res){
        		  	this.waitMessage.hide();
    				if(res.codeError == 0) {
    					this.facturaBean = eval("(" + res.data + ")");
    					this.formateaMontos();
    					
    					dijit.byId("pantallaInicial.interesMoraND").attr('value', monto);
        			}
        		}));
        		handler.addErrback(function(res){
        			this.waitMessage.hide();
        			mostrarMensaje("Ocurrio un error al validar la factura ingresada");
        			return;
        		});
    			
        	} else {
        		return;
        	}
    	} else {    	
	    	/*Inicio SAU20156R120400552*/
		    // var moneda = this.facturaBean.codigoMoneda;
		    var moneda = this.changeMoneda(this.facturaBean.codigoMoneda);
		    /*Fin SAU20156R120400552*/
		    dijit.byId("pantallaInicial.interesMoraND").constraints = {min:0,currency:moneda, places:2};
    	}
    },
    
    limpiaMontos: function() {
       dijit.byId("pantallaInicial.interesMoraND").attr('value',"");
    },	
	
	formateaMontos: function() {
		var txtDG =dijit.byId("pantallaInicial.interesMoraND").value;
		
		if (this.facturaBean != null){
			/*Inicio SAU20156R120400552*/
			// var moneda = this.facturaBean.codigoMoneda;
			var moneda = this.changeMoneda(this.facturaBean.codigoMoneda);
			/*Fin SAU20156R120400552*/                                                                                      
			dijit.byId("pantallaInicial.interesMoraND").constraints = {min:0,currency:moneda, places:2};			
		}
	},	
  	
	downloadDocument: function() {
		var formArchivo = dojo.byId("formArchivo");
		formArchivo.submit();
	},

	// PAS20211U210100010 --Inicio
	downloadNotaDebitoPdf: function() {
		var formNDPdf = dojo.byId("formNotadebitoPdf");
		formNDPdf.submit();
	},
	// PAS20211U210100010 --Fin	

	printDocument: function() {
		window.open(this.controller + "?action=imprimirComprobante&preventCache=" + this.preventCache(), "imprimeCP" , "toolbar=0,location=0,directories=0,status=no,menubar=0,scrollbars=yes,resizable=yes,width=820,height=580,titlebar=no");
	},
	
	closeDocumentInicial: function() {
		dijit.hideTooltip(dojo.byId("pantallaInicial.numeroFE"));
		//if (confirm("Desea salir del aplicativo?")) {
		mostrarMensajeConfirmacion("\u00BFDesea salir del aplicativo?", dojo.hitch(this, function(){
			this.closeDocument();
		}));
	},

	wait: function(message, width) {
		dojo.byId("waitMessage").innerHTML="<div class='dijitInline box-message'></div><div class='dijitInline'>&nbsp;" + message + "...</div>";
	    dojo.byId("waitMessage").style.width = width;
	    this.waitMessage.show();
	},      
		
	backInicio: function() {	
		dijit.hideTooltip(dojo.byId("numeroComprobante"));
		this.content.onLoad = dojo.hitch(this, function(){
			this.initContent();
		});
		
		this.content.setHref(this.controller + "?action=mostrarPantallaInicialConDatos&mode=hidden");     
	},
	
	backModificaItems: function() {
		this.content.setHref(this.controller + "?action=regresarCambiarDetallesND&TipoNotaDebito=42");      
	},
	  
	closeDocument: function() {
		dijit.hideTooltip(dojo.byId("numeroComprobante"));
		this.content.onLoad = dojo.hitch(this, function(){
			this.initContent();
		});
		this.content.setHref(this.controller + "?action=mostrarPantallaInicial&mode=hidden");
	},
	
	iconEdit: function(rowindex) {
		var grilla =dijit.byId('ndAumentoValor.ingreso-grid');
		var datos =grilla.store._arrayOfAllItems;
		var filas = grilla.store._arrayOfAllItems.length;      

        var fila = grilla.getItem(rowindex-1);
        var valorModif= grilla.store.getValue(fila, "valorVtaUnitarioOriginal");
        valorModif = valorModif.replace(',','');
        if (valorModif< 0){ 
            return "";
        }else{
           return "<a href=\"#\" title=\"Editar\" onclick=\"notaDebitoFE.editItem(" + rowindex + ")\"><img class=\"icon-by-edit16\" src=\"/a/imagenes/see/icons/edit.gif\"/></a>";
        }  		 
	},
	
	editItem: function(identificador) {	
		store =dijit.byId('ndAumentoValor.ingreso-grid').store;
        
		store.fetchItemByIdentity({
			identity: identificador,
			onItem : function(item, request) {
				row = item;		
				currentLine = identificador 	;		
			},
			onError : function(item, request) {
				mostrarMensaje("Ocurrio un error al ubicar el documento");
				return;				
			}
		});
		
		var descripcionItem=dojo.trim(store.getValue(row, "descripcion"));
		var buscar="[*****] BONIFICACION [*****]";
		if (descripcionItem.search(buscar)!=-1 ){
			//alert("No se puede editar un item de bonificaci\u00F3n.");
			//return;		
		}
		bCargando= true;
		/*Inicio SAU20156R120400552*/
		//var moneda = this.facturaBean.codigoMoneda;
		var moneda = this.changeMoneda(this.facturaBean.codigoMoneda);
		/*Fin SAU20156R120400552*/
		dijit.byId("item.botonAceptar").attr('disabled', false);
		
		this.dialogItem.attr('title', "Captura ND - Aumento en el valor");
		dojo.byId("item.idItem").value = currentLine ; //store.getValue(row, "identificador");
		dojo.byId("item.precioUnitarioOriginal").value =store.getValue(row, "precioUnitarioOriginal");
		dojo.byId("item.otrosCargosTributos").value =store.getValue(row, "otrosCargosTributos");
		dijit.byId("item.unidadMedida").setValue(store.getValue(row, "unidadMedidaDesc"));						
		
		dijit.byId("item.cantidad").setValue(store.getValue(row, "cantidad"), false);
		dijit.byId("item.descripcion").setValue(store.getValue(row, "descripcionOriginal"));
		dijit.byId("item.igvPorcentaje").setValue(store.getValue(row, "igvPorcentaje"));


		
		//INI: PAS20191U210100075    
		console.log(row);
		var esImpuestoBolsaPlastico = store.getValue(row, "esImpuestoBolsaPlastico");

		dijit.byId("item.impuestoBolsasPlastica00").setAttribute('disabled', true);
		dijit.byId("item.impuestoBolsasPlastica01").setAttribute('disabled', true);
			
		if(esImpuestoBolsaPlastico != "IBP00"){
		
			this.showHiddenDiv(document.getElementById("item.ICBPER1.show"),false); 
			this.showHiddenDiv(document.getElementById("item.ICBPER2.show"),false); 	
			dijit.byId("item.impuestoBolsasPlastica01").setChecked("checked"); 
		}else{
			dijit.byId("item.impuestoBolsasPlastica00").setChecked("checked");
			this.showHiddenDiv(document.getElementById("item.ICBPER1.show"),false); 
			this.showHiddenDiv(document.getElementById("item.ICBPER2.show"),true); 


			var icbpermontovar = store.getValue(row, "icbPerMonto");
			dijit.byId("item.impuestoICBPER").constraints = {min:0,currency:moneda, places:2};//PAS20191U210100075
			dijit.byId("item.impuestoICBPER").attr('value',Number(icbpermontovar).toFixed(2));//PAS20191U210100075
    
		}
		//FIN: PAS20191U210100075	
		
	
		if (store.getValue(row, "modificado") =="0"){		
			//dijit.byId("item.precioUnitario").constraints = {min:0.0000000001,currency:moneda, places:10};
			dijit.byId("item.precioUnitario").constraints = {currency:moneda, places: '2,10'};
			dijit.byId("item.precioUnitario").attr('value',"0.00");
  					
  			//ISC
  			dijit.byId("item.iscMonto").constraints = {min:0,currency:moneda, places:2};
        	var montoISC = store.getValue(row, "iscMonto");
        	if(montoISC == "" || montoISC=="0.00"){
				dijit.byId("item.iscMonto").attr('disabled', true);
  		        dijit.byId("item.iscMonto").attr('value',"");	
  		        dijit.byId("item.iscMonto").attr('style',"background-color:lightgray");	
            }else{
                dijit.byId("item.iscMonto").attr('disabled', false);
                dijit.byId("item.iscMonto").attr('style',"background-color:white");	
                dijit.byId("item.iscMonto").attr('value',"0");
            }
            
            //IGV                      		
  			dijit.byId("item.precioConIGV").constraints = {min:0,currency:moneda, places:'2,10'};// Inicio PAS20211U210100007-jmendozas
        	var montoIGV = store.getValue(row, "igvMonto");
        	if(montoIGV == "" || montoIGV=="0.00" && (store.getValue(row, "tipoBeneficio") != "TB00")){
				dijit.byId("item.igvPorcentaje").setValue(0.00);
            	dijit.byId("item.precioConIGV").attr('disabled', true);
  		        dijit.byId("item.precioConIGV").attr('value',"");	
  		        dijit.byId("item.precioConIGV").attr('style',"background-color:lightgray");	
            }else{
                dijit.byId("item.precioConIGV").attr('disabled', false);
                dijit.byId("item.precioConIGV").attr('style',"background-color:white");	
                dijit.byId("item.precioConIGV").attr('value',"0");
            }
			
            //Otros Tributos
            var montoOtrosCargosTributos = store.getValue(row, "otrosCargosTributos");
        	if((montoOtrosCargosTributos != "" && montoOtrosCargosTributos!="0.00")){
				dijit.byId("item.unidadMedida").attr('disabled',true);			
                dijit.byId("item.unidadMedida").setValue("");				
				dijit.byId("item.cantidad").attr('disabled',true);
                dijit.byId("item.cantidad").setValue("");			
        	}else{
				dijit.byId("item.unidadMedida").attr('disabled',false);			
				dijit.byId("item.cantidad").attr('disabled',false);
            }
  			/*dijit.byId("item.otrosTributos").constraints = {min:0,currency:moneda, places:2};
        	var montoOtrosTributos = this.facturaBean.totalOtrosTributos;

        	if(montoOtrosTributos == "" || montoOtrosTributos=="0.00"){
				dijit.byId("item.otrosTributos").attr('disabled', true);
  		        dijit.byId("item.otrosTributos").attr('value',"");	
  		        dijit.byId("item.otrosTributos").attr('style',"background-color:lightgray");	
            }else{
                dijit.byId("item.otrosTributos").attr('disabled', false);
                dijit.byId("item.otrosTributos").attr('style',"background-color:white");
                dijit.byId("item.otrosTributos").attr('value',"0");	
            }*/
            
            //Otros Cargos
  			/*dijit.byId("item.otrosCargos").constraints = {min:0,currency:moneda, places:2};
        	var montoOtrosCargos = store.getValue(row, "otrosCargos");
        	if(montoOtrosCargos == "" || montoOtrosCargos=="0.00"){
            	dijit.byId("item.otrosCargos").attr('disabled', true);
  		        dijit.byId("item.otrosCargos").attr('value',"");	
  		        dijit.byId("item.otrosCargos").attr('style',"background-color:lightgray");	
            }else{
                dijit.byId("item.otrosCargos").attr('disabled', false);
                dijit.byId("item.otrosCargos").attr('style',"background-color:white");	
                dijit.byId("item.otrosCargos").attr('value',"0");
            }*/
    				
  			dijit.byId("item.importeVenta").constraints = {min:0,currency:moneda, places:'2,10'};// Inicio PAS20211U210100007-jmendozas
  			dijit.byId("item.importeVenta").attr('value',"0");
		}else{				  
			//dijit.byId("item.precioUnitario").constraints = {min:0.0000000001,currency:moneda, places:10};
			dijit.byId("item.precioUnitario").constraints = {currency:moneda, places: '2,10'};
  			dijit.byId("item.precioUnitario").attr('value',store.getValue(row, "precioUnitario"));
  					
  			//ISC
  			dijit.byId("item.iscMonto").constraints = {min:0,currency:moneda, places:2};
        	var montoISC = store.getValue(row, "iscMonto");
        	if(montoISC == "" || montoISC=="0.00"){
				dijit.byId("item.iscMonto").attr('disabled', true);
  		        dijit.byId("item.iscMonto").attr('value',"");	
  		        dijit.byId("item.iscMonto").attr('style',"background-color:lightgray");	
            }else{
                dijit.byId("item.iscMonto").attr('disabled', false);
                dijit.byId("item.iscMonto").attr('style',"background-color:white");	
                dijit.byId("item.iscMonto").attr('value',montoISC);
            }
              					
            //IGV                      		
  			dijit.byId("item.precioConIGV").constraints = {min:0,currency:moneda, places:'2,10'};// Inicio PAS20211U210100007-jmendozas
        	var montoIGV = store.getValue(row, "igvMonto");
        	if(montoIGV == "" || montoIGV=="0.00" && (store.getValue(row, "tipoBeneficio") != "TB00")){
				dijit.byId("item.igvPorcentaje").setValue(0.00);
            	dijit.byId("item.precioConIGV").attr('disabled', true);
				dijit.byId("item.precioConIGV").attr('value',"");	
  		        dijit.byId("item.precioConIGV").attr('style',"background-color:lightgray");	
            }else{
                dijit.byId("item.precioConIGV").attr('disabled', false);
                dijit.byId("item.precioConIGV").attr('style',"background-color:white");	
                dijit.byId("item.precioConIGV").attr('value',montoIGV);
            }
  
            //Otros Cargos
  			/*dijit.byId("item.otrosCargos").constraints = {min:0,currency:moneda, places:2};
        	var montoOtrosCargos = store.getValue(row, "otrosCargos");
        	if(montoOtrosCargos == "" || montoOtrosCargos=="0.00"){
				dijit.byId("item.otrosCargos").attr('disabled', true);
  		        dijit.byId("item.otrosCargos").attr('value',"");	
  		        dijit.byId("item.otrosCargos").attr('style',"background-color:lightgray");	
            }else{
                dijit.byId("item.otrosCargos").attr('disabled', false);
                dijit.byId("item.otrosCargos").attr('style',"background-color:white");	
                dijit.byId("item.otrosCargos").attr('value',montoOtrosCargos);
            }*/
            
            //Otros Tributos
  			/*dijit.byId("item.otrosTributos").constraints = {min:0,currency:moneda, places:2};
        		
        	var montoOtrosTributos = this.facturaBean.totalOtrosTributos;
        	if(montoOtrosTributos == "" || montoOtrosTributos=="0.00"){
				dijit.byId("item.otrosTributos").attr('disabled', true);
  		        dijit.byId("item.otrosTributos").attr('value',"");	
  		        dijit.byId("item.otrosTributos").attr('style',"background-color:lightgray");	
            }else{
                var montoOtrosTributos = store.getValue(row, "otrosTributos");
                dijit.byId("item.otrosTributos").attr('disabled', false);
                dijit.byId("item.otrosTributos").attr('style',"background-color:white");
                dijit.byId("item.otrosTributos").attr('value',montoOtrosTributos);	
            }*/
  				
  			dijit.byId("item.importeVenta").constraints = {min:0,currency:moneda, places:'2,10'};// Inicio PAS20211U210100007-jmendozas
            dijit.byId("item.importeVenta").attr('value', store.getValue(row, "importeVenta"));        
		}
		
		//PAS20191U210100075
		//if(store.getValue(row, "esImpuestoBolsaPlastico") != "IBP00"){
		
			dijit.byId("item.cantidad").constraints = {min:0.0000000001, places:'2,10',pattern:'########.00########'}
			//dijit.byId("item.cantidad").constraints = {min:0,places:2};
			//dijit.byId("item.cantidad").setValue(dojo.trim(dojo.currency.format(store.getValue(row, "cantidad")))); // PAS20191U210100075 01.08
      dijit.byId("item.cantidad").setValue(dojo.trim(store.getValue(row, "cantidad"))); //PAS20201U210100022 				
		/*}else{
			dijit.byId("item.cantidad").constraints = {min:0,places:0};
			dijit.byId("item.cantidad").setValue(Number(store.getValue(row, "cantidad")).toFixed(0), false);
		}
		*/
		
		bCargando= false;
		this.dialogItem.show();		
	},
	//INI PAS20191U210100075
	viewCheckedImpuestoBolsaPlastica: function() {
		var valOpcionImpuestoBolsaPlastica = this.getValorOpcionImpuestoBolsaPlastica();
		   	console.log("check " + valOpcionImpuestoBolsaPlastica);
		
		if (valOpcionImpuestoBolsaPlastica != "IBP00"){
			dojo.byId("item.tasaBolsaGlobal").value = "0";
			this.updateItemAmount26();
			
		}else{
			//dojo.byId("item26.tasaBolsaGlobal").value = dojo.byId("item26.tasaBolsaGlobal2").value;
			this.updateItemAmount26();
		}
			
	},
	getValorOpcionImpuestoBolsaPlastica: function() {
		var valOpcionImpuestoBolsaPlastica="";
		for(i = 0; i < 2; i++) {
			//if(dijit.byId("item.subTipoTB0" + i).getValue() != false) {
			if(document.getElementById("item.impuestoBolsasPlastica0"+i).checked == true) {
				valOpcionImpuestoBolsaPlastica = document.getElementById("item.impuestoBolsasPlastica0"+i).value;
			}
		}
		return valOpcionImpuestoBolsaPlastica;
	},  	
  //FIN PAS20191U210100075
	
	updateItemAmount: function() {
		var cantidad=0;
		var igvPorcentaje = 0;
		var cantidadXPrecio = 0;
		var iscMonto = 0;
		var igvMonto = 0;
		var otroMonto = 0;
		var otroTributo = 0;
		var totalItem = 0;
		var precioUnitario =0;
		
		if (bCargando == true) {return;}
		
		igvPorcentaje = this.igvFE /100 ;    //IGV 19 
		
		//PAS20191U210100075
		/*var valOpcionImpuestoBolsaPlastica = this.getValorOpcionImpuestoBolsaPlastica();
		if (valOpcionImpuestoBolsaPlastica != "IBP00"){ //NO > IMPUESTO BOLSAS;

			dijit.byId("item.cantidad").constraints = {min:0,max:20000,places:2};;
			dijit.byId("item.cantidad").attr('value',dijit.byId("item.cantidad").getValue());
			
		}else{ // SI IMPUESTO BOLSAS				

			dijit.byId("item.cantidad").constraints = {min:0,max:20000,places:0};
			dijit.byId("item.cantidad").attr('value',dijit.byId("item.cantidad").getValue());
		}*/
		cantidad=dijit.byId("item.cantidad").value;
		
		console.log(cantidad);
		//PAS20191U210100075
		
		
		/*Inicio SAU20156R120400552*/
		// var moneda = this.facturaBean.codigoMoneda;
		var moneda = this.changeMoneda(this.facturaBean.codigoMoneda);
		/*Fin SAU20156R120400552*/
		
		var montoOtrosCargosTributos =dojo.byId("item.otrosCargosTributos").value ;
		if (isNaN(montoOtrosCargosTributos) || montoOtrosCargosTributos == 0 ||  montoOtrosCargosTributos == null ){
			cantidad=dojo.byId("item.cantidad").value;
		} else {
			cantidad=1.00;
		}
		
		precioUnitario =dijit.byId("item.precioUnitario").getValue();
		cantidadXPrecio = cantidad * precioUnitario; // Antes
		/*PAS20165E210300142*/
		//cantidadXPrecio = precioUnitario; 
		/*PAS20165E210300142*/
		iscMonto = dijit.byId("item.iscMonto").getValue();
		if (isNaN(iscMonto)){ iscMonto = 0;}
		
		igvMonto = dijit.byId("item.precioConIGV").getValue();
		
		if (isNaN(igvMonto) || (dijit.byId("item.igvPorcentaje").getValue() ==0)){ 
			igvMonto = 0;
		}else{
		   igvMonto = ((cantidadXPrecio + iscMonto)* igvPorcentaje);
		}
		
		//otroMonto = dijit.byId("item.otrosCargos").getValue();
		//if (isNaN(otroMonto)){ otroMonto = 0;}
		
		//otroTributo = dijit.byId("item.otrosTributos").getValue();
		//if (isNaN(otroTributo)){ otroTributo = 0;}
		
		//IMPORTE DE VENTA=((VALOR UNITARIO)*CANTIDAD)-(DESCUENTOS)+(IGV)+(ISC MONTO)+(OTROS CARGOS)
		totalItem =cantidadXPrecio + igvMonto + iscMonto;// + otroMonto + otroTributo;

		//dijit.byId("item.precioUnitario").attr('value',dojo.currency.format(dijit.byId("item.precioUnitario").getValue(), {currency: moneda, places: 10}));
		dojo.byId("item.precioUnitario").value= dojo.number.format(dijit.byId("item.precioUnitario").getValue(),{currency:moneda, places:'2,10'});
		if (isNaN(montoOtrosCargosTributos) || montoOtrosCargosTributos == 0 ||  montoOtrosCargosTributos == null ){	
		    dijit.byId("item.precioConIGV").attr('value',dojo.currency.format(igvMonto, {currency: moneda, places: '2,10'}));// Inicio PAS20211U210100007-jmendozas
		    dijit.byId("item.iscMonto").attr('value',dojo.currency.format(iscMonto, {currency: moneda, places: 2}), false);
		}

		//dijit.byId("item.otrosCargos").attr('value',dojo.currency.format(otroMonto, {currency: moneda, places: 2}),false);
		//dijit.byId("item.otrosTributos").attr('value',dojo.currency.format(otroTributo, {currency: moneda, places: 2}),false);
		dijit.byId("item.importeVenta").attr('value',dojo.currency.format(totalItem, {currency: moneda, places: '2,10'}));// Inicio PAS20211U210100007-jmendozas
        dijit.hideTooltip(dojo.byId("item.precioUnitario"));
		dijit.hideTooltip(dojo.byId("item.iscMonto"));			
	},		
	
	acceptDialogItem: function() {
		/*Inicio SAU20156R120400552*/
        // var moneda = this.facturaBean.codigoMoneda;
        var moneda = this.changeMoneda(this.facturaBean.codigoMoneda);
		/*Fin SAU20156R120400552*/
		
    	if (dijit.byId("item.precioUnitario").getValue() == "" ) {
			var node = dijit.byId("item.precioUnitario");
			this.iconTooltipMessage(node.focusNode,"icon-ok-tooltip", "Debe consignarse el valor unitario.");
				
			//node.constraints = {min:0.0000000001,currency:moneda,places:10};
			node.constraints = {min:0.0000000001,currency:moneda,places:'2,10'};
			return;
		}	
		if (dijit.byId("item.precioUnitario").getValue() <= 0 ) {
			var node = dijit.byId("item.precioUnitario");
			this.iconTooltipMessage(node.focusNode,"icon-ok-tooltip", "Valor unitario debe ser mayor a 0.");
			
			//node.constraints = {min:0.0000000001,currency:moneda, places:10};
			node.constraints = {min:0.0000000001,currency:moneda, places:'2,10'};
			return;
		}	
		
		if (dijit.byId("item.iscMonto").attr('disabled') == false){
			//PAS20211U210100037
			//if (dijit.byId("item.iscMonto").getValue() == "" ) {
        	if (dijit.byId("item.iscMonto").getValue() === "" ) {
  				var node = dijit.byId("item.iscMonto");
  				this.iconTooltipMessage(node.focusNode,"icon-ok-tooltip", "Debe consignarse ISC.");
  				
  				node.constraints = {min:0,currency:moneda, places:2};
  				return;
  			}
  			//if (dijit.byId("item.iscMonto").getValue() <= 0 ) {
			if (dijit.byId("item.iscMonto").getValue() < 0 ) {
  				var node = dijit.byId("item.iscMonto");
  				this.iconTooltipMessage(node.focusNode,"icon-ok-tooltip", "ISC debe ser mayor que 0.");
  				
  				node.constraints = {min:0,currency:moneda, places:2};
  				return;
  			}
  			if (dijit.byId("item.iscMonto").getValue() >= dijit.byId("item.precioUnitario").getValue()) {
  				var node = dijit.byId("item.iscMonto");
  				this.iconTooltipMessage(node.focusNode,"icon-ok-tooltip", "ISC debe ser menor que el Valor Unitario.");
  				
  				node.constraints = {min:0,currency:moneda, places:2};
  				return;
  			}	
		}
		///
		var nbControl = dijit.byId("item.botonAceptar");
		nbControl.setAttribute('disabled', true);
		var nodeButton = nbControl.focusNode;
		var mode = dojo.byId("item.action").value;
		this.wait("Editando", "95px", 200);
		
  		var handler = dojo.io.iframe.send({
  			url: this.controller,
  			handleAs: "json",
  			sync: true,
  			timeout: 10000,
  			preventCache: true,
  			form: "item.form"
  		});
		handler.addCallback(dojo.hitch(this, function(res){
			this.waitMessage.hide();
			if(res.codeError == 0) {
				var row = eval("(" + res.data + ")");					
        		store.fetchItemByIdentity({
        			identity: currentLine,
        			onItem: dojo.hitch(this, function(item){
						store.setValue(item,'precioUnitario',dojo.byId("item.precioUnitario").value );
						if (dojo.byId("item.iscMonto").value != ""){	store.setValue(item,'iscMonto',dojo.byId("item.iscMonto").value ); }
						if (dojo.byId("item.precioConIGV").value != ""){	store.setValue(item,'igvMonto',dojo.byId("item.precioConIGV").value );}
						//if (dojo.byId("item.otrosCargos").value!=""){	store.setValue(item,'otrosCargos',dojo.byId("item.otrosCargos").value );}
						//if (dojo.byId("item.otrosTributos").value!=""){	store.setValue(item,'otrosTributos',dojo.byId("item.otrosTributos").value );}
						store.setValue(item,'modificado',"1");
						store.setValue(item,'importeVenta',dojo.byId("item.importeVenta").value);        			
        			}),
        			onError: function(){}
        		});
					
			  	var grid = dijit.byId('ndAumentoValor.ingreso-grid');
				grid.setStore(store);
				grid.update();
				this.closeDialogItem();
				//this.updateTotalAmount();				
			} else {
				nbControl.setAttribute('disabled', false);
				this.iconTooltipMessage(nodeButton, "icon-error-tooltip", res.messageError);
			}
		}));
		handler.addErrback(dojo.hitch(this, function(res) {
			nbControl.setAttribute('disabled', false);
			this.waitMessage.hide();
			this.iconTooltipMessage(nodeButton, "icon-error-tooltip", "Problemas al conectarse al servidor");
		}));
		
		nbControl.setAttribute('disabled', false);			

		dijit.hideTooltip(dojo.byId("item.precioUnitario"));
		dijit.hideTooltip(dojo.byId("item.precioUnitario"));
		dijit.hideTooltip(dojo.byId("item.iscMonto"));
    },
		
	closeDialogItem: function() {
		this.dialogItem.hide();
	},

	valorUnitario: function(valor, rowindex) {
		var valor2 = valor.replace(',','');

	    if (valor2<0){
			return "";
		}else{
			return valor;
		}	
	},
  	
	verPreliminarIncremento:function(){
	    //Validamos que por lo menos se haya modificado un item
		var grilla =dijit.byId('ndAumentoValor.ingreso-grid');
		var datos =grilla.store._arrayOfAllItems;
		var filas = grilla.store._arrayOfAllItems.length;
		var numModificados=0;
		
		for (i=0; i< filas;i++){
			var fila = grilla.getItem(i);
			var valorModif= grilla.store.getValue(fila, "modificado");
			if (valorModif==1){ numModificados ++;}
		}
		
		if (numModificados == 0){
			mostrarMensaje("Debe seleccionar por lo menos un Item de la FE, y consignar los datos de la Nota de D\xE9bito.");
			return;
		}
		
		var numeroFE = dijit.byId("pantallaInicial.numeroFE").value;
		var serieFE = dijit.byId("pantallaInicial.serieFE").value;
		var motivoEmisionND = dijit.byId("pantallaInicial.motivoEmisionND").value;
		this.content.setHref(this.controller + "?action=preliminarComprobante&TipoNotaDebito=42&factura=" + numeroFE 
		                                        + "&serie=" + serieFE 
												+ "&motivo=" + motivoEmisionND);
	},
	
	
	verPreliminarIncrementoContin:function(){
		var serie = document.getElementById("serie").value;
		var numero = document.getElementById("numero").value;
		var idSerie = document.getElementById("idSerie").value;
	    //Validamos que por lo menos se haya modificado un item
		var grilla =dijit.byId('ndAumentoValor.ingreso-grid');
		var datos =grilla.store._arrayOfAllItems;
		var filas = grilla.store._arrayOfAllItems.length;
		var numModificados=0;
		
		for (i=0; i< filas;i++){
			var fila = grilla.getItem(i);
			var valorModif= grilla.store.getValue(fila, "modificado");
			if (valorModif==1){ numModificados ++;}
		}
		
		if (numModificados == 0){
			mostrarMensaje("Debe seleccionar por lo menos un Item de la FE, y consignar los datos de la Nota de D\xE9bito.");
			return;
		}
		
		var numeroFE = dijit.byId("pantallaInicial.numeroFE").value;
		var motivoEmisionND = dijit.byId("pantallaInicial.motivoEmisionND").value;
		this.content.setHref(this.controller + "?action=preliminarComprobanteContin&TipoNotaDebito=42&factura=" + numeroFE 
												+ "&motivo=" + motivoEmisionND+"&idSerie="+idSerie+"&serie="+serie+"&numero="+numero);
	},
	
	
	onStyleRow :function(inRow){
		var store = dijit.byId('ndAumentoValor.ingreso-grid').store;
		var item = store._arrayOfAllItems[ inRow.index ];
		if (item!=null){
           var modif = store.getValue(item, "modificado");
			if( modif == "1" ) {
				with (inRow) {                  
					inRow.customStyles += ' color: blue; font-weight: bold';
				} 
			}
		}
    },
    
	/*Inicio SAU20156R120400552*/
	changeMoneda: function(moneda){
		if(moneda=="XEU"){
		    return "EUR";
		}
		return moneda;
    },
    /*Fin SAU20156R120400552*/

	showHiddenDiv: function(node,show) {
		if (show == true) { //Mostrar
			node.style.display = "";
	    } else { //Ocultar
			node.style.display = "none";
	    }
	}
       
    });
}
