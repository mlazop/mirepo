// (function(window, $, _) {
    /*
     * :::: CONTAINERS :::: START
     */


 var $formCatalogo = $("#form-email");

var $email=$("#txtEmail");



    /*
   	*  :::: CONTAINERS :::: END
   	*/

   	/*
   	*  :::: HELPERS :::: START
   	*/

   	/*
   	*  :::: HELPERS :::: END
   	*/

   	/*
   	*  :::: FUNCTION :::: START
   	*/

   $('.footable').footable();
   	/*
   	*  :::: FUNCTION :::: END
   	*/

   	/*
   	*  :::: SETUP :::: START
   	*/

    $formCatalogo.validate(_.extend(window._validatorWallSettings, {
        debug: false,
        rules: {
            txtEmail: {
                required: true,
                email: true
            }
        },
       
        submitHandler: function(form) {
           
          var formData=$(form).serializeObject();
          var url = 'emitirbvsimp.do?action=enviarCorreo';
            $.ajax({
              method: 'post',
              data: formData,
              url:url,
              success: function (data) {
              alert('Envio Satisfactorio');
              },

              error: function() {

                alert('Ocurrio un error intentelo en unos minutos');

              }



            })

            
        }
    }));




// })(window, jQuery, _);