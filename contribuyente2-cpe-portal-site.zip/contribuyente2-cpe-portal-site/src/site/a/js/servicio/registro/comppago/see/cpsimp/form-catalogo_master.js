//(function(window, $, _){
/*
 * :::: CONTAINERS :::: START
 */
    var $formCatalogo = $("#form-catalogo");
    var $txtCodigo = $formCatalogo.find("#txtCodigo");
    var $txtDescripcion = $formCatalogo.find("#txtDescripcion");
    var $_ambosValido = $formCatalogo.find("#ambosValido");

    var $formRegistroProductos = $("#form-modal-registro-productos");
    var $formEditarProductos = $("#form-modal-editar-productos");
    var $seccionOtrasMonedas = $('.otras-monedas');

    var $btnEliminar = $(".remover");

    var $modalEditarProducto = $("#modal-editar-producto");
    var $modalRegistroProducto = $("#modal-registro-producto");




    var _validateRegistroEditarSetup = {
        rules: {
            txtCodigo: {
                required: true,
                maxlength: 15,
                validStr: true
            },
            txtDescripcion: {
                required: true,
                maxlength: 200,
                validStr: true
            },
            selTipo: {
                required: true,
            },
            selUnidad: {
                required: true,
            },
            txtPen: {
                required: true,
                number: true,
                lessThan: 999999999999.9999999999,
                moreThan: 0
            }
        },
        messages: {
            datafile: {
                required: "seleccione archivo"
            }
        }
    }

    $('.square-addon').on('click', function (e) {
      $(e.target).removeClass('disabled');
    })
    $('.disable-currency').on('click', function (e) {
      $(e.target).closest('.btn').parent().find('.square-addon').addClass('disabled');
    })
    
    $txtCodigo.add($txtDescripcion).on('change keyup', function (e) {
        $_ambosValido.val((!!$txtCodigo.val() | !!$txtDescripcion.val()) ? "valid" : "").trigger('change');
    })


    $btnEliminar.on('click', function  (e) {
        if(!confirm('seguro?')){
            e.preventDefault();
            return;
        }

        $(this).closest('tr').remove();
        var url = "";
        var data = {}
        $.post(url, data).success(function (data) {
            console.log(data)
        }).error(function (reason) {
            console.log(reason)
        });
    })

    $('.footable').footable();


    $('.mostrar-monedas').on('click', function (e) {
        var $self = $(this).closest('.btn'); // .parent().parent().addClass('hidden');
        var $icon = $self.find('i')
        if($icon.hasClass('glyphicon-chevron-down'))
            $icon.addClass('glyphicon-chevron-up').removeClass('glyphicon-chevron-down')
        else
            $icon.addClass('glyphicon-chevron-down').removeClass('glyphicon-chevron-up')

        $seccionOtrasMonedas.toggleClass('hidden');
    })


    $formCatalogo.validate(_.extend(window._validatorWallSettings, {
        debug: true,
        ignore: 'button',
        rules: {
            txtCodigo: {
                maxlength: 15,
                minlength: 3,
                validStr: true
            },
            txtDescripcion: {
                maxlength: 200,
                validStr: true
            },
            ambosValido: {
                required: true
            }
        },
        // estos mensajes estan aqui porque son d&iacute;n&aacute;micos respecto al html
        messages: {
            ambosValido: {
                required: "almenos 1 campo",
            },
            txtCodigo: {
                maxlength: "txtCodigo -> maxlength",
                minlength: "txtCodigo -> minlength",
                validStr: "txtCodigo -> validStr",
            },
            txtDescripcion: {
                maxlength: "txtDescripcion -> maxlength",
                validStr: "txtDescripcion -> validStr"
            }
        },
        submitHandler: function(form) {
            console.log('valid-consulta-catalogo')
            form.submit();
        }
    }));

     $formRegistroProductos.validate(_.extend(window._validatorWallSettings, _validateRegistroEditarSetup, {
        debug: true,
        submitHandler: function (form) {
            console.log('valid-registrar-producto')
            $modalRegistroProducto.modal('hide');
            
	    /*
            var fields = {}
            decodeURIComponent($formEditarProductos.serialize())
              .split("&")
              .map(function(e){ 
                return e.split('='); 
              })
              .forEach(function(pair){
                fields[pair[0]] = pair[1]
              })
            var url = "catalogo.do?agregarCatalogo"

            var form = $('<form/>', {
                action: url,
                method: 'post'
            }).appendTo('body')
            
            for(var i in fields){
                $('<input/>', {type: 'hidden', name: i}).val(fields[i]).appendTo(form)
            }

	   */
            form.submit();
            
        }
    }));

    $formEditarProductos.validate(_.extend(window._validatorWallSettings, _validateRegistroEditarSetup, {
        debug: true,
        submitHandler: function (form) {
            console.log('valid-editar-producto')
            $modalEditarProducto.modal('hide');
            /*
            var fields = {}
            decodeURIComponent($formEditarProductos.serialize())
              .split("&")
              .map(function(e){ 
                return e.split('='); 
              })
              .forEach(function(pair){
                fields[pair[0]] = pair[1]
              })
            var url = "editar-final.html"

            var form = $('<form/>', {
                action: url,
                method: 'post'
            }).appendTo('body')
            
            for(var i in fields){
                $('<input/>', {type: 'hidden', name: i}).val(fields[i]).appendTo(form)
            }
            form.submit();
            */
        }
    }));

//})(window, jQuery, _);