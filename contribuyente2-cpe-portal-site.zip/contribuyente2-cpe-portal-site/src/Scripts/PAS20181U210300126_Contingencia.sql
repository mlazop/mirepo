unload to "t1510agrupacion.unl" select * from t1510agrupacion;
unload to "t1509sistema.unl" select * from t1509sistema;
unload to "t1506programa.unl" select * from t1506programa;
unload to "t1508grupo.unl" select * from t1508grupo;
unload to "t1507perfilprogram.unl" select * from t1507perfilprogram;
--creacion de una agrupacion
INSERT INTO t1510agrupacion (cod_pestana,cod_agrupacion,des_nombre,des_resumen,num_orden,ind_del,cod_usumodif,fec_modif)
VALUES (11, 17, 'Comprobantes - Contingencia', 'Comprobantes - Contingencia', 17, '2', USER, TODAY);
--creacion de sistemas
INSERT INTO t1509sistema (cod_pestana,cod_agrupacion,cod_sistema,des_nombre,num_orden,ctd_min_opcion, cod_prg_default,ind_del,cod_usumodif,fec_modif)
VALUES (11, 17, 1, 'Factura', 1, 10, '', '2', USER, TODAY);
INSERT INTO t1509sistema (cod_pestana,cod_agrupacion,cod_sistema,des_nombre,num_orden,ctd_min_opcion, cod_prg_default,ind_del,cod_usumodif,fec_modif)
VALUES (11, 17, 2, 'Boleta de Venta', 2, 10, '', '2', USER, TODAY);
INSERT INTO t1509sistema (cod_pestana,cod_agrupacion,cod_sistema,des_nombre,num_orden,ctd_min_opcion, cod_prg_default,ind_del,cod_usumodif,fec_modif)
VALUES (11, 17, 3, 'Comprobante de Percepción', 3, 10, '', '2', USER, TODAY);
INSERT INTO t1509sistema (cod_pestana,cod_agrupacion,cod_sistema,des_nombre,num_orden,ctd_min_opcion, cod_prg_default,ind_del,cod_usumodif,fec_modif)
VALUES (11, 17, 4, 'Comprobante de Retención', 4, 10, '', '2', USER, TODAY);
INSERT INTO t1509sistema (cod_pestana,cod_agrupacion,cod_sistema,des_nombre,num_orden,ctd_min_opcion, cod_prg_default,ind_del,cod_usumodif,fec_modif)
VALUES (11, 17, 5, 'Baja Comprobantes', 5, 10, '', '2', USER, TODAY);
--Creacion de grupos
INSERT INTO t1508grupo(cod_pestana,cod_agrupacion,cod_sistema,cod_grupo,des_nombre,cod_padre, num_orden,ind_del,cod_usumodif,fec_modif) 
VALUES (11, 17, 1, 1, 'Grupo Factura', 0, 1, '2', USER, TODAY);
INSERT INTO t1508grupo(cod_pestana,cod_agrupacion,cod_sistema,cod_grupo,des_nombre,cod_padre, num_orden,ind_del,cod_usumodif,fec_modif) 
VALUES (11, 17, 2, 1, 'Grupo Boleta de Venta', 0, 2, '2', USER, TODAY);
INSERT INTO t1508grupo(cod_pestana,cod_agrupacion,cod_sistema,cod_grupo,des_nombre,cod_padre, num_orden,ind_del,cod_usumodif,fec_modif) 
VALUES (11, 17, 3, 1, 'Grupo Comprobantes de Percepcion', 0, 3, '2', USER, TODAY);
INSERT INTO t1508grupo(cod_pestana,cod_agrupacion,cod_sistema,cod_grupo,des_nombre,cod_padre, num_orden,ind_del,cod_usumodif,fec_modif) 
VALUES (11, 17, 4, 1, 'Grupo Comprobantes de Retencion', 0, 4, '2', USER, TODAY);
INSERT INTO t1508grupo(cod_pestana,cod_agrupacion,cod_sistema,cod_grupo,des_nombre,cod_padre, num_orden,ind_del,cod_usumodif,fec_modif) 
VALUES (11, 17, 5, 1, 'Grupo Baja', 0, 5, '2', USER, TODAY);
--Creacion de un programa------------------------------------------------
INSERT INTO t1506programa (cod_pestana,cod_agrupacion,cod_sistema,cod_grupo,cod_programa, des_nombre,des_contexto, des_servlet,des_tags,des_opcion,fec_inivig, fec_finvig,hor_inicio,hor_fin,num_orden_pestana, num_orden_agrupa,num_orden_sistema,num_orden_grupo,num_orden_programa, ind_acceso,tip_invoca,ind_del,ind_visual,cod_usumodif,fec_modif)
VALUES  (11, 17, 1, 1, 1, 'Registro Factura', '/ol-ti-itemisionfacturacontin', '/emitir.do', 'EmisiondelaFactura', 'Emision de la Factura', to_date('2010-01-01','%Y-%m-%d'), to_date('2040-01-01','%Y-%m-%d'), to_date('00:00','%H:%M') , to_date('23:59','%H:%M'), 11, 17, 1, 1, 1, '1', '3', '2', '1', USER, TODAY); 
INSERT INTO t1506programa (cod_pestana,cod_agrupacion,cod_sistema,cod_grupo,cod_programa, des_nombre,des_contexto, des_servlet,des_tags,des_opcion,fec_inivig, fec_finvig,hor_inicio,hor_fin,num_orden_pestana, num_orden_agrupa,num_orden_sistema,num_orden_grupo,num_orden_programa, ind_acceso,tip_invoca,ind_del,ind_visual,cod_usumodif,fec_modif)
VALUES  (11, 17, 1, 1, 2, 'Notas de Crédito', '/ol-ti-itnotacreditofecontin', '/emitirNCFE.do', 'NotasdeCreditoF', 'Notas de Crédito', to_date('2010-01-01','%Y-%m-%d'), to_date('2040-01-01','%Y-%m-%d'), to_date('00:00','%H:%M') , to_date('23:59','%H:%M'), 11, 17, 1, 1, 2, '1', '3', '2', '1', USER, TODAY); 
INSERT INTO t1506programa (cod_pestana,cod_agrupacion,cod_sistema,cod_grupo,cod_programa, des_nombre,des_contexto, des_servlet,des_tags,des_opcion,fec_inivig, fec_finvig,hor_inicio,hor_fin,num_orden_pestana, num_orden_agrupa,num_orden_sistema,num_orden_grupo,num_orden_programa, ind_acceso,tip_invoca,ind_del,ind_visual,cod_usumodif,fec_modif)
VALUES  (11, 17, 1, 1, 3, 'Notas de Débito', '/ol-ti-itnotadebitofecontin', '/emitirNDFE.do', 'NotasdeDebitoF', 'Notas de Débito', to_date('2010-01-01','%Y-%m-%d'), to_date('2040-01-01','%Y-%m-%d'), to_date('00:00','%H:%M') , to_date('23:59','%H:%M'), 11, 17, 1, 1, 3, '1', '3', '2', '1', USER, TODAY); 
INSERT INTO t1506programa (cod_pestana,cod_agrupacion,cod_sistema,cod_grupo,cod_programa, des_nombre,des_contexto, des_servlet,des_tags,des_opcion,fec_inivig, fec_finvig,hor_inicio,hor_fin,num_orden_pestana, num_orden_agrupa,num_orden_sistema,num_orden_grupo,num_orden_programa, ind_acceso,tip_invoca,ind_del,ind_visual,cod_usumodif,fec_modif)
VALUES  (11, 17, 2, 1, 1, 'Registro Boleta de Venta', '/ol-ti-itemisionboletacontin', '/emitir.do', 'EmitirBoletaDeVenta', 'Emision de la Boleta', to_date('2010-01-01','%Y-%m-%d'), to_date('2040-01-01','%Y-%m-%d'), to_date('00:00','%H:%M') , to_date('23:59','%H:%M'), 11, 17, 2, 1, 1, '1', '3', '2', '1', USER, TODAY); 
INSERT INTO t1506programa (cod_pestana,cod_agrupacion,cod_sistema,cod_grupo,cod_programa, des_nombre,des_contexto, des_servlet,des_tags,des_opcion,fec_inivig, fec_finvig,hor_inicio,hor_fin,num_orden_pestana, num_orden_agrupa,num_orden_sistema,num_orden_grupo,num_orden_programa, ind_acceso,tip_invoca,ind_del,ind_visual,cod_usumodif,fec_modif)
VALUES  (11, 17, 2, 1, 2, 'Notas de Crédito', '/ol-ti-itnotacreditobvecontin', '/emitirNCBVE.do', 'NotasdeCreditoB', 'Notas de Crédito', to_date('2010-01-01','%Y-%m-%d'), to_date('2040-01-01','%Y-%m-%d'), to_date('00:00','%H:%M') , to_date('23:59','%H:%M'), 11, 17, 2, 1, 2, '1', '3', '2', '1', USER, TODAY); 
INSERT INTO t1506programa (cod_pestana,cod_agrupacion,cod_sistema,cod_grupo,cod_programa, des_nombre,des_contexto, des_servlet,des_tags,des_opcion,fec_inivig, fec_finvig,hor_inicio,hor_fin,num_orden_pestana, num_orden_agrupa,num_orden_sistema,num_orden_grupo,num_orden_programa, ind_acceso,tip_invoca,ind_del,ind_visual,cod_usumodif,fec_modif)
VALUES  (11, 17, 2, 1, 3, 'Notas de Débito', '/ol-ti-itnotadebitobvecontin', '/emitirNDBVE.do', 'NotasdeDebitoB', 'Notas de Débito', to_date('2010-01-01','%Y-%m-%d'), to_date('2040-01-01','%Y-%m-%d'), to_date('00:00','%H:%M') , to_date('23:59','%H:%M'), 11, 17, 2, 1, 3, '1', '3', '2', '1', USER, TODAY); 
INSERT INTO t1506programa (cod_pestana,cod_agrupacion,cod_sistema,cod_grupo,cod_programa, des_nombre,des_contexto, des_servlet,des_tags,des_opcion,fec_inivig, fec_finvig,hor_inicio,hor_fin,num_orden_pestana, num_orden_agrupa,num_orden_sistema,num_orden_grupo,num_orden_programa, ind_acceso,tip_invoca,ind_del,ind_visual,cod_usumodif,fec_modif)
VALUES  (11, 17, 3, 1, 1, 'Registro Comprobante de Percepción', '/ol-ti-itcppercepcioncon', '/emision/iniRegiCompCon', 'EmitirComprobantedePercepcion', 'Emitir Comprobante de Percepción de Contingencia', to_date('2010-01-01','%Y-%m-%d'), to_date('2040-01-01','%Y-%m-%d'), to_date('00:00','%H:%M'), to_date('23:59','%H:%M'), 11, 17, 3, 1, 1, '1', '3', '2', '1', USER, TODAY); 
INSERT INTO t1506programa (cod_pestana,cod_agrupacion,cod_sistema,cod_grupo,cod_programa, des_nombre,des_contexto, des_servlet,des_tags,des_opcion,fec_inivig, fec_finvig,hor_inicio,hor_fin,num_orden_pestana, num_orden_agrupa,num_orden_sistema,num_orden_grupo,num_orden_programa, ind_acceso,tip_invoca,ind_del,ind_visual,cod_usumodif,fec_modif)
VALUES  (11, 17, 4, 1, 1, 'Registro Comprobante de Retención', '/ol-ti-itcpretencioncon', '/emision/iniRegiCompCon', 'EmitirComprobantedeRetencion', 'Emitir Comprobante de Retención de Contingencia', to_date('2010-01-01','%Y-%m-%d'), to_date('2040-01-01','%Y-%m-%d'), to_date('00:00','%H:%M'), to_date('23:59','%H:%M'), 11, 17, 4, 1, 1, '1', '3', '2', '1', USER, TODAY); 
INSERT INTO t1506programa (cod_pestana,cod_agrupacion,cod_sistema,cod_grupo,cod_programa, des_nombre,des_contexto, des_servlet,des_tags,des_opcion,fec_inivig, fec_finvig,hor_inicio,hor_fin,num_orden_pestana, num_orden_agrupa,num_orden_sistema,num_orden_grupo,num_orden_programa, ind_acceso,tip_invoca,ind_del,ind_visual,cod_usumodif,fec_modif)
VALUES  (11, 17, 5, 1, 1, 'Baja documentos informados - contingencia', '/ol-ti-itconscpemypebaja', '/baja.do', 'Bajadocumentosinformadoscontingencia', 'Baja documentos informados - contingencia', to_date('2010-01-01','%Y-%m-%d'), to_date('2040-01-01','%Y-%m-%d'), to_date('00:00','%H:%M') , to_date('23:59','%H:%M'), 11, 17, 5, 1, 1, '1', '3', '2', '1', USER, TODAY);
--ingresar perfil programa
INSERT INTO t1507perfilprogram (cod_perfil,cod_pestana,cod_agrupacion, cod_sistema,cod_grupo,cod_programa,cod_usumodif,fec_modif) 
VALUES (14, 11, 17, 1, 1, 1, USER, CURRENT);
INSERT INTO t1507perfilprogram (cod_perfil,cod_pestana,cod_agrupacion, cod_sistema,cod_grupo,cod_programa,cod_usumodif,fec_modif) 
VALUES (14, 11, 17, 1, 1, 2, USER, CURRENT);
INSERT INTO t1507perfilprogram (cod_perfil,cod_pestana,cod_agrupacion, cod_sistema,cod_grupo,cod_programa,cod_usumodif,fec_modif) 
VALUES (14, 11, 17, 1, 1, 3, USER, CURRENT);
INSERT INTO t1507perfilprogram (cod_perfil,cod_pestana,cod_agrupacion, cod_sistema,cod_grupo,cod_programa,cod_usumodif,fec_modif) 
VALUES (14, 11, 17, 2, 1, 1, USER, CURRENT);
INSERT INTO t1507perfilprogram (cod_perfil,cod_pestana,cod_agrupacion, cod_sistema,cod_grupo,cod_programa,cod_usumodif,fec_modif) 
VALUES (14, 11, 17, 2, 1, 2, USER, CURRENT);
INSERT INTO t1507perfilprogram (cod_perfil,cod_pestana,cod_agrupacion, cod_sistema,cod_grupo,cod_programa,cod_usumodif,fec_modif) 
VALUES (14, 11, 17, 2, 1, 3, USER, CURRENT);
INSERT INTO t1507perfilprogram (cod_perfil,cod_pestana,cod_agrupacion, cod_sistema,cod_grupo,cod_programa,cod_usumodif,fec_modif) 
VALUES (14, 11, 17, 3, 1, 1, USER, CURRENT);
INSERT INTO t1507perfilprogram (cod_perfil,cod_pestana,cod_agrupacion, cod_sistema,cod_grupo,cod_programa,cod_usumodif,fec_modif) 
VALUES (14, 11, 17, 4, 1, 1, USER, CURRENT);
INSERT INTO t1507perfilprogram (cod_perfil,cod_pestana,cod_agrupacion, cod_sistema,cod_grupo,cod_programa,cod_usumodif,fec_modif) 
VALUES (14, 11, 17, 5, 1, 1, USER, CURRENT);