UPDATE t01param SET t01_funcion = 'CLIENT_ID                     23d35311-4d53-464c-96a9-6b140ee573de                                                                ' 
where t01_numero ='C01' AND t01_argumento='02';

UPDATE t01param SET t01_funcion = 'CLIENT_SECRET                 qp.p8]CEIB?5pe/IXhKq5JX77R6uXb=.                                                                    ' 
where t01_numero ='C01' AND t01_argumento='03';

UPDATE t01param SET t01_funcion = 'CLIENT_ID_OPERACIONES         bc19b3be-4d49-403e-910e-b202e339f5f2                                                                '  
where t01_numero ='C01' AND t01_argumento='04';

UPDATE t01param SET t01_funcion = 'CLIENT_SECRET_OPERACIONES     V4ff1pMiLO2p7ACeZPrmmq.kdynB[B:_                                                                    ' 
where t01_numero ='C01' AND t01_argumento='05';

UPDATE t01param SET t01_funcion='RESOURCE_URL_CPEFILES         http://api.sunat.peru/v1/contribuyente/cpe/portal/cloud/api/cpefiles                                '
where t01_numero ='C01' AND t01_argumento='06';

UPDATE t01param SET t01_funcion='RESOURCE_URL_OPERACIONES      http://api.sunat.peru/v1/contribuyente/cpe/portal/cloud/api/cpes/:cpeid                             '
where t01_numero ='C01' AND t01_argumento='08';