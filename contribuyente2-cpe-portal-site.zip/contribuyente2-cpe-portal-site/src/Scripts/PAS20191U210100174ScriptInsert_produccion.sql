INSERT INTO t01param(t01_numero, t01_tipo, t01_argumento, t01_funcion, t01_user, t01_factualiz, t01_hora)
VALUES('C01', 'D', '01', 'TOKEN_REQUEST_URL             http://api.sunat.peru/v1/contribuyente/cpe/portal/cloud/oauth2/token                                ', USER, SYSDATE, CAST(CURRENT AS DATETIME HOUR TO MINUTE));

INSERT INTO t01param(t01_numero, t01_tipo, t01_argumento, t01_funcion, t01_user, t01_factualiz, t01_hora)
VALUES('C01', 'D', '02', 'CLIENT_ID                     23d35311-4d53-464c-96a9-6b140ee573de                                                                ', USER, SYSDATE, CAST(CURRENT AS DATETIME HOUR TO MINUTE));

INSERT INTO t01param(t01_numero, t01_tipo, t01_argumento, t01_funcion, t01_user, t01_factualiz, t01_hora)
VALUES('C01', 'D', '03', 'CLIENT_SECRET                 qp.p8]CEIB?5pe/IXhKq5JX77R6uXb=.                                                                    ', USER, SYSDATE, CAST(CURRENT AS DATETIME HOUR TO MINUTE));

INSERT INTO t01param(t01_numero, t01_tipo, t01_argumento, t01_funcion, t01_user, t01_factualiz, t01_hora)
VALUES('C01', 'D', '04', 'CLIENT_ID_OPERACIONES         bc19b3be-4d49-403e-910e-b202e339f5f2                                                                ', USER, SYSDATE, CAST(CURRENT AS DATETIME HOUR TO MINUTE));

INSERT INTO t01param(t01_numero, t01_tipo, t01_argumento, t01_funcion, t01_user, t01_factualiz, t01_hora)
VALUES('C01', 'D', '05', 'CLIENT_SECRET_OPERACIONES     V4ff1pMiLO2p7ACeZPrmmq.kdynB[B:_                                                                    ', USER, SYSDATE, CAST(CURRENT AS DATETIME HOUR TO MINUTE));

INSERT INTO t01param(t01_numero, t01_tipo, t01_argumento, t01_funcion, t01_user, t01_factualiz, t01_hora)
VALUES('C01', 'D', '09', 'CLIENT_ID_QUERY_XML           224cd511-0d1f-44c2-9884-5e4b134d2842                                                                ', USER, SYSDATE, CAST(CURRENT AS DATETIME HOUR TO MINUTE));

INSERT INTO t01param(t01_numero, t01_tipo, t01_argumento, t01_funcion, t01_user, t01_factualiz, t01_hora)
VALUES('C01', 'D', '10', 'CLIENT_SECRET_QUERY_XML       dH@BE53[:2/ga13*oUPIRcqTSlA+.PWT                                                                    ', USER, SYSDATE, CAST(CURRENT AS DATETIME HOUR TO MINUTE));

INSERT INTO t01param(t01_numero, t01_tipo, t01_argumento, t01_funcion, t01_user, t01_factualiz, t01_hora)
VALUES('C01', 'D', '06', 'RESOURCE_URL_CPEFILES         http://api.sunat.peru/v1/contribuyente/cpe/portal/cloud/api/cpefiles                                ', USER, SYSDATE, CAST(CURRENT AS DATETIME HOUR TO MINUTE));

INSERT INTO t01param(t01_numero, t01_tipo, t01_argumento, t01_funcion, t01_user, t01_factualiz, t01_hora)
VALUES('C01', 'D', '08', 'RESOURCE_URL_OPERACIONES      http://api.sunat.peru/v1/contribuyente/cpe/portal/cloud/api/cpes/:cpeid                             ', USER, SYSDATE, CAST(CURRENT AS DATETIME HOUR TO MINUTE));

INSERT INTO t01param(t01_numero, t01_tipo, t01_argumento, t01_funcion, t01_user, t01_factualiz, t01_hora)
VALUES('C01', 'D', '11', 'RESOURCE_URL_QUERY_XML        http://api.sunat.peru/v1/contribuyente/cpe/portal/cloud/api/cpefiles/:cpeid                         ', USER, SYSDATE, CAST(CURRENT AS DATETIME HOUR TO MINUTE));

UPDATE t01param SET t01_funcion = 'CLIENT_ID                     23d35311-4d53-464c-96a9-6b140ee573de                                                                ' 
where t01_numero ='C01' AND t01_argumento='02';

UPDATE t01param SET t01_funcion = 'CLIENT_SECRET                 qp.p8]CEIB?5pe/IXhKq5JX77R6uXb=.                                                                    ' 
where t01_numero ='C01' AND t01_argumento='03';

UPDATE t01param SET t01_funcion = 'CLIENT_ID_OPERACIONES         bc19b3be-4d49-403e-910e-b202e339f5f2                                                                '  
where t01_numero ='C01' AND t01_argumento='04';

UPDATE t01param SET t01_funcion = 'CLIENT_SECRET_OPERACIONES     V4ff1pMiLO2p7ACeZPrmmq.kdynB[B:_                                                                    ' 
where t01_numero ='C01' AND t01_argumento='05';

UPDATE t01param SET t01_funcion = 'CLIENT_ID_QUERY_XML           224cd511-0d1f-44c2-9884-5e4b134d2842                                                                '  
where t01_numero ='C01' AND t01_argumento='09';

UPDATE t01param SET t01_funcion = 'CLIENT_SECRET_QUERY_XML       dH@BE53[:2/ga13*oUPIRcqTSlA+.PWT                                                                    ' 
where t01_numero ='C01' AND t01_argumento='10';

UPDATE t01param SET t01_funcion='RESOURCE_URL_CPEFILES         http://api.sunat.peru/v1/contribuyente/cpe/portal/cloud/api/cpefiles                                '
where t01_numero ='C01' AND t01_argumento='06';

UPDATE t01param SET t01_funcion='RESOURCE_URL_OPERACIONES      http://api.sunat.peru/v1/contribuyente/cpe/portal/cloud/api/cpes/:cpeid                             '
where t01_numero ='C01' AND t01_argumento='08';

UPDATE t01param SET t01_funcion='RESOURCE_URL_QUERY_XML        http://api.sunat.peru/v1/contribuyente/cpe/portal/cloud/api/cpefiles/:cpeid                         '
where t01_numero ='C01' AND t01_argumento='11';
