UPDATE t01param SET t01_funcion = 'CLIENT_ID                     77e5fc92-651e-4a57-9de9-d111abf3e045                                                                ' 
where t01_numero ='C01' AND t01_argumento='02';

UPDATE t01param SET t01_funcion = 'CLIENT_SECRET                 FtYiPegJeFJNj0lBkV2VqsMHaY29][=.                                                                    ' 
where t01_numero ='C01' AND t01_argumento='03';

UPDATE t01param SET t01_funcion = 'CLIENT_ID_OPERACIONES         a306ff8c-15fe-46e8-bdc0-d4027c2a5394                                                                '  
where t01_numero ='C01' AND t01_argumento='04';

UPDATE t01param SET t01_funcion = 'CLIENT_SECRET_OPERACIONES     .E@_Y2q9DnA:WTYcVvJU3UltMDVtl2l[                                                                    ' 
where t01_numero ='C01' AND t01_argumento='05';

UPDATE t01param SET t01_funcion='RESOURCE_URL_CPEFILES         http://api.sunat.peru/v1/contribuyente/cpe/portal/cloud/api/cpefiles                                '
where t01_numero ='C01' AND t01_argumento='06';

UPDATE t01param SET t01_funcion='RESOURCE_URL_OPERACIONES      http://api.sunat.peru/v1/contribuyente/cpe/portal/cloud/api/cpes/:cpeid                             '
where t01_numero ='C01' AND t01_argumento='08';
