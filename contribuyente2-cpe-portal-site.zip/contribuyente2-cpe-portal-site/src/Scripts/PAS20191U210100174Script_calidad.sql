UPDATE t01param SET t01_funcion = 'CLIENT_ID                     77e5fc92-651e-4a57-9de9-d111abf3e045                                                                ' 
where t01_numero ='C01' AND t01_argumento='02';
UPDATE t01param SET t01_funcion = 'CLIENT_SECRET                 FtYiPegJeFJNj0lBkV2VqsMHaY29][=.                                                                    ' 
where t01_numero ='C01' AND t01_argumento='03';
UPDATE t01param SET t01_funcion = 'CLIENT_ID_OPERACIONES         a306ff8c-15fe-46e8-bdc0-d4027c2a5394                                                                '  
where t01_numero ='C01' AND t01_argumento='04';
UPDATE t01param SET t01_funcion = 'CLIENT_SECRET_OPERACIONES     .E@_Y2q9DnA:WTYcVvJU3UltMDVtl2l[                                                                    ' 
where t01_numero ='C01' AND t01_argumento='05';
UPDATE t01param SET t01_funcion = 'CLIENT_ID_QUERY_XML           0fe899ed-b6b2-4577-8d96-060d54a534d7                                                                '  
where t01_numero ='C01' AND t01_argumento='09';
UPDATE t01param SET t01_funcion = 'CLIENT_SECRET_QUERY_XML       GL2v26kLThPY2Q/PwCnbR.UQ:GtgavV[                                                                    ' 
where t01_numero ='C01' AND t01_argumento='10';
UPDATE t01param SET t01_funcion='RESOURCE_URL_CPEFILES         http://api.sunat.peru/v1/contribuyente/cpe/portal/cloud/api/cpefiles                                '
where t01_numero ='C01' AND t01_argumento='06';
UPDATE t01param SET t01_funcion='RESOURCE_URL_OPERACIONES      http://api.sunat.peru/v1/contribuyente/cpe/portal/cloud/api/cpes/:cpeid                             '
where t01_numero ='C01' AND t01_argumento='08';
/*
UPDATE t01param SET t01_funcion='RESOURCE_URL_QUERY_XML        http://api.sunat.peru/v1/contribuyente/cpe/portal/cloud/api/cpefiles/:cpeid                         '
where t01_numero ='C01' AND t01_argumento='11';
*/
INSERT INTO t01param(t01_numero, t01_tipo, t01_argumento, t01_funcion, t01_user, t01_factualiz, t01_hora)
VALUES('C01', 'D', '11', 'RESOURCE_URL_QUERY_XML        http://api.sunat.peru/v1/contribuyente/cpe/portal/cloud/api/cpefiles/:cpeid                         ', USER, SYSDATE, CAST(CURRENT AS DATETIME HOUR TO MINUTE));
