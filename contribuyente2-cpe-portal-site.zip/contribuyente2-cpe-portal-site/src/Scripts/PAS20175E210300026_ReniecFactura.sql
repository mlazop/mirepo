unload to "t01paramsistema_PAS20175E210300026.txt" select * from t01param where t01_numero = "770" and t01_tipo= "D";

delete from t01param where t01_numero = "770" and t01_tipo= "D" and t01_argumento = "161510";

INSERT INTO t01param (t01_numero,t01_tipo,t01_argumento,t01_funcion,t01_user,t01_factualiz,t01_hora) VALUES ('770','D','161510','FACTURA ELECTRONICA                                                                                                       1       ','INSI','01-01-2017','00:00');