package pe.gob.sunat.contribuyentems.servicio.consultacpe.consulta.retper.ws.rest;
import static javax.ws.rs.core.MediaType.APPLICATION_JSON;

import pe.gob.sunat.contribuyentems.servicio.consultacpe.consulta.retper.services.ComprobanteService;
import pe.gob.sunat.contribuyentems.servicio.consultacpe.consulta.retper.util.Constantes;
import pe.gob.sunat.contribuyentems.servicio.consultacpe.consulta.retper.util.exceptions.ErrorEnum;
import pe.gob.sunat.contribuyentems.servicio.consultacpe.consulta.retper.util.exceptions.ErrorMessage;
import pe.gob.sunat.contribuyentems.servicio.consultacpe.consulta.retper.util.exceptions.UnprocessableEntityException;
import pe.gob.sunat.contribuyentems.servicio.consultacpe.consulta.retper.ws.dto.ArchivoRequestDTO;
import pe.gob.sunat.contribuyentems.servicio.consultacpe.consulta.retper.ws.dto.ArchivoResponseDTO;
import pe.gob.sunat.contribuyentems.servicio.consultacpe.consulta.retper.ws.dto.ComprobanteIndividualRequestDTO;
import pe.gob.sunat.contribuyentems.servicio.consultacpe.consulta.retper.ws.dto.ComprobanteMasivaRequestDTO;
import pe.gob.sunat.tecnologiams.arquitectura.framework.core.util.UtilLog;

import javax.inject.Inject;
import javax.ws.rs.*;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;
import java.nio.charset.StandardCharsets;
import java.util.Objects;
@Consumes(MediaType.APPLICATION_JSON)
@Produces(APPLICATION_JSON + ";charset=utf-8")
@Path("/v1/contribuyente/consultacpe")
public class ComprobanteRestService {
    @Inject
    private UtilLog utilLog;
    @Inject
    private ComprobanteService comprobanteService;

    @GET
    @Path(value = "/e/comprobantes/retper/{numRucEmisor}-{codCpe}-{numSerie}-{numCpe}-{codFiltroCpe}")
    @Produces(MediaType.APPLICATION_JSON)
    public Response obtenerComprobantes(
            @HeaderParam("numRuc") String numRucHeader,
            @PathParam("numRucEmisor") String numRuc,
            @PathParam("codCpe") String codCpe,
            @PathParam("numSerie") String numSerie,
            @PathParam("numCpe") Long numCpe,
            @PathParam("codFiltroCpe") String codFiltroCpe
    ) throws Exception {

        ComprobanteIndividualRequestDTO requestDTO = new ComprobanteIndividualRequestDTO.Builder()
                .setNumRucHeader(numRucHeader)
                .setNumRuc(numRuc)
                .setCodCpe(codCpe)
                .setNumSerie(numSerie)
                .setNumCpe(numCpe)
                .setCodFiltroCpe(codFiltroCpe)
                .build();
        return Response.ok(comprobanteService.obtenerComprobanteIndividual(requestDTO))
                .type(MediaType.APPLICATION_JSON_TYPE.withCharset(StandardCharsets.UTF_8.name())).build();

    }
    
    @GET
    @Path(value = "/e/comprobantes/retper/{numRucEmisor:.*}-{codCpe}-{codFiltroCpe}")
    @Produces(MediaType.APPLICATION_JSON)
    public Response obtenerComprobantesMasiva(
            @HeaderParam("numRuc") String numRucHeader,
            @PathParam("numRucEmisor") String numRuc,
            @PathParam("codCpe") String codCpe,
            @PathParam("codFiltroCpe") String codFiltroCpe,
            @QueryParam("numSerieCpe") String numSerieCpe,
            @QueryParam("numCpeInicio") String numCpeInicio,
            @QueryParam("numCpeFin") String numCpeFin,
            @QueryParam("codEstado") String codEstado,
            @QueryParam("codDocIde") String codDocIde,
            @QueryParam("numDocIde") String numDocIde,
            @QueryParam("fecEmisionIni") String fecEmisionIni,
            @QueryParam("fecEmisionFin") String fecEmisionFin
    ) throws Exception {

        ComprobanteMasivaRequestDTO requestDTO = new ComprobanteMasivaRequestDTO.Builder()
                .setNumRucHeader(numRucHeader)
                .setNumRucEmisor(numRuc)
                .setCodCpe(codCpe)
                .setCodFiltroCpe(codFiltroCpe)
                .setNumSerieCpe(numSerieCpe)
                .setNumCpeIni(Objects.isNull(numCpeInicio)||numCpeInicio.equals("") ?  0:Integer.parseInt(numCpeInicio))
                .setNumCpeFin(Objects.isNull(numCpeFin)||numCpeFin.equals("") ?  0:Integer.parseInt(numCpeFin))
                .setCodEstado(codEstado)
                .setCodDocIde(codDocIde)
                .setNumDocIde(numDocIde)
                .setFecEmisionIni(fecEmisionIni)
                .setFecEmisionFin(fecEmisionFin)
                .build();
        return Response.ok(comprobanteService.obtenerComprobanteMasiva(requestDTO))
                .type(MediaType.APPLICATION_JSON_TYPE.withCharset(StandardCharsets.UTF_8.name())).build();

    }
    @GET
    @Path(value = "/e/comprobantes/retper/{numRucEmisor}-{codCpe}-{numSerie}-{numCpe}-{codFiltroCpe}/{codTipDes}")
    @Produces(MediaType.APPLICATION_JSON)
    @Consumes({MediaType.APPLICATION_JSON})
    public Response descargaComprobante(
            @HeaderParam("numRuc") String numRucHeader,
            @PathParam("numRucEmisor") String numRuc,
            @PathParam("codCpe") String codCpe,
            @PathParam("numSerie") String numSerie,
            @PathParam("numCpe") Long numCpe,
            @PathParam("codFiltroCpe") String codFiltroCpe,
            @PathParam("codTipDes") String codTipDes

    ) throws Exception {
        ArchivoRequestDTO requestDTO = new ArchivoRequestDTO.Builder()
                .setNumRucHeader(numRucHeader)
                .setNumRucEmisor(numRuc)
                .setCodCpe(codCpe)
                .setCodFiltroCpe(codFiltroCpe)
                .setNumSerieCpe(numSerie)
                .setNumCpe(numCpe)
                .setCodFiltroCpe(codFiltroCpe)
                .setCodTipDes(codTipDes)
                .build();
        ArchivoResponseDTO archivoResponseDTO=new ArchivoResponseDTO();
        if (Objects.isNull(requestDTO)) {
            throw new UnprocessableEntityException(new ErrorMessage(ErrorEnum.ERROR_146));
        }
        
        ComprobanteIndividualRequestDTO request = new ComprobanteIndividualRequestDTO.Builder()
                .setNumRucHeader(numRucHeader)
                .setNumRuc(numRuc)
                .setCodCpe(codCpe)
                .setNumSerie(numSerie)
                .setNumCpe(numCpe)
                .setCodFiltroCpe(codFiltroCpe)
                .build();

            archivoResponseDTO = comprobanteService.descargarComprobante(requestDTO,request);

        return Response.ok((archivoResponseDTO))
                .type(MediaType.APPLICATION_JSON_TYPE.withCharset(StandardCharsets.UTF_8.name())).build();

    }    
}



package pe.gob.sunat.contribuyentems.servicio.consultacpe.consulta.retper.services.impl;


import pe.gob.sunat.contribuyentems.servicio.consultacpe.consulta.retper.basebdconsultacpe.domain.dao.repository.GranContribuyenteRepository;
import pe.gob.sunat.contribuyentems.servicio.consultacpe.consulta.retper.basebdparametros.domain.Contribuyentes;
import pe.gob.sunat.contribuyentems.servicio.consultacpe.consulta.retper.basebdparametros.domain.UbigeoContribuyente;
import pe.gob.sunat.contribuyentems.servicio.consultacpe.consulta.retper.basebdparametros.domain.dao.ContribuyenteRepository;
import pe.gob.sunat.contribuyentems.servicio.consultacpe.consulta.retper.domain.*;
import pe.gob.sunat.contribuyentems.servicio.consultacpe.consulta.retper.main.config.PropertiesBean;

import org.apache.commons.io.FileUtils;
import org.apache.commons.lang3.StringUtils;

import net.sf.jasperreports.engine.JasperFillManager;
import net.sf.jasperreports.engine.JasperPrint;
import pe.gob.sunat.contribuyentems.servicio.consultacpe.consulta.retper.repository.ComprobantesRepository;
import pe.gob.sunat.contribuyentems.servicio.consultacpe.consulta.retper.services.ComprobanteService;
import pe.gob.sunat.contribuyentems.servicio.consultacpe.consulta.retper.util.Constantes;
import pe.gob.sunat.contribuyentems.servicio.consultacpe.consulta.retper.util.ValidatorParams;
import pe.gob.sunat.contribuyentems.servicio.consultacpe.consulta.retper.util.exceptions.ErrorEnum;
import pe.gob.sunat.contribuyentems.servicio.consultacpe.consulta.retper.util.exceptions.ErrorMessage;
import pe.gob.sunat.contribuyentems.servicio.consultacpe.consulta.retper.util.exceptions.UnprocessableEntityException;
import pe.gob.sunat.contribuyentems.servicio.consultacpe.consulta.retper.ws.dto.ArchivoRequestDTO;
import pe.gob.sunat.contribuyentems.servicio.consultacpe.consulta.retper.ws.dto.ArchivoResponseDTO;
import pe.gob.sunat.contribuyentems.servicio.consultacpe.consulta.retper.ws.dto.ComprobanteIndividualRequestDTO;
import pe.gob.sunat.contribuyentems.servicio.consultacpe.consulta.retper.ws.dto.ComprobanteIndividualResponseDTO;
import pe.gob.sunat.contribuyentems.servicio.consultacpe.consulta.retper.ws.dto.ComprobanteMasivaRequestDTO;
import pe.gob.sunat.contribuyentems.servicio.consultacpe.consulta.retper.ws.dto.ComprobanteMasivaResponseDTO;
import pe.gob.sunat.contribuyentems.servicio.consultacpe.consulta.retper.ws.dto.ResumenDTO;
import pe.gob.sunat.tecnologiams.arquitectura.framework.common.util.ConstantesUtils;
import pe.gob.sunat.tecnologiams.arquitectura.framework.core.util.UtilLog;

import javax.inject.Inject;
import javax.servlet.http.HttpServletRequest;
import javax.ws.rs.core.StreamingOutput;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.stream.Collectors;
import java.util.zip.ZipEntry;
import java.util.zip.ZipOutputStream;

import net.sf.jasperreports.engine.JRException;
import net.sf.jasperreports.engine.JRExporterParameter;
import net.sf.jasperreports.engine.data.JRBeanCollectionDataSource;
import net.sf.jasperreports.engine.export.JRPdfExporter;
import pe.gob.sunat.contribuyentems.servicio.consultacpe.consulta.retper.basebdconsultacpe.domain.Contribuyente;
import pe.gob.sunat.contribuyentems.servicio.consultacpe.consulta.retper.basebdconsultacpe.domain.DocRelacionadoRet;
import pe.gob.sunat.contribuyentems.servicio.consultacpe.consulta.retper.basebdconsultacpe.domain.PkComprobante;
import pe.gob.sunat.contribuyentems.servicio.consultacpe.consulta.retper.basebdconsultacpe.domain.Retencion;
import pe.gob.sunat.contribuyentems.servicio.consultacpe.consulta.retper.basebdconsultacpe.domain.Ubigeo;
import pe.gob.sunat.contribuyentems.servicio.consultacpe.consulta.retper.basebdconsultacpe.domain.Percepcion;
import pe.gob.sunat.contribuyentems.servicio.consultacpe.consulta.retper.basebdconsultacpe.domain.DocRelacionadoPer;
import pe.gob.sunat.contribuyentems.servicio.consultacpe.consulta.retper.util.Utils;

public class ComprobanteServiceImpl implements ComprobanteService {
    @Inject
    private UtilLog utilLog;
    @Inject
    private ValidatorParams validatorParams;
    @Inject
    private ComprobantesRepository comprobantesRepository;
    @Inject
    private GranContribuyenteRepository granContribuyenteRepository;
    @Inject
    private ContribuyenteRepository contribuyenteRepository;
	@Inject
	private PropertiesBean properties;
    @Override
    public ComprobanteIndividualResponseDTO obtenerComprobanteIndividual(ComprobanteIndividualRequestDTO request)
            throws Exception {

        utilLog.imprimirLog(ConstantesUtils.LEVEL_DEBUG,
                "==== INICIO ---> ComprobanteService - metodo: obtenerComprobanteIndividual  1 =====");

        validatorParams.checkNumRuc(request.getNumRucHeader());
        validatorParams.checkNumRucEmisor(request.getNumRucEmisor(),request.getNumRucHeader(),request.getCodFiltroCpe());
        validatorParams.checkCodCpe(request.getCodCpe());
        validatorParams.checkNumeroSerieCpe(request.getNumSerieCpe(),request.getCodFiltroCpe());
        validatorParams.checkNumCpe(request.getCodCpe(),request.getNumSerieCpe(),request.getCodFiltroCpe());
        validatorParams.checkCodFiltroCpe(request.getCodFiltroCpe());
		Date fechaemision = comprobantesRepository.obtenerFechaEmision(request);
		if (Objects.nonNull(fechaemision)) {
			validatorParams.checkFechaEmisionIndividual(fechaemision, properties.getCntMesesIndividual());
		} else {
			throw new UnprocessableEntityException(new ErrorMessage(ErrorEnum.ERROR_113));
		}
        List<Comprobantes> listaComprobantes = comprobantesRepository.obtenerComprobanteIndividual(request);

        if (Objects.isNull(listaComprobantes) || listaComprobantes.size() == 0) {
            throw new UnprocessableEntityException(new ErrorMessage(ErrorEnum.ERROR_113));
        }
        utilLog.imprimirLog(ConstantesUtils.LEVEL_DEBUG,
                "==== INICIO ---> ComprobanteService - metodo: obtenerComprobanteIndividual  3 =====");

        ComprobanteIndividualResponseDTO response = new ComprobanteIndividualResponseDTO();
        response.setCntTotalReg(listaComprobantes.size());
        response.setNumeroPaginas(properties.getNumeroPaginas());
        response.setComprobantes(listaComprobantes);

        return  response;
            }
    
    @Override
    public ComprobanteMasivaResponseDTO obtenerComprobanteMasiva(ComprobanteMasivaRequestDTO request) throws Exception {
        validatorParams.checkNumRuc(request.getNumRucHeader());
        validatorParams.checkCodFiltroCpe(request.getCodFiltroCpe());
        if(request.getCodFiltroCpe().equals(Constantes.COD_CPE_EMISOR)){
            if (!Objects.isNull(request.getNumRucEmisor()) && !request.getNumRucEmisor().isEmpty()) {
                validatorParams.checkNumRucEmisor(request.getNumRucEmisor(), request.getNumRucHeader(), request.getCodFiltroCpe());
              }
            boolean granemisor = granContribuyenteRepository.validarContribuyente(request.getNumRucHeader(),
                    request.getCodCpe(), Constantes.COD_CPE_EMISOR);
            boolean granreceptor = granContribuyenteRepository.validarContribuyente(request.getNumRucHeader(),
                    request.getCodCpe(), Constantes.COD_CPE_RECEPTOR);
            validatorParams.checkCodCpe(request.getCodCpe());
            //validatorParams.checkNumeroSerieCpeMasiva(request.getNumSerieCpe(), request.getCodFiltroCpe(),granemisor);

            validatorParams.checkNumCpeIniMasiva(request.getNumCpeIni(), request.getCodFiltroCpe(),granemisor);
            validatorParams.checkNumCpeFinMasiva(request.getNumCpeFin(), request.getNumCpeIni(), request.getCodFiltroCpe(),granemisor,Integer.parseInt(properties.getParamLimitInformix()));

            if (!Objects.isNull(request.getCodEstado())) {
                validatorParams.checkCodEstado(request.getCodEstado());
            }
            if (!Objects.isNull(request.getCodDocIde())) {
                validatorParams.checkCodDocIdeRecep(request.getCodDocIde());

            }
            if (!Objects.isNull(request.getNumDocIde())) {
                validatorParams.checkNumDocIdeRecep(request.getNumDocIde());

            }


            validatorParams.checkFechaEmision(request.getFecEmisionIni(), request.getFecEmisionFin(), request.getCodFiltroCpe(),
                    granemisor, granreceptor);

            int meses=properties.getCntMesesMasiva();
            if(Objects.nonNull(request.getFecEmisionIni())){
                validatorParams.checkFechaEmisionMasiva(request.getFecEmisionIni(),meses);

            }


        }else if(request.getCodFiltroCpe().equals(Constantes.COD_CPE_RECEPTOR)) {
            if (!Objects.isNull(request.getNumRucEmisor()) && !request.getNumRucEmisor().isEmpty()) {
                validatorParams.checkNumRucEmisor(request.getNumRucEmisor(), request.getNumRucHeader(), request.getCodFiltroCpe());
            }
            validatorParams.checkCodEstado(request.getCodEstado());

            if (!Objects.isNull(request.getCodDocIde())) {
                validatorParams.checkCodDocIdeRecep(request.getCodDocIde());
            }
            if (!Objects.isNull(request.getNumDocIde())) {
                validatorParams.checkNumDocIdeRecep(request.getNumDocIde());
            }
            String numRucEmisor = request.getNumRucEmisor();

            boolean granemisor = granContribuyenteRepository.validarContribuyente(numRucEmisor,
                    request.getCodCpe(), Constantes.COD_CPE_EMISOR);
            boolean granreceptor = granContribuyenteRepository.validarContribuyente(numRucEmisor,
                    request.getCodCpe(), Constantes.COD_CPE_RECEPTOR);
            validatorParams.checkFechaEmision(request.getFecEmisionIni(), request.getFecEmisionFin(), request.getCodFiltroCpe(),
                    granemisor, granreceptor);
            int meses=properties.getCntMesesMasiva();
            if(Objects.nonNull(request.getFecEmisionIni())){
                validatorParams.checkFechaEmisionMasiva(request.getFecEmisionIni(),meses);

            }

        }


        validatorParams.checkCodFiltroCpe(request.getCodFiltroCpe());
        List<Comprobantes> comprobanteDTOList=new ArrayList<>();
        List<Comprobantes> listaComprobantes = comprobantesRepository.obtenerComprobanteMasiva(request);
        if (Objects.isNull(listaComprobantes) || listaComprobantes.size() == 0) {
            throw new UnprocessableEntityException(new ErrorMessage(ErrorEnum.ERROR_113));
        }else {
            for (Comprobantes comprobante : listaComprobantes) {
                comprobanteDTOList.add(comprobante);
            }
        }

        utilLog.imprimirLog(ConstantesUtils.LEVEL_DEBUG,
                "==== INICIO ---> ComprobanteService - metodo: obtenerComprobanteIndividual  3 =====");
        ComprobanteMasivaResponseDTO response = new ComprobanteMasivaResponseDTO();
        response.setCntTotalReg(listaComprobantes.size());
        response.setNumeroPaginas(properties.getNumeroPaginas());
        response.setComprobantes(comprobanteDTOList);
        response.setResumen(obtenerResumen(comprobanteDTOList));
        return response;
    }
    
    @Override
    public ArchivoResponseDTO descargarComprobante(ArchivoRequestDTO archivoRequestDTO, ComprobanteIndividualRequestDTO request) throws Exception {
        UnprocessableEntityException exception = new UnprocessableEntityException();

        validatorParams.checkNumRuc(archivoRequestDTO.getNumRucHeader());
        validatorParams.checkNumRucEmisor(archivoRequestDTO.getNumRucEmisor(),archivoRequestDTO.getNumRucHeader(),archivoRequestDTO.getCodFiltroCpe());
        validatorParams.checkCodCpe(archivoRequestDTO.getCodCpe());
        validatorParams.checkNumeroSerieCpe(archivoRequestDTO.getNumSerieCpe(),archivoRequestDTO.getCodFiltroCpe());
        validatorParams.checkNumCpe(archivoRequestDTO.getCodCpe(),archivoRequestDTO.getNumSerieCpe(),archivoRequestDTO.getCodFiltroCpe());
        validatorParams.checkCodTipDes(!Objects.isNull(archivoRequestDTO.getCodTipDes())? archivoRequestDTO.getCodTipDes():StringUtils.EMPTY );
        validatorParams.checkCodFiltroCpe(request.getCodFiltroCpe());
//		Date fechaemision = comprobantesRepository.obtenerFechaEmision(request);
//		if (Objects.nonNull(fechaemision)) {
//			validatorParams.checkFechaEmisionIndividual(fechaemision, properties.getCntMesesIndividual());
//		} else {
//			throw new UnprocessableEntityException(new ErrorMessage(ErrorEnum.ERROR_113));
//		}
        List<Comprobantes> listaComprobantes = comprobantesRepository.obtenerComprobanteIndividual(request);

        if (Objects.isNull(listaComprobantes) || listaComprobantes.size() == 0) {
            throw new UnprocessableEntityException(new ErrorMessage(ErrorEnum.ERROR_113));
        }
        
        ArchivoResponseDTO archivoResponseDTO=new ArchivoResponseDTO();
        StreamingOutput streamingOutput = null;
        
        if(archivoRequestDTO.getCodTipDes().equals(Constantes.COD_DESCARGA_PDF)) {

        	return descargarPDF(archivoRequestDTO, request);

        }
        
        
            File file = comprobantesRepository.recuperaComprobanteService(archivoRequestDTO.getNumRucEmisor(), archivoRequestDTO.getNumCpe().toString(),
            		archivoRequestDTO.getCodCpe(), archivoRequestDTO.getNumSerieCpe(), archivoRequestDTO.getCodTipDes(), archivoRequestDTO.getCodFiltroCpe(), archivoRequestDTO.getNumRucHeader());
            
            if (file == null) {
                exception.addError(true, "113", ErrorEnum.ERROR_113.getMsg());
                throw exception;
            }
            
            streamingOutput = ZipFile(file);
            archivoResponseDTO.setValArchivo(convertToByte(streamingOutput));
            
            String tipoCp = archivoRequestDTO.getCodTipDes().equals(Constantes.COD_DESCARGA_XML) ? "XML" : "CDR";
        	
        String nombreArchivo = archivoRequestDTO.getNumRucEmisor() +
        		"-"+archivoRequestDTO.getCodCpe()+
        		"-"+archivoRequestDTO.getNumSerieCpe()+
        		"-"+archivoRequestDTO.getNumCpe()+"-" +tipoCp +".zip";

        archivoResponseDTO.setNomArchivo(nombreArchivo);

        return archivoResponseDTO;
    }    
    
    public ArchivoResponseDTO descargarPDF(ArchivoRequestDTO archivoRequestDTO, ComprobanteIndividualRequestDTO request) throws Exception{
    	
        StreamingOutput streamingOutput =  output ->  {
            try {
                List<Comprobantes> listaComprobantes = comprobantesRepository.obtenerComprobanteIndividual(request);
//                Map<String, Object> param = obtenerParametroPDF(listaComprobantes, obtenerUbigeo(archivoRequestDTO.getNumRucEmisor()));
                Retencion param=new Retencion();
                Percepcion paramPer=new Percepcion();
                Collection<Retencion> listRetencion = new ArrayList<Retencion>();
                Collection<Percepcion> listPercepcion = new ArrayList<Percepcion>();
                if(request.getCodCpe().equals(Constantes.COD_CPE_PERCEPCION)) {
                paramPer = obtenerParametroPercepcionBean(listaComprobantes, obtenerUbigeo(archivoRequestDTO.getNumRucEmisor()), obtenerUbigeo(archivoRequestDTO.getNumRucEmisor()));
		listPercepcion.add(paramPer);
                }
                if(request.getCodCpe().equals(Constantes.COD_CPE_RETENCION)) {
                param = obtenerParametroBean(listaComprobantes, obtenerUbigeo(archivoRequestDTO.getNumRucEmisor()), obtenerUbigeo(archivoRequestDTO.getNumRucEmisor()));
		listRetencion.add(param);
                }

                InputStream jasperStream = null;
                byte[] pdfBytes = null;
                
                if(request.getCodCpe().equals(Constantes.COD_CPE_PERCEPCION)) {
                jasperStream = getClass().getResourceAsStream("/reports/percepcion/percepcion_report_portal.jasper");
                        Map<String, Object> paramData = new HashMap<String, Object>();

                        paramData.put("net.sf.jasperreports.engine.export.JRPdfExporterParameter.METADATA_AUTHOR", "sunat.gob.pe");
                        paramData.put("net.sf.jasperreports.engine.export.JRPdfExporterParameter.METADATA_CREATOR", "SUNAT Java GenDoc derechos reservados");
                        paramData.put("net.sf.jasperreports.engine.export.JRPdfExporterParameter.INPUT_FILE_NAME", jasperStream);
                        paramData.put("SUBREPORT_DIR", "reports/percepcion/");
                        try {
                                if(listPercepcion == null) {
                                        listPercepcion = new ArrayList<Percepcion>();
                                }
                                JasperPrint print = JasperFillManager.fillReport(jasperStream, paramData, 
                                		new JRBeanCollectionDataSource(listPercepcion));

                                ByteArrayOutputStream outputStream = new ByteArrayOutputStream();
                                JRPdfExporter exporter = new JRPdfExporter();
                                exporter.setParameter(JRExporterParameter.JASPER_PRINT, print);
                            exporter.setParameter(JRExporterParameter.OUTPUT_STREAM, outputStream);
                                exporter.exportReport();
                                pdfBytes = outputStream.toByteArray();
                        } catch (JRException e) {
                                throw new RuntimeException("ocurrio un error al crear el pdf",e);
                        }
                }
                if(request.getCodCpe().equals(Constantes.COD_CPE_RETENCION)) {
                        jasperStream = getClass().getResourceAsStream("/reports/retencion/retencion_report_portal.jasper");
                        Map<String, Object> paramData = new HashMap<String, Object>();

                        paramData.put("net.sf.jasperreports.engine.export.JRPdfExporterParameter.METADATA_AUTHOR", "sunat.gob.pe");
                        paramData.put("net.sf.jasperreports.engine.export.JRPdfExporterParameter.METADATA_CREATOR", "SUNAT Java GenDoc derechos reservados");
                        paramData.put("net.sf.jasperreports.engine.export.JRPdfExporterParameter.INPUT_FILE_NAME", jasperStream);
                        paramData.put("SUBREPORT_DIR", "reports/retencion/");
                        try {
                                if(listRetencion == null) {
                                        listRetencion = new ArrayList<Retencion>();
                                }
                                JasperPrint print = JasperFillManager.fillReport(jasperStream, paramData, new JRBeanCollectionDataSource(listRetencion));

                                ByteArrayOutputStream outputStream = new ByteArrayOutputStream();
                                JRPdfExporter exporter = new JRPdfExporter();
                                exporter.setParameter(JRExporterParameter.JASPER_PRINT, print);
                            exporter.setParameter(JRExporterParameter.OUTPUT_STREAM, outputStream);
                                exporter.exportReport();
                                pdfBytes = outputStream.toByteArray();
                        } catch (JRException e) {
                                throw new RuntimeException("ocurrio un error al crear el pdf",e);
                        }
                        }

                output.write(pdfBytes);
                output.flush();
                output.close();
                jasperStream.close();

            } catch (Exception e) {
                utilLog.generarLogException((HttpServletRequest) null,
                        "ComprobanteServiceImpl.descargarPdf - Exception " + e.getMessage(), e);
                // throw new WebApplicationException(e);
            }
        };  
        
        ArchivoResponseDTO archivoResponseDTO=new ArchivoResponseDTO();
    
	    String nombreArchivo = archivoRequestDTO.getNumRucEmisor() +
	    		"-"+archivoRequestDTO.getCodCpe()+
	    		"-"+archivoRequestDTO.getNumSerieCpe()+
	    		"-"+archivoRequestDTO.getNumCpe()+"-PDF" +".zip";
	    
	    String nombreArchivoPdf = archivoRequestDTO.getNumRucEmisor() +
	    		"-"+archivoRequestDTO.getCodCpe()+
	    		"-"+archivoRequestDTO.getNumSerieCpe()+
	    		"-"+archivoRequestDTO.getNumCpe()+".pdf";
	    File newFilePdf = new File(nombreArchivoPdf);
        FileUtils.writeByteArrayToFile(newFilePdf,convertToByte(streamingOutput));
        StreamingOutput outputzip=ZipFile(newFilePdf);
        archivoResponseDTO.setNomArchivo(nombreArchivo);
        archivoResponseDTO.setValArchivo(convertToByte(outputzip));
        
        return archivoResponseDTO;
    }
    
    public Map<String, Object> obtenerParametroPDF(List<Comprobantes> lstCp, UbigeoContribuyente ubigeo) {
        Map<String, Object> param = new HashMap<>();

        for (Comprobantes comprobante : lstCp) {
            param.put("ruc", comprobante.getDatosEmisor().getNumRuc());
            param.put("numeroComprobante",String.valueOf(comprobante.getNumCpe()));
            param.put("serieComprobante", comprobante.getNumSerie());
            param.put("razonSocialEmisor",  String.valueOf(comprobante.getDatosEmisor().getDesRazonSocialEmis()));
            param.put("numDireccionEmisor",  String.valueOf(comprobante.getDatosEmisor().getDesDirEmis()));
            param.put("urbanizacionEmisor",  String.valueOf(ubigeo.getDesNomZon()));
            param.put("departamentoEmisor",  String.valueOf(ubigeo.getDesDepartamento()));
            param.put("provinciaEmisor",  String.valueOf(ubigeo.getDesProvincia()));
            param.put("distritoEmisor",  String.valueOf(ubigeo.getDesDistrito()));
            param.put("fechaEmision",  String.valueOf(comprobante.getFecEmision()));
            param.put("nombreCliente",  String.valueOf(comprobante.getDatosReceptor().getDesRazonSocialRecep()));
            param.put("rucReceptor",  String.valueOf(comprobante.getDatosReceptor().getNumDocIdeRecep()));
            //param.put("DireccionCliente",  String.valueOf(comprobante.getDatosReceptor().get()));
            param.put("tipoDocumentoReceptor",  String.valueOf(comprobante.getDatosReceptor().getCodDocIdeRecep()));
            param.put("numDocumentoReceptor",  String.valueOf(comprobante.getDatosReceptor().getNumDocIdeRecep()));
            
            //detalle
            //param.put("numDocumentoReceptor",  String.valueOf(comprobante.getInformacionItems()));
            //param.put("Observacion",  String.valueOf(comprobante.getDatosReceptor().getDesObservacion()));

        }
        return param;
    }    
    
    private UbigeoContribuyente obtenerUbigeo(String numRuc){
        //String desRazonSocialEmis = "";
        UbigeoContribuyente ubigeo = new UbigeoContribuyente();
        
        try{
            Contribuyentes contribuyente = contribuyenteRepository.obtenerContribuyente(numRuc.trim());
            if(contribuyente != null){
                //desRazonSocialEmis = contribuyente.getUbigeo().getDesNomZon();
            	ubigeo.setCodUbigeo(contribuyente.getUbigeo().getCodUbigeo());
            	ubigeo.setDesNumer1(contribuyente.getUbigeo().getDesNumer1());
            	ubigeo.setCodTipvia(contribuyente.getUbigeo().getCodTipvia());
            	ubigeo.setDesNomVia(contribuyente.getUbigeo().getDesNomVia());
            	ubigeo.setDesNomZon(contribuyente.getUbigeo().getDesNomZon());
            	ubigeo.setDesDepartamento(contribuyente.getUbigeo().getDesDepartamento());
            	ubigeo.setDesProvincia(contribuyente.getUbigeo().getDesProvincia());
            	ubigeo.setDesDistrito(contribuyente.getUbigeo().getDesDistrito());
                
            }
        }catch(Exception ex){
            utilLog.imprimirLog(ConstantesUtils.LEVEL_DEBUG, ex.getMessage());
        }
        return ubigeo;
    }
    
    public  StreamingOutput ZipFile(File file){

        StreamingOutput streamingOutput = output -> {

            try {
                byte[] buffer = new byte[1024];

                ZipOutputStream zos = new ZipOutputStream(output);

                addFileContentToZipOutputStream(buffer, zos, file);

                zos.close();

                FileUtils.forceDelete(file);
            } catch (Exception e) {
                utilLog.generarLogException((HttpServletRequest) null,
                        "XmlComprobanteServiceImpl.descargarReciboPorHonorario - Exception " + e.getMessage(), e);
                // throw new WebApplicationException(e);
            }
        };
        return  streamingOutput;
    }    
    
    private void addFileContentToZipOutputStream(byte[] buffer, ZipOutputStream zos, File file) throws IOException {
        // add the first file to the zip
        ZipEntry zipEntry = new ZipEntry(file.getName());
        zos.putNextEntry(zipEntry);
        FileInputStream fis = new FileInputStream(file);

        int len;
        while ((len = fis.read(buffer)) > 0) {
            zos.write(buffer, 0, len);
        }

        fis.close();
        zos.closeEntry();
    } 
    public static   byte[] convertToByte(StreamingOutput streamingOutput) throws IOException {
        ByteArrayOutputStream outputStream = new ByteArrayOutputStream();
        try {
            streamingOutput.write(outputStream);
        } catch (IOException e) {
            
        }
        byte[] data = outputStream.toByteArray();

        return data;
    }    
    
    public Retencion obtenerParametroBean(List<Comprobantes> lstCp, UbigeoContribuyente ubigeoEmi,UbigeoContribuyente ubigeoRecep) {
            
        DateFormat fmt = new SimpleDateFormat("yyyy-MM-dd");
			
	//Construyendo el Obteto model Retencion  - PDF
        Retencion retencionModel = new Retencion();


        for (Comprobantes comprobante : lstCp) {
           
            Contribuyente emisor=new Contribuyente();
            Contribuyente receptor=new Contribuyente();
            PkComprobante pkComprobante = new PkComprobante(comprobante.getDatosEmisor().getNumRuc(), comprobante.getCodCpe(), comprobante.getNumSerie(), comprobante.getNumCpe());

            Ubigeo ubigeoEmisor = new Ubigeo();
            ubigeoEmisor.setCodUbigeo(Objects.nonNull(ubigeoEmi.getCodUbigeo()) ? 
            		ubigeoEmi.getCodUbigeo() : Constantes.DEFAULT_FIELD);
			ubigeoEmisor.setDireccion(Objects.nonNull(ubigeoEmi.getDesNomVia())? 
					obtenerTipoVia(ubigeoEmi.getCodTipvia()) +" " + ubigeoEmi.getDesNomVia() : Constantes.DEFAULT_FIELD);
			ubigeoEmisor.setUrbanizacion(Objects.nonNull(ubigeoEmi.getDesNomZon())?
					ubigeoEmi.getDesNumer1()+" "+ubigeoEmi.getDesNomZon() : Constantes.DEFAULT_FIELD);
			ubigeoEmisor.setProvincia(Objects.nonNull(ubigeoEmi.getDesProvincia())? 
					ubigeoEmi.getDesProvincia() : Constantes.DEFAULT_FIELD);
			ubigeoEmisor.setDepartamento(Objects.nonNull(ubigeoEmi.getDesDepartamento())?
					ubigeoEmi.getDesDepartamento() : Constantes.DEFAULT_FIELD);
			ubigeoEmisor.setDistrito(Objects.nonNull(ubigeoEmi.getDesDistrito())? 
					ubigeoEmi.getDesDistrito() : Constantes.DEFAULT_FIELD);
			ubigeoEmisor.setCodPais("PE");
                        
            emisor.setNumDocIdentidad(comprobante.getDatosEmisor().getNumRuc());
            emisor.setCodTipoDoc("6");
            emisor.setRazonSocial(comprobante.getDatosEmisor().getDesRazonSocialEmis());
            emisor.setUbigeo(ubigeoEmisor);
            
            Ubigeo ubigeoReceptor = new Ubigeo();
            ubigeoReceptor.setCodUbigeo(ubigeoEmi.getCodUbigeo());
			ubigeoReceptor.setDireccion(obtenerTipoVia(ubigeoEmi.getCodTipvia()) +" " + ubigeoEmi.getDesNomVia());
			ubigeoReceptor.setUrbanizacion(ubigeoEmi.getDesNumer1()+" "+ubigeoEmi.getDesNomZon());
			ubigeoReceptor.setProvincia(ubigeoEmi.getDesProvincia());
			ubigeoReceptor.setDepartamento(ubigeoEmi.getDesDepartamento());
			ubigeoReceptor.setDistrito(ubigeoEmi.getDesDistrito());
			ubigeoReceptor.setCodPais("PE");
            receptor.setCodTipoDoc(comprobante.getDatosReceptor().getCodDocIdeRecep());
            receptor.setNumDocIdentidad(comprobante.getDatosReceptor().getNumDocIdeRecep());
            receptor.setDesTipoDoc(Utils.descCodDoc(comprobante.getDatosReceptor().getCodDocIdeRecep()));
            receptor.setRazonSocial(comprobante.getDatosReceptor().getDesRazonSocialRecep());
            receptor.setNombreComercial("NombreComercial");
            receptor.setUbigeo(ubigeoReceptor);

			retencionModel.setPkRetencion(pkComprobante);
			retencionModel.setEmisor(emisor);
			retencionModel.setReceptor(receptor);
			retencionModel.setFechaEmision(comprobante.getFecEmision());
			retencionModel.setCodRegimenRet(comprobante.getRegRetencion());
//			String[] parts = comprobante.getRegRetencion().split("\\|");
//                        String part1 = parts[0]; // DESC
//                        String part2 = parts[1]; // porc
			retencionModel.setDesRegimenRet(comprobante.getRegRetencion());
			retencionModel.setPorcentajeRet(comprobante.getInformacionItems().get(0).getPorTasa().doubleValue());
			retencionModel.setMontoTotalRetenido(comprobante.getMtoTotalRet().doubleValue());
			retencionModel.setMontoTotalPagado(comprobante.getMtoTotalCobrado().doubleValue());

			List<DocRelacionadoRet> listaDocRel = new ArrayList<DocRelacionadoRet>();
            if(comprobante.getInformacionItems().size() > 0) {
			for(InformacionItems retDocRel : comprobante.getInformacionItems()) {
				DocRelacionadoRet docRel = new DocRelacionadoRet();
				docRel.setCodTipoCpeRel(retDocRel.getCodCpe());
				docRel.setDesTipoCpeRel(Constantes.NOMBRE_COMPROBANTE_ESTANDAR);
				docRel.setNumSerieCpeRel(retDocRel.getNumSerie());
				docRel.setNumCpeRel(retDocRel.getNumCpe()+"");
				docRel.setFechaEmisionCpeRel(retDocRel.getFecEmision());
				docRel.setMontoTotalCpeRel(retDocRel.getMtoTotalCpeRel().doubleValue());
				docRel.setCodMonedaCpeRel(retDocRel.getCodMonedaCpeRel());
				docRel.setSimboloMonedaCpeRel(Utils.descSimboloMoneda(retDocRel.getCodMonedaCpeRel()));
                docRel.setMontoPagado(retDocRel.getMtoImporteNetoPagado().doubleValue());
				//docRel.setIndTipoCalculo(indTipoCalculo);
				docRel.setFechaPago(retDocRel.getFecEmision());
				docRel.setNumPago(retDocRel.getNroPago().toString());
				docRel.setMontoPago(retDocRel.getMtoImportePago().doubleValue());
				docRel.setCodMonedaPago(retDocRel.getCodMonedaPago());
				docRel.setSimboloMonedaPago(Utils.descSimboloMoneda(retDocRel.getCodMonedaPago()));
				docRel.setMontoRetenido(retDocRel.getMtoRetencion().doubleValue());
				docRel.setFechaRetencion(retDocRel.getFecEmision());
				
				listaDocRel.add(docRel);

			}
		}
		
		retencionModel.setLstDocRel(listaDocRel);

        }
        return retencionModel;
    } 

    
    public Percepcion obtenerParametroPercepcionBean(List<Comprobantes> lstCp, UbigeoContribuyente ubigeoEmi,UbigeoContribuyente ubigeoRecep) {
            
        DateFormat fmt = new SimpleDateFormat("yyyy-MM-dd");
			
	//Construyendo el Obteto model Percepcion  - PDF
        Percepcion percepcionModel = new Percepcion();

        for (Comprobantes comprobante : lstCp) {
           
            Contribuyente emisor=new Contribuyente();
            Contribuyente receptor=new Contribuyente();
            PkComprobante pkComprobante = new PkComprobante(comprobante.getDatosEmisor().getNumRuc(), comprobante.getCodCpe(), comprobante.getNumSerie(), comprobante.getNumCpe());

            Ubigeo ubigeoEmisor = new Ubigeo();
            ubigeoEmisor.setCodUbigeo(Objects.nonNull(ubigeoEmi.getCodUbigeo()) ? 
            		ubigeoEmi.getCodUbigeo() : Constantes.DEFAULT_FIELD);
			ubigeoEmisor.setDireccion(Objects.nonNull(ubigeoEmi.getDesNomVia())? 
					obtenerTipoVia(ubigeoEmi.getCodTipvia()) +" " + ubigeoEmi.getDesNomVia() : Constantes.DEFAULT_FIELD);
			ubigeoEmisor.setUrbanizacion(Objects.nonNull(ubigeoEmi.getDesNomZon())?
					ubigeoEmi.getDesNumer1()+" "+ubigeoEmi.getDesNomZon() : Constantes.DEFAULT_FIELD);
			ubigeoEmisor.setProvincia(Objects.nonNull(ubigeoEmi.getDesProvincia())? 
					ubigeoEmi.getDesProvincia() : Constantes.DEFAULT_FIELD);
			ubigeoEmisor.setDepartamento(Objects.nonNull(ubigeoEmi.getDesDepartamento())?
					ubigeoEmi.getDesDepartamento() : Constantes.DEFAULT_FIELD);
			ubigeoEmisor.setDistrito(Objects.nonNull(ubigeoEmi.getDesDistrito())? 
					ubigeoEmi.getDesDistrito() : Constantes.DEFAULT_FIELD);
			ubigeoEmisor.setCodPais("PE");
                        
            emisor.setNumDocIdentidad(comprobante.getDatosEmisor().getNumRuc());
            emisor.setCodTipoDoc("6");
            emisor.setRazonSocial(comprobante.getDatosEmisor().getDesRazonSocialEmis());
            emisor.setUbigeo(ubigeoEmisor);
            
                        Ubigeo ubigeoReceptor = new Ubigeo();
                        ubigeoReceptor.setCodUbigeo(ubigeoEmi.getCodUbigeo());
			ubigeoReceptor.setDireccion(ubigeoEmi.getDesNomVia());
			ubigeoReceptor.setUrbanizacion(ubigeoEmi.getDesNomZon());
			ubigeoReceptor.setProvincia(ubigeoEmi.getDesProvincia());
			ubigeoReceptor.setDepartamento(ubigeoEmi.getDesDepartamento());
			ubigeoReceptor.setDistrito(ubigeoEmi.getDesDistrito());
			ubigeoReceptor.setCodPais("PE");
                        receptor.setCodTipoDoc(comprobante.getDatosReceptor().getCodDocIdeRecep());
                        receptor.setNumDocIdentidad(comprobante.getDatosReceptor().getNumDocIdeRecep());
                        receptor.setDesTipoDoc(Utils.descCodDoc(comprobante.getDatosReceptor().getCodDocIdeRecep()));
                        receptor.setRazonSocial(comprobante.getDatosReceptor().getDesRazonSocialRecep());
                        receptor.setNombreComercial("Nombre Comercial");
                        receptor.setUbigeo(ubigeoReceptor);

			percepcionModel.setPkPercepcion(pkComprobante);
			percepcionModel.setEmisor(emisor);
			percepcionModel.setReceptor(receptor);
			percepcionModel.setFechaEmision(comprobante.getFecEmision());
//                        String[] parts = comprobante.getRegPercepcion().split("\\|");
//                        String part1 = parts[0]; // DESC
//                        String part2 = parts[1]; // porc
			percepcionModel.setDesRegimenPer(comprobante.getRegPercepcion());
			percepcionModel.setPorcentajePer(comprobante.getInformacionItems().get(0).getPorTasa().doubleValue());
                        percepcionModel.setMontoTotalCobrado(comprobante.getMtoTotalCobrado().doubleValue());
			percepcionModel.setMontoTotalPercibido(comprobante.getMtoTotalPer().doubleValue());
                                
			List<DocRelacionadoPer> listaDocRel = new ArrayList<DocRelacionadoPer>();
            if(comprobante.getInformacionItems().size() > 0) {
			for(InformacionItems retDocPer : comprobante.getInformacionItems()) {
				DocRelacionadoPer docRel = new DocRelacionadoPer();
				docRel.setCodTipoCpeRel(retDocPer.getCodCpe());
				docRel.setDesTipoCpeRel(Constantes.NOMBRE_COMPROBANTE_ESTANDAR);
				docRel.setNumSerieCpeRel(retDocPer.getNumSerie());
				docRel.setNumCpeRel(retDocPer.getNumCpe()+"");
				docRel.setFechaEmisionCpeRel(retDocPer.getFecEmision());
				docRel.setMontoTotalCpeRel(retDocPer.getMtoTotalCpeRel().doubleValue());
				docRel.setCodMonedaCpeRel(retDocPer.getCodMonedaCpeRel());
				docRel.setSimboloMonedaCpeRel(Utils.descSimboloMoneda(retDocPer.getCodMonedaCpeRel()));
				docRel.setMontoCobrado(retDocPer.getMtoImporteNetoCobrado().doubleValue());

				docRel.setFechaPago(retDocPer.getFecEmision());
				docRel.setNumPago(retDocPer.getNroCobro().toString());

				docRel.setMontoPago(retDocPer.getMtoImporteCobro().doubleValue());
				docRel.setCodMonedaPago(retDocPer.getCodMonedaPago());
				docRel.setSimboloMonedaPago(Utils.descSimboloMoneda(retDocPer.getCodMonedaPago()));
				docRel.setMontoPercibido(retDocPer.getMtoPercepcion().doubleValue());
				docRel.setFechaPercepcion(retDocPer.getFecEmision());
				
				listaDocRel.add(docRel);

			}
		}
		
		percepcionModel.setLstDocRel(listaDocRel);

        }
        return percepcionModel;
    } 
    
	private List<ResumenDTO> obtenerResumen(List<Comprobantes> comprobanteDTOS){
		List<ResumenDTO> resumenDTOS= new ArrayList<>();
		Map<Date,Long> conteoPorFecha = comprobanteDTOS.stream()
				.collect(Collectors.groupingBy(Comprobantes::getFecEmision, Collectors.counting()));
		final int[] contador = {1};
		conteoPorFecha.entrySet().stream()
				.sorted(Map.Entry.comparingByKey()).forEach((entry) -> {
				ResumenDTO resumenDTO= new ResumenDTO();
				resumenDTO.setNumCorrel(contador[0]);
				resumenDTO.setFecCpe(entry.getKey());
				resumenDTO.setCntCpe(entry.getValue().intValue());
				resumenDTOS.add((resumenDTO));
				contador[0] = contador[0] +1;
		});

		return resumenDTOS;
	}
    
    private String obtenerTipoVia(String desNomvia) {
        HashMap<String, String> tipodesNomvia = new HashMap<>();
        String tipoAfectacionStr = desNomvia.toString();
        
        tipodesNomvia.put("01", "Av.");
        tipodesNomvia.put("02", "Jr.");
        return tipodesNomvia.get(tipoAfectacionStr);
    }
    
}





package pe.gob.sunat.contribuyentems.servicio.consultacpe.consulta.retper.repository.impl;


import pe.gob.sunat.contribuyentems.servicio.consultacpe.consulta.retper.basebdcpe.*;


import pe.gob.sunat.contribuyentems.servicio.consultacpe.consulta.retper.basebdcpe.dao.PercepcionRepository;
import pe.gob.sunat.contribuyentems.servicio.consultacpe.consulta.retper.basebdcpe.dao.RetencionFileRepository;
import pe.gob.sunat.contribuyentems.servicio.consultacpe.consulta.retper.basebdcpe.dao.PercepcionFileRepository;
import pe.gob.sunat.contribuyentems.servicio.consultacpe.consulta.retper.basebdcpe.dao.RetencionRepository;
import pe.gob.sunat.contribuyentems.servicio.consultacpe.consulta.retper.basebdparametros.domain.Contribuyentes;
import pe.gob.sunat.contribuyentems.servicio.consultacpe.consulta.retper.basebdparametros.domain.UbigeoContribuyente;
import pe.gob.sunat.contribuyentems.servicio.consultacpe.consulta.retper.basebdparametros.domain.dao.ContribuyenteRepository;
import pe.gob.sunat.contribuyentems.servicio.consultacpe.consulta.retper.basebdrecauda.Param;
import pe.gob.sunat.contribuyentems.servicio.consultacpe.consulta.retper.basebdrecauda.dao.ParamRepository;
import pe.gob.sunat.contribuyentems.servicio.consultacpe.consulta.retper.domain.*;
import pe.gob.sunat.contribuyentems.servicio.consultacpe.consulta.retper.main.config.PropertiesBean;
import pe.gob.sunat.contribuyentems.servicio.consultacpe.consulta.retper.repository.ComprobantesRepository;
import pe.gob.sunat.contribuyentems.servicio.consultacpe.consulta.retper.repository.MongoDBRepository;
import pe.gob.sunat.contribuyentems.servicio.consultacpe.consulta.retper.util.Constantes;
import pe.gob.sunat.contribuyentems.servicio.consultacpe.consulta.retper.util.Utils;
import pe.gob.sunat.contribuyentems.servicio.consultacpe.consulta.retper.util.exceptions.ErrorEnum;
import pe.gob.sunat.contribuyentems.servicio.consultacpe.consulta.retper.util.exceptions.ErrorMessage;
import pe.gob.sunat.contribuyentems.servicio.consultacpe.consulta.retper.util.exceptions.UnprocessableEntityException;
import pe.gob.sunat.contribuyentems.servicio.consultacpe.consulta.retper.ws.dto.ComprobanteIndividualRequestDTO;
import pe.gob.sunat.contribuyentems.servicio.consultacpe.consulta.retper.ws.dto.ComprobanteMasivaRequestDTO;
import pe.gob.sunat.tecnologiams.arquitectura.framework.common.util.ConstantesUtils;
import pe.gob.sunat.tecnologiams.arquitectura.framework.core.util.UtilLog;

import javax.inject.Inject;

import org.apache.commons.io.FileUtils;
import org.apache.commons.lang3.StringUtils;

import com.google.gson.Gson;
import com.google.gson.JsonArray;
import com.google.gson.JsonObject;

import java.io.BufferedReader;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.math.BigDecimal;
import java.math.BigInteger;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.text.Format;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.*;
import java.util.stream.Collectors;
import java.util.zip.ZipEntry;
import java.util.zip.ZipInputStream;

public class ComprobantesRepositoryImpl extends MongoDBRepository implements ComprobantesRepository {
    @Inject
    private PercepcionRepository percepcionRepository;
    @Inject
    private RetencionRepository retencionRepository;
    @Inject
    private ParamRepository paramRepository;
    @Inject
    private ContribuyenteRepository contribuyenteRepository;
    @Inject
    private PercepcionFileRepository percepcionXMLRepository;
    @Inject
    private RetencionFileRepository retencionXMLRepository;    
    @Inject
    private UtilLog utilLog;
    @Inject
    private Utils util;
    @Inject
	private PropertiesBean properties;
    
    @Override
    public List<Comprobantes> obtenerComprobanteIndividual(ComprobanteIndividualRequestDTO request) throws ParseException {

        List<Comprobantes> comprobantes= new ArrayList<>();
        DatosEmisor datosEmisor =new DatosEmisor();
        DatosReceptor datosReceptor =new DatosReceptor();
        ComprobantePK comprobantePk=new ComprobantePK();
        Comprobantes  comprobanteInd=new Comprobantes();
        comprobantePk.setCodCpe(request.getCodCpe());
        comprobantePk.setNumCpe(request.getNumCpe().intValue());
        comprobantePk.setNumRuc(request.getNumRucEmisor());
        comprobantePk.setNumSerieCpe(request.getNumSerieCpe());
        
        String rucReceptor = null;
        if(request.getCodFiltroCpe().equals(Constantes.COD_CPE_RECEPTOR)){
        	rucReceptor = Objects.nonNull(request.getNumRucHeader())? 
            		request.getNumRucHeader() : StringUtils.EMPTY;
        }
        
        
        //RETENCION
        if(request.getCodCpe().equals(Constantes.COD_CPE_RETENCION)) {
            
        Retencion comprobante = Optional
                .ofNullable(retencionRepository.obtenerComprobante(comprobantePk,rucReceptor))
                .orElse(null);
        if(Objects.nonNull(comprobante)){
        	
            List<RetDocRel> listaPerDocRel = Optional
                    .ofNullable(retencionRepository.obtenerDetalleRetencion(comprobantePk))
                    .orElse(null);
            
            datosEmisor.setNumRuc(comprobante.getRetencionPK().getNumRuc());
            datosEmisor.setDesRazonSocialEmis(obtenerRazonSocial(comprobante.getRetencionPK().getNumRuc()));
            datosEmisor.setDesDirEmis(obtenerDireccion(comprobante.getRetencionPK().getNumRuc()));
            
            datosReceptor.setCodDocIdeRecep(comprobante.getCodTipoDocRecep());
            datosReceptor.setNumDocIdeRecep(comprobante.getNumDocRecep());
            datosReceptor.setDesRazonSocialRecep(comprobante.getDesNomRecep());
            comprobanteInd.setCodCpe(comprobante.getRetencionPK().getCodCpe());
            comprobanteInd.setNumSerie(comprobante.getRetencionPK().getNumSerieCpe());
            comprobanteInd.setNumCpe(comprobante.getRetencionPK().getNumCpe());
            comprobanteInd.setFecEmision(comprobante.getFecEmi());
            comprobanteInd.setFecRegistro(comprobante.getFecRegis());
            comprobanteInd.setIndEstadoCpe(comprobante.getCodEstCpe());
            comprobanteInd.setIndProcedencia(comprobante.getIndProcedencia());
            comprobanteInd.setMtoTotalCobrado(comprobante.getMtoTotalPagado());
            comprobanteInd.setMtoTotalRet(comprobante.getMtoTotalRet());
            comprobanteInd.setUbigeo(obtenerUbigeo(comprobante.getRetencionPK().getNumRuc()));
            comprobanteInd.setCodEstCpe(comprobante.getCodEstCpe());
            comprobanteInd.setFecReversion(comprobante.getFecRev());
            comprobanteInd.setObservacion(comprobante.getDesObservacion());
            comprobanteInd.setMotivoReversion(comprobante.getDesMotivoRev());
            // paramRepository
             String respuesta = Optional
             .ofNullable(paramRepository.obtenerParametros(comprobantePk.getCodCpe(),comprobante.getCodRegRet()))
             .orElse(null);
             String[] parts = respuesta.split("\\|");
             String part1 = parts[0];
               String part2 = parts[1]; // porc
               Double porceptaje=Double.valueOf(part2);
            comprobanteInd.setRegRetencion(part1);
            
            List<InformacionItems> lstInfItems = new ArrayList<>();
            for(RetDocRel a : listaPerDocRel) {
            	InformacionItems infItems = new InformacionItems();
            	infItems.setCodCpe(a.getCodTipCpeRel());
            	infItems.setNumSerie(a.getNumSerieCpeRel());
            	infItems.setNumCpe(Integer.valueOf(a.getNumCpeRel()));
            	infItems.setFecEmision(a.getFecEmiCpeRel());
            	infItems.setCodMonedaCpeRel(a.getCodMonedaCpeRel());
            	infItems.setCodMonedaPago(a.getCodMonedaPago());
            	infItems.setMtoTotal(a.getMtoTotalCpeRel());
            	//mongo
            	infItems.setNroPago(new BigDecimal(a.getNumPago()));
            	infItems.setMtoImportePago(a.getMtoPago());
            	infItems.setPorTasa(BigDecimal.valueOf(porceptaje));
            	infItems.setMtoRetencion(a.getMtoRet());
            	infItems.setMtoImporteNetoPagado(a.getMtoPagado());
                infItems.setMtoTotalCpeRel(a.getMtoTotalCpeRel());
            	lstInfItems.add(infItems);
            	
            }
            
            comprobanteInd.setDatosEmisor(datosEmisor);
            comprobanteInd.setDatosReceptor(datosReceptor);
            comprobanteInd.setInformacionItems(lstInfItems);
            comprobantes.add(comprobanteInd);

        }
        
        }        
        
      //PERCEPCION
        if(request.getCodCpe().equals(Constantes.COD_CPE_PERCEPCION)) {
        
        Percepcion comprobante = Optional
                .ofNullable(percepcionRepository.obtenerComprobante(comprobantePk,rucReceptor))
                .orElse(null);
        if(Objects.nonNull(comprobante)){
        	
            List<PerDocRel> listaPerDocRel = Optional
                    .ofNullable(percepcionRepository.obtenerDetallePercepcion(comprobantePk))
                    .orElse(null);

            datosEmisor.setNumRuc(comprobante.getPercepcionPK().getNumRuc());
            datosEmisor.setDesRazonSocialEmis(obtenerRazonSocial(comprobante.getPercepcionPK().getNumRuc()));
            datosEmisor.setDesDirEmis(obtenerDireccion(comprobante.getPercepcionPK().getNumRuc()));
            
            datosReceptor.setCodDocIdeRecep(comprobante.getCodTipoDocRecep());
            datosReceptor.setNumDocIdeRecep(comprobante.getNumDocRecep());
            datosReceptor.setDesRazonSocialRecep(comprobante.getDesNomRecep());
            comprobanteInd.setCodCpe(comprobante.getPercepcionPK().getCodCpe());
            comprobanteInd.setNumSerie(comprobante.getPercepcionPK().getNumSerieCpe());
            comprobanteInd.setNumCpe(comprobante.getPercepcionPK().getNumCpe());
            comprobanteInd.setFecEmision(comprobante.getFecEmi());
            comprobanteInd.setFecRegistro(comprobante.getFecRegis());
            comprobanteInd.setIndEstadoCpe(comprobante.getCodEstCpe());
            comprobanteInd.setIndProcedencia(comprobante.getIndProcedencia());
            comprobanteInd.setMtoTotalCobrado(comprobante.getMtoTotalCobrado());
            comprobanteInd.setMtoTotalPer(comprobante.getMtoTotalPer());
            comprobanteInd.setUbigeo(obtenerUbigeo(comprobante.getPercepcionPK().getNumRuc()));

            comprobanteInd.setCodEstCpe(comprobante.getCodEstCpe());
            comprobanteInd.setFecReversion(comprobante.getFecRev());
            comprobanteInd.setObservacion(comprobante.getDesObservacion());
            comprobanteInd.setMotivoReversion(comprobante.getDesMotivoRev());
            comprobanteInd.setIndReempReve(comprobante.getIndReempRev());
         // paramRepository
        String respuesta = Optional
        .ofNullable(paramRepository.obtenerParametros(comprobantePk.getCodCpe(),comprobante.getCodRegPer()))
        .orElse(null);
        String[] parts = respuesta.split("\\|");
        String part1 = parts[0]; // porc
          String part2 = parts[1]; // porc
          Double porceptaje=Double.valueOf(part2);
            comprobanteInd.setRegPercepcion(part1 + " " + part2 );
            BigDecimal totalItems= BigDecimal.ZERO;
            List<InformacionItems> lstInfItems = new ArrayList<>();
            for(PerDocRel a : listaPerDocRel) {
            	InformacionItems infItems = new InformacionItems();
            	infItems.setCodCpe(a.getCodTipCpeRel());
            	infItems.setNumSerie(a.getNumSerieCpeRel());
            	infItems.setNumCpe(Integer.valueOf(a.getNumCpeRel()));
            	infItems.setFecEmision(a.getFecEmiCpeRel());
            	infItems.setCodMonedaCpeRel(a.getCodMonedaCpeRel());
            	infItems.setCodMonedaPago(a.getCodMonedaPago());
            	infItems.setMtoTotal(a.getMtoTotalCpeRel());
            	//mongo
                infItems.setNroCobro(new BigDecimal(a.getNumPago()));
            	infItems.setMtoImporteCobro(a.getMtoPago());
            	infItems.setPorTasa(BigDecimal.valueOf(porceptaje));
            	infItems.setMtoPercepcion(a.getMtoPer());
            	infItems.setMtoImporteNetoCobrado(a.getMtoCobrado());
            	infItems.setMtoTotalCpeRel(a.getMtoTotalCpeRel());
                totalItems=totalItems.add(infItems.getMtoImporteNetoCobrado());
            	lstInfItems.add(infItems);
            	
            }
            comprobanteInd.setMtoRedondeo(totalItems.subtract(comprobante.getMtoTotalCobrado()));
            //Comprobantes  comprobanteInd=new Comprobantes();
            comprobanteInd.setDatosEmisor(datosEmisor);
            comprobanteInd.setDatosReceptor(datosReceptor);
            comprobanteInd.setInformacionItems(lstInfItems);
            comprobantes.add(comprobanteInd);

        }
        
        }
        return comprobantes;
    }

    @Override
    public List<Comprobantes> obtenerComprobanteMasiva(ComprobanteMasivaRequestDTO request) throws ParseException, UnprocessableEntityException {

    	//comprobantes
        List<Comprobantes> comprobantesList= new ArrayList<>();
;		int limit=Integer.parseInt(properties.getParamLimitInformix());
		int cntComp=properties.getCntComp();

        ComprobantePK comprobantePk=new ComprobantePK();
        Comprobantes  comprobanteInd=new Comprobantes();
        comprobantePk.setCodCpe(request.getCodCpe());
//        comprobantePk.setNumCpe(request.getNumCpe().intValue());
        String numRucEmisor="";
        if(request.getCodFiltroCpe().contains(Constantes.COD_CPE_EMISOR)){
            if(Objects.isNull(request.getNumRucEmisor())|| request.getNumRucEmisor().isEmpty()) {
                numRucEmisor = request.getNumRucHeader();
                comprobantePk.setNumRuc(numRucEmisor);
            }else{
                numRucEmisor = request.getNumRucEmisor();
                comprobantePk.setNumRuc(numRucEmisor);
            }
        }else{
            numRucEmisor=request.getNumRucEmisor()==null ? "":request.getNumRucEmisor();
            comprobantePk.setNumRuc(numRucEmisor);
        }
        comprobantePk.setNumSerieCpe(request.getNumSerieCpe());
        
        
        String rucReceptor = null;
        if(request.getCodFiltroCpe().equals(Constantes.COD_CPE_RECEPTOR)){
        	rucReceptor = Objects.nonNull(request.getNumRucHeader())? 
            		request.getNumRucHeader() : StringUtils.EMPTY;
        }
       
        //RETENCION
        if(request.getCodCpe().equals(Constantes.COD_CPE_RETENCION)) {
            
        	//comprobante
        	List<Retencion> comprobantesTotal = Optional
                .ofNullable(retencionRepository.obtenerComprobantesxFiltro(comprobantePk,request.getFecEmisionIni(),
                		request.getFecEmisionFin(),request.getNumCpeIni(),request.getNumCpeFin(),request.getCodDocIde(),
                		rucReceptor,request.getCodEstado()))
                .orElse(null);
        if(Objects.nonNull(comprobantesTotal)){
        	
        	if (comprobantesTotal.size() > limit) {
            	throw new UnprocessableEntityException(new ErrorMessage("231", "Debe mejorar el filtro b\u00FAsqueda porque excede los "+limit+" comprobantes."));
            }
        	
        	List<Retencion> comprobantes = comprobantesTotal.stream()
                    .limit(properties.getCntComp())
                    .collect(Collectors.toList());
        	
        	for(Retencion comprobante:comprobantes){
        		Comprobantes  comprobanteIndCpe=new Comprobantes();
                DatosEmisor datosEmisor =new DatosEmisor();
                DatosReceptor datosReceptor =new DatosReceptor();
                ComprobantePK comprobantePkList=new ComprobantePK();
                comprobantePkList.setCodCpe(comprobante.getRetencionPK().getCodCpe());
                comprobantePk.setNumCpe(comprobante.getRetencionPK().getNumCpe());
                comprobantePkList.setNumCpe(comprobante.getRetencionPK().getNumCpe());
                comprobantePkList.setNumRuc(comprobante.getRetencionPK().getNumRuc());
                comprobantePkList.setNumSerieCpe(comprobante.getRetencionPK().getNumSerieCpe());
                
                datosEmisor.setNumRuc(comprobante.getRetencionPK().getNumRuc());
                datosEmisor.setDesRazonSocialEmis(obtenerRazonSocial(comprobante.getRetencionPK().getNumRuc()));
                datosEmisor.setDesDirEmis(obtenerDireccion(comprobante.getRetencionPK().getNumRuc()));
                
                datosReceptor.setCodDocIdeRecep(comprobante.getCodTipoDocRecep());
                datosReceptor.setNumDocIdeRecep(comprobante.getNumDocRecep());
                datosReceptor.setDesRazonSocialRecep(comprobante.getDesNomRecep());
                comprobanteIndCpe.setCodCpe(comprobante.getRetencionPK().getCodCpe());
                comprobanteIndCpe.setNumSerie(comprobante.getRetencionPK().getNumSerieCpe());
                comprobanteIndCpe.setNumCpe(comprobante.getRetencionPK().getNumCpe());
                comprobanteIndCpe.setFecEmision(comprobante.getFecEmi());
                comprobanteIndCpe.setFecRegistro(comprobante.getFecRegis());
                comprobanteIndCpe.setIndEstadoCpe(comprobante.getCodEstCpe());
                comprobanteIndCpe.setIndProcedencia(comprobante.getIndProcedencia());
                comprobanteIndCpe.setUbigeo(obtenerUbigeo(comprobante.getRetencionPK().getNumRuc()));
                comprobanteIndCpe.setMtoTotalCobrado(comprobante.getMtoTotalPagado());
                comprobanteIndCpe.setMtoTotalRet(comprobante.getMtoTotalRet());
                comprobanteIndCpe.setCodEstCpe(comprobante.getCodEstCpe());
                comprobanteIndCpe.setFecReversion(comprobante.getFecRev());
                
                 // paramRepository
		        String respuesta = Optional
		        .ofNullable(paramRepository.obtenerParametros(comprobantePk.getCodCpe(),comprobante.getCodRegRet()))
		        .orElse(null);
		        String[] parts = respuesta.split("\\|");
		        String part1 = parts[0];
		        String part2 = parts[1]; // porc
		        Double porceptaje=Double.valueOf(part2);
            //comprobanteInd.setRegPercepcion(respuesta);
            
		        comprobanteIndCpe.setRegRetencion(part1);
        		
                List<RetDocRel> listaPerDocRel = Optional
                        .ofNullable(retencionRepository.obtenerDetalleRetencion(comprobantePkList))
                        .orElse(null);
                
                List<InformacionItems> lstInfItems = new ArrayList<>();
                for(RetDocRel a : listaPerDocRel) {
                	InformacionItems infItems = new InformacionItems();
            	infItems.setCodCpe(a.getRetDocRelPK().getCodCpe());
            	infItems.setNumSerie(a.getRetDocRelPK().getNumSerieCpe());
            	infItems.setNumCpe(a.getRetDocRelPK().getNumCpe());
            	infItems.setFecEmision(a.getFecEmiCpeRel());
            	infItems.setCodMonedaCpeRel(a.getCodMonedaCpeRel());
            	infItems.setCodMonedaPago(a.getCodMonedaPago());
            	infItems.setMtoTotal(a.getMtoTotalCpeRel());
            	//mongo
            	infItems.setNroPago(new BigDecimal(a.getNumPago()));
            	infItems.setMtoImportePago(a.getMtoPago());
            	infItems.setPorTasa(BigDecimal.valueOf(porceptaje));
            	infItems.setMtoRetencion(a.getMtoRet());
            	infItems.setMtoImporteNetoPagado(a.getMtoPagado());
            	lstInfItems.add(infItems);
                	
                }
                
                
                comprobanteIndCpe.setDatosEmisor(datosEmisor);
                comprobanteIndCpe.setDatosReceptor(datosReceptor);
                comprobanteIndCpe.setInformacionItems(lstInfItems);
                comprobantesList.add(comprobanteIndCpe);
        		
        	}
        	


        }
        
        }        
        
      //PERCEPCION
        if(request.getCodCpe().equals(Constantes.COD_CPE_PERCEPCION)) {
        
        //comprobante	
        List<Percepcion> comprobantesTotal = Optional
                .ofNullable(percepcionRepository.obtenerComprobantesxFiltro(comprobantePk,request.getFecEmisionIni(),
                		request.getFecEmisionFin(),request.getNumCpeIni(),request.getNumCpeFin(),request.getCodDocIde(),
                		rucReceptor,request.getCodEstado()))
                .orElse(null);
        if(Objects.nonNull(comprobantesTotal)){
        	
        	if (comprobantesTotal.size() > limit) {
            	throw new UnprocessableEntityException(new ErrorMessage("231", "Debe mejorar el filtro b\u00FAsqueda porque excede los "+limit+" comprobantes."));
            }
        	
        	List<Percepcion> comprobantes = comprobantesTotal.stream()
                    .limit(properties.getCntComp())
                    .collect(Collectors.toList());
        	
        	for(Percepcion comprobante:comprobantes){
                DatosEmisor datosEmisor =new DatosEmisor();
                DatosReceptor datosReceptor =new DatosReceptor();
        		Comprobantes  comprobanteIndCpe=new Comprobantes();
        		
                ComprobantePK comprobantePkList=new ComprobantePK();
                comprobantePkList.setCodCpe(comprobante.getPercepcionPK().getCodCpe());
                comprobantePkList.setNumCpe(comprobante.getPercepcionPK().getNumCpe());
                comprobantePkList.setNumRuc(comprobante.getPercepcionPK().getNumRuc());
                comprobantePkList.setNumSerieCpe(comprobante.getPercepcionPK().getNumSerieCpe());
                
                datosEmisor.setNumRuc(comprobante.getPercepcionPK().getNumRuc());
                datosEmisor.setDesRazonSocialEmis(obtenerRazonSocial(comprobante.getPercepcionPK().getNumRuc()));
                datosEmisor.setDesDirEmis(obtenerDireccion(comprobante.getPercepcionPK().getNumRuc()));
                
                datosReceptor.setCodDocIdeRecep(comprobante.getCodTipoDocRecep());
                datosReceptor.setNumDocIdeRecep(comprobante.getNumDocRecep());
                datosReceptor.setDesRazonSocialRecep(comprobante.getDesNomRecep());
                comprobanteIndCpe.setCodCpe(comprobante.getPercepcionPK().getCodCpe());
                comprobanteIndCpe.setNumSerie(comprobante.getPercepcionPK().getNumSerieCpe());
                comprobanteIndCpe.setNumCpe(comprobante.getPercepcionPK().getNumCpe());
                comprobanteIndCpe.setFecEmision(comprobante.getFecEmi());
                comprobanteIndCpe.setFecRegistro(comprobante.getFecRegis());
                comprobanteIndCpe.setIndEstadoCpe(comprobante.getCodEstCpe());
                comprobanteIndCpe.setIndProcedencia(comprobante.getIndProcedencia());
                comprobanteIndCpe.setUbigeo(obtenerUbigeo(comprobante.getPercepcionPK().getNumRuc()));
                comprobanteIndCpe.setMtoTotalCobrado(comprobante.getMtoTotalCobrado());
                comprobanteIndCpe.setMtoTotalPer(comprobante.getMtoTotalPer());
                comprobanteIndCpe.setCodEstCpe(comprobante.getCodEstCpe());
                comprobanteIndCpe.setFecReversion(comprobante.getFecRev());
                                 // paramRepository
        String respuesta = Optional
        .ofNullable(paramRepository.obtenerParametros(comprobantePk.getCodCpe(),comprobante.getCodRegPer()))
        .orElse(null);
        String[] parts = respuesta.split("\\|");
          String part2 = parts[1]; // porc
          Double porceptaje=Double.valueOf(part2);
          comprobanteIndCpe.setRegPercepcion(respuesta);
            
          comprobanteIndCpe.setRegPercepcion(respuesta);
                
                List<PerDocRel> listaPerDocRel = Optional
                        .ofNullable(percepcionRepository.obtenerDetallePercepcion(comprobantePkList))
                        .orElse(null);
                
                List<InformacionItems> lstInfItems = new ArrayList<>();
                for(PerDocRel a : listaPerDocRel) {
                	InformacionItems infItems = new InformacionItems();
            	infItems.setCodCpe(a.getPerDocRelPK().getCodCpe());
            	infItems.setNumSerie(a.getPerDocRelPK().getNumSerieCpe());
            	infItems.setNumCpe(a.getPerDocRelPK().getNumCpe());
            	infItems.setFecEmision(a.getFecEmiCpeRel());
                infItems.setCodMonedaCpeRel(a.getCodMonedaCpeRel());
            	infItems.setCodMonedaPago(a.getCodMonedaPago());
            	infItems.setMtoTotal(a.getMtoTotalCpeRel());
            	//mongo
                infItems.setNroCobro(new BigDecimal(a.getNumPago()));
            	infItems.setMtoImporteCobro(a.getMtoPago());
            	infItems.setPorTasa(BigDecimal.valueOf(porceptaje));
            	infItems.setMtoPercepcion(a.getMtoPer());
            	infItems.setMtoImporteNetoCobrado(a.getMtoCobrado());
            	lstInfItems.add(infItems);
                	
                }
                
                //Comprobantes  comprobanteInd=new Comprobantes();
                comprobanteIndCpe.setDatosEmisor(datosEmisor);
                comprobanteIndCpe.setDatosReceptor(datosReceptor);
                comprobanteIndCpe.setInformacionItems(lstInfItems);
                comprobantesList.add(comprobanteIndCpe);
        		
        	}
        }  
        }
        return comprobantesList;
    }
    
    @Override
    public Date obtenerFechaEmision(ComprobanteIndividualRequestDTO request) throws ParseException {
        ComprobantePK comprobantePk = new ComprobantePK();
        comprobantePk.setCodCpe(request.getCodCpe());
        comprobantePk.setNumCpe(request.getNumCpe().intValue());
        comprobantePk.setNumRuc(request.getNumRucEmisor());
        comprobantePk.setNumSerieCpe(request.getNumSerieCpe());
        
        String rucReceptor = null;
        if(request.getCodFiltroCpe().equals(Constantes.COD_CPE_RECEPTOR)){
        	rucReceptor = Objects.nonNull(request.getNumRucHeader())? 
            		request.getNumRucHeader() : StringUtils.EMPTY;
        }
        
        Optional<Date> fecha = null;
        if(request.getCodCpe().equals(Constantes.COD_CPE_PERCEPCION)){
        	fecha = Optional.ofNullable(percepcionRepository.obtenerFechaEmision(comprobantePk, rucReceptor));
        }
        if(request.getCodCpe().equals(Constantes.COD_CPE_RETENCION)){
        	fecha = Optional.ofNullable(retencionRepository.obtenerFechaEmision(comprobantePk, rucReceptor));
        }
        
        
        if (fecha.isPresent()) {
            return fecha.get();

        } else {
            return null;
        }
    }
    
    
    private String obtenerRazonSocial(String numRuc){

        String desRazonSocialEmis = "";
        try{
            Contribuyentes contribuyente = contribuyenteRepository.obtenerContribuyente(numRuc.trim());
            if(contribuyente != null){
                desRazonSocialEmis = contribuyente.getDesNombre().trim();
            }
        }catch(Exception ex){
            utilLog.imprimirLog(ConstantesUtils.LEVEL_DEBUG, ex.getMessage());
        }
        return desRazonSocialEmis;
    }
    private String obtenerDireccion(String numRuc){

        String desRazonSocialEmis = "";
        try{
            Contribuyentes contribuyente = contribuyenteRepository.obtenerContribuyente(numRuc.trim());
            if(contribuyente != null){
                desRazonSocialEmis = contribuyente.getUbigeo().getDesNomZon();
            }
        }catch(Exception ex){
            utilLog.imprimirLog(ConstantesUtils.LEVEL_DEBUG, ex.getMessage());
        }
        return desRazonSocialEmis;
    }
    
    private String obtenerUbigeo(String numRuc){
        String ubigeoStr = "";
        
        try{
            Contribuyentes contribuyente = contribuyenteRepository.obtenerContribuyente(numRuc.trim());
            if(contribuyente != null){	
            	ubigeoStr = ubigeoStr
            			.concat(contribuyente.getUbigeo().getDesNomZon()+"-")
            			.concat(contribuyente.getUbigeo().getDesDepartamento()+ "-")
            			.concat(contribuyente.getUbigeo().getDesProvincia() + "-")
            			.concat(contribuyente.getUbigeo().getDesDistrito());
            }
        }catch(Exception ex){
            utilLog.imprimirLog(ConstantesUtils.LEVEL_DEBUG, ex.getMessage());
        }
        return ubigeoStr;
    }
    
    public File recuperaComprobanteService(String numRuc, String numCpe, String codCpe, String numSerieCpe,
    		String codTipDes, String codFiltro, String rucHeader) throws UnprocessableEntityException {
    	
        utilLog.imprimirLog(ConstantesUtils.LEVEL_DEBUG,
                "XmlComprobanteServiceImpl.recuperaComprobanteXmlService - INICIO");
        
        try {
        	String numTicket;
        	byte[] byteArray = null;
        	String fileName = "";
        	ComprobantePK comprobantePK = new ComprobantePK();
        	comprobantePK.setNumRuc(numRuc);
        	comprobantePK.setNumCpe(Integer.parseInt(numCpe));
        	comprobantePK.setCodCpe(codCpe);
        	comprobantePK.setNumSerieCpe(numSerieCpe);
        	
            String rucReceptor = null;
            if(codFiltro.equals(Constantes.COD_CPE_RECEPTOR)){
            	rucReceptor = Objects.nonNull(rucHeader)? 
            			rucHeader : StringUtils.EMPTY;
            }
        	
        	
        	if(codCpe.equals(Constantes.COD_CPE_PERCEPCION)) {
            	Percepcion percepcion = percepcionRepository.obtenerComprobante(comprobantePK, rucReceptor);
//            	if(percepcion.getIndProcedencia().equals(Constantes.COD_IND_PROCEDENCIA_PORTAL) 
//            			&& codTipDes.equals(Constantes.COD_DESCARGA_CDR)) {
//            		throw new UnprocessableEntityException(new ErrorMessage(ErrorEnum.ERROR_150));
//            	}
            	
                if(codTipDes.equals(Constantes.COD_DESCARGA_XML)) {
                	codTipDes = "1";

                } else if (codTipDes.equals(Constantes.COD_DESCARGA_CDR)){
                	codTipDes = "0";

                }
                
                //recupero fecha de emision,
                //busco en el nfs
                
                
                
                
            	numTicket = percepcion.getNumTicket();
            	
                PercepcionXML comprobanteArchivo = new PercepcionXML();
                PercepcionXMLPK pk = new PercepcionXMLPK();
                pk.setIndModo(codTipDes);
                pk.setNumTicket(Long.parseLong(numTicket));
                comprobanteArchivo =percepcionXMLRepository.findComprobanteXmlService(pk);
                byteArray = comprobanteArchivo.getDatosArchivo();
                if(codTipDes.equals(Constantes.COD_DESCARGA_CDR_BD)){
                	fileName = nomFileCDR(comprobanteArchivo.getNomArchivo());
                	
                } else {
                	fileName = comprobanteArchivo.getNomArchivo();
                }
        	}
        	
        	if(codCpe.equals(Constantes.COD_CPE_RETENCION)) {
            	Retencion retencion = retencionRepository.obtenerComprobante(comprobantePK, rucReceptor);
//            	if(retencion.getIndProcedencia().equals(Constantes.COD_IND_PROCEDENCIA_PORTAL) 
//            			&& codTipDes.equals(Constantes.COD_DESCARGA_CDR)) {
//            		throw new UnprocessableEntityException(new ErrorMessage(ErrorEnum.ERROR_150));
//            	}
            	
                if(codTipDes.equals(Constantes.COD_DESCARGA_XML)) {
                	codTipDes = "1";

                } else if (codTipDes.equals(Constantes.COD_DESCARGA_CDR)){
                	codTipDes = "0";

                }
            	numTicket = retencion.getNumTicket();
                RetencionXML comprobanteArchivo = new RetencionXML();
                RetencionXMLPK pk = new RetencionXMLPK();
                pk.setIndModo(codTipDes);
                pk.setNumTicket(Long.parseLong(numTicket));
                comprobanteArchivo =retencionXMLRepository.findComprobanteXmlService(pk);
                byteArray = comprobanteArchivo.getDatosArchivo();
                
                
                if(codTipDes.equals(Constantes.COD_DESCARGA_CDR_BD)){
                	fileName = nomFileCDR(comprobanteArchivo.getNomArchivo());
                	
                } else {
                	fileName = comprobanteArchivo.getNomArchivo();
                }
        	}


            File newFile = new File(fileName);
            FileUtils.writeByteArrayToFile(newFile, byteArray);
        		
            utilLog.imprimirLog(ConstantesUtils.LEVEL_DEBUG,
                    "XmlComprobanteServiceImpl.recuperaComprobanteXmlService - FIN");
            return newFile;
        } catch (Exception e) {
            return null;
        }
    }
    
    private String nomFileCDR(String nomFile) {
    	String[] parts = nomFile.split("\\.");
    	return parts[0] + "." + "zip";
    	
    }
    
    
    
    public String buscarArchivoNFS(String textoJson) {
    	utilLog.imprimirLog(ConstantesUtils.LEVEL_DEBUG, "Inicio - consultarNFS textoJson: "+textoJson);
        String resp = "";
        //String url = "http://cpeose-tkgi.k8s.sunat.peru/v1/contribuyentems2/registro/cpe/consulta/nfs/individual";
 
        // JSON que quieres enviar
        String jsonInputString = textoJson;
        HttpURLConnection con = null;
        BufferedReader br = null;
        OutputStream os = null;
        try {
        	Param pbean = null;
			pbean.setNumero("967");
			//pbean.setArgumento("INTRES16152601");	
        	utilLog.imprimirLog(ConstantesUtils.LEVEL_DEBUG, "consultarNFS - URI - inicio");
			///pbean = t01DAO.findByNumeroArgumento("967", "INTRES16152601");
        	       	
        	
        	Param pbean = t01DAO.findByNumeroArgumento("967", "INTRES16152601");
        	utilLog.imprimirLog(ConstantesUtils.LEVEL_DEBUG, "consultarNFS - URI - fin");
			String s_uri=pbean.getFuncion().substring(0, 119).trim();
			String s_estadoWS=pbean.getFuncion().substring(124, 125).trim();
			if("0".equals(s_estadoWS)) {				
				throw new RuntimeException("Servicio Web se encuentra inhabilitado.WS:"+"INTRES16152601");
			}
			utilLog.imprimirLog(ConstantesUtils.LEVEL_DEBUG, "consultarNFS - URI "+ s_uri);			

            //URL urlObj = new URL(url);
			URL urlObj = new URL(s_uri);
            con = (HttpURLConnection) urlObj.openConnection();
            con.setRequestMethod("POST");
            con.setRequestProperty("Content-Type", "application/json");
            con.setDoOutput(true);
            // Envío del JSON
            os = con.getOutputStream();
            byte[] input = jsonInputString.getBytes(StandardCharsets.UTF_8);
            os.write(input, 0, input.length);
            
            ///TimeSpan interval = new TimeSpan(0, 0, 2);
            
            // Lectura de la respuesta
            br = new BufferedReader(new InputStreamReader(con.getInputStream(), "utf-8"));
            StringBuilder response = new StringBuilder();
            String responseLine;
            while ((responseLine = br.readLine()) != null) {
                response.append(responseLine.trim());
            }
            resp = response.toString();
            
            // Procesar la respuesta JSON para extraer el valor base64
            
            
            
            //JSONObject jsonObject = new JSONObject(resp);
            //JSONArray resultsArray = jsonObject.getJSONArray("results");
            // Suponiendo que solo hay un objeto en el array "results"
            //JSONObject resultObject = resultsArray.getJSONObject(0);
            
            Gson gson = new Gson();
            JsonObject jsonObject1 = gson.fromJson(resp, JsonObject.class);
            JsonArray resultsArray1 = jsonObject1.getAsJsonArray("results");
            
            
            byte[] decodedBytes = null;
            String decodedString = null;
            
            
			if (resultsArray1.size() > 0) {
				JsonObject firstResult = resultsArray1.get(0).getAsJsonObject();
                utilLog.imprimirLog(ConstantesUtils.LEVEL_DEBUG, "firstResult: "+firstResult);
                // Obtener el valor base64
                String base64String = firstResult.get("base64").getAsString();
                utilLog.imprimirLog(ConstantesUtils.LEVEL_DEBUG, "base64String: "+base64String);
 
    			decodedBytes = Base64.getDecoder().decode(base64String); // JAVA 8+
					decodedBytes=decompress(decodedBytes);
					utilLog.imprimirLog(ConstantesUtils.LEVEL_DEBUG, "decodedBytes-8: "+decodedBytes);
    			decodedString = new String(decodedBytes, "UTF-8");
    			utilLog.imprimirLog(ConstantesUtils.LEVEL_DEBUG, "decodedString-8: "+decodedString);
    			}
			
            return decodedString;
 
            
        } catch (Exception e) {
        	utilLog.imprimirLog(ConstantesUtils.LEVEL_DEBUG, "consultarNFS - Except: "+e);
        		return null;
        } finally {
        			if (os != null) {
        				try {
        					os.close();
        				} catch (Exception e) 
        					{ utilLog.imprimirLog(ConstantesUtils.LEVEL_DEBUG, "consultarNFS - Except os: "+e);}
        			}
        			if (br != null) {
        				try {
        					br.close();
        				} catch (Exception e) {
        					utilLog.imprimirLog(ConstantesUtils.LEVEL_DEBUG, "consultarNFS - Except br: "+e);
        				}
        			}
        			if (con != null) {
        				con.disconnect();
        			}
        }
	}
    
    public byte[] decompress(byte[] data) {
        try (ByteArrayInputStream byteArrayInputStream = new ByteArrayInputStream(data);
             ZipInputStream zipInputStream = new ZipInputStream(byteArrayInputStream);
             ByteArrayOutputStream byteArrayOutputStream = new ByteArrayOutputStream(data.length)) {

            byte[] buffer = new byte[2048];
            ZipEntry entry;

            while ((entry = zipInputStream.getNextEntry()) != null) {
                if (entry.getName().contains("R-")) {
                    continue;
                }
                int len;
                while ((len = zipInputStream.read(buffer)) > 0) {
                    byteArrayOutputStream.write(buffer, 0, len);
                }
            }
            return byteArrayOutputStream.toByteArray();

        } catch (IOException e) {
            e.printStackTrace(); 
            return data; 
        }
    }
    
    
    
    
    

}




package pe.gob.sunat.contribuyentems.servicio.consultacpe.consulta.retper.basebdcpe.dao.jpa;


import pe.gob.sunat.contribuyentems.servicio.consultacpe.consulta.retper.basebdcpe.ComprobantePK;
import pe.gob.sunat.contribuyentems.servicio.consultacpe.consulta.retper.basebdcpe.RetDocRel;
import pe.gob.sunat.contribuyentems.servicio.consultacpe.consulta.retper.basebdcpe.RetDocRelPK;
import pe.gob.sunat.contribuyentems.servicio.consultacpe.consulta.retper.basebdcpe.Retencion;
import pe.gob.sunat.contribuyentems.servicio.consultacpe.consulta.retper.basebdcpe.RetencionPK;
import pe.gob.sunat.contribuyentems.servicio.consultacpe.consulta.retper.basebdcpe.dao.RetencionRepository;
import pe.gob.sunat.contribuyentems.servicio.consultacpe.consulta.retper.main.config.PropertiesBean;
import pe.gob.sunat.contribuyentems.servicio.consultacpe.consulta.retper.util.Constantes;
import pe.gob.sunat.tecnologiams.arquitectura.framework.common.util.ConstantesUtils;
import pe.gob.sunat.tecnologiams.arquitectura.framework.core.util.UtilLog;
import pe.gob.sunat.tecnologiams.arquitectura.framework.jpa.dao.AbstractDao;

import javax.inject.Inject;
import javax.persistence.EntityManager;
import javax.persistence.NoResultException;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

import org.joda.time.DateTime;
import org.joda.time.LocalDate;
import org.joda.time.format.DateTimeFormat;
import org.joda.time.format.DateTimeFormatter;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class RetencionRepositoryImpl extends AbstractDao<Retencion, RetencionPK>  implements RetencionRepository {
    @PersistenceContext(unitName = "dccpe")
    private EntityManager entityManager;

    @Inject
    private UtilLog utilLog;
	@Inject
	private PropertiesBean properties;
    public EntityManager getDccpe() {
        return this.entityManager;
    }
    @Override
    public EntityManager buildEntityManager() {
        return entityManager;
    }

    public static RetencionRepositoryImpl forEntityManager(EntityManager entityManager) {
        RetencionRepositoryImpl dao = new RetencionRepositoryImpl();
        dao.entityManager = entityManager;
        dao.init();
        return dao;
    }


    @Override
    public Class<Retencion> provideEntityClass() {
        return Retencion.class;
    }
    
    @Override
    public Date obtenerFechaEmision(ComprobantePK comprobantePK, String rucReceptor) {
        // Usamos un Map para almacenar los parametros de la consulta
        Map<Integer, Object> parameters = new HashMap<>();
        
        StringBuilder sb = new StringBuilder();
        sb.append("select fec_emi from t6573retencion t ");
        sb.append("where t.num_ruc = ? and t.cod_cpe = ? and t.num_serie_cpe = ? and t.num_cpe = ? ");
        
        //seteamos los parametros
        parameters.put(1, comprobantePK.getNumRuc());
        parameters.put(2, comprobantePK.getCodCpe());
        parameters.put(3, comprobantePK.getNumSerieCpe());
        parameters.put(4, comprobantePK.getNumCpe());        
        
        int index = 5;
        if (rucReceptor!= null) {
            sb.append("and t.num_doc_recep = ? ");
            parameters.put(index++, rucReceptor);
        }

        Date fecha;
        try {
            Query query = entityManager.createNativeQuery(sb.toString());
            
            // AÃ±adimos los parametros a la consulta
            parameters.entrySet().forEach((entry) -> {
                query.setParameter(entry.getKey(), entry.getValue());
            });
            
            fecha = (Date)query.getSingleResult();
        } catch ( NoResultException nre) {
            utilLog.imprimirLog(ConstantesUtils.LEVEL_ERROR, nre.getMessage());
            fecha = null;
        } catch (Exception e) {
            utilLog.imprimirLog(ConstantesUtils.LEVEL_ERROR, e.getMessage());
            fecha = null;
        }
        return  fecha;
    }
    @Override
    public Retencion obtenerComprobante(ComprobantePK comprobantePK, String rucReceptor) {
        // Usamos un Map para almacenar los parametros de la consulta
        Map<Integer, Object> parameters = new HashMap<>();
        
        StringBuilder sb = new StringBuilder();
        sb.append("select * from t6573retencion t ");
        sb.append("where t.num_ruc = ? and t.cod_cpe = ? and t.num_serie_cpe = ? and t.num_cpe = ? ");
        
        //seteamos los parametros
        parameters.put(1, comprobantePK.getNumRuc());
        parameters.put(2, comprobantePK.getCodCpe());
        parameters.put(3, comprobantePK.getNumSerieCpe());
        parameters.put(4, comprobantePK.getNumCpe());        
        
        int index = 5;
        if (rucReceptor!= null) {
            sb.append("and t.num_doc_recep = ? ");
            parameters.put(index++, rucReceptor);
        }
        
        Retencion element;
        try {
            Query query = entityManager.createNativeQuery(sb.toString(), Retencion.class);
            
            // AÃ±adimos los parametros a la consulta
            parameters.entrySet().forEach((entry) -> {
                query.setParameter(entry.getKey(), entry.getValue());
            });
            
            element = (Retencion)query.getSingleResult();
        } catch ( NoResultException nre) {
            utilLog.imprimirLog(ConstantesUtils.LEVEL_ERROR, nre.getMessage());
            element = null;
        } catch (Exception e) {
            utilLog.imprimirLog(ConstantesUtils.LEVEL_ERROR, e.getMessage());
            element = null;
        }
        return element;
    }
    
    @SuppressWarnings("unchecked")
    @Override
    public List<RetDocRel> obtenerDetalleRetencion(ComprobantePK comprobantePK) {
        // Usamos un Map para almacenar los parametros de la consulta
        Map<Integer, Object> parameters = new HashMap<>();
        
        StringBuilder sb = new StringBuilder();
        sb.append("select * from t6574retdocrel t ");
        sb.append("where t.num_ruc = ? and t.cod_cpe = ? and t.num_serie_cpe = ? and t.num_cpe = ? ");
        
        //seteamos los parametros
        parameters.put(1, comprobantePK.getNumRuc());
        parameters.put(2, comprobantePK.getCodCpe());
        parameters.put(3, comprobantePK.getNumSerieCpe());
        parameters.put(4, comprobantePK.getNumCpe());
        
        List<RetDocRel> lst= new ArrayList<>();
        //List<PerDocRel> lista;
        try {    	
        	Query query = entityManager.createNativeQuery(sb.toString());  
                
                // AÃ±adimos los parametros a la consulta
                parameters.entrySet().forEach((entry) -> {
                    query.setParameter(entry.getKey(), entry.getValue());
                });
                
        	List<Object[]> rows  = query.getResultList();

        	for (Object[] row : rows) {
        		RetDocRel retDocRel = new RetDocRel();
        		RetDocRelPK retDocRelPK = new RetDocRelPK();
        		retDocRelPK.setNumRuc(row[0].toString());
        		retDocRelPK.setCodCpe(row[1].toString());
        		retDocRelPK.setNumSerieCpe(row[2].toString());
        		retDocRelPK.setNumCpe( Integer.parseInt(row[3].toString()));
        		retDocRel.setRetDocRelPK(retDocRelPK);
        		retDocRel.setCodTipCpeRel(row[4].toString());
        		retDocRel.setNumSerieCpeRel(row[5].toString());
        		retDocRel.setNumCpeRel(row[6].toString());
        		retDocRel.setNumPago(row[7].toString());
        		retDocRel.setFecEmiCpeRel((Date)row[8]);
        		retDocRel.setMtoTotalCpeRel((BigDecimal)row[9]);
        		retDocRel.setCodMonedaCpeRel(row[10].toString());
        		retDocRel.setFecPago((Date)row[11]);
        		retDocRel.setMtoPago((BigDecimal)row[12]);
        		retDocRel.setCodMonedaPago(row[13].toString());
        		retDocRel.setMtoRet((BigDecimal)row[14]);
        		retDocRel.setFecRet((Date)row[15]);
        		retDocRel.setMtoPagado((BigDecimal)row[16]);
        		retDocRel.setMtoTipCambio((BigDecimal)row[17]);
        		retDocRel.setIndCpeRelRev(row[18].toString());
        		retDocRel.setFecRegis((Date)row[19]);
        		retDocRel.setCodUsuRegis(row[20].toString());
        		retDocRel.setFecModif((Date)row[21]);
        		retDocRel.setCodUsuModif(row[22].toString());
        		      		
        		lst.add(retDocRel);      	
        	}

    
        } catch ( NoResultException | NumberFormatException nre) {
            utilLog.imprimirLog(ConstantesUtils.LEVEL_ERROR, nre.getMessage());
            lst = null;
        }
        return lst;
    }
    
    @Override
    public List<Retencion> obtenerComprobantesxFiltro(ComprobantePK comprobantePK,String fechaIni,String fechaFin,int NumIni,int NumFin,String codIdDoc,String numIdDoc,String codEstado) {
        List<Retencion> lista = new ArrayList<>();
        // Usamos un Map para almacenar los parametros de la consulta
        Map<Integer, Object> parameters = new HashMap<>();
        
        StringBuilder sb = new StringBuilder();

        sb.append("select "
        		+ " num_ruc,cod_tip_doc_recep,num_doc_recep,des_nom_recep,"
        		+ "cod_cpe,num_serie_cpe,num_cpe,fec_emi,fec_regis,cod_est_cpe,ind_procedencia,cod_reg_ret,"
        		+ "mto_total_pagado,mto_total_ret from t6573retencion t ");
        sb.append("where ");
        
        int index = 1;
        if ( comprobantePK.getNumRuc()!= null&& !comprobantePK.getNumRuc().isEmpty()) {
            sb.append("t.num_ruc = ? ");
            parameters.put(index++, comprobantePK.getNumRuc());
            if ( comprobantePK.getCodCpe()!= null) {
                sb.append("and t.cod_cpe = ? ");
                parameters.put(index++, comprobantePK.getCodCpe());
            }
        }else{
            if ( comprobantePK.getCodCpe()!= null) {
                sb.append("t.cod_cpe = ? ");
                parameters.put(index++, comprobantePK.getCodCpe());
            }
        }
        //ind_estado
        if ( codEstado!= null && !codEstado.isEmpty()) {
            if (!codEstado.equals(Constantes.COD_ESTADO_TODOS)) {
            sb.append("and t.cod_est_cpe = ? ");
            parameters.put(index++, codEstado);
            }
        }
        //cod_docide_recep
        if ( codIdDoc!= null && !codIdDoc.isEmpty()) {
            sb.append("and t.cod_tip_doc_recep in (?,?,?) " );
            parameters.put(index++, codIdDoc);
            parameters.put(index++, codIdDoc+" ");
            parameters.put(index++, "0"+codIdDoc);
        }
        //num_docide_recep
        if ( numIdDoc!= null) {
            sb.append("and t.num_doc_recep = ? ");
            parameters.put(index++, numIdDoc);
        }
        if ((NumIni>0 && NumFin>0) && (NumIni!=0 && NumFin!=0)) {
            sb.append("and t.num_cpe >= ? and t.num_cpe <= ? ");
            parameters.put(index++, NumIni);
            parameters.put(index++, NumFin);
        }
        if (comprobantePK.getNumSerieCpe()!=null){
            sb.append("and t.num_serie_cpe = ? ");
            parameters.put(index++, comprobantePK.getNumSerieCpe());
        }
        if (fechaIni != null && fechaFin != null) {
            DateTimeFormatter FORMATTER = DateTimeFormat.forPattern(Constantes.DATE_FORMAT);
            DateTime fechaInicio = FORMATTER.parseDateTime(fechaIni);
            LocalDate fechaInicioLocalDate = fechaInicio.toLocalDate();

            DateTime fechaFinal= FORMATTER.parseDateTime(fechaFin);
            LocalDate fechaFinalLocalDate = fechaFinal.toLocalDate();
            sb.append("and t.fec_emi >= ? and t.fec_emi <= ? ");
            parameters.put(index++, fechaInicioLocalDate.toString() + " 00:00:00");
            parameters.put(index++, fechaFinalLocalDate.toString() + " 23:59:59");
        }
        sb.append("order by t.fec_emi,t.fec_regis desc LIMIT ").append(Integer.parseInt(properties.getParamLimitInformix())+1);

        try {
            Query query = entityManager.createNativeQuery(sb.toString());
            
            // AÃ±adimos los parametros a la consulta
            parameters.entrySet().forEach((entry) -> {
                query.setParameter(entry.getKey(), entry.getValue());
            });
            
            List<Object[]> rows  = query.getResultList();
            for (Object[] row : rows) {
            	Retencion comprobante = new Retencion();
                RetencionPK compPK= new RetencionPK();
                compPK.setNumRuc(row[0].toString());
                comprobante.setCodTipoDocRecep(row[1].toString());
                comprobante.setNumDocRecep(row[2].toString());
                comprobante.setDesNomRecep(row[3].toString());
                compPK.setCodCpe(row[4].toString());
                compPK.setNumSerieCpe(row[5].toString());
                compPK.setNumCpe((int)row[6]);
                comprobante.setFecEmi((Date)row[7]);
                comprobante.setFecRegis((Date)row[8]);
                comprobante.setCodEstCpe(row[9].toString());
                comprobante.setIndProcedencia(row[10].toString());
                comprobante.setCodRegRet(row[11].toString());
                comprobante.setMtoTotalPagado((BigDecimal)row[12]);
                comprobante.setMtoTotalRet((BigDecimal)row[13]);
                comprobante.setRetencionPK(compPK);

                lista.add(comprobante);
            }
        } catch ( NoResultException nre) {
            utilLog.imprimirLog(ConstantesUtils.LEVEL_ERROR, nre.getMessage());
            lista = null;
        } catch (Exception e) {
            utilLog.imprimirLog(ConstantesUtils.LEVEL_ERROR, e.getMessage());
            lista = null;
        }
        return lista;
    }
    
}



package pe.gob.sunat.contribuyentems.servicio.consultacpe.consulta.retper.basebdcpe.dao.jpa;


import pe.gob.sunat.contribuyentems.servicio.consultacpe.consulta.retper.basebdcpe.ComprobantePK;
import pe.gob.sunat.contribuyentems.servicio.consultacpe.consulta.retper.basebdcpe.PerDocRel;
import pe.gob.sunat.contribuyentems.servicio.consultacpe.consulta.retper.basebdcpe.PerDocRelPK;
import pe.gob.sunat.contribuyentems.servicio.consultacpe.consulta.retper.basebdcpe.Percepcion;
import pe.gob.sunat.contribuyentems.servicio.consultacpe.consulta.retper.basebdcpe.PercepcionPK;
import pe.gob.sunat.contribuyentems.servicio.consultacpe.consulta.retper.basebdcpe.dao.PercepcionRepository;
import pe.gob.sunat.contribuyentems.servicio.consultacpe.consulta.retper.basebdrecauda.Param;
import pe.gob.sunat.contribuyentems.servicio.consultacpe.consulta.retper.main.config.PropertiesBean;
import pe.gob.sunat.contribuyentems.servicio.consultacpe.consulta.retper.util.Constantes;
import pe.gob.sunat.tecnologiams.arquitectura.framework.common.util.ConstantesUtils;
import pe.gob.sunat.tecnologiams.arquitectura.framework.core.util.UtilLog;
import pe.gob.sunat.tecnologiams.arquitectura.framework.jpa.dao.AbstractDao;

import javax.inject.Inject;
import javax.persistence.EntityManager;
import javax.persistence.NoResultException;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

import org.joda.time.DateTime;
import org.joda.time.LocalDate;
import org.joda.time.format.DateTimeFormat;
import org.joda.time.format.DateTimeFormatter;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;


public class PercepcionRepositoryImpl extends AbstractDao<Percepcion, PercepcionPK>  implements PercepcionRepository {
    @PersistenceContext(unitName = "dccpe")
    private EntityManager entityManager;

    @Inject
    private UtilLog utilLog;
    
    @Inject
    private PropertiesBean properties;
    
    public EntityManager getDccpe() {
        return this.entityManager;
    }
    @Override
    public EntityManager buildEntityManager() {
        return entityManager;
    }

    public static PercepcionRepositoryImpl forEntityManager(EntityManager entityManager) {
        PercepcionRepositoryImpl dao = new PercepcionRepositoryImpl();
        dao.entityManager = entityManager;
        dao.init();
        return dao;
    }


    @Override
    public Class<Percepcion> provideEntityClass() {
        return Percepcion.class;
    }
    @Override
    public Date obtenerFechaEmision(ComprobantePK comprobantePK, String rucReceptor) {
        // Usamos un Map para almacenar los parametros de la consulta
        Map<Integer, Object> parameters = new HashMap<>();
        
        StringBuilder sb = new StringBuilder();
        sb.append("select t.fec_emi from t6571percepcion t ");
        sb.append("where t.num_ruc = ? and t.cod_cpe = ? and t.num_serie_cpe = ? and t.num_cpe = ? ");
        
        //seteamos los parametros
        parameters.put(1, comprobantePK.getNumRuc());
        parameters.put(2, comprobantePK.getCodCpe());
        parameters.put(3, comprobantePK.getNumSerieCpe());
        parameters.put(4, comprobantePK.getNumCpe());        
        
        int index = 5;
        if (rucReceptor!= null) {
            sb.append("and t.num_doc_recep = ? ");
            parameters.put(index++, rucReceptor);
        }

        Date fecha;
        try {
            Query query = entityManager.createNativeQuery(sb.toString());
            
             // AÃ±adimos los parametros a la consulta
            parameters.entrySet().forEach((entry) -> {
                query.setParameter(entry.getKey(), entry.getValue());
            });
            
            fecha = (Date)query.getSingleResult();
        } catch ( NoResultException nre) {
            utilLog.imprimirLog(ConstantesUtils.LEVEL_ERROR, nre.getMessage());
            fecha = null;
        } catch (Exception e) {
            utilLog.imprimirLog(ConstantesUtils.LEVEL_ERROR, e.getMessage());
            fecha = null;
        }
        return  fecha;
    }
    @Override
    public Percepcion obtenerComprobante(ComprobantePK comprobantePK, String rucReceptor) {
        // Usamos un Map para almacenar los parametros de la consulta
        Map<Integer, Object> parameters = new HashMap<>();
        StringBuilder sb = new StringBuilder();
        sb.append("select * from t6571percepcion t ");
        sb.append("where t.num_ruc = ? and t.cod_cpe = ? and t.num_serie_cpe = ? and t.num_cpe = ? ");
        
        //seteamos los parametros
        parameters.put(1, comprobantePK.getNumRuc());
        parameters.put(2, comprobantePK.getCodCpe());
        parameters.put(3, comprobantePK.getNumSerieCpe());
        parameters.put(4, comprobantePK.getNumCpe());        
        
        int index = 5;
        if (rucReceptor!= null) {
            sb.append("and t.num_doc_recep = ? ");
            parameters.put(index++, rucReceptor);
        }
        Percepcion element;
        try {
            Query query = entityManager.createNativeQuery(sb.toString(), Percepcion.class);
            
             // AÃ±adimos los parametros a la consulta
            parameters.entrySet().forEach((entry) -> {
                query.setParameter(entry.getKey(), entry.getValue());
            });
            
            element = (Percepcion)query.getSingleResult();
        } catch ( NoResultException nre) {
            utilLog.imprimirLog(ConstantesUtils.LEVEL_ERROR, nre.getMessage());
            element = null;
        } catch (Exception e) {
            utilLog.imprimirLog(ConstantesUtils.LEVEL_ERROR, e.getMessage());
            element = null;
        }
        return element;
    }
    
    @Override
    public List<PerDocRel> obtenerDetallePercepcion(ComprobantePK comprobantePK) {
        // Usamos un Map para almacenar los parametros de la consulta
        Map<Integer, Object> parameters = new HashMap<>();
        
        StringBuilder sb = new StringBuilder();
        sb.append("select * from t6572perdocrel t ");
        sb.append("where t.num_ruc = ? and t.cod_cpe = ? and t.num_serie_cpe = ? and t.num_cpe = ? ");
        
        //seteamos los parametros
        parameters.put(1, comprobantePK.getNumRuc());
        parameters.put(2, comprobantePK.getCodCpe());
        parameters.put(3, comprobantePK.getNumSerieCpe());
        parameters.put(4, comprobantePK.getNumCpe());
        
        List<PerDocRel> lst= new ArrayList<>();
        try {    	
        	Query query = entityManager.createNativeQuery(sb.toString());  
                
                 // AÃ±adimos los parametros a la consulta
                    parameters.entrySet().forEach((entry) -> {
                        query.setParameter(entry.getKey(), entry.getValue());
                    });
            
        	List<Object[]> rows  = query.getResultList();

        	for (Object[] row : rows) {
        		PerDocRel perDocRel = new PerDocRel();
        		PerDocRelPK perDocRelPK = new PerDocRelPK();
        		perDocRelPK.setNumRuc(row[0].toString());
        		perDocRelPK.setCodCpe(row[1].toString());
        		perDocRelPK.setNumSerieCpe(row[2].toString());
        		perDocRelPK.setNumCpe( Integer.parseInt(row[3].toString()));
        		perDocRel.setPerDocRelPK(perDocRelPK);
        		perDocRel.setCodTipCpeRel(row[4].toString());
        		perDocRel.setNumSerieCpeRel(row[5].toString());
        		perDocRel.setNumCpeRel(row[6].toString());
        		perDocRel.setNumPago(row[7].toString());
        		perDocRel.setFecEmiCpeRel((Date)row[8]);
        		perDocRel.setMtoTotalCpeRel((BigDecimal)row[9]);
        		perDocRel.setCodMonedaCpeRel(row[10].toString());
        		perDocRel.setFecPago((Date)row[11]);
        		perDocRel.setMtoPago((BigDecimal)row[12]);
        		perDocRel.setCodMonedaPago(row[13].toString());
        		perDocRel.setMtoPer((BigDecimal)row[14]);
        		perDocRel.setFecPer((Date)row[15]);
        		perDocRel.setMtoCobrado((BigDecimal)row[16]);
        		perDocRel.setIndTipCalculo(row[17].toString());
        		perDocRel.setMtoTipCambio((BigDecimal)row[18]);
        		perDocRel.setIndCpeRelRev(row[19].toString());
        		perDocRel.setFecRegis((Date)row[20]);
        		perDocRel.setCodUsuRegis(row[21].toString());
        		perDocRel.setFecModif((Date)row[22]);
        		perDocRel.setCodUsuModif(row[23].toString());
        		      		
        		lst.add(perDocRel);      	
        	}

    
        } catch ( NoResultException nre) {
            utilLog.imprimirLog(ConstantesUtils.LEVEL_ERROR, nre.getMessage());
            lst = null;
        } catch (Exception e) {
            utilLog.imprimirLog(ConstantesUtils.LEVEL_ERROR, e.getMessage());
            lst = null;
        }
        return lst;
    }
    
    @Override
    public List<Percepcion> obtenerComprobantesxFiltro(ComprobantePK comprobantePK,String fechaIni,String fechaFin,int NumIni,int NumFin,String codIdDoc,String numIdDoc,String codEstado) {
        List<Percepcion> lista = new ArrayList<>();
        // Usamos un Map para almacenar los parametros de la consulta
        Map<Integer, Object> parameters = new HashMap<>();
        
        StringBuilder sb = new StringBuilder();

        sb.append("select "
        		+ " num_ruc,cod_tip_doc_recep,num_doc_recep,des_nom_recep,"
        		+ "cod_cpe,num_serie_cpe,num_cpe,fec_emi,fec_regis,cod_est_cpe,ind_procedencia,cod_reg_per,mto_total_cobrado,mto_total_per from t6571percepcion t ");
        sb.append("where ");
        
        int index = 1;
        if ( comprobantePK.getNumRuc()!= null&& !comprobantePK.getNumRuc().isEmpty()) {
            sb.append("t.num_ruc = ? ");
            parameters.put(index++, comprobantePK.getNumRuc());
            if ( comprobantePK.getCodCpe()!= null) {
                sb.append("and t.cod_cpe = ? ");
                parameters.put(index++, comprobantePK.getCodCpe());
            }
        }else{
            if ( comprobantePK.getCodCpe()!= null) {
                sb.append("t.cod_cpe = ? ");
                parameters.put(index++, comprobantePK.getCodCpe());
            }
        }

        //ind_estado
        if ( codEstado!= null && !codEstado.isEmpty()) {
            if (!codEstado.equals(Constantes.COD_ESTADO_TODOS)) {
            sb.append("and t.cod_est_cpe = ? ");
            parameters.put(index++, codEstado);
            }
        }
        //cod_docide_recep
        if ( codIdDoc!= null && !codIdDoc.isEmpty()) {
            sb.append("and t.cod_tip_doc_recep in (?,?,?) " );
            parameters.put(index++, codIdDoc);
            parameters.put(index++, codIdDoc+" ");
            parameters.put(index++, "0"+codIdDoc);
        }
        //num_docide_recep
        if ( numIdDoc!= null) {
            sb.append("and t.num_doc_recep = ? ");
            parameters.put(index++, numIdDoc);
            
        }
        if ((NumIni>0 && NumFin>0 ) && (NumIni!=0 && NumFin!=0)) {
            sb.append("and t.num_cpe >= ? and t.num_cpe <= ? ");
            parameters.put(index++, NumIni);
            parameters.put(index++, NumFin);
        }
        
        if (comprobantePK.getNumSerieCpe() != null) {
        	sb.append("and t.num_serie_cpe = ? ");
                parameters.put(index++, comprobantePK.getNumSerieCpe());
        } 

        if (fechaIni != null && fechaFin != null) {
            DateTimeFormatter FORMATTER = DateTimeFormat.forPattern(Constantes.DATE_FORMAT);
            DateTime fechaInicio = FORMATTER.parseDateTime(fechaIni);
            LocalDate fechaInicioLocalDate = fechaInicio.toLocalDate();

            DateTime fechaFinal= FORMATTER.parseDateTime(fechaFin);
            LocalDate fechaFinalLocalDate = fechaFinal.toLocalDate();
            sb.append("and t.fec_emi >= ? and t.fec_emi <= ? ");
            parameters.put(index++, fechaInicioLocalDate.toString() + " 00:00:00");
            parameters.put(index++, fechaFinalLocalDate.toString() + " 23:59:59");
        }
        
        sb.append("order by t.fec_emi,t.fec_regis desc LIMIT ").append(Integer.parseInt(properties.getParamLimitInformix())+1);

        try {
            Query query = entityManager.createNativeQuery(sb.toString());
            
             // AÃ±adimos los parametros a la consulta
            parameters.entrySet().forEach((entry) -> {
                query.setParameter(entry.getKey(), entry.getValue());
            });
            
            List<Object[]> rows  = query.getResultList();
            for (Object[] row : rows) {
            	Percepcion comprobante = new Percepcion();
                PercepcionPK compPK= new PercepcionPK();
                compPK.setNumRuc(row[0].toString());
                comprobante.setCodTipoDocRecep(row[1].toString());
                comprobante.setNumDocRecep(row[2].toString());
                comprobante.setDesNomRecep(row[3].toString());
                compPK.setCodCpe(row[4].toString());
                compPK.setNumSerieCpe(row[5].toString());
                compPK.setNumCpe((int)row[6]);
                comprobante.setFecEmi((Date)row[7]);
                comprobante.setFecRegis((Date)row[8]);
                comprobante.setCodEstCpe(row[9].toString());
                comprobante.setIndProcedencia(row[10].toString());
                comprobante.setCodRegPer(row[11].toString());
                comprobante.setMtoTotalCobrado((BigDecimal)row[12]);
                comprobante.setMtoTotalPer((BigDecimal)row[13]);
                comprobante.setPercepcionPK(compPK);

                lista.add(comprobante);
            }
        } catch ( NoResultException nre) {
            utilLog.imprimirLog(ConstantesUtils.LEVEL_ERROR, nre.getMessage());
            lista = null;
        } catch (Exception e) {
            utilLog.imprimirLog(ConstantesUtils.LEVEL_ERROR, e.getMessage());
            lista = null;
        }
        return lista;
    }
    
    
     
}

