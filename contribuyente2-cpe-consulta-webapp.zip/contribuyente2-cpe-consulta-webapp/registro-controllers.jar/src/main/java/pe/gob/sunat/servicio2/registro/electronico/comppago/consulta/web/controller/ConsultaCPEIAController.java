package pe.gob.sunat.servicio2.registro.electronico.comppago.consulta.web.controller;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.InputStream;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.TreeMap;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.mvc.multiaction.MultiActionController;
import org.springframework.web.servlet.view.InternalResourceView;
import org.springframework.web.util.WebUtils;

import pe.gob.sunat.framework.core.pattern.ServiceLocator;
import pe.gob.sunat.framework.spring.bean.ResponseBean;
import pe.gob.sunat.framework.spring.util.bean.MensajeBean;
import pe.gob.sunat.framework.spring.util.exception.ServiceException;
import pe.gob.sunat.framework.spring.web.util.JsonUtil;
import pe.gob.sunat.framework.util.Propiedades;
import pe.gob.sunat.framework.util.io.factory.DescargaFactory;
import pe.gob.sunat.framework.util.io.interfaz.Descarga;
import pe.gob.sunat.servicio2.registro.electronico.comppago.consulta.service.ConsultaCPEService;
import pe.gob.sunat.servicio2.registro.electronico.comppago.factura.consultar.bean.ConsultarFacturaBean;
import pe.gob.sunat.tecnologia.menu.bean.UsuarioBean;


/**
 * <p>Description: Clase Controladora de la consulta de comprobantes de pago electronicos.</p>
 * @author jchuquitaype
 */
@SuppressWarnings({"rawtypes", "unchecked"})
public class ConsultaCPEIAController extends MultiActionController {
protected final Log log = LogFactory.getLog(getClass());
	
	private ConsultaCPEService consultarService;
	private String view;
	private String iframeJsonView;
	private String downloadView;

	
	/**
	 * Carga la pantalla inicial de la consulta de factura electronica.	
	 * */
	public ModelAndView inicio(HttpServletRequest request, HttpServletResponse response) {
		if(log.isInfoEnabled()) log.info(">> inicio :: Ingresa formulario de consulta Factura Notas en Intranet.");
		try {
			UsuarioBean usuarioBean = (UsuarioBean) WebUtils.getSessionAttribute(request, "usuarioBean");
			log.debug("usuarioBean: " + usuarioBean.getNumRUC());
			request.getSession().removeAttribute("printLista");
			request.getSession().removeAttribute("lstFacturas");
			
			return new ModelAndView("ConsultaPrincipal"); // Interfase
		} catch(ServiceException e) {
			log.error(e);
			MensajeBean msg = (e.getMensaje()!=null ? e.getMensaje() : new MensajeBean());
			if (!msg.isError()) {
				request.setAttribute("beanM", msg);
				return new ModelAndView("PagM");
			} else {
				request.setAttribute("beanErr", msg);
				return new ModelAndView("PagE");
			}
		} catch(Exception e) {
			log.error(e);
			MensajeBean msg = new MensajeBean();
			msg.setMensajeerror("Se present� un error al momento de ejecutar la aplicaci�n.  Por favor intente nuevamente.");
			request.setAttribute("beanErr", msg);
			return new ModelAndView("PagE");
		}
	}
	
	public ModelAndView mostrarCriterios(HttpServletRequest request, HttpServletResponse response) {
		log.info("iniciando mostrarCriterios");
		return new ModelAndView("ConsultaCriterios"); // Interfase
	}
	
	
	public ModelAndView mostrarListado(HttpServletRequest request, HttpServletResponse response) {
		log.info("iniciando mostrarListado");
		Map <String, Object> inputParms = (TreeMap <String, Object>) WebUtils.getParametersStartingWith(request, null);
		
		Map <String, String> params = MapParamUtil.objectMapToStringMap(inputParms);
		
				
		ModelAndView modelView = null;  
		if ("10".equals(params.get("tipoConsulta"))) {
			modelView = new ModelAndView("ConsultaListadoEmitidos"); // Interfase			
		} 
		else if ("11".equals(params.get("tipoConsulta"))) {
			modelView = new ModelAndView("ConsultaListadoRecibidos"); // Interfase
		}
		else if ("12".equals(params.get("tipoConsulta"))) {
			modelView = new ModelAndView("ConsultaListadoRechazados"); // Interfase
		}
		// opciones  agregadas para las consultas de notas de  credito y debito  el 23-11-2010  NAA
		else if ("13".equals(params.get("tipoConsulta"))) {
			modelView = new ModelAndView("ConsultaListadoNCEmitidos"); // Interfase
		}
		else if ("14".equals(params.get("tipoConsulta"))) {
			modelView = new ModelAndView("ConsultaListadoNCRecibidos"); // Interfase
		}
		else if ("15".equals(params.get("tipoConsulta"))) {
			modelView = new ModelAndView("ConsultaListadoNDEmitidos"); // Interfase
		}
		else if ("16".equals(params.get("tipoConsulta"))) {
			modelView = new ModelAndView("ConsultaListadoNDRecibidos"); // Interfase
		}
		else if ("17".equals(params.get("tipoConsulta"))) {
			modelView = new ModelAndView("ConsultaListadoBVEEmitidos"); // Interfase
		}
		else if ("18".equals(params.get("tipoConsulta"))) {
			modelView = new ModelAndView("ConsultaListadoBVERecibidos"); // Interfase
		}
		else if ("20".equals(params.get("tipoConsulta"))) {
			modelView = new ModelAndView("ConsultaListadoNCBVEEmitidos"); // Interfase
		}
		else if ("21".equals(params.get("tipoConsulta"))) {
			modelView = new ModelAndView("ConsultaListadoNCBVERecibidos"); // Interfase
		}
		else if ("22".equals(params.get("tipoConsulta"))) {
			modelView = new ModelAndView("ConsultaListadoNDBVEEmitidos"); // Interfase
		}
		else if ("23".equals(params.get("tipoConsulta"))) {
			modelView = new ModelAndView("ConsultaListadoNDBVERecibidos"); // Interfase
		}
		log.info("view seleccionado:"+ modelView.getViewName());
		return modelView;
	}	
	
	/**
	 *  Ejecuta la consulta de factura electronica.
	 * @author Erick Cavalie Garay
	 * @since 10/05/2010
	 * */
	//
	public ModelAndView realizarConsulta(HttpServletRequest request, HttpServletResponse response) {
				
		ResponseBean res = new ResponseBean(0);
		try {
			
			//Map <String, Object> filtro = (TreeMap <String, String>) WebUtils.getParametersStartingWith(request, null);
			
			Map <String, Object> inputParms = (TreeMap <String, Object>) WebUtils.getParametersStartingWith(request, null);
			
			Map <String, String> filtro = MapParamUtil.objectMapToStringMap(inputParms);
			
			if(log.isInfoEnabled()) log.info(">> realizarConsulta :: Factura Notas en Intranet. \n Parametros "+filtro);

			List <ConsultarFacturaBean> lista = consultarService.ejecutarConsulta(filtro);
			
			if(log.isDebugEnabled()) log.debug(">> resultado de la consulta [" + lista.size() + "] : " + lista);
			
			request.getSession().setAttribute("lstFacturas", lista);
			
			if(lista.size() > 0) {				
				res.setData(lista, JsonUtil.getJsonNoNameVar("responseConsulta"));
			} else {
				String   tipo = filtro.get("tipoConsulta"); 
				int   xtipo= 0; 
				if (tipo!=null){
					xtipo =  Integer.parseInt(tipo); 
				}
				if ( xtipo==10 || xtipo==11 ||  xtipo==12){
					res.setCodeAndMessageError(1, "No existen Facturas Electronicas con los criterios seleccionados.");
				}else if ( xtipo==13 ||   xtipo==14){
					res.setCodeAndMessageError(1, "No existen Notas de Credito con los criterios seleccionados.");
				}else if ( xtipo==15 ||   xtipo==16){
					res.setCodeAndMessageError(1, "No existen Notas de Debito con los criterios seleccionados.");
				}else if ( xtipo==17 || xtipo==18){
					res.setCodeAndMessageError(1, "No existen Boletas de Venta con los criterios seleccionados.");
				}else if ( xtipo==20 ||   xtipo==21){
					res.setCodeAndMessageError(1, "No existen Notas de Cr�dito con los criterios seleccionados.");
				}else if ( xtipo==22 ||   xtipo==23){
					res.setCodeAndMessageError(1, "No existen Notas de D�bito con los criterios seleccionados.");
				}else {
					res.setCodeAndMessageError(1, "No existen Facturas Electronicas con los criterios seleccionados.");
				}
			}
		} catch(ServiceException e) {
			log.error(e.toString());			
			res.setCodeAndMessageError(1, e.getMessage());
		} catch(Exception e) {
			log.error(e.toString());
			res.setCodeAndMessageError(2, e.getLocalizedMessage());
		}
		return new ModelAndView(this.iframeJsonView, "datamodel", res);
	}

	
	public ModelAndView imprimirListado(HttpServletRequest request, HttpServletResponse response) {
		log.info("Imprime el listado Factura Electronica");
		//Map <String, String> params = (TreeMap <String, String>) WebUtils.getParametersStartingWith(request, null);
		Map <String, Object> inputParms = (TreeMap <String, Object>) WebUtils.getParametersStartingWith(request, null);
		
		Map <String, String> params = MapParamUtil.objectMapToStringMap(inputParms);
		request.getSession().setAttribute("printLista", params);

		if (log.isDebugEnabled()){log.debug("params: " + params);}

		return new ModelAndView("ConsultaListadoImprimir"); // Interfase
	}
	
	public ModelAndView validarRUC(HttpServletRequest request, HttpServletResponse response) {
		log.info("Valida el numero de ruc ingresado.");
		ResponseBean res = new ResponseBean(0);
		try {
//			UsuarioBean usuarioBean = (UsuarioBean) WebUtils.getSessionAttribute(request, "usuarioBean");

	        String nroRUC = request.getParameter("nroRUC");
			log.debug("nroRUC : " + nroRUC);
			res.setData(consultarService.verificarRUC(nroRUC).getDdp_nombre().trim());

//			if (!nroRUC.trim().equals(usuarioBean.getNumRUC().trim())) {
//				res.setData(consultarService.verificarRUC(nroRUC).getDdp_nombre().trim());
//			} else {
//				throw new ServiceException(this, "RUC ingresado no puede ser igual que RUC SOL.");
//			}			
		} catch(ServiceException e) {
			log.debug("Error: ", e);
			res.setCodeAndMessageError(1, e.getLocalizedMessage());
		} catch(Exception e) {
			log.debug("Error: ", e);
			res.setCodeAndMessageError(2, e.getLocalizedMessage());
		}
		return new ModelAndView(this.view, "datamodel", res);
	}
	
	
	public ModelAndView descargarFactura(HttpServletRequest request, HttpServletResponse response) {
		log.info("Descarga el comprobante");
		MensajeBean msgErr = new MensajeBean();
		try {
			//Map <String, String> params = (TreeMap <String, String>) WebUtils.getParametersStartingWith(request, null);
			
			Map <String, Object> inputParms = (TreeMap <String, Object>) WebUtils.getParametersStartingWith(request, null);
			
			Map <String, String> params = MapParamUtil.objectMapToStringMap(inputParms);

			log.debug("params: " + params);
			
			/** FACTURAE001-NNNRRRRRRRRRRR.zip*/
			/** BOLETAEB01-NNNRRRRRRRRRRR.zip*/
			String nombre = "FACTURA"; 
			if ( params.get("tipo").equals("13")){
				nombre = "NOTA_CREDITO"; 
			}
			if ( params.get("tipo").equals("15")){
				nombre = "NOTA_DEBITO"; 
			}
			if ( params.get("tipo").equals("17")){
				nombre = "BOLETA"; 
			}
			if ( params.get("tipo").equals("20")){
				nombre = "NOTA_CREDITO";
			}
			if ( params.get("tipo").equals("22")){
				nombre = "NOTA_DEBITO";
			}
			
			String fileName = nombre + 
				params.get("serie").toString() + "-" +
				params.get("numero").toString().trim() +
				params.get("ruc").toString() + ".zip";				
			
			log.debug("nombre file: " + fileName);
			
			//Para facturas, NDs, NCs de factura
			if (!params.get("tipo").equals("17") &&
				!params.get("tipo").equals("20") &&
				!params.get("tipo").equals("22")){
				pe.gob.sunat.servicio2.registro.electronico.comppago.factura.bean.ArchivoComprobanteBean archivo = consultarService.descargarFactura(params);
				
				if(archivo != null) {
					Map mres = new HashMap();
					mres.put("fileName", fileName);
					mres.put("dataBytes", archivo.getContenidoArchivoZip());
					return new ModelAndView(this.downloadView, "datamodel", mres);
				} else {                 
					throw new ServiceException(this, "No se encontro el archivo del comprobante");
				}
			}
			//Para boletas
			else{
				pe.gob.sunat.servicio2.registro.electronico.comppago.boleta.bean.ArchivoComprobanteBean archivo = consultarService.descargarBoleta(params);
				
				if(archivo != null) {
					Map mres = new HashMap();
					mres.put("fileName", fileName);
					mres.put("dataBytes", archivo.getContenidoArchivoZip());
					return new ModelAndView(this.downloadView, "datamodel", mres);
				} else {                 
					throw new ServiceException(this, "No se encontro el archivo del comprobante");
				}
			}
		} catch(ServiceException e) {
            log.error(e);
            msgErr.setMensajeerror(e.getLocalizedMessage());
            msgErr.setMensajesol("Por favor comuniquese con el webmaster para comunicarle el problema.");
            request.setAttribute("beanErr", msgErr);
		} catch(Exception e) {
            log.error(e);
            msgErr.setMensajeerror(e.getLocalizedMessage());
            msgErr.setMensajesol("Por favor comuniquese con el webmaster para comunicarle el problema.");
            request.setAttribute("beanErr", msgErr);
		}
		return new ModelAndView(new InternalResourceView("PagE"));
	}
	
	
	public ModelAndView verImprimirFactura(HttpServletRequest request, HttpServletResponse response) {
		log.info("Cargando pantalla de impresion de comprobante");
		try {
			
			//Map <String, String> params = (TreeMap <String, String>) WebUtils.getParametersStartingWith(request, null);
			
			Map <String, Object> inputParms = (TreeMap <String, Object>) WebUtils.getParametersStartingWith(request, null);
			
			Map <String, String> params = MapParamUtil.objectMapToStringMap(inputParms);
			
			String  xtipo = params.get("tipo"); 
			String  xvista = "ConsultaFacturaImprimir"; 
			if  (xtipo!=null  &&   xtipo.equals("10")||xtipo.equals("11")||xtipo.equals("12") ){
				xvista ="ConsultaFacturaImprimir"; 
			}
			if  (xtipo!=null  &&   xtipo.equals("13")||xtipo.equals("14") ){
				xvista ="ConsultaNCImprimir"; 
			}
			if  (xtipo!=null  &&   xtipo.equals("15")||xtipo.equals("16") ){
				xvista ="ConsultaNDImprimir"; 
			}
			if  (xtipo!=null  &&   xtipo.equals("17")||xtipo.equals("18") ){
				xvista ="ConsultaBVEImprimir"; 
			}
			if  (xtipo!=null  &&   xtipo.equals("20")||xtipo.equals("21") ){
				xvista ="ConsultaNCBVEImprimir"; 
			}
			if  (xtipo!=null  &&   xtipo.equals("22")||xtipo.equals("23") ){
				xvista ="ConsultaNDBVEImprimir"; 
			}
			
			if(log.isInfoEnabled())log.info(">> verImprimirFactura :: params=" + params );
			log.debug("vista: "+ xvista);
			//Para facturas, NDs, NCs de factura
			if (!xtipo.equals("17") &&
				!xtipo.equals("20") && 
				!xtipo.equals("22")){
				pe.gob.sunat.servicio2.registro.electronico.comppago.factura.bean.ComprobanteBean bean = consultarService.recuperarInfoFactura(params);
				request.getSession().setAttribute("comprobante", bean);
			}
			//Para boletas
			else{
				pe.gob.sunat.servicio2.registro.electronico.comppago.boleta.bean.ComprobanteBean bean = consultarService.recuperarInfoBoleta(params);
				request.getSession().setAttribute("comprobante", bean);
			}
			
			return new ModelAndView(xvista); // Interfase
			
			//return new ModelAndView("ConsultaFacturaImprimir"); // Interfase					
		} catch(ServiceException e) {
			log.error(e);
			MensajeBean msg = (e.getMensaje()!=null ? e.getMensaje() : new MensajeBean());
			if (!msg.isError()) {
				request.setAttribute("beanM", msg);
				return new ModelAndView("PagM");
			} else {
				request.setAttribute("beanErr", msg);
				return new ModelAndView("PagE");
			}
		} catch(Exception e) {
			log.error(e);
			MensajeBean msg = new MensajeBean();
			msg.setMensajeerror("Se present� un error al momento de ejecutar la aplicaci�n. Por favor intente nuevamente.");
			request.setAttribute("beanErr", msg);
			return new ModelAndView("PagE");
		}
	}	

	public ModelAndView descargarPDF(HttpServletRequest request, HttpServletResponse response){
		//ResponseBean res = new ResponseBean(0);
		log.info("Descarga el PDF");
		MensajeBean msgErr = new MensajeBean();
		//UsuarioBean usuarioBean = (UsuarioBean) WebUtils.getSessionAttribute(request, "usuarioBean");
		//Map <String, String> params = (TreeMap <String, String>) WebUtils.getParametersStartingWith(request, null);
		
		Map <String, Object> inputParms = (TreeMap <String, Object>) WebUtils.getParametersStartingWith(request, null);
		
		Map <String, String> params = MapParamUtil.objectMapToStringMap(inputParms);

		log.debug("params: " + params);

		Propiedades prop = new Propiedades(getClass(),"/reporte.properties");
		String nombrePDF = prop.leePropiedad("pdfTaxFreeRutaOutput") + params.get("nombrePDF");
		if (log.isDebugEnabled()) {log.debug("mostrarTaxFree PDF");}
		int nRead;
		byte[] contenidoPDF= new byte[16384];
		ByteArrayOutputStream buffer = new ByteArrayOutputStream();
		try {
			Descarga descarga = new DescargaFactory().getDescargador(DescargaFactory.FISCALIZACION,0);
			
			Map data = descarga.descargar(ServiceLocator.getInstance().
					getDataSource("jdbc/dcrfisca"),new Integer(params.get("idPDF")));
						
			File oldFile = new File(data.get("arc_datos").toString());
			File newFile = new File( nombrePDF);
			oldFile.renameTo(newFile);

			File fArchivo = new File(nombrePDF);
			InputStream archivo = new FileInputStream(fArchivo);             

			while ((nRead = archivo.read(contenidoPDF, 0, contenidoPDF.length)) != -1) {
			  buffer.write(contenidoPDF, 0, nRead);
			}
			buffer.flush();
			archivo.close();
		} catch(ServiceException e) {
            log.error(e);
            msgErr.setMensajeerror(e.getLocalizedMessage());
            msgErr.setMensajesol("Por favor comuniquese con el webmaster para comunicarle el problema.");
            request.setAttribute("beanErr", msgErr);
		} catch(Exception e) {
            log.error(e);
            msgErr.setMensajeerror(e.getLocalizedMessage());
            msgErr.setMensajesol("Por favor comuniquese con el webmaster para comunicarle el problema.");
            request.setAttribute("beanErr", msgErr);
		}
		//return new ModelAndView(new InternalResourceView("http://wssunat:8080/cl-at-framework-unloadfile/descargaArchivoAlias?data0_sis_id=1000&data0_num_id=".concat((comprobante.getNumeroFirma()).toString())) );
		Map mres = new HashMap();
		mres.put("fileName", params.get("nombrePDF"));
		mres.put("dataBytes", buffer.toByteArray());
		return new ModelAndView(this.downloadView, "datamodel", mres);
	}
	
	public ModelAndView dataCriterios(HttpServletRequest request, HttpServletResponse response) {
		ResponseBean res = new ResponseBean(0);
		request.getSession().removeAttribute("printLista");
		request.getSession().removeAttribute("lstFacturas");

		return new ModelAndView(this.view, "datamodel", res);
	}
	
	public ModelAndView backCriterios(HttpServletRequest request, HttpServletResponse response) {
		log.info("Cargando pantalla ingreso de criterios - back");
		return new ModelAndView("ConsultaCriterios"); // Interfase
	}
	
	//GETTERS AND SETTERS//
	public void setView(String view) {
		this.view = view;
	}

	public String getView() {
		return this.view;
	}

	public String getIframeJsonView() {
		return iframeJsonView;
	}

	public void setIframeJsonView(String iframeJsonView) {
		this.iframeJsonView = iframeJsonView;
	}	
	
	public String getDownloadView() {
		return downloadView;
	}

	public void setDownloadView(String downloadView) {
		this.downloadView = downloadView;
	}

	public void setConsultarService(ConsultaCPEService consultarService) {
		this.consultarService = consultarService;
	}	
	
}
