package pe.gob.sunat.servicio2.registro.electronico.comppago.consulta.web.controller;

import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.TreeMap;

import com.fasterxml.jackson.databind.ObjectMapper;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.lang.StringUtils;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.apache.log4j.NDC;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.ServletRequestUtils;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.mvc.multiaction.MultiActionController;
import org.springframework.web.util.WebUtils;
import org.springframework.web.client.RestTemplate;

import net.sf.jasperreports.engine.JRException;
import net.sf.jasperreports.engine.JasperCompileManager;
import net.sf.jasperreports.engine.JasperExportManager;
import net.sf.jasperreports.engine.JasperFillManager;
import net.sf.jasperreports.engine.JasperPrint;
import net.sf.jasperreports.engine.JasperReport;
import net.sf.jasperreports.engine.data.JRBeanCollectionDataSource;
import net.sf.jasperreports.engine.data.JRMapArrayDataSource;
import net.sf.jasperreports.engine.design.JasperDesign;
import net.sf.jasperreports.engine.xml.JRXmlLoader;
import pe.gob.sunat.framework.spring.util.bean.MensajeBean;
import pe.gob.sunat.framework.spring.util.exception.ServiceException;
import pe.gob.sunat.servicio2.registro.electronico.comppago.consulta.service.ValidaComprobanteContingenciaService;
import pe.gob.sunat.servicio2.registro.electronico.comppago.consulta.service.ValidaCoprobanteElectronicoService;


/**
 * <p>Description: Clase Controladora de la consulta de de validez del comprobante de pago electronico, Mogrado desde Recibo por Honorarios electronicos.</p>
 * @author jchuquitaype
 */
@SuppressWarnings({"rawtypes"})
public class ConsultaValidezCPEController extends MultiActionController {
	
	private static final Log log = LogFactory.getLog(ConsultaValidezCPEController.class);
	private ValidaComprobanteContingenciaService validaCPCService;
	private String downloadView;	
	private ValidaCoprobanteElectronicoService validaCPEService;
	
	public static final String SERVICIO_VALIDA_CAPTCHA_V3 = "http://sunatti.k8s.sunat.peru/v1/tecnologia/controlacceso/t/recaptcha3/verificar";
	                                                     
	
	
	public ValidaComprobanteContingenciaService getValidaCPCService() {
		return validaCPCService;
	}
	public void setValidaCPCService(
			ValidaComprobanteContingenciaService validaCPCService) {
		this.validaCPCService = validaCPCService;
	}
	public ValidaCoprobanteElectronicoService getValidaCPEService() {
		return validaCPEService;
	}	
	public void setValidaCPEService(
			ValidaCoprobanteElectronicoService validaCPEService) {
		this.validaCPEService = validaCPEService;
	}	
	public String getDownloadView() {
		return downloadView;
	}
	public void setDownloadView(String downloadView) {
		this.downloadView = downloadView;
	}	


	/**
	 * Muestra la pantalla inicial. 
	 * @param request
	 * @param response
	 * @return
	 */
	public ModelAndView mostrarForm(HttpServletRequest request,
			HttpServletResponse response) {
		ModelAndView modelAndView = null ; 
		try {			
			modelAndView = new ModelAndView("consultavalidez1");			
		} catch (ServiceException ex) {
			MensajeBean msb = new MensajeBean(); 
			msb.setError(true);
			msb.setMensajeerror("Error al ingresar al formulario.  ");
			modelAndView = new ModelAndView("PagE");
			modelAndView.addObject("beanErr", msb);
		} catch (Exception ex) {
			MensajeBean msb = new MensajeBean(); 
			msb.setError(true);
			msb.setMensajeerror("Error al ingresar al formulario.");
			modelAndView = new ModelAndView("PagE");
			modelAndView.addObject("beanErr", msb);
		}finally{
			NDC.pop();
			NDC.remove();
		}
		return modelAndView ; 
	}
	/**
	 * Metodo migrado desde Arquitectura I
	 * @param request
	 * @param response
	 * @return
	 */
	public ModelAndView CapturaCriterioValidez(HttpServletRequest request, HttpServletResponse response){
		ModelAndView modelAndView = null ;
		if(log.isDebugEnabled()) log.debug("ConsultaValidezCPEController.CapturaCriterioValidez - Inic");

		try {
		//String codigo = ServletRequestUtils.getStringParameter(request, "codigo") ;
		
		//INICIO VALIDAR GOOGLE CAPTCHA
        String codigo = null;
        log.debug("INICIO VALIDAR GOOGLE CAPTCHA 1");
    	String token = request.getParameter("token");
    	
    	if(StringUtils.isNotBlank(token)){
    		   boolean captchaValidoBool  = validarCaptchaV3(token);
    		   //boolean captchaValidoBool  = true;
    		   if(captchaValidoBool){
    			   
    			   if(log.isDebugEnabled())log.debug("INICIO VALIDAR GOOGLE CAPTCHA VALIDACION EXITOSA ");
    			    codigo = "true";
    		  }
    	}

    	if(log.isDebugEnabled()) log.debug("token --> "+ token);
    	if(log.isDebugEnabled()) log.debug("codigo --> "+ codigo);
    	
    	// FIN VALIDAR GOOGLE CAPTCHA
        
		
		if(codigo == null && StringUtils.isNotBlank(token)) {
			if(log.isDebugEnabled()) log.debug("El c�digo es null y el token es "+ token);
			MensajeBean beanM = new MensajeBean();
            beanM.setMensajeerror("El c�digo ingresado es incorrecto");
            beanM.setMensajesol("Por favor intente nuevamente refrescando el c�digo.");
			modelAndView = new ModelAndView("PagE");
			modelAndView.addObject("beanErr", beanM);
			return modelAndView ;
		}
            
        
		if(codigo == null)
			
        {
            if(log.isDebugEnabled()) log.debug("El c�digo es null.");
            
        	MensajeBean beanM = new MensajeBean();
            beanM.setMensajeerror("El c�digo ingresado es incorrecto");
            beanM.setMensajesol("Por favor intente nuevamente refrescando el c�digo.");
            modelAndView = new ModelAndView("PagE");
			modelAndView.addObject("beanErr", beanM);
			return modelAndView ;
			
        }
		
		Map<String,String> datos = new HashMap<String,String>();
		datos.put("num_ruc",  		ServletRequestUtils.getStringParameter(request, "num_ruc")); 
		datos.put("tipocomprobante",ServletRequestUtils.getStringParameter(request, "tipocomprobante")); 
		datos.put("num_serie",  	ServletRequestUtils.getStringParameter(request, "num_serie").toUpperCase());
		datos.put("num_comprob",  	ServletRequestUtils.getStringParameter(request, "num_comprob"));
		datos.put("fec_emision",  	ServletRequestUtils.getStringParameter(request, "fec_emision")); 
		datos.put("cantidad",  		ServletRequestUtils.getStringParameter(request, "cantidad")); 
		
		log.debug("num_ruc="+ServletRequestUtils.getStringParameter(request, "num_ruc")); 
		log.debug("tipocomprobante="+ServletRequestUtils.getStringParameter(request, "tipocomprobante")); 
		log.debug("num_serie="+ServletRequestUtils.getStringParameter(request, "num_serie").toUpperCase());
		log.debug("num_comprob="+ServletRequestUtils.getStringParameter(request, "num_comprob"));
		log.debug("fec_emision="+ServletRequestUtils.getStringParameter(request, "fec_emision")); 
		log.debug("cantidad="+ServletRequestUtils.getStringParameter(request, "cantidad"));
		
		///  AGREGADO POR NAA el  2011-01-25
		String codDocide = null; 
		String numDocide = null;
		codDocide = ServletRequestUtils.getStringParameter(request, "cod_docide") ; 
		if ( codDocide!=null && !codDocide.trim().equals("-")){
			numDocide = ServletRequestUtils.getStringParameter(request, "num_docide") ;  
			if(numDocide!=null && !numDocide.trim().equals("-")){
				datos.put("cod_docide",  codDocide);
				datos.put("num_docide",  numDocide);
			}
		}
		///  FIN DEL AGREGADO POR NAA el  2011-01-25	
		String tipoComprobante = ServletRequestUtils.getStringParameter(request, "tipocomprobante");
		// Agregado por M. Aguilar Inicio 
		if(tipoComprobante.substring(0,1).equals("C"))
		{
			// Realizar COnsulta a Contingencia 
			tipoComprobante=tipoComprobante.substring(1,3);
			datos.put("tipocomprobante",tipoComprobante); 
			Map resp = 	 validaCPCService.consultaValidezCPC(datos);
			Map respvalidacion = (HashMap)resp.get("resp"); 
			
			request.getSession().setAttribute("respvalidez",respvalidacion);
			
			modelAndView = new ModelAndView("resultadovalidez1");
		}
		else
		{
		// Agregado por M. Aguilar Final 
			// Realiza la consulta de mnera regular
			datos.put("tipocomprobante",tipoComprobante); 
			Map resp = 	 validaCPEService.consultaValidezRHE_NCE(datos);
			Map respvalidacion = (HashMap)resp.get("resp"); 
			request.getSession().setAttribute("respvalidez",respvalidacion);
			
			String esOSE = (String)respvalidacion.get("esOSE");
			
			log.debug("esOSE:"+esOSE);			
			String valido = "No";
			//if("1".equals(esOSE))  valido="Si";
			
			//Ini PAS20175E210300094
			if(tipoComprobante.equals("TCF")) {
				if(respvalidacion.get("exito").equals("1")) {
					valido="Si";
				}
			} else {
				if("1".equals(esOSE))  valido="Si";
			}
			//Fin PAS20175E210300094
			
			//Ini PAS20175E210300094
			if(tipoComprobante.equals("TCF")) {
				valido="Si";
			}
			//Fin PAS20175E210300094
			
			if(tipoComprobante.equals("TME12") || tipoComprobante.equals("TME07")) {
				if(respvalidacion.get("exito").equals("1")) {
					valido="Si";
				}
			}
			Map<String, String> datosBoleta = new HashMap<String, String>();
			
			datosBoleta.put("resultado", valido);
			datosBoleta.put("tipoComprobante", tipoComprobante);
			datosBoleta.put("num_ruc", ServletRequestUtils.getStringParameter(request, "num_ruc"));
			datosBoleta.put("num_serie", ServletRequestUtils.getStringParameter(request, "num_serie").toUpperCase());
			datosBoleta.put("num_comprobante", ServletRequestUtils.getStringParameter(request, "num_comprob"));			
			log.debug("asignando:"+datosBoleta.toString());
			request.getSession().setAttribute("datosBoleta",datosBoleta);		
			modelAndView = new ModelAndView("resultadovalidez1");			
			
		}
		
		}catch(ServiceException e){
			log.error(e);
			MensajeBean msb = new MensajeBean(); 
			msb.setError(true);
			msb.setMensajeerror("Ha ocurrido al procesar la consulta: \n"+e.getMessage());
			modelAndView = new ModelAndView("PagE");
			modelAndView.addObject("beanErr", msb);
		} catch (Exception e) {
			log.error(e);
			MensajeBean msb = new MensajeBean(); 
			msb.setError(true);
			msb.setMensajeerror("Ha ocurrido al procesar la consulta: \n\n"+e.getMessage());
			modelAndView = new ModelAndView("PagE");
			modelAndView.addObject("beanErr", msb);
		}
		
		if(log.isDebugEnabled()) log.debug("ConsultaValidezCPEController.CapturaCriterioValidez - Fin");
		
		return modelAndView ;
	}
	
		@SuppressWarnings("unchecked")
	public ModelAndView descargarBoletaXML(HttpServletRequest request, HttpServletResponse response) {
		log.debug("Descarga xml de boleta");
		MensajeBean msgErr = new MensajeBean();
		try {
			Map params = (TreeMap)WebUtils.getParametersStartingWith(request, null);

			log.debug("params: " + params);
			
			/** BOLETAEB01-NNNRRRRRRRRRRR.zip*/
			String nombre = "BOLETA"; 
			if ( params.get("tipo").equals("11")){
				nombre = "NOTA_CREDITO";
			}
			if ( params.get("tipo").equals("12")){
				nombre = "NOTA_DEBITO";
			}
			
			String fileName = nombre + 
				params.get("serie").toString() + "-" +
				params.get("numero").toString().trim() +
				//params.get("ruc").toString() + ".zip";				
				params.get("ruc").toString() + ".xml";
			
			log.debug("nombre file: " + fileName);
			
			pe.gob.sunat.servicio2.registro.electronico.comppago.boleta.bean.ArchivoComprobanteBean archivo = validaCPEService.descargarBoleta(params);
				
				if(archivo != null) {
					Map mres = new HashMap();
					mres.put("fileName", fileName);
					mres.put("dataBytes", archivo.getContenidoArchivoZip());
					
				    //response.setContentType("application/zip");   
				    response.setContentType("text/xml");
					response.setHeader("content-disposition","attachment;filename ="+fileName);	
					OutputStream outputStream = response.getOutputStream();
					//outputStream.write(archivo.getContenidoArchivoZip());
					outputStream.write(archivo.getContenidoArchivoXml().getBytes());
					outputStream.flush();
					outputStream.close();
					
					return null;//new ModelAndView(this.downloadView, "datamodel", mres);
				} else {                 
					throw new ServiceException(this, "No se encontro el archivo del comprobante");
				}
	
		} catch(ServiceException e) {
            log.error(e);
            msgErr.setMensajeerror(e.getLocalizedMessage());
            msgErr.setMensajesol("Por favor comuniquese con el webmaster para comunicarle el problema.");
            request.setAttribute("beanErr", msgErr);
		} catch(Exception e) {
            log.error(e);
            msgErr.setMensajeerror(e.getLocalizedMessage());
            msgErr.setMensajesol("Por favor comuniquese con el webmaster para comunicarle el problema.");
            request.setAttribute("beanErr", msgErr);
		}
		
		return new ModelAndView("PagE");
	}	
	
	public ModelAndView descargarBoletaPDF(HttpServletRequest request, HttpServletResponse response){
		
		log.debug("Descarga pdf de boleta");		
		MensajeBean msgErr = new MensajeBean();
		
		try {
			Map params = (TreeMap)WebUtils.getParametersStartingWith(request, null);

			log.debug("params: " + params);
			
			/** BOLETAEB01-NNNRRRRRRRRRRR.pdf*/
			
			String nombre = "BOLETA"; 
			if ( params.get("tipo").equals("11")){
				nombre = "NOTA_CREDITO";
			}
			if ( params.get("tipo").equals("12")){
				nombre = "NOTA_DEBITO";
			}
			
			
			String fileName = nombre + 
				params.get("serie").toString() + "-" +
				params.get("numero").toString().trim() +
				params.get("ruc").toString() + ".pdf";		
			
			//Ini PAS20175E210300094
			if(params.get("tipo").equals("TCF")) {
				fileName = params.get("ruc").toString().trim() + "-12-" + 
						params.get("serie").toString().trim() + "-" + params.get("numero").toString().trim() + ".pdf";
			}
			//Fin PAS20175E210300094
			
			//Ini PAS20181U210300013
			if(params.get("tipo").equals("TME12")) {
				fileName = params.get("ruc").toString().trim() + "-12-" + 
						params.get("serie").toString().trim() + "-" + params.get("numero").toString().trim() + ".pdf";
			}
			if(params.get("tipo").equals("TME07")) {
				fileName = params.get("ruc").toString().trim() + "-07-" + 
						params.get("serie").toString().trim() + "-" + params.get("numero").toString().trim() + ".pdf";
			}
			//Fin PAS20181U210300013
			
			log.debug("nombre file: " + fileName);
			
			
			
			
			//Ini PAS20175E210300094
			Map<String,Object> mapaDatos = new HashMap<String, Object>();
			
			if(params.get("tipo").equals("TCF")) {
				Map<String,String> datos = new HashMap<String,String>();
				datos.put("num_ruc",  		params.get("ruc").toString().trim()); 
				datos.put("tipocomprobante",params.get("tipo").toString().trim()); 
				datos.put("num_serie",  	params.get("serie").toString().trim());
				datos.put("num_comprob",  	params.get("numero").toString().trim());
	
				mapaDatos = validaCPEService.generarPDFTicketPOS(datos);
				
				if(!mapaDatos.get("exito").equals("1")) {
					throw new ServiceException(this, "No se encontro el archivo del comprobante");
				}
			
			} else if(params.get("tipo").equals("TME12") || params.get("tipo").equals("TME07")) {
				Map<String,String> datos = new HashMap<String,String>();
				datos.put("num_ruc",  		params.get("ruc").toString().trim()); 
				datos.put("tipocomprobante",params.get("tipo").toString().trim()); 
				datos.put("num_serie",  	params.get("serie").toString().trim());
				datos.put("num_comprob",  	params.get("numero").toString().trim());
	
				mapaDatos = validaCPEService.generarPDFTicketME(datos);
				
				if(!mapaDatos.get("exito").equals("1")) {
					throw new ServiceException(this, "No se encontro el archivo del comprobante");
				}
			
			} else {
				
				pe.gob.sunat.servicio2.registro.electronico.comppago.boleta.bean.ArchivoComprobanteBean archivo = validaCPEService.descargarBoleta(params);
				
				if(archivo != null) {
					
					mapaDatos = validaCPEService.generarPDF(archivo.getContenidoArchivoZip(),nombre);
					
				} else {                 
					throw new ServiceException(this, "No se encontro el archivo del comprobante");
				}
				
			}
			
			
			//pe.gob.sunat.servicio2.registro.electronico.comppago.boleta.bean.ArchivoComprobanteBean archivo = validaCPEService.descargarBoleta(params);
				
			//	if(archivo != null) {
					
					//log.debug("Llamando a convertir a pdf");
					
					
			//		Map<String, Object> mapaDatos = validaCPEService.generarPDF(archivo.getContenidoArchivoZip(),nombre);
									
					//log.debug("Imprimiendo sobre el jasper");
					
//******************************METODO 1*********************************************
					//log.debug("primera forma");
					JasperPrint pdf = null;
					try{
						//pdf = toPDF("/PLANTILLA000846.jrxml", mapaDatos);
						String jasper = mapaDatos.get("jasper").toString();
						pdf = toPDF(jasper, mapaDatos);
					} catch(Exception e){
						log.error("Error:"+e.toString());						
					}
					
					response.setContentType("application/x-pdf");
				    response.setHeader("Content-disposition", "inline; filename="+fileName);
				    
				    OutputStream os = null;
				    os = response.getOutputStream();
				    JasperExportManager.exportReportToPdfStream(pdf, os);
				    return null;
//******************************FIN METODO 1*********************************************				    
				    
//******************************METODO 2*********************************************
//					log.debug("segunda forma");
//			        JRDataSource ds = new JRBeanCollectionDataSource((Collection) mapaDatos.get("DetalleItems"));			        
//			        mapaDatos.put("datasource", ds);										
//					ModelAndView modelAndView = new ModelAndView(mapaDatos.get("plantilla").toString(), mapaDatos);					
//					return modelAndView;
					
//******************************FIN METODO 2*********************************************					
					
				/*} else {                 
					throw new ServiceException(this, "No se encontro el archivo del comprobante");
				}*/
	
		} catch(ServiceException e) {
            log.error(e);
            msgErr.setMensajeerror(e.getLocalizedMessage());
            msgErr.setMensajesol("Por favor comuniquese con el webmaster para comunicarle el problema.");
            request.setAttribute("beanErr", msgErr);
		} catch(Exception e) {
            log.error(e);
            msgErr.setMensajeerror(e.getLocalizedMessage());
            msgErr.setMensajesol("Por favor comuniquese con el webmaster para comunicarle el problema.");
            request.setAttribute("beanErr", msgErr);
		}
		
		return new ModelAndView("PagE");
		
		
	}	
		
	@SuppressWarnings("unchecked")
	public JasperPrint toPDF(String reportName, Map<String,Object> parameters) throws JRException {

		InputStream reportStream = this.getClass().getResourceAsStream(reportName);

		JasperDesign jd = JRXmlLoader.load(reportStream); 
		JasperReport report = JasperCompileManager.compileReport(jd);
		
		List<Object> dataList = (List<Object>) parameters.get("DetalleItems");
		JasperPrint print = null;
		
		if(dataList!=null){
			JRBeanCollectionDataSource beanColDataSource = new JRBeanCollectionDataSource(dataList);
			 print = JasperFillManager.fillReport(report, parameters, beanColDataSource);
		}else{
			
			JRMapArrayDataSource source =  new JRMapArrayDataSource(new Object[] {new HashMap()});
			 print = JasperFillManager.fillReport(report, parameters,source);
		}
		
		return print;
		
	}	
	
	/*private boolean validarCaptchaV3(String token) throws IOException {
		boolean respuesta=true;
		return respuesta;
	}*/
	
	private boolean validarCaptchaV3(String numCaptcha) {
    	boolean respuesta = false;
    	   String url = this.SERVICIO_VALIDA_CAPTCHA_V3;
    	   RestTemplate restTemplate = new RestTemplate();
    	   try {
    	      
    	      HashMap<String, Object> mensaje = new HashMap<String, Object>();
    	      
    	      mensaje.put("resp", numCaptcha);
    	      HttpEntity<HashMap> request = new HttpEntity(mensaje);
    	      ResponseEntity<String> response= restTemplate.postForEntity(url, request, String.class);
    	      log.info("Cdigo de respuesta del servicio de validacion de captcha:"+response.getStatusCode());
    	      if(HttpStatus.OK.equals(response.getStatusCode())) {
    	         try {
    	            String jsonRespuesta = response.getBody();          
    	            
    	           
    	            
    	            Map<String,Object> result =    new ObjectMapper().readValue(jsonRespuesta, HashMap.class);
    	              	            
    	            String score = result.containsKey("score")?result.get("score").toString():"0";
    	            String success = result.containsKey("success")?result.get("success").toString():"false"; 
    	            
    	            log.info("Respuesta result :::>" + result);
    	            
    	            
    	            log.info("Respuesta del servicio de validacion del captcha v3 {success:"+success+",score:"+score+"}");
    	            if("true".equals(success) && Double.parseDouble(score)>=0.5){
    	               respuesta = true;
    	            }
    	         }catch(Exception e) {
    	            log.info("Ocurri un error al procesar el servicio de validacin del captcha",e);
    	         }
    	      }
    	   }catch(Exception e) {
    	      log.info("Ocurri un error al procesar el servicio de validacion",e);
    	   }
    	   return respuesta;

	}
}
