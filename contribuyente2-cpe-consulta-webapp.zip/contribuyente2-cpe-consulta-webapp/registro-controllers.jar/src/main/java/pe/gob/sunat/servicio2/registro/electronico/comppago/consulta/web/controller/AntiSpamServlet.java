package pe.gob.sunat.servicio2.registro.electronico.comppago.consulta.web.controller;

import java.awt.image.BufferedImage;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.Random;

import javax.imageio.IIOImage;
import javax.imageio.ImageIO;
import javax.imageio.ImageTypeSpecifier;
import javax.imageio.ImageWriter;
import javax.imageio.metadata.IIOMetadata;
import javax.imageio.stream.ImageOutputStream;
import javax.servlet.ServletException;
import javax.servlet.ServletOutputStream;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import pe.gob.sunat.servicio.registro.cp.electronico.captcha.CaptchaInformation;
import pe.gob.sunat.servicio.registro.cp.electronico.captcha.SunatCaptchaEngine;

import com.octo.captcha.service.CaptchaServiceException;

/**
 * @author Carlos Enrique Quispe Salazar
 * @web.servlet name="AntiSpamServlet"
 * @web.servlet-mapping url-pattern = "/captcha"
 */
public class AntiSpamServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
	protected transient Log log = LogFactory.getLog(this.getClass());

	protected void doGet(HttpServletRequest request, HttpServletResponse response)
	throws ServletException, IOException {
		doPost(request, response);
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response)
	throws ServletException, IOException {
		String accion = request.getParameter("accion");
		if(accion.equals("image")) {
			doImage(request, response);
		}
		else if(accion.equals("random")) {
			doRandom(request, response);
		}
	}

	protected void doImage(HttpServletRequest request, HttpServletResponse response)
	throws ServletException, IOException {
		HttpSession session = request.getSession();
		if(log.isDebugEnabled())log.debug("doImage");
		byte[] captchaChallengeAsJpeg = null;
		ByteArrayOutputStream jpegOutputStream = new ByteArrayOutputStream();
		if(log.isDebugEnabled())log.debug("creo el jpegOutputStream");
		try {
			CaptchaInformation info = SunatCaptchaEngine.generateCaptcha();
			if(log.isDebugEnabled())log.debug("info.."+   info.toString()); 
			
			
			//JPEGImageEncoder jpegEncoder = JPEGCodec.createJPEGEncoder(jpegOutputStream);
			//if(log.isDebugEnabled())log.debug("jpegEncoder.."+   jpegEncoder.toString()); 
			//jpegEncoder.encode(info.getImage());
			
			BufferedImage challenge = info.getImage();
			
			ImageWriter imageWriter = (ImageWriter)ImageIO.getImageWritersBySuffix("jpeg").next();
			ImageOutputStream ios = ImageIO.createImageOutputStream(jpegOutputStream);
			imageWriter.setOutput(ios);
			IIOMetadata imageMetaData = imageWriter.getDefaultImageMetadata(new ImageTypeSpecifier(challenge), null);
			imageWriter.write(imageMetaData, new IIOImage(challenge, null, null), null);
			
			
			
			if(log.isDebugEnabled())log.debug("encode"); 
			session.setAttribute("jcaptcha", info.getWord());
			if(log.isDebugEnabled())log.debug("jcaptcha"+ info.getWord());
			

		}
		catch (IllegalArgumentException e) {
			e.printStackTrace(); 
			log.error("**** Error **** " + e);
			response.sendError(HttpServletResponse.SC_NOT_FOUND);
			return;
		}
		catch (CaptchaServiceException e) {
			e.printStackTrace(); 
			log.error("**** Error **** " + e);
			response.sendError(HttpServletResponse.SC_INTERNAL_SERVER_ERROR);
			return;
		}catch (Throwable e) {
			e.printStackTrace(); 
			log.error("**** Error **** " + e);
			response.sendError(HttpServletResponse.SC_INTERNAL_SERVER_ERROR);
			return;
		}

		log.debug("generando imagen...........");
		captchaChallengeAsJpeg = jpegOutputStream.toByteArray();
		response.setHeader("Cache-Control", "no-store");
		response.setHeader("Pragma", "no-cache");
		response.setDateHeader("Expires", 0);
		response.setContentType("image/jpeg");
		ServletOutputStream responseOutputStream = response.getOutputStream();
		responseOutputStream.write(captchaChallengeAsJpeg);
		responseOutputStream.flush();
		responseOutputStream.close();
	}
	
	protected void doRandom(HttpServletRequest request, HttpServletResponse response)
	throws ServletException, IOException {
		HttpSession session = request.getSession();
		PrintWriter out = response.getWriter();
		
		log.debug("generando random");
        Random rnd = new Random();
        String numRnd = Integer.toString(rnd.nextInt());
        session.setAttribute("numRnd", numRnd);
        if(log.isDebugEnabled())log.debug("numRnd"+ numRnd);
        out.print(numRnd);
        out.flush();
        out.close();
	}
}
