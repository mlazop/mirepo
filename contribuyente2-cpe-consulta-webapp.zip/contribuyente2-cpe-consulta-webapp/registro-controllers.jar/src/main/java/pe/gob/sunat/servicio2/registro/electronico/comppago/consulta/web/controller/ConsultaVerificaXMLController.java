package pe.gob.sunat.servicio2.registro.electronico.comppago.consulta.web.controller;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.InputStream;
import java.net.URL;
import java.util.HashMap;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.xml.namespace.QName;
import javax.xml.rpc.ParameterMode;

import net.sf.jmimemagic.Magic;
import net.sf.jmimemagic.MagicException;
import net.sf.jmimemagic.MagicMatch;
import net.sf.jmimemagic.MagicMatchNotFoundException;
import net.sf.jmimemagic.MagicParseException;

import org.apache.axis.client.Call;
import org.apache.axis.client.Service;
import org.apache.axis.encoding.XMLType;
import org.apache.commons.io.IOUtils;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.web.bind.ServletRequestBindingException;
import org.springframework.web.bind.ServletRequestUtils;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.multipart.MultipartHttpServletRequest;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.mvc.multiaction.MultiActionController;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;

import pe.gob.sunat.framework.spring.util.bean.MensajeBean;
import pe.gob.sunat.framework.spring.util.exception.ServiceException;
import pe.gob.sunat.servicio2.registro.electronico.comppago.consulta.service.VerificaCoprobanteElectronicoService;
import pe.gob.sunat.servicio2.registro.electronico.comppago.factura.bean.ComprobanteParserBean;
import pe.gob.sunat.servicio2.registro.electronico.comppago.factura.context.FacturaContext;
import pe.gob.sunat.servicio2.registro.electronico.comppago.factura.context.GuiaRemisionBienFiscalizableContext;
import pe.gob.sunat.servicio2.registro.electronico.comppago.factura.context.GuiaRemisionElectronicaContext;
import pe.gob.sunat.servicio2.registro.electronico.comppago.factura.context.NotaCreditoContext;
import pe.gob.sunat.servicio2.registro.electronico.comppago.factura.context.NotaDebitoContext;
import pe.gob.sunat.servicio2.registro.electronico.comppago.factura.context.PercepcionContext;
import pe.gob.sunat.servicio2.registro.electronico.comppago.factura.context.RetencionContext;
import pe.gob.sunat.tecnologia2.validadoc.bean.VerifySignResult;

/**
 * <p>Title: ConsultaVerificaXMLController</p>
 * <p>Description: Clase Controladora de verificaci�n autenticidad del XML.</p>
 * @author jchuquitaype
 */
public class ConsultaVerificaXMLController extends MultiActionController {
	private static final Log log = LogFactory.getLog(ConsultaVerificaXMLController.class);
	private static final String PDF_MIME = "application/pdf";

	private VerificaCoprobanteElectronicoService verificaCPEService;
	//private String rutaCargaArchivo ; 
	
	/**
	 * Muestra la pantalla inicial. 
	 * @param request
	 * @param response
	 * @return
	 */
	public ModelAndView mostrarForm(HttpServletRequest request,
			HttpServletResponse response) {
		ModelAndView modelAndView = null ; 
		try {			
			modelAndView = new ModelAndView("upload");			
		}catch (Exception ex) {
			log.error(ex.getMessage(),ex);
			MensajeBean msb = new MensajeBean();
			msb.setError(true); 
			msb.setMensajeerror("Ocurrio un error al al cargar la vista de verificaci�n de los documentos XML.");
			modelAndView = new ModelAndView("PagE");
			modelAndView.addObject("beanErr", msb);
		}
		return modelAndView  ;		
	}
	/**
	 * Si se verifica que el c�digo captcha generado es igual al ingresado por el usuario, retorna <code>null</code>, caso contrario retorna la vista con el mensaje correspondiente al error. 
	 * @param request
	 * @return
	 * @throws ServletRequestBindingException
	 */
	private ModelAndView verificaCaptcha(HttpServletRequest request) throws ServletRequestBindingException{
		ModelAndView modelAndView = null ;
		
		String codigo = ServletRequestUtils.getRequiredStringParameter(request, "codigo");
        if(codigo != null) {
            codigo = codigo.trim();
            if(log.isDebugEnabled()) log.debug("Validando imagen ...........");
            Object obj = request.getSession().getAttribute("jcaptcha");
            if(obj != null){
                if(!((String)obj).equals(codigo)) {
                	if(log.isDebugEnabled()) log.debug("El c�digo ingresado es incorrecto.");
                    MensajeBean beanM = new MensajeBean();
                    beanM.setMensajeerror("El c�digo ingresado es incorrecto");
                    beanM.setMensajesol("Por favor intente nuevamente refrescando el c?digo.");
                    modelAndView = new ModelAndView("PagE");
                    modelAndView.addObject("beanErr", beanM);
                    return modelAndView ;
                }
                request.getSession().removeAttribute("jcaptcha");
            }else {
                if(log.isDebugEnabled()) log.debug("No se cargo la imagen.");
                MensajeBean beanM = new MensajeBean();
                beanM.setMensajeerror("No se carg� la imagen que contiene el c�digo.");
                beanM.setMensajesol("Por favor intente nuevamente refrescando el c�digo.");
                modelAndView = new ModelAndView("PagE");
                modelAndView.addObject("beanErr", beanM);
                return modelAndView ;
            }
        }else {
        	if(log.isDebugEnabled()) log.debug("El c�digo ingresado es incorrecto.");
            MensajeBean beanM = new MensajeBean();
            beanM.setMensajeerror("El c�digo ingresado es incorrecto");
            beanM.setMensajesol("Por favor intente nuevamente refrescando el c�digo.");
            modelAndView = new ModelAndView("PagE");
            modelAndView.addObject("beanErr", beanM);
            return modelAndView ;
        }
		
		return modelAndView ; 
	}
	/**
	 * Migrado desde el proyecto de Recibos por honorarios.
	 * @param request
	 * @param response
	 * @return
	 */
	public ModelAndView verificaXML(HttpServletRequest request, HttpServletResponse response){
		ModelAndView modelAndView = null ;
		InputStream is = null ; 
		try {
			//Ini IMR
	    	Map<String,String> respuesta = new HashMap<String, String>();
	        //Fin IMR
	        MensajeBean msgErr = new MensajeBean();
	        msgErr.setError(true);
	        long lastTime = System.currentTimeMillis();
	        
	        //comentarjm
	        // Validaci�n captcha  
	        modelAndView = verificaCaptcha(request) ; 
	        if(null!=modelAndView )
	        	return modelAndView  ; 	        
	       
    		MultipartHttpServletRequest multipartRequest=(MultipartHttpServletRequest)request;
    		MultipartFile multipartFile = multipartRequest.getFile("archivo");
    		is = multipartFile.getInputStream() ;
    		
    		//archivo cargado convertido en un Array de Bytes
    		byte[] bytes = IOUtils.toByteArray(is);
			InputStream isAux = new ByteArrayInputStream(bytes);
    		    		
    		if(log.isDebugEnabled()) log.debug(">> Se recupero el  archivo");
    		
    		ComprobanteParserBean parser = new ComprobanteParserBean();
    		//Valida que est� bien formado
			Document doc = parser.parse(isAux);
    		/*
			* PAS20171U210300083 prefijo cualquiera GetLocalName
			*/
			String documentName = doc.getDocumentElement().getLocalName(); //Antes getNodeName();			
			if(log.isDebugEnabled()) log.debug(">> Recupero documentName: "+ documentName);
    		
			//NAA 
			String tipodocumento = "-";
			boolean comaparableByte = false;
			// FIN NAA
				try {
					String serieNumDoc = obtenerValorNodo(doc.getDocumentElement(), "cbc:ID");
					
					if(serieNumDoc == null || serieNumDoc == ""){
						//serieNumDoc = obtenerValorNodo(doc.getDocumentElement(), "n4:ID");
						serieNumDoc = obtenerContenidoNodo(doc.getDocumentElement(), ":ID");
					}				

					if(documentName != null) {
						documentName = documentName.trim();
						
						if(log.isDebugEnabled()) log.debug(">> Serie y numero = " + serieNumDoc);
						
						if(documentName.contains("Invoice") && serieNumDoc.toUpperCase().substring(0, 4).equals("EB01") ) {
							parser.setComprobanteContext(new FacturaContext());
							tipodocumento= "Invoice";
							comaparableByte = true;//PAS20191U210100175
						}else if(documentName.contains("DebitNote") && serieNumDoc.toUpperCase().substring(0, 4).equals("EB01") ) {
							parser.setComprobanteContext(new NotaDebitoContext());
							tipodocumento= "DebitNote";
							comaparableByte = true;//PAS20191U210100175
						}else if(documentName.contains("CreditNote") && serieNumDoc.toUpperCase().substring(0, 4).equals("EB01") ) {
							parser.setComprobanteContext(new NotaCreditoContext());
							tipodocumento= "CreditNote";
							comaparableByte = true;//PAS20191U210100175
						}else if(documentName.contains("Invoice") && serieNumDoc.toUpperCase().startsWith("E") ) {
							parser.setComprobanteContext(new FacturaContext());
							tipodocumento= "Invoice";
							comaparableByte = true;
						}else if(documentName.contains("DebitNote") && serieNumDoc.toUpperCase().startsWith("E") ) {
							parser.setComprobanteContext(new NotaDebitoContext());
							tipodocumento= "DebitNote";
							comaparableByte = true;
						}else if(documentName.contains("CreditNote") && serieNumDoc.toUpperCase().startsWith("E") ) {
							parser.setComprobanteContext(new NotaCreditoContext());
							tipodocumento= "CreditNote";
							comaparableByte = true;
						}else if(documentName.contains("Invoice") && serieNumDoc.toUpperCase().startsWith("F") ) {
							parser.setComprobanteContext(new FacturaContext());
							tipodocumento= "InvoiceGEM";
							comaparableByte = true;
						}else if(documentName.contains("DebitNote") && serieNumDoc.toUpperCase().startsWith("F") ) {
							parser.setComprobanteContext(new NotaDebitoContext());
							tipodocumento= "DebitNoteGEM";
							comaparableByte = true;
						}else if(documentName.contains("CreditNote") && serieNumDoc.toUpperCase().startsWith("F") ) {
							parser.setComprobanteContext(new NotaCreditoContext());
							tipodocumento= "CreditNoteGEM";
							comaparableByte = true;
						}else if(documentName.contains("DespatchAdvice") && serieNumDoc.toUpperCase().startsWith("G") ) {
							String tipoDeGuia = obtenerValorNodo(doc.getDocumentElement(), "cbc:DespatchAdviceTypeCode");
							parser.setComprobanteContext(new GuiaRemisionBienFiscalizableContext(tipoDeGuia));
							tipodocumento= "DespatchAdviceBienFiscalizable";
						}else if(documentName.contains("Perception") && serieNumDoc.toUpperCase().startsWith("P") ) {
							parser.setComprobanteContext(new PercepcionContext());
							tipodocumento= "PerceptionGEM";
							comaparableByte = true;
						}else if(documentName.contains("Perception") && serieNumDoc.toUpperCase().substring(0, 4).equals("E001") ) {
							parser.setComprobanteContext(new PercepcionContext());
							tipodocumento= "Perception";
						}else if(documentName.contains("Retention") && serieNumDoc.toUpperCase().startsWith("R") ) {
							parser.setComprobanteContext(new RetencionContext());
							tipodocumento= "RetentionGEM";
							comaparableByte = true;
						}else if(documentName.contains("Retention") && serieNumDoc.toUpperCase().substring(0, 4).equals("E001") ) {
							parser.setComprobanteContext(new RetencionContext());
							tipodocumento= "Retention";
						}else if(documentName.contains("DespatchAdvice") && serieNumDoc.toUpperCase().startsWith("T") ) {
							parser.setComprobanteContext(new GuiaRemisionElectronicaContext());
							tipodocumento= "DespatchAdviceGEM";
							comaparableByte = true;
						}else if(documentName.contains("DespatchAdvice") && serieNumDoc.toUpperCase().substring(0, 4).equals("EG01") ) {
							parser.setComprobanteContext(new GuiaRemisionElectronicaContext());
							tipodocumento= "DespatchAdvice";
						}else {						 
							throw new ServiceException(this, "S�lo archivos Digitales de Facturas Electr�nicas, Notas de Cr�dito de Factura y Notas de D�bito de Factura pueden ser Verificados.");
						}
					}else {
						throw new Exception("No se encontro la ra�z del documento.");
					}

					if(log.isDebugEnabled()) log.debug("tipodocumento: "+  tipodocumento);
					if(log.isDebugEnabled()) log.debug("comaparableByte: "+  comaparableByte);
					if(log.isDebugEnabled()) log.debug("respuesta: "+  respuesta);
										
					if(comaparableByte){
						//metodo donde compara archivo con archivo
						if(log.isDebugEnabled()) log.debug("DVDR - ConsultaVerificaXMLController.verificaXML : Iniciando comparacion de archivos");
						respuesta = verificaCPEService.evaluarInputStream(doc, tipodocumento, parser, bytes) ;
						if(log.isDebugEnabled()) log.debug("respuesta archivo con archivo:"+  respuesta);
					}
					if(log.isDebugEnabled()) log.debug("respuesta: "+  respuesta);
					if(log.isDebugEnabled()) log.debug("respuesta.get(mensaje): "+  respuesta.get("mensaje"));
					
					
					String rpta = "NO INFORMADO";
					if (respuesta.get("mensaje")!=null) rpta = respuesta.get("mensaje").toString();
					if(log.isDebugEnabled()) log.debug("rpta:"+  rpta);
					
					if (rpta.equals("DIFERENTES") || rpta.equals("NO INFORMADO")){
						if(log.isDebugEnabled()) log.debug("Entro al flujo");
						
						if (!serieNumDoc.substring(0, 4).toUpperCase().equals("EB01")){
							// Validacion de comprobantes de GEM 
							if(tipodocumento.equals("InvoiceGEM") || tipodocumento.equals("DebitNoteGEM") || tipodocumento.equals("CreditNoteGEM") ){
								File fileXml = new File("/data0/see/emision/factura/files/docgem"+System.currentTimeMillis()) ;
								//comentarjm
								//File fileXml = new File("D:\\data0\\see\\emision\\factura\\files\\"+System.currentTimeMillis()) ;
								multipartFile.transferTo(fileXml) ; 
								
								if(log.isDebugEnabled()) log.debug(">> fileXml :: "+ fileXml.toURI().toURL().toString() );
								
								//respuesta = verificaCPEService.evaluarFacturaGEM(doc, tipodocumento, parser, fileXml) ;
								//validando factura							
								if(log.isDebugEnabled()) log.debug("CALL-evaluarFileFacturaGEM");
								respuesta = verificaCPEService.evaluarFileFacturaGEM(doc, tipodocumento, parser, fileXml, bytes) ;
								if(log.isDebugEnabled()) log.debug("FIN-CALL-evaluarFileFacturaGEM");
								if(log.isDebugEnabled()) log.debug("respuesta===" + respuesta);
							// Validacion de comprobantes de emision desde PORTAL SOL - Facturas
							}else if(tipodocumento.equals("Invoice") || tipodocumento.equals("DebitNote") || tipodocumento.equals("CreditNote") || tipodocumento.equals("DespatchAdviceBienFiscalizable")){
								respuesta = verificaCPEService.evaluarFacturaPORTAL(doc, tipodocumento, parser);
							}
						} else {
							// Validacion de comprobantes de emision desde PORTAL SOL - Boletas
							if(tipodocumento.equals("Invoice") || tipodocumento.equals("DebitNote") || tipodocumento.equals("CreditNote")){
								respuesta = verificaCPEService.evaluarBoletaPORTAL(doc, tipodocumento, parser);
							}
						}
						if(log.isDebugEnabled()) log.debug("respuesta validaci�n inicial:"+  respuesta);
					}else{ //PAS20221U210700267	
						if(log.isDebugEnabled()) log.debug("Comprobante sin errores-" + serieNumDoc.substring(0, 4).toUpperCase() + "==" + tipodocumento );
						if (!serieNumDoc.substring(0, 4).toUpperCase().equals("EB01")){
							if(tipodocumento.equals("InvoiceGEM") || tipodocumento.equals("DebitNoteGEM") || tipodocumento.equals("CreditNoteGEM") ){
								File fileXml = new File("/data0/see/emision/factura/files/docgem"+System.currentTimeMillis()) ;
								multipartFile.transferTo(fileXml) ; 
								
								if(log.isDebugEnabled()) log.debug(">> fileXml :: "+ fileXml.toURI().toURL().toString() );
								
									if(log.isDebugEnabled()) log.debug("CALL-consultaFileNube");
									respuesta = verificaCPEService.consultaGrabaFileNube(doc, tipodocumento, parser, fileXml, bytes) ;
									if(log.isDebugEnabled()) log.debug("FIN-CALL-consultaFileNube");
							}
						}
						if(log.isDebugEnabled()) log.debug("respuesta validaci�n inicial:"+  respuesta);
					}

					long elapsed = (System.currentTimeMillis() - lastTime);
					log.debug(">> Valida XML en: " + elapsed + "ms.");
					//Ini IMR
					if(log.isDebugEnabled()) log.debug(">> Respuesta : " + respuesta);
					request.setAttribute("mensaje", respuesta);
					//Fin IMR
					modelAndView = new ModelAndView("response");					
				}catch(ServiceException ce) {
					log.error(ce,ce);
					throw ce;
				}catch(Exception e) {
					log.error(e,e); 
					throw e;
				}finally {
					if(is != null) is.close();
				}		
		}catch(ServiceException e){
			log.error(e);
			MensajeBean msb = new MensajeBean() ; 
			msb.setError(true); 
			msb.setMensajeerror(e.getMessage());
			modelAndView = new ModelAndView("PagE");
			modelAndView.addObject("beanErr", msb);
		}catch (Exception ex) {
			log.error(ex.getMessage(),ex);
			MensajeBean msb = new MensajeBean();
			msb.setError(true); 
			msb.setMensajeerror("Ocurrio un error en la verificaci�n del documento.");
			modelAndView = new ModelAndView("PagE");
			modelAndView.addObject("beanErr", msb);
		}
		return modelAndView ; 
		
	}
	/**
	 * Obtiene el valor de nodo de un hijo especifico de un elemento.
	 * @param doc elemento
	 * @param nombreTag nombre del nodo para el que queremos ubicar su valor.
	 * @return
	 */
	private String obtenerValorNodo(Element doc, String nameNode){

		NodeList nodos = doc.getChildNodes() ;
		Node nodo = null ;
		String tmpNombreNodo = "" ; 
		String valorNodo = "" ; 

		for(int i =0 ;i<nodos.getLength(); i++){
			nodo = nodos.item(i);    		
			if( nameNode.equals(nodo.getNodeName().trim()) ){
				Element el = (Element)nodo;
				valorNodo = el.getFirstChild().getNodeValue();
				break ; 
			}	
		}

		if(log.isDebugEnabled()) log.debug(">> "+nodo+ " - "+tmpNombreNodo+" - "+ valorNodo);
		return valorNodo ;

	}
	
	private String obtenerContenidoNodo(Element doc, String nameNode){

		NodeList nodos = doc.getChildNodes() ;
		Node nodo = null ;
		String tmpNombreNodo = "" ; 
		String valorNodo = "" ; 

		for(int i =0 ;i<nodos.getLength(); i++){
			nodo = nodos.item(i);    					
			if(  (nodo.getNodeName().trim()).contains(nameNode)  ){				 
				Element el = (Element)nodo;
				valorNodo = el.getFirstChild().getNodeValue();
				break ; 
			}
		}

		if(log.isDebugEnabled()) log.debug(">> "+nodo+ " - "+tmpNombreNodo+" - "+ valorNodo);
		return valorNodo ;

	}
	
	/**
	 * 
	 * @param request
	 * @param response
	 * @author pchacalia
	 * @return
	 */
	public ModelAndView verificaPDF(HttpServletRequest request, HttpServletResponse response){
		ModelAndView modelAndView = null ;
		InputStream is = null ; 
		try {
	    	Map<String,String> respuesta = new HashMap<String, String>();
	        MensajeBean msgErr = new MensajeBean();
	        msgErr.setError(true);
	        long lastTime = System.currentTimeMillis();
	        
	        /** Validaci�n captcha */
	        modelAndView = verificaCaptcha(request) ; 
	        if(null!=modelAndView )
	        	return modelAndView  ; 	        
	        
    		MultipartHttpServletRequest multipartRequest=(MultipartHttpServletRequest)request;
    		MultipartFile multipartFile = multipartRequest.getFile("archivo");
    		is = multipartFile.getInputStream() ;
    		
    		ByteArrayOutputStream buffer = new ByteArrayOutputStream();

    		int nRead;
    		byte[] data = new byte[16384];

    		while ((nRead = is.read(data, 0, data.length)) != -1) {
    		  buffer.write(data, 0, nRead);
    		}

    		buffer.flush();
    		
    		esPDF(buffer);

    		if(log.isDebugEnabled()) log.debug(">> Se recupero el  archivo"); 

    		String mensaje = "";	
    		String codApli = "ERHE";
    		String tipo = "pdf";
    		Service service = new Service();
    		Call callValidaPDF = (Call)service.createCall();
    		if(log.isDebugEnabled()) log.debug("-->callValidaPDF : " + callValidaPDF);
    		//callValidaPDF.setTargetEndpointAddress(new URL("http://localhost:7020/cl-ti-itvalidadoc2-service/ValidadorFirmaDigitalService"));//Desarrollo
    	    //callValidaPDF.setTargetEndpointAddress(new URL("https://150.50.2.7/cl-ti-itvalidadoc2-service/ValidadorFirmaDigitalService"));//Integracion
    		//callValidaPDF.setTargetEndpointAddress(new URL("http://192.168.34.11:80/cl-ti-itvalidadoc2-service/ValidadorFirmaDigitalService"));//Calidad
    		callValidaPDF.setTargetEndpointAddress(new URL("http://wssunat:8080/cl-ti-itvalidadoc2-service/ValidadorFirmaDigitalService"));//Produccion
    		
    		QName qname = new QName( "http://tempuri.org/", "result" );

    		callValidaPDF.registerTypeMapping(VerifySignResult.class, qname,
    		new org.apache.axis.encoding.ser.BeanSerializerFactory(VerifySignResult.class, qname),
    		new org.apache.axis.encoding.ser.BeanDeserializerFactory(VerifySignResult.class, qname)); 
    		
    	    
    		callValidaPDF.setOperationName(new QName("http://tempuri.org/", "valida1"));
    		callValidaPDF.addParameter("codApli", XMLType.XSD_STRING, ParameterMode.IN);
    		callValidaPDF.addParameter("tipo", XMLType.XSD_STRING, ParameterMode.IN);
    		callValidaPDF.addParameter("archivo",XMLType.SOAP_BASE64BINARY, ParameterMode.IN);
    		callValidaPDF.setReturnClass(VerifySignResult.class);
    		VerifySignResult verifySignResult = (VerifySignResult)callValidaPDF.invoke(new Object[] { codApli.toString(), tipo.toString(), buffer.toByteArray()});
    		
    		int resultado= verifySignResult.getResultCode();
            
            switch (resultado){
                 case 1: mensaje = "El Archivo PDF es valido y ha sido firmado por SUNAT correctamente.";
                 		break;
                 case 0: mensaje = "El Archivo PDF no ha sido firmado por SUNAT o presenta multiples firmas.";
                 		break;
                 case 2: mensaje = "El Archivo PDF seleccionado no se encuentra firmado digitalmente.";
                 		break;
                 case 3: mensaje = "El Archivo PDF fue modificado desde que fue firmado digitalmente por SUNAT. Por lo tanto el documento no es v�lido.";
          				break;
          	     //Ini IMR	
                 case 4: 
                	 mensaje = "El documento no es valido por que fue firmado con un certificado vencido.";
   				       break;	
   				 //Fin IMR      
                 case -1: mensaje = "Se produjo un error al momento de validar el documento. Por favor rep�rtelo a nuestro Buz�n de Quejas y Sugerencias de nuestro Portal Web.";
                 		break;
                 default: mensaje = "Se produjo un error al momento de validar el documento. Por favor rep�rtelo a nuestro Buz�n de Quejas y Sugerencias de nuestro Portal Web.";
                 		break;
            }
            is.close();
			               
			long elapsed = (System.currentTimeMillis() - lastTime);
			log.debug(">> Valida PDF en: " + elapsed + "ms.");
			if(log.isDebugEnabled()) log.debug(">> Respuesta : " + mensaje);
			respuesta.put("mensaje", mensaje);
			request.setAttribute("mensaje", respuesta);
			modelAndView = new ModelAndView("response");
		}catch(ServiceException e){
			log.error(e);
			MensajeBean msb = new MensajeBean() ; 
			msb.setError(true); 
			msb.setMensajeerror(e.getMessage());
			modelAndView = new ModelAndView("PagE");
			modelAndView.addObject("beanErr", msb);
		}catch (Exception ex) {
			log.error(ex.getMessage(),ex);
			MensajeBean msb = new MensajeBean();
			msb.setError(true); 
			msb.setMensajeerror("Ocurrio un error en la verificaci�n del documento.");
			modelAndView = new ModelAndView("PagE");
			modelAndView.addObject("beanErr", msb);
		}
		return modelAndView ; 
		
	}
	
	private void esPDF(ByteArrayOutputStream is) throws Exception {
		try {
			MagicMatch match;
			match = Magic.getMagicMatch(is.toByteArray(), true);
			if( !PDF_MIME.equals(match.getMimeType()) ) {
				throw new ServiceException(this, "El archivo enviado no es un pdf");
			}
		} catch (MagicParseException e1) {
			log.info("Ocurrio un Error al parsear el archivo enviado");
			throw new Exception(e1);
		} catch (MagicMatchNotFoundException e1) {			
			throw new ServiceException(this, "El archivo enviado no es un pdf");
		} catch (MagicException e1) {
			log.info("Ocurrio un Error al parsear el archivo enviado");
			throw new Exception(e1);
		}		
	}
	
	public void setVerificaCPEService(
			VerificaCoprobanteElectronicoService verificaCPEService) {
		this.verificaCPEService = verificaCPEService;
	}	
}
