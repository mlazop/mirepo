package pe.gob.sunat.servicio2.registro.electronico.comppago.consulta.web.controller;

import java.util.HashMap;
import java.util.Map;
import java.util.Map.Entry;

public class MapParamUtil {

	public static Map<String, String> objectMapToStringMap(Map<String, Object> input) {

		Map<String, String> output = new HashMap<String, String>();

		for (Entry<String, Object> entry : input.entrySet()) {

			output.put(entry.getKey(), entry.getValue().toString());
		}

		return output;
	}

}
