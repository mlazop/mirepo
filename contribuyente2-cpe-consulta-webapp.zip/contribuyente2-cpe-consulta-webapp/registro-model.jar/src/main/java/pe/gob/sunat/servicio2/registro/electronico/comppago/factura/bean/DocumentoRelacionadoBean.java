package pe.gob.sunat.servicio2.registro.electronico.comppago.factura.bean;

import java.io.Serializable;
import java.sql.Timestamp;

import pe.gob.sunat.framework.spring.util.date.FechaBean;

/**
 * POJO de datos del documento relacionado.
 * Ambito: Base de datos.
 * @author Carlos Enrique Quispe Salazar
 * */
public class DocumentoRelacionadoBean implements Serializable {
	private static final long serialVersionUID = 1L;
	private String numeroRuc;
	private String tipoComprobante;
	private String serieComprobante;
	private Integer numeroComprobante;
	
	/** Cuando son NC y ND relacionadas a una Factura o Boleta */
	private String tipoComprobanteRelacionado;
	private String descTipoComprobanteRelacionado ;
	private String serieComprobanteRelacionado;
	private Integer numeroComprobanteRelacionado;
	 	
	private String indicadorElectronico; /** Indicador */
	
	private String codigoUsuarioModificador;
	private String fechaModificacion;
	private String horaModificacion;
	
	public String getNumeroRuc() {
		return numeroRuc;
	}
	
	public void setNumeroRuc(String numeroRuc) {
		this.numeroRuc = numeroRuc;
	}
	
	public String getTipoComprobante() {
		return tipoComprobante;
	}
	
	public void setTipoComprobante(String tipoComprobante) {
		this.tipoComprobante = tipoComprobante;
	}
	
	public String getSerieComprobante() {
		return serieComprobante;
	}
	
	public void setSerieComprobante(String serieComprobante) {
		this.serieComprobante = serieComprobante;
	}
	
	public Integer getNumeroComprobante() {
		return numeroComprobante;
	}
	
	public void setNumeroComprobante(Integer numeroComprobante) {
		this.numeroComprobante = numeroComprobante;
	}
	
	public String getTipoComprobanteRelacionado() {
		return tipoComprobanteRelacionado;
	}
	
	public void setTipoComprobanteRelacionado(String tipoComprobanteRelacionado) {
		this.tipoComprobanteRelacionado = tipoComprobanteRelacionado;
	}
	
	public String getSerieComprobanteRelacionado() {
		return serieComprobanteRelacionado;
	}
	
	public void setSerieComprobanteRelacionado(String serieComprobanteRelacionado) {
		this.serieComprobanteRelacionado = serieComprobanteRelacionado;
	}
	
	public Integer getNumeroComprobanteRelacionado() {
		return numeroComprobanteRelacionado;
	}
	
	public void setNumeroComprobanteRelacionado(Integer numeroComprobanteRelacionado) {
		this.numeroComprobanteRelacionado = numeroComprobanteRelacionado;
	}

	public String getIndicadorElectronico() {
		return indicadorElectronico;
	}

	public void setIndicadorElectronico(String indicadorElectronico) {
		this.indicadorElectronico = indicadorElectronico;
	}

	public String getCodigoUsuarioModificador() {
		return codigoUsuarioModificador;
	}

	public void setCodigoUsuarioModificador(String codigoUsuarioModificador) {
		this.codigoUsuarioModificador = codigoUsuarioModificador;
	}

	public String getFechaModificacion() {
		return fechaModificacion;
	}

	public void setFechaModificacion(String fechaModificacion) {
		this.fechaModificacion = fechaModificacion;
	}

	public String getHoraModificacion() {
		return horaModificacion;
	}

	public void setHoraModificacion(String horaModificacion) {
		this.horaModificacion = horaModificacion;
	}
	
	public Timestamp getFechaHoraModificacion() {
		if(this.getFechaModificacion() == null || this.getHoraModificacion() == null) return null;
		FechaBean fb = new FechaBean(this.getFechaModificacion() + "-" + this.getHoraModificacion(), "dd/MM/yyyy-HH:mm:ss");
		return fb.getTimestamp();
	}

	public String getDescTipoComprobanteRelacionado() {
		return descTipoComprobanteRelacionado;
	}

	public void setDescTipoComprobanteRelacionado(
			String descTipoComprobanteRelacionado) {
		this.descTipoComprobanteRelacionado = descTipoComprobanteRelacionado;
	}
}
