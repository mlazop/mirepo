package pe.gob.sunat.servicio2.registro.electronico.comppago.factura.model.dao.ibatis;

import pe.gob.sunat.framework.spring.util.dao.SqlMapDAOBase;
import pe.gob.sunat.servicio2.registro.electronico.comppago.factura.model.dao.T6576ArchRetDAO;
import pe.gob.sunat.servicio2.registro.electronico.comppago.factura.model.domain.PkComprobante;
import pe.gob.sunat.servicio2.registro.electronico.comppago.factura.model.domain.T6576ArchRetBean;

public class SqlMapT6576ArchRetDAOImpl extends SqlMapDAOBase implements T6576ArchRetDAO {

   
    public T6576ArchRetBean selectByPrimaryKey(String indModo, Object numTicket) {
        T6576ArchRetBean key = new T6576ArchRetBean();
        key.setIndModo(indModo);
        key.setNumTicket(numTicket);
        T6576ArchRetBean record = (T6576ArchRetBean) getSqlMapClientTemplate().queryForObject("t6576archret.ibatorgenerated_selectByPrimaryKey", key);
        return record;
    }


	@Override
	public T6576ArchRetBean selectByDocument(String numRuc, String codCpe, String numSerieCpe, Integer numCpe) {

        PkComprobante pk = new PkComprobante(numRuc, codCpe, numSerieCpe, numCpe);
        T6576ArchRetBean record = (T6576ArchRetBean) getSqlMapClientTemplate().queryForObject("t6576archret.selectByDocument", pk);
        return record;
		
	}


}