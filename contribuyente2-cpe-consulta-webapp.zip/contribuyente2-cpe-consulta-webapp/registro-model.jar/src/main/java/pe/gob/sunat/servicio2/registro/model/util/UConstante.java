package pe.gob.sunat.servicio2.registro.model.util;

import java.util.HashMap;
import java.util.Map;

public class UConstante {
	
	public static final String FORMAT_DATE ="dd/MM/yyyyy";
	public static final String FORMAT_HORA = "hh:mm aa";

	//TIPO DOCUMENTO IDENTIDAD
    public static final String COD_TIPO_DOCUMENTO_RUC = "6";
    public static final String COD_TIPO_DOCUMENTO_DNI = "1";
    public static final String COD_TIPO_DOCUMENTO_PASAPORTE  = "7";
    public static final String COD_TIPO_DOCUMENTO_DTS_RUC  = "0";
    public static final String COD_TIPO_DOCUMENTO_CARNET_EXT  = "4";
    public static final String COD_TIPO_DOCUMENTO_CED_DIPL  = "A";
    
    //TIPO DE COMPROBANTES
    public static final String COD_TIPO_COMP_FACTURA = "01";
    public static final String COD_TIPO_COMP_BOLETA = "03";
    public static final String COD_TIPO_COMP_NOTA_CRED = "07";
    public static final String COD_TIPO_COMP_NOTA_DEB = "08";
    public static final String COD_TIPO_COMP_TICKET = "12";
    
    //REGIMENES PERCEPCIONES
    public static final String COD_REGIMEN_PERCEP_TASA_ESPECIAL = "03";

    public static final String NUM_PARAMETRO_TIPO_DOCUMENTO = "044";
    public static final String NUM_PARAMETRO_REGIMEN_PERCEPCION = "974";
    public static final String NUM_PARAMETRO_REGIMEN_RETENCION = "975";
    public static final String NUM_PARAMETRO_ESTADO_COMPROBANTE_PERCEP_RETEN = "976";
    public static final String NUM_PARAMETRO_DOCUMENTOS_RELACIONADOS = "977";
    public static final String NUM_PARAMETRO_TIPO_COMPROBANTE= "233";
    public static final String NUM_PARAMETRO_TIPO_MONEDA= "864";
    public static final String NUM_PARAMETRO_ESTADO_ENVIO_RESUMEN = "A23";
    
    //Ini PAS20181U210300070
    public static final String NUM_PARAMETRO_API_CPES_NUBE = "C01";//779
    public static final int COD_RUBRO_CPE_NUBE = 32001;
    //Fin PAS20181U210300070
    
    public static final String COD_DOCUMENTOS_RELACIONADOS_PERCEPCION = "40";
    public static final String COD_DOCUMENTOS_RELACIONADOS_RETENCION = "20";
	public static final String VACIO = "";
	public static final String ESPACIO = " ";
	public static final String COD_SISTEMA_TREGISTRO = "16";
	public static final String COD_SUBSISTEMA_RETENCION = "1516";
	public static final String TIPO_RESPUESTA = "4";
	public static final String USUARIO_GENERICO = "SUNAT001";
	public static final String INDICADOR_ORIGEN = "2";
	public static final String TIPO_CONSULTA = "2";
	public static final Object SERIE_DOCUMENTO_E001 = "E001";
	public static final Object SERIE_DOCUMENTO_EB01 = "EB01";
	public static final Object SERIE_DOCUMENTO_FXXX = "F";
	public static final Object SERIE_DOCUMENTO_BXXX = "B";
	public static final String MSJ_RANGO_INVALIDO_COMP = "Serie y n&uacute;mero de documento no se encuentra en el rango autorizado por la SUNAT";
	
	//COD_ESTADO
	public static final String COD_EST_EMITIDO = "01";
	public static final String COD_EST_REVERTIDO = "02";
	public static final String COD_EST_ANULADO = "03";
	
	//MENSAJES
	public static final String MSJ_NO_AGENTE_RETENCION = "Usted no es un agente de retenci&oacute;n o no se encuentra vigente";
	public static final String MSJ_COMPROBANTE_NO_EXISTE = "El comprobante de retenci&oacute;n {0}-{1} no encontrado o no existe";
	public static final String MSJ_COMPRBANTE_NO_REGISTRADO_POR_AGENTE = "Sr. contribuyente Ud. no emiti&oacute; el comprobante de retenci&oacute;n del IGV {0} - {1}, por favor ingrese otro comprobante";
	public static final String MSJ_COMPROBANTE_REVERTIDO = "Se ha revertido correctamente el comprobante de retenci&oacute;n electr&oacute;nico  {0} - {1}";
	public static final String MSJ_COMPROBANTE_REVERTIDO_ADVERTENCIA = "Deber&aacute; entregar la reversi&oacute;n del comprobante de retenci&oacute;n a un correo electr&oacute;nico del cliente";
	public static final String MSJ_INGRESE_MOTIVO_REVESION = "Se debe ingresar el motivo de reversi&oacute;n";
	public static final String MSJ_CORREO_REVERSION_ENVIADO = "Se ha enviado el correo electr&oacute;nico correctamente";
	public static final String MSJ_CORREO_REVERSION_NO_ENVIADO = "Ocurri&oacute; un error al enviar el correo electr&oacute;nico, intente nuevamente";
	public static final String MSJ_ESTADO_NO_EMITIDO_CONFIRMADO = "El comprobante de retenci&oacute;n del IGV {0} - {1} no se encuentra EMITIDO o CONFIRMADO";
	public static final String MSJ_COMPROBANTE_EXISTE_REVERTIDO = "El comprobante de retenci&oacute;n ya se encuentra revertido";
	public static final String MSJ_COMPROBANTE_EXISTE_GEM = "El comprobante de retenci&oacute;n N&deg {0} - {1} fue emitido a trav&eacute;s de GEM, no se puede revertir";
	public static final String MSJ_RUC_NO_ENCONTRADO = "N&uacute;mero de RUC no encontrado. Ingrese nuevamente";
	public static final String MSJ_DNI_NO_ENCONTRADO = "N&uacute;mero de DNI no encontrado. Ingrese nuevamente";
	public static final String MSJ_COMPROBANTE_NO_EXISTE_SUNAT = "El comprobante electr&oacute;nico que intenta buscar no se encuentra en la SUNAT, o fue emitido por un sujeto distinto del Proveedor";
	public static final String MSJ_COMPROBANTE_NO_EXISTE_O_PENDIENTE = "El documento electr&oacute;nico no existe o est&aacute; pendiente de ser comunicado a la SUNAT. &iquest;Desea continuar?";
	public static final String MSJ_EMISION_COMPROBANTE_EXITO = "Se ha emitido correctamente el comprobante de retenci&oacute;n electr&oacute;nico E001-{0}"; 
	public static final String MSJ_EMISION_SIN_CORREO = "Deber&aacute; entregar el CPE a un correo electr&oacute;nico del proveedor o proporcionar una representaci&oacute;n impresa";
	public static final String MSJ_RESULTADOS_CONSULTA ="Ning&uacute;n registro encontrado con los criterios de b&uacute;squeda ingresados";
	public static final String MSJ_REVERTIDO_NO_ENCONTRADO ="El Nro. de documento <serie>-<numero> no se ha encontrado o no se encuentra en estado Revertido";
	public static final String MSJ_REVERTIDO_UTILIZADO ="El Nro. de documento de retenci<o>n revertido <serie>-<numero> ya fue utilizado por otro Comprobante de retenci<o>n electr<o>nico";
	
	//PROCEDENCIA AGENTES
	public static final String COD_PROC_AGENTE_RETEN = "0";
	public static final String COD_PROC_AGENTE_PERCEP = "1";
	public static final String COD_PROC_AGENTE_PERCEP_VI = "9";
	public static final int    COD_PROC_AGENTE_EXCEP_PERCEP = 39;
	
	//ESTADO AGENTE
	public static final String COD_ESTADO_AGENTE_ACTIVO = "00";
	public static final String COD_ESTADO_AGENTE_RET_ACTIVO = "04";
	
	public static final String COD_CPE_RETENCION = "20";
	
	//PROCEDENCIA DEL COMPROBANTE DE PERCEPCION
	public static final String COD_PROCEDENCIA_PORTAL = "1";
	public static final String COD_PROCEDENCIA_GEM = "2";
	
	//PARAMETROS ENVIAR CORREO
	public static final String ASUNTO_RETENCION_EMITIDO = "Comprobante de Retenci�n Electr�nico N. {0} - {1} - EMITIDO";
	public static final String ASUNTO_RETENCION_REVERSION = "Comprobante de Retenci�n Electr�nico N. {0} - {1} - REVERTIDO";
	public static final String ASUNTO_RETENCION_CONSULTA_EMI = "Comprobante de Retenci�n Electr�nico N. {0} - {1} - Emitido / Consultas";
	public static final String ASUNTO_RETENCION_CONSULTA_REV = "Comprobante de Retenci�n Electr�nico N. {0} - {1} - Revertido / Consultas";
	
	//TIPO DE MONEDAS
	public static final String COD_MONEDA_SOL = "PEN";
	public static final String COD_MONEDA_DOLAR_USA = "USD";
	public static final String COD_MONEDA_DOLAR_CANADA = "CAD";
	public static final String COD_MONEDA_LIBRA = "GBP";
	public static final String COD_MONEDA_YEN = "JPY";
	public static final String COD_MONEDA_CORONA = "SEK";
	public static final String COD_MONEDA_FRANCO = "CHF";
	public static final String COD_MONEDA_EURO = "EUR";
	
	public static final String COD_MODO_ARCHIVO_XML = "1";
	public static final String COD_MODO_ARCHIVO_PDF = "2";
	
	//PARAMETRO CONSULTAR TODOS
	public static final String COD_CONSULTAR_TODOS = "000";

	public static final String REGEX_EMAIL = "^[_A-Za-z0-9-\\+]+(\\.[_A-Za-z0-9-]+)*@[A-Za-z0-9-]+(\\.[A-Za-z0-9]+)*(\\.[A-Za-z]{2,})?$";
	
	public static final Map<String, String> listaSimboloMonedas = new HashMap<String, String>();
	
	static {
		listaSimboloMonedas.put("PEN", "S/");
		listaSimboloMonedas.put("USD", "$");
		listaSimboloMonedas.put("CAD", "C$");
		listaSimboloMonedas.put("GBP", "�");
		listaSimboloMonedas.put("JPY", "�");
		listaSimboloMonedas.put("SEK", "Kr");
		listaSimboloMonedas.put("CHF", "Fr");
		listaSimboloMonedas.put("EUR", "�");
	}
}

