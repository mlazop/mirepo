package pe.gob.sunat.servicio2.registro.electronico.comppago.factura.model.dao;

import pe.gob.sunat.servicio2.registro.electronico.comppago.factura.model.domain.T4534Bean;


/**
 * Dao para el control de la tabla T4534RELCOMPELEC  
 * @author narista
 */
public interface T4534DAO {
	
	public  abstract void insertar(T4534Bean t4534Bean);
	public  abstract T4534Bean findByPK(String nroRUC, String serie ,String tipocomp, Integer  numcomp );
	
}
