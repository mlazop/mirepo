package pe.gob.sunat.servicio2.registro.electronico.comppago.model.domain;

import java.io.Serializable;
import java.math.BigDecimal;
import java.sql.Date;

public class T3634Bean implements Serializable {
	private static final long serialVersionUID = -2927669303445471403L;

	private String num_ruc;
	private String num_serie;
	private Integer num_nota;
	private String cod_docide;
	private String num_docide;
	private String cod_tipcomp_ori;
	private String num_serie_ori;
	private Integer num_comprob_ori;
	private String des_motivo_nc;
	private String des_motivo2_nc;
	private String des_observ_nc;
	private String des_observ2_nc;
	private Date fec_registro;
	private Date fec_emision_nc;
	private String ind_estado_nc;
	private String cod_moneda;
	private BigDecimal mto_nc_bruto;
	private BigDecimal mto_nc_ret;
	private BigDecimal mto_nc_neto;
	private Integer ann_registro;
	private Integer num_indice;
	private Integer num_archivo;
	private String cod_usumodif;
	private Date fec_modif;
	
	public String getNum_ruc() {
		return num_ruc;
	}
	public void setNum_ruc(String numRuc) {
		num_ruc = numRuc;
	}
	public String getNum_serie() {
		return num_serie;
	}
	public void setNum_serie(String numSerie) {
		num_serie = numSerie;
	}
	public Integer getNum_nota() {
		return num_nota;
	}
	public void setNum_nota(Integer numNota) {
		num_nota = numNota;
	}
	public String getCod_docide() {
		return cod_docide;
	}
	public void setCod_docide(String codDocide) {
		cod_docide = codDocide;
	}
	public String getNum_docide() {
		return num_docide;
	}
	public void setNum_docide(String numDocide) {
		num_docide = numDocide;
	}
	public String getCod_tipcomp_ori() {
		return cod_tipcomp_ori;
	}
	public void setCod_tipcomp_ori(String codTipcompOri) {
		cod_tipcomp_ori = codTipcompOri;
	}
	public String getNum_serie_ori() {
		return num_serie_ori;
	}
	public void setNum_serie_ori(String numSerieOri) {
		num_serie_ori = numSerieOri;
	}
	public Integer getNum_comprob_ori() {
		return num_comprob_ori;
	}
	public void setNum_comprob_ori(Integer numComprobOri) {
		num_comprob_ori = numComprobOri;
	}
	public String getDes_motivo_nc() {
		return des_motivo_nc;
	}
	public void setDes_motivo_nc(String desMotivoNc) {
		des_motivo_nc = desMotivoNc;
	}
	public String getDes_motivo2_nc() {
		return des_motivo2_nc;
	}
	public void setDes_motivo2_nc(String desMotivo2Nc) {
		des_motivo2_nc = desMotivo2Nc;
	}
	public String getDes_observ_nc() {
		return des_observ_nc;
	}
	public void setDes_observ_nc(String desObservNc) {
		des_observ_nc = desObservNc;
	}
	public String getDes_observ2_nc() {
		return des_observ2_nc;
	}
	public void setDes_observ2_nc(String desObserv2Nc) {
		des_observ2_nc = desObserv2Nc;
	}
	public Date getFec_registro() {
		return fec_registro;
	}
	public void setFec_registro(Date fecRegistro) {
		fec_registro = fecRegistro;
	}
	public Date getFec_emision_nc() {
		return fec_emision_nc;
	}
	public void setFec_emision_nc(Date fecEmisionNc) {
		fec_emision_nc = fecEmisionNc;
	}
	public String getInd_estado_nc() {
		return ind_estado_nc;
	}
	public void setInd_estado_nc(String indEstadoNc) {
		ind_estado_nc = indEstadoNc;
	}
	public String getCod_moneda() {
		return cod_moneda;
	}
	public void setCod_moneda(String codMoneda) {
		cod_moneda = codMoneda;
	}
	public BigDecimal getMto_nc_bruto() {
		return mto_nc_bruto;
	}
	public void setMto_nc_bruto(BigDecimal mtoNcBruto) {
		mto_nc_bruto = mtoNcBruto;
	}
	public BigDecimal getMto_nc_ret() {
		return mto_nc_ret;
	}
	public void setMto_nc_ret(BigDecimal mtoNcRet) {
		mto_nc_ret = mtoNcRet;
	}
	public BigDecimal getMto_nc_neto() {
		return mto_nc_neto;
	}
	public void setMto_nc_neto(BigDecimal mtoNcNeto) {
		mto_nc_neto = mtoNcNeto;
	}
	public Integer getAnn_registro() {
		return ann_registro;
	}
	public void setAnn_registro(Integer annRegistro) {
		ann_registro = annRegistro;
	}
	public Integer getNum_indice() {
		return num_indice;
	}
	public void setNum_indice(Integer numIndice) {
		num_indice = numIndice;
	}
	public Integer getNum_archivo() {
		return num_archivo;
	}
	public void setNum_archivo(Integer numArchivo) {
		num_archivo = numArchivo;
	}
	public String getCod_usumodif() {
		return cod_usumodif;
	}
	public void setCod_usumodif(String codUsumodif) {
		cod_usumodif = codUsumodif;
	}
	public Date getFec_modif() {
		return fec_modif;
	}
	public void setFec_modif(Date fecModif) {
		fec_modif = fecModif;
	}

}
