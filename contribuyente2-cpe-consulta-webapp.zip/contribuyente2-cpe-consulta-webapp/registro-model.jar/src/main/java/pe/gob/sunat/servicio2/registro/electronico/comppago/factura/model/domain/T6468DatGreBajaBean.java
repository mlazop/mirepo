package pe.gob.sunat.servicio2.registro.electronico.comppago.factura.model.domain;

import java.io.Serializable;
import java.util.Date;

public class T6468DatGreBajaBean implements Serializable   {

	
	private static final long serialVersionUID = -6300908528710205658L;
	
	private String num_ruc;
	private String cod_gre;
	private String num_serie_gre;
	private Integer num_gre;
	private Date fec_baja;	
	private String cod_motbaja;	
	private String cod_usuregis;	
	private Date fec_regis;	
	private String cod_usumodif;	
	private Date fec_modif;
	
	public String getNum_ruc() {
		return num_ruc;
	}
	public void setNum_ruc(String num_ruc) {
		this.num_ruc = num_ruc;
	}
	public String getCod_gre() {
		return cod_gre;
	}
	public void setCod_gre(String cod_gre) {
		this.cod_gre = cod_gre;
	}
	public String getNum_serie_gre() {
		return num_serie_gre;
	}
	public void setNum_serie_gre(String num_serie_gre) {
		this.num_serie_gre = num_serie_gre;
	}
	public Integer getNum_gre() {
		return num_gre;
	}
	public void setNum_gre(Integer num_gre) {
		this.num_gre = num_gre;
	}
	public Date getFec_baja() {
		return fec_baja;
	}
	public void setFec_baja(Date fec_baja) {
		this.fec_baja = fec_baja;
	}
	public String getCod_motbaja() {
		return cod_motbaja;
	}
	public void setCod_motbaja(String cod_motbaja) {
		this.cod_motbaja = cod_motbaja;
	}
	public String getCod_usuregis() {
		return cod_usuregis;
	}
	public void setCod_usuregis(String cod_usuregis) {
		this.cod_usuregis = cod_usuregis;
	}
	public Date getFec_regis() {
		return fec_regis;
	}
	public void setFec_regis(Date fec_regis) {
		this.fec_regis = fec_regis;
	}
	public String getCod_usumodif() {
		return cod_usumodif;
	}
	public void setCod_usumodif(String cod_usumodif) {
		this.cod_usumodif = cod_usumodif;
	}
	public Date getFec_modif() {
		return fec_modif;
	}
	public void setFec_modif(Date fec_modif) {
		this.fec_modif = fec_modif;
	}
	
}
