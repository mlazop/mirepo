package pe.gob.sunat.servicio2.registro.electronico.comppago.consulta.model.dao;

import pe.gob.sunat.servicio2.registro.electronico.comppago.consulta.model.domain.T6491Bean;

public interface T6491DAO {

	public abstract void inserta(T6491Bean bean);
}
