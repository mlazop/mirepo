package pe.gob.sunat.servicio2.registro.model.dao.ibatis;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import pe.gob.sunat.framework.spring.util.dao.SqlMapDAOBase;
import pe.gob.sunat.servicio2.registro.model.dao.T140DAO;
import pe.gob.sunat.servicio2.registro.model.domain.T140Bean;
@SuppressWarnings({"deprecation","unchecked", "rawtypes"})
public class SqlMapT140DAOImpl extends SqlMapDAOBase implements T140DAO {

	@Override
	public List<T140Bean> findByRucFormNroAuto(String ruc, String form, Integer orden){
		if (log.isDebugEnabled()) {log.debug("SQLMapDao findByRucFormNroAuto (" +ruc+","+form+","+orden+ ")");}
		
		Map m = new HashMap();
		m.put("ruc", ruc);
		m.put("form", form);
		m.put("orden", orden);
		
		return (List<T140Bean>) getSqlMapClientTemplate().queryForList("T140.findByRucFormNroAuto", m);
	}
	
}
