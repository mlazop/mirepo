package pe.gob.sunat.servicio2.registro.electronico.comppago.factura.model.dao.ibatis;

import pe.gob.sunat.framework.spring.util.dao.SqlMapDAOBase;
import pe.gob.sunat.servicio2.registro.electronico.comppago.factura.model.dao.T6464ArcGreDAO;
import pe.gob.sunat.servicio2.registro.electronico.comppago.factura.model.domain.PkComprobante;
import pe.gob.sunat.servicio2.registro.electronico.comppago.factura.model.domain.T6464ArcGreBean;

public class SqlMapT6464ArcGreDAOImpl extends SqlMapDAOBase implements T6464ArcGreDAO {
	
	
	@Override
	public T6464ArcGreBean selectDoc(String numRuc, String codCpe, String numSerieCpe, Integer numCpe) {
		
		if (log.isDebugEnabled()) log.debug("SqlMapT6464ArcGreDAOImpl.selectDoc - Inic");
		
	    PkComprobante pk = new PkComprobante(numRuc, codCpe, numSerieCpe, numCpe);
		
		T6464ArcGreBean retVal = (T6464ArcGreBean)getSqlMapClientTemplate().queryForObject("t6464arcgre.selectDoc",pk);
		
		if (log.isDebugEnabled()) log.debug("SqlMapT6464ArcGreDAOImpl.selectDoc - Fin");
		return retVal;
		
	}

	@Override
	public T6464ArcGreBean selectByPrimaryKey(String nroTicket, String modo) {

		if (log.isDebugEnabled()) log.debug("SqlMapT6464ArcGreDAOImpl.selectByPrimaryKey - Inic");
		
		T6464ArcGreBean data = new T6464ArcGreBean();
		data.setNumTicket(nroTicket);
		data.setIndModo(modo);
		T6464ArcGreBean retVal = (T6464ArcGreBean)getSqlMapClientTemplate().queryForObject("t6464arcgre.selectByPrimaryKey",data);
		
		if (log.isDebugEnabled()) log.debug("SqlMapT6464ArcGreDAOImpl.selectByPrimaryKey - Fin");
		
		return retVal;
	}

	
}
