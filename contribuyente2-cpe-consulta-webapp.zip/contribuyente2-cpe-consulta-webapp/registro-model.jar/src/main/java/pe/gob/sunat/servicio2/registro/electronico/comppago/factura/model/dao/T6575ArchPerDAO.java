package pe.gob.sunat.servicio2.registro.electronico.comppago.factura.model.dao;

import pe.gob.sunat.servicio2.registro.electronico.comppago.factura.model.domain.T6575ArchPerBean;


public interface T6575ArchPerDAO {

	public T6575ArchPerBean selectByPrimaryKey(String indModo, Long numTicket);
    
    public T6575ArchPerBean selectByDocument(String numRuc, String codCpe, String numSerieCpe, Integer numCpe);
    
}