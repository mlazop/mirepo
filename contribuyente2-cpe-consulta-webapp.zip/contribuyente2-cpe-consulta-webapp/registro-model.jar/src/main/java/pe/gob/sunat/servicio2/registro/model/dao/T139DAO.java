package pe.gob.sunat.servicio2.registro.model.dao;

import pe.gob.sunat.servicio2.registro.model.domain.T139Bean;

public interface T139DAO {

	public T139Bean findByRucAutorizacion(String ruc, String autorizacion);
}
