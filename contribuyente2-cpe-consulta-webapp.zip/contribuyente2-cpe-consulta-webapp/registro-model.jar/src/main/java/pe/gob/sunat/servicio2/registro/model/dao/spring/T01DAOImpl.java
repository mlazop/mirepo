package pe.gob.sunat.servicio2.registro.model.dao.spring;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.TreeMap;

import javax.sql.DataSource;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.dao.IncorrectResultSizeDataAccessException;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;

import pe.gob.sunat.framework.spring.util.date.FechaBean;
import pe.gob.sunat.servicio2.registro.model.dao.T01DAO;
import pe.gob.sunat.servicio2.registro.model.domain.T01Bean;

@SuppressWarnings({"unchecked", "rawtypes"})
public class T01DAOImpl implements T01DAO {
	private static final long serialVersionUID = -7620828220507189880L;

	protected final Log log = LogFactory.getLog(getClass());

	private final String findAllByNumeroArgumento = "SELECT * FROM t01param WHERE t01_numero = ? AND t01_argumento = ?;";
	private final String findAllCdrValidoByNumero = "SELECT * FROM t01param WHERE t01_numero = ? AND t01_tipo='D' AND t01_funcion[26,27] = '1';";
	private final String findByNumeroArgumento = "SELECT t01_argumento, t01_funcion FROM t01param WHERE t01_numero = ? AND t01_argumento = ?;";	
	private final String findUnidadMedidaVigente = "SELECT t01_argumento, t01_funcion[1,30] FROM t01param WHERE t01_numero = ? AND t01_funcion[61] = '1';";
	
	private final String findUnidadMedidaExportacion = "SELECT t01_argumento, t01_funcion[1,30] FROM t01param WHERE t01_numero = ? AND t01_funcion[61] = '1';";
	private final String findUnidadMedidaNoExportacion = "SELECT t01_argumento, t01_funcion[1,30] FROM t01param WHERE t01_numero = ? AND t01_funcion[61,62] = '11';";
	private final String findTiposDocActivos= "SELECT t01_argumento, t01_funcion[1,47] FROM t01param WHERE t01_numero=? AND t01_tipo='D' AND t01_funcion[47,47] =1;";

	private final String findTiposComprobante = "SELECT t01_argumento, t01_funcion[1,70] FROM t01param WHERE t01_numero = ? AND t01_tipo='D' AND t01_funcion[70] IN ('1','2','3') order by t01_funcion[70] ;";
	
	private JdbcTemplate jdbcTemplate;
	
	public void setDataSource(DataSource dataSource) {
		this.jdbcTemplate = new JdbcTemplate(dataSource);
	}
	
	@Override
	public  List<T01Bean> findTiposComprobante() {
		if (log.isDebugEnabled()) {log.debug("findTiposComprobante");}

		try {
		    RowMapper mapper = new RowMapper() {
		    	public Object mapRow(ResultSet rs, int rowNum) throws SQLException {
		    		T01Bean bean = new T01Bean();
		    		bean.setNumero("233");
		    		bean.setTipo("D");
		    		bean.setArgumento(rs.getString("t01_argumento"));
		    		bean.setFuncion(rs.getString("t01_funcion"));
	    		
		            return bean;
		        }
		    };  

			return (List<T01Bean>)jdbcTemplate.query(this.findTiposComprobante,new Object[]{"233"}, mapper);
		}
		catch(IncorrectResultSizeDataAccessException e) { return null; }
	}
	

	@Override
	public  List<T01Bean> findTiposDocumentoActivos() {
		if (log.isDebugEnabled()) {log.debug("findTiposDocumentoActivos");}

		try {
		    RowMapper mapper = new RowMapper() {
		    	public Object mapRow(ResultSet rs, int rowNum) throws SQLException {
		    		T01Bean bean = new T01Bean();
		    		bean.setNumero("044");
		    		bean.setTipo("D");
		    		bean.setArgumento(rs.getString("t01_argumento"));
		    		bean.setFuncion(rs.getString("t01_funcion"));
	    		
		            return bean;
		        }
		    };  

			return (List<T01Bean>)jdbcTemplate.query(this.findTiposDocActivos,new Object[]{"044"}, mapper);
		}
		catch(IncorrectResultSizeDataAccessException e) { return null; }
	}
	
	@Override
	public T01Bean findAllByNumeroArgumento(String numero, String argumento) {
		if (log.isDebugEnabled()) {log.debug("findAllByNumeroArgumento( " + numero + ", " + argumento + " )");}

		try {
		    RowMapper mapper = new RowMapper() {
		    	public Object mapRow(ResultSet rs, int rowNum) throws SQLException {
		    		T01Bean bean = new T01Bean();
		    		bean.setNumero(rs.getString("t01_numero"));
		    		bean.setTipo(rs.getString("t01_tipo"));
		    		bean.setArgumento(rs.getString("t01_argumento"));
		    		bean.setFuncion(rs.getString("t01_funcion"));
		    		bean.setUsuarioActualizacion(rs.getString("t01_user"));
		    		bean.setFechaActualizacion(new FechaBean(rs.getTimestamp("t01_factualiz")));
		    		bean.setHoraActualizacion(rs.getString("t01_hora"));		    		
		            return bean;
		        }
		    };  

			return (T01Bean)jdbcTemplate.queryForObject(this.findAllByNumeroArgumento,
					new Object[]{numero, argumento}, mapper);
		}
		catch(IncorrectResultSizeDataAccessException e) { return null; }
	}
	

	@Override
	public List<T01Bean> findUnidadMedidaVigente(String numero) {
		if (log.isDebugEnabled()) {log.debug("findUnidadMedidaVigente( " + numero + " )");}

		try {
		    RowMapper mapper = new RowMapper() {
		    	public Object mapRow(ResultSet rs, int rowNum) throws SQLException {
		    		T01Bean bean = new T01Bean();
		    		bean.setArgumento(rs.getString("t01_argumento"));
		    		bean.setFuncion(rs.getString("t01_funcion").trim());
		            return bean;
		        }
		    };

			return (List<T01Bean>)jdbcTemplate.query(this.findUnidadMedidaVigente,
					new Object[]{numero}, mapper);
		}
		catch(IncorrectResultSizeDataAccessException e) { return null; }
	}
	
	@Override
	public T01Bean findByNumeroArgumento(String numero, String argumento) {
		if (log.isDebugEnabled()) {log.debug("T01DAOImpl findByNumeroArgumento( " + numero + " , "+ argumento + " )");}

		try {
		    RowMapper mapper = new RowMapper() {
		    	public Object mapRow(ResultSet rs, int rowNum) throws SQLException {
		    		T01Bean bean = new T01Bean();
		    		bean.setArgumento(rs.getString("t01_argumento"));
		    		bean.setFuncion(rs.getString("t01_funcion"));
		            return bean;
		        }
		    };
		    log.debug("T01 Mapeado ok");
		    Object retorno = jdbcTemplate.queryForObject(this.findByNumeroArgumento,new Object[]{numero, argumento}, mapper);
			return (T01Bean )retorno;
		}
		catch(IncorrectResultSizeDataAccessException e) { return null; }
	}
	

	@Override
	public List<T01Bean> findUnidadMedidaExportacion(String numero) {
		if (log.isDebugEnabled()) {log.debug("findUnidadMedidaExportacion( " + numero + " )");}

		try {
		    RowMapper mapper = new RowMapper() {
		    	public Object mapRow(ResultSet rs, int rowNum) throws SQLException {
		    		T01Bean bean = new T01Bean();
		    		bean.setArgumento(rs.getString("t01_argumento"));
		    		bean.setFuncion(rs.getString("t01_funcion").trim());
		            return bean;
		        }
		    };

			return (List<T01Bean>)jdbcTemplate.query(this.findUnidadMedidaExportacion,
					new Object[]{numero}, mapper);
		}
		catch(IncorrectResultSizeDataAccessException e) { return null; }
	}
	

	@Override
	public List<T01Bean> findUnidadMedidaNoExportacion(String numero) {
		if (log.isDebugEnabled()) {log.debug("findUnidadMedidaNoExportacion( " + numero + " )");}

		try {
		    RowMapper mapper = new RowMapper() {
		    	public Object mapRow(ResultSet rs, int rowNum) throws SQLException {
		    		T01Bean bean = new T01Bean();
		    		bean.setArgumento(rs.getString("t01_argumento"));
		    		bean.setFuncion(rs.getString("t01_funcion").trim());
		            return bean;
		        }
		    };

			return (List<T01Bean>)jdbcTemplate.query(this.findUnidadMedidaNoExportacion,
					new Object[]{numero}, mapper);
		}
		catch(IncorrectResultSizeDataAccessException e) { return null; }
	}

	@Override
	public String findByArgumento(String numero, String argumento) {

		return null;
	}

	@Override
	public List findByArgumentoINfuncion(Map param) {

		return null;
	}

	@Override
	public List findByArgumentoPatron(String numero, String argumento) {

		return null;
	}

	@Override
	public TreeMap mbuscar(ArrayList v) {

		return null;
	}

	@Override
	public T01Bean findByNumeroArgumentoCache(String numero, String argumento) {

		return null;
	}

	@Override
	public List<T01Bean> findByNumeroCache(String numero) {

		return null;
	}

	@Override
	public List buscaParametroLimiteEnte(Map param) {

		return null;
	}

	@Override
	public List buscaParametroPorEnte(Map param) {

		return null;
	}

	@Override
	public void desacticaMontoVigente(Map param) {

		
	}

	@Override
	public void insertNuevoMonto(Map param) {

		
	}

	@Override
	public void updateMontoHoy(Map param) {

		
	}

	@Override
	public String findByNumero003Libros(String argumento) {
		throw new RuntimeException("metodo aun no esta implementado");
		
	}

	@Override
	public List<T01Bean> findByNumero052Dependencia(String codDependencia) {
		throw new RuntimeException("metodo aun no esta implementado");
	}

	@Override
	public List<T01Bean> findByNumeroConsultaComprobante(String numero) {
		if (log.isDebugEnabled()) {log.debug("T01DAOImpl findByNumeroConsultaComprobante( " + numero + " )");}

		try {
		    RowMapper mapper = new RowMapper() {
		    	public Object mapRow(ResultSet rs, int rowNum) throws SQLException {
		    		T01Bean bean = new T01Bean();
		    		bean.setNumero(rs.getString("t01_numero"));
		    		bean.setTipo(rs.getString("t01_tipo"));
		    		bean.setArgumento(rs.getString("t01_argumento"));
		    		bean.setFuncion(rs.getString("t01_funcion"));
		    		bean.setUsuarioActualizacion(rs.getString("t01_user"));
		    		bean.setFechaActualizacion(new FechaBean(rs.getTimestamp("t01_factualiz")));
		    		bean.setHoraActualizacion(rs.getString("t01_hora"));		    		
		            return bean;
		        }
		    };  
			return (List<T01Bean>)jdbcTemplate.query(this.findAllCdrValidoByNumero,
					new Object[]{numero}, mapper);
		}
		catch(IncorrectResultSizeDataAccessException e) { return null; }
	}	
	

}
