package pe.gob.sunat.servicio2.registro.electronico.comppago.factura.model.domain;

import java.io.Serializable;
import java.util.Date;

public class T6460CabGreBean implements Serializable{

	private static final long serialVersionUID = 1L;
	
	private PkComprobante pkGuia;
	
	private Date fecEmision;
	
	private String codUbiFiscal;
	
	private String desUbiFiscal;
	
	private String codDocIdeRecep;
	
	private String numDocIdeRecep;
	
	private String nomDestinatario;
	
	private String indCamDestin;
	
	private String indTransProgramado;
	
	private String codMotTraslado;
	
	private String desMotTraslado;
	
	private String codMotEmisionComp;
	
	private String valPesBrutGuia;
	
	private String obsGre;
		
	private String indEstado;
	
	private Long numTicket;
	
	private AuditoriaBean auditoria;
	
	public Date getFecEmision() {
		return fecEmision;
	}

	public PkComprobante getPkGuia() {
		return pkGuia;
	}

	public void setPkGuia(PkComprobante pkGuia) {
		this.pkGuia = pkGuia;
	}

	public void setFecEmision(Date fecEmision) {
		this.fecEmision = fecEmision;
	}

	public String getCodDocIdeRecep() {
		return codDocIdeRecep;
	}

	public void setCodDocIdeRecep(String codDocIdeRecep) {
		this.codDocIdeRecep = codDocIdeRecep;
	}

	public String getNumDocIdeRecep() {
		return numDocIdeRecep;
	}

	public void setNumDocIdeRecep(String numDocIdeRecep) {
		this.numDocIdeRecep = numDocIdeRecep;
	}

	public String getNomDestinatario() {
		return nomDestinatario;
	}

	public void setNomDestinatario(String nomDestinatario) {
		this.nomDestinatario = nomDestinatario;
	}

	public String isIndCamDestin() {
		return indCamDestin;
	}

	public void setIndCamDestin(String indCamDestin) {
		this.indCamDestin = indCamDestin;
	}

	public String isIndTransProgramado() {
		return indTransProgramado;
	}

	public void setIndTransProgramado(String indTransProgramado) {
		this.indTransProgramado = indTransProgramado;
	}

	public String getCodMotTraslado() {
		return codMotTraslado;
	}

	public void setCodMotTraslado(String codMotTraslado) {
		this.codMotTraslado = codMotTraslado;
	}

	public String getDesMotTraslado() {
		return desMotTraslado;
	}

	public void setDesMotTraslado(String desMotTraslado) {
		this.desMotTraslado = desMotTraslado;
	}

	public String getIndCamDestin() {
		return indCamDestin;
	}

	public String getIndTransProgramado() {
		return indTransProgramado;
	}

	public String getCodMotEmisionComp() {
		return codMotEmisionComp;
	}

	public void setCodMotEmisionComp(String codMotEmisionComp) {
		this.codMotEmisionComp = codMotEmisionComp;
	}

	public String getValPesBrutGuia() {
		return valPesBrutGuia;
	}

	public void setValPesBrutGuia(String valPesBrutGuia) {
		this.valPesBrutGuia = valPesBrutGuia;
	}

	public String getObsGre() {
		return obsGre;
	}

	public void setObsGre(String obsGre) {
		this.obsGre = obsGre;
	}

	public Long getNumTicket() {
		return numTicket;
	}

	public void setNumTicket(Long numTicket) {
		this.numTicket = numTicket;
	}

	public String getIndEstado() {
		return indEstado;
	}

	public void setIndEstado(String indEstado) {
		this.indEstado = indEstado;
	}

	public String getCodUbiFiscal() {
		return codUbiFiscal;
	}

	public void setCodUbiFiscal(String codUbiFiscal) {
		this.codUbiFiscal = codUbiFiscal;
	}

	public String getDesUbiFiscal() {
		return desUbiFiscal;
	}

	public void setDesUbiFiscal(String desUbiFiscal) {
		this.desUbiFiscal = desUbiFiscal;
	}

	public AuditoriaBean getAuditoria() {
		return auditoria;
	}

	public void setAuditoria(AuditoriaBean auditoria) {
		this.auditoria = auditoria;
	}
	
	

}
