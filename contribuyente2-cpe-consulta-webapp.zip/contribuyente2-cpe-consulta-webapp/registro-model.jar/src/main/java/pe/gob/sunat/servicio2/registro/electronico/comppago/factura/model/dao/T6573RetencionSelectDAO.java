package pe.gob.sunat.servicio2.registro.electronico.comppago.factura.model.dao;

import pe.gob.sunat.servicio2.registro.electronico.comppago.factura.model.domain.PkComprobante;
import pe.gob.sunat.servicio2.registro.electronico.comppago.factura.model.domain.T6573RetencionBean;

public interface T6573RetencionSelectDAO {


    T6573RetencionBean selectByPrimaryKey(String codCpe, Integer numCpe, String numRuc, String numSerieCpe);
    
    T6573RetencionBean buscarPorPk(String numeroRuc, String codigoGuia, String numeroSerie, Integer numeroGuia);
    
    int countSelectByPrimaryKey(String codCpe, Integer numCpe, String numRuc, String numSerieCpe);
    
    PkComprobante selectByTicket(Long nroTicket);

}