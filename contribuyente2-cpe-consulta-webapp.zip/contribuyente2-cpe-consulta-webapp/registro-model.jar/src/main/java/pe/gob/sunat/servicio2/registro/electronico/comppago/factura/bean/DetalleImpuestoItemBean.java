package pe.gob.sunat.servicio2.registro.electronico.comppago.factura.bean;

import java.io.Serializable;

/**
 * POJO del detalle de impuestos del item.
 * Ambito: XML.
 * @author Carlos Enrique Quispe Salazar
 * */
public class DetalleImpuestoItemBean implements Serializable {
	private static final long serialVersionUID = 1L;
	private String montoImpuesto;				/** taxtAmount */
	private String porcentajeImpuesto;			/** percent */
	private String codigoTributo;				/** categoryID */
	private String descripcionTributo;			/** categoryName */

	public String getMontoImpuesto() {
		return montoImpuesto;
	}

	public void setMontoImpuesto(String montoImpuesto) {
		this.montoImpuesto = montoImpuesto;
	}

	public String getPorcentajeImpuesto() {
		return porcentajeImpuesto;
	}

	public void setPorcentajeImpuesto(String porcentajeImpuesto) {
		this.porcentajeImpuesto = porcentajeImpuesto;
	}
	
	public String getCodigoTributo() {
		return codigoTributo;
	}
	
	public void setCodigoTributo(String codigoTributo) {
		this.codigoTributo = codigoTributo;
	}
	
	public String getDescripcionTributo() {
		return descripcionTributo;
	}
	
	public void setDescripcionTributo(String descripcionTributo) {
		this.descripcionTributo = descripcionTributo;
	}
}
