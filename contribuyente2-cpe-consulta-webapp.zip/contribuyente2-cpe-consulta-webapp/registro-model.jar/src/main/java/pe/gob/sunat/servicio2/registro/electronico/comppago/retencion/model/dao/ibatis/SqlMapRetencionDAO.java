package pe.gob.sunat.servicio2.registro.electronico.comppago.retencion.model.dao.ibatis;


import java.util.HashMap;

import org.springframework.stereotype.Repository;

import pe.gob.sunat.servicio2.registro.electronico.comppago.retencion.model.RetencionBean;
import pe.gob.sunat.servicio2.registro.electronico.comppago.retencion.model.dao.RetencionDAO;

@Repository("retencionDAO")
public class SqlMapRetencionDAO extends BaseCpeleDAO implements RetencionDAO {

	@Override
	public RetencionBean selectPorEmisor(RetencionBean retencionBean) {
		return (RetencionBean) getSqlMapClientTemplate().queryForObject("t6573.selectPorEmisor", retencionBean);
	}	
	
	///INICIO PAS20191U210100160
	@Override
	public String buscarCanalEnvio( HashMap < String, Object > mapParametros ) {
		return ( String ) getSqlMapClientTemplate ().queryForObject ( "t6573.buscarCanalEnvio", mapParametros );
	}
	
	@Override
	public int countRechazo( HashMap < String, Object > mapParametros ) {
		return ( Integer ) getSqlMapClientTemplate ().queryForObject ( "t6573.countRechazo", mapParametros );
	}
	///FIN PAS20191U210100160
}
