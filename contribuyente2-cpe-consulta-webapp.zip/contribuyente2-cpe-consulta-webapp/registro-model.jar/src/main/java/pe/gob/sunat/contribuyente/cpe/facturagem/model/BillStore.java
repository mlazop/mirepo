package pe.gob.sunat.contribuyente.cpe.facturagem.model;

import java.io.Serializable;
import java.util.Arrays;
import java.util.Date;

public class BillStore implements Serializable {
	private static final long serialVersionUID = 1L;
	
	private String ticket;
	private String filename;
	private Integer correlativo;
	private String modo;
	private byte[] contenido;
	private String usuarioModificador;
	//private String fechaModificacion;
	private Date fechaModificacion;

	public String getTicket() {
		return ticket;
	}
	
	public void setTicket(String ticket) {
		this.ticket = ticket;
	}

	public String getModo() {
		return modo;
	}

	public void setModo(String modo) {
		this.modo = modo;
	}

	public byte[] getContenido() {
		return contenido;
	}

	public void setContenido(byte[] contenido) {
		this.contenido = contenido;
	}

	public String getUsuarioModificador() {
		return usuarioModificador;
	}

	public void setUsuarioModificador(String usuarioModificador) {
		this.usuarioModificador = usuarioModificador;
	}

	public Date getFechaModificacion() {
		return fechaModificacion;
	}

	public void setFechaModificacion(Date fechaModificacion) {
		this.fechaModificacion = fechaModificacion;
	}

	public Integer getCorrelativo() {
	    return correlativo;
	}

	public void setCorrelativo(Integer correlativo) {
	    this.correlativo = correlativo;
	}

	public String getFilename() {
	    return filename;
	}

	public void setFilename(String filename) {
	    this.filename = filename;
	}

	@Override
	public String toString() {
		return "BillStore [ticket=" + ticket + ", filename=" + filename + ", correlativo=" + correlativo + ", modo="
				+ modo + ", contenido=" + Arrays.toString(contenido) + ", usuarioModificador=" + usuarioModificador
				+ ", fechaModificacion=" + fechaModificacion + "]";
	}
	
	
}
