package pe.gob.sunat.servicio2.registro.model.domain;

import java.io.Serializable;

import pe.gob.sunat.framework.spring.util.date.FechaBean;

public class T139Bean implements Serializable{

	private static final long serialVersionUID = -5399026510369994174L;
	private String t139_numreg;
	private String t139_numruc;
	private String t139_rucimp;
	private String t139_numaut;
	private Integer t139_indice;
	private String t139_formul;
	private Integer t139_orden;	
	private String t139_userna;
	private FechaBean t139_fecact;
	public String getT139_numreg() {
		return t139_numreg;
	}
	public void setT139_numreg(String t139Numreg) {
		t139_numreg = t139Numreg;
	}
	public String getT139_numruc() {
		return t139_numruc;
	}
	public void setT139_numruc(String t139Numruc) {
		t139_numruc = t139Numruc;
	}
	public String getT139_rucimp() {
		return t139_rucimp;
	}
	public void setT139_rucimp(String t139Rucimp) {
		t139_rucimp = t139Rucimp;
	}
	public String getT139_numaut() {
		return t139_numaut;
	}
	public void setT139_numaut(String t139Numaut) {
		t139_numaut = t139Numaut;
	}
	public Integer getT139_indice() {
		return t139_indice;
	}
	public void setT139_indice(Integer t139Indice) {
		t139_indice = t139Indice;
	}
	public String getT139_formul() {
		return t139_formul;
	}
	public void setT139_formul(String t139Formul) {
		t139_formul = t139Formul;
	}
	public Integer getT139_orden() {
		return t139_orden;
	}
	public void setT139_orden(Integer t139Orden) {
		t139_orden = t139Orden;
	}
	public String getT139_userna() {
		return t139_userna;
	}
	public void setT139_userna(String t139Userna) {
		t139_userna = t139Userna;
	}
	public FechaBean getT139_fecact() {
		return t139_fecact;
	}
	public void setT139_fecact(FechaBean t139Fecact) {
		t139_fecact = t139Fecact;
	}
	
}
