package pe.gob.sunat.servicio2.registro.electronico.comppago.factura.model.dao;

import java.util.List;

import pe.gob.sunat.servicio2.registro.electronico.comppago.factura.model.domain.T8249Bean;

public interface T8249DAO {
	
	public List<T8249Bean> findByFiltro(T8249Bean param) ;
	
}
