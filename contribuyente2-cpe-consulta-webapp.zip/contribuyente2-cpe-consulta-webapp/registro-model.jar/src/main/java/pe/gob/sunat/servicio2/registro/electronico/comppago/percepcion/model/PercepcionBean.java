package pe.gob.sunat.servicio2.registro.electronico.comppago.percepcion.model;

import java.io.Serializable;
import java.math.BigDecimal;
import java.util.Date;
import java.util.List;

public class PercepcionBean implements Serializable{
	
	private static final long serialVersionUID = 1L;
	
	private String numRuc;
	private String codCpe;
	private String numSerieCpe;
	private Integer numCpe;
	private String codTipoDocRecep;
	private String numDocRecep;
	private String descNombreRecep;
	private Date fechaEmision;
	private String codRegimenPer;
	private String descObservacion;
	private BigDecimal montoTotalPercibido;
	private BigDecimal montoTotalCobrado;
	private String codEstadoCpe;
	private String indProcedencia;
	private String indCompFisico;
	private String descMotivoReversion;
	private Date fechaReversion;
	private String codUsuReversion;
	private Long numTicket;
	private String codCorreoRecep;
	private String codMotivoContin;
	private Date fechaRegistro;
	private String codUsuRegistro;
	private Date fechaModificacion;
	private String codUsuModificacion;
	private List<PerDocRelBean> listaDocumentosRel;
	
	//descripciones
	private String descNombreEmisor;
	private String descTipoDocRecep;
	private String descTipoRegimenPer;
	private String descEstadoCpe;
	
	// hquispeon - Agregar revertido
	private String indReempRev;
	
	//PAS20165E210300193 wsandovalh nuevos Atributos
	private String numPeriodo;
	private BigDecimal montoBaseCalculo;
	
	private int numFila;
	
	public String getNumRuc() {
		return numRuc;
	}
	public void setNumRuc(String numRuc) {
		this.numRuc = numRuc;
	}
	public String getCodCpe() {
		return codCpe;
	}
	public void setCodCpe(String codCpe) {
		this.codCpe = codCpe;
	}
	public String getNumSerieCpe() {
		return numSerieCpe;
	}
	public void setNumSerieCpe(String numSerieCpe) {
		this.numSerieCpe = numSerieCpe;
	}
	public Integer getNumCpe() {
		return numCpe;
	}
	public void setNumCpe(Integer numCpe) {
		this.numCpe = numCpe;
	}
	public String getCodTipoDocRecep() {
		return codTipoDocRecep;
	}
	public void setCodTipoDocRecep(String codTipoDocRecep) {
		this.codTipoDocRecep = codTipoDocRecep;
	}
	public String getNumDocRecep() {
		return numDocRecep;
	}
	public void setNumDocRecep(String numDocRecep) {
		this.numDocRecep = numDocRecep;
	}
	public String getDescNombreRecep() {
		return descNombreRecep;
	}
	public void setDescNombreRecep(String descNombreRecep) {
		this.descNombreRecep = descNombreRecep;
	}
	public Date getFechaEmision() {
		return fechaEmision;
	}
	public void setFechaEmision(Date fechaEmision) {
		this.fechaEmision = fechaEmision;
	}
	public String getCodRegimenPer() {
		return codRegimenPer;
	}
	public void setCodRegimenPer(String codRegimenPer) {
		this.codRegimenPer = codRegimenPer;
	}
	public String getDescObservacion() {
		return descObservacion;
	}
	public void setDescObservacion(String descObservacion) {
		this.descObservacion = descObservacion;
	}
	public BigDecimal getMontoTotalPercibido() {
		return montoTotalPercibido;
	}
	public void setMontoTotalPercibido(BigDecimal montoTotalPercibido) {
		this.montoTotalPercibido = montoTotalPercibido;
	}
	public BigDecimal getMontoTotalCobrado() {
		return montoTotalCobrado;
	}
	public void setMontoTotalCobrado(BigDecimal montoTotalCobrado) {
		this.montoTotalCobrado = montoTotalCobrado;
	}
	public String getCodEstadoCpe() {
		return codEstadoCpe;
	}
	public void setCodEstadoCpe(String codEstadoCpe) {
		this.codEstadoCpe = codEstadoCpe;
	}
	public String getIndProcedencia() {
		return indProcedencia;
	}
	public void setIndProcedencia(String indProcedencia) {
		this.indProcedencia = indProcedencia;
	}
	public String getIndCompFisico() {
		return indCompFisico;
	}
	public void setIndCompFisico(String indCompFisico) {
		this.indCompFisico = indCompFisico;
	}
	public String getDescMotivoReversion() {
		return descMotivoReversion;
	}
	public void setDescMotivoReversion(String descMotivoReversion) {
		this.descMotivoReversion = descMotivoReversion;
	}
	public Date getFechaReversion() {
		return fechaReversion;
	}
	public void setFechaReversion(Date fechaReversion) {
		this.fechaReversion = fechaReversion;
	}
	public String getCodUsuReversion() {
		return codUsuReversion;
	}
	public void setCodUsuReversion(String codUsuReversion) {
		this.codUsuReversion = codUsuReversion;
	}
	public Long getNumTicket() {
		return numTicket;
	}
	public void setNumTicket(Long numTicket) {
		this.numTicket = numTicket;
	}
	public String getCodCorreoRecep() {
		return codCorreoRecep;
	}
	public void setCodCorreoRecep(String codCorreoRecep) {
		this.codCorreoRecep = codCorreoRecep;
	}
	public String getCodMotivoContin() {
		return codMotivoContin;
	}
	public void setCodMotivoContin(String codMotivoContin) {
		this.codMotivoContin = codMotivoContin;
	}
	public Date getFechaRegistro() {
		return fechaRegistro;
	}
	public void setFechaRegistro(Date fechaRegistro) {
		this.fechaRegistro = fechaRegistro;
	}
	public String getCodUsuRegistro() {
		return codUsuRegistro;
	}
	public void setCodUsuRegistro(String codUsuRegistro) {
		this.codUsuRegistro = codUsuRegistro;
	}
	public Date getFechaModificacion() {
		return fechaModificacion;
	}
	public void setFechaModificacion(Date fechaModificacion) {
		this.fechaModificacion = fechaModificacion;
	}
	public String getCodUsuModificacion() {
		return codUsuModificacion;
	}
	public void setCodUsuModificacion(String codUsuModificacion) {
		this.codUsuModificacion = codUsuModificacion;
	}	
	public String getDescNombreEmisor() {
		return descNombreEmisor;
	}
	public void setDescNombreEmisor(String descNombreEmisor) {
		this.descNombreEmisor = descNombreEmisor;
	}
	public String getDescTipoDocRecep() {
		return descTipoDocRecep;
	}
	public void setDescTipoDocRecep(String descTipoDocRecep) {
		this.descTipoDocRecep = descTipoDocRecep;
	}
	public String getDescTipoRegimenPer() {
		return descTipoRegimenPer;
	}
	public void setDescTipoRegimenPer(String descTipoRegimenPer) {
		this.descTipoRegimenPer = descTipoRegimenPer;
	}
	public String getDescEstadoCpe() {
		return descEstadoCpe;
	}
	public void setDescEstadoCpe(String descEstadoCpe) {
		this.descEstadoCpe = descEstadoCpe;
	}
	public List<PerDocRelBean> getListaDocumentosRel() {
		return listaDocumentosRel;
	}
	public void setListaDocumentosRel(List<PerDocRelBean> listaDocumentosRel) {
		this.listaDocumentosRel = listaDocumentosRel;
	}
	public int getNumFila() {
		return numFila;
	}
	public void setNumFila(int numFila) {
		this.numFila = numFila;
	}
	public String getIndReempRev() {
		return indReempRev;
	}
	public void setIndReempRev(String indReempRev) {
		this.indReempRev = indReempRev;
	}
	public String getNumPeriodo() {
		return numPeriodo;
	}
	public void setNumPeriodo(String numPeriodo) {
		this.numPeriodo = numPeriodo;
	}
	public BigDecimal getMontoBaseCalculo() {
		return montoBaseCalculo;
	}
	public void setMontoBaseCalculo(BigDecimal montoBaseCalculo) {
		this.montoBaseCalculo = montoBaseCalculo;
	}
	
}
