package pe.gob.sunat.servicio2.registro.electronico.comppago.factura.model.domain;

import java.io.Serializable;
import java.util.Date;

public class T6573RetencionBean implements Serializable{
    
	private static final long serialVersionUID = -1829836638218423378L;
	
	private PkComprobante pkRetencion;
    private String codTipDocRecep;
    private String desNomRecep;
    private String numDocRecep;
    private Date fecEmi;
    private String codRegRet;
    private String desObservacion;
    private Double mtoTotalRet;
    private Double mtoTotalPagado;
    private String codEstCpe;
    private String indProcedencia;
    private String indCpeFisico;
    private String desMotivoRev;
    private Date fecRev;
    private String codUsuRev;
    private Long numTicket;
    private String codCorreoRecep;
    private String codMotContin;
	private String numPeriodo;//nuevo
	private Double montoBaseCalculo;//nuevo
	private String indReemplazoReversion;//nuevo
    private AuditoriaBean auditoria;
    
	public PkComprobante getPkRetencion() {
		return pkRetencion;
	}
	public void setPkRetencion(PkComprobante pkRetencion) {
		this.pkRetencion = pkRetencion;
	}
	public String getCodTipDocRecep() {
		return codTipDocRecep;
	}
	public void setCodTipDocRecep(String codTipDocRecep) {
		this.codTipDocRecep = codTipDocRecep;
	}
	public String getDesNomRecep() {
		return desNomRecep;
	}
	public void setDesNomRecep(String desNomRecep) {
		this.desNomRecep = desNomRecep;
	}
	public String getNumDocRecep() {
		return numDocRecep;
	}
	public void setNumDocRecep(String numDocRecep) {
		this.numDocRecep = numDocRecep;
	}
	public Date getFecEmi() {
		return fecEmi;
	}
	public void setFecEmi(Date fecEmi) {
		this.fecEmi = fecEmi;
	}
	public String getCodRegRet() {
		return codRegRet;
	}
	public void setCodRegRet(String codRegRet) {
		this.codRegRet = codRegRet;
	}
	public String getDesObservacion() {
		return desObservacion;
	}
	public void setDesObservacion(String desObservacion) {
		this.desObservacion = desObservacion;
	}
	public Double getMtoTotalRet() {
		return mtoTotalRet;
	}
	public void setMtoTotalRet(Double mtoTotalRet) {
		this.mtoTotalRet = mtoTotalRet;
	}
	public Double getMtoTotalPagado() {
		return mtoTotalPagado;
	}
	public void setMtoTotalPagado(Double mtoTotalPagado) {
		this.mtoTotalPagado = mtoTotalPagado;
	}
	public String getCodEstCpe() {
		return codEstCpe;
	}
	public void setCodEstCpe(String codEstCpe) {
		this.codEstCpe = codEstCpe;
	}
	public String getIndProcedencia() {
		return indProcedencia;
	}
	public void setIndProcedencia(String indProcedencia) {
		this.indProcedencia = indProcedencia;
	}
	public String getIndCpeFisico() {
		return indCpeFisico;
	}
	public void setIndCpeFisico(String indCpeFisico) {
		this.indCpeFisico = indCpeFisico;
	}
	public String getDesMotivoRev() {
		return desMotivoRev;
	}
	public void setDesMotivoRev(String desMotivoRev) {
		this.desMotivoRev = desMotivoRev;
	}
	public Date getFecRev() {
		return fecRev;
	}
	public void setFecRev(Date fecRev) {
		this.fecRev = fecRev;
	}
	public String getCodUsuRev() {
		return codUsuRev;
	}
	public void setCodUsuRev(String codUsuRev) {
		this.codUsuRev = codUsuRev;
	}
	public Long getNumTicket() {
		return numTicket;
	}
	public void setNumTicket(Long numTicket) {
		this.numTicket = numTicket;
	}
	public String getCodCorreoRecep() {
		return codCorreoRecep;
	}
	public void setCodCorreoRecep(String codCorreoRecep) {
		this.codCorreoRecep = codCorreoRecep;
	}
	public String getCodMotContin() {
		return codMotContin;
	}
	public void setCodMotContin(String codMotContin) {
		this.codMotContin = codMotContin;
	}
	
	public String getNumPeriodo() {
		return numPeriodo;
	}
	public void setNumPeriodo(String numPeriodo) {
		this.numPeriodo = numPeriodo;
	}
	public Double getMontoBaseCalculo() {
		return montoBaseCalculo;
	}
	public void setMontoBaseCalculo(Double montoBaseCalculo) {
		this.montoBaseCalculo = montoBaseCalculo;
	}
	public String getIndReemplazoReversion() {
		return indReemplazoReversion;
	}
	public void setIndReemplazoReversion(String indReemplazoReversion) {
		this.indReemplazoReversion = indReemplazoReversion;
	}
	public AuditoriaBean getAuditoria() {
		return auditoria;
	}
	public void setAuditoria(AuditoriaBean auditoria) {
		this.auditoria = auditoria;
	}

}