package pe.gob.sunat.servicio2.registro.electronico.comppago.factura.model.dao;

import pe.gob.sunat.servicio2.registro.electronico.comppago.factura.model.domain.T10194Bean;

@SuppressWarnings({"rawtypes"})
public interface T10194DAO {
	public T10194Bean findByFiltro(T10194Bean param) ;
	public T10194Bean findByFiltroRucSerieCodNum(T10194Bean param) ;
}
