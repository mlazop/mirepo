package pe.gob.sunat.servicio2.registro.electronico.comppago.model.dao.ibatis;

import java.util.HashMap;
import java.util.Map;

import pe.gob.sunat.framework.spring.util.dao.SqlMapDAOBase;
import pe.gob.sunat.servicio2.registro.electronico.comppago.model.dao.T3639DAO;
import pe.gob.sunat.servicio2.registro.electronico.comppago.model.domain.T3639Bean;

@SuppressWarnings({"deprecation"})
public class SqlMapT3639DAOImpl extends SqlMapDAOBase implements T3639DAO {

	private static final long serialVersionUID = -7455295421475399522L;

	@Override
	public T3639Bean findByFiltro(T3639Bean bean){		
		Object obj = getSqlMapClientTemplate().queryForObject("T3639.findByFiltro", bean);
		return (obj != null ? (T3639Bean) obj: null);	
	}
	
	@Override
	public T3639Bean findByPk(String ruc, String serie, String tipo, Integer numero){
		if (this.log.isDebugEnabled()) this.log.debug("SQLMap T3639.findByPk (" + ruc + "-" + serie+"-" +tipo+"-"+numero );
	    Map < String , Object > m = new HashMap< String, Object >();
		 m.put("num_ruc", ruc);
		 m.put("num_serie", serie);
		 m.put("cod_tipcomp", tipo);
		 m.put("num_comprob", numero);		 
		Object obj = getSqlMapClientTemplate().queryForObject("T3639.findByPk", m);
		return (obj != null ? (T3639Bean) obj: null);
	}

}
