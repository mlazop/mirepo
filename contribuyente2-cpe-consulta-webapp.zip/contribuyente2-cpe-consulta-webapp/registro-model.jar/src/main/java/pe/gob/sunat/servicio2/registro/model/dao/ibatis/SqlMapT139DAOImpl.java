package pe.gob.sunat.servicio2.registro.model.dao.ibatis;

import java.util.HashMap;
import java.util.Map;

import pe.gob.sunat.framework.spring.util.dao.SqlMapDAOBase;
import pe.gob.sunat.servicio2.registro.model.dao.T139DAO;
import pe.gob.sunat.servicio2.registro.model.domain.T139Bean;

@SuppressWarnings({"deprecation","unchecked", "rawtypes"})
public class SqlMapT139DAOImpl extends SqlMapDAOBase implements T139DAO {

	@Override
	public T139Bean findByRucAutorizacion(String ruc, String autorizacion){	
		if (log.isDebugEnabled()) {log.debug("SQLMapDao findByRucAutorizacion (" + ruc+", "+ autorizacion+")");}
		
		Map m = new HashMap();
		m.put("ruc", ruc);
		m.put("autorizacion", autorizacion);
		
		T139Bean bean = (T139Bean) getSqlMapClientTemplate().queryForObject("T139.findByRucAutorizacion", m);
		
		return bean;
	}
	
}
