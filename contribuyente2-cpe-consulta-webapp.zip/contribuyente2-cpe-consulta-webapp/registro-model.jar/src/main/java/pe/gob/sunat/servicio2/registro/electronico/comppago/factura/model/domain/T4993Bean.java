package pe.gob.sunat.servicio2.registro.electronico.comppago.factura.model.domain;

import java.io.Serializable;
import java.util.Arrays;

import pe.gob.sunat.framework.spring.util.date.FechaBean;

public class T4993Bean implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 4612971058092273686L;
	/**
	 * 
	 */
	private String num_ruc;
    private Long num_id_archivo;
    private Integer num_correl;
    private byte[] arc_adjunto;
    private FechaBean fec_archivo;
    private String ind_procedencia;
    private String des_nombre;
    private Integer num_id_firma;
    private String cod_usumodif;
    private FechaBean fec_modif;
	public Integer getNum_correl() {
		return num_correl;
	}
	public void setNum_correl(Integer numCorrel) {
		num_correl = numCorrel;
	}
	public Integer getNum_id_firma() {
		return num_id_firma;
	}
	public void setNum_id_firma(Integer numIdFirma) {
		num_id_firma = numIdFirma;
	}
	public String getNum_ruc() {
		return num_ruc;
	}
	public void setNum_ruc(String numRuc) {
		num_ruc = numRuc;
	}
	public Long getNum_id_archivo() {
		return num_id_archivo;
	}
	public void setNum_id_archivo(Long numIdArchivo) {
		num_id_archivo = numIdArchivo;
	}
	public byte[] getArc_adjunto() {
		return arc_adjunto;
	}
	public void setArc_adjunto(byte[] arcAdjunto) {
		arc_adjunto = arcAdjunto;
	}
	public FechaBean getFec_archivo() {
		return fec_archivo;
	}
	public void setFec_archivo(FechaBean fecArchivo) {
		fec_archivo = fecArchivo;
	}
	public String getInd_procedencia() {
		return ind_procedencia;
	}
	public void setInd_procedencia(String indProcedencia) {
		ind_procedencia = indProcedencia;
	}
	public String getDes_nombre() {
		return des_nombre;
	}
	public void setDes_nombre(String desNombre) {
		des_nombre = desNombre;
	}
	public String getCod_usumodif() {
		return cod_usumodif;
	}
	public void setCod_usumodif(String codUsumodif) {
		cod_usumodif = codUsumodif;
	}
	public FechaBean getFec_modif() {
		return fec_modif;
	}
	public void setFec_modif(FechaBean fecModif) {
		fec_modif = fecModif;
	}
	@Override
	public String toString() {
		return "T4993Bean [arc_adjunto=" + arc_adjunto == null ? "" :Arrays.toString(arc_adjunto)
				+ ", cod_usumodif=" + cod_usumodif + ", des_nombre="
				+ des_nombre + ", fec_archivo=" + fec_archivo + ", fec_modif="
				+ fec_modif + ", ind_procedencia=" + ind_procedencia
				+ ", num_correl=" + num_correl + ", num_id_archivo="
				+ num_id_archivo + ", num_id_firma=" + num_id_firma
				+ ", num_ruc=" + num_ruc + "]";
	}
    

}
