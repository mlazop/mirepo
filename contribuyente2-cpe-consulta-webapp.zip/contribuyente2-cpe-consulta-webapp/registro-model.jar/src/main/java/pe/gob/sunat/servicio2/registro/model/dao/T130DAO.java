package pe.gob.sunat.servicio2.registro.model.dao;

import java.util.List;

import pe.gob.sunat.servicio2.registro.model.domain.T130Bean;

/**
 * Dao para el control de la tabla t130detmau
 * @author wcavalie
 *
 */
public interface T130DAO {
	public List<T130Bean> findByRUC_Serie_TipoDoc(T130Bean bean) ;

	public Integer findComprobanteAutorizado(String numeroRuc, String tipodocumento, 
			String  serie, Integer  numero);
	
	public Integer findComprobanteAutorizadoRange(String numeroRuc, String tipodocumento, 
			String  serie, String  numeroCPDesde, String numeroCPHasta);
			
	/* DCERRENO - 17/06/2015 - INICIO */		
	public Integer getSerieAutorizada(T130Bean t130Bean);
  /* DCERRENO - 17/06/2015 - FIN */ 		
}