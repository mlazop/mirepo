package pe.gob.sunat.servicio2.registro.electronico.comppago.factura.model.domain;

import java.io.Serializable;

import pe.gob.sunat.framework.spring.util.date.FechaBean;

public class T4536Bean implements Serializable {
	private static final long serialVersionUID = 1L;
	
	private String ticket;
	private String modo;
	private byte[] contenido;
	private String usuarioModificador;
	private FechaBean fechaModificacion;

	private Integer correlativo;

	private String firma;
	
	public String getTicket() {
		return ticket;
	}
	
	public void setTicket(String ticket) {
		this.ticket = ticket;
	}

	public String getModo() {
		return modo;
	}

	public void setModo(String modo) {
		this.modo = modo;
	}

	public byte[] getContenido() {
		return contenido;
	}

	public void setContenido(byte[] contenido) {
		this.contenido = contenido;
	}

	public String getUsuarioModificador() {
		return usuarioModificador;
	}

	public void setUsuarioModificador(String usuarioModificador) {
		this.usuarioModificador = usuarioModificador;
	}

	public FechaBean getFechaModificacion() {
		return fechaModificacion;
	}

	public void setFechaModificacion(FechaBean fechaModificacion) {
		this.fechaModificacion = fechaModificacion;
	}

	public void setCorrelativo(Integer correlativo) {
		this.correlativo = correlativo;
	}
	
	public Integer getCorrelativo() {
		return this.correlativo;
	}
	
	public void setFirma(String firma) {
		this.firma = firma;
	}
	
	public String getFirma() {
		return this.firma;
	}
	
}
