package pe.gob.sunat.servicio2.registro.electronico.comppago.consulta.model.domain;

import java.io.Serializable;

import pe.gob.sunat.framework.spring.util.date.FechaBean;

public class T6491Bean implements Serializable {

	private static final long serialVersionUID = -1857454074948953525L;
	
	private Long numConsulta;			 
	private String numRucconsume;
	private String nomWservice; 
	private String nomWsmetodo;
	private String nomParams; 
	private String codResul;
	private FechaBean fecConsulta;
	private String codUsuconsulta;
	
	public Long getNumConsulta() {
		return numConsulta;
	}
	public void setNumConsulta(Long numConsulta) {
		this.numConsulta = numConsulta;
	}
	public String getNumRucconsume() {
		return numRucconsume;
	}
	public void setNumRucconsume(String numRucconsume) {
		this.numRucconsume = numRucconsume;
	}
	public String getNomWservice() {
		return nomWservice;
	}
	public void setNomWservice(String nomWservice) {
		this.nomWservice = nomWservice;
	}
	public String getNomWsmetodo() {
		return nomWsmetodo;
	}
	public void setNomWsmetodo(String nomWsmetodo) {
		this.nomWsmetodo = nomWsmetodo;
	}
	public String getNomParams() {
		return nomParams;
	}
	public void setNomParams(String nomParams) {
		this.nomParams = nomParams;
	}
	public FechaBean getFecConsulta() {
		return fecConsulta;
	}
	public void setFecConsulta(FechaBean fecConsulta) {
		this.fecConsulta = fecConsulta;
	}
	public String getCodUsuconsulta() {
		return codUsuconsulta;
	}
	public void setCodUsuconsulta(String codUsuconsulta) {
		this.codUsuconsulta = codUsuconsulta;
	}
	public String getCodResul() {
		return codResul;
	}
	public void setCodResul(String codResul) {
		this.codResul = codResul;
	}
	
	
}
