
package pe.gob.sunat.servicio2.registro.comppago.factura.gem.contingencia.model.domain;

import java.io.Serializable;

import pe.gob.sunat.framework.spring.util.date.FechaBean;

public class T5677Bean implements Serializable{
	
	private static final long serialVersionUID = 9029959794017239305L;
	private Long	numeTicket;
	private byte[] 	archivoContingencia;
	private String	descripcionResumen;
	private byte[] 	archivoRespuesta;
	private String	usuarioRegistra;
	private FechaBean fechaRegistra;

	public Long getNumeTicket() {
		return numeTicket;
	}

	public void setNumeTicket(Long numeTicket) {
		this.numeTicket = numeTicket;
	}

	public byte[]  getArchivoContingencia() {
		return archivoContingencia;
	}

	public void setArchivoContingencia(byte[]  archivoContingencia) {
		this.archivoContingencia = archivoContingencia;
	}

	public String getDescripcionResumen() {
		return descripcionResumen;
	}

	public void setDescripcionResumen(String descripcionResumen) {
		this.descripcionResumen = descripcionResumen;
	}

	public byte[]  getArchivoRespuesta() {
		return archivoRespuesta;
	}

	public void setArchivoRespuesta(byte[] archivoRespuesta) {
		this.archivoRespuesta = archivoRespuesta;
	}

	public String getUsuarioRegistra() {
		return usuarioRegistra;
	}

	public void setUsuarioRegistra(String usuarioRegistra) {
		this.usuarioRegistra = usuarioRegistra;
	}

	public FechaBean getFechaRegistra() {
		return fechaRegistra;
	}

	public void setFechaRegistra(FechaBean fechaRegistra) {
		this.fechaRegistra = fechaRegistra;
	}
}
