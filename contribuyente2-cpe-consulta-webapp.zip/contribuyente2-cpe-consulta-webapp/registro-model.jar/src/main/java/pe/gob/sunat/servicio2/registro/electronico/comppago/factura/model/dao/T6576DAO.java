package pe.gob.sunat.servicio2.registro.electronico.comppago.factura.model.dao;

import pe.gob.sunat.servicio2.registro.electronico.comppago.factura.model.domain.T6576ArchRetBean;


public interface T6576DAO {

    public T6576ArchRetBean selectByPrimaryKey(String indModo, Object numTicket);

    //public T6576ArchRetBean selectByDocument(String numRuc, String codCpe, String numSerieCpe, Integer numCpe);
    public T6576ArchRetBean selectByDocument(Long numTicket);
    
}