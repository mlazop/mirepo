package pe.gob.sunat.servicio2.registro.model.dao.ibatis;

import java.sql.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.dao.DataAccessException;

import pe.gob.sunat.framework.spring.util.dao.SqlMapDAOBase;
import pe.gob.sunat.framework.spring.util.date.FechaBean;
import pe.gob.sunat.servicio2.registro.model.dao.DdsDAO;
import pe.gob.sunat.servicio2.registro.model.domain.DdsBean;

@SuppressWarnings({"unchecked", "rawtypes", "deprecation"})
public class SqlMapDdsDAOImpl extends SqlMapDAOBase implements DdsDAO {

	/**
	 * 
	 */
	private static final long serialVersionUID = -3619377303650821566L;

	@Override
	public DdsBean findByRUC(String numeroDeRUC) {
    if (this.log.isDebugEnabled()) this.log.debug("findByRUC (" + numeroDeRUC + ")");

    DdsBean dds = (DdsBean)getSqlMapClientTemplate().queryForObject("Dds.findByRUC", numeroDeRUC);
    return dds;
	}
	
	public Map findByRUC_Map(String numRuc) {
	    if (this.log.isDebugEnabled())
	    	this.log.debug("findByRUC_Map (" + numRuc + ")");

	    return (Map)getSqlMapClientTemplate().queryForObject("Dds.findByRUC_Map", numRuc);
	}
	
  /**
   * Metodo que busca informacion de un tipo de documento
   * @autor rmanrique 
   * @param numDoc String
   * @param tipDoc String
   * @return List
   * @throws DataAccessException
   */
	public List findByTipNumDoc(String numDoc, String tipDoc){
		Map p = new HashMap();
		p.put("tipDoc",tipDoc);
		p.put("numDoc", numDoc);
		return this.getSqlMapClientTemplate().queryForList("Dds.findByTipNumDoc", p);
	}

	/**
	 * Inserta un nuevo registro de datos del contribuyente.
	 * @param params
	 */
	public void insert(Map params) {
		getSqlMapClientTemplate().insert("Dds.insert", params);
	}
	
	public DdsBean findByTipDocNumDoc(Map param){
		
		List lista = this.getSqlMapClientTemplate().queryForList("Dds.findByTipDocNumDoc", param);
		
		DdsBean bean = new DdsBean();
		
		if(lista!=null && lista.size()>0){
			//SimpleDateFormat formater = new SimpleDateFormat("dd/MM/yyyy");
			
			for(int i=0; i<lista.size(); i++){
				bean = (DdsBean)lista.get(i);
		        bean.setDds_consti(bean.getDds_consti()); 
				bean.setDds_inicio(bean.getDds_inicio());
				bean.setDds_fecven(bean.getDds_fecven());
				bean.setDds_fecnac(bean.getDds_fecnac());
			}
		}
				
		return bean;
	}
	
	//EAG 27/10/2011
	public Map buscarPorTipoDocNumDoc(String tipo_doc, String num_doc){
		Map param = new HashMap();
		param.put("tipo_doc", tipo_doc);		
		param.put("num_doc",num_doc);
		return (Map)this.getSqlMapClientTemplate().queryForObject("Dds.buscarPorTipoDocNumDoc", param);
	}	
	
	//ECR 19/01/2012
	public List joinWithDdpDocumentoIdentidad(String tipoDoc, String numDoc) {
		Map param = new HashMap();
		param.put("tipo_doc", tipoDoc);		
		param.put("num_doc", numDoc);
		return getSqlMapClientTemplate().queryForList("Dds.joinWithDdpDocumentoIdentidad", param);
	}

	//ECR 09/10/2012
	public Map findByRucJoinT1144ws(String ddsNumruc, String ddpEstado) {
		Map param = new HashMap();
		param.put("dds_numruc", ddsNumruc);	
		param.put("ddp_estado", ddpEstado);	
		return (Map)this.getSqlMapClientTemplate().queryForObject("Dds.findByRucJoinT1144ws", param);
	}
	@Override
	public Date findFechaIniActByRuc(String numruc) throws DataAccessException {
		//return (Map)this.getSqlMapClientTemplate().queryForObject("Dds.findFechaIniActByRuc", numruc);
		Map p = new HashMap();
		p.put("numruc", numruc);
		List rpta = getSqlMapClientTemplate().queryForList("Dds.findFechaIniActByRuc", p);
		if(rpta == null || rpta.isEmpty()){
			return null;
		} else{
			//rpta = parametrizar(rpta, false, true);
			return (Date)((HashMap)rpta.get(0)).get("dds_inicio");
		}
	}

	@Override
	public String findCondDomicFiscalByRuc(String numruc)
			throws DataAccessException {
		Map p = new HashMap();
		p.put("numruc", numruc);
		List rpta = getSqlMapClientTemplate().queryForList("Dds.findCondDomicFiscalByRuc",p);
		if(rpta == null || rpta.isEmpty()){
			return null;
		} else{
			//rpta = parametrizar(rpta, false, true);
			return (String)((HashMap)rpta.get(0)).get("dds_domici");
		}
	}
	
	//MSF 13/08/2015
	@Override
	public boolean isInicioActividadesOK(String ruc, FechaBean fecha){
		DdsBean dds = findByRUC(ruc);
		boolean ok = false;
		FechaBean fh_i = new FechaBean();
		FechaBean fh_f = new FechaBean();
		
		if(dds.getDds_inicio() == null){
			ok = false;
		}else if(fecha.getFormatDate("dd/MM/yyyy").equals("01/01/0001")){
			ok = false;
		}else{
			fh_i = dds.getDds_inicio();
			fh_f = fecha;
			if(fh_i.getCalendar().equals(fh_f.getCalendar()) || 
				fh_i.getCalendar().before(fh_f.getCalendar())){
				ok = true;
			}
		}
		return ok;
	}

}
