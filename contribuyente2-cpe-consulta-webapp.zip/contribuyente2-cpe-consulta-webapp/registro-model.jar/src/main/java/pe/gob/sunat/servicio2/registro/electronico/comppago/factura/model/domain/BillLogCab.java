package pe.gob.sunat.servicio2.registro.electronico.comppago.factura.model.domain;

import java.io.Serializable;
import java.util.Date;

public class BillLogCab implements Serializable {
	private static final long serialVersionUID = 1L;
	
	private Long ticket;
	private Long    ticketPack;
	private String nombreArchivo;
	private Integer tamanioArchivo;
	private Date fechaInicio;
	private Date fechaFin;
	private Integer estadoProceso;
	private Integer codigoResultado;	
	private String usuarioModificador;
	private Date fechaModificacion;
	private Long ticketXML;
	private Long ticketCDR;
	private Integer correlativo;
	
	public Long getTicket() {
		return ticket;
	}

	public void setTicket(Long ticket) {
		this.ticket = ticket;
	}

	
	public String getNombreArchivo() {
		return nombreArchivo;
	}

	public void setNombreArchivo(String nombreArchivo) {
		this.nombreArchivo = nombreArchivo;
	}

	public Integer getTamanioArchivo() {
		return tamanioArchivo;
	}

	public void setTamanioArchivo(Integer tamanioArchivo) {
		this.tamanioArchivo = tamanioArchivo;
	}

	public Date getFechaInicio() {
		return fechaInicio;
	}

	public void setFechaInicio(Date fechaInicio) {
		this.fechaInicio = fechaInicio;
	}

	public Date getFechaFin() {
		return fechaFin;
	}

	public void setFechaFin(Date fechaFin) {
		this.fechaFin = fechaFin;
	}

	public Integer getEstadoProceso() {
		return estadoProceso;
	}

	public void setEstadoProceso(Integer estadoProceso) {
		this.estadoProceso = estadoProceso;
	}

	public Integer getCodigoResultado() {
		return codigoResultado;
	}

	public void setCodigoResultado(Integer codigoResultado) {
		this.codigoResultado = codigoResultado;
	}

	public String getUsuarioModificador() {
		return usuarioModificador;
	}

	public void setUsuarioModificador(String usuarioModificador) {
		this.usuarioModificador = usuarioModificador;
	}

	public Date getFechaModificacion() {
		return fechaModificacion;
	}

	public void setFechaModificacion(Date fechaModificacion) {
		this.fechaModificacion = fechaModificacion;
	}

	public Long getTicketPack() {
		return ticketPack;
	}

	public void setTicketPack(Long ticketPack) {
		this.ticketPack = ticketPack;
	}
	
   public Long getTicketXML() {
      return ticketXML;
   }

   public void setTicketXML(Long ticketXML) {
      this.ticketXML = ticketXML;
   }

   public Long getTicketCDR() {
      return ticketCDR;
   }

   public void setTicketCDR(Long ticketCDR) {
      this.ticketCDR = ticketCDR;
   }

	public Integer getCorrelativo() {
		return correlativo;
	}
	
	public void setCorrelativo(Integer correlativo) {
		this.correlativo = correlativo;
	}
   
   
}
