package pe.gob.sunat.servicio2.registro.electronico.comppago.factura.model.dao;

import pe.gob.sunat.servicio2.registro.electronico.comppago.factura.model.domain.T6575ArchPerBean;


public interface T6575ArchPerInsertDAO {
    
    public void insertDocument(T6575ArchPerBean data);
}