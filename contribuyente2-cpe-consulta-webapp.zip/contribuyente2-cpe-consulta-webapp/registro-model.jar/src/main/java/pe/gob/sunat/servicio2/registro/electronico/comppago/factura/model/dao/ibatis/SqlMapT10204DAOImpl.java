package pe.gob.sunat.servicio2.registro.electronico.comppago.factura.model.dao.ibatis;

import pe.gob.sunat.framework.spring.util.dao.SqlMapDAOBase;
import pe.gob.sunat.servicio2.registro.electronico.comppago.factura.model.dao.T10204DAO;
import pe.gob.sunat.servicio2.registro.electronico.comppago.factura.model.domain.T10204Bean;
import pe.gob.sunat.servicio2.registro.electronico.comppago.factura.model.domain.T4241Bean;
import pe.gob.sunat.servicio2.registro.electronico.comppago.factura.model.domain.T4243Bean;
import pe.gob.sunat.servicio2.registro.electronico.comppago.factura.model.domain.T4536Bean;

@SuppressWarnings({"deprecation", "unchecked", "rawtypes"})
public class SqlMapT10204DAOImpl extends SqlMapDAOBase implements T10204DAO {

    @Override
    public T10204Bean findByFiltro(T10204Bean param) {
        Object obj = getSqlMapClientTemplate().queryForObject("T10204.findByFiltro", param);
        return (obj != null ? (T10204Bean) obj : null);
    }
    
    @Override
	public T4536Bean findByDataDAE( String nroRUC, String codCpe, String nroSerie, Integer nroCPE ) {
    	
    	T4243Bean bean = new T4243Bean();
		bean.setNum_ruc(nroRUC);
		bean.setCod_cpe(codCpe);
		bean.setNum_serie_cpe(nroSerie);
		bean.setNum_cpe(nroCPE);
    	
        Object obj = getSqlMapClientTemplate().queryForObject("T10204.findByData", bean);
        return (obj != null ? (T4536Bean) obj : null);
    }
    
    @Override
	public T4241Bean findByPK(String nroRUC, String nroSerie, Integer nroCPE, String codCpe) {
		T4241Bean bean = new T4241Bean();
		bean.setCod_cpe(codCpe);
		bean.setNum_ruc(nroRUC);
		bean.setNum_serie_cpe(nroSerie);
		bean.setNum_cpe(nroCPE);
		
		Object obj = getSqlMapClientTemplate().queryForObject("T10204.findByPK", bean);
		
		return (obj != null ? (T4241Bean) obj: null);
		
	}

}
