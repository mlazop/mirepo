package pe.gob.sunat.servicio2.registro.electronico.comppago.factura.model.domain;

import java.io.Serializable;
import java.math.BigDecimal;

import pe.gob.sunat.framework.spring.util.date.FechaBean;

public class T6235Bean implements Serializable {

	private static final long serialVersionUID = -2512266411263957633L;
	
	private Integer num_ticket;
	private String num_tran;
	private String num_serie;
	private String num_ruc;
	private String cod_local;
	private String cod_ef;
	private String ind_tip_tarjeta;
	private FechaBean fec_emision;
	private String hor_emision;
	private String cod_moneda;
	private BigDecimal mto_importe;
	private BigDecimal mto_propina;
	private BigDecimal mto_total;
	private String cod_docide_cliente;
	private String num_docide_cliente;
	private String ind_vigente;
	private FechaBean fec_regis;
	private String cod_usuregis;
	private FechaBean fec_modif;
	private String cod_usumodif;
	
	private T6236Bean t6236Bean;
	
	public Integer getNum_ticket() {
		return num_ticket;
	}
	public void setNum_ticket(Integer num_ticket) {
		this.num_ticket = num_ticket;
	}
	public String getNum_tran() {
		return num_tran;
	}
	public void setNum_tran(String num_tran) {
		this.num_tran = num_tran;
	}
	public String getNum_serie() {
		return num_serie;
	}
	public void setNum_serie(String num_serie) {
		this.num_serie = num_serie;
	}
	public String getNum_ruc() {
		return num_ruc;
	}
	public void setNum_ruc(String num_ruc) {
		this.num_ruc = num_ruc;
	}
	public String getCod_local() {
		return cod_local;
	}
	public void setCod_local(String cod_local) {
		this.cod_local = cod_local;
	}
	public String getCod_ef() {
		return cod_ef;
	}
	public void setCod_ef(String cod_ef) {
		this.cod_ef = cod_ef;
	}
	public String getInd_tip_tarjeta() {
		return ind_tip_tarjeta;
	}
	public void setInd_tip_tarjeta(String ind_tip_tarjeta) {
		this.ind_tip_tarjeta = ind_tip_tarjeta;
	}
	public FechaBean getFec_emision() {
		return fec_emision;
	}
	public void setFec_emision(FechaBean fec_emision) {
		this.fec_emision = fec_emision;
	}
	public String getHor_emision() {
		return hor_emision;
	}
	public void setHor_emision(String hor_emision) {
		this.hor_emision = hor_emision;
	}
	public String getCod_moneda() {
		return cod_moneda;
	}
	public void setCod_moneda(String cod_moneda) {
		this.cod_moneda = cod_moneda;
	}
	public BigDecimal getMto_importe() {
		return mto_importe;
	}
	public void setMto_importe(BigDecimal mto_importe) {
		this.mto_importe = mto_importe;
	}
	public BigDecimal getMto_propina() {
		return mto_propina;
	}
	public void setMto_propina(BigDecimal mto_propina) {
		this.mto_propina = mto_propina;
	}
	public BigDecimal getMto_total() {
		return mto_total;
	}
	public void setMto_total(BigDecimal mto_total) {
		this.mto_total = mto_total;
	}
	public String getCod_docide_cliente() {
		return cod_docide_cliente;
	}
	public void setCod_docide_cliente(String cod_docide_cliente) {
		this.cod_docide_cliente = cod_docide_cliente;
	}
	public String getNum_docide_cliente() {
		return num_docide_cliente;
	}
	public void setNum_docide_cliente(String num_docide_cliente) {
		this.num_docide_cliente = num_docide_cliente;
	}
	public String getInd_vigente() {
		return ind_vigente;
	}
	public void setInd_vigente(String ind_vigente) {
		this.ind_vigente = ind_vigente;
	}
	public FechaBean getFec_regis() {
		return fec_regis;
	}
	public void setFec_regis(FechaBean fec_regis) {
		this.fec_regis = fec_regis;
	}
	public String getCod_usuregis() {
		return cod_usuregis;
	}
	public void setCod_usuregis(String cod_usuregis) {
		this.cod_usuregis = cod_usuregis;
	}
	public FechaBean getFec_modif() {
		return fec_modif;
	}
	public void setFec_modif(FechaBean fec_modif) {
		this.fec_modif = fec_modif;
	}
	public String getCod_usumodif() {
		return cod_usumodif;
	}
	public void setCod_usumodif(String cod_usumodif) {
		this.cod_usumodif = cod_usumodif;
	}
	
	public T6236Bean getT6236Bean() {
		return t6236Bean;
	}
	public void setT6236Bean(T6236Bean t6236Bean) {
		this.t6236Bean = t6236Bean;
	}

	
}
