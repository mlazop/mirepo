package pe.gob.sunat.servicio2.registro.model.dao.ibatis;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import pe.gob.sunat.framework.spring.util.dao.SqlMapDAOBase;
import pe.gob.sunat.servicio2.registro.model.dao.T122DAO;
import pe.gob.sunat.servicio2.registro.model.domain.T122Bean;

@SuppressWarnings({"deprecation","unchecked", "rawtypes"})
public class SqlMapT122DAOImpl extends SqlMapDAOBase implements T122DAO {

	@Override
	public List<T122Bean> findByRUC_Serie_TipoDoc(T122Bean bean) {
		if (log.isDebugEnabled()) {log.debug("SQLMapDao findByRUC_Serie_TipoDoc (" + bean.getT122_tipdoc() + ")");}
		
		return (List<T122Bean>) getSqlMapClientTemplate().queryForList("T122.findByRUC_Serie_TipoDoc", bean);
	}

	@Override
	public List<T122Bean> findByRUC_Serie_TipoDoc_Rango(T122Bean bean) {
		if (log.isDebugEnabled()) {log.debug("SQLMapDao findByRUC_Serie_TipoDoc_Rango (" + bean.getT122_tipdoc() + ")");}
		
		return (List<T122Bean>) getSqlMapClientTemplate().queryForList("T122.findByRUC_Serie_TipoDoc_Rango", bean);
	}	
	
	@Override
	public List<T122Bean> findByRucDocIndice(String ruc, String serie, String tip_doc, Integer indice){
		if (log.isDebugEnabled()) {log.debug("SQLMapDao findByRucDocIndice (" + ruc+","+serie+","+tip_doc+","+indice+")");}
		
		Map m = new HashMap();
		m.put("ruc", ruc);
		m.put("serie", serie);
		m.put("tip_doc", tip_doc);
		m.put("indice", indice);
		
		return (List<T122Bean>) getSqlMapClientTemplate().queryForList("T122.findByRucDocIndice", m);
	}
}
