package pe.gob.sunat.servicio2.registro.electronico.comppago.factura.model.dao;

import pe.gob.sunat.servicio2.registro.electronico.comppago.factura.model.domain.T4541Bean;



/**
 * Dao para el control de la tabla T4541FEANULADO  
 * @author narista
 */
public interface T4541DAO {
	public T4541Bean findByFiltro(T4541Bean bean);
	public  abstract void insertar(T4541Bean bean);
	public  abstract T4541Bean findByPK(String nroRUC, String serie ,String tipocomp, Integer  numcomp );
	public T4541Bean findByPKAndTicket(String rucEmisor, String numeroSerie,
			Integer numeroComprobante, String tipoComprobante, String ticket);
	
} 
