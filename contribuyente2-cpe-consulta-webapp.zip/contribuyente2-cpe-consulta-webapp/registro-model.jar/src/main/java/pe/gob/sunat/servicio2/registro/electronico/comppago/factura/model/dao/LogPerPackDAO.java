package pe.gob.sunat.servicio2.registro.electronico.comppago.factura.model.dao;

import pe.gob.sunat.servicio2.registro.electronico.comppago.factura.model.domain.BillLogPack;

public interface LogPerPackDAO {

	Integer actualizaEstado(String numTicket);
	
	Integer actualizaEstado(BillLogPack data);

}
