package pe.gob.sunat.servicio2.registro.electronico.comppago.factura.model.dao.ibatis;

import pe.gob.sunat.framework.spring.util.dao.SqlMapDAOBase;
import pe.gob.sunat.servicio2.registro.electronico.comppago.factura.model.dao.T6575DAO;
import pe.gob.sunat.servicio2.registro.electronico.comppago.factura.model.domain.PkComprobante;
import pe.gob.sunat.servicio2.registro.electronico.comppago.factura.model.domain.T6575ArchPerBean;

public class SqlMapT6575DAOImpl extends SqlMapDAOBase implements T6575DAO {

    public T6575ArchPerBean selectByPrimaryKey(String indModo, Long numTicket) {
    	T6575ArchPerBean key = new T6575ArchPerBean();
        key.setIndModo(indModo);
        key.setNumTicket(numTicket);
        T6575ArchPerBean record = (T6575ArchPerBean) getSqlMapClientTemplate().queryForObject("t6575.selectByPrimaryKey", key);
        return record;
    }

	@Override
	public T6575ArchPerBean selectByDocument(Long numTicket) {
	//public T6575ArchPerBean selectByDocument(String numRuc, String codCpe, String numSerieCpe, Integer numCpe) {

		T6575ArchPerBean key = new T6575ArchPerBean();
        key.setIndModo("1");
        key.setNumTicket(numTicket);
        
        T6575ArchPerBean record = (T6575ArchPerBean) getSqlMapClientTemplate().queryForObject("t6575.selectByDocument", key);
        return record;
	}

}