package pe.gob.sunat.servicio2.registro.electronico.comppago.factura.model.dao.ibatis;

import java.util.HashMap;
import java.util.Map;

import org.springframework.orm.ibatis.support.SqlMapClientDaoSupport;

import pe.gob.sunat.servicio2.registro.electronico.comppago.factura.model.dao.GRELogCabSelectDAO;
import pe.gob.sunat.servicio2.registro.electronico.comppago.factura.model.domain.BillLogCab;
@SuppressWarnings({ "deprecation", "unchecked" })
public class SqlMapGRELogCabDAO extends SqlMapClientDaoSupport implements GRELogCabSelectDAO {

	@Override
	public BillLogCab selectByParam(String ticket, Integer correlativo) {
		Map<String, Object> param = new HashMap();
		param.put("ticket", ticket);
		param.put("correlativo", correlativo);
	   return (BillLogCab)getSqlMapClientTemplate().queryForObject("GreLogCab.selectByParam", param);
	}

	@Override
	public void update(String ticket, Integer correlativo) {
		Map<String, Object> param = new HashMap();
		param.put("ticket", ticket);
		param.put("correlativo", correlativo);
	    getSqlMapClientTemplate().update("GreLogCab.update", param);
	}

	@Override
	public void update(BillLogCab data) {
		getSqlMapClientTemplate().update("GreLogCab.updateData", data);
		
	}
	
}
