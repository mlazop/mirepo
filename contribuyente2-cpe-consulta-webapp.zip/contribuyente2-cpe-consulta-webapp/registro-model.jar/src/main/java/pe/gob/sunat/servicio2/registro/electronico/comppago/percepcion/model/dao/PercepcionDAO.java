package pe.gob.sunat.servicio2.registro.electronico.comppago.percepcion.model.dao;
import java.util.HashMap;

import pe.gob.sunat.servicio2.registro.electronico.comppago.percepcion.model.PercepcionBean;


public interface PercepcionDAO {
	
	PercepcionBean selectPorEmisor(PercepcionBean percepcionBean);
	
	///INICIO PAS20191U210100160
	public String buscarCanalEnvio(HashMap<String, Object> mapParametros);
	public int countRechazo(HashMap<String, Object> mapParametros);
	///FIN PAS20191U210100160

}
