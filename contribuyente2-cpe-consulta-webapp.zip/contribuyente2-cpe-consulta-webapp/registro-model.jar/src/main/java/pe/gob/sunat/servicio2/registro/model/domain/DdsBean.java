package pe.gob.sunat.servicio2.registro.model.domain;

import java.io.Serializable;

import pe.gob.sunat.framework.spring.util.date.FechaBean;

public class DdsBean implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = -6090723892414493833L;

	private String dds_numruc;

	private String dds_telef1;

	private String dds_telef2;

	private String dds_telef3;

	private String dds_numfax;

	private String dds_pasapo;

	private String dds_licenc;

	private String dds_contab;

	private String dds_factur;

	private FechaBean dds_consti;

	private String dds_ficha;

	private FechaBean dds_inicio;

	private String dds_cierre;

	private FechaBean dds_fecven;
  //private FechaBean fecven;
	//private String dds_calif;
	private String dds_califi;

	private String dds_domici;

	private String dds_orient;

	private String dds_patron;

	private String dds_ejempl;

	private String dds_motemi;

	private String dds_nomcom;

	private String dds_aparta;

	private String dds_paispa;

	private String dds_nfolio;

	private String dds_asient;

	private String dds_comext;

	private String dds_centro;

	private String dds_motbaj;

	private String dds_docide;

	private String dds_nrodoc;

	private String dds_sexo;

	private String dds_nacion;
  //private FechaBean fecnac;
	private FechaBean dds_fecnac;

	private String dds_userna;

	private FechaBean dds_fecact;
	
	private String desc_factur;
	
	private String desc_sexo;
	
	private String desc_nacion;
	
	private String desc_docide;
	
	private String desc_cierre;
	
	private String desc_domici;
	
	private String desc_orient;
	
	private String desc_comext;
	
	private String desc_motbaj;
	
	public DdsBean() {
		  super();
	  }
	
	public String getDds_numruc() {
		return dds_numruc;
	}

	public void setDds_numruc(String ddsNumruc) {
		dds_numruc = ddsNumruc;
	}

	public String getDds_telef1() {
		return dds_telef1;
	}

	public void setDds_telef1(String ddsTelef1) {
		dds_telef1 = ddsTelef1;
	}

	public String getDds_telef2() {
		return dds_telef2;
	}

	public void setDds_telef2(String ddsTelef2) {
		dds_telef2 = ddsTelef2;
	}

	public String getDds_telef3() {
		return dds_telef3;
	}

	public void setDds_telef3(String ddsTelef3) {
		dds_telef3 = ddsTelef3;
	}

	public String getDds_numfax() {
		return dds_numfax;
	}

	public void setDds_numfax(String ddsNumfax) {
		dds_numfax = ddsNumfax;
	}

	public String getDds_pasapo() {
		return dds_pasapo;
	}

	public void setDds_pasapo(String ddsPasapo) {
		dds_pasapo = ddsPasapo;
	}

	public String getDds_licenc() {
		return dds_licenc;
	}

	public void setDds_licenc(String ddsLicenc) {
		dds_licenc = ddsLicenc;
	}

	public String getDds_contab() {
		return dds_contab;
	}

	public void setDds_contab(String ddsContab) {
		dds_contab = ddsContab;
	}

	public String getDds_factur() {
		return dds_factur;
	}

	public void setDds_factur(String ddsFactur) {
		dds_factur = ddsFactur;
	}

	public FechaBean getDds_consti() {
		return dds_consti;
	}

	public void setDds_consti(FechaBean ddsConsti) {
		dds_consti = ddsConsti;
	}

	public String getDds_ficha() {
		return dds_ficha;
	}

	public void setDds_ficha(String ddsFicha) {
		dds_ficha = ddsFicha;
	}

	public FechaBean getDds_inicio() {
		return dds_inicio;
	}

	public void setDds_inicio(FechaBean ddsInicio) {
		dds_inicio = ddsInicio;
	}

	public String getDds_cierre() {
		return dds_cierre;
	}

	public void setDds_cierre(String ddsCierre) {
		dds_cierre = ddsCierre;
	}

	public FechaBean getDds_fecven() {
		return dds_fecven;
	}

	public void setDds_fecven(FechaBean ddsFecven) {
		dds_fecven = ddsFecven;
	}

	public String getDds_califi() {
		return dds_califi;
	}

	public void setDds_califi(String ddsCalifi) {
		dds_califi = ddsCalifi;
	}

	public String getDds_domici() {
		return dds_domici;
	}

	public void setDds_domici(String ddsDomici) {
		dds_domici = ddsDomici;
	}

	public String getDds_orient() {
		return dds_orient;
	}

	public void setDds_orient(String ddsOrient) {
		dds_orient = ddsOrient;
	}

	public String getDds_patron() {
		return dds_patron;
	}

	public void setDds_patron(String ddsPatron) {
		dds_patron = ddsPatron;
	}

	public String getDds_ejempl() {
		return dds_ejempl;
	}

	public void setDds_ejempl(String ddsEjempl) {
		dds_ejempl = ddsEjempl;
	}

	public String getDds_motemi() {
		return dds_motemi;
	}

	public void setDds_motemi(String ddsMotemi) {
		dds_motemi = ddsMotemi;
	}

	public String getDds_nomcom() {
		return dds_nomcom;
	}

	public void setDds_nomcom(String ddsNomcom) {
		dds_nomcom = ddsNomcom;
	}

	public String getDds_aparta() {
		return dds_aparta;
	}

	public void setDds_aparta(String ddsAparta) {
		dds_aparta = ddsAparta;
	}

	public String getDds_paispa() {
		return dds_paispa;
	}

	public void setDds_paispa(String ddsPaispa) {
		dds_paispa = ddsPaispa;
	}

	public String getDds_nfolio() {
		return dds_nfolio;
	}

	public void setDds_nfolio(String ddsNfolio) {
		dds_nfolio = ddsNfolio;
	}

	public String getDds_asient() {
		return dds_asient;
	}

	public void setDds_asient(String ddsAsient) {
		dds_asient = ddsAsient;
	}

	public String getDds_comext() {
		return dds_comext;
	}

	public void setDds_comext(String ddsComext) {
		dds_comext = ddsComext;
	}

	public String getDds_centro() {
		return dds_centro;
	}

	public void setDds_centro(String ddsCentro) {
		dds_centro = ddsCentro;
	}

	public String getDds_motbaj() {
		return dds_motbaj;
	}

	public void setDds_motbaj(String ddsMotbaj) {
		dds_motbaj = ddsMotbaj;
	}

	public String getDds_docide() {
		return dds_docide;
	}

	public void setDds_docide(String ddsDocide) {
		dds_docide = ddsDocide;
	}

	public String getDds_nrodoc() {
		return dds_nrodoc;
	}

	public void setDds_nrodoc(String ddsNrodoc) {
		dds_nrodoc = ddsNrodoc;
	}

	public String getDds_sexo() {
		return dds_sexo;
	}

	public void setDds_sexo(String ddsSexo) {
		dds_sexo = ddsSexo;
	}

	public String getDds_nacion() {
		return dds_nacion;
	}

	public void setDds_nacion(String ddsNacion) {
		dds_nacion = ddsNacion;
	}

	public FechaBean getDds_fecnac() {
		return dds_fecnac;
	}

	public void setDds_fecnac(FechaBean ddsFecnac) {
		dds_fecnac = ddsFecnac;
	}

	public String getDds_userna() {
		return dds_userna;
	}

	public void setDds_userna(String ddsUserna) {
		dds_userna = ddsUserna;
	}

	public FechaBean getDds_fecact() {
		return dds_fecact;
	}

	public void setDds_fecact(FechaBean ddsFecact) {
		dds_fecact = ddsFecact;
	}

	public String getDesc_factur() {
		return desc_factur;
	}

	public void setDesc_factur(String desc_factur) {
		this.desc_factur = desc_factur;
	}

	public String getDesc_sexo() {
		return desc_sexo;
	}

	public void setDesc_sexo(String desc_sexo) {
		this.desc_sexo = desc_sexo;
	}

	public String getDesc_nacion() {
		return desc_nacion;
	}

	public void setDesc_nacion(String desc_nacion) {
		this.desc_nacion = desc_nacion;
	}

	public String getDesc_docide() {
		return desc_docide;
	}

	public void setDesc_docide(String desc_docide) {
		this.desc_docide = desc_docide;
	}

	public String getDesc_cierre() {
		return desc_cierre;
	}

	public void setDesc_cierre(String desc_cierre) {
		this.desc_cierre = desc_cierre;
	}

	public String getDesc_domici() {
		return desc_domici;
	}

	public void setDesc_domici(String desc_domici) {
		this.desc_domici = desc_domici;
	}

	public String getDesc_orient() {
		return desc_orient;
	}

	public void setDesc_orient(String desc_orient) {
		this.desc_orient = desc_orient;
	}

	public String getDesc_comext() {
		return desc_comext;
	}

	public void setDesc_comext(String desc_comext) {
		this.desc_comext = desc_comext;
	}

	public String getDesc_motbaj() {
		return desc_motbaj;
	}

	public void setDesc_motbaj(String desc_motbaj) {
		this.desc_motbaj = desc_motbaj;
	}

}
