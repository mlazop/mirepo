package pe.gob.sunat.servicio2.registro.electronico.comppago.factura.model.domain;

import java.io.Serializable;
import java.sql.Timestamp;

public class AuditoriaBean implements Serializable{
	
	private static final long serialVersionUID = 1L;

	private String codUsuRegis;
	
	private Timestamp fecRegis;
	
	private String codUsuModif;
	
	private Timestamp fecModif;

	public String getCodUsuRegis() {
		return codUsuRegis;
	}

	public void setCodUsuRegis(String codUsuRegis) {
		this.codUsuRegis = codUsuRegis;
	}

	public Timestamp getFecRegis() {
		return fecRegis;
	}

	public void setFecRegis(Timestamp fecRegis) {
		this.fecRegis = fecRegis;
	}

	public String getCodUsuModif() {
		return codUsuModif;
	}

	public void setCodUsuModif(String codUsuModif) {
		this.codUsuModif = codUsuModif;
	}

	public Timestamp getFecModif() {
		return fecModif;
	}

	public void setFecModif(Timestamp fecModif) {
		this.fecModif = fecModif;
	}

	
	
	

}
