package pe.gob.sunat.servicio2.registro.electronico.comppago.factura.bean;

import java.beans.BeanInfo;
import java.beans.Introspector;
import java.beans.PropertyDescriptor;
import java.io.Serializable;
import java.lang.reflect.Method;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import pe.gob.sunat.framework.spring.util.date.FechaBean;

/**
 * POJO de domicilio para el comprobante.
 * Ambito: XML.
 * @author Patricia Chacaliaza
 * */
public class DireccionComprobanteBean implements Serializable {
	
	/**
	 * 
	 */
	private static final long serialVersionUID = -4544340036794738321L;

	protected final Log log = LogFactory.getLog(getClass());

	private String cod_tipo_ingreso;
	private String cod_tipo_direccion;
	private String id_estab_emisor;
	private String cod_tipo_establecimiento;
	private String cod_ubigeo;
	private String des_ubigeo;	
	private String cod_dpto;
	private String des_dpto;
	private String cod_prov;
	private String des_prov;	
	private String cod_dist;
	private String des_dist;		
	private String tip_zona;
	private String tip_zona_desc;    
	private String des_zona;
	private String tip_via;
	private String tip_via_desc;    
	private String des_via;
	private String num_numer;
	private String num_inter;
	private String num_kilom;
	private String num_manza;
	private String num_depar;
	private String num_lote;
	private String des_refer;
	private String direccion;
	private String num_ruc_domicilio;
	private Integer cod_estab;

	public String getCod_tipo_ingreso() {
		return cod_tipo_ingreso;
	}


	public void setCod_tipo_ingreso(String codTipoIngreso) {
		cod_tipo_ingreso = codTipoIngreso;
	}


	public String getCod_dpto() {
		return cod_dpto;
	}


	public void setCod_dpto(String codDpto) {
		cod_dpto = codDpto;
	}


	public String getDes_dpto() {
		return des_dpto;
	}


	public void setDes_dpto(String desDpto) {
		des_dpto = desDpto;
	}


	public String getCod_prov() {
		return cod_prov;
	}


	public void setCod_prov(String codProv) {
		cod_prov = codProv;
	}


	public String getDes_prov() {
		return des_prov;
	}


	public void setDes_prov(String desProv) {
		des_prov = desProv;
	}


	public String getCod_dist() {
		return cod_dist;
	}


	public void setCod_dist(String codDist) {
		cod_dist = codDist;
	}


	public String getDes_dist() {
		return des_dist;
	}


	public void setDes_dist(String desDist) {
		des_dist = desDist;
	}


	public String getId_estab_emisor() {
		return id_estab_emisor;
	}


	public void setId_estab_emisor(String idEstabEmisor) {
		id_estab_emisor = idEstabEmisor;
	}


	public String getDireccion() {
		return direccion;
	}


	public void setDireccion(String direccion) {
		this.direccion = direccion;
	}


	public String getCod_tipo_direccion() {
		return cod_tipo_direccion;
	}


	public void setCod_tipo_direccion(String codTipoDireccion) {
		cod_tipo_direccion = codTipoDireccion;
	}


	public String getCod_tipo_establecimiento() {
		return cod_tipo_establecimiento;
	}


	public void setCod_tipo_establecimiento(String codTipoEstablecimiento) {
		cod_tipo_establecimiento = codTipoEstablecimiento;
	}


	public String getCod_ubigeo() {
		return cod_ubigeo;
	}


	public void setCod_ubigeo(String codUbigeo) {
		cod_ubigeo = codUbigeo;
	}


	public String getDes_ubigeo() {
		return des_ubigeo;
	}


	public void setDes_ubigeo(String desUbigeo) {
		des_ubigeo = desUbigeo;
	}
	
	public String getNum_ruc_domicilio() {
		return num_ruc_domicilio;
	}


	public void setNum_ruc_domicilio(String num_ruc_domicilio) {
		this.num_ruc_domicilio = num_ruc_domicilio;
	}


	public Integer getCod_estab() {
		return cod_estab;
	}


	public void setCod_estab(Integer cod_estab) {
		this.cod_estab = cod_estab;
	}

	public String getTip_zona() {
		return tip_zona;
	}


	public void setTip_zona(String tipZona) {
		tip_zona = tipZona;
	}


	public String getTip_zona_desc() {
		return tip_zona_desc;
	}


	public void setTip_zona_desc(String tipZonaDesc) {
		tip_zona_desc = tipZonaDesc;
	}


	public String getDes_zona() {
		return des_zona;
	}


	public void setDes_zona(String desZona) {
		des_zona = desZona;
	}


	public String getTip_via() {
		return tip_via;
	}


	public void setTip_via(String tipVia) {
		tip_via = tipVia;
	}


	public String getTip_via_desc() {
		return tip_via_desc;
	}


	public void setTip_via_desc(String tipViaDesc) {
		tip_via_desc = tipViaDesc;
	}


	public String getDes_via() {
		return des_via;
	}


	public void setDes_via(String desVia) {
		des_via = desVia;
	}


	public String getNum_numer() {
		return num_numer;
	}


	public void setNum_numer(String numNumer) {
		num_numer = numNumer;
	}


	public String getNum_inter() {
		return num_inter;
	}


	public void setNum_inter(String numInter) {
		num_inter = numInter;
	}


	public String getNum_kilom() {
		return num_kilom;
	}


	public void setNum_kilom(String numKilom) {
		num_kilom = numKilom;
	}


	public String getNum_manza() {
		return num_manza;
	}


	public void setNum_manza(String numManza) {
		num_manza = numManza;
	}


	public String getNum_depar() {
		return num_depar;
	}


	public void setNum_depar(String numDepar) {
		num_depar = numDepar;
	}


	public String getNum_lote() {
		return num_lote;
	}


	public void setNum_lote(String numLote) {
		num_lote = numLote;
	}


	public String getDes_refer() {
		return des_refer;
	}


	public void setDes_refer(String desRefer) {
		des_refer = desRefer;
	}


	public Log getLog() {
		return log;
	}


	@Override
	public String toString(){
		String result = "Valores del BEAN "+this.getClass()+"\r" ; 
		Object nill = null;
		try {
			BeanInfo info =  Introspector.getBeanInfo(this.getClass());
			PropertyDescriptor[] pds  = info.getPropertyDescriptors() ;	
			Method getter = null  ; 
			Object valor = "" ; 
			for(PropertyDescriptor pd : pds){								
				if(!"class".equals(pd.getName())){
					try {
						getter = new PropertyDescriptor(pd.getName(), this.getClass()).getReadMethod();
						valor = getter.invoke(this,nill) ;
						result = result +"[ "+ pd.getName()+" ] \t"+" : "+ (valor instanceof FechaBean?((FechaBean)valor).getTimestamp(): valor)+"\r" ;
					} catch (Exception e) {

					}					
				}
			}
		} catch (Exception e) {
			log.error(e, e) ; 
		}		
		return result ; 
	}
}
