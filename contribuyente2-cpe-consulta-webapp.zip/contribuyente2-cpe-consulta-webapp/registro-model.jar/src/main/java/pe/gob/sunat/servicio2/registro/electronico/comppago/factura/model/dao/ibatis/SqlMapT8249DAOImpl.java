package pe.gob.sunat.servicio2.registro.electronico.comppago.factura.model.dao.ibatis;

import java.util.List;

import pe.gob.sunat.framework.spring.util.dao.SqlMapDAOBase;
import pe.gob.sunat.servicio2.registro.electronico.comppago.factura.model.dao.T8249DAO;
import pe.gob.sunat.servicio2.registro.electronico.comppago.factura.model.domain.T8249Bean;

@SuppressWarnings({"deprecation", "unchecked"})
public class SqlMapT8249DAOImpl extends SqlMapDAOBase implements T8249DAO {

	@Override
	public List<T8249Bean> findByFiltro(T8249Bean bean) {
		return (List<T8249Bean>) getSqlMapClientTemplate().queryForList("T8249.findByFiltro", bean);
	}

}
