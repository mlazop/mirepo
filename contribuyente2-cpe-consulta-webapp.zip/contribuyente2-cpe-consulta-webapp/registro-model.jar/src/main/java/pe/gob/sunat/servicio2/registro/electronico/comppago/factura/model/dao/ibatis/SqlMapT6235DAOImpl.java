package pe.gob.sunat.servicio2.registro.electronico.comppago.factura.model.dao.ibatis;

import java.util.List;

import pe.gob.sunat.framework.spring.util.dao.SqlMapDAOBase;
import pe.gob.sunat.servicio2.registro.electronico.comppago.factura.model.dao.T6235DAO;
import pe.gob.sunat.servicio2.registro.electronico.comppago.factura.model.domain.T6235Bean;

@SuppressWarnings({"deprecation", "unchecked"})
public class SqlMapT6235DAOImpl extends SqlMapDAOBase implements T6235DAO {

	@Override
	public List<T6235Bean> findByFiltro(T6235Bean bean) {		
		return (List<T6235Bean>) getSqlMapClientTemplate().queryForList("T6235.findByFiltro", bean);
	}

}
