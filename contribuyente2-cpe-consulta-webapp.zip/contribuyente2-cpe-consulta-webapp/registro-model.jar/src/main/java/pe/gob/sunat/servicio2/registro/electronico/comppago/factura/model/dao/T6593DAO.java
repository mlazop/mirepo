package pe.gob.sunat.servicio2.registro.electronico.comppago.factura.model.dao;

import pe.gob.sunat.servicio2.registro.electronico.comppago.factura.model.domain.BillLogPack;


public interface T6593DAO {
	

	public void actualizaEstado(String nroTicket);
	
	public void actualizaEstado(BillLogPack data);
	
}
