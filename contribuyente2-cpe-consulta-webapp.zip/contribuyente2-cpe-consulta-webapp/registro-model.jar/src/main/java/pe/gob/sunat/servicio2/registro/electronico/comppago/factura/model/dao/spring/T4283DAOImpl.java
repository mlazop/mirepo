package pe.gob.sunat.servicio2.registro.electronico.comppago.factura.model.dao.spring;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;

import javax.sql.DataSource;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.dao.EmptyResultDataAccessException;
import org.springframework.dao.IncorrectResultSizeDataAccessException;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.jdbc.support.lob.LobHandler;

import pe.gob.sunat.servicio2.registro.electronico.comppago.factura.model.dao.T4283DAO;
import pe.gob.sunat.servicio2.registro.electronico.comppago.factura.model.domain.T4283Bean;

@SuppressWarnings({"unchecked", "rawtypes"})
public class T4283DAOImpl implements T4283DAO  {
	
	private final String findRubroCabecera_ByRUC_codCPE_Serie_CPE_Rubro = "SELECT num_ruc ,cod_cpe ,num_serie_cpe ,num_cpe ,num_fila_item ,ind_cab_det ,cod_rubro ,mto_rubro ,des_detalle_rubro ,fec_rubro , cod_usumodif , fec_modif FROM T4283rubroscpe WHERE num_ruc       = ? AND   cod_cpe       = ? AND   num_serie_cpe = ? AND   num_cpe       = ? AND   cod_rubro     = ?   ;";
	
	
	protected final Log log = LogFactory.getLog(getClass());
	private JdbcTemplate jdbcTemplate;
	private LobHandler lobHandler;
	
	
	public void setDataSource(DataSource dataSource) {
		this.jdbcTemplate = new JdbcTemplate(dataSource);
	}
	
	public void setLobHandler(LobHandler lobHandler) {
		this.lobHandler = lobHandler;
	}	
	
	

	public int insert(T4283Bean bean) {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public T4283Bean findRubroCabecera_ByRUC_codCPE_Serie_CPE_Rubro(T4283Bean bean) {
		if (log.isDebugEnabled()) { log.debug("findRubroCabecera_ByRUC_codCPE_Serie_CPE_Rubro( " + bean.toString() +  " )");}
		
		try {
		    RowMapper mapper = new RowMapper() {
		    	public Object mapRow(ResultSet rs, int rowNum) throws SQLException {
		    		T4283Bean beanSearch = new T4283Bean();
		    		if (log.isDebugEnabled()) { log.debug("T4283DAOImpl findRubroCabecera_ByRUC_codCPE_Serie_CPE_Rubro :Mapeando datos");}
		    		beanSearch.setNum_ruc(rs.getString("num_ruc"));
		    		beanSearch.setCod_cpe(rs.getString("cod_cpe"));
		    		beanSearch.setNum_serie_cpe(rs.getString("num_serie_cpe"));
		    		beanSearch.setNum_cpe(rs.getInt("num_cpe"));
		    		beanSearch.setCod_rubro(rs.getInt("cod_rubro"));
		            return beanSearch;
		        }
		    };

			return (T4283Bean)jdbcTemplate.queryForObject(this.findRubroCabecera_ByRUC_codCPE_Serie_CPE_Rubro,
					new Object[]{bean.getNum_ruc(), bean.getCod_cpe(), bean.getNum_serie_cpe(), bean.getNum_cpe(), bean.getCod_rubro()}, mapper);
		} catch (EmptyResultDataAccessException e) {
		    log.warn("No se encontro registro en rubro", e);
		    return null;
		}  catch (IncorrectResultSizeDataAccessException e) {
		    log.warn("No se encontro registro en rubro o se encontro mas de un comprobante", e);
		    return null;
		} catch (RuntimeException e) {
		    log.error(e, e);
		    return null;
		}
	
	}

	
	public List<T4283Bean> findRubroDetalle_ByRUC_codCPE_Serie_CPE_rubro(T4283Bean bean) {
		// TODO Auto-generated method stub
		return null;
	}


	public T4283Bean findRubro_ByRUC_codCPE_Serie_CPE_rubro_numFila_indcabdet(T4283Bean bean) {
		// TODO Auto-generated method stub
		return null;
	}


	public Integer findMaxFila_ByRUC_CPE_Indcabdet(T4283Bean bean) {
		// TODO Auto-generated method stub
		return null;
	}


	public List<T4283Bean> findRubros_ByRUC_codCPE_Serie_CPE_numFila_indcabdet(T4283Bean bean) {
		// TODO Auto-generated method stub
		return null;
	}


	public void deleteByRUC_codCPE_Serie_CPE_indcabdet(T4283Bean bean) {
		// TODO Auto-generated method stub
		
	}


	public void deleteByRUC_codCPE_Serie_CPE_indcabdet_rubro(T4283Bean bean) {
		// TODO Auto-generated method stub
		
	}

}
