package pe.gob.sunat.servicio2.registro.electronico.comppago.factura.model.domain;

import java.io.Serializable;

import pe.gob.sunat.framework.spring.util.date.FechaBean;

public class T4429Bean implements Serializable {
	
	/**
	 * 
	 */
	private static final long serialVersionUID = -1649881113795337259L;
	private String num_ruc;
    private String cod_cpe;
    private String num_serie_cpe ;
    private Integer num_cpe;
    private String num_ruc_rel ;
    private String cod_doc_rel;
    private String num_serie_doc_rel;
    private String num_doc_rel;
    private String cod_relacion;
    private String cod_usumodif;
    private FechaBean fec_modif;
    
	public String getNum_ruc() {
		return num_ruc;
	}
	public void setNum_ruc(String numRuc) {
		num_ruc = numRuc;
	}
	public String getCod_cpe() {
		return cod_cpe;
	}
	public void setCod_cpe(String codCpe) {
		cod_cpe = codCpe;
	}
	public String getNum_serie_cpe() {
		return num_serie_cpe;
	}
	public void setNum_serie_cpe(String numSerieCpe) {
		num_serie_cpe = numSerieCpe;
	}
	public Integer getNum_cpe() {
		return num_cpe;
	}
	public void setNum_cpe(Integer numCpe) {
		num_cpe = numCpe;
	}
	public String getNum_ruc_rel() {
		return num_ruc_rel;
	}
	public void setNum_ruc_rel(String numRucRel) {
		num_ruc_rel = numRucRel;
	}
	public String getCod_doc_rel() {
		return cod_doc_rel;
	}
	public void setCod_doc_rel(String codDocRel) {
		cod_doc_rel = codDocRel;
	}
	public String getNum_serie_doc_rel() {
		return num_serie_doc_rel;
	}
	public void setNum_serie_doc_rel(String numSerieDocRel) {
		num_serie_doc_rel = numSerieDocRel;
	}
	public String getNum_doc_rel() {
		return num_doc_rel;
	}
	public void setNum_doc_rel(String numDocRel) {
		num_doc_rel = numDocRel;
	}
	public String getCod_relacion() {
		return cod_relacion;
	}
	public void setCod_relacion(String codRelacion) {
		cod_relacion = codRelacion;
	}
	public String getCod_usumodif() {
		return cod_usumodif;
	}
	public void setCod_usumodif(String codUsumodif) {
		cod_usumodif = codUsumodif;
	}
	public FechaBean getFec_modif() {
		return fec_modif;
	}
	public void setFec_modif(FechaBean fecModif) {
		fec_modif = fecModif;
	}
     

}
