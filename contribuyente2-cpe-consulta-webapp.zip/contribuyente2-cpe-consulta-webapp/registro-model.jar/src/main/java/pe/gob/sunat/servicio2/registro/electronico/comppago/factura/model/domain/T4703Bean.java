package pe.gob.sunat.servicio2.registro.electronico.comppago.factura.model.domain;


import pe.gob.sunat.framework.spring.util.date.FechaBean;

public class T4703Bean  implements java.io.Serializable{  
	private static final long serialVersionUID = 1L;
	
	
	private String    num_ticket;
	private Integer   num_linea;
	private String    num_ruc; 	
	private String    cod_cpe; 
	private String    num_serie_cpe; 
	private Integer   num_cpe; 
	private FechaBean fec_emision;	
	private String    ind_origen; 
	private String    ind_estado;	
	private String    des_motivo; 
	private String    cod_usumodif; 
    private FechaBean fec_modif;
	public String getNum_ticket() {
		return num_ticket;
	}
	public void setNum_ticket(String numTicket) {
		num_ticket = numTicket;
	}
	public Integer getNum_linea() {
		return num_linea;
	}
	public void setNum_linea(Integer numLinea) {
		num_linea = numLinea;
	}
	public String getNum_ruc() {
		return num_ruc;
	}
	public void setNum_ruc(String numRuc) {
		num_ruc = numRuc;
	}
	public String getCod_cpe() {
		return cod_cpe;
	}
	public void setCod_cpe(String codCpe) {
		cod_cpe = codCpe;
	}
	public String getNum_serie_cpe() {
		return num_serie_cpe;
	}
	public void setNum_serie_cpe(String numSerieCpe) {
		num_serie_cpe = numSerieCpe;
	}
	public Integer getNum_cpe() {
		return num_cpe;
	}
	public void setNum_cpe(Integer numCpe) {
		num_cpe = numCpe;
	}
	public FechaBean getFec_emision() {
		return fec_emision;
	}
	public void setFec_emision(FechaBean fecEmision) {
		fec_emision = fecEmision;
	}
	public String getInd_origen() {
		return ind_origen;
	}
	public void setInd_origen(String indOrigen) {
		ind_origen = indOrigen;
	}
	public String getInd_estado() {
		return ind_estado;
	}
	public void setInd_estado(String indEstado) {
		ind_estado = indEstado;
	}
	public String getDes_motivo() {
		return des_motivo;
	}
	public void setDes_motivo(String desMotivo) {
		des_motivo = desMotivo;
	}
	public String getCod_usumodif() {
		return cod_usumodif;
	}
	public void setCod_usumodif(String codUsumodif) {
		cod_usumodif = codUsumodif;
	}
	public FechaBean getFec_modif() {
		return fec_modif;
	}
	public void setFec_modif(FechaBean fecModif) {
		fec_modif = fecModif;
	}
	@Override
	public String toString() {
		return "T4703Bean [cod_cpe=" + cod_cpe + ", cod_usumodif="
				+ cod_usumodif + ", des_motivo=" + des_motivo
				+ ", fec_emision=" + fec_emision + ", fec_modif=" + fec_modif
				+ ", ind_estado=" + ind_estado + ", ind_origen=" + ind_origen
				+ ", num_cpe=" + num_cpe + ", num_linea=" + num_linea
				+ ", num_ruc=" + num_ruc + ", num_serie_cpe=" + num_serie_cpe
				+ ", num_ticket=" + num_ticket + "]";
	}
	public T4703Bean(String numTicket, Integer numLinea, String numRuc,
			String codCpe, String numSerieCpe, Integer numCpe,
			FechaBean fecEmision, String indOrigen, String indEstado,
			String desMotivo, String codUsumodif, FechaBean fecModif) {
		super();
		num_ticket = numTicket;
		num_linea = numLinea;
		num_ruc = numRuc;
		cod_cpe = codCpe;
		num_serie_cpe = numSerieCpe;
		num_cpe = numCpe;
		fec_emision = fecEmision;
		ind_origen = indOrigen;
		ind_estado = indEstado;
		des_motivo = desMotivo;
		cod_usumodif = codUsumodif;
		fec_modif = fecModif;
	}
	public T4703Bean() {
		super();
	}
    
}
/*

create table T4703DETCOMBAJA  (
  NUM_TICKET           CHAR(15)                        not null,
  NUM_LINEA            INTEGER                         not null,
  NUM_RUC              CHAR(11)                        not null,
  COD_CPE              CHAR(2)                         not null,
  NUM_SERIE_CPE        VARCHAR(20)                     not null,
  NUM_CPE              INTEGER                         not null,
  FEC_EMISION          DATE                            not null,
  IND_ORIGEN           CHAR(1)                         not null,
  IND_ESTADO           CHAR(1)                         not null,
  DES_MOTIVO           VARCHAR(250)                    not null,
  COD_USUMODIF         VARCHAR(20)                     not null,
  FEC_MODIF            DATETIME YEAR TO SECOND         not null
);     
      */
/*
 create table tbanulado(
  NUM_RUC              CHAR(11)       not null,
  NUM_TICKET           CHAR(15)       not null,
  NUM_CORREL_TICKET    INTEGER        not null,
  NUM_SERIE            CHAR(4)        not null,
  COD_TIPCOMP          CHAR(2),
  NUM_COMPROBANTE      INTEGER,
  FEC_EMISION          DATE,
  IND_ORIGEN           CHAR(1),
  IND_PROCESO          CHAR(1),
  FEC_REGISTRO         date,
  IND_ESTADO           char(1),
  DES_MOTIVO           VARCHAR(200),
  COD_USUMODIF        VARCHAR(20),
  FEC_MODIF            DATETIME YEAR TO SECOND,
primary key (NUM_RUC, NUM_TICKET, NUM_CORREL_TICKET)
      constraint PK_tbanulado
);


 */

