package pe.gob.sunat.servicio2.registro.electronico.comppago.factura.model.dao;

import pe.gob.sunat.servicio2.registro.electronico.comppago.factura.model.domain.T6576ArchRetBean;


public interface T6576ArchRetInsertDAO {
    
    public void insertDocument(T6576ArchRetBean data);
}