package pe.gob.sunat.servicio2.registro.electronico.comppago.retencion.model.dao.ibatis;

import javax.annotation.PostConstruct;
import javax.annotation.Resource;

import org.springframework.orm.ibatis.support.SqlMapClientDaoSupport;

import com.ibatis.sqlmap.client.SqlMapClient;

@SuppressWarnings("deprecation")
public class BaseCpeleDAO extends SqlMapClientDaoSupport {

	@Resource(name = "sqlMapClientCpele")
	private SqlMapClient sqlMapClient; 

	@PostConstruct
	public void initSqlMapClient() {
		super.setSqlMapClient(sqlMapClient);
	}
	
	
	
}