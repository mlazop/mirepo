package pe.gob.sunat.servicio2.registro.electronico.comppago.factura.model.dao;

import java.util.List;

import pe.gob.sunat.servicio2.registro.electronico.comppago.factura.model.domain.T6235Bean;

public interface T6235DAO {
	
	public List<T6235Bean> findByFiltro(T6235Bean param) ;
	
}
