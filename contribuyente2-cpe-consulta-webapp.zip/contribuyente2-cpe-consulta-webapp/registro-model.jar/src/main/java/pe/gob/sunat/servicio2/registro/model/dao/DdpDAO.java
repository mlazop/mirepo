package pe.gob.sunat.servicio2.registro.model.dao;

import java.util.List;
import java.util.Map;

import javax.sql.DataSource;

import org.springframework.dao.DataAccessException;

import pe.gob.sunat.servicio2.registro.model.domain.DdpBean;

/**
 * Dao para el control de la tabla ddp
 * @author wcavalie
 */
@SuppressWarnings({"rawtypes"})
public interface DdpDAO {
	public DdpBean findByNroRUC(String nroRUC);
	public Integer findByRUCActivo(String numeroDeRUC);
	/**
   * Metodo que busca informacion del ruc
   * @autor rmanrique
   * @param numruc String
   * @return Map
   * @throws DataAccessException
   */		
  public Map findByPK(String numruc) throws DataAccessException;
  
  /**
   * Metodo que busca informacion del ruc con un datasource especifico
   * @autor rmanrique
   * @param datasource DataSource
   * @param numruc String
   * @return Map
   * @throws DataAccessException
   */
  public Map findByPK(DataSource dataSource, String numruc) throws DataAccessException;
  
  public Map findByPK(String s, boolean flag) throws DataAccessException;

  public Map findByPK(String s, boolean flag, boolean flag1) throws DataAccessException;

  public Map findByPKDirecc(String s)  throws DataAccessException;

  public Map findByPKDirecc(String s, boolean flag)  throws DataAccessException;

  public Map findByPKDirecc(String s, boolean flag, boolean flag1)  throws DataAccessException;
  
  public Map findByPKDirecc(DataSource dataSource, String s, boolean flag, boolean flag1)  throws DataAccessException;

  public String getDomicilioLegal(String s)  throws DataAccessException;

  /**
   * Inserta un nuevo contribuyente.
   * @param params
  */
  
  public void insert(Map params);

  /**
   * Actualiza la direcci�n del contribuyente, seg�n el nro de ruc.
   * @param params
   */

  public void updateDirecc(DataSource dataSource, Map params);
  
  public String recuperaDependencia(String ruc);
  
  public Map findNumregCiiuByPK(String numruc) throws DataAccessException;
  
  public List findWithDdsNroDoc(String nrodoc) throws DataAccessException;
 
  /**
  * Actualiza el estado del flag22 seg�n el n�mero de ruc
  * @param dataSource
  * @param params
  * <br><b>flag22</b> el valor del estado a actualizar
  * <br><b>usuario</b> el usuario de modificaci�n
  * <br><b>ddp_numruc</b> n�mero de ruc
  */
  public void updateFlag22(DataSource dataSource, Map params);
  
  public DdpBean findByNroRUCMD(String nroRUC);
  
  /**
   * Metodo que trae un registro de la ddp en base al ruc y estado para la el ws consultaruc
   * @author ecardenasr
   * @param numruc
   * @param estado
   * @return
   */	
  
public Map findByPKws(String ddp_numruc, String ddp_estado);
  
  /**
   * Metodo que trae los datos necesarios para formar el domicilio legal del ws consultaruc
   * @author ecardenasr
   * @param numruc
   * @param estado
   * @return
   */
  
public Map getDomicilioLegalWS(String numruc, String estado);
  
}
