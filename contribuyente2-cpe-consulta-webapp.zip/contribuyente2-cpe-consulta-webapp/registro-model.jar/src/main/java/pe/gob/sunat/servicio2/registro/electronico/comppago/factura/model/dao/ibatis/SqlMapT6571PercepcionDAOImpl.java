package pe.gob.sunat.servicio2.registro.electronico.comppago.factura.model.dao.ibatis;


import java.util.HashMap;
import java.util.Map;

import pe.gob.sunat.framework.spring.util.dao.SqlMapDAOBase;
import pe.gob.sunat.servicio2.registro.electronico.comppago.factura.model.dao.T6571PercepcionSelectDAO;
import pe.gob.sunat.servicio2.registro.electronico.comppago.factura.model.domain.PkComprobante;
import pe.gob.sunat.servicio2.registro.electronico.comppago.factura.model.domain.T6571PercepcionBean;

public class SqlMapT6571PercepcionDAOImpl extends SqlMapDAOBase implements T6571PercepcionSelectDAO {
	

	@Override
	public T6571PercepcionBean buscarPorPk(String numeroRuc, String codigoGuia, String numeroSerie, Integer numeroGuia) {
		
		
		PkComprobante pkComprobante = new PkComprobante(numeroRuc,codigoGuia,numeroSerie,numeroGuia);
		
		if (log.isDebugEnabled()) log.debug("SqlMapT6571PercepcionDAOImpl.buscarPorPk");
	
		return (T6571PercepcionBean) getSqlMapClientTemplate().queryForObject("T6571.buscarPorPk", pkComprobante);
		
	}
	
	@Override
	public Integer buscarPorPrimaryKey(String numeroRuc, String codigoGuia, String numeroSerie, String numeroGuia) {
		
		if (log.isDebugEnabled()) log.debug("SqlMapT6571PercepcionDAOImpl.buscarPorPrimaryKey");
	
		Map<String, Object> params = new HashMap<String, Object>(); 
		params.put("numeroRuc", numeroRuc) ;
		params.put("codigoGuia", codigoGuia) ; 
		params.put("numeroSerie", numeroSerie) ;
		params.put("numeroGuia", numeroGuia) ; 
		
		return (Integer) getSqlMapClientTemplate().queryForObject("T6571.buscarPorPrimaryKey", params);
		
	}
	

   
}
