package pe.gob.sunat.servicio2.registro.comppago.factura.gem.contingencia.model.domain;

import java.io.Serializable;

import pe.gob.sunat.framework.spring.util.date.FechaBean;


public class T5675Bean implements Serializable{
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 9029959794017239305L;
	private Long	numeTicket;
	private String	numeRuc;
	private String	contingencia;
	private FechaBean	fechaRegistro;
	private Integer	numeCorreEnvio;
	private String	nombreArchivo;
	private FechaBean	fechaDesdePro;
	private FechaBean	fechaHastaPro;
	private String	periodoUsoCpe;

	private Integer	cantProcCpe;
	private Integer	cantTamaArch;
	private String	indicadorEstado;
	private String	usuarioRegistra;
	private FechaBean fechaRegistra;
	private String indicadorVigente;
	private FechaBean fechaContingencia;
	private String indicadorProcesado;
	private T5676Bean contingenciaDetalleBean;
	private T5677Bean contingenciaArchivoBean;
	private T5678Bean contingenciaErrorBean;
	
	/**
	 * @return the numeTicket
	 */
	public Long getNumeTicket() {
		return numeTicket;
	}
	/**
	 * @param numeTicket the numeTicket to set
	 */
	public void setNumeTicket(Long numeTicket) {
		this.numeTicket = numeTicket;
	}
	/**
	 * @return the numeRuc
	 */
	public String getNumeRuc() {
		return numeRuc;
	}
	/**
	 * @param numeRuc the numeRuc to set
	 */
	public void setNumeRuc(String numeRuc) {
		this.numeRuc = numeRuc;
	}
	/**
	 * @return the contingencia
	 */
	public String getContingencia() {
		return contingencia;
	}
	/**
	 * @param contingencia the contingencia to set
	 */
	public void setContingencia(String contingencia) {
		this.contingencia = contingencia;
	}
	/**
	 * @return the fechaRegistro
	 */
	public FechaBean getFechaRegistro() {
		return fechaRegistro;
	}
	/**
	 * @param fechaRegistro the fechaRegistro to set
	 */
	public void setFechaRegistro(FechaBean fechaRegistro) {
		this.fechaRegistro = fechaRegistro;
	}
	/**
	 * @return the numeCorreEnvio
	 */
	public Integer getNumeCorreEnvio() {
		return numeCorreEnvio;
	}
	/**
	 * @param numeCorreEnvio the numeCorreEnvio to set
	 */
	public void setNumeCorreEnvio(Integer numeCorreEnvio) {
		this.numeCorreEnvio = numeCorreEnvio;
	}
	/**
	 * @return the nombreArchivo
	 */
	public String getNombreArchivo() {
		return nombreArchivo;
	}
	/**
	 * @param nombreArchivo the nombreArchivo to set
	 */
	public void setNombreArchivo(String nombreArchivo) {
		this.nombreArchivo = nombreArchivo;
	}
	/**
	 * @return the fechaDesdePro
	 */
	public FechaBean getFechaDesdePro() {
		return fechaDesdePro;
	}
	/**
	 * @param fechaDesdePro the fechaDesdePro to set
	 */
	public void setFechaDesdePro(FechaBean fechaDesdePro) {
		this.fechaDesdePro = fechaDesdePro;
	}
	/**
	 * @return the fechaHastaPro
	 */
	public FechaBean getFechaHastaPro() {
		return fechaHastaPro;
	}
	/**
	 * @param fechaHastaPro the fechaHastaPro to set
	 */
	public void setFechaHastaPro(FechaBean fechaHastaPro) {
		this.fechaHastaPro = fechaHastaPro;
	}
	/**
	 * @return the periodoUsoCpe
	 */
	public String getPeriodoUsoCpe() {
		return periodoUsoCpe;
	}
	/**
	 * @param periodoUsoCpe the periodoUsoCpe to set
	 */
	public void setPeriodoUsoCpe(String periodoUsoCpe) {
		this.periodoUsoCpe = periodoUsoCpe;
	}
	/**
	 * @return the cantProcCpe
	 */
	public Integer getCantProcCpe() {
		return cantProcCpe;
	}
	/**
	 * @param cantProcCpe the cantProcCpe to set
	 */
	public void setCantProcCpe(Integer cantProcCpe) {
		this.cantProcCpe = cantProcCpe;
	}
	/**
	 * @return the cantTamaArch
	 */
	public Integer getCantTamaArch() {
		return cantTamaArch;
	}
	/**
	 * @param cantTamaArch the cantTamaArch to set
	 */
	public void setCantTamaArch(Integer cantTamaArch) {
		this.cantTamaArch = cantTamaArch;
	}
	/**
	 * @return the estadoContingencia
	 */
	public String getIndicadorEstado() {
		return indicadorEstado;
	}
	/**
	 * @param estadoContingencia the estadoContingencia to set
	 */
	public void setIndicadorEstado(String indicadorEstado) {
		this.indicadorEstado = indicadorEstado;
	}
	/**
	 * @return the usuarioRegistra
	 */
	public String getUsuarioRegistra() {
		return usuarioRegistra;
	}
	/**
	 * @param usuarioRegistra the usuarioRegistra to set
	 */
	public void setUsuarioRegistra(String usuarioRegistra) {
		this.usuarioRegistra = usuarioRegistra;
	}
	/**
	 * @return the fechaRegistra
	 */
	public FechaBean getFechaRegistra() {
		return fechaRegistra;
	}
	/**
	 * @param fechaRegistra the fechaRegistra to set
	 */
	public void setFechaRegistra(FechaBean fechaRegistra) {
		this.fechaRegistra = fechaRegistra;
	}
	
	/**
	 * @return the contingenciaDetalleBean
	 */
	public T5676Bean getContingenciaDetalleBean() {
		return contingenciaDetalleBean;
	}
	/**
	 * @param contingenciaDetalleBean the contingenciaDetalleBean to set
	 */
	public void setContingenciaDetalleBean(
			T5676Bean contingenciaDetalleBean) {
		this.contingenciaDetalleBean = contingenciaDetalleBean;
	}
	/**
	 * @return the contingenciaArchivoBean
	 */
	public T5677Bean getContingenciaArchivoBean() {
		return contingenciaArchivoBean;
	}
	/**
	 * @param contingenciaArchivoBean the contingenciaArchivoBean to set
	 */
	public void setContingenciaArchivoBean(
			T5677Bean contingenciaArchivoBean) {
		this.contingenciaArchivoBean = contingenciaArchivoBean;
	}
	/**
	 * @return the contingenciaErrorBean
	 */
	public T5678Bean getContingenciaErrorBean() {
		return contingenciaErrorBean;
	}
	/**
	 * @param contingenciaErrorBean the contingenciaErrorBean to set
	 */
	public void setContingenciaErrorBean(T5678Bean contingenciaErrorBean) {
		this.contingenciaErrorBean = contingenciaErrorBean;
	}
	
	public String getIndicadorVigente() {
		return indicadorVigente;
	}
	public void setIndicadorVigente(String indicadorVigente) {
		this.indicadorVigente = indicadorVigente;
	}
	public FechaBean getFechaContingencia() {
		return fechaContingencia;
	}
	public void setFechaContingencia(FechaBean fechaContingencia) {
		this.fechaContingencia = fechaContingencia;
	}
	
	public String getIndicadorProcesado() {
		return indicadorProcesado;
	}
	public void setIndicadorProcesado(String indicadorProcesado) {
		this.indicadorProcesado = indicadorProcesado;
	}
}
