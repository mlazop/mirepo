package pe.gob.sunat.servicio2.registro.electronico.comppago.factura.model.dao.ibatis;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import pe.gob.sunat.framework.spring.util.dao.SqlMapDAOBase;
import pe.gob.sunat.framework.spring.util.date.FechaBean;
import pe.gob.sunat.servicio2.registro.electronico.comppago.factura.model.dao.T4241DAO;
import pe.gob.sunat.servicio2.registro.electronico.comppago.factura.model.domain.T4241Bean;

@SuppressWarnings({"deprecation","unchecked", "rawtypes"})
public class SqlMapT4241DAOImpl extends SqlMapDAOBase implements T4241DAO{
    

	@Override
	public List<T4241Bean> findByRUCRecepCPEPendientesAnulacion(
			String numeroDeRUC , String codCpe) {
		if (log.isDebugEnabled()) {log.debug("SqlMapDAOBase findByRUCRecepCPEPendientesAnulacion (" + numeroDeRUC + ")");}
		T4241Bean bean = new T4241Bean();
		bean.setCod_docide_recep("06");
		bean.setNum_docide_recep(numeroDeRUC);
		bean.setCod_cpe(codCpe);
		List <T4241Bean> lst = (ArrayList <T4241Bean>) getSqlMapClientTemplate().queryForList("T4241.findByRUCRecepCPEPendientesAnulacion", bean);
		return lst;
	}

	@Override
	public int insert(T4241Bean bean) {
		if (log.isDebugEnabled()) {log.debug("insert (" + bean + ")");}
		getSqlMapClientTemplate().insert("T4241.insert", bean);
		return 0;
	}
	
	@Override
	public void updateCPEAnular(T4241Bean cpe) {
		if (log.isDebugEnabled()) {log.debug("SqlMapDAOBase updateCPEAnular (" + cpe.getNum_cpe() + ")");}
	
		getSqlMapClientTemplate().update("T4241.updateCPEAnular",cpe);
	}
	
	@Override
	public void updateCPERVI(T4241Bean cpe) {
		if (log.isDebugEnabled()) {log.debug("SqlMapDAOBase updateCPERVI (" + cpe.getNum_cpe() + ")");}
	
		getSqlMapClientTemplate().update("T4241.updateCPERVI",cpe);
	}
	
	
	
	@Override
	public List<T4241Bean> findByNroRUCEmitidas(String nroRUC, FechaBean fechaIni, FechaBean fechaFin, String codCpe) {
		if (log.isDebugEnabled()) {log.debug("findByNroRUCEmitidas (" + nroRUC + ")");}
		
		Map<String, Object> params = new HashMap<String, Object>();
		params.put("cod_cpe", codCpe);
		params.put("nroRUC", nroRUC);
		params.put("fechaIni", fechaIni);
		params.put("fechaFin", fechaFin);
		
		log.debug(params);
		
		List emitidas =  (ArrayList<T4241Bean>) getSqlMapClientTemplate().queryForList("T4241.findByNroRUCEmitidas", params);
		return emitidas;
	}

	
	@Override
	public List<T4241Bean> findByNroRUCRechazadas(String nroRUC, FechaBean fechaIni, FechaBean fechaFin, String codCpe) {
		if (log.isDebugEnabled()) {log.debug("findByNroRUCRechazadas (" + nroRUC + ")");}
		
		Map<String, Object> params = new HashMap<String, Object>();
		params.put("cod_cpe", codCpe);
		params.put("nroRUC", nroRUC);
		params.put("fechaIni", fechaIni);
		params.put("fechaFin", fechaFin);
		
		List rechazadas =  (ArrayList<T4241Bean>) getSqlMapClientTemplate().queryForList("T4241.findByNroRUCRechazadas", params);
		return rechazadas;
	}

	
	@Override
	public List<T4241Bean> findByNroRUCRecibidas(String nroRUC, FechaBean fechaIni, FechaBean fechaFin, String codCpe) {
		if (log.isDebugEnabled()) {log.debug("findByNroRUCRecibidas (" + nroRUC + ")");}
		
		Map<String, Object> params = new HashMap<String, Object>();
		params.put("cod_cpe", codCpe);
		params.put("nroRUC", nroRUC);
		params.put("fechaIni", fechaIni);
		params.put("fechaFin", fechaFin);
		
		List recibidas =  (ArrayList<T4241Bean>) getSqlMapClientTemplate().queryForList("T4241.findByNroRUCRecibidas", params);
		return recibidas;
	}
	
	
	@Override
	public List<T4241Bean> findByNroRUCBVERecibidas(String nroRUC, FechaBean fechaIni, FechaBean fechaFin, String codCpe) {
		if (log.isDebugEnabled()) {log.debug("findByNroRUCBVERecibidas (" + nroRUC + ")");}
		
		Map<String, Object> params = new HashMap<String, Object>();
		params.put("cod_cpe", codCpe);
		params.put("nroRUC", nroRUC);
		params.put("fechaIni", fechaIni);
		params.put("fechaFin", fechaFin);
		
		List recibidas =  (ArrayList<T4241Bean>) getSqlMapClientTemplate().queryForList("T4241.findByNroRUCBVERecibidas", params);
		return recibidas;
	}
	
//	
//	@Override
//	public List<T4241Bean> findByNroRUCRecibidas(String nroRUC, FechaBean fechaIni, FechaBean fechaFin, String codCpe, String numSerieCpe) {
//		Map<String, Object> params = new HashMap<String, Object>();
//		params.put("cod_cpe", codCpe);
//		params.put("nroRUC", nroRUC);
//		params.put("fechaIni", fechaIni);
//		params.put("fechaFin", fechaFin);
//		params.put("numSerieCpe", numSerieCpe);
//		
//		List recibidas =  (ArrayList<T4241Bean>) getSqlMapClientTemplate().queryForList("T4241.findByNroRUCRecibidas", params);
//		return recibidas;
//	}


	@Override
	public T4241Bean findByPK(String nroRUC, String nroSerie, Integer nroCPE, String codCpe) {
		T4241Bean bean = new T4241Bean();
		bean.setCod_cpe(codCpe);
		bean.setNum_ruc(nroRUC);
		bean.setNum_serie_cpe(nroSerie);
		bean.setNum_cpe(nroCPE);
		
		Object obj = getSqlMapClientTemplate().queryForObject("T4241.findByPK", bean);
		
		return (obj != null ? (T4241Bean) obj: null);
		
	}
	
	
	public List<T4241Bean> findCPEBy_RUCTipoProcedencia (String nroRUC,  String codCpe, String procedencia) {
		if (log.isDebugEnabled()) {log.debug(" SqlMapDAOBase findCPEBy_RUCTipoProcedencia (" + nroRUC + ")");}
		
		T4241Bean bean = new T4241Bean();
		bean.setCod_cpe(codCpe);
		bean.setNum_ruc(nroRUC);
		bean.setInd_procedencia(procedencia);
		List <T4241Bean> lst = (ArrayList <T4241Bean>) getSqlMapClientTemplate().queryForList("T4241.findCPEBy_RUCTipoProcedencia", bean);
		return lst;
	
	}
	
	
	
	public List<T4241Bean> findFacturasByRUC (String nroRUC,  String codCpe) {
		if (log.isDebugEnabled()) {log.debug(" SqlMapDAOBase findFacturasByRUC (" + nroRUC + ")");}
		
		T4241Bean bean = new T4241Bean();
		bean.setCod_cpe(codCpe);
		bean.setNum_ruc(nroRUC);
		List <T4241Bean> lst = (ArrayList <T4241Bean>) getSqlMapClientTemplate().queryForList("T4241.findFacturasByRUC", bean);
		return lst;
	
	}

	public List<T4241Bean> findByNroRUCNCNDEmitidas(String nroRUC,
			FechaBean fechaIni, FechaBean fechaFin, String codCpe) {
		
		if (log.isDebugEnabled()) {log.debug("findByNroRUCNCNDEmitidas (" + nroRUC + ")");}
		
		Map<String, Object> params = new HashMap<String, Object>();
		params.put("cod_cpe", codCpe);
		params.put("nroRUC", nroRUC);
		params.put("fechaIni", fechaIni);
		params.put("fechaFin", fechaFin);
		
		log.debug(params);		
		
		List emitidas =  (ArrayList<T4241Bean>) getSqlMapClientTemplate().queryForList("T4241.findByNroRUCNDNCEmitidas", params);
		return emitidas;
		
	}

	
	public List<T4241Bean> findByNroRUCNCNDRecibidas(String nroRUC, FechaBean fechaIni, FechaBean fechaFin, String codCpe) {
		if (log.isDebugEnabled()) {log.debug("findByNroRUCNCNDRecibidas (" + nroRUC + ")");}
		
		Map<String, Object> params = new HashMap<String, Object>();
		params.put("cod_cpe", codCpe);
		params.put("nroRUC", nroRUC);
		params.put("fechaIni", fechaIni);
		params.put("fechaFin", fechaFin);
		
		List recibidas =  (ArrayList<T4241Bean>) getSqlMapClientTemplate().queryForList("T4241.findByNroRUCNCNDRecibidas", params);
		return recibidas;
	}
	
	public List<T4241Bean> findByNroRUCNCNDBVEEmitidas(String nroRUC,
			FechaBean fechaIni, FechaBean fechaFin, String codCpe) {
		
		if (log.isDebugEnabled()) {log.debug("findByNroRUCNCNDBVEEmitidas (" + nroRUC + ")");}
		
		Map<String, Object> params = new HashMap<String, Object>();
		params.put("cod_cpe", codCpe);
		params.put("nroRUC", nroRUC);
		params.put("fechaIni", fechaIni);
		params.put("fechaFin", fechaFin);
		
		log.debug(params);		
		
		List emitidas =  (ArrayList<T4241Bean>) getSqlMapClientTemplate().queryForList("T4241.findByNroRUCNDNCBVEEmitidas", params);
		return emitidas;		
	}

	
	public List<T4241Bean> findByNroRUCNCNDBVERecibidas(String nroRUC, FechaBean fechaIni, FechaBean fechaFin, String codCpe) {
		if (log.isDebugEnabled()) {log.debug("findByNroRUCNCNDBVERecibidas (" + nroRUC + ")");}
		
		Map<String, Object> params = new HashMap<String, Object>();
		params.put("cod_cpe", codCpe);
		params.put("nroRUC", nroRUC);
		params.put("fechaIni", fechaIni);
		params.put("fechaFin", fechaFin);
		
		List recibidas =  (ArrayList<T4241Bean>) getSqlMapClientTemplate().queryForList("T4241.findByNroRUCNCNDBVERecibidas", params);
		return recibidas;
	}
	
	
	public List<T4241Bean> findByNroRUCBVEEmitidas(String nroRUC, FechaBean fechaIni, FechaBean fechaFin, String codCpe){
		if (log.isDebugEnabled()) {log.debug("findByNroRUCBVERecibidas (" + nroRUC + ")");}
		
		Map<String, Object> params = new HashMap<String, Object>();
		params.put("cod_cpe", codCpe);
		params.put("nroRUC", nroRUC);
		params.put("fechaIni", fechaIni);
		params.put("fechaFin", fechaFin);
		
		List recibidas =  (ArrayList<T4241Bean>) getSqlMapClientTemplate().queryForList("T4241.findByNroRUCBVEEmitidas", params);
		return recibidas;
	}

	@Override
	public void updateCPEDeBajaFeGem(T4241Bean factura) {
		if (log.isDebugEnabled()) {log.debug("SqlMapT4241DAO updateCPEDeBajaFeGem (" + factura.getNum_cpe() + ")");}		
		getSqlMapClientTemplate().update("T4241.updateCPEDEBAJAFEGEM",factura);
		
	}

	
	
	public List<T4241Bean> findByNroRUCCPCEmitidos(String nroRUC, FechaBean fechaIni, FechaBean fechaFin) {
		if (log.isDebugEnabled()) {log.debug("findByNroRUCCPCEmitidos (" + nroRUC + ")");}
		
		Map<String, Object> params = new HashMap<String, Object>();
		params.put("nroRUC", nroRUC);
		params.put("fechaIni", fechaIni);
		params.put("fechaFin", fechaFin);
		
		List comprobantes =  (ArrayList<T4241Bean>) getSqlMapClientTemplate().queryForList("T4241.findByNroRUCCPCEmitidos", params);
		return comprobantes;
	}	
	
	
	public List<T4241Bean> findByNroRUCCPCEmitidosMonedaExtranjera(String nroRUC, FechaBean fechaIni, FechaBean fechaFin) {
		if (log.isDebugEnabled()) {log.debug("findByNroRUCCPCEmitidosMonedaExtranjera (" + nroRUC + ")");}
		
		Map<String, Object> params = new HashMap<String, Object>();
		params.put("nroRUC", nroRUC);
		params.put("fechaIni", fechaIni);
		params.put("fechaFin", fechaFin);
		
		List comprobantes =  (ArrayList<T4241Bean>) getSqlMapClientTemplate().queryForList("T4241.findByNroRUCCPCEmitidosMonedaExtranjera", params);
		return comprobantes;
	}	

	
	
	public List<T4241Bean> findByNroRUCCPCEmitidos_RVI(String nroRUC, FechaBean fechaIni, FechaBean fechaFin) {
		if (log.isDebugEnabled()) {log.debug("findByNroRUCCPCEmitidos_RVI (" + nroRUC + ")");}
		
		Map<String, Object> params = new HashMap<String, Object>();
		params.put("nroRUC", nroRUC);
		params.put("fechaIni", fechaIni);
		params.put("fechaFin", fechaFin);
		
		List comprobantes =  (ArrayList<T4241Bean>) getSqlMapClientTemplate().queryForList("T4241.findByNroRUCCPCEmitidos_RVI", params);
		return comprobantes;
	}	

	
	@Override
	public Integer findMaxCuo_ByRUCPerRegVen(String nroRUC, String periodoRegVen) {
		if (log.isDebugEnabled()) {log.debug("findMaxCuo_ByRUCPerRegVen (" + nroRUC + ")");}
		
		Map<String, Object> params = new HashMap<String, Object>();
		params.put("nroRUC", nroRUC);
		params.put("periodo", periodoRegVen);
	
		return (Integer) getSqlMapClientTemplate().queryForObject("T4241.findMaxCuo_ByRUCPerRegVen", params);
	}


	
	public Integer findTotalFacturasByRUC (String nroRUC,  String codCpe) {
		if (log.isDebugEnabled()) {log.debug(" SqlMapDAOBase findTotalFacturasByRUC (" + nroRUC + ")");}
		
		T4241Bean bean = new T4241Bean();
		bean.setCod_cpe(codCpe);
		bean.setNum_ruc(nroRUC);
		Integer total = (Integer) getSqlMapClientTemplate().queryForObject("T4241.findTotalFacturasByRUC", bean);
		return total;	
	}
	
	
	public Integer findTotalBoletasByRUC (String nroRUC,  String codCpe) {
		if (log.isDebugEnabled()) {log.debug(" SqlMapDAOBase findTotalBoletasByRUC (" + nroRUC + ")");}
		
		T4241Bean bean = new T4241Bean();
		bean.setCod_cpe(codCpe);
		bean.setNum_ruc(nroRUC);
		Integer total = (Integer) getSqlMapClientTemplate().queryForObject("T4241.findTotalBoletasByRUC", bean);
		return total;	
	}

	@Override
	public List<T4241Bean> buscarFacturaEmitida(Map parametros) {
		return (ArrayList)getSqlMapClientTemplate().queryForList("T4241.buscarFacturaEmitida", parametros);
	}

	@Override
	public List<T4241Bean> buscarFacturaRechazada(Map parametros) {
		return (ArrayList)getSqlMapClientTemplate().queryForList("T4241.buscarFacturaRechazada", parametros);
	}

	
	@Override
	public List<T4241Bean> buscarFacturaRecibida(Map parametros) {
		return (ArrayList)getSqlMapClientTemplate().queryForList("T4241.buscarFacturaRecibida", parametros);
	}

	@Override
	public List<T4241Bean> buscarNCNDEmitida(Map parametros) {
		return (ArrayList)getSqlMapClientTemplate().queryForList("T4241.buscarNCNDEmitida", parametros);
	}

	@Override
	public List<T4241Bean> buscarNCNDRecibida(Map parametros) {
		return (ArrayList)getSqlMapClientTemplate().queryForList("T4241.buscarNCNDRecibida", parametros);
	}
	
	@Override
	public List<T4241Bean> buscarBoletaEmitida(Map parametros) {
		return (ArrayList)getSqlMapClientTemplate().queryForList("T4241.buscarBoletaEmitida", parametros);
	}
	
	@Override
	public List<T4241Bean> buscarBoletaRecibida(Map parametros) {
		return (ArrayList)getSqlMapClientTemplate().queryForList("T4241.buscarBoletaRecibida", parametros);
	}

	@Override
	public T4241Bean findByFiltro(T4241Bean bean){		
			Object obj = getSqlMapClientTemplate().queryForObject("T4241.findByFiltro", bean);
			return (obj != null ? (T4241Bean) obj: null);		
	}
	
	@Override
	public List<Map> buscarGreEmitida(Map parametros) {
		return (ArrayList)getSqlMapClientTemplate().queryForList("T4241.buscarGreEmitida", parametros);
	}

	@Override
	public List<Map> buscarGreRecibida(Map parametros) {
		return (ArrayList)getSqlMapClientTemplate().queryForList("T4241.buscarGreRecibida", parametros);
	}

	@Override
	public List<Map> buscarGreRelacionada(Map parametros) {
		return (ArrayList)getSqlMapClientTemplate().queryForList("T4241.buscarGreRelacionada", parametros);
	}
	
	@Override
	public List<Map> consultarGreRelacionadasPadre(Map parametros) {
	return (ArrayList)getSqlMapClientTemplate().queryForList("T4241.consultarGreRelacionadaPadre", parametros);
	}
	
	@Override
	public List<Map> consultarGreRelacionadasHijo(Map parametros) {
	return (ArrayList)getSqlMapClientTemplate().queryForList("T4241.consultarGreRelacionadaHijo", parametros);
	}
	
	
	@Override
	public List<Map> findByTiposRuc(Map parametros) {
		return (ArrayList<Map>)getSqlMapClientTemplate().queryForList("T4241.findByTiposRuc", parametros);
	}
	
	@Override
	public List<Map> findByTiposRucSerieNumero(Map parametros) {
		return (ArrayList<Map>)getSqlMapClientTemplate().queryForList("T4241.findByTiposRucSerieNumero", parametros);
	}
	
	@Override
	public List<Map> findByPlaca(Map parametros) {
		return (ArrayList<Map>)getSqlMapClientTemplate().queryForList("T4241.findByPlaca", parametros);
	}
	
	@Override
	public List<Map> findGuiaAsociada(Map parametros) {
		return (ArrayList<Map>)getSqlMapClientTemplate().queryForList("T4241.findGuiaAsociada", parametros);
	}
	
	@Override
	public T4241Bean findByFiltroGreBf(T4241Bean bean){		
			Object obj = getSqlMapClientTemplate().queryForObject("T4241.findByFiltroGreBf", bean);
			return (obj != null ? (T4241Bean) obj: null);		
	}

	@Override
	public T4241Bean findByPKAndTicket(String rucEmisor, String numeroSerie,
			Integer numeroComprobante, String tipoComprobante, String ticket) {
		Map<String, Object> params = new HashMap<String, Object>();
        params.put("cod_cpe", tipoComprobante);
        params.put("num_ruc", rucEmisor);
        params.put("num_serie_cpe", numeroSerie);
        params.put("num_cpe", numeroComprobante);
        params.put("num_ticket", ticket);

        Object obj = getSqlMapClientTemplate().queryForObject("T4241.findByPKAndTicket", params);

        return (obj != null ? (T4241Bean) obj : null);
	}

	@Override
	public List<T4241Bean> buscarCPEEmitidoOSE(Map parametros) {
		return (ArrayList)getSqlMapClientTemplate().queryForList("T4241.buscarCPEEmitidoOSE", parametros);
	}
	
}
