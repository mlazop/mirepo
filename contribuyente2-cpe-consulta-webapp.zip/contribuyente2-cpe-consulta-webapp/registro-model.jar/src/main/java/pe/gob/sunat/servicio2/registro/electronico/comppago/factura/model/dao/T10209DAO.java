package pe.gob.sunat.servicio2.registro.electronico.comppago.factura.model.dao;

import pe.gob.sunat.servicio2.registro.electronico.comppago.factura.model.domain.T10209Bean;
import pe.gob.sunat.servicio2.registro.electronico.comppago.factura.model.domain.T4241Bean;
import pe.gob.sunat.servicio2.registro.electronico.comppago.factura.model.domain.T4536Bean;

@SuppressWarnings({"rawtypes"})
public interface T10209DAO {
	public T10209Bean findByFiltro(T10209Bean param);
	
	public T4536Bean findByDataDAE( String nroRUC, String codCpe, String nroSerie, Integer nroCPE );
	
	public T4241Bean findByPK(String nroRUC, String nroSerie, Integer nroCPE, String codCpe);
}
