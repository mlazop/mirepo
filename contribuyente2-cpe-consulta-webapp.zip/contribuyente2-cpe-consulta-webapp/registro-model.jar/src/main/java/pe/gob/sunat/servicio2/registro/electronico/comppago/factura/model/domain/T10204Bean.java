package pe.gob.sunat.servicio2.registro.electronico.comppago.factura.model.domain;

import java.io.Serializable;
import java.math.BigDecimal;

import pe.gob.sunat.framework.spring.util.date.FechaBean;

public class T10204Bean implements Serializable {

    private static final long serialVersionUID = -2363237513123236515L;
	
    private String num_ruc;
    private String cod_cpe;
    private String num_serie_cpe ;
    private Integer num_cpe;
    private String cod_docide_recep;
    private String num_docide_recep;
    private FechaBean fec_emision;
    private BigDecimal mto_importe_total;
    private String ind_estado;
    
	public String getNum_ruc() {
		return num_ruc;
	}
	public void setNum_ruc(String num_ruc) {
		this.num_ruc = num_ruc;
	}
	public String getCod_cpe() {
		return cod_cpe;
	}
	public void setCod_cpe(String cod_cpe) {
		this.cod_cpe = cod_cpe;
	}
	public String getNum_serie_cpe() {
		return num_serie_cpe;
	}
	public void setNum_serie_cpe(String num_serie_cpe) {
		this.num_serie_cpe = num_serie_cpe;
	}
	public Integer getNum_cpe() {
		return num_cpe;
	}
	public void setNum_cpe(Integer num_cpe) {
		this.num_cpe = num_cpe;
	}
	public String getCod_docide_recep() {
		return cod_docide_recep;
	}
	public void setCod_docide_recep(String cod_docide_recep) {
		this.cod_docide_recep = cod_docide_recep;
	}
	public String getNum_docide_recep() {
		return num_docide_recep;
	}
	public void setNum_docide_recep(String num_docide_recep) {
		this.num_docide_recep = num_docide_recep;
	}
	public FechaBean getFec_emision() {
		return fec_emision;
	}
	public void setFec_emision(FechaBean fec_emision) {
		this.fec_emision = fec_emision;
	}
	public BigDecimal getMto_importe_total() {
		return mto_importe_total;
	}
	public void setMto_importe_total(BigDecimal mto_importe_total) {
		this.mto_importe_total = mto_importe_total;
	}
	public String getInd_estado() {
		return ind_estado;
	}
	public void setInd_estado(String ind_estado) {
		this.ind_estado = ind_estado;
	}

}
