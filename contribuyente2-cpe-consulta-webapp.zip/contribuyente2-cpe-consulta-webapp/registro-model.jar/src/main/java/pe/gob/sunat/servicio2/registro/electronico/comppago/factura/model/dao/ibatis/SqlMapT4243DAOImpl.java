package pe.gob.sunat.servicio2.registro.electronico.comppago.factura.model.dao.ibatis;

import java.util.HashMap;
import java.util.Map;

import pe.gob.sunat.contribuyente.cpe.facturagem.model.BillStore;
import pe.gob.sunat.framework.spring.util.dao.SqlMapDAOBase;
import pe.gob.sunat.servicio2.registro.electronico.comppago.factura.model.dao.T4243DAO;
import pe.gob.sunat.servicio2.registro.electronico.comppago.factura.model.domain.T4243Bean;
import pe.gob.sunat.servicio2.registro.electronico.comppago.factura.model.domain.T4536Bean;

@SuppressWarnings("deprecation")
public class SqlMapT4243DAOImpl extends SqlMapDAOBase implements T4243DAO{

	@Override
	public T4243Bean findByRUC_Serie_CPE_ID(T4243Bean bean) {
		if (log.isDebugEnabled()) {log.debug("SqlMapDAOBase findByRUC_Serie_CPE_ID (" + bean.getNum_ruc() + ")");}

		return (T4243Bean) getSqlMapClientTemplate().queryForObject("T4243.findByRUC_Serie_CPE_ID", bean);
	}

	@Override
	public T4243Bean findFileXmlJoinTCabCPETArcXmlByPrimaryKey(String nroRUC, String codCpe, String nroSerie, Integer nroCPE){
		
		T4243Bean bean = new T4243Bean();
		bean.setNum_ruc(nroRUC);
		bean.setCod_cpe(codCpe);
		bean.setNum_serie_cpe(nroSerie);
		bean.setNum_cpe(nroCPE);
		
		Object obj = getSqlMapClientTemplate().queryForObject("T4243.findFileXmlJoinTCabCPETArcXmlByPrimaryKey", bean);
		
		return (obj != null ? (T4243Bean) obj: null);		
	}

	@Override
	public T4243Bean findFileZipJoinTCabCPETRelcompelecTFESTOREByPrimaryKey(String nroRUC, String codCpe, String nroSerie, Integer nroCPE){
		
		T4243Bean bean = new T4243Bean();
		bean.setNum_ruc(nroRUC);
		bean.setCod_cpe(codCpe);
		bean.setNum_serie_cpe(nroSerie);
		bean.setNum_cpe(nroCPE);
		
		Object obj = getSqlMapClientTemplate().queryForObject("T4243.findFileZipJoinTCabCPETRelcompelecTFESTOREByPrimaryKey", bean);
		
		return (obj != null ? (T4243Bean) obj: null);		
	}
	
	@Override
	public T4536Bean findFileZipJoinTCabCPETRelcompelecByPrimaryKey(String nroRUC, String codCpe, String nroSerie, Integer nroCPE){
		
		T4243Bean bean = new T4243Bean();
		bean.setNum_ruc(nroRUC);
		bean.setCod_cpe(codCpe);
		bean.setNum_serie_cpe(nroSerie);
		bean.setNum_cpe(nroCPE);
		
		return (T4536Bean) getSqlMapClientTemplate().queryForObject("T4243.findFileZipJoinTCabCPETRelcompelecByPrimaryKey", bean);
				
	}
	
	@Override
	public void insert(T4243Bean bean) throws Exception {

		
	}

	@Override
	public T4243Bean findFileXmlJoinTCabCPETArcXmlByPrimaryKeyISO88591(String nroRUC, String codCPE, String nroSerie, Integer nroCPE) {

		return null;
	}

	@Override
	public T4243Bean findByRUC_Serie_CPE(T4243Bean bean) {
		if (log.isDebugEnabled()) {log.debug("SqlMapDAOBase findByRUC_Serie_CPE (" + bean.getNum_ruc() + ")");}

		return (T4243Bean) getSqlMapClientTemplate().queryForObject("T4243.findByRUC_Serie_CPE", bean);
	}
	
	@Override
	public Map<String,String> find_ticket_CPE(String nroRUC, String codCPE, String nroSerie, Integer nroCPE) {
		
		T4243Bean bean = new T4243Bean();
		bean.setNum_ruc(nroRUC);
		bean.setCod_cpe(codCPE);
		bean.setNum_serie_cpe(nroSerie);
		bean.setNum_cpe(nroCPE);

		return (Map<String, String>) getSqlMapClientTemplate().queryForObject("T4243.find_ticket_CPE", bean);
	}
	
	
	@Override
	public void delete_ticket_CPE(String num_ticket) {	
		getSqlMapClientTemplate().delete("T4243.delete_ticket_CPE",num_ticket);
	}
		
	
    @Override
    public void insert_ticket_CPE(final BillStore billStore) {
    	log.debug("insert_ticket_CPE en SqlMapT4243DAOImpl");	
    }
    
    @Override
    public void update_ticket_CPE(final BillStore billStore) {
    	log.debug("update_ticket_CPE en SqlMapT4243DAOImpl");	
    }

}
