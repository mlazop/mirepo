package pe.gob.sunat.servicio2.registro.electronico.comppago.factura.model.dao.ibatis;

import pe.gob.sunat.framework.spring.util.dao.SqlMapDAOBase;
import pe.gob.sunat.servicio2.registro.electronico.comppago.factura.model.dao.T6573RetencionSelectDAO;
import pe.gob.sunat.servicio2.registro.electronico.comppago.factura.model.domain.PkComprobante;
import pe.gob.sunat.servicio2.registro.electronico.comppago.factura.model.domain.T6573RetencionBean;

public class SqlMapT6573RetencionDAOImpl extends SqlMapDAOBase implements T6573RetencionSelectDAO {

   
    @Override
    public T6573RetencionBean selectByPrimaryKey(String codCpe, Integer numCpe, String numRuc, String numSerieCpe) {
    	PkComprobante key = new PkComprobante();
        key.setCodCpe(codCpe);
        key.setNumCpe(numCpe);
        key.setNumRuc(numRuc);
        key.setNumSerieCpe(numSerieCpe);
        T6573RetencionBean record = (T6573RetencionBean) getSqlMapClientTemplate().queryForObject("t6573retencion.ibatorgenerated_selectByPrimaryKey", key);
        return record;
    }
    
    
    @Override
	public T6573RetencionBean buscarPorPk(String numeroRuc, String codigoGuia, String numeroSerie, Integer numeroGuia) {
    	
    	PkComprobante pkComprobante = new PkComprobante(numeroRuc, codigoGuia, numeroSerie, numeroGuia);
		
		if (log.isDebugEnabled()) log.debug("t6573retencion.buscarPorPk");
	
		return (T6573RetencionBean) getSqlMapClientTemplate().queryForObject("t6573retencion.buscarPorPk", pkComprobante);
		
	}
    
    
    @Override
	public int countSelectByPrimaryKey(String codCpe, Integer numCpe, String numRuc, String numSerieCpe) {
		PkComprobante key = new PkComprobante();
	    key.setCodCpe(codCpe);
	    key.setNumCpe(numCpe);
	    key.setNumRuc(numRuc);
	    key.setNumSerieCpe(numSerieCpe);
	    return (Integer) getSqlMapClientTemplate().queryForObject("t6573retencion.ibatorgenerated_countSelectByPrimaryKey", key);
	    
	}

	@Override
	public PkComprobante selectByTicket(Long nroTicket) {
		return (PkComprobante) getSqlMapClientTemplate().queryForObject("t6573retencion.getPk",nroTicket);
	}


}
