package pe.gob.sunat.servicio2.registro.electronico.comppago.model.dao;

import java.io.Serializable;

import pe.gob.sunat.servicio2.registro.electronico.comppago.model.domain.T3634Bean;

public interface T3634DAO  extends Serializable {
	public T3634Bean findByFiltro(T3634Bean param) ;
}
