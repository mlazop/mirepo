package pe.gob.sunat.servicio2.registro.electronico.comppago.factura.model.dao.ibatis;


import pe.gob.sunat.framework.spring.util.dao.SqlMapDAOBase;
import pe.gob.sunat.servicio2.registro.electronico.comppago.factura.model.dao.T6460CabGreDAO;
import pe.gob.sunat.servicio2.registro.electronico.comppago.factura.model.domain.PkComprobante;
import pe.gob.sunat.servicio2.registro.electronico.comppago.factura.model.domain.T6460CabGreBean;

public class SqlMapT6460CABGREDAOImpl extends SqlMapDAOBase implements T6460CabGreDAO {
	

	@Override
	public T6460CabGreBean buscarPorPk(String numeroRuc, String codigoGuia, String numeroSerie, Integer numeroGuia) {
		
		if (log.isDebugEnabled()) log.debug("T6460CABGREDaoImpl.buscarPorPk");
		
		PkComprobante pk = new PkComprobante(numeroRuc, codigoGuia, numeroSerie, numeroGuia);
	
		return (T6460CabGreBean) getSqlMapClientTemplate().queryForObject("T6460CabGre.buscarPorPk", pk);
		
	}
	

}
