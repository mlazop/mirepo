package pe.gob.sunat.servicio2.registro.electronico.comppago.factura.model.dao;


import java.util.List;

import pe.gob.sunat.framework.spring.util.date.FechaBean;
import pe.gob.sunat.servicio2.registro.electronico.comppago.factura.model.domain.T4704Bean;


/**
 * tabla    donde  se guardan los  detalles de los resumenes  de las  boletas y sus  NC y ND
 * @author narista
 */     
public interface T4704DAO {   
	public T4704Bean findByFiltro(T4704Bean bean);
	public  abstract boolean registraDetResumen( T4704Bean bean); 
	public  abstract List<T4704Bean> listaDetallesresumenRucfecha(String ruc, FechaBean fecha);
	public  abstract boolean borradoLogicodetresumen(T4704Bean  bean);
	public   abstract  T4704Bean   buscarComprobanteEspecifico (String ruc, String  codcpe, String  seriecpe,  Integer numcpe); 
	
	
}
