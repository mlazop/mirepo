package pe.gob.sunat.servicio2.registro.electronico.comppago.factura.model.dao.ibatis;

import pe.gob.sunat.framework.spring.util.dao.SqlMapDAOBase;
import pe.gob.sunat.servicio2.registro.electronico.comppago.factura.model.dao.T4533DAO;
import pe.gob.sunat.servicio2.registro.electronico.comppago.factura.model.domain.T4533Bean;

@SuppressWarnings({"deprecation"})
public class SqlMapT4533DAOImpl extends SqlMapDAOBase implements T4533DAO {

	@Override
	public T4533Bean getLogPackStatus(String ticket) {
	    return (T4533Bean)getSqlMapClientTemplate().queryForObject("selectLogPackStatus", ticket);
	}

	@Override
	public void updateToPendingByTiket(String numTicket) {
		getSqlMapClientTemplate().update("updateLogPackToPendingByTiket", numTicket);
	}

	@Override
	public void actualizaEstado(T4533Bean pack) {
		getSqlMapClientTemplate().update("updateLogPack", pack);
		
	}
}
