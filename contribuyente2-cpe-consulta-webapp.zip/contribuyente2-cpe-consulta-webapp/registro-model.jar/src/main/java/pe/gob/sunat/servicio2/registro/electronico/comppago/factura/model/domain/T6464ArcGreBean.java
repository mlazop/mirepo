package pe.gob.sunat.servicio2.registro.electronico.comppago.factura.model.domain;

import java.io.Serializable;
import java.util.Date;

/**
 * @author evargasc
 *
 */
public class T6464ArcGreBean implements Serializable {

	
	private static final long serialVersionUID = -6746695697685294240L;
	
	private String indModo;
    private byte[] arcInput;
    private Object numTicket;
    private String desArchivo;
    private String codUsumodif;
    private Date fecModif;

    private String arc_xml;

	public String getIndModo() {
		return indModo;
	}

	public void setIndModo(String indModo) {
		this.indModo = indModo;
	}

	public byte[] getArcInput() {
		return arcInput;
	}

	public void setArcInput(byte[] arcInput) {
		this.arcInput = arcInput;
	}

	public Object getNumTicket() {
		return numTicket;
	}

	public void setNumTicket(Object numTicket) {
		this.numTicket = numTicket;
	}

	public String getDesArchivo() {
		return desArchivo;
	}

	public void setDesArchivo(String desArchivo) {
		this.desArchivo = desArchivo;
	}
	
	public String getCodUsumodif() {
		return codUsumodif;
	}

	public void setCodUsumodif(String codUsumodif) {
		this.codUsumodif = codUsumodif;
	}

	public Date getFecModif() {
		return fecModif;
	}

	public void setFecModif(Date fecModif) {
		this.fecModif = fecModif;
	}
    
	
	public String getArc_xml() {
		return arc_xml;
	}

	public void setArc_xml(String arc_xml) {
		this.arc_xml = arc_xml;
	}
    
	
}
