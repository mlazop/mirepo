package pe.gob.sunat.servicio2.registro.electronico.comppago.factura.model.dao;

import pe.gob.sunat.servicio2.registro.electronico.comppago.factura.model.domain.BillLogCab;


/**
 * @author dloyola
 * @since [PAS20165E210300204] - F2[161526]
 */
public interface LogCabSelectDAO {
   
 
   public BillLogCab obtenerEstado(String numTicket);
   
   public void update(String numTicket);
   
   public void update(BillLogCab data);
   
}
