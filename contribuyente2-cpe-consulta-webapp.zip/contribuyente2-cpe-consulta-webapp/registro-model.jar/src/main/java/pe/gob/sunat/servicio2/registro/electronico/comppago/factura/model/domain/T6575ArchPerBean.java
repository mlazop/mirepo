package pe.gob.sunat.servicio2.registro.electronico.comppago.factura.model.domain;

import java.io.Serializable;
import java.util.Date;

public class T6575ArchPerBean implements Serializable{
	
	private static final long serialVersionUID = -5919333155685543008L;
	
	private Long numTicket;
	private String indModo;
	private byte[] arcArchivo;
	private String nomArchivo;
	private Date fecRegis;
	private String codUsuregis;
	private Date fecModif;
	private String codUsumodif;
	
	private String arc_xml;
	
	public Long getNumTicket() {
		return numTicket;
	}
	public void setNumTicket(Long numTicket) {
		this.numTicket = numTicket;
	}
	public String getIndModo() {
		return indModo;
	}
	public void setIndModo(String indModo) {
		this.indModo = indModo;
	}
	public byte[] getArcArchivo() {
		return arcArchivo;
	}
	public void setArcArchivo(byte[] arcArchivo) {
		this.arcArchivo = arcArchivo;
	}
	public String getNomArchivo() {
		return nomArchivo;
	}
	public void setNomArchivo(String nomArchivo) {
		this.nomArchivo = nomArchivo;
	}
	public Date getFecRegis() {
		return fecRegis;
	}
	public void setFecRegis(Date fecRegis) {
		this.fecRegis = fecRegis;
	}
	public String getCodUsuregis() {
		return codUsuregis;
	}
	public void setCodUsuregis(String codUsuregis) {
		this.codUsuregis = codUsuregis;
	}
	public Date getFecModif() {
		return fecModif;
	}
	public void setFecModif(Date fecModif) {
		this.fecModif = fecModif;
	}
	public String getCodUsumodif() {
		return codUsumodif;
	}
	public void setCodUsumodif(String codUsumodif) {
		this.codUsumodif = codUsumodif;
	}

	public String getArc_xml() {
		return arc_xml;
	}
	public void setArc_xml(String arc_xml) {
		this.arc_xml = arc_xml;
	}
	
}
