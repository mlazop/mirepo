package pe.gob.sunat.servicio2.registro.model.domain;

import java.io.Serializable;

import pe.gob.sunat.framework.spring.util.date.FechaBean;

public class DdpBean implements Serializable {
	private static final long serialVersionUID = -6499447801812809726L;
	
	private String ddp_lllttt;
    private Integer ddp_secuen;
    private String ddp_nombre;
    private String ddp_numruc;
    private String ddp_numreg;
    private String ddp_tpoemp;
    private String ddp_tamano;
    private String ddp_identi;
    private String ddp_ciiu;
    private String ddp_ubigeo;
    private String ddp_nomvia;
    private String ddp_numer1;
    private String ddp_inter1;
    private String ddp_nomzon;
    private String ddp_refer1;
    private String ddp_flag22;
    private String ddp_estado;
    private FechaBean ddp_fecalt;
    private FechaBean ddp_fecbaj;
    private String ddp_tipvia;
    private String ddp_tipzon;
    private String ddp_doble;
    private String ddp_mclase;
    private String ddp_reacti;
    private String ddp_userna;
    private FechaBean ddp_fecact;
    
	public String getDdp_lllttt() {
		return ddp_lllttt;
	}
	public void setDdp_lllttt(String ddpLllttt) {
		ddp_lllttt = ddpLllttt;
	}
	public Integer getDdp_secuen() {
		return ddp_secuen;
	}
	public void setDdp_secuen(Integer ddpSecuen) {
		ddp_secuen = ddpSecuen;
	}
	public String getDdp_nombre() {
		return ddp_nombre;
	}
	public void setDdp_nombre(String ddpNombre) {
		ddp_nombre = ddpNombre;
	}
	public String getDdp_numruc() {
		return ddp_numruc;
	}
	public void setDdp_numruc(String ddpNumruc) {
		ddp_numruc = ddpNumruc;
	}
	public String getDdp_numreg() {
		return ddp_numreg;
	}
	public void setDdp_numreg(String ddpNumreg) {
		ddp_numreg = ddpNumreg;
	}
	public String getDdp_tpoemp() {
		return ddp_tpoemp;
	}
	public void setDdp_tpoemp(String ddpTpoemp) {
		ddp_tpoemp = ddpTpoemp;
	}
	public String getDdp_tamano() {
		return ddp_tamano;
	}
	public void setDdp_tamano(String ddpTamano) {
		ddp_tamano = ddpTamano;
	}
	public String getDdp_identi() {
		return ddp_identi;
	}
	public void setDdp_identi(String ddpIdenti) {
		ddp_identi = ddpIdenti;
	}
	public String getDdp_ciiu() {
		return ddp_ciiu;
	}
	public void setDdp_ciiu(String ddpCiiu) {
		ddp_ciiu = ddpCiiu;
	}
	public String getDdp_ubigeo() {
		return ddp_ubigeo;
	}
	public void setDdp_ubigeo(String ddpUbigeo) {
		ddp_ubigeo = ddpUbigeo;
	}
	public String getDdp_nomvia() {
		return ddp_nomvia;
	}
	public void setDdp_nomvia(String ddpNomvia) {
		ddp_nomvia = ddpNomvia;
	}
	public String getDdp_numer1() {
		return ddp_numer1;
	}
	public void setDdp_numer1(String ddpNumer1) {
		ddp_numer1 = ddpNumer1;
	}
	public String getDdp_inter1() {
		return ddp_inter1;
	}
	public void setDdp_inter1(String ddpInter1) {
		ddp_inter1 = ddpInter1;
	}
	public String getDdp_nomzon() {
		return ddp_nomzon;
	}
	public void setDdp_nomzon(String ddpNomzon) {
		ddp_nomzon = ddpNomzon;
	}
	public String getDdp_refer1() {
		return ddp_refer1;
	}
	public void setDdp_refer1(String ddpRefer1) {
		ddp_refer1 = ddpRefer1;
	}
	public String getDdp_flag22() {
		return ddp_flag22;
	}
	public void setDdp_flag22(String ddpFlag22) {
		ddp_flag22 = ddpFlag22;
	}
	public String getDdp_estado() {
		return ddp_estado;
	}
	public void setDdp_estado(String ddpEstado) {
		ddp_estado = ddpEstado;
	}
	public FechaBean getDdp_fecalt() {
		return ddp_fecalt;
	}
	public void setDdp_fecalt(FechaBean ddpFecalt) {
		ddp_fecalt = ddpFecalt;
	}
	public FechaBean getDdp_fecbaj() {
		return ddp_fecbaj;
	}
	public void setDdp_fecbaj(FechaBean ddpFecbaj) {
		ddp_fecbaj = ddpFecbaj;
	}
	public String getDdp_tipvia() {
		return ddp_tipvia;
	}
	public void setDdp_tipvia(String ddpTipvia) {
		ddp_tipvia = ddpTipvia;
	}
	public String getDdp_tipzon() {
		return ddp_tipzon;
	}
	public void setDdp_tipzon(String ddpTipzon) {
		ddp_tipzon = ddpTipzon;
	}
	public String getDdp_doble() {
		return ddp_doble;
	}
	public void setDdp_doble(String ddpDoble) {
		ddp_doble = ddpDoble;
	}
	public String getDdp_mclase() {
		return ddp_mclase;
	}
	public void setDdp_mclase(String ddpMclase) {
		ddp_mclase = ddpMclase;
	}
	public String getDdp_reacti() {
		return ddp_reacti;
	}
	public void setDdp_reacti(String ddpReacti) {
		ddp_reacti = ddpReacti;
	}
	public String getDdp_userna() {
		return ddp_userna;
	}
	public void setDdp_userna(String ddpUserna) {
		ddp_userna = ddpUserna;
	}
	public FechaBean getDdp_fecact() {
		return ddp_fecact;
	}
	public void setDdp_fecact(FechaBean ddpFecact) {
		ddp_fecact = ddpFecact;
	}

}

