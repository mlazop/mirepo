package pe.gob.sunat.servicio2.registro.model.dao.ibatis;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.sql.DataSource;

import org.springframework.orm.ibatis.SqlMapClientTemplate;

import pe.gob.sunat.framework.spring.util.dao.SqlMapDAOBase;
import pe.gob.sunat.servicio2.registro.model.dao.T1331DAO;
import pe.gob.sunat.servicio2.registro.model.domain.T1331Bean;

@SuppressWarnings({"deprecation","unchecked", "rawtypes"})
public class SqlMapT1331DAOImpl extends SqlMapDAOBase implements T1331DAO {

	private DataSource remoteJNDIDS;
	
	  public DataSource getRemoteJNDIDS()
	  {
	    return this.remoteJNDIDS;
	  }

	  public void setRemoteJNDIDS(DataSource remoteJNDIDS)
	  {
	    this.remoteJNDIDS = remoteJNDIDS;
	  }
	  
	public T1331Bean afiliadoAlSEE(String nroRUC) {
		if (log.isDebugEnabled()) {log.debug("afiliadoAlSEE (" + nroRUC + ")");}
		
		Object obj = getSqlMapClientTemplate().queryForObject("T1331.afiliadoAlSEE", nroRUC);
		
		T1331Bean bean = (obj != null ? (T1331Bean) obj: null);
		return bean;
	}
	
	@Override
	public T1331Bean findByRUC_Ind_proc(T1331Bean t1331) {
		if (log.isDebugEnabled()) {log.debug("sqlMapClient_recauda0jDC (" + t1331.getNumeroDeRUC() + "," + t1331.getIndProceso() + " )");}
		
		Object obj = getSqlMapClientTemplate().queryForObject("T1331.findByRUC_Ind_proc", t1331);
		
		T1331Bean bean = (obj != null ? (T1331Bean) obj: null);
		return bean;
	}
	

	  
	
	public List findAfiliacionesByRUCAfiliado(String numeroDeRUC)
	  {
	    if (this.log.isDebugEnabled()) this.log.debug("SQLMap findAfiliacionesByRUCAfiliado (" + numeroDeRUC + ")");

	    if (this.remoteJNDIDS != null) {
	        setDataSource(this.remoteJNDIDS);
	      }
	    List lst = (ArrayList)getSqlMapClientTemplate().queryForList("T1331.findAfiliacionesByRUCAfiliado", numeroDeRUC);
	    return lst;
	  }

	  public Integer findByRUCIngresoMaximoAfiliacion(String numeroDeRUC)
	  {
	    if (this.log.isDebugEnabled()) this.log.debug("SQLMap findByRUCIngresoMaximoAfiliacion (" + numeroDeRUC + ")");

	    if (this.remoteJNDIDS != null) {
	        setDataSource(this.remoteJNDIDS);
	      }
	    
	    Integer count = (Integer)getSqlMapClientTemplate().queryForObject("T1331.findByRUCIngresoMaximoAfiliacion", numeroDeRUC);
	    return count;
	  }

	  public void insertar(T1331Bean bean)
	  {

	    if (this.remoteJNDIDS != null) {
	        setDataSource(this.remoteJNDIDS);
	      }
	    getSqlMapClientTemplate().insert("T1331.insertar", bean);
	  }

	public T1331Bean afiliacionPorRucProcesoEstado(String numeroRuc, Integer indProceso, String estado) {
		Map m = new HashMap();
		m.put("numeroRuc", numeroRuc);
		m.put("indicadorProceso", indProceso);
		m.put("estado", estado);
		return (T1331Bean) getSqlMapClientTemplate().queryForObject("T1331.findByRUCProcesoEstadoAfiliacion", m);
	}
	
	/**
	 * Busca por el n�mero de ruc, indicador de proceso y estado
	 * @param dataSource
	 * @param params
	 * <br><b>indicadorProceso</b> indicador de proceso
     * <br><b>numeroRuc</b> n�mero de ruc
     * <br><b>estado</b> estado en el padr�n
	 */
	public T1331Bean findByRucProceso(DataSource dataSource, Map params) {

		if(dataSource==null){
			return (T1331Bean)getSqlMapClientTemplate().queryForObject("T1331.findByRUCProcesoEstadoAfiliacion", params);
		}else{
			return (T1331Bean) new SqlMapClientTemplate(dataSource, getSqlMapClient()).queryForObject("T1331.findByRUCProcesoEstadoAfiliacion", params);
		}
	}

	/**
	 * Elimina el registro seg�n el n�mero de ruc e indicador de proceso
	 * @param dataSource
	 * @param params
	 * <br><b>ind_proc</b> indicador de proceso
     * <br><b>ddp_numruc</b> n�mero de ruc
	 */
	public void delete(DataSource dataSource, Map params) {
		if(dataSource==null){
			getSqlMapClientTemplate().delete("T1331.delete", params);
		}else{
			new SqlMapClientTemplate(dataSource, getSqlMapClient()).delete("T1331.delete", params);
		}
	}
	@Override
	public boolean esAgentePercepcion(String numRuc){
		Map<String, String> params = new HashMap<String, String>(); 
		params.put("numRuc", numRuc) ; 
		Object o = getSqlMapClientTemplate().queryForObject("T1331.esAgentePercepcion", params) ;
		return (null==o?false:true); 
	}
	@Override
	public boolean esAfectoISC(String numRuc){
		Map<String, String> params = new HashMap<String, String>(); 
		params.put("numRuc", numRuc) ; 
		Object o = getSqlMapClientTemplate().queryForObject("T1331.countCodISC", params) ;
		return (null==o || Integer.parseInt(o.toString())<=0?false:true);
	}
	
	@Override
	public void actualizarEstado(String numRuc, Integer indProceso, String indEstado){
		Map<String, Object> params = new HashMap<String, Object>(); 
		params.put("numRuc", numRuc) ;
		params.put("indEstado", indEstado) ; 
		params.put("indProc", indProceso) ; 
		if(log.isInfoEnabled())log.info(" MAPA T1331 ==> " + params);
		getSqlMapClientTemplate().update("T1331.actualizarEstado", params); 
	}
	
	public T1331Bean findByRucEstadoProceso(String numRuc, String indEstado, Integer indProc) {
		Map<String, Object> params = new HashMap<String, Object>(); 
		params.put("numRuc", numRuc) ;
		params.put("indEstado", indEstado) ; 
		params.put("indProc", indProc) ; 
		
		Object o = getSqlMapClientTemplate().queryForObject("T1331.findByRucEstadoProceso", params) ;
		return (o==null?null:(T1331Bean)o);
	}

	public Integer findByRucEstadoProceso1(String numRuc, Integer indProceso, String indEstado) {
		Map<String, Object> params = new HashMap<String, Object>(); 
		params.put("numRuc", numRuc) ;
		params.put("indEstado", indEstado) ; 
		params.put("indProceso", indProceso) ; 
		
		Integer count = (Integer)getSqlMapClientTemplate().queryForObject("T1331.findByRucEstadoProceso1", params) ;
		return (count); 
	}

	
	@Override
	public void updateEstado(DataSource dataSource, String numRuc, Integer indProceso, String indEstado) {
		Map<String, Object> params = new HashMap<String, Object>(); 
		params.put("numRuc", numRuc) ;
		params.put("indEstado", indEstado) ; 
		params.put("indProceso", indProceso) ; 
		
		if(dataSource==null){
			getSqlMapClientTemplate().update("T1331.actualizarEstado", params); 
		}else{
			new SqlMapClientTemplate(dataSource, getSqlMapClient()).update("T1331.actualizarEstado", params);
		}
	}
	
	/**
	 * realiza la busqueda por medio de el ruc y el ind_proc
	 * 
	 * @param params
	 * @return
	 */
	@Override
	public Map findByRUC_Ind_proc(Map params){
		Map map = (Map) getSqlMapClientTemplate().queryForObject("T1331.findByRUCIndProc", params);
		return map;
	}
	
	//Ini PAS20175E210300094
	@Override
	public List<T1331Bean> select(T1331Bean t1331) {
		return (List<T1331Bean>) getSqlMapClientTemplate().queryForList("T1331.select", t1331);
	}
	//Fin PAS20175E210300094
	
	@Override
	public List<T1331Bean> selectTME(T1331Bean t1331) {
		return (List<T1331Bean>) getSqlMapClientTemplate().queryForList("T1331.selectTME", t1331);
	}
	
}
