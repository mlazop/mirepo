package pe.gob.sunat.servicio2.registro.electronico.comppago.factura.model.dao;

import pe.gob.sunat.servicio2.registro.electronico.comppago.factura.model.domain.T4536Bean;
import pe.gob.sunat.servicio2.registro.electronico.comppago.factura.model.domain.T6464ArcGreBean;
import pe.gob.sunat.servicio2.registro.electronico.comppago.factura.model.domain.T6575ArchPerBean;
import pe.gob.sunat.servicio2.registro.electronico.comppago.factura.model.domain.T6576ArchRetBean;

public interface T4536DAO {

	public void deleteByTiketAndModo(String numTicket, Integer correlativo,
			String string);

	public T4536Bean getBillStore(String ticket, Integer correlativo, String mode);

	public void inserta(T4536Bean billStore);
	public void inserta(T6575ArchPerBean billStore);
	public void inserta(T6576ArchRetBean billStore);
	public void inserta(T6464ArcGreBean billStore);
	
	public String findNombre( String ticket );
	
	//public T4536Bean findFileZipTFESTOREByPrimaryKey( String ticket, String num_correl );
	public T4536Bean findFileZipTFESTOREByPrimaryKey( T4536Bean t4536bean );
	
	public T4536Bean findFileZipTFESTOREByPrimaryKey( String ticket );
}
