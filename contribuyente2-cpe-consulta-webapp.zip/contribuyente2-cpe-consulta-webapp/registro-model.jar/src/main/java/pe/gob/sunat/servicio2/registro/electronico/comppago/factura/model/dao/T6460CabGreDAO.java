package pe.gob.sunat.servicio2.registro.electronico.comppago.factura.model.dao;

import pe.gob.sunat.servicio2.registro.electronico.comppago.factura.model.domain.T6460CabGreBean;

public interface T6460CabGreDAO {
	
	public T6460CabGreBean buscarPorPk(String numeroRuc, String codigoGuia, String numeroSerie, Integer numeroGuia);
	

}
