package pe.gob.sunat.servicio2.registro.model.dao;

import java.io.Serializable;
import java.sql.Date;
import java.util.List;
import java.util.Map;

import org.springframework.dao.DataAccessException;

import pe.gob.sunat.framework.spring.util.date.FechaBean;
import pe.gob.sunat.servicio2.registro.model.domain.DdsBean;

@SuppressWarnings({"rawtypes"})
public interface DdsDAO  extends Serializable {
	public DdsBean findByRUC(String numeroDeRUC);
	public Map findByRUC_Map(String numRuc);
/**
   * Metodo que busca informacion de un tipo de documento
   * @autor rmanrique
   * @param numDoc String
   * @param tipDoc String
   * @return List
   * @throws DataAccessException
   */
   public List findByTipNumDoc(String numDoc, String tipDoc) ;

	/**
	 * Inserta un nuevo registro de datos del contribuyente.
	 * @param params
	 */
	public void insert(Map params);
	
	public DdsBean findByTipDocNumDoc(Map param);
	
	//EAG 27/10/2011
	public Map buscarPorTipoDocNumDoc(String tipo_doc, String num_doc);
	
	//ECR 19/01/2012
	public List joinWithDdpDocumentoIdentidad(String tipo_doc, String num_doc);
	
	//ECR 09/10/2012
	public Map findByRucJoinT1144ws(String dds_numruc, String estado);
	
	public Date findFechaIniActByRuc(String numruc) throws DataAccessException;
	public String findCondDomicFiscalByRuc(String numruc) throws DataAccessException;

	//MSF 13/08/2015
	public boolean isInicioActividadesOK(String ruc, FechaBean fecha);
}