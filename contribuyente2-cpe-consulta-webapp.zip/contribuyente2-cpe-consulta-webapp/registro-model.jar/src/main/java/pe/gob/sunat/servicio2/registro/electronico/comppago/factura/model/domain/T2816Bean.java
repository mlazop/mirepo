package pe.gob.sunat.servicio2.registro.electronico.comppago.factura.model.domain;

import java.io.Serializable;

public class T2816Bean implements Serializable {
	
	
    /**
	 * 
	 */
	private static final long serialVersionUID = -1L;
	
	private String cod_usuario;
	private String cod_acceso;
	private String cod_tipdocum;
	private String num_docum;
	private String nom_contrib;
	private String num_abono;
	private String cod_formul;
	private String num_orden;
	private String cod_detalle;
	private String ind_estado;
	private String num_anno;
	private String cod_idacc;
	private String cod_cic;
	
	
	
	public String getCod_usuario() {
		return cod_usuario;
	}
	public void setCod_usuario(String cod_usuario) {
		this.cod_usuario = cod_usuario;
	}
	public String getCod_acceso() {
		return cod_acceso;
	}
	public void setCod_acceso(String cod_acceso) {
		this.cod_acceso = cod_acceso;
	}
	public String getCod_tipdocum() {
		return cod_tipdocum;
	}
	public void setCod_tipdocum(String cod_tipdocum) {
		this.cod_tipdocum = cod_tipdocum;
	}
	public String getNum_docum() {
		return num_docum;
	}
	public void setNum_docum(String num_docum) {
		this.num_docum = num_docum;
	}
	public String getNom_contrib() {
		return nom_contrib;
	}
	public void setNom_contrib(String nom_contrib) {
		this.nom_contrib = nom_contrib;
	}
	public String getNum_abono() {
		return num_abono;
	}
	public void setNum_abono(String num_abono) {
		this.num_abono = num_abono;
	}
	public String getCod_formul() {
		return cod_formul;
	}
	public void setCod_formul(String cod_formul) {
		this.cod_formul = cod_formul;
	}
	public String getNum_orden() {
		return num_orden;
	}
	public void setNum_orden(String num_orden) {
		this.num_orden = num_orden;
	}
	public String getCod_detalle() {
		return cod_detalle;
	}
	public void setCod_detalle(String cod_detalle) {
		this.cod_detalle = cod_detalle;
	}
	public String getInd_estado() {
		return ind_estado;
	}
	public void setInd_estado(String ind_estado) {
		this.ind_estado = ind_estado;
	}
	public String getNum_anno() {
		return num_anno;
	}
	public void setNum_anno(String num_anno) {
		this.num_anno = num_anno;
	}
	public String getCod_idacc() {
		return cod_idacc;
	}
	public void setCod_idacc(String cod_idacc) {
		this.cod_idacc = cod_idacc;
	}
	public String getCod_cic() {
		return cod_cic;
	}
	public void setCod_cic(String cod_cic) {
		this.cod_cic = cod_cic;
	}
	

	
}
