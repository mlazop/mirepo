package pe.gob.sunat.servicio2.registro.electronico.comppago.factura.model.dao;

import java.util.Map;

import pe.gob.sunat.contribuyente.cpe.facturagem.model.BillStore;
import pe.gob.sunat.servicio2.registro.electronico.comppago.factura.model.domain.T4243Bean;
import pe.gob.sunat.servicio2.registro.electronico.comppago.factura.model.domain.T4536Bean;

public interface T4243DAO {
	public void insert(T4243Bean bean) throws Exception;
	public T4243Bean findFileXmlJoinTCabCPETArcXmlByPrimaryKey(String nroRUC, String codCPE, String nroSerie, Integer nroCPE);
	public T4243Bean findByRUC_Serie_CPE_ID(T4243Bean bean);
	T4243Bean findFileXmlJoinTCabCPETArcXmlByPrimaryKeyISO88591(String nroRUC, String codCPE, String nroSerie, Integer nroCPE);
	T4243Bean findFileZipJoinTCabCPETRelcompelecTFESTOREByPrimaryKey(String nroRUC, String codCPE, String nroSerie, Integer nroCPE);
	
	public T4536Bean findFileZipJoinTCabCPETRelcompelecByPrimaryKey(String nroRUC, String codCPE, String nroSerie, Integer nroCPE);
	
	public Map<String,String> find_ticket_CPE(String nroRUC, String codCPE, String nroSerie, Integer nroCPE);
	
	public void delete_ticket_CPE(String num_ticket);
	
	public T4243Bean findByRUC_Serie_CPE(T4243Bean bean);
	
	public void insert_ticket_CPE(BillStore billStore);
	
	public void update_ticket_CPE(BillStore billStore);
}
