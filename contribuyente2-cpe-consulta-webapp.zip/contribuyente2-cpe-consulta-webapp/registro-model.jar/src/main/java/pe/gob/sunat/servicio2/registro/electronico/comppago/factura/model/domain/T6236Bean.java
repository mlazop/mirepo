package pe.gob.sunat.servicio2.registro.electronico.comppago.factura.model.domain;

import java.io.Serializable;

import pe.gob.sunat.framework.spring.util.date.FechaBean;

public class T6236Bean implements Serializable {

	private static final long serialVersionUID = 2619684039672872547L;
	
	private Integer num_ticket;
	private String num_ruc;
	private String per_operacion;
	private String nom_archivo;
	private Integer num_cor_envio;
	private Integer ctd_registros;
	private Integer ctd_tam_det;
	private String ind_vigente;
	private Integer ind_est_proceso;
	private FechaBean fec_regis;
	private String cod_usuregis;
	private FechaBean fec_modif;
	private String cod_usumodif;
	
	public Integer getNum_ticket() {
		return num_ticket;
	}
	public void setNum_ticket(Integer num_ticket) {
		this.num_ticket = num_ticket;
	}
	public String getNum_ruc() {
		return num_ruc;
	}
	public void setNum_ruc(String num_ruc) {
		this.num_ruc = num_ruc;
	}
	public String getPer_operacion() {
		return per_operacion;
	}
	public void setPer_operacion(String per_operacion) {
		this.per_operacion = per_operacion;
	}
	public String getNom_archivo() {
		return nom_archivo;
	}
	public void setNom_archivo(String nom_archivo) {
		this.nom_archivo = nom_archivo;
	}
	public Integer getNum_cor_envio() {
		return num_cor_envio;
	}
	public void setNum_cor_envio(Integer num_cor_envio) {
		this.num_cor_envio = num_cor_envio;
	}
	public Integer getCtd_registros() {
		return ctd_registros;
	}
	public void setCtd_registros(Integer ctd_registros) {
		this.ctd_registros = ctd_registros;
	}
	public Integer getCtd_tam_det() {
		return ctd_tam_det;
	}
	public void setCtd_tam_det(Integer ctd_tam_det) {
		this.ctd_tam_det = ctd_tam_det;
	}
	public String getInd_vigente() {
		return ind_vigente;
	}
	public void setInd_vigente(String ind_vigente) {
		this.ind_vigente = ind_vigente;
	}
	public Integer getInd_est_proceso() {
		return ind_est_proceso;
	}
	public void setInd_est_proceso(Integer ind_est_proceso) {
		this.ind_est_proceso = ind_est_proceso;
	}
	public FechaBean getFec_regis() {
		return fec_regis;
	}
	public void setFec_regis(FechaBean fec_regis) {
		this.fec_regis = fec_regis;
	}
	public String getCod_usuregis() {
		return cod_usuregis;
	}
	public void setCod_usuregis(String cod_usuregis) {
		this.cod_usuregis = cod_usuregis;
	}
	public FechaBean getFec_modif() {
		return fec_modif;
	}
	public void setFec_modif(FechaBean fec_modif) {
		this.fec_modif = fec_modif;
	}
	public String getCod_usumodif() {
		return cod_usumodif;
	}
	public void setCod_usumodif(String cod_usumodif) {
		this.cod_usumodif = cod_usumodif;
	}
	
	
	
}
