package pe.gob.sunat.servicio2.registro.model.dao;

import java.util.List;
import java.util.Map;

import javax.sql.DataSource;

import pe.gob.sunat.servicio2.registro.model.domain.T1331Bean;

/**
 * Dao para el control de la tabla t1331rucpad, contribuyentes afiliados
 * a la emision de factura electronica.
 * @author wcavalie
 *
 */
@SuppressWarnings({"rawtypes"})
public interface T1331DAO {
	public T1331Bean afiliadoAlSEE(String nroRUC);	
	public abstract List<T1331Bean> findAfiliacionesByRUCAfiliado(String paramString);
	public abstract Integer findByRUCIngresoMaximoAfiliacion(String paramString);
	public abstract void insertar(T1331Bean paramT1331Bean);	
	
	public T1331Bean afiliacionPorRucProcesoEstado(String  numeroRuc ,Integer  ind_proceso, String estado);
	public abstract void setRemoteJNDIDS(DataSource paramDataSource);
	public T1331Bean findByRUC_Ind_proc(T1331Bean t1331);

	/**
	 * Busca por el n�mero de ruc, indicador de proceso y estado
	 * @param dataSource
	 * @param params
	 * <br><b>indicadorProceso</b> indicador de proceso
     * <br><b>numeroRuc</b> n�mero de ruc
     * <br><b>estado</b> estado en el padr�n
	 */
	public T1331Bean findByRucProceso(DataSource dataSource, Map params);
	
	/**
	 * Elimina el registro seg�n el n�mero de ruc e indicador de proceso
	 * @param dataSource
	 * @param params
	 * <br><b>ind_proc</b> indicador de proceso
     * <br><b>ddp_numruc</b> n�mero de ruc
	 */
	public void delete(DataSource dataSource, Map params);
	/**
	 * Retorna true si es agente de percepci�n false si no lo es. 
	 * @param numRuc
	 * @return
	 */
	public boolean esAgentePercepcion(String numRuc);
	/**
	 * Reorna true si es afecto y false si no lo es. 
	 * @param numRuc
	 * @return
	 */
	public boolean esAfectoISC(String numRuc);
	/**
	 * Permite actualizar el estado.
	 * @param numRuc
	 * @param indProceso
	 * @param indEstado
	 */
	public void actualizarEstado(String numRuc, Integer indProceso, String indEstado);
	
	public T1331Bean findByRucEstadoProceso(String numRuc, String indEstado, Integer indProc) ; 
	
	public void updateEstado(DataSource dataSource, String numRuc, Integer indProceso, String indEstado);

	public Integer findByRucEstadoProceso1(String numeroDeRUC, Integer indProceso, String indEstado);
	
	public Map findByRUC_Ind_proc(Map params);
	
	//Ini PAS20175E210300094
	public List<T1331Bean> select(T1331Bean t1331);
	//Fin PAS20175E210300094

	public List<T1331Bean> selectTME(T1331Bean t1331);
}

