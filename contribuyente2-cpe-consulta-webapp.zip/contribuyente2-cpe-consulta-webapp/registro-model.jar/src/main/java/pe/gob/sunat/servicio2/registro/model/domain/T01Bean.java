package pe.gob.sunat.servicio2.registro.model.domain;

import java.io.Serializable;
import java.sql.Date;

import pe.gob.sunat.framework.spring.util.date.FechaBean;

public class T01Bean implements Serializable {

	private static final long serialVersionUID = -5195861212406267618L;
	
	private String numero;
	private String tipo;
    private String argumento;
    private String funcion;
     private String usuarioActualizacion;
    private FechaBean fechaActualizacion;
    private Date factualiz;
    private String horaActualizacion;
    private String activo;
    
    public T01Bean(){}
    
    public T01Bean(String numero, String tipo, String arg){
        this.setNumero(numero);
        this.setTipo(tipo);
        this.setArgumento(arg);
        this.setFuncion(null);
        this.setFechaActualizacion(null);
        this.setHoraActualizacion(null);
    }
    
	public String getNumero() {
		return numero;
	}
	public void setNumero(String numero) {
		this.numero = numero;
	}
	public String getTipo() {
		return tipo;
	}
	public void setTipo(String tipo) {
		this.tipo = tipo;
	}
	public String getArgumento() {
		return argumento;
	}
	public void setArgumento(String argumento) {
		this.argumento = argumento;
	}
	public String getFuncion() {
		return funcion;
	}
	public void setFuncion(String funcion) {
		this.funcion = funcion;
		if (funcion.length()>=44){
			if (!" ".equals(funcion.substring(43, 44)))
				activo=funcion.substring(43, 44);
		}
	}
	public String getUsuarioActualizacion() {
		return usuarioActualizacion;
	}
	public void setUsuarioActualizacion(String usuarioActualizacion) {
		this.usuarioActualizacion = usuarioActualizacion;
	}
	public FechaBean getFechaActualizacion() {
		return fechaActualizacion;
	}
	public void setFechaActualizacion(FechaBean fechaActualizacion) {
		this.fechaActualizacion = fechaActualizacion;
	}
	public String getHoraActualizacion() {
		return horaActualizacion;
	}
	public void setHoraActualizacion(String horaActualizacion) {
		this.horaActualizacion = horaActualizacion;
	}
	public Date getFecha() {
		return fechaActualizacion.getSQLDate();
	}
	public Date getFactualiz() {
		return factualiz;
	}
	public void setFactualiz(Date factualiz) {
		this.factualiz = factualiz;
		this.fechaActualizacion=new FechaBean(factualiz);
	}

	public String getActivo() {
		return activo;
	}

	public void setActivo(String activo) {
		this.activo = activo;
	}

}
