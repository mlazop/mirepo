package pe.gob.sunat.servicio2.registro.electronico.comppago.factura.model.domain;

import java.io.Serializable;
import java.util.Date;

public class T6571PercepcionBean implements Serializable{


	private static final long serialVersionUID = 6557865518418109530L;
	
	private PkComprobante pkPercepcion;
	private String codTipoDocRecep;
	private String numDocRecep;
	private String descNombreRecep;
	private Date fechaEmision;
	private String codRegimenPer;
	private String descObservacion;
	private Double montoTotalPercibido;
	private Double montoTotalCobrado;
	private String codEstadoCpe;
	private String indProcedencia;
	private String indCompFisico;
	private String descMotivoReversion;
	private Date fechaReversion;
	private String codUsuReversion;
	private Long numTicket;
	private String codCorreoRecep;
	private String codMotivoContin;
	private String numPeriodo;//nuevo
	private double montoBaseCalculo;//nuevo
	private String indReemplazoReversion;//nuevo
	private AuditoriaBean auditoria;
	
	
	public PkComprobante getPkPercepcion() {
		return pkPercepcion;
	}
	public void setPkPercepcion(PkComprobante pkPercepcion) {
		this.pkPercepcion = pkPercepcion;
	}
	public String getCodTipoDocRecep() {
		return codTipoDocRecep;
	}
	public void setCodTipoDocRecep(String codTipoDocRecep) {
		this.codTipoDocRecep = codTipoDocRecep;
	}
	public String getNumDocRecep() {
		return numDocRecep;
	}
	public void setNumDocRecep(String numDocRecep) {
		this.numDocRecep = numDocRecep;
	}
	public String getDescNombreRecep() {
		return descNombreRecep;
	}
	public void setDescNombreRecep(String descNombreRecep) {
		this.descNombreRecep = descNombreRecep;
	}
	public Date getFechaEmision() {
		return fechaEmision;
	}
	public void setFechaEmision(Date fechaEmision) {
		this.fechaEmision = fechaEmision;
	}
	public String getCodRegimenPer() {
		return codRegimenPer;
	}
	public void setCodRegimenPer(String codRegimenPer) {
		this.codRegimenPer = codRegimenPer;
	}
	public String getDescObservacion() {
		return descObservacion;
	}
	public void setDescObservacion(String descObservacion) {
		this.descObservacion = descObservacion;
	}
	public Double getMontoTotalPercibido() {
		return montoTotalPercibido;
	}
	public void setMontoTotalPercibido(Double montoTotalPercibido) {
		this.montoTotalPercibido = montoTotalPercibido;
	}
	public Double getMontoTotalCobrado() {
		return montoTotalCobrado;
	}
	public void setMontoTotalCobrado(Double montoTotalCobrado) {
		this.montoTotalCobrado = montoTotalCobrado;
	}
	public String getCodEstadoCpe() {
		return codEstadoCpe;
	}
	public void setCodEstadoCpe(String codEstadoCpe) {
		this.codEstadoCpe = codEstadoCpe;
	}
	public String getIndProcedencia() {
		return indProcedencia;
	}
	public void setIndProcedencia(String indProcedencia) {
		this.indProcedencia = indProcedencia;
	}
	public String getIndCompFisico() {
		return indCompFisico;
	}
	public void setIndCompFisico(String indCompFisico) {
		this.indCompFisico = indCompFisico;
	}
	public String getDescMotivoReversion() {
		return descMotivoReversion;
	}
	public void setDescMotivoReversion(String descMotivoReversion) {
		this.descMotivoReversion = descMotivoReversion;
	}
	public Date getFechaReversion() {
		return fechaReversion;
	}
	public void setFechaReversion(Date fechaReversion) {
		this.fechaReversion = fechaReversion;
	}
	public String getCodUsuReversion() {
		return codUsuReversion;
	}
	public void setCodUsuReversion(String codUsuReversion) {
		this.codUsuReversion = codUsuReversion;
	}
	public Long getNumTicket() {
		return numTicket;
	}
	public void setNumTicket(Long numTicket) {
		this.numTicket = numTicket;
	}
	public String getCodCorreoRecep() {
		return codCorreoRecep;
	}
	public void setCodCorreoRecep(String codCorreoRecep) {
		this.codCorreoRecep = codCorreoRecep;
	}
	public String getCodMotivoContin() {
		return codMotivoContin;
	}
	public void setCodMotivoContin(String codMotivoContin) {
		this.codMotivoContin = codMotivoContin;
	}
	public String getNumPeriodo() {
		return numPeriodo;
	}
	public void setNumPeriodo(String numPeriodo) {
		this.numPeriodo = numPeriodo;
	}
	public double getMontoBaseCalculo() {
		return montoBaseCalculo;
	}
	public void setMontoBaseCalculo(double montoBaseCalculo) {
		this.montoBaseCalculo = montoBaseCalculo;
	}
	public String getIndReemplazoReversion() {
		return indReemplazoReversion;
	}
	public void setIndReemplazoReversion(String indReemplazoReversion) {
		this.indReemplazoReversion = indReemplazoReversion;
	}
	public AuditoriaBean getAuditoria() {
		return auditoria;
	}
	public void setAuditoria(AuditoriaBean auditoria) {
		this.auditoria = auditoria;
	}
		
	
}
