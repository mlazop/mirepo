package pe.gob.sunat.servicio2.registro.electronico.comppago.model.domain;

import java.io.Serializable;
import java.math.BigDecimal;
import java.sql.Date;

public class T3639Bean implements Serializable {
	private static final long serialVersionUID = -2927669303445471403L;

	private 	String      num_ruc          ;
	private 	String       num_serie        ;
	private 	String       cod_tipcomp      ;
	private 	Integer       num_comprob      ;
	private 	String       cod_docide       ;
	private 	String      num_docide       ;
	private 	String  nom_usuario_serv ;
	private 	String  dir_domfis_emi   ;
	private 	String  des_motivo_rec   ;
	private 	String  des_motivo2_rec  ;
	private 	String  des_observ_rec   ;
	private 	String  des_observ2_rec  ;
	private 	String       ind_actividad    ;
	private 	String       ind_gratuito     ;
	private 	Date     fec_registro     ;
	private 	Date          fec_emision_rec  ;
	private 	String   dir_correoelec   ;
	private 	String       cod_retencion    ;
	private 	BigDecimal mto_bruto        ;
	private 	BigDecimal mto_retencion    ;
	private 	BigDecimal mto_neto         ;
	private 	BigDecimal mto_pag_bruto    ;
	private 	BigDecimal mto_pag_ret      ;
	private 	BigDecimal mto_pag_neto     ;
	private 	BigDecimal mto_nc_bruto     ;
	private 	BigDecimal mto_nc_ret       ;
	private 	BigDecimal mto_nc_neto      ;
	private 	BigDecimal mto_extorno      ;
	private 	String       ind_renta        ;
	private 	String       ind_estado_rec   ;
	private 	String       ind_pago         ;
	private 	String       ind_ncredito     ;
	private 	String       cod_moneda       ;
	private 	Integer      ann_registro     ;
	private 	Integer       num_indice       ;
	private 	Integer       num_archivo      ;
	private 	String   cod_usumodif     ;
	private 	Date     fec_modif        ;
	
	public String getNum_ruc() {
		return num_ruc;
	}
	public void setNum_ruc(String numRuc) {
		num_ruc = numRuc;
	}
	public String getNum_serie() {
		return num_serie;
	}
	public void setNum_serie(String numSerie) {
		num_serie = numSerie;
	}
	public String getCod_tipcomp() {
		return cod_tipcomp;
	}
	public void setCod_tipcomp(String codTipcomp) {
		cod_tipcomp = codTipcomp;
	}
	public Integer getNum_comprob() {
		return num_comprob;
	}
	public void setNum_comprob(Integer numComprob) {
		num_comprob = numComprob;
	}
	public String getCod_docide() {
		return cod_docide;
	}
	public void setCod_docide(String codDocide) {
		cod_docide = codDocide;
	}
	public String getNum_docide() {
		return num_docide;
	}
	public void setNum_docide(String numDocide) {
		num_docide = numDocide;
	}
	public String getNom_usuario_serv() {
		return nom_usuario_serv;
	}
	public void setNom_usuario_serv(String nomUsuarioServ) {
		nom_usuario_serv = nomUsuarioServ;
	}
	public String getDir_domfis_emi() {
		return dir_domfis_emi;
	}
	public void setDir_domfis_emi(String dirDomfisEmi) {
		dir_domfis_emi = dirDomfisEmi;
	}
	public String getDes_motivo_rec() {
		return des_motivo_rec;
	}
	public void setDes_motivo_rec(String desMotivoRec) {
		des_motivo_rec = desMotivoRec;
	}
	public String getDes_motivo2_rec() {
		return des_motivo2_rec;
	}
	public void setDes_motivo2_rec(String desMotivo2Rec) {
		des_motivo2_rec = desMotivo2Rec;
	}
	public String getDes_observ_rec() {
		return des_observ_rec;
	}
	public void setDes_observ_rec(String desObservRec) {
		des_observ_rec = desObservRec;
	}
	public String getDes_observ2_rec() {
		return des_observ2_rec;
	}
	public void setDes_observ2_rec(String desObserv2Rec) {
		des_observ2_rec = desObserv2Rec;
	}
	public String getInd_actividad() {
		return ind_actividad;
	}
	public void setInd_actividad(String indActividad) {
		ind_actividad = indActividad;
	}
	public String getInd_gratuito() {
		return ind_gratuito;
	}
	public void setInd_gratuito(String indGratuito) {
		ind_gratuito = indGratuito;
	}	
	public String getDir_correoelec() {
		return dir_correoelec;
	}
	public void setDir_correoelec(String dirCorreoelec) {
		dir_correoelec = dirCorreoelec;
	}
	public String getCod_retencion() {
		return cod_retencion;
	}
	public void setCod_retencion(String codRetencion) {
		cod_retencion = codRetencion;
	}
	public BigDecimal getMto_bruto() {
		return mto_bruto;
	}
	public void setMto_bruto(BigDecimal mtoBruto) {
		mto_bruto = mtoBruto;
	}
	public BigDecimal getMto_retencion() {
		return mto_retencion;
	}
	public void setMto_retencion(BigDecimal mtoRetencion) {
		mto_retencion = mtoRetencion;
	}
	public BigDecimal getMto_neto() {
		return mto_neto;
	}
	public void setMto_neto(BigDecimal mtoNeto) {
		mto_neto = mtoNeto;
	}
	public BigDecimal getMto_pag_bruto() {
		return mto_pag_bruto;
	}
	public void setMto_pag_bruto(BigDecimal mtoPagBruto) {
		mto_pag_bruto = mtoPagBruto;
	}
	public BigDecimal getMto_pag_ret() {
		return mto_pag_ret;
	}
	public void setMto_pag_ret(BigDecimal mtoPagRet) {
		mto_pag_ret = mtoPagRet;
	}
	public BigDecimal getMto_pag_neto() {
		return mto_pag_neto;
	}
	public void setMto_pag_neto(BigDecimal mtoPagNeto) {
		mto_pag_neto = mtoPagNeto;
	}
	public BigDecimal getMto_nc_bruto() {
		return mto_nc_bruto;
	}
	public void setMto_nc_bruto(BigDecimal mtoNcBruto) {
		mto_nc_bruto = mtoNcBruto;
	}
	public BigDecimal getMto_nc_ret() {
		return mto_nc_ret;
	}
	public void setMto_nc_ret(BigDecimal mtoNcRet) {
		mto_nc_ret = mtoNcRet;
	}
	public BigDecimal getMto_nc_neto() {
		return mto_nc_neto;
	}
	public void setMto_nc_neto(BigDecimal mtoNcNeto) {
		mto_nc_neto = mtoNcNeto;
	}
	public BigDecimal getMto_extorno() {
		return mto_extorno;
	}
	public void setMto_extorno(BigDecimal mtoExtorno) {
		mto_extorno = mtoExtorno;
	}
	public String getInd_renta() {
		return ind_renta;
	}
	public void setInd_renta(String indRenta) {
		ind_renta = indRenta;
	}
	public String getInd_estado_rec() {
		return ind_estado_rec;
	}
	public void setInd_estado_rec(String indEstadoRec) {
		ind_estado_rec = indEstadoRec;
	}
	public String getInd_pago() {
		return ind_pago;
	}
	public void setInd_pago(String indPago) {
		ind_pago = indPago;
	}
	public String getInd_ncredito() {
		return ind_ncredito;
	}
	public void setInd_ncredito(String indNcredito) {
		ind_ncredito = indNcredito;
	}
	public String getCod_moneda() {
		return cod_moneda;
	}
	public void setCod_moneda(String codMoneda) {
		cod_moneda = codMoneda;
	}
	public Integer getAnn_registro() {
		return ann_registro;
	}
	public void setAnn_registro(Integer annRegistro) {
		ann_registro = annRegistro;
	}
	public Integer getNum_indice() {
		return num_indice;
	}
	public void setNum_indice(Integer numIndice) {
		num_indice = numIndice;
	}
	public Integer getNum_archivo() {
		return num_archivo;
	}
	public void setNum_archivo(Integer numArchivo) {
		num_archivo = numArchivo;
	}
	public String getCod_usumodif() {
		return cod_usumodif;
	}
	public void setCod_usumodif(String codUsumodif) {
		cod_usumodif = codUsumodif;
	}
	public static long getSerialversionuid() {
		return serialVersionUID;
	}
	public Date getFec_registro() {
		return fec_registro;
	}
	public void setFec_registro(Date fecRegistro) {
		fec_registro = fecRegistro;
	}
	public Date getFec_emision_rec() {
		return fec_emision_rec;
	}
	public void setFec_emision_rec(Date fecEmisionRec) {
		fec_emision_rec = fecEmisionRec;
	}
	public Date getFec_modif() {
		return fec_modif;
	}
	public void setFec_modif(Date fecModif) {
		fec_modif = fecModif;
	}
	

}
