package pe.gob.sunat.servicio2.registro.electronico.comppago.factura.model.dao.ibatis;

import pe.gob.sunat.framework.spring.util.dao.SqlMapDAOBase;
import pe.gob.sunat.servicio2.registro.electronico.comppago.factura.model.dao.T6576DAO;
import pe.gob.sunat.servicio2.registro.electronico.comppago.factura.model.domain.PkComprobante;
import pe.gob.sunat.servicio2.registro.electronico.comppago.factura.model.domain.T6575ArchPerBean;
import pe.gob.sunat.servicio2.registro.electronico.comppago.factura.model.domain.T6576ArchRetBean;

public class SqlMapT6576DAOImpl extends SqlMapDAOBase implements T6576DAO {

   
    public T6576ArchRetBean selectByPrimaryKey(String indModo, Object numTicket) {
        T6576ArchRetBean key = new T6576ArchRetBean();
        key.setIndModo(indModo);
        key.setNumTicket(numTicket);
        T6576ArchRetBean record = (T6576ArchRetBean) getSqlMapClientTemplate().queryForObject("t6576.ibatorgenerated_selectByPrimaryKey", key);
        return record;
    }


	@Override
	public T6576ArchRetBean selectByDocument(Long numTicket) {

		T6576ArchRetBean key = new T6576ArchRetBean();
        key.setIndModo("1");
        key.setNumTicket(numTicket);
        
        T6576ArchRetBean record = (T6576ArchRetBean) getSqlMapClientTemplate().queryForObject("t6576.selectByDocument", key);
        return record;
		
	}


}