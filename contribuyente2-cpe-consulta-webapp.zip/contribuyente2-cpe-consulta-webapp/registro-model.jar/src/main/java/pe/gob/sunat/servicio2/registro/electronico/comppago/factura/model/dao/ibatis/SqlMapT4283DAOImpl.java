package pe.gob.sunat.servicio2.registro.electronico.comppago.factura.model.dao.ibatis;

import java.util.ArrayList;
import java.util.List;

import pe.gob.sunat.framework.spring.util.dao.SqlMapDAOBase;
import pe.gob.sunat.servicio2.registro.electronico.comppago.factura.model.dao.T4283DAO;
import pe.gob.sunat.servicio2.registro.electronico.comppago.factura.model.domain.T4283Bean;

@SuppressWarnings({"deprecation","unchecked"})
public class SqlMapT4283DAOImpl extends SqlMapDAOBase implements T4283DAO{

	@Override
	public int insert(T4283Bean bean) {
		if (log.isDebugEnabled()) {log.debug("insert (" + bean + ")");}
		getSqlMapClientTemplate().insert("T4283.insert", bean);
		return 0;
	}
	
	public T4283Bean findRubroCabecera_ByRUC_codCPE_Serie_CPE_Rubro(T4283Bean bean) {
		if (log.isDebugEnabled()) {
			log.debug("findRubroCabecera_ByRUC_codCPE_Serie_CPE_Rubro (" + bean.toString() + ")");
		}
		
		Object obj = getSqlMapClientTemplate().queryForObject("T4283.findRubroCabecera_ByRUC_codCPE_Serie_CPE_Rubro", bean);
		return (obj != null ? (T4283Bean) obj: null);
	}


	public List <T4283Bean> findRubroDetalle_ByRUC_codCPE_Serie_CPE_rubro(T4283Bean bean) {
		if (log.isDebugEnabled()) {log.debug("findRubroDetalle_ByRUC_codCPE_Serie_CPE_rubro (" + bean + ")");}
		
		return (ArrayList <T4283Bean>)  getSqlMapClientTemplate().queryForList("T4283.findRubroDetalle_ByRUC_codCPE_Serie_CPE_rubro", bean);
	}

	public T4283Bean findRubro_ByRUC_codCPE_Serie_CPE_rubro_numFila_indcabdet(T4283Bean bean) {
		if (log.isDebugEnabled()) {log.debug("findRubro_ByRUC_codCPE_Serie_CPE_rubro_numFila_indcabdet (" + bean + ")");}
		Object obj = getSqlMapClientTemplate().queryForObject("T4283.findRubro_ByRUC_codCPE_Serie_CPE_rubro_numFila_indcabdet", bean);
		return (obj != null ? (T4283Bean) obj: null);
	}
	
	public Integer findMaxFila_ByRUC_CPE_Indcabdet(T4283Bean bean) {
		if (log.isDebugEnabled()) {log.debug("findMaxFila_ByRUC_CPE_Indcabdet (" + bean + ")");}
		 
		return (Integer) getSqlMapClientTemplate().queryForObject("T4283.findMaxFila_ByRUC_CPE_Indcabdet", bean);
	}
	
	public List<T4283Bean> findRubros_ByRUC_codCPE_Serie_CPE_numFila_indcabdet(T4283Bean bean) {
		if (log.isDebugEnabled()) {log.debug("findRubros_ByRUC_codCPE_Serie_CPE_numFila_indcabdet (" + bean + ")");}
		return getSqlMapClientTemplate().queryForList("T4283.findRubros_ByRUC_codCPE_Serie_CPE_numFila_indcabdet", bean);
	}
	
	@Override
	public void deleteByRUC_codCPE_Serie_CPE_indcabdet(T4283Bean bean) {
		if (log.isDebugEnabled()) {log.debug("deleteByRUC_codCPE_Serie_CPE_indcabdet (" +bean.getNum_ruc() + ")");}
		getSqlMapClientTemplate().delete("T4283.deleteByRUC_codCPE_Serie_CPE_indcabdet",bean);
		return ;
	}
 
	@Override
	public void deleteByRUC_codCPE_Serie_CPE_indcabdet_rubro(T4283Bean bean) {
		if (log.isDebugEnabled()) {log.debug("deleteByRUC_codCPE_Serie_CPE_indcabdet_rubro (" +bean.getNum_ruc() + ")");}
		getSqlMapClientTemplate().delete("T4283.deleteByRUC_codCPE_Serie_CPE_indcabdet_rubro",bean);
		return ;
	}
}
