package pe.gob.sunat.servicio2.registro.electronico.comppago.model.dao.ibatis;

import pe.gob.sunat.framework.spring.util.dao.SqlMapDAOBase;
import pe.gob.sunat.servicio2.registro.electronico.comppago.model.dao.T3634DAO;
import pe.gob.sunat.servicio2.registro.electronico.comppago.model.domain.T3634Bean;

@SuppressWarnings({"deprecation"})
public class SqlMapT3634DAOImpl extends SqlMapDAOBase implements T3634DAO {

	private static final long serialVersionUID = -7455295421475399522L;

	@Override
	public T3634Bean findByFiltro(T3634Bean bean){		
		Object obj = getSqlMapClientTemplate().queryForObject("T3634.findByFiltro", bean);
		return (obj != null ? (T3634Bean) obj: null);	
	}

}
