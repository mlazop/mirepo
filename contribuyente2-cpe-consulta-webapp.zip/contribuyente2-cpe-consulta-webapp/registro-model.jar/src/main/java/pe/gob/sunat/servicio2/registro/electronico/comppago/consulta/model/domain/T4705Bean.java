package pe.gob.sunat.servicio2.registro.electronico.comppago.consulta.model.domain;

import java.util.Date;

public class T4705Bean implements java.io.Serializable {
    private static final long serialVersionUID = 1L;
    
    private String num_ruc;
    private String cod_cpe;
    private String num_serie_cpe;
    private Integer num_desde;
    private Integer num_hasta;
    private Integer num_correlativo;
    private String cod_usumodif;
    private Date fec_modif;

    public T4705Bean() {
        super();
    }

    public T4705Bean(String numRuc, String codCpe, String numSerieCpe,
            Integer numDesde, Integer numHasta, Integer numCorrelativo,
            String codUsumodif, Date fecModif) {
        super();
        num_ruc = numRuc;
        cod_cpe = codCpe;
        num_serie_cpe = numSerieCpe;
        num_desde = numDesde;
        num_hasta = numHasta;
        num_correlativo = numCorrelativo;
        cod_usumodif = codUsumodif;
        fec_modif = fecModif;
        
    }  

    public String getNum_ruc() {
        return num_ruc;
    }

    public void setNum_ruc(String numRuc) {
        num_ruc = numRuc;
    }

    public String getCod_cpe() {
        return cod_cpe;
    }

    public void setCod_cpe(String codCpe) {
        cod_cpe = codCpe;
    }

    public String getNum_serie_cpe() {
        return num_serie_cpe;
    }

    public void setNum_serie_cpe(String numSerieCpe) {
        num_serie_cpe = numSerieCpe;
    }

    public Integer getNum_desde() {
        return num_desde;
    }

    public void setNum_desde(Integer numDesde) {
        num_desde = numDesde;
    }

    public Integer getNum_hasta() {
        return num_hasta;
    }

    public void setNum_hasta(Integer numHasta) {
        num_hasta = numHasta;
    }

    public Integer getNum_correlativo() {
        return num_correlativo;
    }

    public void setNum_correlativo(Integer numCorrelativo) {
        this.num_correlativo = numCorrelativo;
    }

    public String getCod_usumodif() {
        return cod_usumodif;
    }

    public void setCod_usumodif(String codUsumodif) {
        cod_usumodif = codUsumodif;
    }

    public Date getFec_modif() {
        return fec_modif;
    }

    public void setFec_modif(Date fecModif) {
        fec_modif = fecModif;
    }

   
}

