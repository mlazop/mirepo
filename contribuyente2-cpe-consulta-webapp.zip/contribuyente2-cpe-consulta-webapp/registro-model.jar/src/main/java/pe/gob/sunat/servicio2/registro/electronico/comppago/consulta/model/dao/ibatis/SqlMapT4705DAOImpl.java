package pe.gob.sunat.servicio2.registro.electronico.comppago.consulta.model.dao.ibatis;


import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import org.springframework.orm.ibatis.support.SqlMapClientDaoSupport;

import pe.gob.sunat.servicio2.registro.electronico.comppago.consulta.model.domain.T4705Bean;
import pe.gob.sunat.servicio2.registro.electronico.comppago.consulta.model.dao.T4705DAOSelect;
import pe.gob.sunat.framework.spring.util.dao.SqlMapDAOBase;


@SuppressWarnings({ "unchecked", "deprecation", "rawtypes" })
public class SqlMapT4705DAOImpl extends SqlMapDAOBase implements T4705DAOSelect {
	
	private static final Log log = LogFactory.getLog(SqlMapT4705DAOImpl.class);

    @Override
    public List<T4705Bean> buscarComprobanteEnRangos(String ruc, String codcpe, String seriecpe) {
    	log.debug("entro a buscarComprobanteEnRangos");
    	List<T4705Bean> lista = new ArrayList<T4705Bean>();
        Map<String, Object> m = new HashMap<String, Object>();
        m.put("ruc", ruc);
        m.put("codcpe", codcpe);
        m.put("seriecpe", seriecpe);
        lista = getSqlMapClientTemplate().queryForList("rangosGem.findByPKRangos", m);
        log.debug(" se encontraron : " + lista.size() + " elementos");
        return lista;
    }

}
