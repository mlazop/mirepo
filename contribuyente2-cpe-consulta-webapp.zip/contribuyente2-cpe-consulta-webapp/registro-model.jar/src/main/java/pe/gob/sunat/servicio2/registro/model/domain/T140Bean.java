package pe.gob.sunat.servicio2.registro.model.domain;

import java.io.Serializable;

import pe.gob.sunat.framework.spring.util.date.FechaBean;

public class T140Bean implements Serializable{

	private static final long serialVersionUID = -5399026510369994174L;
	private String t140_numreg;
	private String t140_numruc;
	private String t140_motbaj;	
	private Integer t140_ordaut;
	private FechaBean t140_fecocu;
	private String t140_estado;
	private Integer t140_indice;
	private String t140_formul;
	private Integer t140_orden;
	private String t140_userna;
	private FechaBean t140_fecact;
	public String getT140_numreg() {
		return t140_numreg;
	}
	public void setT140_numreg(String t140Numreg) {
		t140_numreg = t140Numreg;
	}
	public String getT140_numruc() {
		return t140_numruc;
	}
	public void setT140_numruc(String t140Numruc) {
		t140_numruc = t140Numruc;
	}
	public String getT140_motbaj() {
		return t140_motbaj;
	}
	public void setT140_motbaj(String t140Motbaj) {
		t140_motbaj = t140Motbaj;
	}
	public Integer getT140_ordaut() {
		return t140_ordaut;
	}
	public void setT140_ordaut(Integer t140Ordaut) {
		t140_ordaut = t140Ordaut;
	}
	public FechaBean getT140_fecocu() {
		return t140_fecocu;
	}
	public void setT140_fecocu(FechaBean t140Fecocu) {
		t140_fecocu = t140Fecocu;
	}
	public String getT140_estado() {
		return t140_estado;
	}
	public void setT140_estado(String t140Estado) {
		t140_estado = t140Estado;
	}
	public Integer getT140_indice() {
		return t140_indice;
	}
	public void setT140_indice(Integer t140Indice) {
		t140_indice = t140Indice;
	}
	public String getT140_formul() {
		return t140_formul;
	}
	public void setT140_formul(String t140Formul) {
		t140_formul = t140Formul;
	}
	public Integer getT140_orden() {
		return t140_orden;
	}
	public void setT140_orden(Integer t140Orden) {
		t140_orden = t140Orden;
	}
	public String getT140_userna() {
		return t140_userna;
	}
	public void setT140_userna(String t140Userna) {
		t140_userna = t140Userna;
	}
	public FechaBean getT140_fecact() {
		return t140_fecact;
	}
	public void setT140_fecact(FechaBean t140Fecact) {
		t140_fecact = t140Fecact;
	}
	
}
