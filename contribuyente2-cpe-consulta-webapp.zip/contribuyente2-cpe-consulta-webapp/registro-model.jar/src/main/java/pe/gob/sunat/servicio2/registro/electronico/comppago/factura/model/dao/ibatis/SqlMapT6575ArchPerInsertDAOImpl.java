package pe.gob.sunat.servicio2.registro.electronico.comppago.factura.model.dao.ibatis;

import java.sql.PreparedStatement;
import java.sql.SQLException;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.dao.DataAccessException;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.support.AbstractLobCreatingPreparedStatementCallback;
import org.springframework.jdbc.support.lob.LobCreator;
import org.springframework.jdbc.support.lob.LobHandler;

import pe.gob.sunat.framework.spring.util.dao.SqlMapDAOBase;
import pe.gob.sunat.servicio2.registro.electronico.comppago.factura.model.dao.T6575ArchPerInsertDAO;
import pe.gob.sunat.servicio2.registro.electronico.comppago.factura.model.domain.T6575ArchPerBean;

public class SqlMapT6575ArchPerInsertDAOImpl extends SqlMapDAOBase implements T6575ArchPerInsertDAO {
	
	protected final Log log = LogFactory.getLog(getClass());
    private JdbcTemplate jdbcTemplate;
    private LobHandler lobHandler;
	
	private final String INSERT_SENTENCE = "INSERT INTO T6575ARCHPER (ind_modo, num_ticket, nom_archivo, cod_usuregis, fec_regis, cod_usumodif, fec_modif, arc_archivo)"
		    + "  VALUES (?,?,?,?,?,?,?,?)";
	
	public void setLobHandler(LobHandler lobHandler) {
		this.lobHandler = lobHandler;
	}
	
	@Override
	public void insertDocument(final T6575ArchPerBean data) {
		
		log.debug("SqlMapT6575ArchPerInsertDAOImpl.insertDocument - data" + data);
		log.debug("SqlMapT6575ArchPerInsertDAOImpl.insertDocument - lobHandler" + lobHandler);
		log.debug("SqlMapT6575ArchPerInsertDAOImpl.insertDocument - jdbcTemplate" + jdbcTemplate);
		
		jdbcTemplate.execute(this.INSERT_SENTENCE, new AbstractLobCreatingPreparedStatementCallback(lobHandler) {
		    protected void setValues(PreparedStatement ps, LobCreator lobCreator) throws SQLException,
			    DataAccessException {

		    	log.debug("SqlMapT6575ArchPerInsertDAOImpl.insertDocument - ps" + ps);
		    	log.debug("SqlMapT6575ArchPerInsertDAOImpl.insertDocument - lobCreator" + lobCreator);
		    	ps.setString(1, data.getIndModo());
		    	ps.setString(2, data.getNumTicket().toString());
		    	ps.setString(3, data.getNomArchivo());
		    	ps.setString(4, data.getCodUsuregis());			
		    	ps.setDate(5, new java.sql.Date((data.getFecRegis().getTime())));
		    	ps.setString(6, data.getCodUsumodif());
		    	ps.setDate(7, new java.sql.Date((data.getFecModif().getTime())));
		    	lobCreator.setBlobAsBytes(ps, 8, data.getArcArchivo());
		    }
		});
		
		
	}
}