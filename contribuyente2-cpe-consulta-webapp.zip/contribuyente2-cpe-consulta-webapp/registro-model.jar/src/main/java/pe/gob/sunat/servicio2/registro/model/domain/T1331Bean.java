package pe.gob.sunat.servicio2.registro.model.domain;

import java.io.Serializable;

import pe.gob.sunat.framework.spring.util.date.FechaBean;

public class T1331Bean implements Serializable {
	private static final long serialVersionUID = -7776113717831848230L;

	public String getNumeroDeRUC() {
		return numeroDeRUC;
	}
	public void setNumeroDeRUC(String numeroDeRUC) {
		this.numeroDeRUC = numeroDeRUC;
	}
	public FechaBean getFechaDeAlta() {
		return fechaDeAlta;
	}
	public void setFechaDeAlta(FechaBean fechaDeAlta) {
		this.fechaDeAlta = fechaDeAlta;
	}
	public FechaBean getFechaIniVig() {
		return fechaIniVig;
	}
	public void setFechaIniVig(FechaBean fechaIniVig) {
		this.fechaIniVig = fechaIniVig;
	}
	public FechaBean getFechaFinVig() {
		return fechaFinVig;
	}
	public void setFechaFinVig(FechaBean fechaFinVig) {
		this.fechaFinVig = fechaFinVig;
	}
	public String getTipoDoc() {
		return tipoDoc;
	}
	public void setTipoDoc(String tipoDoc) {
		this.tipoDoc = tipoDoc;
	}
	public String getNumeroDoc() {
		return numeroDoc;
	}
	public void setNumeroDoc(String numeroDoc) {
		this.numeroDoc = numeroDoc;
	}
	public String getIndEstado() {
		return indEstado;
	}
	public void setIndEstado(String indEstado) {
		this.indEstado = indEstado;
	}
	public Integer getIndProceso() {
		return indProceso;
	}
	public void setIndProceso(Integer indProceso) {
		this.indProceso = indProceso;
	}
	public String getTipInscrip() {
		return tipInscrip;
	}
	public void setTipInscrip(String tipInscrip) {
		this.tipInscrip = tipInscrip;
	}
	public String getCodRegistro() {
		return codRegistro;
	}
	public void setCodRegistro(String codRegistro) {
		this.codRegistro = codRegistro;
	}
	public String getNumProceso() {
		return numProceso;
	}
	public void setNumProceso(String numProceso) {
		this.numProceso = numProceso;
	}
	public String getIndParidad() {
		return indParidad;
	}
	public void setIndParidad(String indParidad) {
		this.indParidad = indParidad;
	}
	public String getCodUsuario() {
		return codUsuario;
	}
	public void setCodUsuario(String codUsuario) {
		this.codUsuario = codUsuario;
	}
	public FechaBean getFecAct() {
		return fecAct;
	}
	public void setFecAct(FechaBean fecAct) {
		this.fecAct = fecAct;
	}
	private String numeroDeRUC;
	private FechaBean fechaDeAlta;
	private FechaBean fechaIniVig;
	private FechaBean fechaFinVig;
	private String tipoDoc;
	private String numeroDoc;
	private String indEstado;
	private Integer indProceso;
	private String tipInscrip;
	private String codRegistro;
	private String numProceso;
	private String indParidad;
	private String codUsuario;
	private FechaBean fecAct;



}
