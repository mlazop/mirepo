package pe.gob.sunat.servicio2.registro.electronico.comppago.factura.model.dao.ibatis;



import java.util.ArrayList;
import java.util.List;

import pe.gob.sunat.framework.spring.util.dao.SqlMapDAOBase;
import pe.gob.sunat.servicio2.registro.electronico.comppago.factura.model.dao.T6468DatGreBajaDAO;
import pe.gob.sunat.servicio2.registro.electronico.comppago.factura.model.domain.PkComprobante;
import pe.gob.sunat.servicio2.registro.electronico.comppago.factura.model.domain.T6468DatGreBajaBean;

/**
 * @author evargasc
 *
 */
public class SqlMapT6468DatGreBajaDAOImpl extends SqlMapDAOBase implements T6468DatGreBajaDAO {

	@Override
	public List<T6468DatGreBajaBean> buscarPk(String numeroRuc, String codigoGuia, String numeroSerie, Integer numeroGuia) {
		PkComprobante key = new PkComprobante();
		key.setNumRuc(numeroRuc);
		key.setCodCpe(codigoGuia);
		key.setNumSerieCpe(numeroSerie);
		key.setNumCpe(numeroGuia);
		List <T6468DatGreBajaBean> lst = (ArrayList <T6468DatGreBajaBean>) getSqlMapClientTemplate().queryForList("t6468grebajaproc.buscarPk", key);
		return lst;
	}

	@Override
	public void insert(T6468DatGreBajaBean record) {
	        getSqlMapClientTemplate().insert("t6468grebajaproc.insert", record);
	    }

	@Override
	public void delete(String numeroRuc, String codigoGuia, String numeroSerie, Integer numeroGuia) {
		PkComprobante key = new PkComprobante();
		key.setNumRuc(numeroRuc);
		key.setCodCpe(codigoGuia);
		key.setNumSerieCpe(numeroSerie);
		key.setNumCpe(numeroGuia);
		int rows = getSqlMapClientTemplate().delete("t6468grebajaproc.delete", key);
		
	}

	
}
