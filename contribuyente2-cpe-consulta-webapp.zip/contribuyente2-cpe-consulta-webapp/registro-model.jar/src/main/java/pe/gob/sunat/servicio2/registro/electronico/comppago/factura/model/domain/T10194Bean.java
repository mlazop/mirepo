package pe.gob.sunat.servicio2.registro.electronico.comppago.factura.model.domain;

import java.io.Serializable;
import java.math.BigDecimal;
import pe.gob.sunat.framework.spring.util.date.FechaBean;

public class T10194Bean implements Serializable {

    private static final long serialVersionUID = -2363237513123236515L;
	
    private String num_ruc;
    private String cod_cpe;
    private String num_serie_cpe ;
    private Integer num_cpe;
    private String cod_moneda;
    private BigDecimal mto_subtotal_grava;
    private BigDecimal mto_subtotal_inafe;
    private BigDecimal mto_subtotal_exone;
    private BigDecimal mto_subtotal;
    private BigDecimal mto_igv;
    private BigDecimal mto_otros_cargos;
    private BigDecimal mto_importe_total;
    private String des_importe_total;
    private String des_dir_remate;
    private String cod_ubigeo;
    private FechaBean fec_emision;
    private String ind_baja;
    private String des_motivo;
    private String fec_baja;
    private String cod_usu_modif;
    private FechaBean fec_modif;
    private String cod_usu_regis;
    private FechaBean fec_usu_regis;
    private String cod_docide_persona;
    private String num_docide_persona;
    
    public String getNum_ruc() {
        return num_ruc;
    }

    public void setNum_ruc(String num_ruc) {
        this.num_ruc = num_ruc;
    }

    public String getCod_cpe() {
        return cod_cpe;
    }

    public void setCod_cpe(String cod_cpe) {
        this.cod_cpe = cod_cpe;
    }

    public String getNum_serie_cpe() {
        return num_serie_cpe;
    }

    public void setNum_serie_cpe(String num_serie_cpe) {
        this.num_serie_cpe = num_serie_cpe;
    }

    public Integer getNum_cpe() {
        return num_cpe;
    }

    public void setNum_cpe(Integer num_cpe) {
        this.num_cpe = num_cpe;
    }

    public String getCod_moneda() {
        return cod_moneda;
    }

    public void setCod_moneda(String cod_moneda) {
        this.cod_moneda = cod_moneda;
    }

    public BigDecimal getMto_subtotal_grava() {
        return mto_subtotal_grava;
    }

    public void setMto_subtotal_grava(BigDecimal mto_subtotal_grava) {
        this.mto_subtotal_grava = mto_subtotal_grava;
    }

    public BigDecimal getMto_subtotal_inafe() {
        return mto_subtotal_inafe;
    }

    public void setMto_subtotal_inafe(BigDecimal mto_subtotal_inafe) {
        this.mto_subtotal_inafe = mto_subtotal_inafe;
    }

    public BigDecimal getMto_subtotal_exone() {
        return mto_subtotal_exone;
    }

    public void setMto_subtotal_exone(BigDecimal mto_subtotal_exone) {
        this.mto_subtotal_exone = mto_subtotal_exone;
    }

    public BigDecimal getMto_subtotal() {
        return mto_subtotal;
    }

    public void setMto_subtotal(BigDecimal mto_subtotal) {
        this.mto_subtotal = mto_subtotal;
    }

    public BigDecimal getMto_igv() {
        return mto_igv;
    }

    public void setMto_igv(BigDecimal mto_igv) {
        this.mto_igv = mto_igv;
    }

    public BigDecimal getMto_otros_cargos() {
        return mto_otros_cargos;
    }

    public void setMto_otros_cargos(BigDecimal mto_otros_cargos) {
        this.mto_otros_cargos = mto_otros_cargos;
    }

    public BigDecimal getMto_importe_total() {
        return mto_importe_total;
    }

    public void setMto_importe_total(BigDecimal mto_importe_total) {
        this.mto_importe_total = mto_importe_total;
    }

    public String getDes_importe_total() {
        return des_importe_total;
    }

    public void setDes_importe_total(String des_importe_total) {
        this.des_importe_total = des_importe_total;
    }

    public String getDes_dir_remate() {
        return des_dir_remate;
    }

    public void setDes_dir_remate(String des_dir_remate) {
        this.des_dir_remate = des_dir_remate;
    }

    public String getCod_ubigeo() {
        return cod_ubigeo;
    }

    public void setCod_ubigeo(String cod_ubigeo) {
        this.cod_ubigeo = cod_ubigeo;
    }

    public FechaBean getFec_emision() {
        return fec_emision;
    }

    public void setFec_emision(FechaBean fec_emision) {
        this.fec_emision = fec_emision;
    }

    public String getInd_baja() {
        return ind_baja;
    }

    public void setInd_baja(String ind_baja) {
        this.ind_baja = ind_baja;
    }

    public String getDes_motivo() {
        return des_motivo;
    }

    public void setDes_motivo(String des_motivo) {
        this.des_motivo = des_motivo;
    }

    public String getFec_baja() {
        return fec_baja;
    }

    public void setFec_baja(String fec_baja) {
        this.fec_baja = fec_baja;
    }

    public String getCod_usu_modif() {
        return cod_usu_modif;
    }

    public void setCod_usu_modif(String cod_usu_modif) {
        this.cod_usu_modif = cod_usu_modif;
    }

    public FechaBean getFec_modif() {
        return fec_modif;
    }

    public void setFec_modif(FechaBean fec_modif) {
        this.fec_modif = fec_modif;
    }

    public String getCod_usu_regis() {
        return cod_usu_regis;
    }

    public void setCod_usu_regis(String cod_usu_regis) {
        this.cod_usu_regis = cod_usu_regis;
    }

    public FechaBean getFec_usu_regis() {
        return fec_usu_regis;
    }

    public void setFec_usu_regis(FechaBean fec_usu_regis) {
        this.fec_usu_regis = fec_usu_regis;
    }
    
    public String getCod_docide_persona() {
        return cod_docide_persona;
    }

    public void setCod_docide_persona(String cod_docide_persona) {
        this.cod_docide_persona = cod_docide_persona;
    }

    public String getNum_docide_persona() {
        return num_docide_persona;
    }

    public void setNum_docide_persona(String num_docide_persona) {
        this.num_docide_persona = num_docide_persona;
    }

}
