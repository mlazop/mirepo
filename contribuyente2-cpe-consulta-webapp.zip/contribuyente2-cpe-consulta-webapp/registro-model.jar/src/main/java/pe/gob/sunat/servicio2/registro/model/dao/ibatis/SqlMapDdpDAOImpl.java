package pe.gob.sunat.servicio2.registro.model.dao.ibatis;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.sql.DataSource;

import org.springframework.dao.DataAccessException;
import org.springframework.orm.ibatis.SqlMapClientTemplate;

import pe.gob.sunat.framework.spring.util.cache2.bean.ParamBean;
import pe.gob.sunat.framework.spring.util.cache2.dao.ParamDAO;
import pe.gob.sunat.framework.spring.util.dao.SqlMapDAOBase;
import pe.gob.sunat.servicio2.registro.model.dao.DdpDAO;
import pe.gob.sunat.servicio2.registro.model.domain.DdpBean;

@SuppressWarnings({"unchecked", "rawtypes", "deprecation"})
public class SqlMapDdpDAOImpl extends SqlMapDAOBase implements DdpDAO {
	
	private ParamDAO paramDAOT01;
	
	public void setParamDAOT01(ParamDAO paramDAOT01){
		this.paramDAOT01 = paramDAOT01;
	}
	
	public DdpBean findByNroRUC(String nroRUC) {
		if (log.isDebugEnabled()) {log.debug("SQLMapDaoImpl findByNroRUC (" + nroRUC + ")");}
		
		DdpBean ddp = (DdpBean) getSqlMapClientTemplate().queryForObject("Ddp.findByNroRUC", nroRUC);
		return ddp;
	}

	
	public Integer findByRUCActivo(String numeroDeRUC) {
		if (this.log.isDebugEnabled()) this.log.debug("SqlMapDao findByRUCActivo (" + numeroDeRUC + ")");

		Integer count = (Integer)getSqlMapClientTemplate().queryForObject("Ddp.findByRUCActivo", numeroDeRUC);
		return count;
	}
   /**
    * Metodo que busca informacion del ruc
	* @autor rmanrique
	* @param numruc String
	* @return Map
	* @throws DataAccessException
	*/	
	 public Map findByPK(String numruc) throws DataAccessException {
		return findByPK(numruc, false);
	 }
	/**
	* Metodo que busca informacion del ruc con un datasource especifico
	* @autor rmanrique
	* @param datasource DataSource
	* @param numruc String
	* @return Map
	* @throws DataAccessException
	*/
    public Map findByPK(DataSource datasource, String numruc) throws DataAccessException{
    	Map p = new HashMap();
    	p.put("numruc", numruc);
    	Map map = (Map)(new SqlMapClientTemplate(datasource, getSqlMapClientTemplate().getSqlMapClient())).queryForObject("Ddp.findByPK", p);
    	return map;
    }
    
    public Map findByPK(String numruc, boolean parametrizar) throws DataAccessException{
    	return findByPK(numruc, parametrizar, false);
    }

	public Map findByPK(String numruc, boolean parametrizar, boolean cdp) throws DataAccessException {
		Map p = new HashMap();
		p.put("numruc", numruc);
		Map map = (Map) getSqlMapClientTemplate().queryForObject(
				"Ddp.findByPK", p);
		List rpta = new ArrayList();
		if (map != null) {
			rpta.add(map);
			if (parametrizar)
				rpta = parametrizar(rpta, cdp, true);
		}
		if (rpta.isEmpty())
			return null;
		else
			return (Map) rpta.get(0);
	}

	private List parametrizar(List rpta, boolean cdp, boolean ubigeo) {
		ParamBean o = null;
		for(int i = 0; i < rpta.size(); i++) {
			if(log.isDebugEnabled()) log.debug("buscando en recaudaprm003");
			((Map)rpta.get(i)).put("ddp_numreg_desc", "-".equals(((String)((Map)rpta.get(i)).get("ddp_numreg")).trim()) ? "-" : ((Object) ((o = paramDAOT01.buscar("recaudaprm003", (String)((Map)rpta.get(i)).get("ddp_numreg"), 1)) == null ? "-" : ((Object) (o.getDescripcion().substring(11, 35).trim())))));
			if(log.isDebugEnabled()) log.debug("buscando en recaudaprm006");
			((Map)rpta.get(i)).put("ddp_tpoemp_desc", "-".equals(((String)((Map)rpta.get(i)).get("ddp_tpoemp")).trim()) ? "-" : ((Object) ((o = paramDAOT01.buscar("recaudaprm006", (String)((Map)rpta.get(i)).get("ddp_tpoemp"), 1)) == null ? "-" : ((Object) (o.getDescripcion().substring(0, 35).trim())))));
			if(log.isDebugEnabled())log.debug("buscando en recaudaprm009");
			((Map)rpta.get(i)).put("ddp_tamano_desc", "-".equals(((String)((Map)rpta.get(i)).get("ddp_tamano")).trim()) ? "-" : ((Object) ((o = paramDAOT01.buscar("recaudaprm009", (String)((Map)rpta.get(i)).get("ddp_tamano"), 1)) == null ? "-" : ((Object) (o.getDescripcion().substring(0, 20).trim())))));
			if(log.isDebugEnabled())log.debug("buscando en recaudaprm026");
			((Map)rpta.get(i)).put("ddp_flag22_desc", "-".equals(((String)((Map)rpta.get(i)).get("ddp_flag22")).trim()) ? "-" : ((Object) ((o = paramDAOT01.buscar("recaudaprm026", (String)((Map)rpta.get(i)).get("ddp_flag22"), 1)) == null ? "-" : ((Object) (o.getDescripcion().substring(0, 35).trim())))));
			if(log.isDebugEnabled())log.debug("buscando en recaudaprm178");
			((Map)rpta.get(i)).put("ddp_estado_desc", "-".equals(((String)((Map)rpta.get(i)).get("ddp_estado")).trim()) ? "-" : ((Object) ((o = paramDAOT01.buscar("recaudaprm178", (String)((Map)rpta.get(i)).get("ddp_estado"), 1)) == null ? "-" : ((Object) (o.getDescripcion().substring(0, 25).trim())))));
			if(log.isDebugEnabled())log.debug("buscando en recaudaprm058");
			((Map)rpta.get(i)).put("ddp_tipvia_desc", "-".equals(((String)((Map)rpta.get(i)).get("ddp_tipvia")).trim()) ? "-" : ((Object) ((o = paramDAOT01.buscar("recaudaprm058", (String)((Map)rpta.get(i)).get("ddp_tipvia"), 1)) == null ? "-" : ((Object) (o.getDescripcion().substring(0, 4).trim())))));
			if(log.isDebugEnabled())log.debug("buscando en recaudaprm059");
			((Map)rpta.get(i)).put("ddp_tipzon_desc", "-".equals(((String)((Map)rpta.get(i)).get("ddp_tipzon")).trim()) ? "-" : ((Object) ((o = paramDAOT01.buscar("recaudaprm059", (String)((Map)rpta.get(i)).get("ddp_tipzon"), 1)) == null ? "-" : ((Object) (o.getDescripcion().substring(0, 4).trim())))));
			if(log.isDebugEnabled()) log.debug("buscando en recaudaprm002");
			((Map)rpta.get(i)).put("ddp_ciiu_desc", "-".equals(((String)((Map)rpta.get(i)).get("ddp_ciiu")).trim()) ? "-" : ((Object) ((o = paramDAOT01.buscar("recaudaprm002", (String)((Map)rpta.get(i)).get("ddp_ciiu"), 1)) == null ? "-" : ((Object) (o.getDescripcion().substring(0, 40).trim())))));
			if(log.isDebugEnabled())log.debug("buscando en recaudaprm030");
			((Map)rpta.get(i)).put("depa_desc", "-".equals(((String)((Map)rpta.get(i)).get("ddp_ubigeo")).trim()) ? "-" : ((Object) ((o = paramDAOT01.buscar("recaudaprm030", ((String)((Map)rpta.get(i)).get("ddp_ubigeo")).substring(0, 2), 1)) == null ? "-" : ((Object) (o.getDescripcion().trim())))));
			if(log.isDebugEnabled())log.debug("buscando en recaudaprm031");
			((Map)rpta.get(i)).put("prov_desc", "-".equals(((String)((Map)rpta.get(i)).get("ddp_ubigeo")).trim()) ? "-" : ((Object) ((o = paramDAOT01.buscar("recaudaprm031", ((String)((Map)rpta.get(i)).get("ddp_ubigeo")).substring(0, 4), 1)) == null ? "-" : ((Object) (o.getDescripcion().trim())))));
			if(log.isDebugEnabled())log.debug("buscando en recaudaprm001");
			((Map)rpta.get(i)).put("dist_desc", "-".equals(((String)((Map)rpta.get(i)).get("ddp_ubigeo")).trim()) ? "-" : ((Object) ((o = paramDAOT01.buscar("recaudaprm001", (String)((Map)rpta.get(i)).get("ddp_ubigeo"), 1)) == null ? "-" : ((Object) (o.getDescripcion().substring(0, 31).trim())))));
			((Map)rpta.get(i)).put("direccion_desc", genDireccion((Map)rpta.get(i), cdp, ubigeo));
			((Map)rpta.get(i)).put("identi_desc", "-".equals(((String)((Map)rpta.get(i)).get("ddp_identi")).trim()) ? "-" : ((Object) (((String)((Map)rpta.get(i)).get("ddp_identi")).trim().equals("01") ? "PERSONA NATURAL" : ((Object) (((String)((Map)rpta.get(i)).get("ddp_identi")).trim().equals("02") ? "PERSONA JURIDICA" : "-")))));
		}
		return rpta;
	}

	private String genDireccion(Map row, boolean es_cdp, boolean ubigeo){
		StringBuffer sb_dir = new StringBuffer("");
		if(log.isDebugEnabled())log.debug("ddp->row " + row);
		if(!"-".equals(row.get("ddp_tipvia_desc")) && !"----".equals(row.get("ddp_tipvia_desc")))
			sb_dir.append(row.get("ddp_tipvia_desc")).append(" ");
		if(!"-".equals(((String)row.get("ddp_nomvia")).trim()))
			sb_dir.append(((String)row.get("ddp_nomvia")).trim()).append(" ");
		if(!"-".equals(((String)row.get("ddp_numer1")).trim()))
			sb_dir.append("NRO. ").append(((String)row.get("ddp_numer1")).trim()).append(" ");
		if(row.get("num_kilom") != null && !"-".equals(((String)row.get("num_kilom")).trim()))
			sb_dir.append("KM. ").append(((String)row.get("num_kilom")).trim()).append(" ");
		if(row.get("num_manza") != null && !"-".equals(((String)row.get("num_manza")).trim()))
			sb_dir.append("MZA. ").append(((String)row.get("num_manza")).trim()).append(" ");
		if(!"-".equals(((String)row.get("ddp_inter1")).trim()))
			sb_dir.append("INT. ").append(((String)row.get("ddp_inter1")).trim()).append(" ");
		if(row.get("num_depar") != null && !"-".equals(((String)row.get("num_depar")).trim()))
			sb_dir.append("DPTO. ").append(((String)row.get("num_depar")).trim()).append(" ");
		if(row.get("num_lote") != null && !"-".equals(((String)row.get("num_lote")).trim()))
			sb_dir.append("LOTE. ").append(((String)row.get("num_lote")).trim()).append(" ");
		if(!"-".equals(row.get("ddp_tipzon_desc")) && !"----".equals(row.get("ddp_tipzon_desc")))
			sb_dir.append(row.get("ddp_tipzon_desc")).append(" ");
		if(!"-".equals(((String)row.get("ddp_nomzon")).trim()))
			sb_dir.append(((String)row.get("ddp_nomzon")).trim()).append(" ");
		if(!es_cdp && !"-".equals(((String)row.get("ddp_refer1")).trim()))
			sb_dir.append("(").append(((String)row.get("ddp_refer1")).trim()).append(") ");
		if(ubigeo && !"-".equals(((String)row.get("ddp_ubigeo")).trim()))
			sb_dir.append(row.get("depa_desc")).append(" - ").append(row.get("prov_desc")).append(" - ").append(row.get("dist_desc"));
		return sb_dir.toString();
	}

	public Map findByPKDirecc(String ruc)throws DataAccessException{
		return findByPKDirecc(ruc, false);
	}

	public Map findByPKDirecc(String ruc, boolean parametrizar) throws DataAccessException{
    	return findByPKDirecc(ruc, parametrizar, false);
	}

	public Map findByPKDirecc(String ruc, boolean parametrizar, boolean es_cdp)throws DataAccessException {
		return findByPKDirecc(null, ruc, parametrizar, es_cdp);
	}
	
	public Map findByPKDirecc(DataSource dataSource, String ruc, boolean parametrizar, boolean es_cdp)throws DataAccessException {
		Map p = new HashMap();
		p.put("numruc", ruc);
		
		List rpta;
		if(dataSource == null)
			rpta = getSqlMapClientTemplate().queryForList("Ddp.findByPKDirecc", p);
		else
			rpta = new SqlMapClientTemplate(dataSource, getSqlMapClientTemplate().getSqlMapClient()).
							queryForList("Ddp.findByPKDirecc", p);
		
		if(rpta == null || rpta.isEmpty())
			return null;
		if(parametrizar)
			rpta = parametrizar(rpta, es_cdp, true);
		return (Map)rpta.get(0);
	}

	public String getDomicilioLegal(String nroRuc)throws DataAccessException{
		Map p = new HashMap();
		p.put("numruc", nroRuc);
		p.put("estado", "20");
		List rpta = getSqlMapClientTemplate().queryForList("Ddp.findByPKDirecc", p);
		if(rpta == null || rpta.isEmpty()){
			return null;
		} else{
			rpta = parametrizar(rpta, false, true);
			return (String)((HashMap)rpta.get(0)).get("direccion_desc");
		}
	}

	/**
	 * Inserta un nuevo contribuyente.
	 * @param params
	 */
	public void insert(Map params){
		getSqlMapClientTemplate().insert("Ddp.insert", params);
	}

	/**
	 * Actualiza la direcci�n del contribuyente, seg�n el nro de ruc.
	 * @param params
	 */
	public void updateDirecc(DataSource dataSource, Map params){
		new SqlMapClientTemplate(dataSource, getSqlMapClientTemplate().getSqlMapClient()).
        update("Ddp.updateDirecc", params);
	}

	/**
	 * Obtiene la dependencia, seg�n el nro de ruc.
	 * @param String
	 */
	@Override
	public String recuperaDependencia(String ruc) {
		return (String)this.getSqlMapClientTemplate().queryForObject("Ddp.recuperaDependencia", ruc);
	}

	@Override
	public Map findNumregCiiuByPK(String numruc) throws DataAccessException {
		return (Map)this.getSqlMapClientTemplate().queryForObject("Ddp.findNumregCiiuByPK", numruc);
	}

	@Override
	public List findWithDdsNroDoc(String nrodoc) throws DataAccessException {
		return this.getSqlMapClientTemplate().queryForList("Ddp.findWithDdsNroDoc", nrodoc);
	}

	/**
	  * Actualiza el estado del flag22 seg�n el n�mero de ruc
	  * @param dataSource
	  * @param params
	  * <br><b>flag22</b> el valor del estado a actualizar
	  * <br><b>usuario</b> el usuario de modificaci�n
	  * <br><b>ddp_numruc</b> n�mero de ruc
	  */
	public void updateFlag22(DataSource dataSource, Map params) {
		if(dataSource==null){
			getSqlMapClientTemplate().update("Ddp.updateFlag22", params);
		}else{
			new SqlMapClientTemplate(dataSource, getSqlMapClient()).update("Ddp.updateFlag22", params);
		}
	}
	
	public DdpBean findByNroRUCMD(String nroRUC) {
		if (log.isDebugEnabled()) {log.debug("SQLMapDaoImpl findByNroRUCMD (" + nroRUC + ")");}
		
		DdpBean ddp = (DdpBean) getSqlMapClientTemplate().queryForObject("Ddp.findByNroRUCMD", nroRUC);
		return ddp;
	}
	
	/**
	 * Metodo que trae un registro de la ddp en base al ruc y estado para la el ws consultaruc
	 * @author ecardenasr
	 * @param numruc
	 * @param estado
	 * @return
	 */	

	public Map findByPKws(String ddp_numruc, String ddp_estado) {
		Map params = new HashMap();
		params.put("ddp_numruc", ddp_numruc);
		params.put("ddp_estado", ddp_estado);
		if (log.isDebugEnabled()) log.debug("SQLMapDaoImpl.findByPKws" + params);
		return (Map)getSqlMapClientTemplate().queryForObject("Ddp.findByPKws", params);
	}
	
	/**
	 * Metodo que trae los datos necesarios para formar el domicilio legal
	 * @author ecardenasr
	 * @param numruc
	 * @param estado
	 * @return
	 */

	public Map getDomicilioLegalWS(String numruc, String estado) {
		Map params = new HashMap();
		params.put("numruc", numruc);
		params.put("estado", estado);
		if (log.isDebugEnabled()) log.debug("SQLMapDaoImpl.getDomicilioLegalWS" + params);
		return (Map)this.getSqlMapClientTemplate().queryForObject("Ddp.findByPKDirecc", params);
	}	
}
