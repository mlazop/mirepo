package pe.gob.sunat.servicio2.registro.model.dao;

import java.util.List;

import pe.gob.sunat.servicio2.registro.model.domain.T140Bean;

public interface T140DAO {

	public List<T140Bean> findByRucFormNroAuto(String ruc, String form, Integer orden);
}
