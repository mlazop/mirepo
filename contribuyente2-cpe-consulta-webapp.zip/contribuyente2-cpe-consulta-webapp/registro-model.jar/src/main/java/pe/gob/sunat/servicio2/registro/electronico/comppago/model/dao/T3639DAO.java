package pe.gob.sunat.servicio2.registro.electronico.comppago.model.dao;

import java.io.Serializable;

import pe.gob.sunat.servicio2.registro.electronico.comppago.model.domain.T3639Bean;

public interface T3639DAO  extends Serializable {
	public T3639Bean findByFiltro(T3639Bean param) ;
	public T3639Bean findByPk(String ruc, String serie, String tipo, Integer numero) ;
}
