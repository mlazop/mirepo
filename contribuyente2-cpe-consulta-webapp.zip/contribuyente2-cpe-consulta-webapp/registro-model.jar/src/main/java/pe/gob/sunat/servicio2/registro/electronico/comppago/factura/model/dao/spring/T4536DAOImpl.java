package pe.gob.sunat.servicio2.registro.electronico.comppago.factura.model.dao.spring;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import javax.sql.DataSource;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.dao.DataAccessException;
import org.springframework.dao.EmptyResultDataAccessException;
import org.springframework.dao.IncorrectResultSizeDataAccessException;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.jdbc.core.support.AbstractLobCreatingPreparedStatementCallback;
import org.springframework.jdbc.support.lob.LobCreator;
import org.springframework.jdbc.support.lob.LobHandler;

import pe.gob.sunat.framework.spring.util.date.FechaBean;
import pe.gob.sunat.servicio2.registro.electronico.comppago.factura.model.dao.T4536DAO;
import pe.gob.sunat.servicio2.registro.electronico.comppago.factura.model.domain.T4536Bean;
import pe.gob.sunat.servicio2.registro.electronico.comppago.factura.model.domain.T6464ArcGreBean;
import pe.gob.sunat.servicio2.registro.electronico.comppago.factura.model.domain.T6575ArchPerBean;
import pe.gob.sunat.servicio2.registro.electronico.comppago.factura.model.domain.T6576ArchRetBean;

public class T4536DAOImpl implements T4536DAO {
    protected final Log log = LogFactory.getLog(getClass());
    private JdbcTemplate jdbcTemplate;
    private LobHandler lobHandler;

    private final String findBill = "SELECT num_ticket, num_correl, ind_modo, arc_input, cod_usumodif, fec_modif FROM T4536FESTORE WHERE num_ticket = ? AND num_correl = ? AND ind_modo = ? ;";
    
    //private final String findNombre = "SELECT b.des_archivo as des_nombre FROM T4536FESTORE a, t4533logfepack b WHERE a.num_ticket = b.num_ticket AND b.num_ticket = ? LIMIT 1;";
    private final String findNombre = "SELECT b.des_archivo as des_nombre FROM t4533logfepack b LEFT JOIN T4536FESTORE a ON a.num_ticket = b.num_ticket AND b.num_ticket = ? LIMIT 1";
    

    private final String delete_cdr = "delete from T4536FESTORE WHERE num_ticket = ? AND num_correl = ? AND ind_modo = ?";

    private final String INSERT_SENTENCE = "INSERT INTO T4536FESTORE ( 	num_ticket,num_correl,ind_modo,arc_input,cod_usumodif,fec_modif	)"
	    + "  VALUES (?,?,?,?,?,?)";
    
    private final String INSERT_SENTENCE_PER = "INSERT INTO T6575ARCHPER (ind_modo, num_ticket, nom_archivo, cod_usuregis, fec_regis, cod_usumodif, fec_modif, arc_archivo)"
		    + "  VALUES (?,?,?,?,?,?,?,?)";
    
    private final String INSERT_SENTENCE_RET = "INSERT INTO t6576archret (ind_modo, num_ticket, nom_archivo, cod_usuregis, fec_regis, cod_usumodif, fec_modif, arc_archivo)"
		    + "  VALUES (?,?,?,?,?,?,?,?)";
    
    private final String INSERT_SENTENCE_GRE = "INSERT INTO t6464arcgre (ind_modo, num_ticket, des_archivo, cod_usumodif, fec_modif, arc_input)"
    	    + "  VALUES (?,?,?,?,?,?)";
    
    private final String findDaeBill = "select num_ticket, 0 num_correl, ind_modo, arc_archivo arc_input, cod_usuregis cod_usumodif, fec_regis fec_modif from t10201logdaearc where num_ticket = ? and ind_modo = ?";

    public void setDataSource(DataSource dataSource) {
	this.jdbcTemplate = new JdbcTemplate(dataSource);
    }

    public void setLobHandler(LobHandler lobHandler) {
	this.lobHandler = lobHandler;
    }

    public JdbcTemplate getJdbcTemplate() {
	return jdbcTemplate;
    }

    public void setJdbcTemplate(JdbcTemplate jdbcTemplate) {
	this.jdbcTemplate = jdbcTemplate;
    }

    @SuppressWarnings({ "rawtypes", "unchecked" })
    @Override
    public T4536Bean getBillStore(String ticket, Integer correlativo, String mode) {

	if (log.isDebugEnabled()) {
	    log.debug("T4536DAOImpl Spring getBillStore( " + ticket + ", " + mode + ")");
	}
	try {
	    RowMapper mapper = new RowMapper() {
		public Object mapRow(ResultSet rs, int rowNum) throws SQLException {
		    T4536Bean bean = new T4536Bean();
		    if (log.isDebugEnabled()) {
			log.debug("T4536DAOImpl findBill :Mapeando datos");
		    }

		    bean.setTicket(rs.getString("num_ticket"));
		    bean.setCorrelativo(rs.getInt("num_correl"));
		    bean.setModo(rs.getString("ind_modo"));
		    bean.setContenido(lobHandler.getBlobAsBytes(rs, "arc_input"));
		    bean.setUsuarioModificador(rs.getString("cod_usumodif"));
		    bean.setFechaModificacion(new FechaBean(rs.getTimestamp("fec_modif")));
		    return bean;
		}
	    };

	    return (T4536Bean) jdbcTemplate.queryForObject(this.findBill, new Object[] { ticket, correlativo, mode }, mapper);
	
	} catch (EmptyResultDataAccessException e) {
	    log.warn("No se encontro la constancia", e);
	    return null;
	}  catch (IncorrectResultSizeDataAccessException e) {
	    log.warn("No se encontro la constancia o se encontro mas de un comprobante", e);
	    return null;
	} catch (RuntimeException e) {
	    log.error(e, e);
	    return null;
	}
    }

    @Override
    public void deleteByTiketAndModo(String numTicket, Integer correlativo, String mode) {
	jdbcTemplate.update(this.delete_cdr, new Object[] { numTicket, correlativo, mode });

    }

    @Override
    public void inserta(final T4536Bean billStore) {

	jdbcTemplate.execute(this.INSERT_SENTENCE, new AbstractLobCreatingPreparedStatementCallback(lobHandler) {
	    protected void setValues(PreparedStatement ps, LobCreator lobCreator) throws SQLException,
		    DataAccessException {

		ps.setString(1, billStore.getTicket());

		ps.setInt(2, billStore.getCorrelativo());

		ps.setString(3, billStore.getModo());

		lobCreator.setBlobAsBytes(ps, 4, billStore.getContenido());

		ps.setString(5, billStore.getUsuarioModificador());

		ps.setTimestamp(6, billStore.getFechaModificacion().getTimestamp());
	    }
	});

    }

	@Override
	public void inserta(final T6575ArchPerBean billStore) {
		
		jdbcTemplate.execute(this.INSERT_SENTENCE_PER, new AbstractLobCreatingPreparedStatementCallback(lobHandler) {
		    protected void setValues(PreparedStatement ps, LobCreator lobCreator) throws SQLException,
			    DataAccessException {

		    	ps.setString(1, billStore.getIndModo());
		    	ps.setString(2, billStore.getNumTicket().toString());
		    	ps.setString(3, billStore.getNomArchivo());
		    	ps.setString(4, billStore.getCodUsuregis());			
		    	ps.setDate(5, new java.sql.Date((billStore.getFecRegis().getTime())));
		    	ps.setString(6, billStore.getCodUsumodif());
		    	ps.setDate(7, new java.sql.Date((billStore.getFecModif().getTime())));
		    	lobCreator.setBlobAsBytes(ps, 8, billStore.getArcArchivo());
		    }
		});
		
	}

	@Override
	public void inserta(final T6576ArchRetBean billStore) {		

		jdbcTemplate.execute(this.INSERT_SENTENCE_RET, new AbstractLobCreatingPreparedStatementCallback(lobHandler) {
		    protected void setValues(PreparedStatement ps, LobCreator lobCreator) throws SQLException,
			    DataAccessException {

		    	ps.setString(1, billStore.getIndModo());
		    	ps.setString(2, billStore.getNumTicket().toString());
		    	ps.setString(3, billStore.getNomArchivo());
		    	ps.setString(4, billStore.getCodUsuRegis());			
		    	ps.setDate(5, new java.sql.Date((billStore.getFecRegis().getTime())));
		    	ps.setString(6, billStore.getCodUsumodif());
		    	ps.setDate(7, new java.sql.Date((billStore.getFecModif().getTime())));
		    	lobCreator.setBlobAsBytes(ps, 8, billStore.getArcArchivo());
		    }
		});
		
	}

	@Override
	public void inserta(final T6464ArcGreBean billStore) {
		
		jdbcTemplate.execute(this.INSERT_SENTENCE_GRE, new AbstractLobCreatingPreparedStatementCallback(lobHandler) {
		    protected void setValues(PreparedStatement ps, LobCreator lobCreator) throws SQLException,
			    DataAccessException {

		    	ps.setString(1, billStore.getIndModo());
		    	ps.setString(2, billStore.getNumTicket().toString());
		    	ps.setString(3, billStore.getDesArchivo());
		    	ps.setString(4, billStore.getCodUsumodif());
		    	ps.setDate(5, new java.sql.Date((billStore.getFecModif().getTime())));
		    	lobCreator.setBlobAsBytes(ps, 6, billStore.getArcInput());
		    }
		});
		
	}
	
	public String findNombre( String ticket ) {

		if (log.isDebugEnabled()) {
		    log.debug("T4536DAOImpl Spring findNombre( " + ticket + ")");
		}
		try {
		    RowMapper mapper = new RowMapper() {
			public Object mapRow(ResultSet rs, int rowNum) throws SQLException {
			    return rs.getString("des_nombre");
			}
		    };

		    return (String) jdbcTemplate.queryForObject(this.findNombre, new Object[] { ticket }, mapper);
		
		} catch (EmptyResultDataAccessException e) {
		    log.warn("No se encontro el nombre del xml", e);
		    return null;
		}  catch (IncorrectResultSizeDataAccessException e) {
		    log.warn("No se encontro el nombre del xml o se encontro mas de un nombre", e);
		    return null;
		} catch (RuntimeException e) {
		    log.error(e, e);
		    return null;
		}
	    }
	
	public T4536Bean findFileZipTFESTOREByPrimaryKey( T4536Bean t4536bean ) {

		if (log.isDebugEnabled()) {
		    log.debug("T4536DAOImpl Spring findFileZipTFESTOREByPrimaryKey( " + t4536bean.getTicket() + ")");
		}
		try {
		    RowMapper mapper = new RowMapper() {
				public Object mapRow(ResultSet rs, int rowNum) throws SQLException {
				    T4536Bean bean = new T4536Bean();
				    if (log.isDebugEnabled()) {
					log.debug("T4536DAOImpl findBill :Mapeando datos");
				    }
	
				    bean.setTicket(rs.getString("num_ticket"));
				    bean.setCorrelativo(rs.getInt("num_correl"));
				    bean.setModo(rs.getString("ind_modo"));
				    bean.setContenido(lobHandler.getBlobAsBytes(rs, "arc_input"));
				    bean.setUsuarioModificador(rs.getString("cod_usumodif"));
				    bean.setFechaModificacion(new FechaBean(rs.getTimestamp("fec_modif")));
				    return bean;
				}
		    };

		    return (T4536Bean) jdbcTemplate.queryForObject(this.findBill, new Object[] { t4536bean.getTicket(), t4536bean.getCorrelativo()+"", "1" }, mapper);
		
		} catch (EmptyResultDataAccessException e) {
		    log.warn("No se encontro la constancia", e);
		    return null;
		}  catch (IncorrectResultSizeDataAccessException e) {
		    log.warn("No se encontro la constancia o se encontro mas de un comprobante", e);
		    return null;
		} catch (RuntimeException e) {
		    log.error(e, e);
		    return null;
		}
	    }
	
	public T4536Bean findFileZipTFESTOREByPrimaryKey( String ticket ) {

		if ( log.isDebugEnabled () ) {
			log.debug ( "T4536DAOImpl Spring findFileZipTFESTOREByPrimaryKey( " + ticket + ")" );
		}
		try {
			RowMapper mapper = new RowMapper () {
				public Object mapRow( ResultSet rs, int rowNum ) throws SQLException {
					T4536Bean bean = new T4536Bean ();

					if ( log.isDebugEnabled () ) {
						log.debug ( "T4536DAOImpl findDaeBill :Mapeando datos" );
					}

					bean.setTicket ( rs.getString ( "num_ticket" ) );
					bean.setCorrelativo ( rs.getInt ( "num_correl" ) );
					bean.setModo ( rs.getString ( "ind_modo" ) );
					bean.setContenido ( lobHandler.getBlobAsBytes ( rs, "arc_input" ) );
					bean.setUsuarioModificador ( rs.getString ( "cod_usumodif" ) );
					bean.setFechaModificacion ( new FechaBean ( rs.getTimestamp ( "fec_modif" ) ) );

					return bean;
				}
			};

			log.debug ( "T4536DAOImpl Spring query( " + this.findDaeBill + ")" );

			return ( T4536Bean ) jdbcTemplate.queryForObject ( this.findDaeBill, new Object [] { ticket, "1" },
					mapper );

		} catch ( EmptyResultDataAccessException e ) {
			log.warn ( "No se encontro la zip en la tabla festore", e );
			return null;
		} catch ( IncorrectResultSizeDataAccessException e ) {
			log.warn ( "No se encontro la constancia o se encontro mas de un comprobante", e );
			return null;
		} catch ( RuntimeException e ) {
			log.error ( e, e );
			return null;
		}
	}

}
