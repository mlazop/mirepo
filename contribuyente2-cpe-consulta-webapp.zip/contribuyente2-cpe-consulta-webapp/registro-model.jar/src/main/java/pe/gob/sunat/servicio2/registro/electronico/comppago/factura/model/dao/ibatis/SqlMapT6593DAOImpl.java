package pe.gob.sunat.servicio2.registro.electronico.comppago.factura.model.dao.ibatis;

import java.util.HashMap;
import java.util.Map;

import pe.gob.sunat.framework.spring.util.dao.SqlMapDAOBase;
import pe.gob.sunat.servicio2.registro.electronico.comppago.factura.model.dao.T6593DAO;
import pe.gob.sunat.servicio2.registro.electronico.comppago.factura.model.domain.BillLogPack;

@SuppressWarnings({"deprecation"})
public class SqlMapT6593DAOImpl extends SqlMapDAOBase implements T6593DAO {

	@Override
	public void actualizaEstado(String nroTicket) {
		Map<String,String> data = new HashMap<String, String>();
		data.put("numTicket", nroTicket);
		getSqlMapClientTemplate().update("GreLogPack.update", data);
	}
	
	@Override
	public void actualizaEstado(BillLogPack data) {
		getSqlMapClientTemplate().update("GreLogPack.updateData", data);
				
	}
}
