package pe.gob.sunat.servicio2.registro.electronico.comppago.factura.model.dao;

import pe.gob.sunat.servicio2.registro.electronico.comppago.factura.model.domain.T2816Bean;

public interface T2816DAO {
	
	public T2816Bean select(String num_docum, String cod_acceso, String cod_detalle);
	public int update(String num_docum, String cod_acceso, String cod_detalle);

}
