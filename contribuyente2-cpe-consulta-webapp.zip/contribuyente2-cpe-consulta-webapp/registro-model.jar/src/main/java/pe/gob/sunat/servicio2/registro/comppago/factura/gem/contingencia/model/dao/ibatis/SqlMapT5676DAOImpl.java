package pe.gob.sunat.servicio2.registro.comppago.factura.gem.contingencia.model.dao.ibatis;

import java.sql.SQLException;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;

import org.springframework.orm.ibatis.SqlMapClientCallback;

import pe.gob.sunat.framework.spring.util.dao.SqlMapDAOBase;
import pe.gob.sunat.servicio2.registro.comppago.factura.gem.contingencia.model.dao.T5676DAO;
import pe.gob.sunat.servicio2.registro.comppago.factura.gem.contingencia.model.domain.T5675Bean;
import pe.gob.sunat.servicio2.registro.comppago.factura.gem.contingencia.model.domain.T5676Bean;
import pe.gob.sunat.servicio2.registro.comppago.factura.gem.contingencia.model.domain.T5676QueryParameterBean;

import com.ibatis.sqlmap.client.SqlMapClient;
import com.ibatis.sqlmap.client.SqlMapExecutor;

@SuppressWarnings({"rawtypes", "unchecked", "deprecation"})
public class SqlMapT5676DAOImpl extends SqlMapDAOBase implements T5676DAO {
	private static final long serialVersionUID = 9029959794017239305L;
	@SuppressWarnings("unused")
	private SqlMapClient  sqlMapClient;
	
	@Override
	public void updateVigenciaByTicket(HashMap map) {
		try {
			if (log.isDebugEnabled()) {log.trace("Actualizar Vigencia por numero de Tickect");}
			 getSqlMapClientTemplate().update("T5676.updateVigenciaByTicket", map);
		} catch (Exception e) {
		
			if (log.isDebugEnabled()) 
					{
					log.debug(e.getMessage());}
					}
		}
		
	private static final int DB_BATCH_SIZE = 100;

	@Override
    public void insertarContingenciaDetalle(final List<T5676Bean> datos) {
	getSqlMapClientTemplate().execute(new SqlMapClientCallback() {

	    @Override
	    public Object doInSqlMapClient(SqlMapExecutor executor) throws SQLException {
			executor.startBatch();
			insertarContingenciaDetalleBatch(datos, executor);
			return executor.executeBatch();
	    }
	});
    }
    

	private void insertarContingenciaDetalleBatch(List<T5676Bean> datos, SqlMapExecutor executor) 
			throws SQLException {
		if (datos != null && datos.size()>0) {
			    Iterator<T5676Bean> iterContingenciaDetalle = datos.iterator();
			    int count = 0;
			    while (iterContingenciaDetalle.hasNext()) {
			    	T5676Bean contingenciaDetalle = iterContingenciaDetalle.next();
			    	executor.insert("T5676.insertarContingenciaDetalle", contingenciaDetalle);
			    	count++;
	                if (count % DB_BATCH_SIZE == 0){	
	                	executor.executeBatch();
	                	executor.startBatch();
	                }
			    }
			    //Para el resto de inserciones
			    executor.executeBatch();
			}
	    }
    
    @Override
    public void actualizarVigenciaContingenciaDetalle(T5675Bean t5675Bean){
		
		getSqlMapClientTemplate().update("T5676.actualizarVigenciaContingenciaDetalle", t5675Bean);
		
	} 
    
    @Override
    public Integer contarContingenciaDetalleByNumeRuc(T5676Bean t5676Bean){
		Integer retorno = (Integer)getSqlMapClientTemplate().queryForObject("T5676.contarContingenciaDetalleByNumeRuc",t5676Bean);
		return retorno;
	}

    @Override
    public Integer contarContingenciaDetalleByComprobante(T5676Bean t5676Bean){
		Integer retorno = (Integer)getSqlMapClientTemplate().queryForObject("T5676.contarContingenciaDetalleByComprobante",t5676Bean);
		return retorno;
	}

	@Override
	public List<T5676Bean> obtenerListaComprobantesContingencia(HashMap map) {
    	try {
    		List<T5676Bean> lstT5676Bean = (List<T5676Bean>)getSqlMapClientTemplate().queryForList("T5676.findCompContingByRucAndIDParams",map);
    		return lstT5676Bean;
    		
		} catch (Exception e) {
			if (log.isDebugEnabled()) 
			{
			log.debug(e.getMessage());
			}
			return null;
		}
	}
    
	@Override
	public List<T5676Bean> obtenerValidacionComprobantesContingencia(T5676QueryParameterBean t5676QueryParameterBean) {
    	try {
    		List<T5676Bean> lstT5676Bean = (List<T5676Bean>)getSqlMapClientTemplate().queryForList("T5676.findCompContingByValidParams",t5676QueryParameterBean);
    		return lstT5676Bean;
    		
		} catch (Exception e) {
			if (log.isDebugEnabled()) 
			{
			log.debug(e.getMessage());
			}
			return null;
		}
	}
	
    
}
