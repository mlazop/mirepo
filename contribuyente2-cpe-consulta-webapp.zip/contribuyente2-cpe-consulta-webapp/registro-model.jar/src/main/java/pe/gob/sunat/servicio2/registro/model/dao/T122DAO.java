package pe.gob.sunat.servicio2.registro.model.dao;


import java.util.List;

import pe.gob.sunat.servicio2.registro.model.domain.T122Bean;

/**
 * Dao para el control de la tabla t122detaut
 * @author pchacalia
 *
 */
public interface T122DAO {
	public List<T122Bean> findByRUC_Serie_TipoDoc(T122Bean bean) ;

	public List<T122Bean> findByRUC_Serie_TipoDoc_Rango(T122Bean bean);
	
	public List<T122Bean> findByRucDocIndice(String ruc, String serie, String tip_doc, Integer indice);

}
