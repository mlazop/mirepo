package pe.gob.sunat.servicio2.registro.electronico.comppago.factura.model.dao;

import pe.gob.sunat.servicio2.registro.electronico.comppago.factura.model.domain.PkComprobante;
import pe.gob.sunat.servicio2.registro.electronico.comppago.factura.model.domain.T6571PercepcionBean;

public interface T6571PercepcionSelectDAO {
	
	public T6571PercepcionBean buscarPorPk(String numeroRuc, String codigoGuia, String numeroSerie, Integer numeroGuia);
	
	public Integer buscarPorPrimaryKey(String numeroRuc, String codigoGuia, String numeroSerie, String numeroGuia);
	

}
