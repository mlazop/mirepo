package pe.gob.sunat.servicio2.registro.model.dao.ibatis;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.TreeMap;

import pe.gob.sunat.framework.spring.util.dao.SqlMapDAOBase;
import pe.gob.sunat.servicio2.registro.model.dao.T01DAO;
import pe.gob.sunat.servicio2.registro.model.domain.T01Bean;

@SuppressWarnings({"unchecked", "rawtypes", "deprecation"})
public class SqlMapT01DAOImpl extends SqlMapDAOBase implements T01DAO{

	/**
	 * 
	 */
	private static final long serialVersionUID = 7026709158235788133L;

	@Override
	public T01Bean findByNumeroArgumento(String numero, String argumento)
	{
		if (log.isDebugEnabled()) {log.debug("findByNumeroArgumento (" + numero + ", " + argumento + ")" );}
		T01Bean bean = new T01Bean();
		bean.setNumero(numero);
		bean.setArgumento(argumento);
		return  (T01Bean)getSqlMapClientTemplate().queryForObject("T01.findByNumeroArgumento", bean);
	}

	@Override
	public List<T01Bean>  findTiposComprobante() {
		return null;
	}

	
	@Override
	public T01Bean findAllByNumeroArgumento(String numero, String argumento) {
		return null;
	}

	@Override
	public List<T01Bean> findUnidadMedidaExportacion(String numero) {

		return null;
	}

	@Override
	public List<T01Bean> findUnidadMedidaNoExportacion(String numero) {

		return null;
	}

	@Override
	public List<T01Bean> findUnidadMedidaVigente(String numero) {

		return null;
	}

	@Override
	public List<T01Bean> findTiposDocumentoActivos() {

		return null;
	}

	
	//Inicio agregado fsantosl
	public TreeMap mbuscar(ArrayList v){
		if(log.isDebugEnabled())
			log.debug("BeanT01c==>>> buscar por lista de elementos");
		TreeMap r = new TreeMap();
		
		Map param = new HashMap();
		param.put("numeros", v);
		
		List lista = (List)this.getSqlMapClientTemplate().queryForObject("T01.mbuscar", param);
		
		if(lista!=null && lista.size()>0){
			T01Bean beanT01;
			for(int i=0; i<lista.size(); i++){
				beanT01 = (T01Bean) lista.get(i);
				r.put(beanT01.getArgumento(), beanT01);
			}
			if(log.isDebugEnabled())
				log.debug("Elementos cargados..: "+r.size());
		}
		
		return r;
	}
	
	public String findByArgumento(String numero, String argumento){
		T01Bean bean = new T01Bean();
		bean.setNumero(numero);
		bean.setArgumento(argumento);

		String retorno ="-";
		
		T01Bean beanRetorno = (T01Bean)this.getSqlMapClientTemplate().queryForObject("T01.findByNumeroArgumento", bean);
		
		if(beanRetorno!=null && beanRetorno.getFuncion()!=null){
			retorno = beanRetorno.getFuncion();
		}
		
		return retorno;
	}
	
	public List findByArgumentoINfuncion(Map param){
		return getSqlMapClientTemplate().queryForList("T01.findByArgumentoINfuncion", param);
	}
	
	public List findByArgumentoPatron(String numero, String argumento){
		T01Bean bean = new T01Bean();
		bean.setNumero(numero);
		bean.setArgumento(argumento);
			
		return getSqlMapClientTemplate().queryForList("T01.findByArgumentoPatron", bean);
	}
	
	
	//Fin agregado fsantosl
	
	// 20110922- naa-  metodos  para factura grandes emisores - metodos  que  usan  cache- pueden ser  usados  por otros  aplicativos.
	
	
	@Override
	public T01Bean findByNumeroArgumentoCache(String numero, String argumento) {
		if (log.isDebugEnabled()) {log.debug("findByNumeroArgumentoCache (" + numero + ", " + argumento + ")" );}
		T01Bean bean = new T01Bean();
		bean.setNumero(numero);
		bean.setArgumento(argumento);
		return  (T01Bean)getSqlMapClientTemplate().queryForObject("T01.findByNumeroArgumentoCache", bean);
	}

	@Override
	public List<T01Bean> findByNumeroCache(String numero) {
		if (log.isDebugEnabled()) {log.debug("findByNumeroCache (" + numero  );}
		T01Bean bean = new T01Bean();
		List<T01Bean>  lista = new ArrayList<T01Bean>(); 
		bean.setNumero(numero);	
		lista = getSqlMapClientTemplate().queryForList("T01.findByNumeroCache", bean);
		return  lista; 	
	}
	//  fin de  20110922- naa-  metodos  para factura grandes emisores 
	
	//Inicio agregado fsantosl
	public List buscaParametroLimiteEnte(Map param){
		List lista = this.getSqlMapClientTemplate().queryForList("T01.buscaParametroLimiteEnte", param);
		return lista;
	}
	
	public List buscaParametroPorEnte(Map param){
		List lista = this.getSqlMapClientTemplate().queryForList("T01.buscaParametroPorEnte", param);
		return lista;
	}
	
	public void updateMontoHoy(Map param){
		this.getSqlMapClientTemplate().update("T01.updateMontoHoy", param);
	}
	
	public void desacticaMontoVigente(Map param){
		this.getSqlMapClientTemplate().update("T01.desacticaMontoVigente", param);
	}
	
	public void insertNuevoMonto(Map param){
		this.getSqlMapClientTemplate().insert("T01.insertNuevoMonto", param);
	}
	//Fin agregado fsantosl
	
	//agregado para PLE por NAA
	@Override
	public String findByNumero003Libros(String argumento) {
		String cad = null;
		cad = (String)this.getSqlMapClientTemplate().queryForObject("T01.findByNumero003LibroCache", argumento); 
		return cad; 
	}

	@Override
	public List<T01Bean> findByNumero052Dependencia(String codDependencia) {
		if (log.isDebugEnabled()) {log.debug("findByNumeroCache (" + codDependencia  );}
		List<T01Bean>  lista = new ArrayList<T01Bean>(); 
		lista = getSqlMapClientTemplate().queryForList("T01.findByNumero052Dependencia", codDependencia);
		return  lista; 	
	}

	@Override
	public List<T01Bean> findByNumeroConsultaComprobante(String numero) {
		/*if (log.isDebugEnabled()) {log.debug("SqlMapT01DAOImpl findByNumeroConsultaComprobante (" + numero + ")" );}
		T01Bean bean = new T01Bean();
		List<T01Bean>  lista = new ArrayList<T01Bean>(); 
		bean.setNumero(numero);
		lista = getSqlMapClientTemplate().queryForList("T01.findByNumeroTipo", bean);
		return lista;*/
		return null;
	}
}
