package pe.gob.sunat.servicio2.registro.electronico.comppago.factura.model.dao;

import java.util.List;

import pe.gob.sunat.servicio2.registro.electronico.comppago.factura.model.domain.T6468DatGreBajaBean;

/**
 * @author evargasc
 *
 */
public interface T6468DatGreBajaDAO {

	public List<T6468DatGreBajaBean> buscarPk(String numeroRuc, String codigoGuia, String numeroSerie, Integer numeroGuia);
	public void insert(T6468DatGreBajaBean record);
	public void delete(String numeroRuc, String codigoGuia, String numeroSerie, Integer numeroGuia);
}
