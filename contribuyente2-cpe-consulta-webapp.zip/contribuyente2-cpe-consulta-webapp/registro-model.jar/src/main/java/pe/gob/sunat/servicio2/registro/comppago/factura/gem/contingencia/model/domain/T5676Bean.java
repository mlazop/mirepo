
package pe.gob.sunat.servicio2.registro.comppago.factura.gem.contingencia.model.domain;

import java.io.Serializable;
import java.math.BigDecimal;

import pe.gob.sunat.framework.spring.util.date.FechaBean;


public class T5676Bean  implements Serializable{
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 9029959794017239305L;
	private Long numeTicket;
	private String tipoComprobante;
	private String serieComprobante;
	private String numeComprobanteDesde;
	private String numeComprobanteHasta;
	private FechaBean fechaEmision;
	private String tipoDocumentoIdentidad; 
	private String numeroDocuIdencliente;
	private String nombreCliente;
	private String moneda;
	private String tipoComprobanteModifica;
	private String serieDocuModifica;
	private String 	numeCompModiDesde;
	private String	numeCompModiHasta;
	private BigDecimal	montoVentaGravada;
	private BigDecimal	montoVentaExonerada;
	private BigDecimal	montoVentaInafecta;
	private BigDecimal	montoIsc;
	private BigDecimal	montoIgvIpm;
	private BigDecimal	montoOtros;
	private BigDecimal	montoTotal;
	private String	indicadorEstado;
	private String	codiMotivo;
	private String	usuarioRegistra;
	private FechaBean fechaRegistro;
	private String indicadorVigente;
	
	public String getIndicadorVigente() {
		return indicadorVigente;
	}
	public void setIndicadorVigente(String indicadorVigente) {
		this.indicadorVigente = indicadorVigente;
	}
	
	
	public Long getNumeTicket() {
		return numeTicket;
	}

	public void setNumeTicket(Long numeTicket) {
		this.numeTicket = numeTicket;
	}

	public String getTipoComprobante() {
		return tipoComprobante;
	}

	public void setTipoComprobante(String tipoComprobante) {
		this.tipoComprobante = tipoComprobante;
	}

	public String getSerieComprobante() {
		return serieComprobante;
	}

	public void setSerieComprobante(String serieComprobante) {
		this.serieComprobante = serieComprobante;
	}

	public String getNumeComprobanteDesde() {
		return numeComprobanteDesde;
	}

	public void setNumeComprobanteDesde(String numeComprobanteDesde) {
		this.numeComprobanteDesde = numeComprobanteDesde;
	}

	public String getNumeComprobanteHasta() {
		return numeComprobanteHasta;
	}

	public void setNumeComprobanteHasta(String numeComprobanteHasta) {
		this.numeComprobanteHasta = numeComprobanteHasta;
	}

	public FechaBean getFechaEmision() {
		return fechaEmision;
	}

	public void setFechaEmision(FechaBean fechaEmision) {
		this.fechaEmision = fechaEmision;
	}

	public String getTipoDocumentoIdentidad() {
		return tipoDocumentoIdentidad;
	}

	public void setTipoDocumentoIdentidad(String tipoDocumentoIdentidad) {
		this.tipoDocumentoIdentidad = tipoDocumentoIdentidad;
	}

	public String getNumeroDocuIdencliente() {
		return numeroDocuIdencliente;
	}

	public void setNumeroDocuIdencliente(String numeroDocuIdencliente) {
		this.numeroDocuIdencliente = numeroDocuIdencliente;
	}

	public String getNombreCliente() {
		return nombreCliente;
	}

	public void setNombreCliente(String nombreCliente) {
		this.nombreCliente = nombreCliente;
	}

	public String getMoneda() {
		return moneda;
	}

	public void setMoneda(String moneda) {
		this.moneda = moneda;
	}

	public String getTipoComprobanteModifica() {
		return tipoComprobanteModifica;
	}
	
	public void setTipoComprobanteModifica(String tipoComprobanteModifica) {
		this.tipoComprobanteModifica =tipoComprobanteModifica;
	}
	
	public String getSerieDocuModifica() {
		return serieDocuModifica;
	}

	public void setSerieDocuModifica(String serieDocuModifica) {
		this.serieDocuModifica = serieDocuModifica;
	}

	public String getNumeCompModiDesde() {
		return numeCompModiDesde;
	}

	public void setNumeCompModiDesde(String numeCompModiDesde) {
		this.numeCompModiDesde = numeCompModiDesde;
	}

	public String getNumeCompModiHasta() {
		return numeCompModiHasta;
	}

	public void setNumeCompModiHasta(String numeCompModiHasta) {
		this.numeCompModiHasta = numeCompModiHasta;
	}

	public BigDecimal getMontoVentaGravada() {
		return montoVentaGravada;
	}

	public void setMontoVentaGravada(BigDecimal montoVentaGravada) {
		this.montoVentaGravada = montoVentaGravada;
	}

	public BigDecimal getMontoVentaExonerada() {
		return montoVentaExonerada;
	}

	public void setMontoVentaExonerada(BigDecimal montoVentaExonerada) {
		this.montoVentaExonerada = montoVentaExonerada;
	}

	public BigDecimal getMontoVentaInafecta() {
		return montoVentaInafecta;
	}

	public void setMontoVentaInafecta(BigDecimal montoVentaInafecta) {
		this.montoVentaInafecta = montoVentaInafecta;
	}

	public BigDecimal getMontoIsc() {
		return montoIsc;
	}

	public void setMontoIsc(BigDecimal montoIsc) {
		this.montoIsc = montoIsc;
	}

	public BigDecimal getMontoIgvIpm() {
		return montoIgvIpm;
	}

	public void setMontoIgvIpm(BigDecimal montoIgvIpm) {
		this.montoIgvIpm = montoIgvIpm;
	}

	public BigDecimal getMontoOtros() {
		return montoOtros;
	}

	public void setMontoOtros(BigDecimal montoOtros) {
		this.montoOtros = montoOtros;
	}

	public BigDecimal getMontoTotal() {
		return montoTotal;
	}

	public void setMontoTotal(BigDecimal montoTotal) {
		this.montoTotal = montoTotal;
	}

	public String getIndicadorEstado() {
		return indicadorEstado;
	}

	public void setIndicadorEstado(String indicadorEstado) {
		this.indicadorEstado = indicadorEstado;
	}

	public String getCodiMotivo() {
		return codiMotivo;
	}

	public void setCodiMotivo(String codiMotivo) {
		this.codiMotivo = codiMotivo;
	}

	public String getUsuarioRegistra() {
		return usuarioRegistra;
	}

	public void setUsuarioRegistra(String usuarioRegistra) {
		this.usuarioRegistra = usuarioRegistra;
	}

	public FechaBean getFechaRegistro() {
		return fechaRegistro;
	}

	public void setFechaRegistro(FechaBean fechaRegistro) {
		this.fechaRegistro = fechaRegistro;
	}

}
