package pe.gob.sunat.servicio2.registro.model.domain;

import java.io.Serializable;

import pe.gob.sunat.framework.spring.util.date.FechaBean;

public class T130Bean implements Serializable {
	private static final long serialVersionUID = -6499447801812809726L;
	
	private String t130_numruc;
	private String t130_serie;
	private String t130_tipdoc;
	private Integer t130_desde;
	private Integer t130_hasta;
	private String t130_userna;
	private FechaBean t130_fecact;
	public String getT130_numruc() {
		return t130_numruc;
	}
	public void setT130_numruc(String t130Numruc) {
		t130_numruc = t130Numruc;
	}
	public String getT130_serie() {
		return t130_serie;
	}
	public void setT130_serie(String t130Serie) {
		t130_serie = t130Serie;
	}
	public String getT130_tipdoc() {
		return t130_tipdoc;
	}
	public void setT130_tipdoc(String t130Tipdoc) {
		t130_tipdoc = t130Tipdoc;
	}
	public Integer getT130_desde() {
		return t130_desde;
	}
	public void setT130_desde(Integer t130Desde) {
		t130_desde = t130Desde;
	}
	public Integer getT130_hasta() {
		return t130_hasta;
	}
	public void setT130_hasta(Integer t130Hasta) {
		t130_hasta = t130Hasta;
	}
	public String getT130_userna() {
		return t130_userna;
	}
	public void setT130_userna(String t130Userna) {
		t130_userna = t130Userna;
	}
	public FechaBean getT130_fecact() {
		return t130_fecact;
	}
	public void setT130_fecact(FechaBean t130Fecact) {
		t130_fecact = t130Fecact;
	}
	
	@Override
	public String toString() {
		return "T130Bean [t130_desde=" + t130_desde + ", t130_fecact="
				+ t130_fecact + ", t130_hasta=" + t130_hasta + ", t130_numruc="
				+ t130_numruc + ", t130_serie=" + t130_serie + ", t130_tipdoc="
				+ t130_tipdoc + ", t130_userna=" + t130_userna + "]";
	}
	
	public T130Bean(String t130Numruc, String t130Serie, String t130Tipdoc,
			Integer t130Desde, Integer t130Hasta, String t130Userna,
			FechaBean t130Fecact) {
		super();
		t130_numruc = t130Numruc;
		t130_serie = t130Serie;
		t130_tipdoc = t130Tipdoc;
		t130_desde = t130Desde;
		t130_hasta = t130Hasta;
		t130_userna = t130Userna;
		t130_fecact = t130Fecact;
	}
	
	public T130Bean() {
		super();
	}
	
	
	
}

