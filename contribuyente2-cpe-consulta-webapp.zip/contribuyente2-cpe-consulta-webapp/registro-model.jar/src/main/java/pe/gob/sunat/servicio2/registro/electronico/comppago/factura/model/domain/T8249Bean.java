package pe.gob.sunat.servicio2.registro.electronico.comppago.factura.model.domain;

import java.io.Serializable;

import java.math.BigDecimal;
import pe.gob.sunat.framework.spring.util.date.FechaBean;

public class T8249Bean implements Serializable {

	private static final long serialVersionUID = 8829200419140342503L;

	private Integer num_ticket;
	private String num_ruc_emisor;
	private FechaBean fec_emision_cp;
	private String fecha_emision;
	private String hora_emision;
	private String tip_cp;
	private String num_serie_cp;
	private String num_cp;
	private BigDecimal mto_total;
	private String tip_doc_idecliente;
	private String num_doc_idecliente;
	private String num_cp_modif;
	private String ind_vigente;
	private String cod_usuregis;
	private FechaBean fec_regis;
	private String cod_usumodif;
	private FechaBean fec_modif;
	
	private T8248Bean t8248Bean;
	
	
	public T8248Bean getT8248Bean() {
		return t8248Bean;
	}
	public void setT8248Bean(T8248Bean t8248Bean) {
		this.t8248Bean = t8248Bean;
	}
	public Integer getNum_ticket() {
		return num_ticket;
	}
	public void setNum_ticket(Integer num_ticket) {
		this.num_ticket = num_ticket;
	}
	public String getNum_ruc_emisor() {
		return num_ruc_emisor;
	}
	public void setNum_ruc_emisor(String num_ruc_emisor) {
		this.num_ruc_emisor = num_ruc_emisor;
	}
	public FechaBean getFec_emision_cp() {
		return fec_emision_cp;
	}
	public void setFec_emision_cp(FechaBean fec_emision_cp) {
		this.fec_emision_cp = fec_emision_cp;
	}
	public String getTip_cp() {
		return tip_cp;
	}
	public void setTip_cp(String tip_cp) {
		this.tip_cp = tip_cp;
	}
	public String getNum_serie_cp() {
		return num_serie_cp;
	}
	public void setNum_serie_cp(String num_serie_cp) {
		this.num_serie_cp = num_serie_cp;
	}
	public String getNum_cp() {
		return num_cp;
	}
	public void setNum_cp(String num_cp) {
		this.num_cp = num_cp;
	}
	public BigDecimal getMto_total() {
		return mto_total;
	}
	public void setMto_total(BigDecimal mto_total) {
		this.mto_total = mto_total;
	}
	public String getTip_doc_idecliente() {
		return tip_doc_idecliente;
	}
	public void setTip_doc_idecliente(String tip_doc_idecliente) {
		this.tip_doc_idecliente = tip_doc_idecliente;
	}
	public String getNum_doc_idecliente() {
		return num_doc_idecliente;
	}
	public void setNum_doc_idecliente(String num_doc_idecliente) {
		this.num_doc_idecliente = num_doc_idecliente;
	}
	public String getNum_cp_modif() {
		return num_cp_modif;
	}
	public void setNum_cp_modif(String num_cp_modif) {
		this.num_cp_modif = num_cp_modif;
	}
	public String getInd_vigente() {
		return ind_vigente;
	}
	public void setInd_vigente(String ind_vigente) {
		this.ind_vigente = ind_vigente;
	}
	public String getCod_usuregis() {
		return cod_usuregis;
	}
	public void setCod_usuregis(String cod_usuregis) {
		this.cod_usuregis = cod_usuregis;
	}
	public FechaBean getFec_regis() {
		return fec_regis;
	}
	public void setFec_regis(FechaBean fec_regis) {
		this.fec_regis = fec_regis;
	}
	public String getCod_usumodif() {
		return cod_usumodif;
	}
	public void setCod_usumodif(String cod_usumodif) {
		this.cod_usumodif = cod_usumodif;
	}
	public FechaBean getFec_modif() {
		return fec_modif;
	}
	public void setFec_modif(FechaBean fec_modif) {
		this.fec_modif = fec_modif;
	}
	
	
	public String getFecha_emision() {
		return fecha_emision;
	}
	public void setFecha_emision(String fecha_emision) {
		this.fecha_emision = fecha_emision;
	}
	public String getHora_emision() {
		return hora_emision;
	}
	public void setHora_emision(String hora_emision) {
		this.hora_emision = hora_emision;
	}
	
}
