package pe.gob.sunat.servicio2.registro.electronico.comppago.factura.bean;

import java.beans.BeanInfo;
import java.beans.Introspector;
import java.beans.PropertyDescriptor;
import java.io.Serializable;
import java.lang.reflect.Method;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import pe.gob.sunat.framework.spring.util.date.FechaBean;

/**
 * POJO del detalle del comprobante. Ambito: XML.
 * 
 * @author Carlos Enrique Quispe Salazar
 */
public class DetalleComprobanteBean implements Serializable {

	protected final Log log = LogFactory.getLog(getClass());

	private static final long serialVersionUID = 1L;

	private Integer identificador;
	/** ID, identificador del item */
	private String tipoComprobante;
	/** Tipo de Comprobante */
	private Integer numeroLinea;
	/** lineID, numero de linea de item */
	private String descripcion;
	/** Numero de serie y Numero de motor - description */
	private String motivo;
	/** Motivo */
	private String detalle;
	/** Es la sumatoria de descripcion y motivo */
	private String unidadMedida;
	/** unitCode, unidad de medida */
	private String cantidad;
	/** invoicedQuantity, cantidad de elementos por item */
	private String precioUnitario;
	/** priceList, precio unitario de lista */
	private String montoNeto;
	/** priceAmount, precio por cantidad */
	private String totalImpuestos;
	/** taxTotal */
	private String montoBruto;
	/** lineExtensionAmount, todo incluyendo el impuesto */
	private Integer identificadorOriginal;
	/** ID, identificador del item original */
	private DetalleImpuestoItemBean[] detalleImpuestoItemBean;
	/** Datos adicionales para impresion en el formulario */
	private String descuentoPorcentaje;
	private String descuentoMonto;
	private String igvPorcentaje;
	private String igvMonto;
	private String iscSistema;
	private String iscPorcentaje;
	private String iscMonto;
	private String otroPorcentaje;
	private String otroMonto;
	private String otroCodigoImpuesto;
	private String precioUnitarioAux;
	private String precioVentaUnitario; /* importeVenta/cantidad */
	private String valorVentaItem; /* PxQ-(Descuentos de linea) */
	// 20100209 ecg
	private String tipoItem; /* indica si es bien o servicio */
	private String tipoBeneficio; /* indica si es gravado, exonerado o inafecto */
	private String tipoBonificacion; /* indica si es o no operacion gratuita */
	private String tipoOtrosCargosTributos; /* indica si tiene otros cargos o tributos */
	private String otrosCargos;
	private String otrosTributos;
	private String otrosCargosTributos;
	private String valorVenta;
	private String importeVenta;
	private String importeVentaOriginal;
	private String codigoItem;
	/** Codigo interno de cada item que es asignado por el contribuyente */
	private String tipoItemDesc;
	private String tipoBeneficioDesc;
	// private String tipoBonificacionDesc;
	private String codigoBonificacionDesc;
	private String codigoBonificacion;
	private String unidadMedidaDesc;
	private String descripcionHidden;
	private String valorVtaUnitario;
	private String valorVtaUnitarioOriginal;
	// 20110126 mpcr
	private Integer modificado;
	/** 0/null =Original 1=Modificado */
	private String precioUnitarioOriginal;
	private String descuentoMontoOriginal;
	private String descripcionNueva;
	private String descripcionFinal;
	private String iscMontoOriginal;
	private String otrosCargosOriginal;
	private String otrosTributosOriginal;
	private String otrosCargosTributosOriginal;
	private String totalVentaPorItem;
	// 20140912 mpcr para pagos anticipados
	private String anticipo;
	private String serieFacturaAnticipo;
	private String numeroFacturaAnticipo;
	private String fechaEmisionFacturaAnticipo;
	private String importeTotalFacturaAnticipo;
	// PAS20191U210100119
	private Integer numeroBolsas;
	private String valorICBPER;
	private String importeICBPER;

	public String getValorICBPER() {
		return valorICBPER;
	}

	public void setValorICBPER(String valorICBPER) {
		this.valorICBPER = valorICBPER;
	}

	public Integer getNumeroBolsas() {
		return numeroBolsas;
	}

	public void setNumeroBolsas(Integer numeroBolsas) {
		this.numeroBolsas = numeroBolsas;
	}

	public String getImporteICBPER() {
		return importeICBPER;
	}

	public void setImporteICBPER(String importeICBPER) {
		this.importeICBPER = importeICBPER;
	}

	public String getValorVtaUnitarioOriginal() {
		return valorVtaUnitarioOriginal;
	}

	public void setValorVtaUnitarioOriginal(String valorVtaUnitarioOriginal) {
		this.valorVtaUnitarioOriginal = valorVtaUnitarioOriginal;
	}

	public String getAnticipo() {
		return anticipo;
	}

	public void setAnticipo(String anticipo) {
		this.anticipo = anticipo;
	}

	public String getSerieFacturaAnticipo() {
		return serieFacturaAnticipo;
	}

	public void setSerieFacturaAnticipo(String serieFacturaAnticipo) {
		this.serieFacturaAnticipo = serieFacturaAnticipo;
	}

	public String getNumeroFacturaAnticipo() {
		return numeroFacturaAnticipo;
	}

	public void setNumeroFacturaAnticipo(String numeroFacturaAnticipo) {
		this.numeroFacturaAnticipo = numeroFacturaAnticipo;
	}

	public String getFechaEmisionFacturaAnticipo() {
		return fechaEmisionFacturaAnticipo;
	}

	public void setFechaEmisionFacturaAnticipo(String fechaEmisionFacturaAnticipo) {
		this.fechaEmisionFacturaAnticipo = fechaEmisionFacturaAnticipo;
	}

	public String getImporteTotalFacturaAnticipo() {
		return importeTotalFacturaAnticipo;
	}

	public void setImporteTotalFacturaAnticipo(String importeTotalFacturaAnticipo) {
		this.importeTotalFacturaAnticipo = importeTotalFacturaAnticipo;
	}

	public String getImporteVentaOriginal() {
		return importeVentaOriginal;
	}

	public void setImporteVentaOriginal(String importeVentaOriginal) {
		this.importeVentaOriginal = importeVentaOriginal;
	}

	public String getPrecioUnitarioAux() {
		return precioUnitarioAux;
	}

	public void setPrecioUnitarioAux(String precioUnitarioAux) {
		this.precioUnitarioAux = precioUnitarioAux;
	}

	public String getOtrosCargosTributosOriginal() {
		return otrosCargosTributosOriginal;
	}

	public void setOtrosCargosTributosOriginal(String otrosCargosTributosOriginal) {
		this.otrosCargosTributosOriginal = otrosCargosTributosOriginal;
	}

	public String getOtrosCargosTributos() {
		return otrosCargosTributos;
	}

	public void setOtrosCargosTributos(String otrosCargosTributos) {
		this.otrosCargosTributos = otrosCargosTributos;
	}

	public String getTipoBonificacion() {
		return tipoBonificacion;
	}

	public void setTipoBonificacion(String tipoBonificacion) {
		this.tipoBonificacion = tipoBonificacion;
	}

	public String getCodigoBonificacionDesc() {
		return codigoBonificacionDesc;
	}

	public void setCodigoBonificacionDesc(String codigoBonificacionDesc) {
		this.codigoBonificacionDesc = codigoBonificacionDesc;
	}

	public String getCodigoBonificacion() {
		return codigoBonificacion;
	}

	public void setCodigoBonificacion(String codigoBonificacion) {
		this.codigoBonificacion = codigoBonificacion;

		/**
		 * Descripciones y c�digos de los tipos de afectaci�n segun el catalogo de Nro.
		 * 07 de GEM.
		 */
		if ("00".equals(codigoBonificacion)) {
			this.codigoBonificacionDesc = "-";
		} else if ("10".equals(codigoBonificacion)) {
			this.setCodigoBonificacionDesc(" ***** GRAVADO -  OPERACI�N ONEROSA *****");
		} else if ("11".equals(codigoBonificacion)) {
			this.setCodigoBonificacionDesc(" ***** PREMIO *****");
		} else if ("12".equals(codigoBonificacion)) {
			this.setCodigoBonificacionDesc(" ***** DONACI�N *****");
		} else if ("13".equals(codigoBonificacion)) {
			this.setCodigoBonificacionDesc(" ***** RETIRO *****");
		} else if ("14".equals(codigoBonificacion)) {
			this.setCodigoBonificacionDesc(" ***** PUBLICIDAD *****");
		} else if ("15".equals(codigoBonificacion)) {
			this.setCodigoBonificacionDesc(" ***** BONIFICACION *****");
		} else if ("16".equals(codigoBonificacion)) {
			this.setCodigoBonificacionDesc(" ***** ENTREGA A TRABAJADORES *****");
		} else if ("20".equals(codigoBonificacion)) {
			this.setCodigoBonificacionDesc(" ***** EXONERADO - OPERACI�N ONEROSA *****");
		} else if ("30".equals(codigoBonificacion)) {
			this.setCodigoBonificacionDesc(" ***** INAFECTO - OPERACI�N ONEROSA *****");
		} else if ("31".equals(codigoBonificacion)) {
			this.setCodigoBonificacionDesc(" ***** BONIFICACI�N *****");
		} else if ("32".equals(codigoBonificacion)) {
			this.setCodigoBonificacionDesc(" ***** RETIRO *****");
		} else if ("33".equals(codigoBonificacion)) {
			this.setCodigoBonificacionDesc(" ***** MUESTRAS M�DICAS *****");
		} else if ("34".equals(codigoBonificacion)) {
			this.setCodigoBonificacionDesc(" ***** CONVENIO COLECTIVO *****");
		} else if ("35".equals(codigoBonificacion)) {
			this.setCodigoBonificacionDesc(" ***** PREMIO *****");
		} else if ("36".equals(codigoBonificacion)) {
			this.setCodigoBonificacionDesc(" ***** PUBLICIDAD *****");

		} else if ("08".equals(codigoBonificacion)) {
			this.setCodigoBonificacionDesc(" ***** OPERACION GRATUITA *****");
		}

	}

	public String getTipoOtrosCargosTributos() {
		return tipoOtrosCargosTributos;
	}

	public void setTipoOtrosCargosTributos(String tipoOtrosCargosTributos) {
		this.tipoOtrosCargosTributos = tipoOtrosCargosTributos;
	}

	public void setTipoItemDesc(String tipoItemDesc) {
		this.tipoItemDesc = tipoItemDesc;
	}

	public String getOtrosCargosOriginal() {
		return otrosCargosOriginal;
	}

	public void setOtrosCargosOriginal(String otrosCargosOriginal) {
		this.otrosCargosOriginal = otrosCargosOriginal;
	}

	public String getOtrosTributosOriginal() {
		return otrosTributosOriginal;
	}

	public void setOtrosTributosOriginal(String otrosTributosOriginal) {
		this.otrosTributosOriginal = otrosTributosOriginal;
	}

	public String getIscMontoOriginal() {
		return iscMontoOriginal;
	}

	public void setIscMontoOriginal(String iscMontoOriginal) {
		this.iscMontoOriginal = iscMontoOriginal;
	}

	public String getDescripcionFinal() {
		return descripcionFinal;
	}

	public void setDescripcionFinal(String descripcionFinal) {
		this.descripcionFinal = descripcionFinal;
	}

	public String getDescripcionNueva() {
		return descripcionNueva;
	}

	public void setDescripcionNueva(String descripcionNueva) {
		this.descripcionNueva = descripcionNueva;
	}

	public String getDescuentoMontoOriginal() {
		return descuentoMontoOriginal;
	}

	public void setDescuentoMontoOriginal(String descuentoMontoOriginal) {
		this.descuentoMontoOriginal = descuentoMontoOriginal;
	}

	public Integer getIdentificadorOriginal() {
		return identificadorOriginal;
	}

	public void setIdentificadorOriginal(Integer identificadorOriginal) {
		this.identificadorOriginal = identificadorOriginal;
	}

	public String getPrecioUnitarioOriginal() {
		return precioUnitarioOriginal;
	}

	public void setPrecioUnitarioOriginal(String precioUnitarioOriginal) {
		this.precioUnitarioOriginal = precioUnitarioOriginal;
	}

	/** priceList, precio unitario de lista */

	public Integer getModificado() {
		return modificado;
	}

	public void setModificado(Integer modificado) {
		this.modificado = modificado;
	}

	public Integer getIdentificador() {
		return identificador;
	}

	public void setIdentificador(Integer identificador) {
		this.identificador = identificador;
	}

	public String getTipoComprobante() {
		return tipoComprobante;
	}

	public void setTipoComprobante(String tipoComprobante) {
		this.tipoComprobante = tipoComprobante;
	}

	public Integer getNumeroLinea() {
		return numeroLinea;
	}

	public void setNumeroLinea(Integer numeroLinea) {
		this.numeroLinea = numeroLinea;
	}

	public String getDescripcion() {
		return descripcion;
	}

	public void setDescripcion(String descripcion) {
		this.descripcion = descripcion;
	}

	public String getMotivo() {
		return motivo;
	}

	public void setMotivo(String motivo) {
		this.motivo = motivo;
	}

	public String getDetalle() {
		return detalle;
	}

	public void setDetalle(String detalle) {
		this.detalle = detalle;
	}

	public String getUnidadMedida() {
		return unidadMedida;
	}

	public void setUnidadMedida(String unidadMedida) {
		this.unidadMedida = unidadMedida;
	}

	public String getCantidad() {
		return cantidad;
	}

	public void setCantidad(String cantidad) {
		this.cantidad = cantidad;
	}

	public String getPrecioUnitario() {
		return precioUnitario;
	}

	public void setPrecioUnitario(String precioUnitario) {
		this.precioUnitario = precioUnitario;
	}

	public String getMontoNeto() {
		return montoNeto;
	}

	public void setMontoNeto(String montoNeto) {
		this.montoNeto = montoNeto;
	}

	public String getTotalImpuestos() {
		return totalImpuestos;
	}

	public void setTotalImpuestos(String totalImpuestos) {
		this.totalImpuestos = totalImpuestos;
	}

	public String getMontoBruto() {
		return montoBruto;
	}

	public void setMontoBruto(String montoBruto) {
		this.montoBruto = montoBruto;
	}

	public DetalleImpuestoItemBean[] getDetalleImpuestoItemBean() {
		return detalleImpuestoItemBean;
	}

	public void setDetalleImpuestoItemBean(DetalleImpuestoItemBean[] detalleImpuestoItemBean) {
		this.detalleImpuestoItemBean = detalleImpuestoItemBean;
	}

	public String getIgvPorcentaje() {
		return igvPorcentaje;
	}

	public String getDescuentoPorcentaje() {
		return descuentoPorcentaje;
	}

	public void setDescuentoPorcentaje(String descuentoPorcentaje) {
		this.descuentoPorcentaje = descuentoPorcentaje;
	}

	public String getDescuentoMonto() {
		return descuentoMonto;
	}

	public void setDescuentoMonto(String descuentoMonto) {
		this.descuentoMonto = descuentoMonto;
	}

	public void setIgvPorcentaje(String igvPorcentaje) {
		this.igvPorcentaje = igvPorcentaje;
	}

	public String getIgvMonto() {
		return igvMonto;
	}

	public void setIgvMonto(String igvMonto) {
		this.igvMonto = igvMonto;
	}

	public String getIscSistema() {
		return iscSistema;
	}

	public void setIscSistema(String iscSistema) {
		this.iscSistema = iscSistema;
	}

	public String getIscPorcentaje() {
		return iscPorcentaje;
	}

	public void setIscPorcentaje(String iscPorcentaje) {
		this.iscPorcentaje = iscPorcentaje;
	}

	public String getIscMonto() {
		return iscMonto;
	}

	public void setIscMonto(String iscMonto) {
		this.iscMonto = iscMonto;
	}

	public String getOtroPorcentaje() {
		return otroPorcentaje;
	}

	public void setOtroPorcentaje(String otroPorcentaje) {
		this.otroPorcentaje = otroPorcentaje;
	}

	public String getOtroMonto() {
		return otroMonto;
	}

	public void setOtroMonto(String otroMonto) {
		this.otroMonto = otroMonto;
	}

	public String getOtroCodigoImpuesto() {
		return otroCodigoImpuesto;
	}

	public void setOtroCodigoImpuesto(String otroCodigoImpuesto) {
		this.otroCodigoImpuesto = otroCodigoImpuesto;
	}

	public String getTipoItem() {
		return tipoItem;
	}

	public void setTipoItem(String tipoItem) {
		this.tipoItem = tipoItem;

		if ("TI01".equals(tipoItem)) {
			this.tipoItemDesc = "Bien";
		} else if ("TI02".equals(tipoItem)) {
			this.tipoItemDesc = "Servicio";
		} else {
			this.tipoItemDesc = "";
		}
	}

	public String getTipoBeneficio() {
		return tipoBeneficio;
	}

	public void setTipoBeneficio(String tipoBeneficio) {
		this.tipoBeneficio = tipoBeneficio;
	}

	public String getCodigoItem() {
		return codigoItem;
	}

	public void setCodigoItem(String codigoItem) {
		this.codigoItem = codigoItem;
	}

	public String getOtrosCargos() {
		return otrosCargos;
	}

	public void setOtrosCargos(String otrosCargos) {
		this.otrosCargos = otrosCargos;
	}

	public String getImporteVenta() {
		return importeVenta;
	}

	public void setImporteVenta(String importeVenta) {
		this.importeVenta = importeVenta;
	}

	public String getTipoItemDesc() {
		return tipoItemDesc;
	}

	public String getTipoBeneficioDesc() {
		return tipoBeneficioDesc;
	}

	/*
	 * public String getTipoBonificacion() { return tipoBonificacion; }
	 * 
	 * public void setTipoBonificacion(String tipoBonificacion) {
	 * this.tipoBonificacion = tipoBonificacion;
	 * 
	 * if ("BO01".equals(tipoBonificacion)) {
	 * this.tipoBonificacionDesc="Bonificacion"; } else {
	 * this.tipoBonificacionDesc="Ninguno"; } }
	 * 
	 * public String getTipoBonificacionDesc() { return tipoBonificacionDesc; }
	 */
	public String getDescripcionHidden() {
		return descripcionHidden;
	}

	public void setDescripcionHidden(String descripcionHidden) {
		this.descripcionHidden = descripcionHidden;
	}

	public String getUnidadMedidaDesc() {
		return unidadMedidaDesc;
	}

	public void setUnidadMedidaDesc(String unidadMedidaDesc) {
		this.unidadMedidaDesc = unidadMedidaDesc;
	}

	public String getOtrosTributos() {
		return otrosTributos;
	}

	public void setOtrosTributos(String otrosTributos) {
		this.otrosTributos = otrosTributos;
	}

	public String getValorVenta() {
		return valorVenta;
	}

	public void setValorVenta(String valorVenta) {
		this.valorVenta = valorVenta;
	}

	public String getValorVtaUnitario() {
		return valorVtaUnitario;
	}

	public void setValorVtaUnitario(String valorVtaUnitario) {
		this.valorVtaUnitario = valorVtaUnitario;
	}

	public void setTipoBeneficioDesc(String tipoBeneficio) {

		tipoBeneficioDesc = "-";

		if ("TB01".equals(tipoBeneficio)) {
			this.tipoBeneficioDesc = "Exonerado";
		}

		if ("TB02".equals(tipoBeneficio)) {
			this.tipoBeneficioDesc = "Inafecto";
		}

		if ("TB00".equals(tipoBeneficio)) {
			this.tipoBeneficioDesc = "Gravado";
		}
	}

	public String getTotalVentaPorItem() {
		return totalVentaPorItem;
	}

	public void setTotalVentaPorItem(String totalVentaPorItem) {
		this.totalVentaPorItem = totalVentaPorItem;
	}

	// public String toString(){
	// StringBuilder datos = new StringBuilder();
	//
	// datos.append("Identificador : " + (this.identificador != null ?
	// this.identificador : "null")).append("\n");
	// datos.append("Codigo Item : " + (this.codigoItem != null ? this.codigoItem :
	// "null")).append("\n");
	// datos.append("Es Bonificacion : " + (this.tipoBonificacion != null ?
	// this.tipoBonificacion : "null")).append("\n");
	// datos.append("Cantidad : " + (this.cantidad != null ? this.cantidad :
	// "null")).append("\n");
	// datos.append("Descripci�n : " + (this.descripcion!= null ? this.descripcion :
	// "null")).append("\n");
	// datos.append("Descripci�n Nueva : " + (this.descripcionNueva!= null ?
	// this.descripcionNueva : "null")).append("\n");
	// datos.append("Valor Venta : " + (this.valorVenta != null ? this.valorVenta :
	// "null")).append("\n");
	// datos.append("Precio Unitario : " + (this.precioUnitario != null ?
	// this.precioUnitario : "null")).append("\n");
	// datos.append("Precio Unitario Original: " + (this.precioUnitarioOriginal !=
	// null ? this.precioUnitarioOriginal : "null")).append("\n");
	// datos.append("Unidad de Medida : " + (this.unidadMedida!= null ?
	// this.unidadMedida : "null")).append("\n");
	// datos.append("ISC : " + (this.iscMonto!= null ? this.iscMonto :
	// "null")).append("\n");
	// datos.append("IGV : " + (this.igvMonto!= null ? this.igvMonto :
	// "null")).append("\n");
	// datos.append("Otros Cargos : " + (this.otrosCargos != null ? this.otrosCargos
	// : "null")).append("\n");
	// datos.append("Otros Tributos : " + (this.otrosTributos != null ?
	// this.otrosTributos : "null")).append("\n");
	// datos.append("Importe Venta : " + (this.importeVenta!= null ?
	// this.importeVenta : "null")).append("\n");
	//
	// return datos.toString();
	// }

	public String getPrecioVentaUnitario() {
		return precioVentaUnitario;
	}

	public void setPrecioVentaUnitario(String precioVentaUnitario) {
		this.precioVentaUnitario = precioVentaUnitario;
	}

	public String getValorVentaItem() {
		return valorVentaItem;
	}

	public void setValorVentaItem(String valorVentaItem) {
		this.valorVentaItem = valorVentaItem;
	}

	@Override
	public String toString() {
		String result = "Valores del BEAN " + this.getClass() + "\r";
		Object nill = null;
		try {
			BeanInfo info = Introspector.getBeanInfo(this.getClass());
			PropertyDescriptor[] pds = info.getPropertyDescriptors();
			Method getter = null;
			Object valor = "";
			for (PropertyDescriptor pd : pds) {
				if (!"class".equals(pd.getName())) {
					try {
						getter = new PropertyDescriptor(pd.getName(), this.getClass()).getReadMethod();
						valor = getter.invoke(this, nill);
						result = result + "[ " + pd.getName() + " ] \t" + " : "
								+ (valor instanceof FechaBean ? ((FechaBean) valor).getTimestamp() : valor) + "\r";
					} catch (Exception e) {

					}
				}
			}
		} catch (Exception e) {
			log.error(e, e);
		}
		return result;
	}
}
