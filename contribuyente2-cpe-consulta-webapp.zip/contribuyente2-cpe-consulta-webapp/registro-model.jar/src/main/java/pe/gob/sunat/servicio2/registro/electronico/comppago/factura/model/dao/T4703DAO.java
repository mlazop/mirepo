package pe.gob.sunat.servicio2.registro.electronico.comppago.factura.model.dao;


import java.util.List;
import java.util.Map;

import pe.gob.sunat.servicio2.registro.electronico.comppago.factura.model.domain.T4703Bean;


/**
 * tabla    donde  se guardan los  detalles de los resumenes  de las  boletas y sus  NC y ND
 * @author narista
 */     
public interface T4703DAO {   
       
	public  abstract  boolean registraDetAnulado(T4703Bean bean); 
	public abstract T4703Bean buscaComprobanteAnulado(String ruc, String serie, String tipdoc, Integer numdoc);
	public  abstract  List<T4703Bean> listaDetallesAnuladosRucTicket(String ruc, String  ticket ) ;   
	public abstract boolean borradoLogicoDetAnulados(T4703Bean  bean); 
	public abstract T4703Bean buscaComprobanteAnuladoORechazado(String ruc, String serie, String tipdoc, Integer numdoc);
	
	public  abstract List<T4703Bean>  buscarComprobanteAnuladoEnRango(String ruc, String serie, String tipdoc, Integer numdesde, Integer numhasta );       
	    
	public Map<String,Object> buscarFechaPresentacion(String numRuc, String codCpe, String numSerie, Integer numCpe);
}
