package pe.gob.sunat.servicio2.registro.electronico.comppago.consulta.model.dao;

import java.util.List;

import pe.gob.sunat.servicio2.registro.electronico.comppago.consulta.model.domain.T4705Bean;

public interface T4705DAOSelect {

	List<T4705Bean> buscarComprobanteEnRangos(String ruc, String codcpe, String seriecpe);
        

}