package pe.gob.sunat.servicio2.registro.electronico.comppago.factura.model.domain;

import java.io.Serializable;

import pe.gob.sunat.framework.spring.util.date.FechaBean;

public class T8248Bean implements Serializable {

	private static final long serialVersionUID = -8246694757938400977L;

	private Integer num_ticket;
	private Integer per_anual;
	private String num_ruc;
	private String nom_archivo;
	private String num_cor_envio;
	private Integer ctd_registros;
	private String per_envio;
	private String ind_vigente;
	private Integer ind_est_proceso;
	private FechaBean fec_regis;
	private String cod_usuregis;
	private FechaBean fec_modif;
	private String cod_usumodif;
	private Integer ctd_tam_det;
	
	
	public Integer getNum_ticket() {
		return num_ticket;
	}
	public void setNum_ticket(Integer num_ticket) {
		this.num_ticket = num_ticket;
	}
	public Integer getPer_anual() {
		return per_anual;
	}
	public void setPer_anual(Integer per_anual) {
		this.per_anual = per_anual;
	}
	public String getNum_ruc() {
		return num_ruc;
	}
	public void setNum_ruc(String num_ruc) {
		this.num_ruc = num_ruc;
	}
	public String getNom_archivo() {
		return nom_archivo;
	}
	public void setNom_archivo(String nom_archivo) {
		this.nom_archivo = nom_archivo;
	}
	public String getNum_cor_envio() {
		return num_cor_envio;
	}
	public void setNum_cor_envio(String num_cor_envio) {
		this.num_cor_envio = num_cor_envio;
	}
	public Integer getCtd_registros() {
		return ctd_registros;
	}
	public void setCtd_registros(Integer ctd_registros) {
		this.ctd_registros = ctd_registros;
	}
	public String getPer_envio() {
		return per_envio;
	}
	public void setPer_envio(String per_envio) {
		this.per_envio = per_envio;
	}
	public String getInd_vigente() {
		return ind_vigente;
	}
	public void setInd_vigente(String ind_vigente) {
		this.ind_vigente = ind_vigente;
	}
	public Integer getInd_est_proceso() {
		return ind_est_proceso;
	}
	public void setInd_est_proceso(Integer ind_est_proceso) {
		this.ind_est_proceso = ind_est_proceso;
	}
	public FechaBean getFec_regis() {
		return fec_regis;
	}
	public void setFec_regis(FechaBean fec_regis) {
		this.fec_regis = fec_regis;
	}
	public String getCod_usuregis() {
		return cod_usuregis;
	}
	public void setCod_usuregis(String cod_usuregis) {
		this.cod_usuregis = cod_usuregis;
	}
	public FechaBean getFec_modif() {
		return fec_modif;
	}
	public void setFec_modif(FechaBean fec_modif) {
		this.fec_modif = fec_modif;
	}
	public String getCod_usumodif() {
		return cod_usumodif;
	}
	public void setCod_usumodif(String cod_usumodif) {
		this.cod_usumodif = cod_usumodif;
	}
	public Integer getCtd_tam_det() {
		return ctd_tam_det;
	}
	public void setCtd_tam_det(Integer ctd_tam_det) {
		this.ctd_tam_det = ctd_tam_det;
	}
	
	
		
	
}
