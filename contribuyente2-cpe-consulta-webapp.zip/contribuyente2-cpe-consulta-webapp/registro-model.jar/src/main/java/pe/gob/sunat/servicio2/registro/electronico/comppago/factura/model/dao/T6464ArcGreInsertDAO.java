/**
 * 
 */
package pe.gob.sunat.servicio2.registro.electronico.comppago.factura.model.dao;

import pe.gob.sunat.servicio2.registro.electronico.comppago.factura.model.domain.T6464ArcGreBean;


/**
 * @author evargasc
 *
 */
public interface T6464ArcGreInsertDAO {

	
	public void insertDocument(T6464ArcGreBean data);
}


