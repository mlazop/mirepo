package pe.gob.sunat.servicio2.registro.comppago.factura.gem.contingencia.model.domain;

import java.io.Serializable;

import pe.gob.sunat.framework.spring.util.date.FechaBean;

public class T5678Bean implements Serializable{
	

	private static final long serialVersionUID = 9029959794017239305L;
	private Long	numeTicket;
	private Integer	numeFila;
	private Integer	numeColumna;
	private String	codigoError;
	private String	usuarioRegistra;
	private FechaBean	fechaRegistra;
	private String valor;

	public Long getNumeTicket() {
		return numeTicket;
	}
	public String getValor() {
		return valor;
	}
	public void setValor(String valor) {
		this.valor = valor;
	}

	public void setNumeTicket(Long numeTicket) {
		this.numeTicket = numeTicket;
	}

	public Integer getNumeFila() {
		return numeFila;
	}

	public void setNumeFila(Integer numeFila) {
		this.numeFila = numeFila;
	}
	public Integer getNumeColumna() {
		return numeColumna;
	}

	
	public void setNumeColumna(Integer numeColumna) {
		this.numeColumna = numeColumna;
	}

	public String getCodigoError() {
		return codigoError;
	}

	public void setCodigoError(String codigoError) {
		this.codigoError = codigoError;
	}

	public String getUsuarioRegistra() {
		return usuarioRegistra;
	}

	public void setUsuarioRegistra(String usuarioRegistra) {
		this.usuarioRegistra = usuarioRegistra;
	}

	public FechaBean getFechaRegistra() {
		return fechaRegistra;
	}

	public void setFechaRegistra(FechaBean fechaRegistra) {
		this.fechaRegistra = fechaRegistra;
	}
	
	

}
