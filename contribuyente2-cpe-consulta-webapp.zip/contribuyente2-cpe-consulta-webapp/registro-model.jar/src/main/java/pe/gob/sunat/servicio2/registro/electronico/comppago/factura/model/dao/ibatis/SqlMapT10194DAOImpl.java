package pe.gob.sunat.servicio2.registro.electronico.comppago.factura.model.dao.ibatis;

import pe.gob.sunat.framework.spring.util.dao.SqlMapDAOBase;
import pe.gob.sunat.servicio2.registro.electronico.comppago.factura.model.dao.T10194DAO;
import pe.gob.sunat.servicio2.registro.electronico.comppago.factura.model.domain.T10194Bean;

@SuppressWarnings({"deprecation", "unchecked", "rawtypes"})
public class SqlMapT10194DAOImpl extends SqlMapDAOBase implements T10194DAO {

    @Override
    public T10194Bean findByFiltro(T10194Bean param) {
        Object obj = getSqlMapClientTemplate().queryForObject("T10194.findByFiltro", param);
        return (obj != null ? (T10194Bean) obj : null);
    }
    
    @Override
    public T10194Bean findByFiltroRucSerieCodNum(T10194Bean param) {
        Object obj = getSqlMapClientTemplate().queryForObject("T10194.findByFiltroRucSerieCodNum", param);
        return (obj != null ? (T10194Bean) obj : null);
    }

}
