package pe.gob.sunat.servicio2.registro.comppago.factura.gem.contingencia.model.dao;

import java.io.Serializable;
import java.util.HashMap;
import java.util.List;

import pe.gob.sunat.servicio2.registro.comppago.factura.gem.contingencia.model.domain.T5675Bean;
import pe.gob.sunat.servicio2.registro.comppago.factura.gem.contingencia.model.domain.T5676Bean;
import pe.gob.sunat.servicio2.registro.comppago.factura.gem.contingencia.model.domain.T5676QueryParameterBean;

@SuppressWarnings({"rawtypes"})
public interface T5676DAO extends Serializable{

	public void updateVigenciaByTicket(HashMap map);
	
	public void insertarContingenciaDetalle(final List<T5676Bean> datos);
	
	public void actualizarVigenciaContingenciaDetalle(T5675Bean t5675Bean);
	
	public Integer contarContingenciaDetalleByNumeRuc(T5676Bean t5676Bean);
	
	public Integer contarContingenciaDetalleByComprobante(T5676Bean t5676Bean);
	
	public List<T5676Bean> obtenerListaComprobantesContingencia(HashMap map);

	public List<T5676Bean> obtenerValidacionComprobantesContingencia(T5676QueryParameterBean t5676QueryParameterBean);
	
}
