package pe.gob.sunat.servicio2.registro.model.dao.ibatis;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import pe.gob.sunat.framework.spring.util.dao.SqlMapDAOBase;
import pe.gob.sunat.servicio2.registro.model.dao.T130DAO;
import pe.gob.sunat.servicio2.registro.model.domain.T130Bean;
@SuppressWarnings({"deprecation","unchecked", "rawtypes"})
public class SqlMapT130DAOImpl extends SqlMapDAOBase implements T130DAO {

	@Override
	public List<T130Bean> findByRUC_Serie_TipoDoc(T130Bean bean) {
		if (log.isDebugEnabled()) {log.debug("SQLMapDao findByRUC_Serie_TipoDoc (" + bean.getT130_tipdoc() + ")");}
		
		return (List<T130Bean>) getSqlMapClientTemplate().queryForList("T130.findByRUC_Serie_TipoDoc", bean);
	}
	
	@Override
	public Integer findComprobanteAutorizado(String numeroRuc,
			String tipodocumento, String serie, Integer numero) {
		if (this.log.isDebugEnabled()) this.log.debug("SqlMapT130DAOImpl- findComprobanteAutorizado("
				+ numeroRuc +  " "+	tipodocumento +  " "+ serie +  " "+ numero +")");
		Map param = new  HashMap(); 
		param.put("numeroRuc",numeroRuc );
		param.put("tipodocumento",tipodocumento );
		param.put("serie", serie);		
		param.put("numdocumentodesde",numero );
		param.put("numdocumentohasta", numero);
	    Integer count = (Integer)getSqlMapClientTemplate().queryForObject("T130.findComprobanteAutorizado", param);
	    return count;
	}

	@Override
	public Integer findComprobanteAutorizadoRange(String numeroRuc,
			String tipodocumento, String serie, String numeroCPDesde,
			String numeroCPHasta) {

		if (this.log.isDebugEnabled()) this.log.debug("SqlMapT130DAOImpl- findComprobanteAutorizado("
				+ numeroRuc +  " "+	tipodocumento +  " "+ serie +  " "+ numeroCPDesde +" "+ numeroCPHasta +")");
		
		Map param = new  HashMap(); 
		param.put("numeroRuc",numeroRuc );
		param.put("tipodocumento",tipodocumento );
		param.put("serie", Integer.parseInt(serie));		
		param.put("numdocumentodesde",Integer.parseInt(numeroCPDesde));
		
		if (numeroCPHasta.equals("")||numeroCPHasta.equals("-"))
		{
			param.put("numdocumentohasta", Integer.parseInt(numeroCPDesde));
		}
		else
		{
			param.put("numdocumentohasta", Integer.parseInt(numeroCPHasta));
		}
		
		try {
		    Integer count = (Integer)getSqlMapClientTemplate().queryForObject("T130.findComprobanteAutorizado", param);
		    return count;
			
		} catch (Exception e) {
			// : handle exception
			this.log.debug(e.getMessage());
			return 0;
		}
		

		
	}
	
	/* DCERRENO - 17/06/2015 - INICIO */
	@Override
	public Integer getSerieAutorizada(T130Bean t130Bean) {
		Integer retorno = (Integer) getSqlMapClientTemplate().queryForObject("T130.getSerieAutorizada", t130Bean);
		
		return retorno;
		
	}
	/* DCERRENO - 17/06/2015 - FIN */
	

}
