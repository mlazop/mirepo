package pe.gob.sunat.servicio2.registro.electronico.comppago.factura.model.domain;

import java.util.Date;

public class T6576ArchRetBean {
	
    private String indModo;
    private Object numTicket;
    private String nomArchivo;
    private Date fecRegis;
    private String codUsuRegis;
    private Date fecModif;
    private String codUsumodif;
    private byte[] arcArchivo;
    
    private String arc_xml;
    
	public String getIndModo() {
		return indModo;
	}
	public void setIndModo(String indModo) {
		this.indModo = indModo;
	}
	public Object getNumTicket() {
		return numTicket;
	}
	public void setNumTicket(Object numTicket) {
		this.numTicket = numTicket;
	}
	public String getNomArchivo() {
		return nomArchivo;
	}
	public void setNomArchivo(String nomArchivo) {
		this.nomArchivo = nomArchivo;
	}
	public Date getFecRegis() {
		return fecRegis;
	}
	public void setFecRegis(Date fecRegis) {
		this.fecRegis = fecRegis;
	}
	public String getCodUsuRegis() {
		return codUsuRegis;
	}
	public void setCodUsuRegis(String codUsuRegis) {
		this.codUsuRegis = codUsuRegis;
	}
	public Date getFecModif() {
		return fecModif;
	}
	public void setFecModif(Date fecModif) {
		this.fecModif = fecModif;
	}
	public String getCodUsumodif() {
		return codUsumodif;
	}
	public void setCodUsumodif(String codUsumodif) {
		this.codUsumodif = codUsumodif;
	}
	public byte[] getArcArchivo() {
		return arcArchivo;
	}
	public void setArcArchivo(byte[] arcArchivo) {
		this.arcArchivo = arcArchivo;
	}
    
	public String getArc_xml() {
		return arc_xml;
	}
	public void setArc_xml(String arc_xml) {
		this.arc_xml = arc_xml;
	}
    
}