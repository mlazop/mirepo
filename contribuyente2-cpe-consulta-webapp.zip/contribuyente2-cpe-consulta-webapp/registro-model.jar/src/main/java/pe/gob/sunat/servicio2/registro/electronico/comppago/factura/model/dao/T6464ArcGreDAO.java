/**
 * 
 */
package pe.gob.sunat.servicio2.registro.electronico.comppago.factura.model.dao;

import pe.gob.sunat.servicio2.registro.electronico.comppago.factura.model.domain.T6464ArcGreBean;


/**
 * @author evargasc
 *
 */
public interface T6464ArcGreDAO {

	
	public T6464ArcGreBean selectDoc(String numRuc, String codCpe, String numSerieCpe, Integer numCpe);
	
	public T6464ArcGreBean selectByPrimaryKey(String nroTicket, String modo);
	
}


