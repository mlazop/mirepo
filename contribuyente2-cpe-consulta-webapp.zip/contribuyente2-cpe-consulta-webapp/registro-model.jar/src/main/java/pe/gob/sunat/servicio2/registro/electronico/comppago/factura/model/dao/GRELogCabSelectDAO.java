package pe.gob.sunat.servicio2.registro.electronico.comppago.factura.model.dao;

import pe.gob.sunat.servicio2.registro.electronico.comppago.factura.model.domain.BillLogCab;

public interface GRELogCabSelectDAO {
	
	public BillLogCab selectByParam(String ticket, Integer correlativo);
	
	public void update(String ticket, Integer correlativo);
	
	public void update(BillLogCab data);
	
	
}
