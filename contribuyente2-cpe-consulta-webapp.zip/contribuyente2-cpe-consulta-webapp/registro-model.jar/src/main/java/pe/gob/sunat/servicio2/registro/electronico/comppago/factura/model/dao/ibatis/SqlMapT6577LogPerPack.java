package pe.gob.sunat.servicio2.registro.electronico.comppago.factura.model.dao.ibatis;

import org.springframework.orm.ibatis.support.SqlMapClientDaoSupport;

import pe.gob.sunat.servicio2.registro.electronico.comppago.factura.model.dao.LogPerPackDAO;
import pe.gob.sunat.servicio2.registro.electronico.comppago.factura.model.domain.BillLogPack;

@SuppressWarnings("deprecation")
public class SqlMapT6577LogPerPack  extends SqlMapClientDaoSupport implements  LogPerPackDAO {
	
	@Override
	public Integer actualizaEstado(String numTicket) {
		return getSqlMapClientTemplate().update("PerLogPack.update", numTicket);
	}

	@Override
	public Integer actualizaEstado(BillLogPack data) {

		return getSqlMapClientTemplate().update("PerLogPack.updateLogPack", data);
		
	}

}
