package pe.gob.sunat.servicio2.registro.electronico.comppago.factura.model.dao.ibatis;

import org.springframework.orm.ibatis.support.SqlMapClientDaoSupport;

import pe.gob.sunat.servicio2.registro.electronico.comppago.factura.model.dao.LogCabSelectDAO;
import pe.gob.sunat.servicio2.registro.electronico.comppago.factura.model.domain.BillLogCab;

@SuppressWarnings({ "deprecation", "unchecked" })
public class SqlMapT6578LogPerCab  extends SqlMapClientDaoSupport implements LogCabSelectDAO{

	@Override
	public BillLogCab obtenerEstado(String numTicket) {
		
		return (BillLogCab) getSqlMapClientTemplate().queryForObject("PerLogCab.obtenerEstado", numTicket);
		
	}

	@Override
	public void update(String numTicket) {
		getSqlMapClientTemplate().update("PerLogCab.update", numTicket);
	}

	@Override
	public void update(BillLogCab data) {
		
		getSqlMapClientTemplate().update("PerLogCab.updateLogCab", data);
		
	}

	
}
