package pe.gob.sunat.servicio2.registro.electronico.comppago.percepcion.model.dao.ibatis;
import java.util.HashMap;

import org.springframework.stereotype.Repository;

import pe.gob.sunat.servicio2.registro.electronico.comppago.percepcion.model.PercepcionBean;
import pe.gob.sunat.servicio2.registro.electronico.comppago.percepcion.model.dao.PercepcionDAO;

@Repository("percepcionDAO")
public class SqlMapPercepcionDAO extends BaseCpeleDAO implements PercepcionDAO {

	@SuppressWarnings("deprecation")
	@Override
	public PercepcionBean selectPorEmisor(PercepcionBean percepcionBean) {
		return (PercepcionBean) getSqlMapClientTemplate().queryForObject("t6571.selectPorEmisor", percepcionBean);
	}
	
	/// INICIO PAS20191U210100160
	@Override
	public String buscarCanalEnvio(HashMap<String, Object> mapParametros) {
		return (String) getSqlMapClientTemplate().queryForObject("t6571.buscarCanalEnvio", mapParametros);
	}

	@Override
	public int countRechazo(HashMap<String, Object> mapParametros) {
		return (Integer) getSqlMapClientTemplate().queryForObject("t6571.countRechazo", mapParametros);
	}
	/// FIN PAS20191U210100160
}
