package pe.gob.sunat.servicio2.registro.electronico.comppago.retencion.model;

import java.io.Serializable;
import java.math.BigDecimal;
import java.util.Date;

public class RetDocRelBean implements Serializable{
	
	private static final long serialVersionUID = 1L;
	
	private String numRuc;
	private String codCpe;
	private String numSerieCpe;
	private int numCpe;
	private String codTipoCpeRel;
	private String numSerieCpeRel;
	private String numCpeRel;
	private Date fechaEmisionCpeRel;
	private BigDecimal montoTotalCpeRel;
	private String codMonedaCpeRel;
	private Date fechaPago;
	private String numPago;
	private BigDecimal montoPago;
	private String codMonedaPago;
	private BigDecimal montoRetenido;
	private Date fechaRetencion;
	private BigDecimal montoPagado;
	private BigDecimal montoTipoCambio;
	private Date fechaRegistro;
	private String codUsuRegistro;
	private Date fechaModificacion;
	private String codUsuModificacion;
	//wsandoval
	private String indCpeRelRevertido;
	
	public String getNumRuc() {
		return numRuc;
	}
	public void setNumRuc(String numRuc) {
		this.numRuc = numRuc;
	}
	public String getCodCpe() {
		return codCpe;
	}
	public void setCodCpe(String codCpe) {
		this.codCpe = codCpe;
	}
	public String getNumSerieCpe() {
		return numSerieCpe;
	}
	public void setNumSerieCpe(String numSerieCpe) {
		this.numSerieCpe = numSerieCpe;
	}
	public int getNumCpe() {
		return numCpe;
	}
	public void setNumCpe(int numCpe) {
		this.numCpe = numCpe;
	}
	public String getCodTipoCpeRel() {
		return codTipoCpeRel;
	}
	public void setCodTipoCpeRel(String codTipoCpeRel) {
		this.codTipoCpeRel = codTipoCpeRel;
	}
	public String getNumSerieCpeRel() {
		return numSerieCpeRel;
	}
	public void setNumSerieCpeRel(String numSerieCpeRel) {
		this.numSerieCpeRel = numSerieCpeRel;
	}
	public String getNumCpeRel() {
		return numCpeRel;
	}
	public void setNumCpeRel(String numCpeRel) {
		this.numCpeRel = numCpeRel;
	}
	public Date getFechaEmisionCpeRel() {
		return fechaEmisionCpeRel;
	}
	public void setFechaEmisionCpeRel(Date fechaEmisionCpeRel) {
		this.fechaEmisionCpeRel = fechaEmisionCpeRel;
	}
	public BigDecimal getMontoTotalCpeRel() {
		return montoTotalCpeRel;
	}
	public void setMontoTotalCpeRel(BigDecimal montoTotalCpeRel) {
		this.montoTotalCpeRel = montoTotalCpeRel;
	}
	public String getCodMonedaCpeRel() {
		return codMonedaCpeRel;
	}
	public void setCodMonedaCpeRel(String codMonedaCpeRel) {
		this.codMonedaCpeRel = codMonedaCpeRel;
	}
	public Date getFechaPago() {
		return fechaPago;
	}
	public void setFechaPago(Date fechaPago) {
		this.fechaPago = fechaPago;
	}
	public String getNumPago() {
		return numPago;
	}
	public void setNumPago(String numPago) {
		this.numPago = numPago;
	}
	public BigDecimal getMontoPago() {
		return montoPago;
	}
	public void setMontoPago(BigDecimal montoPago) {
		this.montoPago = montoPago;
	}
	public String getCodMonedaPago() {
		return codMonedaPago;
	}
	public void setCodMonedaPago(String codMonedaPago) {
		this.codMonedaPago = codMonedaPago;
	}
	public BigDecimal getMontoRetenido() {
		return montoRetenido;
	}
	public void setMontoRetenido(BigDecimal montoRetenido) {
		this.montoRetenido = montoRetenido;
	}
	public Date getFechaRetencion() {
		return fechaRetencion;
	}
	public void setFechaRetencion(Date fechaRetencion) {
		this.fechaRetencion = fechaRetencion;
	}
	public BigDecimal getMontoPagado() {
		return montoPagado;
	}
	public void setMontoPagado(BigDecimal montoPagado) {
		this.montoPagado = montoPagado;
	}
	public BigDecimal getMontoTipoCambio() {
		return montoTipoCambio;
	}
	public void setMontoTipoCambio(BigDecimal montoTipoCambio) {
		this.montoTipoCambio = montoTipoCambio;
	}
	public Date getFechaRegistro() {
		return fechaRegistro;
	}
	public void setFechaRegistro(Date fechaRegistro) {
		this.fechaRegistro = fechaRegistro;
	}
	public String getCodUsuRegistro() {
		return codUsuRegistro;
	}
	public void setCodUsuRegistro(String codUsuRegistro) {
		this.codUsuRegistro = codUsuRegistro;
	}
	public Date getFechaModificacion() {
		return fechaModificacion;
	}
	public void setFechaModificacion(Date fechaModificacion) {
		this.fechaModificacion = fechaModificacion;
	}
	public String getCodUsuModificacion() {
		return codUsuModificacion;
	}
	public void setCodUsuModificacion(String codUsuModificacion) {
		this.codUsuModificacion = codUsuModificacion;
	}
	public String getIndCpeRelRevertido() {
		return indCpeRelRevertido;
	}
	public void setIndCpeRelRevertido(String indCpeRelRevertido) {
		this.indCpeRelRevertido = indCpeRelRevertido;
	}
}
