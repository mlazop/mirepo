package pe.gob.sunat.servicio2.registro.model.domain;

import java.io.Serializable;

import pe.gob.sunat.framework.spring.util.date.FechaBean;

public class T122Bean implements Serializable {


	/**
	 * 
	 */
	private static final long serialVersionUID = -5399026510369994174L;
	private String t122_numreg;
	private String t122_numruc;
	private Integer t122_correl;
	private Integer t122_serie;
	private String t122_tipdoc;
	private Integer t122_ultemi;
	private Integer t122_ultdel;
	private Integer t122_ultal;
	private Integer t122_autal;
	private Integer t122_indice;
	private FechaBean t122_fecven;
	private String t122_userna;
	private FechaBean t122_fecact;
	
	public String getT122_numreg() {
		return t122_numreg;
	}
	public void setT122_numreg(String t122Numreg) {
		t122_numreg = t122Numreg;
	}
	public String getT122_numruc() {
		return t122_numruc;
	}
	public void setT122_numruc(String t122Numruc) {
		t122_numruc = t122Numruc;
	}
	public Integer getT122_correl() {
		return t122_correl;
	}
	public void setT122_correl(Integer t122Correl) {
		t122_correl = t122Correl;
	}
	public Integer getT122_serie() {
		return t122_serie;
	}
	public void setT122_serie(Integer t122Serie) {
		t122_serie = t122Serie;
	}
	public String getT122_tipdoc() {
		return t122_tipdoc;
	}
	public void setT122_tipdoc(String t122Tipdoc) {
		t122_tipdoc = t122Tipdoc;
	}
	public Integer getT122_ultemi() {
		return t122_ultemi;
	}
	public void setT122_ultemi(Integer t122Ultemi) {
		t122_ultemi = t122Ultemi;
	}
	public Integer getT122_ultdel() {
		return t122_ultdel;
	}
	public void setT122_ultdel(Integer t122Ultdel) {
		t122_ultdel = t122Ultdel;
	}
	public Integer getT122_ultal() {
		return t122_ultal;
	}
	public void setT122_ultal(Integer t122Ultal) {
		t122_ultal = t122Ultal;
	}
	public Integer getT122_autal() {
		return t122_autal;
	}
	public void setT122_autal(Integer t122Autal) {
		t122_autal = t122Autal;
	}
	public Integer getT122_indice() {
		return t122_indice;
	}
	public void setT122_indice(Integer t122Indice) {
		t122_indice = t122Indice;
	}
	public FechaBean getT122_fecven() {
		return t122_fecven;
	}
	public void setT122_fecven(FechaBean t122Fecven) {
		t122_fecven = t122Fecven;
	}
	public String getT122_userna() {
		return t122_userna;
	}
	public void setT122_userna(String t122Userna) {
		t122_userna = t122Userna;
	}
	public FechaBean getT122_fecact() {
		return t122_fecact;
	}
	public void setT122_fecact(FechaBean t122Fecact) {
		t122_fecact = t122Fecact;
	}


}
