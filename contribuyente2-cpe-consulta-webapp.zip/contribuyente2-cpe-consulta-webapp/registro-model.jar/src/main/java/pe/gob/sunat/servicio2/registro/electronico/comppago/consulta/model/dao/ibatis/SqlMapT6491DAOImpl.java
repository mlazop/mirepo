package pe.gob.sunat.servicio2.registro.electronico.comppago.consulta.model.dao.ibatis;

import org.springframework.orm.ibatis.support.SqlMapClientDaoSupport;

import pe.gob.sunat.servicio2.registro.electronico.comppago.consulta.model.dao.T6491DAO;
import pe.gob.sunat.servicio2.registro.electronico.comppago.consulta.model.domain.T6491Bean;

@SuppressWarnings("deprecation")
public class SqlMapT6491DAOImpl extends SqlMapClientDaoSupport implements T6491DAO{

	public void inserta(T6491Bean record){
		getSqlMapClientTemplate().insert("T6491.inserta", record);
	}
}
