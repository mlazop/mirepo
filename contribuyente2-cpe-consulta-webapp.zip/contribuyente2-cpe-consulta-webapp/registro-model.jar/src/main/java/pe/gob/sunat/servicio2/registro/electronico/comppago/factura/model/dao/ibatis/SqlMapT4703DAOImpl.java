package pe.gob.sunat.servicio2.registro.electronico.comppago.factura.model.dao.ibatis;


import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import pe.gob.sunat.framework.spring.util.dao.SqlMapDAOBase;
import pe.gob.sunat.servicio2.registro.electronico.comppago.factura.model.dao.T4703DAO;
import pe.gob.sunat.servicio2.registro.electronico.comppago.factura.model.domain.T4703Bean;

@SuppressWarnings({"deprecation","unchecked", "rawtypes"})
public class SqlMapT4703DAOImpl  extends SqlMapDAOBase implements T4703DAO{     
	    
	public boolean registraDetAnulado(T4703Bean bean)  {
		boolean  flag =  false;		
		log.debug("entro a registraDetAnulado");		
		getSqlMapClientTemplate().insert("DetAnulado.registraDetAnulado", bean);
		log.debug("comprobante anulado registrado .");
		flag = true; 
		return flag; 
	}


	public T4703Bean buscaComprobanteAnulado(String ruc, String serie, String tipdoc, Integer numdoc)  {
		log.debug("entro a listaRangosPorRucSerieTipdoc)");		
		T4703Bean resp = new T4703Bean();		
		
		Map  m = new  HashMap(); 
		m.put("ruc", ruc); 
		m.put("serie", serie); 
		m.put("tipdoc", tipdoc); 
		m.put("numdoc", numdoc); 
		resp=(T4703Bean)getSqlMapClientTemplate().queryForObject("DetAnulado.findByRucSerieTipdocNumdocAnulado", m);
		
		return resp;
	}

	public List<T4703Bean> listaDetallesAnuladosRucTicket(String ruc, String ticket)  {
		log.debug("entro a listaDetallesAnuladosRucfecha ruc: "+ ruc + " ticket: "+ ticket);		
		List<T4703Bean> lista = new ArrayList<T4703Bean>();			
		Map  m = new  HashMap(); 
		m.put("ruc", ruc); 
		m.put("ticket", ticket); 
		lista=getSqlMapClientTemplate().queryForList("DetAnulado.findByRucTicketActivoDetAnulado", m);
		log.debug(" se encontraron : "+  lista.size()+" elementos");
		return lista;
	}
	
	 
	@Override
	public boolean borradoLogicoDetAnulados(T4703Bean  bean)  {
		boolean  flag =  false;
		log.debug("entro a borradoLogicoDetAnulados");	
		getSqlMapClientTemplate().delete("DetAnulado.eliminaLogicoDetAnulado", bean);	
		log.debug(" detalleDeAnulados estados actualizados a  eliminados logicos ");
		flag = true; 
		return flag; 
	}

    
	@Override
	public T4703Bean buscaComprobanteAnuladoORechazado(String ruc, String serie, String tipdoc, Integer numdoc) {
		log.debug("entro a buscaComprobanteAnuladoORechazado)");		
		T4703Bean resp = new T4703Bean();		
		
		Map  m = new  HashMap(); 
		m.put("ruc", ruc); 
		m.put("serie", serie); 
		m.put("tipdoc", tipdoc); 
		m.put("numdoc", numdoc); 
		resp=(T4703Bean)getSqlMapClientTemplate().queryForObject("DetAnulado.findByRucSerieTipdocNumdocAnuladooRechazado", m);
		
		return resp;
	}


	@Override
	public List<T4703Bean> buscarComprobanteAnuladoEnRango(String ruc,
			String serie, String tipdoc, Integer numdesde, Integer numhasta) {
		List<T4703Bean> lista = new ArrayList<T4703Bean>();
		Map  param = new HashMap(); 
		param.put("ruc", ruc); 
		param.put("tipodoc", serie);
		param.put("serie", tipdoc); 
		param.put("desde", numdesde); 
		param.put("hasta", numhasta); 
		lista=getSqlMapClientTemplate().queryForList("DetAnulado.findByRucActivoRangoDetAnulado", param);
		return lista;
	}
	
	@Override
	public Map<String,Object> buscarFechaPresentacion(String numRuc, String codCpe, String numSerie, Integer numCpe){
		Map<String, Object> params = new HashMap<String, Object>(); 
		params.put("num_ruc", numRuc);
		params.put("cod_cpe", codCpe); 
		params.put("num_serie_cpe", numSerie); 
		params.put("num_cpe", numCpe); 
		
		return (Map<String,Object>)getSqlMapClientTemplate().queryForObject("DetAnulado.buscaFechaBaja", params);		
	}
	
}








