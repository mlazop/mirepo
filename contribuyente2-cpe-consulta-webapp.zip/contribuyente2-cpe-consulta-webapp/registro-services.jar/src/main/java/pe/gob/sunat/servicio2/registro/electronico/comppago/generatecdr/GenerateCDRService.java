package pe.gob.sunat.servicio2.registro.electronico.comppago.generatecdr;


public interface GenerateCDRService {

	ConstanciaEnvio generate(Envio envio);

	ConstanciaEnvio generate(ErrorDetail error, ComprobanteElectronico cpe,
			String filename, String usuarioEnvio);

}
