package pe.gob.sunat.servicio2.registro.electronico.comppago.generatecdr;

import java.util.Date;

import org.apache.commons.lang.ObjectUtils;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import pe.gob.sunat.servicio2.registro.electronico.comppago.factura.model.dao.T4241DAO;
import pe.gob.sunat.servicio2.registro.electronico.comppago.factura.model.dao.T4541DAO;
import pe.gob.sunat.servicio2.registro.electronico.comppago.factura.model.dao.T6460CabGreDAO;
import pe.gob.sunat.servicio2.registro.electronico.comppago.factura.model.dao.T6571PercepcionSelectDAO;
import pe.gob.sunat.servicio2.registro.electronico.comppago.factura.model.dao.T6573RetencionSelectDAO;
import pe.gob.sunat.servicio2.registro.electronico.comppago.factura.model.domain.T4241Bean;
import pe.gob.sunat.servicio2.registro.electronico.comppago.factura.model.domain.T4537Bean;
import pe.gob.sunat.servicio2.registro.electronico.comppago.factura.model.domain.T4541Bean;
import pe.gob.sunat.servicio2.registro.electronico.comppago.factura.model.domain.T6460CabGreBean;
import pe.gob.sunat.servicio2.registro.electronico.comppago.factura.model.domain.T6571PercepcionBean;
import pe.gob.sunat.servicio2.registro.electronico.comppago.factura.model.domain.T6573RetencionBean;

public class ReconstruirConstanciaFacturaNotaServiceImpl implements
		ReconstruirConstanciaService {
	
	private T4541DAO selectFeAnuladoDAO;
	
	private T4241DAO selectCabcpeDAO;
	
	private T6571PercepcionSelectDAO t6571Dao;
	
	private T6573RetencionSelectDAO t6573Dao;
	
	private T6460CabGreDAO t6460Dao;
	
	private GenerateCDRService generateCDRService;
	
	protected final Log log = LogFactory.getLog(getClass());
	

	public void setT6571Dao(T6571PercepcionSelectDAO t6571Dao) {
		this.t6571Dao = t6571Dao;
	}


	public void setT6573Dao(T6573RetencionSelectDAO t6573Dao) {
		this.t6573Dao = t6573Dao;
	}

	public void setT6460Dao(T6460CabGreDAO t6460Dao) {
		this.t6460Dao = t6460Dao;
	}


	@Override
	public ConstanciaEnvio reconstuirConstancia(T4537Bean blogCba) {
		
		
		String[] nombreArchivo = blogCba.getNombreArchivo().split("-");
        String rucEmisor = nombreArchivo[0];
        String tipoComprobante = nombreArchivo[1];

        String numeroSerie = nombreArchivo[2];
        Integer numeroComprobante = new Integer(nombreArchivo[3].split("\\.")[0]);
        
        
        PkComprobante pkcpe = new PkComprobante(rucEmisor, tipoComprobante, numeroSerie, numeroComprobante.toString());
        
        Contribuyente emisor = new Contribuyente("6", rucEmisor, "");
        
        Contribuyente receptor = new Contribuyente("-", "-", "-");
        
        Date fechaEmision = blogCba.getFechaInicio().getSQLDate();
        
        ComprobanteElectronico cpe = null;
        
        ConstanciaEnvio constancia = null;
        
        
		T4241Bean factura = selectCabcpeDAO.findByPKAndTicket(rucEmisor, numeroSerie, numeroComprobante, tipoComprobante, blogCba.getTicket());
        // solo valido para factura notas de credito y notas de debito
        
        if (factura == null ) {
        	
        	ErrorDetail error = null;

            T4541Bean t4541Bean = selectFeAnuladoDAO.findByPKAndTicket(rucEmisor, numeroSerie, numeroComprobante, tipoComprobante, blogCba.getTicket());

            if (t4541Bean == null) {
                error = new ErrorDetail.Builder(blogCba.getTicket(), blogCba.getCorrelativo(), 200, "La Boleta debe se haber sido informada").build();
                
            } else {
                // genera constancia con error
                
            	pkcpe = new PkComprobante(t4541Bean.getNum_ruc(), t4541Bean.getCod_cpe(), t4541Bean.getNum_serie_cpe(), t4541Bean.getNum_cpe().toString());
                
                error = new ErrorDetail.Builder(blogCba.getTicket(), blogCba.getCorrelativo(), new Integer(t4541Bean.getCod_error()), "El comprobante fue anulado").build();
                
            }
            
            cpe = new ComprobanteElectronico(pkcpe, emisor, receptor, fechaEmision);
            
            constancia = generateCDRService.generate(error, cpe, blogCba.getNombreArchivo(), blogCba.getUsuarioModificador());
            
            
        } else {
        	
        	String tipoComprobanteReceptor = ObjectUtils.toString(factura.getCod_docide_recep(), "-");
        	
        	String numDocumentoReceptor = factura.getNum_docide_recep();
        	
        	receptor = new Contribuyente(tipoComprobanteReceptor, numDocumentoReceptor, "");
        	
        	fechaEmision = factura.getFec_emision().getSQLDate(); 
        	
        	cpe = new ComprobanteElectronico(pkcpe, emisor, receptor, fechaEmision);
        	
        	Envio envio = new Envio(blogCba.getTicket(), blogCba.getCorrelativo(), blogCba.getUsuarioModificador(), blogCba.getNombreArchivo(), cpe, "");
        	
        	constancia = generateCDRService.generate(envio);
        	
        	
        }
        return constancia;
	}


	public void setSelectFeAnuladoDAO(T4541DAO selectFeAnuladoDAO) {
		this.selectFeAnuladoDAO = selectFeAnuladoDAO;
	}


	public void setSelectCabcpeDAO(T4241DAO selectCabcpeDAO) {
		this.selectCabcpeDAO = selectCabcpeDAO;
	}


	public void setGenerateCDRService(GenerateCDRService generateCDRService) {
		this.generateCDRService = generateCDRService;
	}

	@Override
	public ConstanciaEnvio reconstuirConstancia(String archivo, Date FechaInicio, String nroTicket, int nroCorrelativo, String usuario) {
		
		log.debug("ReconstruirConstanciaFacturaNotaServiceImpl.reconstuirConstancia - Inic");

		String[] nombreArchivo = archivo.split("-");
        String rucEmisor = nombreArchivo[0];
        String tipoComprobante = nombreArchivo[1];

        String numeroSerie = nombreArchivo[2];
        Integer numeroComprobante = new Integer(nombreArchivo[3].split("\\.")[0]);
        
        
        PkComprobante pkcpe = new PkComprobante(rucEmisor, tipoComprobante, numeroSerie, numeroComprobante.toString());
        
        Contribuyente emisor = new Contribuyente("6", rucEmisor, "");
        
        Contribuyente receptor = new Contribuyente("-", "-", "-");
        
        Date fechaEmision = FechaInicio;
        
        ComprobanteElectronico cpe = null;
        
        ConstanciaEnvio constancia = null;
        
        
		T4241Bean factura = selectCabcpeDAO.findByPKAndTicket(rucEmisor, numeroSerie, numeroComprobante, tipoComprobante, nroTicket);
        // solo valido para factura notas de credito y notas de debito
        
        if (factura == null ) {
        	
        	ErrorDetail error = null;

            T4541Bean t4541Bean = selectFeAnuladoDAO.findByPKAndTicket(rucEmisor, numeroSerie, numeroComprobante, tipoComprobante, nroTicket);

            if (t4541Bean == null) {
                error = new ErrorDetail.Builder(nroTicket, nroCorrelativo, 200, "La Boleta debe haber sido informada").build();
                
            } else {
                // genera constancia con error
                
            	pkcpe = new PkComprobante(t4541Bean.getNum_ruc(), t4541Bean.getCod_cpe(), t4541Bean.getNum_serie_cpe(), t4541Bean.getNum_cpe().toString());
                
                error = new ErrorDetail.Builder(nroTicket, nroCorrelativo, new Integer(t4541Bean.getCod_error()), "El comprobante fue anulado").build();
                
            }
            
            cpe = new ComprobanteElectronico(pkcpe, emisor, receptor, fechaEmision);
            
            constancia = generateCDRService.generate(error, cpe, archivo, usuario);
            
            
        } else {
        	
        	String tipoComprobanteReceptor = ObjectUtils.toString(factura.getCod_docide_recep(), "-");
        	
        	String numDocumentoReceptor = factura.getNum_docide_recep();
        	
        	receptor = new Contribuyente(tipoComprobanteReceptor, numDocumentoReceptor, "");
        	
        	fechaEmision = factura.getFec_emision().getSQLDate(); 
        	
        	cpe = new ComprobanteElectronico(pkcpe, emisor, receptor, fechaEmision);
        	
        	Envio envio = new Envio(nroTicket, nroCorrelativo, usuario, archivo, cpe, "");
        	
        	constancia = generateCDRService.generate(envio);
        	
        	
        }
        
        log.debug("ReconstruirConstanciaFacturaNotaServiceImpl.reconstuirConstancia - Fin ");
        return constancia;
		
	}
	
	@Override
	public ConstanciaEnvio reconstuirConstanciaPercepcion(String archivo, Date FechaInicio, String nroTicket, int nroCorrelativo, String usuario) {
		
		log.debug("ReconstruirConstanciaFacturaNotaServiceImpl.reconstuirConstanciaPercepcion - Inic");

		String[] nombreArchivo = archivo.split("-");
        String rucEmisor = nombreArchivo[0];
        String tipoComprobante = nombreArchivo[1];

        String numeroSerie = nombreArchivo[2];
        Integer numeroComprobante = new Integer(nombreArchivo[3].split("\\.")[0]);
        
        
        PkComprobante pkcpe = new PkComprobante(rucEmisor, tipoComprobante, numeroSerie, numeroComprobante.toString());
        
        Contribuyente emisor = new Contribuyente("6", rucEmisor, "");
        
        Contribuyente receptor = new Contribuyente("-", "-", "-");
        
        Date fechaEmision = FechaInicio;
        
        ComprobanteElectronico cpe = null;
        
        ConstanciaEnvio constancia = null;
        
        T6571PercepcionBean percepcion = t6571Dao.buscarPorPk(rucEmisor, tipoComprobante, numeroSerie, numeroComprobante);
        // solo valido para factura notas de credito y notas de debito
        
        if (percepcion == null ) {
        	
        	ErrorDetail error = null;
            error = new ErrorDetail.Builder(nroTicket, nroCorrelativo, 200, "El comprobante debe haber sido informado").build();
            
        } else {
        	
        	String tipoComprobanteReceptor = ObjectUtils.toString(percepcion.getCodTipoDocRecep(), "-");
        	
        	String numDocumentoReceptor = percepcion.getNumDocRecep();
        	
        	receptor = new Contribuyente(tipoComprobanteReceptor, numDocumentoReceptor, "");
        	
        	fechaEmision = percepcion.getFechaEmision(); 
        	
        	cpe = new ComprobanteElectronico(pkcpe, emisor, receptor, fechaEmision);
        	
        	Envio envio = new Envio(nroTicket, nroCorrelativo, usuario, archivo, cpe, "");
        	
        	constancia = generateCDRService.generate(envio);
        }
        
        log.debug("ReconstruirConstanciaFacturaNotaServiceImpl.reconstuirConstanciaPercepcion - Fin ");
        
        return constancia;
		
	}
	
	@Override
	public ConstanciaEnvio reconstuirConstanciaRetencion(String archivo, Date FechaInicio, String nroTicket, int nroCorrelativo, String usuario) {
		
		log.debug("ReconstruirConstanciaFacturaNotaServiceImpl.reconstuirConstanciaRetencion - Inic");

		String[] nombreArchivo = archivo.split("-");
        String rucEmisor = nombreArchivo[0];
        String tipoComprobante = nombreArchivo[1];

        String numeroSerie = nombreArchivo[2];
        Integer numeroComprobante = new Integer(nombreArchivo[3].split("\\.")[0]);
        
        
        PkComprobante pkcpe = new PkComprobante(rucEmisor, tipoComprobante, numeroSerie, numeroComprobante.toString());
        
        Contribuyente emisor = new Contribuyente("6", rucEmisor, "");
        
        Contribuyente receptor = new Contribuyente("-", "-", "-");
        
        Date fechaEmision = FechaInicio;
        
        ComprobanteElectronico cpe = null;
        
        ConstanciaEnvio constancia = null;
        
        T6573RetencionBean retencion = t6573Dao.buscarPorPk(rucEmisor, tipoComprobante, numeroSerie, numeroComprobante);
        // solo valido para factura notas de credito y notas de debito
        
        if (retencion == null ) {
        	
        	ErrorDetail error = null;
            error = new ErrorDetail.Builder(nroTicket, nroCorrelativo, 200, "El comprobante debe haber sido informado").build();
            
        } else {
        	
        	String tipoComprobanteReceptor = ObjectUtils.toString(retencion.getCodTipDocRecep(), "-");
        	
        	String numDocumentoReceptor = retencion.getNumDocRecep();
        	
        	receptor = new Contribuyente(tipoComprobanteReceptor, numDocumentoReceptor, "");
        	
        	fechaEmision = retencion.getFecEmi(); 
        	
        	cpe = new ComprobanteElectronico(pkcpe, emisor, receptor, fechaEmision);
        	
        	Envio envio = new Envio(nroTicket, nroCorrelativo, usuario, archivo, cpe, "");
        	
        	constancia = generateCDRService.generate(envio);
        }
        
        log.debug("ReconstruirConstanciaFacturaNotaServiceImpl.reconstuirConstanciaRetencion - Fin ");
        
        return constancia;
		
	}

	
	@Override
	public ConstanciaEnvio reconstuirConstanciaGRE(String archivo, Date FechaInicio, String nroTicket, int nroCorrelativo, String usuario) {
		
		log.debug("ReconstruirConstanciaFacturaNotaServiceImpl.reconstuirConstanciaGRE - Inic");

		String[] nombreArchivo = archivo.split("-");
        String rucEmisor = nombreArchivo[0];
        String tipoComprobante = nombreArchivo[1];

        String numeroSerie = nombreArchivo[2];
        Integer numeroComprobante = new Integer(nombreArchivo[3].split("\\.")[0]);
        
        
        PkComprobante pkcpe = new PkComprobante(rucEmisor, tipoComprobante, numeroSerie, numeroComprobante.toString());
        
        Contribuyente emisor = new Contribuyente("6", rucEmisor, "");
        
        Contribuyente receptor = new Contribuyente("-", "-", "-");
        
        Date fechaEmision = FechaInicio;
        
        ComprobanteElectronico cpe = null;
        
        ConstanciaEnvio constancia = null;
        
        T6460CabGreBean gre = t6460Dao.buscarPorPk(rucEmisor, tipoComprobante, numeroSerie, numeroComprobante);
        // solo valido para factura notas de credito y notas de debito
        
        if (gre == null ) {
        	
        	ErrorDetail error = null;
            error = new ErrorDetail.Builder(nroTicket, nroCorrelativo, 200, "El comprobante debe haber sido informado").build();
            
        } else {
        	
        	String tipoComprobanteReceptor = ObjectUtils.toString(gre.getCodDocIdeRecep(), "-");
        	
        	String numDocumentoReceptor = gre.getNumDocIdeRecep();
        	
        	receptor = new Contribuyente(tipoComprobanteReceptor, numDocumentoReceptor, "");
        	
        	fechaEmision = gre.getFecEmision(); 
        	
        	cpe = new ComprobanteElectronico(pkcpe, emisor, receptor, fechaEmision);
        	
        	Envio envio = new Envio(nroTicket, nroCorrelativo, usuario, archivo, cpe, "");
        	
        	constancia = generateCDRService.generate(envio);
        }
        
        log.debug("ReconstruirConstanciaFacturaNotaServiceImpl.reconstuirConstanciaGRE - Fin ");
        
        return constancia;
		
	}

}
