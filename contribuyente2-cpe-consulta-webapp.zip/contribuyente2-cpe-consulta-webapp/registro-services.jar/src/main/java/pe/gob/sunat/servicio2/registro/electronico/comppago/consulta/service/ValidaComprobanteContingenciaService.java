package pe.gob.sunat.servicio2.registro.electronico.comppago.consulta.service;

import java.util.Map;
@SuppressWarnings({"rawtypes"})
public interface ValidaComprobanteContingenciaService {
	
	public Map consultaValidezCPC(Map<String,String>datos) ;
	
	

}
