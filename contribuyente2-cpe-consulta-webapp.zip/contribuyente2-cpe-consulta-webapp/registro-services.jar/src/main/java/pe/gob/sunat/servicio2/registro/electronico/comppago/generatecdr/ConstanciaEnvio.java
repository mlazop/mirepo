package pe.gob.sunat.servicio2.registro.electronico.comppago.generatecdr;

public class ConstanciaEnvio {
	
    private ApplicationResponse applicationResponse;
    private int hito = 500;
    private boolean fault = false;
    private String zippedBase64Cdr;
    private String archivoNombre;
    private Integer correlativo = 0;
    private String usuarioEnvio;
    private String hashCdr = "";
    private String numSerieCertificado = "";
	
	public void setApplicationResponse(ApplicationResponse applicationResponse) {
		this.applicationResponse = applicationResponse;
		if (applicationResponse.getCodeError() == null) {
			applicationResponse.setCodeError(0);
		}
	}
	public ApplicationResponse getApplicationResponse() {
		return applicationResponse;
	}
	public void setFault(boolean fault) {
		this.fault = fault;
	}
	public boolean getFault() {
		return fault;
	}
	public String getZippedBase64Cdr() {
		return zippedBase64Cdr;
	}
	public void setZippedBase64Cdr(String archivo) {
		this.zippedBase64Cdr = archivo;
	}
	public String getUsuarioEnvio() {
		return usuarioEnvio;
	}
	public void setUsuarioEnvio(String usuario) {
		this.usuarioEnvio = usuario;
	}
	public String getArchivoNombre() {
		return archivoNombre;
	}
	public void setArchivoNombre(String archivoNombre) {
		this.archivoNombre = archivoNombre;
	}
	public void setHito(int hito) {
		this.hito = hito;
	}
	public int getHito() {
		return hito;
	}
	public Integer getCorrelativo() {
		return correlativo;
	}
	public void setCorrelativo(Integer correlativo) {
		this.correlativo = correlativo;
	}
    public String getHashCdr() {
        return hashCdr;
    }
    public void setHashCdr(String hashCdr) {
        this.hashCdr = hashCdr;
    }
    public String getNumSerieCertificado() {
        return numSerieCertificado;
    }
    public void setNumSerieCertificado(String numSerieCertificado) {
        this.numSerieCertificado = numSerieCertificado;
    }

}
