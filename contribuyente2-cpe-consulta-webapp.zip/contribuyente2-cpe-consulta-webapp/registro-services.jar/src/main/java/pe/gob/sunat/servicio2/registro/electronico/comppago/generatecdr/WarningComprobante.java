package pe.gob.sunat.servicio2.registro.electronico.comppago.generatecdr;

import java.io.Serializable;

public class WarningComprobante implements Serializable{
	/**
	 * 
	 */
	private static final long serialVersionUID = -741106073237642469L;
	
	private String codigo;
	
	private String warning;
	
	WarningComprobante() {
	    super();
	}
	
	
	
	public WarningComprobante(String codigo, String warning) {
		this.codigo = codigo;
		this.warning = warning;
	}

	public String getCodigo() {
		return codigo;
	}

	public String getDescripcion() {
		return warning;
	}



	public void setCodigo(String codigo) {
	    this.codigo = codigo;
	}



	public void setWarning(String warning) {
	    this.warning = warning;
	}

}
