package pe.gob.sunat.servicio2.registro.electronico.comppago.generatecdr;


/**
 * Clase que muestra el detalle del error donde: numTicket identificador unico
 * del envio correlativo identificador del archivo (dentro del pack) procesado
 * errorCode codigo de error del aplicativo errorObservation mensaje que
 * describe el posible error; lineError si se trata de una validacion de la
 * linea inidicar la linea donde ocurre el error objectValidate el objeto el
 * cual lanza el error;
 * 
 * @author fjonisllap
 *
 */
public class ErrorDetail {
	private static final Integer ERROR_EN_LA_CABECERA = 0;
	private final String numTicket;
	private final Integer correlativo;
	private final Integer errorCode;
	private final String errorObservation;
	// campos opcionales
	private final Integer lineError;
	private final Object objectValidate;

	public static class Builder {
		// Required parameters
		private final Integer errorCode;
		private final String errorObservation;
		private final String numTicket;
		private final Integer correlativo;

		private Integer lineError = ERROR_EN_LA_CABECERA;
		private Object objectValidate = new Object();

		public Builder(String numTicket, Integer correlativo,
				Integer errorCode, String errorObservation) {
			this.numTicket = numTicket;
			this.errorCode = errorCode;
			this.errorObservation = errorObservation;
			this.correlativo = correlativo;
		}

		public Builder withLine(Integer lineError) {
			this.lineError = lineError;
			return this;
		}

		public Builder withObjectValidate(Object objectValidate) {
			this.objectValidate = objectValidate;
			return this;
		}

		public ErrorDetail build() {
			return new ErrorDetail(this);
		}

	}

	private ErrorDetail(Builder builder) {
		// Required parameters
		this.errorCode = builder.errorCode;
		this.errorObservation = builder.errorObservation;
		this.numTicket = builder.numTicket;

		// Optional parameters
		this.lineError = builder.lineError;
		this.objectValidate = builder.objectValidate;
		this.correlativo = builder.correlativo;
	}

	public String getNumTicket() {
		return numTicket;
	}

	public Integer getErrorCode() {
		return errorCode;
	}

	public String getErrorObservation() {
		return errorObservation;
	}

	public Integer getLineError() {
		return lineError;
	}

	public Integer getCorrelativo() {
		return correlativo;
	}

	public Object getObjectValidate() {
		return objectValidate;
	}

	@Override
	public String toString() {
		return "ErrorDetail [numTicket=" + numTicket + ", correlativo="
				+ correlativo + ", errorCode=" + errorCode
				+ ", errorObservation=" + errorObservation + ", lineError="
				+ lineError + ", objectValidate=" + objectValidate + "]";
	}

}