package pe.gob.sunat.servicio2.registro.electronico.comppago.generatecdr;

import java.util.Date;

import pe.gob.sunat.servicio2.registro.electronico.comppago.factura.model.domain.T4537Bean;


public interface ReconstruirConstanciaService {
	
	/**
     * Reconstruye la constancia de los comprobantes que quedaron en estado 98
     * @param blogCba log de la cabecera donde se puede encontrar el numero de ticket y el nombre del archivo enviado 
     * @return
     */
    public ConstanciaEnvio reconstuirConstancia(T4537Bean blogCba);
    
    public ConstanciaEnvio reconstuirConstancia(String nombreArchivo, Date FechaInicio, String nroTicket, int nroCorrelativo, String usuario);

	public ConstanciaEnvio reconstuirConstanciaPercepcion(String archivo, Date FechaInicio, String nroTicket, int nroCorrelativo, String usuario);

	public ConstanciaEnvio reconstuirConstanciaRetencion(String archivo,  Date FechaInicio, String nroTicket, int nroCorrelativo, String usuario);

	public ConstanciaEnvio reconstuirConstanciaGRE(String archivo, Date FechaInicio, String nroTicket, int nroCorrelativo, String usuario);

}
