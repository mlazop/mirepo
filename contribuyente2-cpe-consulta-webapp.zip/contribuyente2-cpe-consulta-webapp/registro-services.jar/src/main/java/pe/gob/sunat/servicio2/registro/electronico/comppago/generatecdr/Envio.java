package pe.gob.sunat.servicio2.registro.electronico.comppago.generatecdr;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.List;

public class Envio {
    private static final String ENVIO_RESUMEN_BOLETAS = "RC";

    private static final String ENVIO_RESUMEN_ANULADOS = "RA";

    private static final String ENVIO_LOTES = "LT";

    public static final java.lang.String SEND_ONLY_ONE = "1";
    
    public static final java.lang.String SEND_BATCH = "2";
    
    public static final java.lang.String SEND_SUMMARY = "3";
    
    public static final java.lang.String CHANNEL_WS = "1";
    
    public static final java.lang.String CHANNEL_FORM = "2";
    
    
    
    public static final java.lang.String[] LOTES_CODES = new String[] {ENVIO_LOTES};
    
    public static final java.lang.String[] RESUMEN_CODES = new String[] {ENVIO_RESUMEN_ANULADOS, ENVIO_RESUMEN_BOLETAS};
    
    public static final java.lang.String[] COMPROBANTE_CODES = new String[] {ComprobanteElectronico.CODIGO_COMPROMBATE_BOLETA, ComprobanteElectronico.CODIGO_COMPROMBATE_FACTURA, ComprobanteElectronico.CODIGO_COMPROMBATE_NOTA_CREDITO, ComprobanteElectronico.CODIGO_COMPROMBATE_NOTA_DEBITO, ComprobanteElectronico.CODIGO_COMPROMBATE_SERVICIO_PUBLICO};
    
    private String numTicket;
    private Date issueDate; 
    private Integer correlativo;
    private String usuarioEnvio;
    private String filename;
    private List<WarningComprobante> lstWarning;
    private ComprobanteElectronico comprobante;
    private String firmaXML;

    public Envio() {
		super();
		lstWarning = new ArrayList<WarningComprobante>();
    }

    public Envio(String numTicket, Integer correlativo, String usuarioEnvio, String filename, ComprobanteElectronico comprobante, String firmaXML) {
		super();
		this.numTicket = numTicket;
		this.correlativo = correlativo;
		this.usuarioEnvio = usuarioEnvio;
		this.filename = filename;
		this.comprobante = comprobante;
		this.firmaXML = firmaXML;
		lstWarning = new ArrayList<WarningComprobante>();
    }

    public String getNumTicket() {
    	return numTicket;
    }

    public String getUsuarioEnvio() {
    	return usuarioEnvio;
    }

    public ComprobanteElectronico getComprobante() {
    	return comprobante;
    }

    public void setNumTicket(String numTicket) {
    	this.numTicket = numTicket;
    }

    public void setUsuarioEnvio(String usuario) {
    	this.usuarioEnvio = usuario;
    }

    public void setComprobante(ComprobanteElectronico comprobante) {
    	this.comprobante = comprobante;
    }

    public String getFilename() {
    	return filename;
    }

    public void setFilename(String filename) {
    	this.filename = filename;
    }

    public Integer getCorrelativo() {
    	return correlativo;
    }

    public List<WarningComprobante> getLstWarning() {
    	return lstWarning;
    }

    public void setLstWarning(List<WarningComprobante> lstWarning) {
    	this.lstWarning = lstWarning;
    }

    public void addWarning(List<WarningComprobante> lstWarning) {
    	this.lstWarning.addAll(lstWarning);
    }

    public void addWarning(WarningComprobante warning) {
    	this.lstWarning.add(warning);
    }

    public String getFirmaXML() {
	return firmaXML;
    }

    public Date getIssueDate() {
        return issueDate;
    }

    public void setIssueDate(Date issueDate) {
        this.issueDate = issueDate;
    }
    
    
    public static boolean isLotes(String filename) {

	return  Arrays.asList(LOTES_CODES).contains(tipoEnvioByName(filename));
    }
    
    public static boolean isResumen(String filename) {
	return  Arrays.asList(RESUMEN_CODES).contains(tipoEnvioByName(filename));
    }
    
    public static boolean isOneByOne(String filename) {
	return  Arrays.asList(COMPROBANTE_CODES).contains(tipoEnvioByName(filename));
    }
    
    
    public static String tipoEnvioByName(String filename) {
	if(filename == null || filename.length() == 0 || filename.length() < 16) {
	    throw new IllegalArgumentException("El nombre del archivo no tiene el formato adecuado" + filename); 
	}
	return filename.substring(12, 14);
    }
    
    
}


