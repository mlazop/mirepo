package pe.gob.sunat.servicio2.registro.electronico.comppago.generatecdr;

public interface ChangeStatus {

	/**
	 * Cambia el estado del envio a 98 por PK del comprobante
	 * @param numRuc
	 * @param codCPE
	 * @param numSerieCPE
	 * @param numCPE
	 * @return
	 */
	public TicketCorrelativo  changeStatus(String numRuc, String codCPE, String numSerieCPE, Integer numCPE );
	/**
	 * Cambia el estado del envio a 98 por numero de ticket y correlativo
	 * @param numTicket
	 * @param correlativo
	 */
	public void changeStatus(String numTicket, Integer correlativo);
	
	
	/**
	 * Clase utilitario que agrupo el ticket y el correlativo del envio
	 * @author fjonisllap
	 *
	 */
	public static class TicketCorrelativo {
		private String numTicket;
		private Integer corelativo;
		
		
		public TicketCorrelativo(String numTicket, Integer corelativo) {
			super();
			this.numTicket = numTicket;
			this.corelativo = corelativo;
		}
		public String getNumTicket() {
			return numTicket;
		}
		public Integer getCorelativo() {
			return corelativo;
		}
		
		
	}


	public void changeStatus(ConstanciaEnvio envio);
	public void changeStatusPercepcion(ConstanciaEnvio constancia);
	public void changeStatusRetencion(ConstanciaEnvio constancia);
	public void changeStatusGRE(ConstanciaEnvio constancia);
}
