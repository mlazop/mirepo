package pe.gob.sunat.servicio2.registro.electronico.comppago.generatecdr;

import java.util.Date;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import pe.gob.sunat.servicio2.registro.electronico.comppago.factura.model.dao.GRELogCabSelectDAO;
import pe.gob.sunat.servicio2.registro.electronico.comppago.factura.model.dao.LogCabSelectDAO;
import pe.gob.sunat.servicio2.registro.electronico.comppago.factura.model.dao.T4537DAO;
import pe.gob.sunat.servicio2.registro.electronico.comppago.factura.model.domain.BillLogCab;
import pe.gob.sunat.servicio2.registro.electronico.comppago.factura.model.domain.T4537Bean;
import pe.gob.sunat.servicio2.registro.electronico.comppago.generatecdr.ChangeStatus.TicketCorrelativo;


public class RebuilCdrServiceImpl implements RebuilCdrService {

	protected final Log log = LogFactory.getLog(getClass());
	
	private T4537DAO selectFELogCab;
	
	private GRELogCabSelectDAO selectGRELogCab;
	private LogCabSelectDAO selectPERLogCab;
	
	private ChangeStatus changeStatus;
	
	private ReconstruirConstanciaService reconstruirConstanciaFacturaNota;
	
	
	
	public GRELogCabSelectDAO getSelectGRELogCab() {
		return selectGRELogCab;
	}

	public void setSelectGRELogCab(GRELogCabSelectDAO selectGRELogCab) {
		this.selectGRELogCab = selectGRELogCab;
	}

	public LogCabSelectDAO getSelectPERLogCab() {
		return selectPERLogCab;
	}

	public void setSelectPERLogCab(LogCabSelectDAO selectPERLogCab) {
		this.selectPERLogCab = selectPERLogCab;
	}

	public void setSelectFELogCab(T4537DAO selectFELogCab) {
		this.selectFELogCab = selectFELogCab;
	}

	public void setChangeStatus(ChangeStatus changeStatus) {
		this.changeStatus = changeStatus;
	}

	public void setReconstruirConstanciaFacturaNota(
			ReconstruirConstanciaService reconstruirConstanciaFacturaNota) {
		this.reconstruirConstanciaFacturaNota = reconstruirConstanciaFacturaNota;
	}

	@Override
	public ConstanciaEnvio rebuildCDRbyNumTicket(String numticket, Integer correlativo) {
		changeStatus.changeStatus(numticket, correlativo);
		return buildInProgessStateByNumticket(numticket, correlativo);
		
	}

	@Override
	public ConstanciaEnvio buildInProgessStateByNumticket(String numTicket,
			Integer correlativo) {
		
		T4537Bean billLogCab = selectFELogCab.findByPK(numTicket, correlativo);
		if(billLogCab ==null ) {
			throw new RuntimeException("No se encontro el comprobante por numero de ticket: " + numTicket);
		}

		ConstanciaEnvio envio = buildCDROfNewUrl(billLogCab);
		
		changeStatus.changeStatus(envio);
		
		return envio;
		
	}
	
	
	private ConstanciaEnvio buildInProgessStateByNumticket(String numTicket,
			Integer correlativo, String codCPE) {
		
		log.debug("RebuilCdrServiceImpl.buildInProgessStateByNumticket - Inic : numTicket = " + numTicket);
		
		String nombreArchivo = null;
		Date fechaInicio = null;
		String usuario = null;
		ConstanciaEnvio envio = null;
		
		if (codCPE.equals("09")) {
			log.debug("RebuilCdrServiceImpl.buildInProgessStateByNumticket - GRE");
			BillLogCab t6594 = selectGRELogCab.selectByParam(numTicket.toString(), correlativo);
			if(t6594 ==null ) {
				throw new RuntimeException("No se encontro el comprobante por numero de ticket: " + numTicket);
			}
			
			nombreArchivo = t6594.getNombreArchivo();
			fechaInicio = t6594.getFechaInicio();
			usuario = t6594.getUsuarioModificador();
			envio = buildCDROfNewUrl(nombreArchivo, fechaInicio, numTicket, correlativo, usuario, codCPE);
			changeStatus.changeStatusGRE(envio);
		}
		else if (codCPE.equals("20") || codCPE.equals("40")) {
			log.debug("RebuilCdrServiceImpl.buildInProgessStateByNumticket - PER/RET");
			Long auxTicket = new Long(numTicket);
			auxTicket++;
			BillLogCab t6578 = selectPERLogCab.obtenerEstado(auxTicket.toString());
			if(t6578 ==null ) {
				throw new RuntimeException("No se encontro el comprobante por numero de ticket: " + numTicket);
			}
			
			nombreArchivo = t6578.getNombreArchivo();
			fechaInicio = t6578.getFechaInicio();
			usuario = t6578.getUsuarioModificador();
			
			envio = buildCDROfNewUrl(nombreArchivo, fechaInicio, numTicket, correlativo, usuario, codCPE);
			if (codCPE.equals("40")) {
				changeStatus.changeStatusPercepcion(envio);
			} else if (codCPE.equals("20")) {
				changeStatus.changeStatusRetencion(envio);
			}
			
		}
		else {
			log.debug("RebuilCdrServiceImpl.buildInProgessStateByNumticket - CPE");
			T4537Bean billLogCab = selectFELogCab.findByPK(numTicket, correlativo);
			if(billLogCab ==null ) {
				throw new RuntimeException("No se encontro el comprobante por numero de ticket: " + numTicket);
			}
			

			nombreArchivo = billLogCab.getNombreArchivo();
			fechaInicio = billLogCab.getFechaInicio().getSQLDate();
			usuario = billLogCab.getUsuarioModificador();
			
			envio = buildCDROfNewUrl(nombreArchivo, fechaInicio, numTicket, correlativo, usuario, codCPE);
			changeStatus.changeStatus(envio);
		}

		
		
		log.debug("RebuilCdrServiceImpl.buildInProgessStateByNumticket - Fin");
		
		return envio;
		
	}
	
	
	/**
	 * Reconstruye la constancia del nuevo url datapower
	 * 
	 * @param billLogCab
	 * @return
	 */
	private ConstanciaEnvio buildCDROfNewUrl(T4537Bean billLogCab) {

		return reconstruirConstanciaFacturaNota.reconstuirConstancia(billLogCab);
	}
	
	private ConstanciaEnvio buildCDROfNewUrl(String nombreArchivo, Date FechaInicio, String nroTicket, int nroCorrelativo, String usuario, String codCPE) {
		
		
		nombreArchivo = nombreArchivo.replace(".zip", ".xml");
		log.debug("RebuilCdrServiceImpl.rebuildCDRbyBill : nombreArchivo = " + nombreArchivo);
		log.debug("RebuilCdrServiceImpl.rebuildCDRbyBill : codCPE = " + codCPE);

		if (codCPE.equals("40")){//percepcion
			return reconstruirConstanciaFacturaNota.reconstuirConstanciaPercepcion(nombreArchivo, FechaInicio, nroTicket, nroCorrelativo, usuario);
		}
		else if (codCPE.equals("20")){//retencion
			return reconstruirConstanciaFacturaNota.reconstuirConstanciaRetencion(nombreArchivo, FechaInicio, nroTicket, nroCorrelativo, usuario);
		}
		else if (codCPE.equals("09")){//guia
			return reconstruirConstanciaFacturaNota.reconstuirConstanciaGRE(nombreArchivo, FechaInicio, nroTicket, nroCorrelativo, usuario);
		}
		else {
			return reconstruirConstanciaFacturaNota.reconstuirConstancia(nombreArchivo, FechaInicio, nroTicket, nroCorrelativo, usuario);
		}
	}

	
	
	@Override
	public ConstanciaEnvio rebuildCDRbyBill(String numruc, String tipoCPE,
			String numSerieCPE, Integer numCPE) {
		 
		log.debug("RebuilCdrServiceImpl.rebuildCDRbyBill - Inic");
		TicketCorrelativo ticorre = changeStatus.changeStatus(numruc, tipoCPE, numSerieCPE, numCPE);
		
		log.debug("RebuilCdrServiceImpl.rebuildCDRbyBill - Fin");
		
		return buildInProgessStateByNumticket(ticorre.getNumTicket(), ticorre.getCorelativo(), tipoCPE);
		
		
	}

}
