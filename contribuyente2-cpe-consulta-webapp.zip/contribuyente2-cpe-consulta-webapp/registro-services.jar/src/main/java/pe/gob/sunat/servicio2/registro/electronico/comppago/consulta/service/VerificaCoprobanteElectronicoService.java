package pe.gob.sunat.servicio2.registro.electronico.comppago.consulta.service;

import java.io.File;
import java.util.Map;

import org.w3c.dom.Document;

import pe.gob.sunat.framework.spring.util.exception.ServiceException;
import pe.gob.sunat.servicio2.registro.electronico.comppago.factura.bean.ComprobanteParserBean;



/**
 * <p>Description: Verificaci�n del archivo digital.</p>
 * @author jchuquitaype
 */
public interface VerificaCoprobanteElectronicoService{
	/**
	 * Procedimiento de evaluaci�n del documento electr�nico GEM: 
	 * Verifica la firma del documento, obtiene el documento desde la BD y compara el resumen de los dos documentos. 
	 * @param doc
	 * @param tipodocumento
	 * @param parser
	 * @return
	 */
	public static final String BAJAGREBF = "1";
	public static final String BAJACPE = "2";
	public static final String ACTIVORHE = "0";
	
	public Map<String,String> evaluarFacturaGEM(Document doc, String tipodocumento, ComprobanteParserBean parser, File fileXml, byte[] bytes);
	
	public Map<String,String> evaluarFileFacturaGEM(Document doc, String tipodocumento, ComprobanteParserBean parser, File fileXml, byte[] bytes);
	
	public Map<String,String> evaluarFacturaPORTAL(Document doc, String tipodocumento, ComprobanteParserBean parser)throws ServiceException, Exception;
	public Map<String,String> evaluarBoletaPORTAL(Document doc, String tipodocumento, ComprobanteParserBean parser)throws ServiceException, Exception;
	
	//fcayetano
	public Map<String,String> evaluarInputStream(Document doc, String tipodocumento, ComprobanteParserBean parser, byte[] bytes)throws ServiceException, Exception;
	
	public Map<String,String> consultaGrabaFileNube(Document doc, String tipodocumento, ComprobanteParserBean parser, File fileXml, byte[] bytes);
	
}
