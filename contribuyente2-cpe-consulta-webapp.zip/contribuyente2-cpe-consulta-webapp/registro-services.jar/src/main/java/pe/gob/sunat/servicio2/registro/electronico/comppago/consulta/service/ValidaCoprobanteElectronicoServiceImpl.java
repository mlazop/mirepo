package pe.gob.sunat.servicio2.registro.electronico.comppago.consulta.service;

import java.io.BufferedReader;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.Reader;
import java.math.BigDecimal;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;
import java.net.URLConnection;
import java.text.DateFormat;
import java.text.DecimalFormat;
import java.text.DecimalFormatSymbols;
import java.text.NumberFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Properties;
import java.util.zip.ZipEntry;
import java.util.zip.ZipInputStream;

import javax.xml.namespace.NamespaceContext;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.xpath.XPath;
import javax.xml.xpath.XPathConstants;
import javax.xml.xpath.XPathFactory;

import org.apache.commons.lang.ArrayUtils;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.json.JSONObject;
import org.springframework.util.CollectionUtils;
import org.springframework.web.client.RestTemplate;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;

import com.fasterxml.jackson.databind.ObjectMapper;

import net.minidev.json.parser.JSONParser;
import pe.gob.sunat.framework.spring.util.bean.MensajeBean;
import pe.gob.sunat.framework.spring.util.date.FechaBean;
import pe.gob.sunat.framework.spring.util.exception.ServiceException;
import pe.gob.sunat.servicio2.registro.electronico.comppago.boleta.bean.OtroDocumentoRelacionadoBean;
import pe.gob.sunat.servicio2.registro.electronico.comppago.consulta.model.dao.T4705DAOSelect;
import pe.gob.sunat.servicio2.registro.electronico.comppago.consulta.model.domain.T4705Bean;
import pe.gob.sunat.servicio2.registro.electronico.comppago.factura.bean.ComprobanteUtilBean;
import pe.gob.sunat.servicio2.registro.electronico.comppago.factura.model.dao.T10194DAO;
import pe.gob.sunat.servicio2.registro.electronico.comppago.factura.model.dao.T10204DAO;
import pe.gob.sunat.servicio2.registro.electronico.comppago.factura.model.dao.T10209DAO;
import pe.gob.sunat.servicio2.registro.electronico.comppago.factura.model.dao.T4241DAO;
import pe.gob.sunat.servicio2.registro.electronico.comppago.factura.model.dao.T4243DAO;
import pe.gob.sunat.servicio2.registro.electronico.comppago.factura.model.dao.T4283DAO;
import pe.gob.sunat.servicio2.registro.electronico.comppago.factura.model.dao.T4541DAO;
import pe.gob.sunat.servicio2.registro.electronico.comppago.factura.model.dao.T4703DAO;
import pe.gob.sunat.servicio2.registro.electronico.comppago.factura.model.dao.T4704DAO;
import pe.gob.sunat.servicio2.registro.electronico.comppago.factura.model.dao.T6235DAO;
import pe.gob.sunat.servicio2.registro.electronico.comppago.factura.model.dao.T8249DAO;
import pe.gob.sunat.servicio2.registro.electronico.comppago.factura.model.domain.T10194Bean;
import pe.gob.sunat.servicio2.registro.electronico.comppago.factura.model.domain.T10204Bean;
import pe.gob.sunat.servicio2.registro.electronico.comppago.factura.model.domain.T10209Bean;
import pe.gob.sunat.servicio2.registro.electronico.comppago.factura.model.domain.T4241Bean;
import pe.gob.sunat.servicio2.registro.electronico.comppago.factura.model.domain.T4243Bean;
import pe.gob.sunat.servicio2.registro.electronico.comppago.factura.model.domain.T4283Bean;
import pe.gob.sunat.servicio2.registro.electronico.comppago.factura.model.domain.T4541Bean;
import pe.gob.sunat.servicio2.registro.electronico.comppago.factura.model.domain.T4704Bean;
import pe.gob.sunat.servicio2.registro.electronico.comppago.factura.model.domain.T6235Bean;
import pe.gob.sunat.servicio2.registro.electronico.comppago.factura.model.domain.T6236Bean;
import pe.gob.sunat.servicio2.registro.electronico.comppago.factura.model.domain.T8248Bean;
import pe.gob.sunat.servicio2.registro.electronico.comppago.factura.model.domain.T8249Bean;
import pe.gob.sunat.servicio2.registro.electronico.comppago.model.dao.T3634DAO;
import pe.gob.sunat.servicio2.registro.electronico.comppago.model.dao.T3639DAO;
import pe.gob.sunat.servicio2.registro.electronico.comppago.model.domain.T3634Bean;
import pe.gob.sunat.servicio2.registro.electronico.comppago.model.domain.T3639Bean;
import pe.gob.sunat.servicio2.registro.electronico.comppago.percepcion.model.PercepcionBean;
import pe.gob.sunat.servicio2.registro.electronico.comppago.percepcion.model.dao.PercepcionDAO;
import pe.gob.sunat.servicio2.registro.electronico.comppago.percepcion.model.dao.ibatis.SqlMapPercepcionDAO;
import pe.gob.sunat.servicio2.registro.electronico.comppago.retencion.model.RetencionBean;
import pe.gob.sunat.servicio2.registro.electronico.comppago.retencion.model.dao.RetencionDAO;
import pe.gob.sunat.servicio2.registro.electronico.comppago.retencion.model.dao.ibatis.SqlMapRetencionDAO;
import pe.gob.sunat.servicio2.registro.model.dao.DdpDAO;
import pe.gob.sunat.servicio2.registro.model.dao.T01DAO;
import pe.gob.sunat.servicio2.registro.model.dao.T1331DAO;
import pe.gob.sunat.servicio2.registro.model.domain.T1331Bean;

/**
 * <p>
 * Title: ConsultaCoprobanteElectronicoServiceImpl</p>
 * <p>
 * Description: Implementaci�n del Servicio de consulta de comprobantes
 * electr�nicos, migrado desde Recibos por Honorarios electronicos.</p>
 *
 * @author jchuquitaype
 */
@SuppressWarnings({"rawtypes"})
public class ValidaCoprobanteElectronicoServiceImpl implements ValidaCoprobanteElectronicoService {

    private static final Log log = LogFactory.getLog(ValidaCoprobanteElectronicoServiceImpl.class);
    private static String[] tipComproDesc = {"", "Factura Electr�nica", "", "Boleta de Venta Electr�nica", "", "", "", "Nota de Cr�dito Electr�nica", "Nota de D�bito Electr�nica", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "P�LIZA DE ADJUDICACI�N ELECTR�NICA", "", "", "", "", "", "", "Adquiriente", "", "", "", "Operador", "", "", "", "", "", "", "", "Adquiriente"};
    @SuppressWarnings("unused")
    private Properties constantes;
    private T3639DAO t3639DAO;

    private T3634DAO t3634DAO;
    private T4241DAO t4241DAO;
    private T10194DAO t10194DAO;
    private T4541DAO t4541DAO;
    private T4704DAO t4704DAO;
    private T4283DAO t4283DAO;
    private T4703DAO t4703DAO;
    private RetencionDAO t6573DAO;
    private PercepcionDAO t6571DAO;
    private T4705DAOSelect t4705dao;

    //Ini PAS20175E210300094
    private T1331DAO t1331DAO;
    private T6235DAO t6235DAO;

    private T01DAO t01DAO;
    private DdpDAO ddpDAO;
    //Fin PAS20175E210300094

    private T8249DAO t8249DAO;

    private static final String BOLETA_VENTA_GEM = "03";
    private static final String NOTA_CREDITO_GEM = "07";
    private static final String NOTA_DEBITO_GEM = "08";
    private pe.gob.sunat.servicio2.registro.electronico.comppago.boleta.service.ProcesaArchivoComprobanteService archivoServiceBVE;
    private T4243DAO t4243DAO;
    
    private T10204DAO t10204DAO;
    private T10209DAO t10209DAO;

    private XPath xPath;

    @Override
    public Map consultaValidezRHE_NCE(Map<String, String> data) {
        Map<String, Object> result = null;
        
        log.debug("tipocomprobante:" + data.get("tipocomprobante"));
        try {
            if (data.get("tipocomprobante") != null && data.get("tipocomprobante").length() > 0) {
                Map<String, String> rptaValidez = new HashMap<String, String>();
                // Recibo por honorarios
                if ("01".equals(data.get("tipocomprobante").toString())) {
                    rptaValidez = buscarRHE(data);
                    // Nota de credito de RHE
                } else if ("02".equals(data.get("tipocomprobante").toString())) {
                    rptaValidez = buscarNotaCredRHE(data);
                    // Factura Electronica
                } else if ("03".equals(data.get("tipocomprobante").toString())) {
                    rptaValidez = buscarFacturaOrNotas(data, "01");
                    // Nota de credito electronica, para Facturas MYPE GEM y boletas
                } else if ("04".equals(data.get("tipocomprobante").toString())) {
                    //if(data.get("num_serie").trim().startsWith("F") || data.get("num_serie").trim().startsWith("E")){
                    rptaValidez = buscarFacturaOrNotas(data, "07");
                    //}else if(data.get("num_serie").trim().startsWith("B")){
                    //	rptaValidez = buscarBoletaOrNotas(data,"07");
                    //} 
                    // Nota de debito electronica, para factura MYPE GEM y para boletas
                } else if ("05".equals(data.get("tipocomprobante").toString())) {
                    //if(data.get("num_serie").trim().startsWith("F") || data.get("num_serie").trim().startsWith("E")){
                    rptaValidez = buscarFacturaOrNotas(data, "08");
                    //}else if(data.get("num_serie").trim().startsWith("B")){
                    //rptaValidez = buscarBoletaOrNotas(data,"08");
                    //}
                    // Boletas electronicas
                } else if ("06".equals(data.get("tipocomprobante").toString())) {
                    rptaValidez = buscarBoletaOrNotas(data, "03");
                    //Gu�as de Remisi�n Electronica BF
                } else if ("07".equals(data.get("tipocomprobante").toString())) {
                    rptaValidez = buscarGuiasBF(data, "60");
                } else if ("08".equals(data.get("tipocomprobante").toString())) {
                    rptaValidez = buscarGuiasBF(data, "61");
                } else if ("09".equals(data.get("tipocomprobante").toString())) {
                    rptaValidez = buscarGuiasBF(data, "62");
                } else if ("10".equals(data.get("tipocomprobante").toString())) {
                    rptaValidez = buscarGuiasBF(data, "63");
                    // Nota de credito electronica, para BOLETAS
                } else if ("11".equals(data.get("tipocomprobante").toString())) {
                    rptaValidez = buscarBoletaOrNotas(data, "07");
                    // Nota de DEBITO electronica, para BOLETAS
                } else if ("12".equals(data.get("tipocomprobante").toString())) {
                    rptaValidez = buscarBoletaOrNotas(data, "08");
                    // --- Inicio [jpozo] ---	
                    // Boleta de venta simplificada
                    //VALOR TEMPORAL del parametro codCpe: 08 PARA PRUEBAS
                } else if ("13".equals(data.get("tipocomprobante").toString())) {
                    //70 => valor correcto
                    rptaValidez = buscarBoletaVentaSimplificada(data, "70");
                    // --- Fin [jpozo] ---

                    //	PAS20175E210300091 DANY RUIZ INICIO //
                } else if ("20".equals(data.get("tipocomprobante").toString())) { //Retencion

                    rptaValidez = buscarComprobanteRetencion(data, "20");

                } else if ("40".equals(data.get("tipocomprobante").toString())) { //Percepci�n

                    rptaValidez = buscarComprobantePercepcion(data, "40");

                }//Ini PAS20175E210300094
                // P�liza de adjudicaci�n Electr�nica
                else if ("23".equals(data.get("tipocomprobante").toString())) {
                    rptaValidez = buscarPolizaAdjudicacionElectronica(data, "23");
                }
                //Inicio - PAS20201U210100038				
                else if ("30".equals(data.get("tipocomprobante").toString())) {
                    rptaValidez = buscarAdquiriente(data, "30");
                }
                else if ("34".equals(data.get("tipocomprobante").toString())) {
                    rptaValidez = buscarOperador(data, "34");
                }
                else if ("42".equals(data.get("tipocomprobante").toString())) {
                	rptaValidez = buscarAdquiriente(data, "42");
                } //Fin - PAS20201U210100038
                //ticket POS no tiene un codigo en t01param, catalogo 233, se pone TCF "provicional"
                else if ("TCF".equals(data.get("tipocomprobante").toString())) {
                    rptaValidez = buscarTicketPOS(data);
                } //Fin PAS20175E210300094
                //Ini PAS20181U210300013				
                else if ("TME".equals(data.get("tipocomprobante").toString().substring(0, 3))) {
                    rptaValidez = buscarTicketME(data);
                } //Fin PAS20181U210300013
                else {
                    throw new ServiceException(this, "El tipo de comprobante para la consulta no es el correcto, por favor seleccione un tipo de comprobante correcto.");
                }

                result = new HashMap<String, Object>();
                result.put("resp", rptaValidez);
            } else {
                throw new ServiceException(this, "Por favor seleccionar el tipo de comprobante para realizar la consulta");
            }

        } catch (ServiceException se) {
            log.error(se, se);
            throw new ServiceException(this, se.getMessage());
        } catch (Exception e) {
            log.error(e, e);
            throw new ServiceException(this, e.getMessage());
        }
        return result;
    }

    @SuppressWarnings("unused")
    private Map<String, String> buscarComprobanteRetencion(Map<String, String> datos, String codCpe) throws ServiceException {

        log.debug("buscarComprobanteRetencion...");
        Map<String, String> result = new HashMap<String, String>();

        RetencionBean retencionBean = new RetencionBean();

        retencionBean.setNumRuc(datos.get("num_ruc"));
        retencionBean.setNumSerieCpe(datos.get("num_serie").toUpperCase());
        retencionBean.setNumCpe(Integer.valueOf(datos.get("num_comprob")));

        SimpleDateFormat formatter = new SimpleDateFormat("dd/MM/yyyy");
        //String dateInString = "07/06/2013";

        try {

            Date date = formatter.parse(datos.get("fec_emision"));

            retencionBean.setFechaEmision(date);

        } catch (ParseException e) {
            e.printStackTrace();
        }

        if (datos.get("cantidad") != null) {

            String cantidad = datos.get("cantidad").trim();
            BigDecimal monto = new BigDecimal(0);

            if (!"".equals(cantidad)) {
                monto = new BigDecimal(cantidad);
            }

            log.debug("monto:" + monto);
            if (monto.intValue() != BigDecimal.ZERO.intValue()) {
                retencionBean.setMontoTotalRetenido(monto);
            }
        }

        String cod_docide = datos.get("cod_docide") != null ? datos.get("cod_docide").toString() : "";
        if (!"".equals(cod_docide)) {
            retencionBean.setCodTipoDocRecep(datos.get("cod_docide"));
        }

        String num_docide = datos.get("num_docide") != null ? datos.get("num_docide").toString() : "";
        if (!"".equals(num_docide)) {
            retencionBean.setNumDocRecep(datos.get("num_docide"));
        }

        //retencionBean.setCodEstadoCpe("01");
        String descCompro = retencionBean.getNumSerieCpe() + "-" + retencionBean.getNumCpe();

        retencionBean = t6573DAO.selectPorEmisor(retencionBean);

        /// INICIO PAS20191U210100160
        if (retencionBean != null && retencionBean.getCodEstadoCpe().equals("03")) {
            HashMap<String, Object> mapFiltro = new HashMap<String, Object>();
            HashMap<String, Object> mapFiltroRechazo = new HashMap<String, Object>();

            String snumTicket = retencionBean.getNumTicket() + "";
            long numTicket = Long.parseLong((snumTicket.substring(0, snumTicket.length() - 1) + "0"));
            mapFiltro.put("num_ticket", numTicket);
            String canalEnvio = t6573DAO.buscarCanalEnvio(mapFiltro);

            mapFiltroRechazo.put("num_ruc", retencionBean.getNumRuc());
            mapFiltroRechazo.put("cod_cpe", retencionBean.getCodCpe());
            mapFiltroRechazo.put("num_serie_cpe", retencionBean.getNumSerieCpe());
            mapFiltroRechazo.put("num_cpe", retencionBean.getNumCpe());

            if (canalEnvio.equals("3") && t6573DAO.countRechazo(mapFiltroRechazo) == 0) {
                retencionBean.setCodEstadoCpe("01");
            }
        }
        /// FIN PAS20191U210100160

        if (retencionBean == null) {
            result.put("titulo", "No existe un comprobante de retenci�n que cumpla con los criterios ingresados por Usted.");
        } else {

            if ("01".equals(retencionBean.getCodEstadoCpe())) {
                result.put("titulo", "El comprobante de retenci�n " + descCompro + " es v�lido");
            } else if ("02".equals(retencionBean.getCodEstadoCpe())) {
                result.put("titulo", "El comprobante de retenci�n " + descCompro + " existe pero no est� vigente");
            } else if ("03".equals(retencionBean.getCodEstadoCpe())) {
                result.put("titulo", "El comprobante de retenci�n " + descCompro + " esta anulado");
            }
        }

        return result;
    }

    @SuppressWarnings("unused")
    private Map<String, String> buscarComprobantePercepcion(Map<String, String> datos, String codCpe) throws ServiceException {

        log.debug("buscarComprobantePercepcion...");
        Map<String, String> result = new HashMap<String, String>();

        PercepcionBean percepcionBean = new PercepcionBean();

        percepcionBean.setNumRuc(datos.get("num_ruc"));
        percepcionBean.setNumSerieCpe(datos.get("num_serie").toUpperCase());
        percepcionBean.setNumCpe(Integer.valueOf(datos.get("num_comprob")));

        SimpleDateFormat formatter = new SimpleDateFormat("dd/MM/yyyy");
        //String dateInString = "07/06/2013";

        try {

            Date date = formatter.parse(datos.get("fec_emision"));

            percepcionBean.setFechaEmision(date);

        } catch (ParseException e) {
            e.printStackTrace();
        }

        if (datos.get("cantidad") != null) {

            String cantidad = datos.get("cantidad").trim();
            BigDecimal monto = new BigDecimal(0);

            if (!"".equals(cantidad)) {
                monto = new BigDecimal(cantidad);
            }

            log.debug("monto:" + monto);
            if (monto.intValue() != BigDecimal.ZERO.intValue()) {
                percepcionBean.setMontoTotalPercibido(monto);
            }
        }

        String cod_docide = datos.get("cod_docide") != null ? datos.get("cod_docide").toString() : "";
        if (!"".equals(cod_docide)) {
            percepcionBean.setCodTipoDocRecep(datos.get("cod_docide"));
        }

        String num_docide = datos.get("num_docide") != null ? datos.get("num_docide").toString() : "";
        if (!"".equals(num_docide)) {
            percepcionBean.setNumDocRecep(datos.get("num_docide"));
        }

        //retencionBean.setCodEstadoCpe("01");
        String descCompro = percepcionBean.getNumSerieCpe() + "-" + percepcionBean.getNumCpe();

        percepcionBean = t6571DAO.selectPorEmisor(percepcionBean);

        /// INICIO PAS20191U210100160
        if (percepcionBean != null && percepcionBean.getCodEstadoCpe().equals("03")) {
            HashMap<String, Object> mapFiltro = new HashMap<String, Object>();
            HashMap<String, Object> mapFiltroRechazo = new HashMap<String, Object>();

            String snumTicket = percepcionBean.getNumTicket() + "";
            long numTicket = Long.parseLong((snumTicket.substring(0, snumTicket.length() - 1) + "0"));
            mapFiltro.put("num_ticket", numTicket);
            String canalEnvio = t6571DAO.buscarCanalEnvio(mapFiltro);

            mapFiltroRechazo.put("num_ruc", percepcionBean.getNumRuc());
            mapFiltroRechazo.put("cod_cpe", percepcionBean.getCodCpe());
            mapFiltroRechazo.put("num_serie_cpe", percepcionBean.getNumSerieCpe());
            mapFiltroRechazo.put("num_cpe", percepcionBean.getNumCpe());

            if (canalEnvio.equals("3") && t6571DAO.countRechazo(mapFiltroRechazo) == 0) {
                percepcionBean.setCodEstadoCpe("01");
            }
        }
        /// FIN PAS20191U210100160

        if (percepcionBean == null) {
            result.put("titulo", "No existe un comprobante de percepci�n que cumpla con los criterios ingresados por Usted.");
        } else {

            if ("01".equals(percepcionBean.getCodEstadoCpe())) {
                result.put("titulo", "El comprobante de percepci�n " + descCompro + " es v�lido");
            } else if ("02".equals(percepcionBean.getCodEstadoCpe())) {
                result.put("titulo", "El comprobante de percepci�n " + descCompro + " existe pero no est� vigente");
            } else if ("03".equals(percepcionBean.getCodEstadoCpe())) {
                result.put("titulo", "El comprobante de percepci�n " + descCompro + " esta anulado");
            }
        }

        return result;
    }

    private Map<String, String> buscarGuiaRemisionRemitente(Map<String, String> datos, String codCpe) throws ServiceException {
        return null;
    }

    public pe.gob.sunat.servicio2.registro.electronico.comppago.boleta.service.ProcesaArchivoComprobanteService getArchivoServiceBVE() {
        return archivoServiceBVE;
    }

    public void setArchivoServiceBVE(
            pe.gob.sunat.servicio2.registro.electronico.comppago.boleta.service.ProcesaArchivoComprobanteService archivoServiceBVE) {
        this.archivoServiceBVE = archivoServiceBVE;
    }

    private Map<String, String> buscarRHE(Map<String, String> datos) throws ServiceException {
    	    	
        Map<String, String> result = new HashMap<String, String>();
        T3639Bean beanIn = new T3639Bean();
        T3639Bean beanOu = new T3639Bean();
        beanIn.setNum_ruc(datos.get("num_ruc"));
        beanIn.setCod_docide(datos.get("cod_docide") != null && !datos.get("cod_docide").toString().trim().equals("-") ? datos.get("cod_docide") : null);
        beanIn.setNum_docide(datos.get("num_docide") != null && !datos.get("num_docide").toString().trim().equals("-") ? datos.get("num_docide") : null);
        beanIn.setNum_serie(datos.get("num_serie").trim());
        beanIn.setNum_comprob(new Integer(datos.get("num_comprob")));
        beanIn.setFec_emision_rec(new FechaBean(datos.get("fec_emision")).getSQLDate());
        beanIn.setMto_bruto(new BigDecimal(datos.get("cantidad")));

        beanOu = t3639DAO.findByFiltro(beanIn);
        if (null == beanOu) {
            result.put("titulo", "No existe un Recibo por  Honorarios Electr&oacute;nicos  que cumpla  con los criterios ingresados por Usted.");
        } else {
            if (!"0".equals(beanOu.getInd_estado_rec().trim())) {
                result.put("titulo", "El recibo consultado por Usted, existe pero no est� Vigente.");
            } else {
                result.put("titulo", "EL RECIBO POR HONORARIOS ELECTRONICO Nro." + beanOu.getNum_serie() + "-" + beanOu.getNum_comprob() + " CONSULTADO, ES VALIDO.");
            }
        }
        return result;
    }

    private Map<String, String> buscarNotaCredRHE(Map<String, String> datos) throws ServiceException {
        Map<String, String> result = new HashMap<String, String>();
        T3634Bean beanIn = new T3634Bean();
        T3634Bean beanOu = new T3634Bean();

        beanIn.setNum_ruc(datos.get("num_ruc"));
        beanIn.setCod_docide(datos.get("cod_docide") != null && !datos.get("cod_docide").toString().trim().equals("-") ? datos.get("cod_docide") : null);
        beanIn.setNum_docide(datos.get("num_docide") != null && !datos.get("num_docide").toString().trim().equals("-") ? datos.get("num_docide") : null);
        beanIn.setNum_serie(datos.get("num_serie").trim());
        beanIn.setNum_nota(new Integer(datos.get("num_comprob")));
        beanIn.setFec_emision_nc(new FechaBean(datos.get("fec_emision")).getSQLDate());
        beanIn.setMto_nc_bruto(new BigDecimal(datos.get("cantidad")));

        beanOu = t3634DAO.findByFiltro(beanIn);
        if (null == beanOu) {
            result.put("titulo", "No existe una Nota de Cr�dito Electronica  que cumpla  con los criterios ingresados por Usted.");
        } else {
            if (!"0".equals(beanOu.getInd_estado_nc().trim())) {
                result.put("titulo", "La Nota de Cr&eacute;dito Electr&oacute;nica consultada por Usted, existe pero no est&aacute; Vigente.");
            } else {
                result.put("titulo", "LA NOTA DE CREDITO DE RHE ELETRONICA Nro." + beanOu.getNum_serie() + "-" + beanOu.getNum_nota() + " CONSULTADA, ES VALIDA.");
            }
        }
        return result;
    }

    /**
     *
     * @param datos
     * @param codCpe
     * @return
     * @throws ServiceException
     */
    private Map<String, String> buscarFacturaOrNotas(Map<String, String> datos, String codCpe) throws ServiceException {
    	
    	
    	
    	
        Map<String, String> result = new HashMap<String, String>();

        T4241Bean inT4241bean = new T4241Bean();
        T4241Bean ouT4241bean = new T4241Bean();
        T4283Bean t4283BeanIn = null;
        T4283Bean t4283BeanOut = null;

        inT4241bean.setNum_ruc(datos.get("num_ruc"));
        inT4241bean.setCod_cpe(codCpe);

        //MSF: comentado para hacer comparacion posterior 
        //inT4241bean.setCod_docide_recep(datos.get("cod_docide")!=null && !datos.get("cod_docide").toString().trim().equals("-") ? (datos.get("cod_docide").equals("A")?datos.get("cod_docide"):"0"+datos.get("cod_docide")) : null );
        inT4241bean.setCod_docide_recep(null);
        boolean requiereIdcompara = false;
        if (datos.get("cod_docide") != null && !datos.get("cod_docide").toString().trim().equals("-")) {
            requiereIdcompara = true;
        }
        //MSF

        inT4241bean.setNum_docide_recep(datos.get("num_docide") != null && !datos.get("num_docide").toString().trim().equals("-") ? datos.get("num_docide") : null);
        inT4241bean.setNum_serie_cpe(datos.get("num_serie").trim());
        inT4241bean.setNum_cpe(new Integer(datos.get("num_comprob")));
        inT4241bean.setFec_emision(new FechaBean(datos.get("fec_emision")));
        inT4241bean.setMto_importe_total(new BigDecimal(datos.get("cantidad")));

        String descCompro = tipComproDesc[new Integer(codCpe).intValue()] + " " + datos.get("num_serie").trim() + "-" + datos.get("num_comprob") + " ";

        /**
         * Buscare en los enviados y aceptados
         */
        ouT4241bean = t4241DAO.findByFiltro(inT4241bean);

        //MSF: compara documento de identidad
        if (requiereIdcompara) {
            if (ouT4241bean != null) {
                if (ArrayUtils.contains(generaCodIdArray(datos.get("cod_docide")), ouT4241bean.getCod_docide_recep().trim())
                        && ouT4241bean.getNum_docide_recep().trim().equals(inT4241bean.getNum_docide_recep())) {
                    //coincide el documento de identidad
                    log.info(">>Coincide con Doc ID");
                } else {
                    //NO coincide el documento de identidad
                    ouT4241bean = null;
                }
            }
        }
        /**
         * Factura Portal - MYPE
         */
        if (inT4241bean.getNum_serie_cpe().toUpperCase().startsWith("E")) {
            log.debug("Factura Portal - MYPE");
            if (null == ouT4241bean) {
            	
            	//csantillan inicio PAS20231U210600160 	
            	log.info("buscarFacturaOrNotas log rest");
               String comprobante = obtenerComprobanteElectronico(inT4241bean,"F");
            	if (comprobante==null||comprobante==""){
                result.put("titulo", "La " + descCompro + " no existe en los registros de SUNAT.");
            	}else{
            		result.put("titulo", "La " + descCompro + " es un comprobante de pago v�lido.");
            	}
            //csantillan fin	
            	
               // result.put("titulo", "La " + descCompro + " no existe en los registros de SUNAT.");
            } else if (ouT4241bean.getInd_rechazo().trim().equals("0")) {
                result.put("titulo", "La " + descCompro + " es un comprobante de pago v�lido.");
            } else if (ouT4241bean.getInd_rechazo().trim().equals("1")) { // Comrpobange rechazado MYPE. 
                //Buscar fecha de rechazo.
                t4283BeanIn = new T4283Bean();
                t4283BeanIn.setNum_ruc(datos.get("num_ruc"));
                t4283BeanIn.setCod_cpe(codCpe);
                t4283BeanIn.setNum_serie_cpe(datos.get("num_serie").trim());
                t4283BeanIn.setNum_cpe(new Integer(datos.get("num_comprob")));
                t4283BeanIn.setCod_rubro(301);
                t4283BeanIn.setNum_fila_item(0);
                t4283BeanIn.setInd_cab_det("1");

                t4283BeanOut = t4283DAO.findRubro_ByRUC_codCPE_Serie_CPE_rubro_numFila_indcabdet(t4283BeanIn);

                result.put("titulo", "La " + descCompro + " fue rechazada por el contribuyente receptor" + (t4283BeanOut != null ? " el " + t4283BeanOut.getFec_rubro().getFormatDate("dd/MM/yyyy") : "") + ".");
            }
            /**
             * Factura Grandes Emisores - GEM
             */
        } else if (inT4241bean.getNum_serie_cpe().toUpperCase().startsWith("F")) {
            if (null == ouT4241bean) {
                /**
                 * Buscar en los anulados (ind_estado = 0) Rechazados(ind_estado
                 * = 1)
                 */
                T4541Bean inT4541bean = new T4541Bean();
                T4541Bean ouT4541bean = new T4541Bean();

                inT4541bean.setCod_cpe(codCpe);
                inT4541bean.setNum_ruc(datos.get("num_ruc"));
                inT4541bean.setNum_serie_cpe(datos.get("num_serie").trim());
                inT4541bean.setNum_cpe(new Integer(datos.get("num_comprob")));
                inT4541bean.setFec_emision(new FechaBean(datos.get("fec_emision")));
                inT4541bean.setInd_estado_cpe("1");

                ouT4541bean = t4541DAO.findByFiltro(inT4541bean);
                if (null == ouT4541bean) {
               //csantillan inicio PAS20231U210600160 	
                	log.info("buscarFacturaOrNotas log rest");
                   String comprobante = obtenerComprobanteElectronico(inT4241bean,"F");
                	if (comprobante==null||comprobante==""){
                    result.put("titulo", "La " + descCompro + " no existe en los registros de SUNAT.");
                	}else{
                		result.put("titulo", "La " + descCompro + " es un comprobante de pago v�lido.");
                	}
                //csantillan fin	
                } else {
                    result.put("titulo", "La " + descCompro + " fue rechazada por SUNAT " + (ouT4541bean != null ? " el " + ouT4541bean.getFec_registro_doc().getFormatDate("dd/MM/yyyy") : "") + ".");
                }
            } else {
                if (ouT4241bean.getInd_estado().trim().equals("0")) {
                    result.put("titulo", "La " + descCompro + " es un comprobante de pago v�lido.");
                } else if (ouT4241bean.getInd_estado().trim().equals("2")) {
                    Map<String, Object> mFecPres = t4703DAO.buscarFechaPresentacion(datos.get("num_ruc"), codCpe, datos.get("num_serie").trim(), new Integer(datos.get("num_comprob")));
                    result.put("titulo", "La " + descCompro + " fue comunicada de BAJA" + (mFecPres == null ? "." : " el " + new FechaBean((java.sql.Date) mFecPres.get("fec_registro")).getFormatDate("dd/MM/yyyy") + "."));
                }
            }
        }

        return result;
    }

    //poliza
    private Map<String, String> buscarPolizaAdjudicacionElectronica(Map<String, String> datos, String codCpe) throws ServiceException {
        Map<String, String> result = new HashMap<String, String>();

        T10194Bean inT10194bean = new T10194Bean();
        T10194Bean ouT10194bean = new T10194Bean();

        inT10194bean.setNum_ruc(datos.get("num_ruc"));
        inT10194bean.setCod_cpe(codCpe);
        inT10194bean.setCod_docide_persona(null);

        inT10194bean.setCod_docide_persona(datos.get("cod_docide") != null && !datos.get("cod_docide").toString().trim().equals("-") ? datos.get("cod_docide") : null);
        inT10194bean.setNum_docide_persona(datos.get("num_docide") != null && !datos.get("num_docide").toString().trim().equals("-") ? datos.get("num_docide") : null);
        inT10194bean.setNum_serie_cpe(datos.get("num_serie").trim());
        inT10194bean.setNum_cpe(new Integer(datos.get("num_comprob")));
        inT10194bean.setFec_emision(new FechaBean(datos.get("fec_emision")));
        inT10194bean.setMto_importe_total(new BigDecimal(datos.get("cantidad")));

        String descCompro = tipComproDesc[new Integer(codCpe).intValue()] + " " + datos.get("num_serie").trim() + "-" + datos.get("num_comprob") + " ";

        ouT10194bean = t10194DAO.findByFiltro(inT10194bean);
        if (null == ouT10194bean) {
                result.put("titulo", "La " + descCompro + " no existe en los registros de SUNAT.");
        } else {
            if (ouT10194bean.getInd_baja().trim().equals("0")) {
                result.put("titulo", "La " + descCompro + " es v�lido.");
            } else if (ouT10194bean.getInd_baja().trim().equals("1")) {
                result.put("titulo", "La " + descCompro + " existe pero se encuentra de baja. ");
            }else{
                result.put("titulo"," ---  "+ouT10194bean.getInd_baja().trim());
            }
        }

        return result;

    }

    private Map<String, String> buscarBoletaOrNotas(Map<String, String> datos, String codCpe) throws ServiceException {
    	
        Map<String, String> result = new HashMap<String, String>();
        String numSerie = datos.get("num_serie").trim().toUpperCase();

        if (numSerie.startsWith("B")) {

            T4704Bean inT4704bean = new T4704Bean();
            T4704Bean ouT4704bean = new T4704Bean();

            String descCompro = tipComproDesc[new Integer(codCpe).intValue()] + " " + datos.get("num_serie").trim() + "-" + datos.get("num_comprob") + " ";
            /**
             * Por norma solo las boletas se dan de baja no las NC ni ND. *
             * Observada
             */
            Map<String, Object> mFecBaja = t4703DAO.buscarFechaPresentacion(datos.get("num_ruc"), codCpe, datos.get("num_serie").trim(), new Integer(datos.get("num_comprob")));
            if (null != mFecBaja) {
                result.put("titulo", "La " + descCompro + " fue comunicada de BAJA el " + new FechaBean((java.sql.Date) mFecBaja.get("fec_registro")).getFormatDate("dd/MM/yyyy") + ".");
                return result;
            }
            //envios individuales
            T4241Bean inT4241bean = new T4241Bean();
            T4241Bean ouT4241bean = new T4241Bean();

            inT4241bean.setNum_ruc(datos.get("num_ruc"));
            inT4241bean.setNum_serie_cpe(datos.get("num_serie").trim());
            inT4241bean.setNum_cpe(new Integer(datos.get("num_comprob")));
            inT4241bean.setCod_cpe(codCpe);
            inT4241bean.setFec_emision(new FechaBean(datos.get("fec_emision")));
            ouT4241bean = t4241DAO.findByFiltro(inT4241bean);
            /**
             * Boleta Electr�nica Portal - MYPE
             */
            if (null == ouT4241bean) {
            	
            	//******INICIO PAS20221U210700022*******
            	log.debug("ValidaComprobanteElectronicoService.buscarBoletaOrNotas :: t4705dao.buscarComprobanteEnRangos");
            	List<T4705Bean> lst4705bean = t4705dao.buscarComprobanteEnRangos(datos.get("num_ruc"), codCpe, datos.get("num_serie").trim());
            	if(lst4705bean == null || lst4705bean.size() == 0) {
            		log.debug("ValidaComprobanteElectronicoService.buscarBoletaOrNotas :: No existe en rangos");
            		log.debug("ValidaComprobanteElectronicoService.buscarBoletaOrNotas :: t4704dao.findByFiltro");
            		//buscar especifico
                    inT4704bean.setNum_ruc(datos.get("num_ruc"));
                    inT4704bean.setCod_cpe(codCpe);
                    inT4704bean.setNum_serie_cpe(datos.get("num_serie").trim());
                    inT4704bean.setNum_desde(new Integer(datos.get("num_comprob")));
                    inT4704bean.setNum_hasta(new Integer(datos.get("num_comprob")));
                    inT4704bean.setFec_emision(new FechaBean(datos.get("fec_emision")));
                    inT4704bean.setInd_estado("0");

                    ouT4704bean = t4704DAO.findByFiltro(inT4704bean);
                    if (null != ouT4704bean) {
                        result.put("titulo", "La " + descCompro + " ha sido informada a SUNAT");
                    } else {
                    	
                    	//csantillan inicio PAS20231U210600160 	
                    	log.info("buscarFacturaOrNotas log rest");
                       String comprobante = obtenerComprobanteElectronico(inT4241bean,"B");
                    	if (comprobante==null||comprobante==""){
                        result.put("titulo", "La " + descCompro + " no existe en los registros de SUNAT.");
                    	}else{
                    		result.put("titulo", "La " + descCompro + " es un comprobante de pago v�lido.");
                    	}
                    //csantillan fin
                    	
                      //  result.put("titulo", "La " + descCompro + " no ha sido informada a SUNAT");
                    }
            	}
            	else {
            		int numCpe = Integer.parseInt(datos.get("num_comprob"));
            		log.debug("ValidaComprobanteElectronicoService.buscarBoletaOrNotas - t4704dao.findByFiltro:: Existe en rangos");
            		for(T4705Bean t4705Bean : lst4705bean ){
            			log.debug("ValidaComprobanteElectronicoService.buscarBoletaOrNotas :: t4705dao.buscarComprobanteEnRangos -- estado: " + t4705Bean.getNum_correlativo());
            			log.debug("ValidaComprobanteElectronicoService.buscarBoletaOrNotas :: numeroComprobante " + datos.get("num_comprob"));
            			log.debug("ValidateNotas.validate :: numHasta: " + t4705Bean.getNum_hasta());
            			if(t4705Bean.getNum_correlativo() == 1){  // Retorna el n�mero m�ximo del rango registrado 
            				if(numCpe <= t4705Bean.getNum_hasta()) {
            					result.put("titulo", "La " + descCompro + " ha sido informada a SUNAT");
            					break;// or continue para verificar el numero correlativo 2
            				}else {
            					log.debug("ValidaComprobanteElectronicoService.buscarBoletaOrNotas :: numeroComprobante " + datos.get("num_comprob") + " es mayor que numHasta: " + t4705Bean.getNum_hasta());
            					log.debug("ValidaComprobanteElectronicoService.buscarBoletaOrNotas :: t4704dao.findByFiltro");
            					inT4704bean.setNum_ruc(datos.get("num_ruc"));
                                inT4704bean.setCod_cpe(codCpe);
                                inT4704bean.setNum_serie_cpe(datos.get("num_serie").trim());
                                inT4704bean.setNum_desde(new Integer(datos.get("num_comprob")));
                                inT4704bean.setNum_hasta(new Integer(datos.get("num_comprob")));
                                inT4704bean.setFec_emision(new FechaBean(datos.get("fec_emision")));
                                inT4704bean.setInd_estado("0");
                                ouT4704bean = t4704DAO.findByFiltro(inT4704bean);
                                if (null != ouT4704bean) {
                                    result.put("titulo", "La " + descCompro + " ha sido informada a SUNAT");
                                } else {                                                            	
                                    result.put("titulo", "La " + descCompro + " no ha sido informada a SUNAT");
                                }
            				}
            			}
            			
            			if(t4705Bean.getNum_correlativo() == 2) {
            				log.debug("ValidaComprobanteElectronicoService.buscarBoletaOrNotas :: t4705dao.buscarComprobanteEnRangos -- estado: " + t4705Bean.getNum_correlativo());
                			log.debug("ValidaComprobanteElectronicoService.buscarBoletaOrNotas :: numeroComprobante " + datos.get("num_comprob"));
                			log.debug("ValidaComprobanteElectronicoService.buscarBoletaOrNotas :: numDesde: " + t4705Bean.getNum_desde());
                			log.debug("ValidaComprobanteElectronicoService.buscarBoletaOrNotas :: numHasta: " + t4705Bean.getNum_hasta());
                			if(numCpe >= t4705Bean.getNum_desde() && numCpe <= t4705Bean.getNum_hasta()) {
                				log.debug("ValidaComprobanteElectronicoService.buscarBoletaOrNotas :: numeroComprobante " + datos.get("num_comprob") + " esta entre numDesde: " + t4705Bean.getNum_desde() + " y numHasta: " + t4705Bean.getNum_hasta() );
            					log.debug("ValidaComprobanteElectronicoService.buscarBoletaOrNotas :: t4704dao.findByFiltro");
            					
            					inT4704bean.setNum_ruc(datos.get("num_ruc"));
                                inT4704bean.setCod_cpe(codCpe);
                                inT4704bean.setNum_serie_cpe(datos.get("num_serie").trim());
                                inT4704bean.setNum_desde(new Integer(datos.get("num_comprob")));
                                inT4704bean.setNum_hasta(new Integer(datos.get("num_comprob")));
                                inT4704bean.setFec_emision(new FechaBean(datos.get("fec_emision")));
                                inT4704bean.setInd_estado("0");
                                ouT4704bean = t4704DAO.findByFiltro(inT4704bean);
                                if (null != ouT4704bean) {
                                    result.put("titulo", "La " + descCompro + " ha sido informada a SUNAT");
                                } else {
                                    result.put("titulo", "La " + descCompro + " no ha sido informada a SUNAT");
                                }
                			}
            			}
            		}
            	}
            	//******FIN PAS20221U210700022*******
            } else if (ouT4241bean.getInd_rechazo().trim().equals("0")) {
                result.put("titulo", "La " + descCompro + " es un comprobante de pago v�lido.");

                Integer esOSE = ouT4241bean.getEs_ose() != null ? ouT4241bean.getEs_ose() : 0;
                result.put("esOSE", esOSE.toString());

            } else if (ouT4241bean.getInd_rechazo().trim().equals("1")) {
                //Buscar fecha de rechazo.
                /**
                 * Buscar en los anulados (ind_estado = 0) Rechazados(ind_estado
                 * = 1)
                 */
                T4541Bean inT4541bean = new T4541Bean();
                T4541Bean ouT4541bean = new T4541Bean();

                inT4541bean.setCod_cpe(codCpe);
                inT4541bean.setNum_ruc(datos.get("num_ruc"));
                inT4541bean.setNum_serie_cpe(datos.get("num_serie").trim());
                inT4541bean.setNum_cpe(new Integer(datos.get("num_comprob")));
                inT4541bean.setFec_emision(new FechaBean(datos.get("fec_emision")));
                inT4541bean.setInd_estado_cpe("1");

                ouT4541bean = t4541DAO.findByFiltro(inT4541bean);
                if (null == ouT4541bean) {
                    result.put("titulo", "La " + descCompro + " no existe en los registros de SUNAT.");
                } else {
                    result.put("titulo", "La " + descCompro + " fue rechazada por SUNAT " + (ouT4541bean != null ? " el " + ouT4541bean.getFec_registro_doc().getFormatDate("dd/MM/yyyy") : "") + ".");
                }
                return result;
            }
        } else if (numSerie.equals("EB01")) {
            T4241Bean inT4241bean = new T4241Bean();
            T4241Bean ouT4241bean = new T4241Bean();
            T4283Bean t4283BeanIn = null;
            T4283Bean t4283BeanOut = null;

            inT4241bean.setNum_ruc(datos.get("num_ruc"));
            inT4241bean.setCod_cpe(codCpe);
            //MSF: comentado para hacer comparacion posterior 
            //inT4241bean.setCod_docide_recep(datos.get("cod_docide")!=null && !datos.get("cod_docide").toString().trim().equals("-") ? (datos.get("cod_docide").equals("A")?datos.get("cod_docide"):"0"+datos.get("cod_docide")) : null );
            inT4241bean.setCod_docide_recep(null);
            boolean requiereIdcompara = false;
            if (datos.get("cod_docide") != null && !datos.get("cod_docide").toString().trim().equals("-")) {
                requiereIdcompara = true;
            }
            //MSF        	
            inT4241bean.setNum_docide_recep(datos.get("num_docide") != null && !datos.get("num_docide").toString().trim().equals("-") ? datos.get("num_docide") : null);
            inT4241bean.setNum_serie_cpe(datos.get("num_serie").trim());
            inT4241bean.setNum_cpe(new Integer(datos.get("num_comprob")));
            inT4241bean.setFec_emision(new FechaBean(datos.get("fec_emision")));
            inT4241bean.setMto_importe_total(new BigDecimal(datos.get("cantidad")));

            String descCompro = tipComproDesc[new Integer(codCpe).intValue()] + " " + datos.get("num_serie").trim() + "-" + datos.get("num_comprob") + " ";

            /**
             * Buscamos en los enviados y aceptados
             */
            ouT4241bean = t4241DAO.findByFiltro(inT4241bean);

            //MSF: compara documento de identidad
            if (requiereIdcompara) {
                if (ouT4241bean != null) {
                    if (ArrayUtils.contains(generaCodIdArray(datos.get("cod_docide")), ouT4241bean.getCod_docide_recep().trim())
                            && ouT4241bean.getNum_docide_recep().trim().equals(inT4241bean.getNum_docide_recep())) {
                        //coincide el documento de identidad
                        log.info(">>Coincide con Doc ID");
                    } else {
                        //NO coincide el documento de identidad
                        ouT4241bean = null;
                    }
                }
            }
            /**
             * Boleta Electr�nica Portal - MYPE
             */
            if (null == ouT4241bean) {
            	
            	//csantillan inicio PAS20231U210600160 	
            	log.info("buscarFacturaOrNotas log rest");
               String comprobante = obtenerComprobanteElectronico(inT4241bean,"B");
            	if (comprobante==null||comprobante==""){
                result.put("titulo", "La " + descCompro + " no existe en los registros de SUNAT.");
            	}else{
            		result.put("titulo", "La " + descCompro + " es un comprobante de pago v�lido.");
            	}
            	//csantillan fin
            	
               // result.put("titulo", "La " + descCompro + " no existe en los registros de SUNAT.");
            } else if (ouT4241bean.getInd_rechazo().trim().equals("0")) {
                result.put("titulo", "La " + descCompro + " es un comprobante de pago v�lido.");

                Integer esOSE = ouT4241bean.getEs_ose() != null ? ouT4241bean.getEs_ose() : 0;
                result.put("esOSE", esOSE.toString());

            } else if (ouT4241bean.getInd_rechazo().trim().equals("1")) { // Comprobange rechazado MYPE. 
                //Buscar fecha de rechazo.
                t4283BeanIn = new T4283Bean();
                t4283BeanIn.setNum_ruc(datos.get("num_ruc"));
                t4283BeanIn.setCod_cpe(codCpe);
                t4283BeanIn.setNum_serie_cpe(datos.get("num_serie").trim());
                t4283BeanIn.setNum_cpe(new Integer(datos.get("num_comprob")));
                t4283BeanIn.setCod_rubro(301);
                t4283BeanIn.setNum_fila_item(0);
                t4283BeanIn.setInd_cab_det("1");

                t4283BeanOut = t4283DAO.findRubro_ByRUC_codCPE_Serie_CPE_rubro_numFila_indcabdet(t4283BeanIn);

                result.put("titulo", "La " + descCompro + " fue rechazada por el contribuyente receptor" + (t4283BeanOut != null ? " el " + t4283BeanOut.getFec_rubro().getFormatDate("dd/MM/yyyy") : "") + ".");
            }
        }
        return result;
    }

    private Map<String, String> buscarGuiasBF(Map<String, String> datos, String codCpe) throws ServiceException {
        Map<String, String> result = new HashMap<String, String>();
        T4241Bean inT4241bean = new T4241Bean();
        T4241Bean ouT4241bean = new T4241Bean();

        inT4241bean.setNum_ruc(datos.get("num_ruc"));
        inT4241bean.setCod_cpe(codCpe);
        //MSF: comentado para hacer comparacion posterior 
        //inT4241bean.setCod_docide_recep(datos.get("cod_docide")!=null && !datos.get("cod_docide").toString().trim().equals("-") ? (datos.get("cod_docide").equals("A")?datos.get("cod_docide"):datos.get("cod_docide")) : null );
        inT4241bean.setCod_docide_recep(null);
        boolean requiereIdcompara = false;
        if (datos.get("cod_docide") != null && !datos.get("cod_docide").toString().trim().equals("-")) {
            requiereIdcompara = true;
        }
        //MSF
        inT4241bean.setNum_docide_recep(datos.get("num_docide") != null && !datos.get("num_docide").toString().trim().equals("-") ? datos.get("num_docide") : null);
        inT4241bean.setNum_serie_cpe(datos.get("num_serie").trim());
        inT4241bean.setNum_cpe(new Integer(datos.get("num_comprob")));
        inT4241bean.setFec_emision(new FechaBean(datos.get("fec_emision")));

        String descCompro = "";

        //Se elabora descCompro para el mensaje de respuesta
        if (codCpe.equalsIgnoreCase("60")) {
            descCompro = descCompro + "Gu�a de remisi�n electr�nica - Remitente";
        } else if (codCpe.equalsIgnoreCase("61")) {
            descCompro = descCompro + "Gu�a de remisi�n electr�nica - Remitente complementaria";
        } else if (codCpe.equalsIgnoreCase("62")) {
            descCompro = descCompro + "Gu�a de remisi�n electr�nica - Transportista";
        } else if (codCpe.equalsIgnoreCase("63")) {
            descCompro = descCompro + "Gu�a de remisi�n electr�nica - Transportista complementaria";
        }
        descCompro = descCompro + " " + datos.get("num_serie").trim() + "-" + datos.get("num_comprob") + " ";

        //Se busca en T4241cabcpe
        ouT4241bean = t4241DAO.findByFiltroGreBf(inT4241bean);

        //MSF: compara documento de identidad
        if (requiereIdcompara) {
            if (ouT4241bean != null) {
                if (ArrayUtils.contains(generaCodIdArray(datos.get("cod_docide")), ouT4241bean.getCod_docide_recep().trim())
                        && ouT4241bean.getNum_docide_recep().trim().equals(inT4241bean.getNum_docide_recep())) {
                    //coincide el documento de identidad
                    log.info(">>Coincide con Doc ID");
                } else {
                    //NO coincide el documento de identidad
                    ouT4241bean = null;
                }
            }
        }

        //Valida Serie de GRE, por defecto G001
        if (inT4241bean.getNum_serie_cpe().toUpperCase().startsWith("G")) {
            if (null == ouT4241bean) {
                result.put("titulo", "La " + descCompro + " no existe en los registros de SUNAT.");
            } else if (ouT4241bean.getInd_estado().trim().equals("0")) {
                result.put("titulo", "La " + descCompro + " es v�lido.");
            } else if (ouT4241bean.getInd_estado().trim().equals("1")) { // guia de baja 
                result.put("titulo", "La " + descCompro + " existe pero se encuentra de baja.");
            }
        }
        return result;
    }

    // --- Inicio [jpozo] ---
    private Map<String, String> buscarBoletaVentaSimplificada(Map<String, String> datos, String codCpe) throws ServiceException {
        Map<String, String> result = new HashMap<String, String>();
        T4241Bean inT4241bean = new T4241Bean();
        T4241Bean ouT4241bean = new T4241Bean();

        inT4241bean.setNum_ruc(datos.get("num_ruc"));
        inT4241bean.setCod_cpe(codCpe);
        //MSF: comentado para hacer comparacion posterior 
        //inT4241bean.setCod_docide_recep(datos.get("cod_docide")!=null && !datos.get("cod_docide").toString().trim().equals("-") ? (datos.get("cod_docide").equals("A")?datos.get("cod_docide"):datos.get("cod_docide")) : null );
        inT4241bean.setCod_docide_recep(null);
        boolean requiereIdcompara = false;
        if (datos.get("cod_docide") != null && !datos.get("cod_docide").toString().trim().equals("-")) {
            requiereIdcompara = true;
        }
        //MSF
        inT4241bean.setNum_docide_recep(datos.get("num_docide") != null && !datos.get("num_docide").toString().trim().equals("-") ? datos.get("num_docide") : null);
        inT4241bean.setNum_serie_cpe(datos.get("num_serie").trim());
        inT4241bean.setNum_cpe(new Integer(datos.get("num_comprob")));
        inT4241bean.setFec_emision(new FechaBean(datos.get("fec_emision")));
        inT4241bean.setMto_importe_total(new BigDecimal(datos.get("cantidad")));

        //Se busca en T4241cabcpe
        ouT4241bean = t4241DAO.findByFiltroGreBf(inT4241bean);

        //MSF: compara documento de identidad
        if (requiereIdcompara) {
            if (ouT4241bean != null) {
                if (ArrayUtils.contains(generaCodIdArray(datos.get("cod_docide")), ouT4241bean.getCod_docide_recep().trim())
                        && ouT4241bean.getNum_docide_recep().trim().equals(inT4241bean.getNum_docide_recep())) {
                    //coincide el documento de identidad
                    log.info(">>Coincide con Doc ID");
                } else {
                    //NO coincide el documento de identidad
                    ouT4241bean = null;
                }
            }
        }

        if (null == ouT4241bean) {
            result.put("titulo", "El comprobante de pago no ha sido informado a la SUNAT.");
        } else if (ouT4241bean.getInd_estado().trim().equals("0")) {
            result.put("titulo", "El comprobante de pago fue informado a la SUNAT.");
        } else if (ouT4241bean.getInd_estado().trim().equals("1")) { // aun por definir
            result.put("titulo", "El comprobante de pago existe, pero se encuentra de baja.");
        }

        return result;
    }
    // --- Fin [jpozo] ---

    //Ini PAS20175E210300094
    private Map<String, String> buscarTicketPOS(Map<String, String> datos) throws ServiceException {
        Map<String, String> result = new HashMap<String, String>();
        result.put("exito", "0");
        String numSerie = datos.get("num_serie").trim().toUpperCase();
        String numRuc = datos.get("num_ruc").trim();
        String codDocIdeCliente = (datos.get("cod_docide") == null) ? "" : datos.get("cod_docide").trim();
        String numDocIdeCliente = (datos.get("num_docide") == null) ? "" : datos.get("num_docide").trim();
        String fecEmision = datos.get("fec_emision").trim();
        String mtoTotal = datos.get("cantidad").trim();
        String numTran = datos.get("num_comprob").trim();

        //1. La serie debe validarse q corresponda con el ruc del PSE-CF, t1331rucpac - num_doc, ind_proc=48 padron del PSE-CF
        T1331Bean t1331Bean = new T1331Bean();
        t1331Bean.setIndProceso(48);
        t1331Bean.setIndEstado("00");
        t1331Bean.setNumeroDoc(numSerie);

        List<T1331Bean> t1331BeanResult = t1331DAO.select(t1331Bean);

        if (t1331BeanResult.size() > 0) {

            //2. Se verifica el comprobante Ticket POS
            T6236Bean t6236Bean = new T6236Bean();
            t6236Bean.setInd_vigente("1");
            t6236Bean.setNum_ruc(t1331BeanResult.get(0).getNumeroDeRUC());

            T6235Bean t6235Bean = new T6235Bean();
            t6235Bean.setT6236Bean(t6236Bean);
            if (!codDocIdeCliente.equals("")) {
                t6235Bean.setCod_docide_cliente(codDocIdeCliente);
            }
            if (!numDocIdeCliente.equals("")) {
                t6235Bean.setNum_docide_cliente(numDocIdeCliente);
            }
            t6235Bean.setFec_emision(new FechaBean(fecEmision));
            t6235Bean.setMto_total(new BigDecimal(mtoTotal));
            t6235Bean.setNum_ruc(numRuc);
            t6235Bean.setNum_serie(numSerie);
            t6235Bean.setNum_tran(numTran);

            List<T6235Bean> t6235BeanResult = t6235DAO.findByFiltro(t6235Bean);

            if (t6235BeanResult.size() > 0) {
                result.put("exito", "1");
                result.put("titulo", "El Ticket POS " + numSerie + "-" + numTran + " es un comprobante de pago v�lido.");
            } else {
                result.put("titulo", "El Ticket POS " + numSerie + "-" + numTran + " no existe en los registros de SUNAT.");
            }

        } else {
            //La serie no corresponde al RUC del PSE-CF
            result.put("titulo", "El Ticket POS " + numSerie + "-" + numTran + " no existe en los registros de SUNAT.");
        }

        return result;
    }
    //Fin PAS20175E210300094

    //Inicio PAS20181U210300013
    private Map<String, String> buscarTicketME(Map<String, String> datos) throws ServiceException {
        Map<String, String> result = new HashMap<String, String>();
        result.put("exito", "0");
        String numSerie = datos.get("num_serie").trim().toUpperCase();
        String numRuc = datos.get("num_ruc").trim();
        String codDocIdeCliente = (datos.get("cod_docide") == null) ? "" : datos.get("cod_docide").trim();
        String numDocIdeCliente = (datos.get("num_docide") == null) ? "" : datos.get("num_docide").trim();
        String fecEmision = datos.get("fec_emision").trim();
        String mtoTotal = datos.get("cantidad").trim();
        String numTran = datos.get("num_comprob").trim();

        //tipo comprobante
        String tipComp = datos.get("tipocomprobante").trim().toUpperCase();
        tipComp = tipComp.substring(3, 5);
        //log.debug("tipComp:"+tipComp);
        //1. La serie debe validarse q corresponda con el ruc del PSE-ME, t1331rucpac - num_doc, ind_proc=50 padron del PSE-ME
        T1331Bean t1331Bean = new T1331Bean();
        t1331Bean.setIndProceso(50);
        t1331Bean.setIndEstado("00");
        t1331Bean.setNumeroDoc(numSerie);

        List<T1331Bean> t1331BeanResult = t1331DAO.selectTME(t1331Bean);

        if (t1331BeanResult.size() > 0) {

            //2. Se verifica el comprobante Ticket ME
            T8248Bean t8248Bean = new T8248Bean();
            t8248Bean.setInd_vigente("1");
            t8248Bean.setNum_ruc(t1331BeanResult.get(0).getNumeroDeRUC());

            T8249Bean t8249Bean = new T8249Bean();
            t8249Bean.setT8248Bean(t8248Bean);
            if (!codDocIdeCliente.equals("")) {
                t8249Bean.setTip_doc_idecliente(codDocIdeCliente);
            }
            if (!numDocIdeCliente.equals("")) {
                t8249Bean.setNum_doc_idecliente(numDocIdeCliente);
            }
            t8249Bean.setFec_emision_cp(new FechaBean(fecEmision));
            t8249Bean.setMto_total(new BigDecimal(mtoTotal));
            t8249Bean.setNum_ruc_emisor(numRuc);
            t8249Bean.setNum_serie_cp(numSerie);
            t8249Bean.setNum_cp(numTran);

            t8249Bean.setTip_cp(tipComp);

            List<T8249Bean> t8249BeanResult = t8249DAO.findByFiltro(t8249Bean);

            if (t8249BeanResult.size() > 0) {

                if (tipComp.equals("12")) {
                    result.put("exito", "1");
                    result.put("titulo", "El Ticket ME " + numSerie + "-" + numTran + " es un comprobante de pago v�lido.");
                } else if (tipComp.equals("07")) {
                    result.put("exito", "1");
                    result.put("titulo", "La Nota de Cr�dito ME " + numSerie + "-" + numTran + " es un comprobante de pago v�lido.");
                }

            } else {
                if (tipComp.equals("12")) {
                    result.put("titulo", "El Ticket ME " + numSerie + "-" + numTran + " no existe en los registros de SUNAT.");
                } else if (tipComp.equals("07")) {
                    result.put("titulo", "La Nota de Cr�dito ME " + numSerie + "-" + numTran + " no existe en los registros de SUNAT.");
                }

            }

        } else {

            //La serie no corresponde al RUC del ME
            if (tipComp.equals("12")) {
                result.put("titulo", "El Ticket ME " + numSerie + "-" + numTran + " no existe en los registros de SUNAT.");
            } else if (tipComp.equals("07")) {
                result.put("titulo", "La Nota de Cr�dito ME " + numSerie + "-" + numTran + " no existe en los registros de SUNAT.");
            }

        }

        return result;
    }
    //Fin PAS20181U210300013
    
    ////INICIO - PAS20201U210100038
    private Map<String, String> buscarOperador(Map<String, String> datos, String codCpe) throws ServiceException {
        Map<String, String> result = new HashMap<String, String>();

        T10209Bean inT10209bean = new T10209Bean();
        T10209Bean ouT10209bean = new T10209Bean();

        inT10209bean.setNum_ruc(datos.get("num_ruc"));
        inT10209bean.setCod_cpe(codCpe);

        inT10209bean.setCod_docide_recep(datos.get("cod_docide") != null && !datos.get("cod_docide").toString().trim().equals("-") ? datos.get("cod_docide") : null);
        inT10209bean.setNum_docide_recep(datos.get("num_docide") != null && !datos.get("num_docide").toString().trim().equals("-") ? datos.get("num_docide") : null);
        inT10209bean.setNum_serie_cpe(datos.get("num_serie").trim());
        inT10209bean.setNum_cpe(new Integer(datos.get("num_comprob")));
        inT10209bean.setFec_emision(new FechaBean(datos.get("fec_emision")));
        
        if (datos.get("cantidad") != null && !datos.get("cantidad").trim().equals("")) {
        	inT10209bean.setMto_importe_total(new BigDecimal(datos.get("cantidad")));
        }

        String descCompro = tipComproDesc[new Integer(codCpe).intValue()] + " N�mero " + datos.get("num_serie").trim() + "-" + datos.get("num_comprob") + " ";

        ouT10209bean = t10209DAO.findByFiltro(inT10209bean);
        if (null == ouT10209bean) {
                result.put("titulo", "El Documento del " + descCompro + " no ha sido informada a SUNAT ");
        } else {
            if (ouT10209bean.getInd_estado().trim().equals("0")) {
                result.put("titulo", "El Documento del " + descCompro + ", ha sido informada a SUNAT ");
            } else if (ouT10209bean.getInd_estado().trim().equals("2")) {
                result.put("titulo", "El Documento del " + descCompro + " existe pero se encuentra dado de baja. ");
            }else{
                result.put("titulo"," ---  "+ouT10209bean.getInd_estado().trim());
            }
        }

        return result;
    }
    
    private Map<String, String> buscarAdquiriente(Map<String, String> datos, String codCpe) throws ServiceException {
        Map<String, String> result = new HashMap<String, String>();

        T10204Bean inT10204bean = new T10204Bean();
        T10204Bean ouT10204bean = new T10204Bean();

        inT10204bean.setNum_ruc(datos.get("num_ruc"));
        inT10204bean.setCod_cpe(codCpe);

        inT10204bean.setCod_docide_recep(datos.get("cod_docide") != null && !datos.get("cod_docide").toString().trim().equals("-") ? datos.get("cod_docide") : null);
        inT10204bean.setNum_docide_recep(datos.get("num_docide") != null && !datos.get("num_docide").toString().trim().equals("-") ? datos.get("num_docide") : null);
        inT10204bean.setNum_serie_cpe(datos.get("num_serie").trim());
        inT10204bean.setNum_cpe(new Integer(datos.get("num_comprob")));
        inT10204bean.setFec_emision(new FechaBean(datos.get("fec_emision")));
        
        if (datos.get("cantidad") != null && !datos.get("cantidad").trim().equals("")) {
        	inT10204bean.setMto_importe_total(new BigDecimal(datos.get("cantidad")));
        }

        String descCompro = tipComproDesc[new Integer(codCpe).intValue()] + " N�mero " + datos.get("num_serie").trim() + "-" + datos.get("num_comprob") + " ";

        ouT10204bean = t10204DAO.findByFiltro(inT10204bean);
        if (null == ouT10204bean) {
                result.put("titulo", "El Documento del " + descCompro + " no ha sido informada a SUNAT");
        } else {
            if (ouT10204bean.getInd_estado().trim().equals("0")) {
                result.put("titulo", "El Documento del " + descCompro + ", ha sido informada a SUNAT");
            } else if (ouT10204bean.getInd_estado().trim().equals("2")) {
                result.put("titulo", "El Documento del " + descCompro + " existe pero se encuentra dado de baja. ");
            }else{
                result.put("titulo"," ---  "+ouT10204bean.getInd_estado().trim());
            }
        }

        return result;
    }
    
    /////FIN - PAS20201U210100038

    public void setConstantes(Properties constantes) {
        this.constantes = constantes;
    }

    public void setT3639DAO(T3639DAO t3639dao) {
        t3639DAO = t3639dao;
    }

    public void setT3634DAO(T3634DAO t3634dao) {
        t3634DAO = t3634dao;
    }

    public void setT4241DAO(T4241DAO t4241dao) {
        t4241DAO = t4241dao;
    }
    
    public void setT10194DAO(T10194DAO t10194dao) {
        t10194DAO = t10194dao;
    }

    public void setT4541DAO(T4541DAO t4541dao) {
        t4541DAO = t4541dao;
    }

    public void setT4704DAO(T4704DAO t4704dao) {
        t4704DAO = t4704dao;
    }

    public void setT4283DAO(T4283DAO t4283dao) {
        t4283DAO = t4283dao;
    }

    public void setT4703DAO(T4703DAO t4703dao) {
        t4703DAO = t4703dao;
    }
    
    public T4705DAOSelect getT4705dao() {
		return t4705dao;
	}

	public void setT4705dao(T4705DAOSelect t4705dao) {
		this.t4705dao = t4705dao;
	}

	//Ini PAS20175E210300094
    public T1331DAO getT1331DAO() {
        return t1331DAO;
    }

    public void setT1331DAO(T1331DAO t1331dao) {
        t1331DAO = t1331dao;
    }

    public T6235DAO getT6235DAO() {
        return t6235DAO;
    }

    public void setT6235DAO(T6235DAO t6235dao) {
        t6235DAO = t6235dao;
    }

    public T01DAO getT01DAO() {
        return t01DAO;
    }

    public void setT01DAO(T01DAO t01dao) {
        t01DAO = t01dao;
    }

    public DdpDAO getDdpDAO() {
        return ddpDAO;
    }

    public void setDdpDAO(DdpDAO ddpDAO) {
        this.ddpDAO = ddpDAO;
    }
    //Fin PAS20175E210300094

    public T8249DAO getT8249DAO() {
        return t8249DAO;
    }

    public void setT8249DAO(T8249DAO t8249dao) {
        t8249DAO = t8249dao;
    }
    
    public void setT10204DAO(T10204DAO t10204dao) {
        t10204DAO = t10204dao;
    }
    
    public void setT10209DAO(T10209DAO t10209dao) {
        t10209DAO = t10209dao;
    }

    private String[] generaCodIdArray(String codIde) {
        log.info(">>codIde=" + codIde);
        String codIdeAdd = "";
        if (codIde != null && !codIde.equals("-")) {
            codIdeAdd = "0" + codIde;
        } else {
            return null;
        }
        String[] rsp = {codIde, codIdeAdd};
        log.info(">>codIdeAdd=" + codIdeAdd);
        return rsp;
    }

    @SuppressWarnings("unused")
    @Override
    public pe.gob.sunat.servicio2.registro.electronico.comppago.boleta.bean.ArchivoComprobanteBean descargarBoleta(Map<String, String> params) throws IOException {
        if (log.isDebugEnabled()) {
            log.debug("descargarBoleta( " + params + " )");
        }

        String xtipo = BOLETA_VENTA_GEM;
        if (params.get("tipo").toString().trim().equals("11")) {
            xtipo = NOTA_CREDITO_GEM;
        }
        if (params.get("tipo").toString().trim().equals("12")) {
            xtipo = NOTA_DEBITO_GEM;
        }

        T4243Bean bean;
        //if (isGem) {
        bean = t4243DAO.findFileZipJoinTCabCPETRelcompelecTFESTOREByPrimaryKey(params.get("ruc"), xtipo, params.get("serie"), new Integer(params.get("numero")));
        //} else {
        //   bean = t4243DAO.findFileXmlJoinTCabCPETArcXmlByPrimaryKeyISO88591(params.get("ruc"), xtipo, params.get("serie"), new Integer(params.get("numero")));
        //}		

        if (bean != null) {

            pe.gob.sunat.servicio2.registro.electronico.comppago.boleta.bean.ArchivoComprobanteBean beanFile = new pe.gob.sunat.servicio2.registro.electronico.comppago.boleta.bean.ArchivoComprobanteBean();
            beanFile.setNumeroRuc(params.get("ruc"));
            beanFile.setTipoComprobante(params.get("tipo"));
            beanFile.setSerieComprobante(params.get("serie"));
            beanFile.setNumeroComprobante(new Integer(params.get("numero")));
            //if (isGem) {
            beanFile.setContenidoArchivoXml(new String(decompress(bean.getArc_zip())));
            //} else {
            //beanFile.setContenidoArchivoXml(bean.getArc_xml());
            //}

            beanFile.setAdjuntaVisor(false);
            //if (params.get("adjuntaVisor") != null)
            //beanFile.setAdjuntaVisor(Boolean.parseBoolean(params.get("adjuntaVisor")));

            if (xtipo.equals(BOLETA_VENTA_GEM)) {
                beanFile.setTipoComprobante(ComprobanteUtilBean.BOLETA);
            }
            if (xtipo.equals(NOTA_CREDITO_GEM)) {
                beanFile.setTipoComprobante(ComprobanteUtilBean.NOTA_CREDITO);
            }
            if (xtipo.equals(NOTA_DEBITO_GEM)) {
                beanFile.setTipoComprobante(ComprobanteUtilBean.NOTA_DEBITO);
            }

            beanFile.setArchivoXml(archivoServiceBVE.generarArchivoXML(beanFile));
            beanFile.setArchivoZip(archivoServiceBVE.generarArchivoZip(beanFile));
            beanFile.setContenidoArchivoZip(archivoServiceBVE.getContenidoArchivoBin(beanFile.getArchivoZip()));

            return beanFile;

        } else {
            MensajeBean msg = new MensajeBean();
            msg.setError(false);
            msg.setMensajeerror("No existe boleta a descargar.");
            throw new ServiceException(this, msg);
        }
    }

    public byte[] decompress(byte[] data) {

        try {

            InputStream theFile = new ByteArrayInputStream(data);
            ZipInputStream stream = new ZipInputStream(theFile);
            byte[] buffer = new byte[2048];
            ByteArrayOutputStream outputStream = new ByteArrayOutputStream(data.length);

            ZipEntry entry;
            while ((entry = stream.getNextEntry()) != null) {
                String s = String.format("Entry: %s len %d added %TD",
                        entry.getName(), entry.getSize(),
                        new Date(entry.getTime()));
                if (log.isDebugEnabled()) {
                    log.debug(s);
                }

                try {
                    outputStream = new ByteArrayOutputStream();;
                    int len = 0;
                    while ((len = stream.read(buffer)) > 0) {
                        outputStream.write(buffer, 0, len);
                    }
                } finally {
                    if (outputStream != null) {
                        outputStream.close();
                    }
                }
            }

            byte[] output = outputStream.toByteArray();
            return output;
        } catch (IOException e) {
            log.error(">>ConsultarServiceImpl Error !! " + e.getMessage(), e);
            MensajeBean msg = new MensajeBean();
            msg.setError(true);
            msg.setMensajeerror("Error al tratar de descomprimir el archivo ZIP");
            throw new ServiceException(this, msg);
        }

    }

    public T4243DAO getT4243DAO() {
        return t4243DAO;
    }

    public void setT4243DAO(T4243DAO t4243dao) {
        t4243DAO = t4243dao;
    }

    @Override
    public Map<String, Object> generarPDF(byte[] archivoXml, String tipo) {
        // TODO Auto-generated method stub

        log.info("generarPDF");
        Map<String, Object> mapa = new HashMap<String, Object>();
        DateFormat fmt = new SimpleDateFormat("dd/MM/yyyy");

        try {
            ByteArrayOutputStream bos = new ByteArrayOutputStream();
            ZipInputStream zipStream = new ZipInputStream(new ByteArrayInputStream(archivoXml));
            ZipEntry entry = null;
            byte[] byteBuff = null;
            while ((entry = zipStream.getNextEntry()) != null) {
                byteBuff = new byte[4096];
                int bytesRead = 0;
                try {
                    while ((bytesRead = zipStream.read(byteBuff)) != -1) {
                        bos.write(byteBuff, 0, bytesRead);
                    }
                } catch (IOException e) {
                    // TODO Auto-generated catch block
                    e.printStackTrace();
                }
                zipStream.closeEntry();
            }
            zipStream.close();

            log.info("asignando a map");
            log.info("bos" + bos.toString());

//			mapa.put("FechaVencimiento", "");
//			mapa.put("Observacion", "");			
//			mapa.put("DocRelacionado1", "");
//			mapa.put("DocRelacionado2", "");
//			mapa.put("DocRelacionado3", "");
//			mapa.put("DocRelacionado4", "");
//			mapa.put("DocRelacionado5", "");
//			mapa.put("DocRelacionado6", "");
//			mapa.put("DocRelacionado7", "");
//			mapa.put("DocRelacionado8", "");
//			mapa.put("DocRelacionado9", "");
//			mapa.put("DocRelacionado10", "");
//			mapa.put("ventaItinerante", "");			
//			mapa.put("numeroExpediente", "");
//			mapa.put("unidadEjecutora", "");
//			mapa.put("procesoSeleccion", "");
//			mapa.put("numeroContrato", "");
//			mapa.put("ordenDeCompra", "");
//			mapa.put("placaVentaCombustible", "");
//			mapa.put("DesTipoLugarEntrega", "");
//			mapa.put("LugarEntrega", "");
            XPathFactory Xfactory = XPathFactory.newInstance();
            xPath = Xfactory.newXPath();

            String nm = "";
            String tagCompDetalle = "";
            String tagCompDetalleCantidad = "";
            String tagCompDetalleUnidad = "";
            String tagCompDetalleCodigo = "";

            if ("BOLETA".equals(tipo)) {
                xPath.setNamespaceContext(new BoletaNamespace());
                nm = "/sunat:Invoice";
                tagCompDetalle = "/cac:InvoiceLine";
                tagCompDetalleCantidad = "cbc:InvoicedQuantity";
                tagCompDetalleUnidad = "cbc:InvoicedQuantity/@unitCode";
                tagCompDetalleCodigo = "cac:Item/cac:CatalogueDocumentReference/cbc:ID";
                mapa.put("plantilla", "boletapdf");
                mapa.put("jasper", "/PLANTILLA000846.jrxml");

            } else if ("NOTA_CREDITO".equals(tipo)) {
                xPath.setNamespaceContext(new NotaCreditoNamespace());
                nm = "/sunat:CreditNote";
                mapa.put("plantilla", "ncboletapdf");
                mapa.put("jasper", "/PLANTILLA000862.jrxml");
                tagCompDetalle = "/cac:CreditNoteLine";
                tagCompDetalleCantidad = "cbc:CreditedQuantity";
                tagCompDetalleUnidad = "cbc:CreditedQuantity/@unitCode";
                tagCompDetalleCodigo = "cac:Item/cac:SellersItemIdentification/cbc:ID";

            } else if ("NOTA_DEBITO".equals(tipo)) {
                xPath.setNamespaceContext(new NotaDebitoNamespace());
                nm = "/sunat:DebitNote";
                mapa.put("plantilla", "ndboletapdf");
                mapa.put("jasper", "/PLANTILLA000864.jrxml");
                tagCompDetalle = "/cac:DebitNoteLine";
                tagCompDetalleCantidad = "cbc:DebitedQuantity";
                tagCompDetalleUnidad = "cbc:DebitedQuantity/@unitCode";
                tagCompDetalleCodigo = "cac:Item/cac:SellersItemIdentification/cbc:ID";

            }

            log.info("Lee el DOm");
            DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();
            factory.setNamespaceAware(true);
            DocumentBuilder builder = factory.newDocumentBuilder();
            Document document = builder.parse(new ByteArrayInputStream(bos.toByteArray()));
            document.getDocumentElement().normalize();

            String documoriginal = (String) xPath.evaluate(nm + "/cac:DiscrepancyResponse/cbc:ReferenceID", document, XPathConstants.STRING);

            if (!"".equals(documoriginal)) {
                String serieModifica = documoriginal.substring(0, documoriginal.indexOf("-")).trim();
                String numeroModifica = documoriginal.substring(documoriginal.indexOf("-") + 1).trim();
                mapa.put("SerieFactura", serieModifica);
                mapa.put("NumeroFactura", numeroModifica);
            }

            String tipoNota = xPath.evaluate(nm + "/cac:DiscrepancyResponse/cbc:ResponseCode", document, XPathConstants.STRING).toString();
            String glosa = obtenerDescCatalogo09(tipoNota);
            mapa.put("glosa", glosa);

            String serieNumero = (String) xPath.evaluate(nm + "/cbc:ID", document, XPathConstants.STRING);
//			String serieNumero = obtenerValorNodo(document.getDocumentElement(), "cbc:ID");
            log.info("serieNumero:" + serieNumero);
            mapa.put("SerieComprobante", "");
            mapa.put("NumeroComprobante", "");
            mapa.put("serieNumeroFE", serieNumero);

            if (!"".equals(serieNumero)) {
                String[] serieNumeros = serieNumero.split("-");
                if (serieNumeros[0] != null) {
                    mapa.put("SerieComprobante", serieNumeros[0]);
                }
                if (serieNumeros[1] != null) {
                    mapa.put("NumeroComprobante", serieNumeros[1]);
                }
            }

            String fechaEmision = (String) xPath.evaluate(nm + "/cbc:IssueDate", document, XPathConstants.STRING);
//			String fechaEmision = obtenerValorNodo(document.getDocumentElement(), "cbc:IssueDate");
            if (!"".equals(fechaEmision)) {
                String[] fechas = fechaEmision.split("-");
                fechaEmision = fechas[2] + "/" + fechas[1] + "/" + fechas[0];
            }
            mapa.put("FechaEmision", fechaEmision);

            String descripcionMoneda = "";
            if (!xPath.evaluate(nm + "/cbc:DocumentCurrencyCode", document, XPathConstants.STRING).equals("")) {
                descripcionMoneda = (String) xPath.evaluate(nm + "/cbc:DocumentCurrencyCode", document, XPathConstants.STRING);
            } else {
                descripcionMoneda = (String) xPath.evaluate(nm + "/cac:LegalMonetaryTotal/cbc:PayableAmount/@currencyID", document, XPathConstants.STRING);
            }
            mapa.put("DescripcionMoneda", descripcionMoneda);
            log.info("DescripcionMoneda:" + descripcionMoneda);

            //DATOS DEL EMISOR
            mapa.put("NumeroDireccion", "");

            String ubigeo = (String) xPath.evaluate(nm + "/cac:AccountingSupplierParty/cac:Party/cac:PostalAddress/cbc:ID", document, XPathConstants.STRING);
            mapa.put("Ubigeo", ubigeo);
            log.info("ubigeo:" + ubigeo);

            String numeroRuc = (String) xPath.evaluate(nm + "/cac:AccountingSupplierParty/cbc:CustomerAssignedAccountID", document, XPathConstants.STRING);
            mapa.put("NumeroRuc", numeroRuc);
            log.info("NumeroRUC:" + numeroRuc);

            String razonSocial = (String) xPath.evaluate(nm + "/cac:AccountingSupplierParty/cac:Party/cac:PartyLegalEntity/cbc:RegistrationName", document, XPathConstants.STRING);
            mapa.put("RazonSocial", razonSocial);
            log.info("RazonSocial:" + razonSocial);

            String razonComercial = (String) xPath.evaluate(nm + "/cac:AccountingSupplierParty/cac:Party/cac:PartyName/cbc:Name", document, XPathConstants.STRING);
            mapa.put("RazonComercial", razonComercial);
            log.info("RazonComercial:" + razonComercial);

            String calle = (String) xPath.evaluate(nm + "/cac:AccountingSupplierParty/cac:Party/cac:PostalAddress/cbc:StreetName", document, XPathConstants.STRING);
            mapa.put("NombreCalle", calle);
            log.info("calle:" + calle);

            String distrito = (String) xPath.evaluate(nm + "/cac:AccountingSupplierParty/cac:Party/cac:PostalAddress/cbc:District", document, XPathConstants.STRING);
            mapa.put("NombreDistrito", distrito);
            log.info("distrito:" + distrito);

            String provincia = (String) xPath.evaluate(nm + "/cac:AccountingSupplierParty/cac:Party/cac:PostalAddress/cbc:CityName", document, XPathConstants.STRING);
            mapa.put("NombreProvincia", provincia);
            log.info("provincia:" + provincia);

            String departamento = (String) xPath.evaluate(nm + "/cac:AccountingSupplierParty/cac:Party/cac:PostalAddress/cbc:CountrySubentity", document, XPathConstants.STRING);
            mapa.put("NombreDepartamento", departamento);
            log.info("departamento:" + departamento);

            if (!"".equals(departamento) && !"".equals(provincia) && !"".equals(distrito)) {
                ubigeo = departamento + " - " + provincia + " - " + distrito;
                mapa.put("Ubigeo", ubigeo);
            }

            //DATOS DEL CLIENTE
            String nombreCliente = (String) xPath.evaluate(nm + "/cac:AccountingCustomerParty/cac:Party/cac:PartyLegalEntity/cbc:RegistrationName", document, XPathConstants.STRING);
            mapa.put("NombreCliente", nombreCliente);
            log.info("NombreCliente:" + nombreCliente);

            String desTipoDocumentoCliente = (String) xPath.evaluate(nm + "/cac:AccountingCustomerParty/cbc:AdditionalAccountID", document, XPathConstants.STRING);
            String descdoc = "";
            if ("6".equals(desTipoDocumentoCliente)) {
                descdoc = "RUC";
            } else if ("1".equals(desTipoDocumentoCliente)) {
                descdoc = "DNI";
            } else if ("4".equals(desTipoDocumentoCliente)) {
                descdoc = "CARNET EXTRANJERIA";
            } else if ("7".equals(desTipoDocumentoCliente)) {
                descdoc = "PASAPORTE";
            }

            mapa.put("DesTipoDocumentoCliente", descdoc);
            log.info("DesTipoDocumentoCliente:" + desTipoDocumentoCliente);
            log.info("descdoc:" + descdoc);

            String numeroDocumentoCliente = (String) xPath.evaluate(nm + "/cac:AccountingCustomerParty/cbc:CustomerAssignedAccountID", document, XPathConstants.STRING);
            mapa.put("NumeroDocumentoCliente", numeroDocumentoCliente);
            log.info("NumeroDocumentoCliente:" + numeroDocumentoCliente);

            //TOTALES
            log.info("Buscamos montos totales");

            BigDecimal totalOtrosTributos = new BigDecimal(0);
            BigDecimal totalOtrosCargos = new BigDecimal(0);
            BigDecimal totalISC = new BigDecimal(0);
            BigDecimal totalIGV = new BigDecimal(0);
            BigDecimal igvPorcentaje = new BigDecimal(0);
            BigDecimal aValorVenta = new BigDecimal(0);
            BigDecimal aValorVentaNoGravado = new BigDecimal(0);
            BigDecimal aValorVentaExonerado = new BigDecimal(0);
            BigDecimal aImporteDePercepcion = new BigDecimal(0);
            BigDecimal aTotalDescuentos = new BigDecimal(0);

            //subtotal ventas			
            BigDecimal subTotalVentas = new BigDecimal(0.0);

            NodeList totalesVenta = (NodeList) xPath.evaluate(nm + "/ext:UBLExtensions/ext:UBLExtension/ext:ExtensionContent/sac:AdditionalInformation/sac:AdditionalMonetaryTotal", document, XPathConstants.NODESET);
            if (totalesVenta.getLength() > 0) {
                for (int i = 0; i < totalesVenta.getLength(); i++) {
                    Node nodeItem = (Node) totalesVenta.item(i);
                    String identifier = xPath.evaluate("cbc:ID", nodeItem, XPathConstants.STRING).toString();
                    if ("1001".equals(identifier)) {
                        aValorVenta = new BigDecimal((String) xPath.evaluate("cbc:PayableAmount", nodeItem, XPathConstants.STRING));
                    } else if ("1002".equals(identifier)) { // valor de venta inafecta
                        aValorVentaNoGravado = new BigDecimal((String) xPath.evaluate("cbc:PayableAmount", nodeItem, XPathConstants.STRING));
                    } else if ("1003".equals(identifier)) {
                        aValorVentaExonerado = new BigDecimal((String) xPath.evaluate("cbc:PayableAmount", nodeItem, XPathConstants.STRING));
                    } else if ("1005".equals(identifier)) {
                        String s = (String) xPath.evaluate("cbc:PayableAmount", nodeItem, XPathConstants.STRING);
                        if (!"".equals(s)) {
                            subTotalVentas = new BigDecimal(formatTwoDecimal(s));
                        }
                        subTotalVentas = new BigDecimal((String) xPath.evaluate("cbc:PayableAmount", nodeItem, XPathConstants.STRING));
                    } else if ("2001".equals(identifier)) {
                        aImporteDePercepcion = new BigDecimal((String) xPath.evaluate("cbc:PayableAmount", nodeItem, XPathConstants.STRING));
                    } else if ("2005".equals(identifier)) {
                        aTotalDescuentos = new BigDecimal((String) xPath.evaluate("cbc:PayableAmount", nodeItem, XPathConstants.STRING));
                    }
                }
            }

            mapa.put("subTotalVentas", formatTwoDecimal(subTotalVentas.toString()));
            log.info("subTotalVentas:" + subTotalVentas);

            //descuentos
            String d = (String) xPath.evaluate(nm + "/cac:LegalMonetaryTotal/cbc:AllowanceTotalAmount", document, XPathConstants.STRING);
            BigDecimal descuentos = new BigDecimal(0.0);
            if (!"".equals(d)) {
                descuentos = new BigDecimal(formatTwoDecimal(d));
            }
            mapa.put("descuentos", formatTwoDecimal(descuentos.toString()));
            log.info("descuentos:" + descuentos);

            //total valor de venta
            String vv = (String) xPath.evaluate(nm + "/cac:LegalMonetaryTotal/cbc:LineExtensionAmount", document, XPathConstants.STRING);
            BigDecimal valorVenta = new BigDecimal(0.0);
            if (!"".equals(vv)) {
                valorVenta = new BigDecimal(formatTwoDecimal(vv));
            }
            mapa.put("valorVenta", formatTwoDecimal(valorVenta.toString()));
            log.info("valorVenta:" + valorVenta);

            //igv
            BigDecimal montoImpuestos = new BigDecimal(0.0);
            NodeList nodeOtrosTot = (NodeList) xPath.evaluate(nm + "/cac:TaxTotal/cac:TaxSubtotal", document, XPathConstants.NODESET);
            if (nodeOtrosTot.getLength() > 0) {
                String nombre = "";
                String monto = "";
                String porcentaje = "";
                Node nodeItem = null;
                for (int i = 0; i < nodeOtrosTot.getLength(); i++) {
                    nodeItem = (Node) nodeOtrosTot.item(i);

                    nombre = (String) xPath.evaluate("cac:TaxCategory/cac:TaxScheme/cbc:Name", nodeItem, XPathConstants.STRING);
                    monto = (String) xPath.evaluate("cbc:TaxAmount", nodeItem, XPathConstants.STRING);
                    porcentaje = (String) xPath.evaluate("cbc:Percent", nodeItem, XPathConstants.STRING);

//					if ("ISC".equals(nombre.trim().toUpperCase())) {
//						totalISC = new BigDecimal(monto);
//					}
                    if ("IGV".equals(nombre.trim().toUpperCase())) {
                        totalIGV = new BigDecimal(monto);
                        //igvPorcentaje = new BigDecimal(porcentaje);
                    }
//					if ("OTROS TRIBUTOS".equals(nombre.trim().toUpperCase())) {
//						totalOtrosTributos = new BigDecimal(monto);												
//					}		
                }
            }

            montoImpuestos = totalISC.add(totalIGV).add(totalOtrosTributos);
            mapa.put("igv", formatTwoDecimal(montoImpuestos.toString()));
            log.info("igv:" + montoImpuestos);

            //IMporte total
            String it = (String) xPath.evaluate(nm + "/cac:LegalMonetaryTotal/cbc:PayableAmount", document, XPathConstants.STRING);
            BigDecimal importeTotal = new BigDecimal(0.0);
            if (!"".equals(it)) {
                importeTotal = new BigDecimal(formatTwoDecimal(it));
            }
            mapa.put("importeTotal", formatTwoDecimal(importeTotal.toString()));
            log.info("importeTotal:" + importeTotal);

            log.info("Buscamos documentos relacionados");
            /**
             * ------ Obtenemos los documentos relacionados -----
             */
            NodeList nlGuias = (NodeList) xPath.evaluate(nm + "/cac:DespatchDocumentReference", document, XPathConstants.NODESET);
            NodeList nlOtrosDocs = (NodeList) xPath.evaluate(nm + "/cac:AdditionalDocumentReference", document, XPathConstants.NODESET);

            if (nlGuias.getLength() > 0 || nlOtrosDocs.getLength() > 0) {

                int lengthArray = nlGuias.getLength() + nlOtrosDocs.getLength();
                List<OtroDocumentoRelacionadoBean> aOtrosDocs = new ArrayList<OtroDocumentoRelacionadoBean>();
                OtroDocumentoRelacionadoBean docRel = null;

                String tipDocRelacionado = "";
                String numDocRelacionado = "";

                for (int j = 0, x = 0, y = 0; j < lengthArray; j++) {

                    Node nodeItem = (j < nlGuias.getLength() ? (Node) nlGuias.item(x++) : (Node) nlOtrosDocs.item(y++));

//					docRel = new OtroDocumentoRelacionadoBean();
//					docRel.setTipoDocumentoRelacionado((String)xPath.evaluate("cbc:cbc:DocumentTypeCode", nodeItem, XPathConstants.STRING));
//					docRel.setDesTipoDocuRela((String)xPath.evaluate("cbc:DocumentType", nodeItem, XPathConstants.STRING));
//					docRel.setNumeroDocumentoRelacionadoInicial((String)xPath.evaluate("cbc:ID", nodeItem, XPathConstants.STRING));
//					aOtrosDocs.add(docRel);
                    tipDocRelacionado = (String) xPath.evaluate("cbc:DocumentType", nodeItem, XPathConstants.STRING);
                    numDocRelacionado = (String) xPath.evaluate("cbc:ID", nodeItem, XPathConstants.STRING);
                    numDocRelacionado = tipDocRelacionado + ":" + numDocRelacionado;
                    mapa.put("DocRelacionado" + (j + 1), numDocRelacionado);

                }
                //comprobante.setOtroDocumentoRelacionadoBean(aOtrosDocs);
            }

            log.info("Buscamos los detalles");
            NodeList nlItems = (NodeList) xPath.evaluate(nm + tagCompDetalle, document, XPathConstants.NODESET);
            List<Map<String, String>> aDetalleComprobante = new ArrayList<Map<String, String>>();

            if (nlItems.getLength() > 0) {

                for (int i = 0; i < nlItems.getLength(); i++) {
                    Node nodeItem = (Node) nlItems.item(i);

                    if (i == 0) {
                        mapa.put("Observacion", (String) xPath.evaluate("cbc:Note", nodeItem, XPathConstants.STRING));
                    }

                    Map<String, String> detalle = new HashMap<String, String>();
                    detalle.put("cantidad", (String) xPath.evaluate(tagCompDetalleCantidad, nodeItem, XPathConstants.STRING));
                    detalle.put("unidadMedida", (String) xPath.evaluate(tagCompDetalleUnidad, nodeItem, XPathConstants.STRING));
                    detalle.put("codigo", (String) xPath.evaluate(tagCompDetalleCodigo, nodeItem, XPathConstants.STRING));
                    detalle.put("descripcion", (String) xPath.evaluate("cac:Item/cbc:Description", nodeItem, XPathConstants.STRING));

                    String vu = (String) xPath.evaluate("cac:Price/cbc:PriceAmount", nodeItem, XPathConstants.STRING);
                    if (!"".equals(vu)) {
                        vu = formatTwoDecimal(vu);
                    }
                    detalle.put("valorUnitario", vu);

                    log.info("Detalle:" + detalle.toString());

                    aDetalleComprobante.add(detalle);
                }

                log.info("aDetalleComprobante:" + aDetalleComprobante.toString());

            } else {

                Map<String, String> detalle = new HashMap<String, String>();
                detalle.put("cantidad", "");
                detalle.put("unidadMedida", "");
                detalle.put("codigo", "");
                detalle.put("descripcion", "");
                detalle.put("valorUnitario", "");
                aDetalleComprobante.add(detalle);
            }

            mapa.put("DetalleItems", aDetalleComprobante);

            mapa.put("montoEnLetras", "");
            NodeList nodeProperties = (NodeList) xPath.evaluate(nm + "/ext:UBLExtensions/ext:UBLExtension/ext:ExtensionContent/sac:AdditionalInformation/sac:AdditionalProperty", document, XPathConstants.NODESET);
            if (nodeProperties.getLength() > 0) {
                for (int i = 0; i < nodeProperties.getLength(); i++) {
                    String codNodo = (String) xPath.evaluate("cbc:ID", nodeProperties.item(i), XPathConstants.STRING);
                    if (codNodo != null) {
                        if (codNodo.equals("1000")) {
                            mapa.put("montoEnLetras", (String) xPath.evaluate("cbc:Value", nodeProperties.item(i), XPathConstants.STRING));
                        }
                    }
                }
            }

            log.info("datos de mapa:" + mapa.toString());

            bos.close();

        } catch (Exception e) {

            log.error("Error:" + e.toString());
        }
        return mapa;
    }

    private String obtenerValorNodo(Element doc, String nameNode) {

        NodeList nodos = doc.getChildNodes();
        Node nodo = null;
        String tmpNombreNodo = "";
        String valorNodo = "";

        for (int i = 0; i < nodos.getLength(); i++) {
            nodo = nodos.item(i);
            if (nameNode.equals(nodo.getNodeName().trim())) {
                Element el = (Element) nodo;
                valorNodo = el.getFirstChild().getNodeValue();
                break;
            }
        }

        if (log.isDebugEnabled()) {
            log.debug(">> " + nodo + " - " + tmpNombreNodo + " - " + valorNodo);
        }
        return valorNodo;

    }

    public XPath getxPath() {
        return xPath;
    }

    public void setxPath(XPath xPath) {
        this.xPath = xPath;
    }

    private String obtenerDescCatalogo06(String codigo) {
        String result = "";
        if ("06".equals(codigo) || "6".equals(codigo)) {
            result = "RUC";
        } else if ("01".equals(codigo) || "1".equals(codigo)) {
            result = "DNI";
        } else if ("04".equals(codigo) || "4".equals(codigo)) {
            result = "CARNET EXTRANJERIA";
        } else if ("07".equals(codigo) || "7".equals(codigo)) {
            result = "PASAPORTE";
        } else if ("00".equals(codigo) || "0".equals(codigo)) {
            result = "DOC.TRIB.NO.DOM.SIN.RUC";
        }
        return result;
    }

    public class BoletaNamespace implements NamespaceContext {

        public String getNamespaceURI(String prefix) {
            if (prefix.equals("qdt")) {
                return "urn:oasis:names:specification:ubl:schema:xsd:QualifiedDatatypes-2";
            } else if (prefix.equals("ccts")) {
                return "urn:oasis:names:specification:ubl:schema:xsd:CoreComponentParameters-2";
            } else if (prefix.equals("stat")) {
                return "urn:oasis:names:specification:ubl:schema:xsd:DocumentStatusCode-1.0";
            } else if (prefix.equals("cbc")) {
                return "urn:oasis:names:specification:ubl:schema:xsd:CommonBasicComponents-2";
            } else if (prefix.equals("cac")) {
                return "urn:oasis:names:specification:ubl:schema:xsd:CommonAggregateComponents-2";
            } else if (prefix.equals("udt")) {
                return "urn:un:unece:uncefact:data:draft:UnqualifiedDataTypesSchemaModule:2";
            } else if (prefix.equals("ext")) {
                return "urn:oasis:names:specification:ubl:schema:xsd:CommonExtensionComponents-2";
            } else if (prefix.equals("sac")) {
                return "urn:sunat:names:specification:ubl:peru:schema:xsd:SunatAggregateComponents-1";
            } else if (prefix.equals("ds")) {
                return "http://www.w3.org/2000/09/xmldsig#";
            } else {
                return "urn:oasis:names:specification:ubl:schema:xsd:Invoice-2";
            }
        }

        public String getPrefix(String p) {
            return null;
        }

        public Iterator<Object> getPrefixes(String p) {
            return null;
        }
    }

    public class NotaCreditoNamespace implements NamespaceContext {

        public String getNamespaceURI(String prefix) {
            if (prefix.equals("qdt")) {
                return "urn:oasis:names:specification:ubl:schema:xsd:QualifiedDatatypes-2";
            } else if (prefix.equals("ccts")) {
                return "urn:oasis:names:specification:ubl:schema:xsd:CoreComponentParameters-2";
            } else if (prefix.equals("stat")) {
                return "urn:oasis:names:specification:ubl:schema:xsd:DocumentStatusCode-1.0";
            } else if (prefix.equals("cbc")) {
                return "urn:oasis:names:specification:ubl:schema:xsd:CommonBasicComponents-2";
            } else if (prefix.equals("cac")) {
                return "urn:oasis:names:specification:ubl:schema:xsd:CommonAggregateComponents-2";
            } else if (prefix.equals("cac")) {
                return "urn:un:unece:uncefact:data:draft:UnqualifiedDataTypesSchemaModule:2";
            } else if (prefix.equals("ext")) {
                return "urn:oasis:names:specification:ubl:schema:xsd:CommonExtensionComponents-2";
            } else if (prefix.equals("sac")) {
                return "urn:sunat:names:specification:ubl:peru:schema:xsd:SunatAggregateComponents-1";
            } else if (prefix.equals("ds")) {
                return "http://www.w3.org/2000/09/xmldsig#";
            } else {
                return "urn:oasis:names:specification:ubl:schema:xsd:CreditNote-2";
            }
        }

        public String getPrefix(String p) {
            return null;
        }

        public Iterator<Object> getPrefixes(String p) {
            return null;
        }
    }

    public class NotaDebitoNamespace implements NamespaceContext {

        public String getNamespaceURI(String prefix) {
            if (prefix.equals("qdt")) {
                return "urn:oasis:names:specification:ubl:schema:xsd:QualifiedDatatypes-2";
            } else if (prefix.equals("ccts")) {
                return "urn:oasis:names:specification:ubl:schema:xsd:CoreComponentParameters-2";
            } else if (prefix.equals("stat")) {
                return "urn:oasis:names:specification:ubl:schema:xsd:DocumentStatusCode-1.0";
            } else if (prefix.equals("cbc")) {
                return "urn:oasis:names:specification:ubl:schema:xsd:CommonBasicComponents-2";
            } else if (prefix.equals("cac")) {
                return "urn:oasis:names:specification:ubl:schema:xsd:CommonAggregateComponents-2";
            } else if (prefix.equals("cac")) {
                return "urn:un:unece:uncefact:data:draft:UnqualifiedDataTypesSchemaModule:2";
            } else if (prefix.equals("ext")) {
                return "urn:oasis:names:specification:ubl:schema:xsd:CommonExtensionComponents-2";
            } else if (prefix.equals("sac")) {
                return "urn:sunat:names:specification:ubl:peru:schema:xsd:SunatAggregateComponents-1";
            } else if (prefix.equals("ds")) {
                return "http://www.w3.org/2000/09/xmldsig#";
            } else {
                return "urn:oasis:names:specification:ubl:schema:xsd:DebitNote-2";
            }
        }

        public String getPrefix(String p) {
            return null;
        }

        public Iterator<Object> getPrefixes(String p) {
            return null;
        }
    }

    public static String formatTwoDecimal(String decimal) throws ParseException {
        NumberFormat nf = new DecimalFormat("#,##0.##", new DecimalFormatSymbols(Locale.ENGLISH));
        NumberFormat nf2 = new DecimalFormat("#0.00", new DecimalFormatSymbols(Locale.ENGLISH));
        return nf2.format(nf.parse((String) decimal).doubleValue());
    }

    /**
     * Catalogo de Nro. 10 Tipo de nota de d�bito seg�n motivo.
     *
     * @param codigo
     * @return
     */
    private String obtenerDescCatalogo09(String codigo) {

//		if ("21".equals(tipoNota))	comprobante.setGlosa("Anulaci�n de la Operaci�n");
//		if ("22".equals(tipoNota))	comprobante.setGlosa("Anulaci�n por Error en el RUC");
//		if ("23".equals(tipoNota))	comprobante.setGlosa("Descuento Global");
//		if ("24".equals(tipoNota))	comprobante.setGlosa("Devoluci�n Total");
//		if ("25".equals(tipoNota))	comprobante.setGlosa("Correcci�n por Error en la Descripci�n");
//		if ("26".equals(tipoNota))	comprobante.setGlosa("Devoluci�n por Item");
//		if ("27".equals(tipoNota))	comprobante.setGlosa("Descuento por Item");	
        String result = "";
        if (codigo.equals("01")) {
            result = "ANULACI�N DE LA OPERACI�N";
        } else if (codigo.equals("02")) {
            result = "ANULACI�N POR ERROR EN EL RUC";
        } else if (codigo.equals("03")) {
            result = "CORRECCI�N POR ERROR EN LA DESCRIPCI�N";
        } else if (codigo.equals("04")) {
            result = "DESCUENTO GLOBAL";
        } else if (codigo.equals("05")) {
            result = "DESCUENTO POR �TEM";
        } else if (codigo.equals("06")) {
            result = "DEVOLUCI�N TOTAL";
        } else if (codigo.equals("07")) {
            result = "DEVOLUCI�N POR �TEM";
        } else if (codigo.equals("08")) {
            result = "BONIFICACI�N";
        } else if (codigo.equals("09")) {
            result = "DISMINUCI�N EN EL VALOR";
        }
        return result;
    }

    public void setT6573DAO(SqlMapRetencionDAO t6573dao) {
        t6573DAO = t6573dao;
    }

    public void setT6571DAO(SqlMapPercepcionDAO t6571dao) {
        t6571DAO = t6571dao;
    }

    //Ini PAS20175E210300094
    @Override
    public Map<String, Object> generarPDFTicketPOS(Map<String, String> datos) {

        Map<String, Object> result = new HashMap<String, Object>();
        result.put("exito", "0");

        try {

            result.put("plantilla", "ticketPosPdf");
            result.put("jasper", "/PLANTILLA000870.jrxml");

            String numSerie = datos.get("num_serie").trim().toUpperCase();
            String numRuc = datos.get("num_ruc").trim();
            //String codDocIdeCliente = (datos.get("cod_docide") == null) ? "" : datos.get("cod_docide").trim();
            //String numDocIdeCliente = (datos.get("num_docide") == null) ? "" : datos.get("num_docide").trim();
            //String fecEmision = datos.get("fec_emision").trim();
            //String mtoTotal = datos.get("cantidad").trim();
            String numTran = datos.get("num_comprob").trim();

            //1. La serie debe validarse q corresponda con el ruc del PSE-CF, t1331rucpac - num_doc, ind_proc=48 padron del PSE-CF
            T1331Bean t1331Bean = new T1331Bean();
            t1331Bean.setIndProceso(48);
            t1331Bean.setIndEstado("00");
            t1331Bean.setNumeroDoc(numSerie);

            List<T1331Bean> t1331BeanResult = t1331DAO.select(t1331Bean);

            if (t1331BeanResult.size() > 0) {

                //2. Se verifica el comprobante Ticket POS
                T6236Bean t6236Bean = new T6236Bean();
                t6236Bean.setInd_vigente("1");
                t6236Bean.setNum_ruc(t1331BeanResult.get(0).getNumeroDeRUC());

                T6235Bean t6235Bean = new T6235Bean();
                t6235Bean.setT6236Bean(t6236Bean);
                /*if(!codDocIdeCliente.equals("")) {
					t6235Bean.setCod_docide_cliente(codDocIdeCliente);
				}
				if(!numDocIdeCliente.equals("")) {
					t6235Bean.setNum_docide_cliente(numDocIdeCliente);
				}*/
                //t6235Bean.setFec_emision(new FechaBean(fecEmision));
                //t6235Bean.setMto_total(new BigDecimal(mtoTotal));
                t6235Bean.setNum_ruc(numRuc);
                t6235Bean.setNum_serie(numSerie);
                t6235Bean.setNum_tran(numTran);

                List<T6235Bean> t6235BeanResult = t6235DAO.findByFiltro(t6235Bean);

                if (t6235BeanResult.size() > 0) {
                    result.put("exito", "1");

                    // Obtener el tipo de tarjeta
                    String tipoTarjeta = "";
                    if (t6235BeanResult.get(0).getInd_tip_tarjeta().toUpperCase().equals("C")) {
                        tipoTarjeta = "CR�DITO";
                    } else if (t6235BeanResult.get(0).getInd_tip_tarjeta().toUpperCase().equals("D")) {
                        tipoTarjeta = "D�BITO";
                    } else if (t6235BeanResult.get(0).getInd_tip_tarjeta().toUpperCase().equals("E")) {
                        tipoTarjeta = "EFECTIVO";
                    }

                    // Obtener el tipo de documento del Cliente
                    String tipoDocUsu = "";
                    if (t6235BeanResult.get(0).getCod_docide_cliente().trim().equals("1")) {
                        tipoDocUsu = "DNI";
                    } else if (t6235BeanResult.get(0).getCod_docide_cliente().trim().equals("4")) {
                        tipoDocUsu = "C. EXT";
                    } else if (t6235BeanResult.get(0).getCod_docide_cliente().trim().equals("7")) {
                        tipoDocUsu = "PASAPORTE";
                    } else if (t6235BeanResult.get(0).getCod_docide_cliente().trim().equals("6")) {
                        tipoDocUsu = "RUC";
                    } else if (t6235BeanResult.get(0).getCod_docide_cliente().trim().equals("0")) {
                        tipoDocUsu = "OTRO";
                    }

                    // Obtener el nombre de la Entidad Financiera
                    String ef = t01DAO.findByArgumento("004", t6235BeanResult.get(0).getCod_ef());
                    String nombreBanco = ef.trim().equals("-") ? "" : ef.substring(0, 37);
                    log.debug("nombreBanco: " + nombreBanco);

                    // obtener el nombre del operador de tarjeta 
                    pe.gob.sunat.servicio2.registro.model.domain.DdpBean ddpOperador = ddpDAO.findByNroRUC(t6236Bean.getNum_ruc());
                    String nombreOperador = "";
                    if (ddpOperador != null) {
                        nombreOperador = ddpOperador.getDdp_nombre();
                    }
                    log.debug("nombreOperador: " + nombreOperador);

                    // obtener el nombre del Emisor 
                    pe.gob.sunat.servicio2.registro.model.domain.DdpBean ddpEmisor = ddpDAO.findByNroRUC(t6235BeanResult.get(0).getNum_ruc().trim());
                    String nombreEmisor = "";
                    if (ddpEmisor != null) {
                        nombreEmisor = ddpEmisor.getDdp_nombre();
                    }
                    log.debug("nombreEmisor: " + nombreEmisor);

                    // obtener la direccion del Emisor
                    Map mapDatos = this.obtenerDomicilioFiscal(t6235BeanResult.get(0).getNum_ruc().trim());

                    result.put("tipo_tarjeta", tipoTarjeta);
                    result.put("tipo_documento", tipoDocUsu);

                    //DateFormat fmt = new SimpleDateFormat("dd/MM/yyyy");
                    result.put("fecha_emision", t6235BeanResult.get(0).getFec_emision().getFormatDate("dd/MM/yyyy"));
                    //result.put("fecha_emision", "20/05/2017");
                    //t6235BeanResult.get(0).getFec_emision().getFormatDate("dd/MM/yyyy");

                    result.put("num_ruc", t6235BeanResult.get(0).getNum_ruc().trim());
                    result.put("dni_usuario", t6235BeanResult.get(0).getNum_docide_cliente().trim());
                    result.put("serie", t6235BeanResult.get(0).getNum_serie().trim());
                    result.put("transaccion", t6235BeanResult.get(0).getNum_tran().trim());
                    result.put("codigo_local", t6235BeanResult.get(0).getCod_local().trim());
                    result.put("entidad", t6235BeanResult.get(0).getCod_ef().trim());
                    result.put("hora_emision", t6235BeanResult.get(0).getHor_emision().trim().substring(0, 5));
                    result.put("moneda", t6235BeanResult.get(0).getCod_moneda().trim());
                    result.put("importe", t6235BeanResult.get(0).getMto_importe().toString().trim());
                    result.put("propina", t6235BeanResult.get(0).getMto_propina().toString().trim());
                    result.put("importe_total", t6235BeanResult.get(0).getMto_total().toString().trim());

                    result.put("razon_social", nombreEmisor);
                    result.put("nombre_operador", nombreOperador);
                    result.put("nombre_banco", nombreBanco);

                    //result.put("domicilio", contribuyenteService.obtenerDomicilioFiscal(numRuc).get("direccionCorta").toString()); // TODO
                    //result.put("domicilio", "POR AQUISITO NUMAS..."); // TODO
                    //result.put("domicilio", mapDatos.get("direccionCorta").toString());
                    result.put("domicilio", mapDatos.get("direccion").toString().replaceAll("<br />", "\n"));

                }

            }

        } catch (Exception e) {
            log.error(e);
        }

        return result;
    }

    //Ini PAS20181U210300013
    @Override
    public Map<String, Object> generarPDFTicketME(Map<String, String> datos) {

        Map<String, Object> result = new HashMap<String, Object>();
        result.put("exito", "0");

        try {

            result.put("plantilla", "ticketMePdf");
            result.put("jasper", "/Reporte_ticketme.jrxml");

            String numSerie = datos.get("num_serie").trim().toUpperCase();
            String numRuc = datos.get("num_ruc").trim();
            String numTran = datos.get("num_comprob").trim();

            //1. La serie debe validarse q corresponda con el ruc del PSE-ME, t1331rucpac - num_doc, ind_proc=50 padron del PSE-ME
            T1331Bean t1331Bean = new T1331Bean();
            t1331Bean.setIndProceso(50);
            t1331Bean.setIndEstado("00");
            t1331Bean.setNumeroDoc(numSerie);

            List<T1331Bean> t1331BeanResult = t1331DAO.selectTME(t1331Bean);

            if (t1331BeanResult.size() > 0) {

                //2. Se verifica el comprobante Ticket POS
                T8248Bean t8248Bean = new T8248Bean();
                t8248Bean.setInd_vigente("1");
                t8248Bean.setNum_ruc(t1331BeanResult.get(0).getNumeroDeRUC());

                T8249Bean t8249Bean = new T8249Bean();
                t8249Bean.setT8248Bean(t8248Bean);
                t8249Bean.setNum_ruc_emisor(numRuc);
                t8249Bean.setNum_serie_cp(numSerie);
                t8249Bean.setNum_cp(numTran);

                //t8249Bean.setTip_cp(tipComp);
                List<T8249Bean> t8249BeanResult = t8249DAO.findByFiltro(t8249Bean);

                if (t8249BeanResult.size() > 0) {
                    result.put("exito", "1");

                    // Obtener el tipo de tarjeta
                    /*String tipoTarjeta ="";
					if(t8249BeanResult.get(0).getInd_tip_tarjeta().toUpperCase().equals("C")){
						tipoTarjeta = "CR�DITO";
					}else if (t8249BeanResult.get(0).getInd_tip_tarjeta().toUpperCase().equals("D")){
						tipoTarjeta = "D�BITO";
					}else if (t8249BeanResult.get(0).getInd_tip_tarjeta().toUpperCase().equals("E")){
						tipoTarjeta = "EFECTIVO";
					}*/
                    // Obtener el tipo de documento del Cliente
                    String tipoDocUsu = "";
                    if (t8249BeanResult.get(0).getTip_doc_idecliente().trim().equals("1")) {
                        tipoDocUsu = "DNI";
                    } else if (t8249BeanResult.get(0).getTip_doc_idecliente().trim().equals("4")) {
                        tipoDocUsu = "C. EXT";
                    } else if (t8249BeanResult.get(0).getTip_doc_idecliente().trim().equals("7")) {
                        tipoDocUsu = "PASAPORTE";
                    } else if (t8249BeanResult.get(0).getTip_doc_idecliente().trim().equals("6")) {
                        tipoDocUsu = "RUC";
                    } else if (t8249BeanResult.get(0).getTip_doc_idecliente().trim().equals("0")) {
                        tipoDocUsu = "OTRO";
                    }

                    String numCpModif = "";
                    if (t8249BeanResult.get(0).getNum_cp_modif() != null) {
                        numCpModif = t8249BeanResult.get(0).getNum_cp_modif();
                    }

                    String descripcion_tipo_comprobante = "";

                    if (t8249BeanResult.get(0).getTip_cp().equals("12")) {
                        descripcion_tipo_comprobante = "TICKET MONEDERO ELECTR�NICO";
                    } else {
                        descripcion_tipo_comprobante = "NOTA DE CR�DITO ME";
                    }

                    // Obtener el nombre de la Entidad Financiera
                    /*String ef = t01DAO.findByArgumento("004", t8249BeanResult.get(0).getCod_ef());
					String nombreBanco = ef.trim().equals("-") ? "" : ef.substring(0, 37);
					log.debug("nombreBanco: " +  nombreBanco);*/
                    // obtener el nombre del operador de tarjeta 
                    /*pe.gob.sunat.servicio2.registro.model.domain.DdpBean ddpOperador = ddpDAO.findByNroRUC(t6236Bean.getNum_ruc());
					String nombreOperador = "";
					if(ddpOperador != null) {
						nombreOperador = ddpOperador.getDdp_nombre();
					}
					log.debug("nombreOperador: " +  nombreOperador);*/
                    // obtener el nombre del Emisor 
                    //pe.gob.sunat.servicio2.registro.model.domain.DdpBean ddpEmisor = ddpDAO.findByNroRUC(t6235BeanResult.get(0).getNum_ruc().trim());
                    pe.gob.sunat.servicio2.registro.model.domain.DdpBean ddpEmisor = ddpDAO.findByNroRUC(t8249BeanResult.get(0).getNum_ruc_emisor().trim());
                    String nombreEmisor = "";
                    if (ddpEmisor != null) {
                        nombreEmisor = ddpEmisor.getDdp_nombre();
                    }
                    log.debug("nombreEmisor: " + nombreEmisor);

                    // obtener la direccion del Emisor
                    Map mapDatos = this.obtenerDomicilioFiscal(t8249BeanResult.get(0).getNum_ruc_emisor().trim());

                    //result.put("tipo_tarjeta", tipoTarjeta);
                    result.put("tipo_documento", tipoDocUsu);

                    //DateFormat fmt = new SimpleDateFormat("dd/MM/yyyy");
                    result.put("fecha_emision", t8249BeanResult.get(0).getFecha_emision());
                    //result.put("fecha_emision", "20/05/2017");
                    //t6235BeanResult.get(0).getFec_emision().getFormatDate("dd/MM/yyyy");

                    result.put("num_ruc", t8249BeanResult.get(0).getNum_ruc_emisor().trim());
                    result.put("dni_usuario", t8249BeanResult.get(0).getNum_doc_idecliente().trim());
                    result.put("serie", t8249BeanResult.get(0).getNum_serie_cp().trim());
                    result.put("transaccion", t8249BeanResult.get(0).getNum_cp().trim());
                    //result.put("codigo_local", t6235BeanResult.get(0).getCod_local().trim());
                    //result.put("entidad", t6235BeanResult.get(0).getCod_ef().trim());
                    result.put("hora_emision", t8249BeanResult.get(0).getHora_emision());
                    //result.put("moneda", t8249BeanResult.get(0).getCod_moneda().trim());
                    result.put("moneda", "PEN");
                    result.put("numCpModif", numCpModif);
                    //result.put("importe", t8249BeanResult.get(0).getMto_total().toString().trim());
                    //result.put("propina", t6235BeanResult.get(0).getMto_propina().toString().trim());
                    result.put("importe_total", t8249BeanResult.get(0).getMto_total().toString().trim());

                    result.put("razon_social", nombreEmisor);

                    result.put("descripcion_tipo_comprobante", descripcion_tipo_comprobante);
                    //result.put("nombre_operador", nombreOperador);
                    //result.put("nombre_banco", nombreBanco);

                    //result.put("domicilio", contribuyenteService.obtenerDomicilioFiscal(numRuc).get("direccionCorta").toString()); // TODO
                    //result.put("domicilio", "POR AQUISITO NUMAS..."); // TODO
                    //result.put("domicilio", mapDatos.get("direccionCorta").toString());
                    result.put("domicilio", mapDatos.get("direccion").toString().replaceAll("<br />", "\n"));

                }

            }

        } catch (Exception e) {
            log.error(e);
        }

        return result;
    }
    //Fin PAS20181U210300013

    @SuppressWarnings("unchecked")
    private Map obtenerDomicilioFiscal(String numRuc) {
        String direccion = "";
        String direccionCorta = "";
        Map domfiscal = ddpDAO.findByPKDirecc(numRuc);
        if (domfiscal != null) {
            domfiscal.put("indice", "0");
            domfiscal.put("spr_numruc", domfiscal.get("ddp_numruc").toString().trim().equals("") ? "-" : domfiscal.get("ddp_numruc"));
            domfiscal.put("spr_correl", "0");
            domfiscal.put("spr_nombre", "DOMICILIO FISCAL");//spr_tipest
            domfiscal.put("spr_ubigeo", domfiscal.get("ddp_ubigeo").toString().trim().equals("") ? "-" : domfiscal.get("ddp_ubigeo"));
            domfiscal.put("spr_tipzon", domfiscal.get("ddp_tipzon").toString().trim().equals("") ? "-" : domfiscal.get("ddp_tipzon"));
            domfiscal.put("spr_nomzon", domfiscal.get("ddp_nomzon").toString().trim().equals("") ? "-" : domfiscal.get("ddp_nomzon"));
            domfiscal.put("spr_tipvia", domfiscal.get("ddp_tipvia").toString().trim().equals("") ? "-" : domfiscal.get("ddp_tipvia"));
            domfiscal.put("spr_nomvia", domfiscal.get("ddp_nomvia").toString().trim().equals("") ? "-" : domfiscal.get("ddp_nomvia"));
            domfiscal.put("spr_numer1", domfiscal.get("ddp_numer1").toString().trim().equals("") ? "-" : domfiscal.get("ddp_numer1"));
            domfiscal.put("spr_inter1", domfiscal.get("ddp_inter1").toString().trim().equals("") ? "-" : domfiscal.get("ddp_inter1"));
            domfiscal.put("num_kilom", (domfiscal.get("num_kilom") != null ? (domfiscal.get("num_kilom").toString().trim().equals("") ? "-" : domfiscal.get("num_kilom")) : "-"));
            domfiscal.put("num_manza", (domfiscal.get("num_manza") != null ? (domfiscal.get("num_manza").toString().trim().equals("") ? "-" : domfiscal.get("num_manza")) : "-"));
            domfiscal.put("num_depar", (domfiscal.get("num_depar") != null ? (domfiscal.get("num_depar").toString().trim().equals("") ? "-" : domfiscal.get("num_depar")) : "-"));
            domfiscal.put("num_lote", (domfiscal.get("num_lote") != null ? (domfiscal.get("num_lote").toString().trim().equals("") ? "-" : domfiscal.get("num_lote")) : "-"));
            domfiscal.put("spr_refer1", domfiscal.get("ddp_refer1").toString().trim().equals("") ? "-" : domfiscal.get("ddp_refer1"));
            domfiscal.put("nom_dpto", "-");
            domfiscal.put("nom_prov", "-");
            domfiscal.put("nom_dist", "-");
            domfiscal.put("nom_tipovia", "-");
            domfiscal.put("nom_tipozona", "-");
            domfiscal.put("cod_ubigeo", domfiscal.get("spr_ubigeo"));
            domfiscal.put("cod_tipovia", domfiscal.get("spr_tipvia"));
            domfiscal.put("cod_tipozona", domfiscal.get("spr_tipzon"));
            domfiscal.put("direccion", "");

            HashMap<String, Object> nombresparam = this.asignaNombresDeParametros(domfiscal);

            domfiscal.put("nom_dpto", nombresparam.get("nom_dpto") != null ? nombresparam.get("nom_dpto").toString().trim() : "");
            domfiscal.put("nom_prov", nombresparam.get("nom_prov") != null ? nombresparam.get("nom_prov").toString().trim() : "");
            domfiscal.put("nom_dist", nombresparam.get("nom_dist") != null ? nombresparam.get("nom_dist").toString().trim() : "");
            domfiscal.put("nom_tipovia", nombresparam.get("nom_tipovia") != null ? nombresparam.get("nom_tipovia").toString().trim() : "");
            domfiscal.put("nom_tipozona", nombresparam.get("nom_tipozona") != null ? nombresparam.get("nom_tipozona").toString().trim() : "");

            if (!domfiscal.get("spr_nomvia").toString().trim().equals("-")) {
                direccion = direccion.concat(domfiscal.get("nom_tipovia").toString().concat(" ").concat(domfiscal.get("spr_nomvia").toString()).concat(" ").concat(domfiscal.get("spr_numer1").toString())).trim();
                direccionCorta = direccionCorta.concat(domfiscal.get("nom_tipovia").toString().concat(" ").concat(domfiscal.get("spr_nomvia").toString()).concat(" ").concat(domfiscal.get("spr_numer1").toString())).trim();
            }
            if (!domfiscal.get("spr_nomzon").toString().trim().equals("-")) {
                direccion = direccion.concat(" ".concat(domfiscal.get("nom_tipozona").toString()).concat(" ").concat(domfiscal.get("spr_nomzon").toString())).trim();
            }
            if (!domfiscal.get("num_manza").toString().trim().equals("-")) {
                direccion = direccion.concat(" MZA. ".concat(domfiscal.get("num_manza").toString()));
                direccionCorta = direccionCorta.concat(" MZA. ".concat(domfiscal.get("num_manza").toString()));
            }
            if (!domfiscal.get("num_lote").toString().trim().equals("-")) {
                direccion = direccion.concat(" LOTE. ".concat(domfiscal.get("num_lote").toString()));
                direccionCorta = direccionCorta.concat(" LOTE. ".concat(domfiscal.get("num_lote").toString()));
            }
            if (!domfiscal.get("num_depar").toString().trim().equals("-")) {
                direccion = direccion.concat(" DPTO. ".concat(domfiscal.get("num_depar").toString()));
                direccionCorta = direccionCorta.concat(" DPTO. ".concat(domfiscal.get("num_depar").toString()));
            }
            if (!domfiscal.get("spr_inter1").toString().trim().equals("-")) {
                direccion = direccion.concat(" INT. ".concat(domfiscal.get("spr_inter1").toString()));
                direccionCorta = direccionCorta.concat(" INT. ".concat(domfiscal.get("spr_inter1").toString()));
            }
            if (!domfiscal.get("num_kilom").toString().trim().equals("-")) {
                direccion = direccion.concat(" KM. ".concat(domfiscal.get("num_kilom").toString()));
                direccionCorta = direccionCorta.concat(" KM. ".concat(domfiscal.get("num_kilom").toString()));
            }

            direccion = direccion.concat(" <br /> ").concat(domfiscal.get("nom_dpto").toString()).concat("-").concat(domfiscal.get("nom_prov").toString()).concat("-").concat(domfiscal.get("nom_dist").toString()).replaceAll("'", " ").replaceAll("�", "N").replaceAll("�", "n");
            domfiscal.put("direccion", direccion);
            domfiscal.put("direccionCorta", direccionCorta);
        }
        return domfiscal;
    }

    private HashMap<String, Object> asignaNombresDeParametros(Map dom) {

        HashMap<String, Object> datos = new HashMap<String, Object>();

        String nom_dpto = t01DAO.findByArgumento("030", dom.get("cod_ubigeo").toString().substring(0, 2));
        datos.put("nom_dpto", nom_dpto.trim().equals("-") ? "" : nom_dpto.substring(0, 49));

        //String nom_prov = utilService.getParam(Utilidades.getParamBean("031",dom.get("cod_ubigeo").toString().substring(0,4),"0","49")).getDescripcionCorta();
        //datos.put("nom_prov", nom_prov.trim().equals("")?"":nom_prov);
        String nom_prov = t01DAO.findByArgumento("031", dom.get("cod_ubigeo").toString().substring(0, 4));
        datos.put("nom_prov", nom_prov.trim().equals("-") ? "" : nom_prov.substring(0, 49));

        //String nom_dist = utilService.getParam(Utilidades.getParamBean("001",dom.get("cod_ubigeo").toString(),"0","31")).getDescripcionCorta();
        //datos.put("nom_dist", nom_dist.trim().equals("")?"":nom_dist);
        String nom_dist = t01DAO.findByArgumento("001", dom.get("cod_ubigeo").toString());
        datos.put("nom_dist", nom_dist.trim().equals("-") ? "" : nom_dist.substring(0, 31));

        //String nom_tipovia = utilService.getParam(Utilidades.getParamBean("058",dom.get("cod_tipovia").toString(),"0","49")).getDescripcionCorta();
        //datos.put("nom_tipovia", nom_tipovia.trim().equals("")?"":nom_tipovia);
        String nom_tipovia = t01DAO.findByArgumento("058", dom.get("cod_tipovia").toString());
        datos.put("nom_tipovia", nom_tipovia.trim().equals("-") ? "" : nom_tipovia.substring(0, 49));

        //String nom_tipozona = utilService.getParam(Utilidades.getParamBean("059",dom.get("cod_tipozona").toString(),"0","49")).getDescripcionCorta();
        //datos.put("nom_tipozona", nom_tipozona.trim().equals("")?"":nom_tipozona);
        String nom_tipozona = t01DAO.findByArgumento("059", dom.get("cod_tipozona").toString());
        datos.put("nom_tipozona", nom_tipozona.trim().equals("-") ? "" : nom_tipozona.substring(0, 49));

        return datos;
    }

    //Fin PAS20175E210300094
    
    private String obtenerComprobanteElectronico(T4241Bean inT4241bean, String codigo) { //PAS20231U210600160 csantillan ----- codigo: "F" Facturas  "B" Boletas
    	String	output="";
	try {
		
		String numRuc = inT4241bean.getNum_ruc();
		String tipoCpe = inT4241bean.getCod_cpe();
		String numSerie = inT4241bean.getNum_serie_cpe();
		Integer numCpe = inT4241bean.getNum_cpe();
		String fecEmision = inT4241bean.getFec_emision().getFormatDate("yyyy/MM/dd");
		BigDecimal	montoTotal = inT4241bean.getMto_importe_total();
		Double montoTotalDouble = montoTotal!=null?montoTotal.doubleValue():0;
		log.info("numRuc: " + numRuc);
		log.info("fecEmision: " + fecEmision);
		log.info("montoTotal: " + montoTotal);
			log.info("ingresando al metodo");

			String rutaApiCPE = "http://sunatcpe-cloud-aks.sunat.peru/v1/contribuyente/servicio/consulta/e/comprobantepago?numRUC="+numRuc+"&codTipoComprobante="+tipoCpe+"&serComprobante="+numSerie+"&numComprobante="+numCpe;
			//String rutaApiCPE = "https://192.168.44.174/v1/contribuyente/servicio/consulta/e/comprobantepago?numRUC="+numRuc+"&codTipoComprobante="+tipoCpe+"&serComprobante="+numSerie+"&numComprobante="+numCpe;
		
			URL url = new URL(rutaApiCPE);
			log.info("url: " + url);

			URLConnection conn = (URLConnection) url.openConnection();
			log.info("conn: " + conn); 

			Reader r = new InputStreamReader(conn.getInputStream());
 

			BufferedReader br = new BufferedReader(r);
			
			
			String linea = "";
			while((linea = br.readLine())!=null)
			{
				output = linea;
				log.info("output: " + output);
				
			} 
			
			Map<String, Object> cpe = new ObjectMapper().readValue(output, HashMap.class); 
			if(cpe.get("numRUC")!=null)
					{			
							log.info("listaCpe: " + cpe);

							String numRucRest = cpe.get("numRUC")!=null?cpe.get("numRUC").toString():null;
							log.info("numRucRest: " + numRucRest);
							String fecEmisionRest =cpe.get("fecEmision").toString().substring(0, 10).replace("-", "/");
							log.info("fecEmisionRest: " + fecEmisionRest);
																	
								if(fecEmision.equals(fecEmisionRest)){
									log.info(fecEmisionRest + " y " + fecEmision + " son iguales");
									
								}else{
									log.info(fecEmisionRest + " y " + fecEmision + " son diferentes");
									output = "";
								}
							Double	montoTotalRest =(Double) cpe.get("impTotalComprobante");
							log.info("montoTotalRest: " + montoTotalRest);
							if(codigo.equals("F") && Math.abs(montoTotalRest-montoTotalDouble)>0.001){
								log.info(montoTotalRest + " y " + montoTotalDouble + " son diferentes");
								output = "";
							}else{
								log.info(montoTotalRest + " y " + montoTotalDouble + " son iguales");
							}
							}
	

		  } catch (MalformedURLException e) {

			 // this.utilLog.imprimirLog(ConstantesUtils.LEVEL_ERROR, "ERROR! obtenerNombrePorPadronReduccion = " + e.getMessage(), Thread.currentThread().getStackTrace());
			  e.printStackTrace();
			  
			  log.error("mensaje error: " + e.getMessage()+ " MalformedURLException: " + e);

		  } catch (IOException e) {

 

			  //this.utilLog.imprimirLog(ConstantesUtils.LEVEL_ERROR, "ERROR! obtenerNombrePorPadronReduccion = " + e.getMessage(), Thread.currentThread().getStackTrace());
			  e.printStackTrace();
			  log.error("mensaje error: " + e.getMessage()+ " IOException: " + e);

		  } 
	log.info("output2 " + output);
	return output;
	}
    
    
}
