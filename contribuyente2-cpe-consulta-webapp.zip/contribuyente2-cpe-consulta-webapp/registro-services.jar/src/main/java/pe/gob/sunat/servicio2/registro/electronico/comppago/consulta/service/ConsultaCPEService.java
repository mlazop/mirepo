package pe.gob.sunat.servicio2.registro.electronico.comppago.consulta.service;



import java.io.IOException;
import java.util.List;
import java.util.Map;

import javax.naming.NamingException;
import javax.transaction.HeuristicMixedException;
import javax.transaction.HeuristicRollbackException;
import javax.transaction.NotSupportedException;
import javax.transaction.RollbackException;
import javax.transaction.SystemException;

import pe.gob.sunat.servicio2.registro.electronico.comppago.factura.consultar.bean.ConsultarFacturaBean;
import pe.gob.sunat.servicio2.registro.model.domain.DdpBean;

/**
 * <p>Description: Servicio de consulta para comprobantes electronicos</p>
 * @author jchuquitaype
 */
public interface ConsultaCPEService {
	
	public void validarFiltro(Map<String, String> map);
	public DdpBean verificarRUC(String nroRUC);
//	 public List <ConsultarFacturaBean> ejecutarConsulta(String nroRUC, String periodo, String tipoConsulta) throws Exception;
	public List <ConsultarFacturaBean> ejecutarConsulta(Map<String,String> params) throws Exception;
	public pe.gob.sunat.servicio2.registro.electronico.comppago.factura.bean.ArchivoComprobanteBean descargarFactura(Map <String, String> params) throws IOException;
	public pe.gob.sunat.servicio2.registro.electronico.comppago.boleta.bean.ArchivoComprobanteBean descargarBoleta(Map <String, String> params) throws IOException;
	/**
	 * <ul>
	 * <li> tipo 	: 11= factura Emitida, 12=Factura rechazada , 13=NC Emitida , 14 =NC Recibida , 15 = ND Emitida , 16 = ND recibida. 
	 * <li> ruc		:
	 * <li> serie	:
	 * <li> numero	:   
	 * </ul>
	 * @param params
	 * @return
	 */
	public pe.gob.sunat.servicio2.registro.electronico.comppago.factura.bean.ComprobanteBean recuperarInfoFactura(Map <String, String> params)  throws IOException;
	public pe.gob.sunat.servicio2.registro.electronico.comppago.boleta.bean.ComprobanteBean recuperarInfoBoleta(Map <String, String> params)  throws IOException;
	public boolean verificaAfiliacionFactGEM(String nroRUC);
	public boolean verificarAcceso(String num_docum, String cod_acceso, String cod_detalle) throws NamingException, SystemException, NotSupportedException, SecurityException, IllegalStateException, RollbackException, HeuristicMixedException, HeuristicRollbackException;
}
