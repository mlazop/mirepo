package pe.gob.sunat.servicio2.registro.electronico.comppago.boleta.service;

import java.io.File;
import java.io.IOException;

import pe.gob.sunat.servicio2.registro.electronico.comppago.boleta.bean.ArchivoComprobanteBean;
import pe.gob.sunat.servicio2.registro.electronico.comppago.boleta.bean.ComprobanteBean;


public interface ProcesaArchivoComprobanteService {
	public ArchivoComprobanteBean generaComprobanteArchivo(ComprobanteBean comprobante);
	
	public ComprobanteBean generaComprobanteBean(ArchivoComprobanteBean archivoComprobante);
	
	public ComprobanteBean generaComprobanteBean(File fileXml, boolean validate, boolean sign);
	
	public File generarArchivoZip(ArchivoComprobanteBean archivoComprobante);
	public File generarArchivoXML(ArchivoComprobanteBean archivoComprobante) throws IOException;
	public String getContenidoArchivoTxt(File file);
	public byte[] getContenidoArchivoBin(File file);

}
