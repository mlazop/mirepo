package pe.gob.sunat.servicio2.registro.electronico.comppago.generatecdr;

import java.util.Date;

import org.apache.commons.codec.binary.Base64;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import pe.gob.sunat.framework.spring.util.date.FechaBean;
import pe.gob.sunat.servicio2.registro.electronico.comppago.factura.model.dao.GRELogCabSelectDAO;
import pe.gob.sunat.servicio2.registro.electronico.comppago.factura.model.dao.LogCabSelectDAO;
import pe.gob.sunat.servicio2.registro.electronico.comppago.factura.model.dao.LogPerPackDAO;
import pe.gob.sunat.servicio2.registro.electronico.comppago.factura.model.dao.T4533DAO;
import pe.gob.sunat.servicio2.registro.electronico.comppago.factura.model.dao.T4534DAO;
import pe.gob.sunat.servicio2.registro.electronico.comppago.factura.model.dao.T4536DAO;
import pe.gob.sunat.servicio2.registro.electronico.comppago.factura.model.dao.T4537DAO;
import pe.gob.sunat.servicio2.registro.electronico.comppago.factura.model.dao.T6460CabGreDAO;
import pe.gob.sunat.servicio2.registro.electronico.comppago.factura.model.dao.T6464ArcGreDAO;
import pe.gob.sunat.servicio2.registro.electronico.comppago.factura.model.dao.T6464ArcGreInsertDAO;
import pe.gob.sunat.servicio2.registro.electronico.comppago.factura.model.dao.T6468DatGreBajaDAO;
import pe.gob.sunat.servicio2.registro.electronico.comppago.factura.model.dao.T6571PercepcionSelectDAO;
import pe.gob.sunat.servicio2.registro.electronico.comppago.factura.model.dao.T6573RetencionSelectDAO;
import pe.gob.sunat.servicio2.registro.electronico.comppago.factura.model.dao.T6575ArchPerDAO;
import pe.gob.sunat.servicio2.registro.electronico.comppago.factura.model.dao.T6575ArchPerInsertDAO;
import pe.gob.sunat.servicio2.registro.electronico.comppago.factura.model.dao.T6576ArchRetDAO;
import pe.gob.sunat.servicio2.registro.electronico.comppago.factura.model.dao.T6576ArchRetInsertDAO;
import pe.gob.sunat.servicio2.registro.electronico.comppago.factura.model.dao.T6593DAO;
import pe.gob.sunat.servicio2.registro.electronico.comppago.factura.model.domain.BillLogCab;
import pe.gob.sunat.servicio2.registro.electronico.comppago.factura.model.domain.BillLogPack;
import pe.gob.sunat.servicio2.registro.electronico.comppago.factura.model.domain.T4533Bean;
import pe.gob.sunat.servicio2.registro.electronico.comppago.factura.model.domain.T4534Bean;
import pe.gob.sunat.servicio2.registro.electronico.comppago.factura.model.domain.T4536Bean;
import pe.gob.sunat.servicio2.registro.electronico.comppago.factura.model.domain.T4537Bean;
import pe.gob.sunat.servicio2.registro.electronico.comppago.factura.model.domain.T6460CabGreBean;
import pe.gob.sunat.servicio2.registro.electronico.comppago.factura.model.domain.T6464ArcGreBean;
import pe.gob.sunat.servicio2.registro.electronico.comppago.factura.model.domain.T6571PercepcionBean;
import pe.gob.sunat.servicio2.registro.electronico.comppago.factura.model.domain.T6573RetencionBean;
import pe.gob.sunat.servicio2.registro.electronico.comppago.factura.model.domain.T6575ArchPerBean;
import pe.gob.sunat.servicio2.registro.electronico.comppago.factura.model.domain.T6576ArchRetBean;

public class ChangeStatusServiceImpl implements ChangeStatus {

	protected final Log log = LogFactory.getLog(getClass());
	
	private final static String OUTPUT_MODE = "0";
	
	final private String COD_CPE_PERCEPCION = "40";
	final private String COD_CPE_RETENCION = "20";
	final private String COD_CPE_GUIAREMISION = "09";
	
	private T4533DAO fELogPackUpdateDAO;

	private T4534DAO t4534SelectDAO;

	private T4536DAO fEStoreDeleteDAO;
	private T4536DAO fEStoreGreDAO;

	private T4537DAO fELogCabUpdateDAO;
	
	private T6460CabGreDAO t6460Dao;
	private T6571PercepcionSelectDAO t6571Dao;
	private T6573RetencionSelectDAO t6573Dao;
	
	private T6468DatGreBajaDAO t6468Dao;
	private GRELogCabSelectDAO t6594Dao;
	private T6593DAO t6593Dao;
	
	private LogCabSelectDAO t6578Dao;
	private LogPerPackDAO t6577Dao;
	
	private T6464ArcGreInsertDAO insertT6464Dao;
	

	public void setfEStoreGreDAO(T4536DAO fEStoreGreDAO) {
		this.fEStoreGreDAO = fEStoreGreDAO;
	}

	public void setInsertT6464Dao(T6464ArcGreInsertDAO insertT6464Dao) {
		this.insertT6464Dao = insertT6464Dao;
	}

	public void setT6460Dao(T6460CabGreDAO t6460Dao) {
		this.t6460Dao = t6460Dao;
	}

	public void setT6571Dao(T6571PercepcionSelectDAO t6571Dao) {
		this.t6571Dao = t6571Dao;
	}

	public void setT6573Dao(T6573RetencionSelectDAO t6573Dao) {
		this.t6573Dao = t6573Dao;
	}

	public void setT6468Dao(T6468DatGreBajaDAO t6468Dao) {
		this.t6468Dao = t6468Dao;
	}

	public void setT6594Dao(GRELogCabSelectDAO t6594Dao) {
		this.t6594Dao = t6594Dao;
	}
	
	public void setT6593Dao(T6593DAO t6593Dao) {
		this.t6593Dao = t6593Dao;
	}

	public void setT6578Dao(LogCabSelectDAO t6578Dao) {
		this.t6578Dao = t6578Dao;
	}

	public void setT6577Dao(LogPerPackDAO t6577Dao) {
		this.t6577Dao = t6577Dao;
	}

	public void setT4534SelectDAO(T4534DAO t4534SelectDAO) {
		this.t4534SelectDAO = t4534SelectDAO;
	}

	public void setfEStoreDeleteDAO(T4536DAO fEStoreDeleteDAO) {
		this.fEStoreDeleteDAO = fEStoreDeleteDAO;
	}

	public void setfELogCabUpdateDAO(T4537DAO fELogCabUpdateDAO) {
		this.fELogCabUpdateDAO = fELogCabUpdateDAO;
	}

	public void setfELogPackUpdateDAO(T4533DAO fELogPackUpdateDAO) {
		this.fELogPackUpdateDAO = fELogPackUpdateDAO;
	}

	

	@Override
	public void changeStatus(String numTicket, Integer correlativo) {
		fEStoreDeleteDAO.deleteByTiketAndModo(numTicket, correlativo, "0");
		fELogCabUpdateDAO.updateToPendingByTiket(numTicket, correlativo);
		fELogPackUpdateDAO.updateToPendingByTiket(numTicket);
		// fELogDetUpdateDAO.deleteAllByTiket(numTicket, correlativo);
	}

	
	@Override
	public TicketCorrelativo changeStatus(String numRuc, String codCPE, String numSerieCPE, Integer numCPE) {
		
		log.debug("ChangeStatusServiceImpl.changeStatus - Inic");
		
		TicketCorrelativo tiCorrelativo = null;
		
		log.debug("ChangeStatusServiceImpl.changeStatus - DVDR 001");
		if (codCPE.equals(this.COD_CPE_GUIAREMISION)) {
			log.debug("ChangeStatusServiceImpl.changeStatus - DVDR 002");
			//GUIA
			T6460CabGreBean t6460 = t6460Dao.buscarPorPk(numRuc, codCPE, numSerieCPE, numCPE);
			//cambiar estado
			t6468Dao.delete(numRuc, codCPE, numSerieCPE, numCPE);
			t6594Dao.update(t6460.getNumTicket().toString(), 1);
			t6593Dao.actualizaEstado(t6460.getNumTicket().toString());
			tiCorrelativo = new TicketCorrelativo(t6460.getNumTicket().toString(), 1);
			
		}
		else if (codCPE.equals(this.COD_CPE_PERCEPCION)) {
			log.debug("ChangeStatusServiceImpl.changeStatus - DVDR 010");
			//PERCEPCION
			T6571PercepcionBean t6571 = t6571Dao.buscarPorPk(numRuc, codCPE, numSerieCPE, numCPE);
			
			//cambiar estado
			t6578Dao.update(t6571.getNumTicket().toString());
			Long auxTicket = t6571.getNumTicket() - 1;
			t6577Dao.actualizaEstado(auxTicket.toString());
			tiCorrelativo = new TicketCorrelativo(auxTicket.toString(), 1);
			
		}
		else if (codCPE.equals(this.COD_CPE_RETENCION)) {
			log.debug("ChangeStatusServiceImpl.changeStatus - DVDR 020");
			//RETENCION
			T6573RetencionBean t6573 = t6573Dao.buscarPorPk(numRuc, codCPE, numSerieCPE, numCPE);
			//cambiar estado
			t6578Dao.update(t6573.getNumTicket().toString());
			Long auxTicket = t6573.getNumTicket() - 1;
			t6577Dao.actualizaEstado(auxTicket.toString());
			tiCorrelativo = new TicketCorrelativo(auxTicket.toString(), 1);
			
		}
		else {
			log.debug("ChangeStatusServiceImpl.changeStatus - DVDR 030");
			T4534Bean relcompelec = t4534SelectDAO.findByPK(numRuc, numSerieCPE, codCPE, numCPE);
			if (relcompelec == null) {
				throw new RuntimeException(
						"No se encontro el comprobante buscado( numero de ruc: "
								+ numRuc + " tipo comprobante: " + codCPE
								+ " numero de serie: " + numSerieCPE
								+ " numero de comprobante: " + numCPE);
			}
	
			this.changeStatus(relcompelec.getNum_ticket(), relcompelec.getNum_correl_ticket());
			tiCorrelativo = new TicketCorrelativo(relcompelec.getNum_ticket(), relcompelec.getNum_correl_ticket());
			
		}
		
		log.debug("ChangeStatusServiceImpl.changeStatus - Fin");
		
		return tiCorrelativo;
		
	}

	@Override
	public void changeStatus(ConstanciaEnvio constancia) {
		ApplicationResponse response = constancia.getApplicationResponse();

		String numticket = response.getTicket();
		
		Integer status = response.getCodeError() == 0 ? 0 : 99;

		Base64 base64 = new Base64();
		byte[] zippedCdr = base64.decode(constancia.getZippedBase64Cdr()
				.getBytes());

		saveOutput(numticket.toString(), constancia.getCorrelativo(),
				zippedCdr, constancia.getUsuarioEnvio());

		endFile(numticket.toString(),
				constancia.getCorrelativo(), response.getCodeError(), constancia.getUsuarioEnvio());
		
		endPack(numticket, status, constancia.getUsuarioEnvio());

	}
	
	@Override
	public void changeStatusPercepcion(ConstanciaEnvio constancia) {
		ApplicationResponse response = constancia.getApplicationResponse();

		String numticket = response.getTicket();
		
		Integer status = response.getCodeError() == 0 ? 0 : 99;
		
		log.debug("ChangeStatusServiceImpl.changeStatusPercepcion : numticket = " + numticket);
		log.debug("ChangeStatusServiceImpl.changeStatusPercepcion : response.getCodeError() = " + response.getCodeError());
		log.debug("ChangeStatusServiceImpl.changeStatusPercepcion : status = " + status);
		
		Base64 base64 = new Base64();
		byte[] zippedCdr = base64.decode(constancia.getZippedBase64Cdr()
				.getBytes());

		saveInOutPercepion(numticket, constancia.getCorrelativo(), zippedCdr, OUTPUT_MODE, constancia.getUsuarioEnvio(), constancia.getArchivoNombre());
		endFilePer(numticket, response.getCodeError(), constancia.getUsuarioEnvio());
		endPackPer(numticket, status, constancia.getUsuarioEnvio());

	}
	
	@Override
	public void changeStatusRetencion(ConstanciaEnvio constancia) {
		ApplicationResponse response = constancia.getApplicationResponse();

		String numticket = response.getTicket();
		
		Integer status = response.getCodeError() == 0 ? 0 : 99;
		
		Base64 base64 = new Base64();
		byte[] zippedCdr = base64.decode(constancia.getZippedBase64Cdr()
				.getBytes());
		
		log.debug("ChangeStatusServiceImpl.changeStatusRetencion : numticket = " + numticket);
		log.debug("ChangeStatusServiceImpl.changeStatusRetencion : response.getCodeError() = " + response.getCodeError());
		log.debug("ChangeStatusServiceImpl.changeStatusRetencion : status = " + status);

		saveInOutRetencion(numticket, constancia.getCorrelativo(), zippedCdr, OUTPUT_MODE, constancia.getUsuarioEnvio(), constancia.getArchivoNombre());
		endFilePer(numticket, response.getCodeError(), constancia.getUsuarioEnvio());
		
		endPackPer(numticket, status, constancia.getUsuarioEnvio());

	}
	
	@Override
	public void changeStatusGRE(ConstanciaEnvio constancia) {
		ApplicationResponse response = constancia.getApplicationResponse();

		String numticket = response.getTicket();
		
		Integer status = response.getCodeError() == 0 ? 0 : 99;

		Base64 base64 = new Base64();
		byte[] zippedCdr = base64.decode(constancia.getZippedBase64Cdr()
				.getBytes());

		saveInOutGuia(numticket, constancia.getCorrelativo(), zippedCdr, OUTPUT_MODE, constancia.getUsuarioEnvio(), constancia.getArchivoNombre());
		
		endFileGRE(numticket, constancia.getCorrelativo(), response.getCodeError(), constancia.getUsuarioEnvio());
		
		endPackGRE(numticket, status, constancia.getUsuarioEnvio());

	}

	private void saveOutput(String ticket, Integer correlativo, byte[] content,
			String username) {

		saveInOut(ticket, correlativo, content, OUTPUT_MODE, username);
		// return res;
	}

	private void saveInOut(String ticket, Integer correlativo, byte[] content,
			String modo, String username) {

		T4536Bean billStore = new T4536Bean();

		billStore.setTicket(ticket);

		billStore.setCorrelativo(correlativo);

		billStore.setModo(modo);

		billStore.setContenido(content);

		billStore.setUsuarioModificador(username);

		billStore.setFechaModificacion(new FechaBean());

		// daoStore.inserta(billStore);
		fEStoreDeleteDAO.inserta(billStore);
	}
	
	private void saveInOutPercepion(String ticket, Integer correlativo, byte[] content,
			String modo, String username, String nomArchivo) {

		T6575ArchPerBean billStore = new T6575ArchPerBean();

		billStore.setNumTicket(new Long(ticket));
		billStore.setIndModo(modo);
		billStore.setArcArchivo(content);
		billStore.setCodUsumodif(username);
		billStore.setFecModif(new Date());
		billStore.setCodUsuregis(username);
		billStore.setFecRegis(new Date());
		billStore.setNomArchivo(nomArchivo);
		log.debug("ChangeStatusServiceImpl.saveInOutPercepion " + ticket);
		fEStoreDeleteDAO.inserta(billStore);
	}
	
	private void saveInOutRetencion(String ticket, Integer correlativo, byte[] content,
			String modo, String username, String nomArchivo) {

		T6576ArchRetBean billStore = new T6576ArchRetBean();

		billStore.setNumTicket(new Long(ticket));
		billStore.setIndModo(modo);
		billStore.setArcArchivo(content);
		billStore.setCodUsumodif(username);
		billStore.setFecModif(new Date());
		billStore.setCodUsuRegis(username);
		billStore.setFecRegis(new Date());
		billStore.setNomArchivo(nomArchivo);
		log.debug("ChangeStatusServiceImpl.saveInOutRetencion " + ticket);
		fEStoreDeleteDAO.inserta(billStore);
	}
	
	private void saveInOutGuia(String ticket, Integer correlativo, byte[] content,
			String modo, String username, String nomArchivo) {

		T6464ArcGreBean billStore = new T6464ArcGreBean();

		billStore.setNumTicket(new Long(ticket));
		billStore.setIndModo(modo);
		billStore.setArcInput(content);
		billStore.setCodUsumodif(username);
		billStore.setFecModif(new Date());
		billStore.setDesArchivo(nomArchivo);
		log.debug("ChangeStatusServiceImpl.saveInOutGuia " + ticket);
		fEStoreGreDAO.inserta(billStore);
	}

	private void endFile(String ticket, Integer correlativo, Integer resultCode, String username) {

		T4537Bean cab = new T4537Bean();
		cab.setTicket(ticket);
		
		if (resultCode == 0)
			cab.setEstadoProceso(0);
		else
			cab.setEstadoProceso(99);

		cab.setCorrelativo(correlativo);
		cab.setCodigoResultado(resultCode);
		cab.setUsuarioModificador(username);
		cab.setFechaFin(new FechaBean());
		cab.setFechaModificacion(new FechaBean());

		fELogCabUpdateDAO.actualizaEstado(cab);
	}
	
	private void endFilePer(String ticket, Integer resultCode, String username) {

		BillLogCab cab = new BillLogCab();
		Long auxTicket = new Long(ticket)+1;
		cab.setTicket(auxTicket);
		
		if (resultCode == 0)
			cab.setEstadoProceso(0);
		else
			cab.setEstadoProceso(99);
		
		log.debug("ChangeStatusServiceImpl.endFilePer : resultCode = " + resultCode);

		cab.setCodigoResultado(resultCode);
		cab.setUsuarioModificador(username);
		cab.setFechaFin(new Date());
		cab.setFechaModificacion(new Date());

		t6578Dao.update(cab);
	}
	
	private void endFileGRE(String ticket, Integer correlativo, Integer resultCode, String username) {

		BillLogCab cab = new BillLogCab();
		cab.setTicket(new Long(ticket));
		
		if (resultCode == 0)
			cab.setEstadoProceso(0);
		else
			cab.setEstadoProceso(99);

		cab.setCodigoResultado(resultCode);
		cab.setUsuarioModificador(username);
		cab.setFechaFin(new Date());
		cab.setFechaModificacion(new Date());
		cab.setCorrelativo(correlativo);

		t6594Dao.update(cab);
	}

	public void endPack(String ticket, Integer status, String username) {

		T4533Bean pack = new T4533Bean();

		pack.setTicket(ticket);
		pack.setEstadoProceso(status);
		pack.setUsuarioModificador(username);
		pack.setFechaFin(new FechaBean());
		pack.setFechaModificacion(new FechaBean());
		fELogPackUpdateDAO.actualizaEstado(pack);
	}
	
	private void endPackPer(String ticket, Integer status, String username) {

		BillLogPack pack = new BillLogPack();

		pack.setTicket(new Long(ticket));
		pack.setEstadoProceso(status);
		pack.setUsuarioModificador(username);
		pack.setFechaFin(new Date());
		pack.setFechaModificacion(new Date());
		t6577Dao.actualizaEstado(pack);
	}
	
	private void endPackGRE(String ticket, Integer status, String username) {

		BillLogPack pack = new BillLogPack();

		pack.setTicket(new Long(ticket));
		pack.setEstadoProceso(status);
		pack.setUsuarioModificador(username);
		pack.setFechaFin(new Date());
		pack.setFechaModificacion(new Date());
		t6593Dao.actualizaEstado(pack);
	}

}
