package pe.gob.sunat.servicio2.registro.electronico.comppago.generatecdr;


public interface RebuilCdrService {

	public ConstanciaEnvio rebuildCDRbyNumTicket(String numticket, Integer correlativo);
	
	public ConstanciaEnvio rebuildCDRbyBill(String numruc, String tipoCPE, String numSerieCPE, Integer numCPE);
	
	public ConstanciaEnvio buildInProgessStateByNumticket(String numTicket, Integer correlativo);
}
