package pe.gob.sunat.servicio2.registro.electronico.comppago.consulta.service;

import java.io.IOException;
import java.util.Map;

import pe.gob.sunat.servicio2.registro.electronico.comppago.boleta.bean.ArchivoComprobanteBean;



/**
 * <p>Description: Servicio de consulta para comprobantes electronicos</p>
 * @author jchuquitaype
 */
@SuppressWarnings({"rawtypes"})
public interface ValidaCoprobanteElectronicoService {
	
	public Map consultaValidezRHE_NCE(Map<String,String>datos) ;	
	
	public ArchivoComprobanteBean descargarBoleta(Map<String, String> params) throws IOException;

	Map<String, Object> generarPDF(byte[] archivoXml,String tipo);	
	
	//Ini PAS20175E210300094
	public Map<String, Object> generarPDFTicketPOS(Map<String,String> datos);
	//Fin PAS20175E210300094
		
	//Ini PAS20181U210300013
	public Map<String, Object> generarPDFTicketME(Map<String,String> datos);
	//Fin PAS20181U210300013
	
}
