package pe.gob.sunat.servicio2.registro.electronico.compago.cloud;

import javax.net.ssl.HostnameVerifier;
import javax.net.ssl.HttpsURLConnection;
import javax.net.ssl.SSLContext;
import javax.net.ssl.SSLHandshakeException;
import javax.net.ssl.SSLSession;
import javax.net.ssl.TrustManager;
import javax.net.ssl.X509TrustManager;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.net.MalformedURLException;
import java.net.URL;

import java.util.Date;
import java.util.List;

import org.apache.commons.codec.binary.Base64;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.apache.oltu.oauth2.client.request.OAuthClientRequest;
import org.apache.oltu.oauth2.common.exception.OAuthSystemException;
import org.apache.oltu.oauth2.common.message.types.GrantType;

import com.nimbusds.jose.JWSObject;

import net.minidev.json.JSONObject;
import pe.gob.sunat.cpe.portal.cloud.Portal;
import pe.gob.sunat.cpe.portal.cloud.client.PortalClient;
import pe.gob.sunat.cpe.portal.cloud.client.URLConnectionPortalClient;
import pe.gob.sunat.cpe.portal.cloud.client.request.CpePortalClientRequest;
import pe.gob.sunat.cpe.portal.cloud.client.request.CpeRejectedPortalClientRequest;
import pe.gob.sunat.cpe.portal.cloud.client.request.CpefilesPortalClientRequest;
import pe.gob.sunat.cpe.portal.cloud.client.request.PortalClientRequest;
import pe.gob.sunat.cpe.portal.cloud.client.response.PortalCreateCPEResponse;
import pe.gob.sunat.cpe.portal.cloud.client.response.PortalOperacionCPEResponse;
import pe.gob.sunat.cpe.portal.cloud.client.response.PortalQueryXmlFileResponse;
import pe.gob.sunat.cpe.portal.cloud.exception.AccessTokenException;
import pe.gob.sunat.cpe.portal.cloud.exception.PortalProblemException;
import pe.gob.sunat.cpe.portal.cloud.exception.PortalSystemException;
import pe.gob.sunat.facturaelectronica.portal.oauth.OAuthJSONAzureAccessToken;
import pe.gob.sunat.framework.util.Propiedades;
import pe.gob.sunat.servicio2.registro.electronico.compago.cloud.util.CloudUtilBean;
import pe.gob.sunat.servicio2.registro.model.dao.T01DAO;
import pe.gob.sunat.servicio2.registro.model.domain.T01Bean;

// PAS20191U210100174
public class CloudComprobanteServiceImpl implements CloudComprobanteService {
	protected final Log log = LogFactory.getLog(getClass());
	private T01DAO daoT01;
	private static final Propiedades cloudClientConfig = new Propiedades(CloudComprobanteServiceImpl.class,
			"/cloudClientConfig.properties");
	private int consultMaxRetries = Integer.parseInt(cloudClientConfig.leePropiedad("ConsultMaxRetries"));

	private String tokenRequestUrl = "";
	private String resourceUrlCpefiles = "";
	private String clientId = "";
	private String clientSecret = "";
	private String resourceUrlOperaciones = "";
	private String ClientIdOperaciones = "";
	private String ClientSecretOperaciones = "";
	private String resourceUrlCustodia = "";
	private String ClientIdCustodia = "";
	private String ClientSecretCustodia = "";
	private String tokenCpes;
	private String tokenOperaciones;
	private String tokenCustodia;
	private Long fechaExpired;
	// PAS20211U210700133 
	private String resourceUrlCloudConsulta = "";

	public T01DAO getDaoT01() {
		return daoT01;
	}

	public void setDaoT01(T01DAO daoT01) {
		this.daoT01 = daoT01;
	}

	public Long getFechaExpired() {
		return fechaExpired;
	}

	public void setFechaExpired(Long fechaExpired) {
		this.fechaExpired = fechaExpired;
	}

	@Override
	public void inicializarVariablesCpes() throws AccessTokenException {
		this.recuperarParametrosCpes();
		
		this.tokenCpes = this.getAccessTokenCpes();
	}
	
	@Override
	public void inicializarVariablesOperaciones() throws AccessTokenException {
		this.recuperarParametrosOperaciones();
		
		this.tokenOperaciones = this.getAccessTokenOperacion();
	}
	
	@Override
	public void inicializarVariablesCustodia() throws AccessTokenException {
		this.recuperarParametrosCustodia();
		
		this.tokenCustodia = this.getAccessTokenCustodia();
	}
	
	// PAS20211U210700133 
	@Override
	public void inicializarVariablesConsultasCloud() {
		this.recuperarParametrosConsultasCloud();
		
		//this.tokenCustodia = this.getAccessTokenCustodia();
	}
	
	private void recuperarParametrosCpes() {
		this.tokenRequestUrl = (this.daoT01.findByNumeroArgumento(CloudUtilBean.NUM_PARAMETRO_API_CPES_NUBE, "01")).getFuncion().substring(30).trim();
		this.clientId = (this.daoT01.findByNumeroArgumento(CloudUtilBean.NUM_PARAMETRO_API_CPES_NUBE, "02")).getFuncion().substring(30).trim();
		this.clientSecret = (this.daoT01.findByNumeroArgumento(CloudUtilBean.NUM_PARAMETRO_API_CPES_NUBE, "03")).getFuncion().substring(30).trim();
		this.resourceUrlCpefiles = (this.daoT01.findByNumeroArgumento(CloudUtilBean.NUM_PARAMETRO_API_CPES_NUBE, "06")).getFuncion().substring(30).trim();
		
		/*
		this.tokenRequestUrl = "http://api.sunat.peru/v1/contribuyente/cpe/portal/cloud/oauth2/token";
		this.clientId = "77e5fc92-651e-4a57-9de9-d111abf3e045";
		this.clientSecret = "FtYiPegJeFJNj0lBkV2VqsMHaY29][=.";
		this.resourceUrlCpefiles = "http://api.sunat.peru/v1/contribuyente/cpe/portal/cloud/api/cpefiles";
		*/
		
		if (log.isDebugEnabled()) log.debug("tokenRequestUrl==" + tokenRequestUrl + "==");
		if (log.isDebugEnabled()) log.debug("clientId==" + clientId + "==");
		if (log.isDebugEnabled()) log.debug("clientSecret==" + clientSecret + "==");
		if (log.isDebugEnabled()) log.debug("resourceUrlCpefiles==" + resourceUrlCpefiles + "==");		
	}
	
	private void recuperarParametrosOperaciones() {
		this.tokenRequestUrl = (this.daoT01.findByNumeroArgumento(CloudUtilBean.NUM_PARAMETRO_API_CPES_NUBE, "01")).getFuncion().substring(30).trim();
		this.ClientIdOperaciones = (this.daoT01.findByNumeroArgumento(CloudUtilBean.NUM_PARAMETRO_API_CPES_NUBE, "04")).getFuncion().substring(30).trim();
		this.ClientSecretOperaciones = (this.daoT01.findByNumeroArgumento(CloudUtilBean.NUM_PARAMETRO_API_CPES_NUBE,"05")).getFuncion().substring(30).trim();
		this.resourceUrlOperaciones = (this.daoT01.findByNumeroArgumento(CloudUtilBean.NUM_PARAMETRO_API_CPES_NUBE,"08")).getFuncion().substring(30).trim();

		/*
		this.tokenRequestUrl = "http://api.sunat.peru/v1/contribuyente/cpe/portal/cloud/oauth2/token";
		this.ClientIdOperaciones = "d16eaa57-8c0c-459a-b353-244ee5a20af4";
		this.ClientSecretOperaciones = "y=a+W6X1fOVH/y/zSMbX1X5=6p+j8V[d";
		this.resourceUrlOperaciones = "http://api.sunat.peru/v1/contribuyente/cpe/portal/cloud/api/cpes/:cpeid";
		*/
		
		if (log.isDebugEnabled()) log.debug("tokenRequestUrl==" + tokenRequestUrl + "==");
		if (log.isDebugEnabled()) log.debug("ClientIdOperaciones==" + ClientIdOperaciones + "==");
		if (log.isDebugEnabled()) log.debug("ClientSecretOperaciones==" + ClientSecretOperaciones + "==");
		if (log.isDebugEnabled()) log.debug("resourceUrlOperaciones==" + resourceUrlOperaciones + "==");
	}
	
	// PAS20211U210700133 
	private void recuperarParametrosConsultasCloud() {
		if (log.isDebugEnabled()) log.debug("resourceUrlCloudConsulta : " + CloudUtilBean.NUM_PARAMETRO_API_CPES_NUBE + " | recuperarParametrosConsultasCloud");
		List<T01Bean> lista = (this.daoT01.findByNumeroConsultaComprobante(CloudUtilBean.NUM_PARAMETRO_API_CPES_NUBE));
		this.resourceUrlCloudConsulta =	this.separarUrisFuncion(lista);

		if (log.isDebugEnabled()) log.debug("recuperarParametrosConsultasCloud|resourceUrlCloudConsulta==" + this.resourceUrlCloudConsulta + "==");
	}
		
	private void recuperarParametrosCustodia() {
		this.tokenRequestUrl = (this.daoT01.findByNumeroArgumento(CloudUtilBean.NUM_PARAMETRO_API_CPES_NUBE, "01")).getFuncion().substring(30).trim();
		this.ClientIdCustodia = (this.daoT01.findByNumeroArgumento(CloudUtilBean.NUM_PARAMETRO_API_CPES_NUBE, "09")).getFuncion().substring(30).trim();
		this.ClientSecretCustodia = (this.daoT01.findByNumeroArgumento(CloudUtilBean.NUM_PARAMETRO_API_CPES_NUBE,"10")).getFuncion().substring(30).trim();
		this.resourceUrlCustodia = (this.daoT01.findByNumeroArgumento(CloudUtilBean.NUM_PARAMETRO_API_CPES_NUBE,"11")).getFuncion().substring(30).trim();
		
		/*
		this.tokenRequestUrl = "http://api.sunat.peru/v1/contribuyente/cpe/portal/cloud/oauth2/token";
		this.ClientIdCustodia = "0fe899ed-b6b2-4577-8d96-060d54a534d7";
		this.ClientSecretCustodia = "GL2v26kLThPY2Q/PwCnbR.UQ:GtgavV[";
		this.resourceUrlCustodia = "http://api.sunat.peru/v1/contribuyente/cpe/portal/cloud/api/cpefiles/:cpeid";
		*/
		
		if (log.isDebugEnabled()) log.debug("tokenRequestUrl==" + tokenRequestUrl + "==");
		if (log.isDebugEnabled()) log.debug("ClientIdCustodia==" + ClientIdCustodia + "==");
		if (log.isDebugEnabled()) log.debug("ClientSecretCustodia==" + ClientSecretCustodia + "==");
		if (log.isDebugEnabled()) log.debug("resourceUrlCustodia==" + resourceUrlCustodia + "==");
	}
	
	private String getAccessTokenCpes() throws AccessTokenException {
		// CONFIGURACION DEL REQUEST
		OAuthClientRequest request = null;
		try {
			request = OAuthClientRequest.tokenLocation(tokenRequestUrl).setClientId(clientId)
					.setClientSecret(clientSecret).setParameter("resource", clientId)
					// no cambia
					.setGrantType(GrantType.CLIENT_CREDENTIALS)
					.buildBodyMessage();

		} catch (OAuthSystemException e) {
			throw new AccessTokenException("Error al configurar el cliente OAuth", e);
		}

		OAuthJSONAzureAccessToken azureAccessToken = OAuthJSONAzureAccessToken.getInstance();
		
		if (log.isDebugEnabled()) log.debug("TestOauth.getAccessTokenCpes() funciona");
		return azureAccessToken.getAccessToken(request);
	}

	private String getAccessTokenOperacion() throws AccessTokenException {
		OAuthClientRequest request = null;
		try {
			request = OAuthClientRequest.tokenLocation(tokenRequestUrl).setClientId(ClientIdOperaciones)
					.setClientSecret(ClientSecretOperaciones).setParameter("resource", ClientIdOperaciones)
					// no cambia
					.setGrantType(GrantType.CLIENT_CREDENTIALS)
					.buildBodyMessage();

			if (log.isDebugEnabled()) log.debug(request.getLocationUri());
		} catch (OAuthSystemException e) {
			throw new AccessTokenException("Error al configurar el cliente OAuth", e);
		}

		OAuthJSONAzureAccessToken azureAccessToken = OAuthJSONAzureAccessToken.getInstance();
		if (log.isDebugEnabled()) log.debug("TestOauth.getAccessTokenOperacion() funciona");
		return azureAccessToken.getAccessToken(request);
	}
	
	private String getAccessTokenCustodia() throws AccessTokenException {
		OAuthClientRequest request = null;
		try {
			request = OAuthClientRequest.tokenLocation(tokenRequestUrl).setClientId(ClientIdCustodia)
					.setClientSecret(ClientSecretCustodia).setParameter("resource", ClientIdCustodia)
					// no cambia
					.setGrantType(GrantType.CLIENT_CREDENTIALS)
					.buildBodyMessage();

			if (log.isDebugEnabled()) log.debug(request.getLocationUri());
		} catch (OAuthSystemException e) {
			throw new AccessTokenException("Error al configurar el cliente OAuth", e);
		}

		OAuthJSONAzureAccessToken azureAccessToken = OAuthJSONAzureAccessToken.getInstance();
		if (log.isDebugEnabled()) log.debug("TestOauth.getAccessTokenCustodia() funciona");
		return azureAccessToken.getAccessToken(request);
	}

	/**
	 * @param token de autenticacion
	 * @param cpeid - identificador del CPE formato RUC-COD_CPE-NIM_SERIE_CPE-UM_CPE sin ceros las izquierda
	 * @param filename - nombre del archivo XML a firmar (lo mismo del cpeid con la extension .xml)
	 * @param body - XML a firmar en base 64
	 * @return XML firmado en base 64
	 */
	private String[] getGuidFromCpesfilesService(String token, String cpeid, String filename, String body) {
		if (log.isDebugEnabled()) log.debug("getGuidFromCpesfilesService ==" + cpeid + "==");
		String[] result = new String[3];

		PortalClient client = new PortalClient(new URLConnectionPortalClient());

		// se configura el request
		PortalClientRequest request = null;
		try {
			request = CpefilesPortalClientRequest.resourceLocation(resourceUrlCpefiles).setCpeid(cpeid).setContent(body)
					.setFileName(filename).buildJSONMessage();

			request.addAuthorizationHeader(token);
		} catch (PortalSystemException e) {
			result[0] = "-1";
			result[1] = createErrorMessage(cpeid, "Ocurrio un error al configurar el request", e);
			return result;
		}

		PortalCreateCPEResponse portalCPEResponse = null;
		try {
			portalCPEResponse = client.callCreateCpeService(request, PortalCreateCPEResponse.class);
			result[0] = "1";
			result[1] = portalCPEResponse.getGuid();
			result[2] = portalCPEResponse.getContent();
			// portalCPEResponse.getBody();

			return result;

		} catch (PortalSystemException e) {
			result[0] = "-1";
			result[1] = createErrorMessage(cpeid, "Ocurrio un error al realiza el llamado al servicio: ", e);
			return result;
		} catch (PortalProblemException e) {
			result[0] = "-1";
			result[1] = createErrorMessage(cpeid, "Ocurrio un error al procesar el cpe, response status " + e.getResponseStatus(), e);
			return result;
		}
	}

	/**
	 * Rechazado por el receptor; evento que indica que el comprobante fue rechazado
	 * por el receptor
	 * 
	 * @param token
	 * @param cpeid
	 * @return Mensaje de exito o error
	 */
	private String rejectByReciever(String token, String cpeid) {
		if (log.isDebugEnabled()) log.debug("rejectByReciever ==" + cpeid + "==");
		PortalClient client = new PortalClient(new URLConnectionPortalClient());

		PortalClientRequest request = null;
		try {
			if (log.isDebugEnabled()) log.debug("rejectByReciever ==" + resourceUrlOperaciones.replace(":cpeid", cpeid) + "==");
			request = CpeRejectedPortalClientRequest.resourceLocation(resourceUrlOperaciones.replace(":cpeid", cpeid))
					.isRejectedByReceiver().buildJSONMessage();

			request.addAuthorizationHeader(token);
		} catch (PortalSystemException e) {
			return createErrorMessage(cpeid, "Ocurrio un error al configurar el request", e);
		}

		PortalOperacionCPEResponse portalCPEResponse = null;

		try {
			portalCPEResponse = client.callOperacionesCpeService(request);
			return "La operacion de rechazo se ejecuto con exito?: " + portalCPEResponse.isResponseOK();
		} catch (PortalSystemException e) {
			return createErrorMessage(cpeid, "Ocurrio un error al realiza el llamado al servicio", e);
		} catch (PortalProblemException e) {
			return createErrorMessage(cpeid, "Ocurrio un error al procesar el rechazo, response status " + e.getResponseStatus(), e);
		}
	}
		
	public byte[] getServiceXmlFile2_0(String cpeid){
		if (log.isDebugEnabled()) log.debug("==getServiceXmlFile2_0==" + cpeid + "==");
		 ByteArrayOutputStream buffer = null;
		 URL url;
		 String uris = resourceUrlCloudConsulta.replace(":cpeid", cpeid);

		 String[] urls = uris.split(";");
		  for (String uri : urls) {
				 HttpsURLConnection connection;
				 if (log.isDebugEnabled()) log.debug("getServiceXmlFile2_0=uri==" + uri + "==");
				  
				try {		
					
					log.debug("getServiceXmlFile2_0==VerificandoURI==");
		            url = new URL(null, uri, new sun.net.www.protocol.https.Handler());
		
				    log.debug("getServiceXmlFile2_0==HttpsURLConnection==");
					
			        connection = (HttpsURLConnection) url.openConnection();
			       
			        log.debug("HttpsURLConnection==Verificado==");
			        
			        SSLContext sc = SSLContext.getInstance("SSL");
			        log.debug("getServiceXmlFile2_0==Verificado SSL==");
			        
			        sc.init(null, new TrustManager[] { new TrustAnyTrustManager() }, new java.security.SecureRandom());
		
					// Create all-trusting host name verifier
					HostnameVerifier allHostsValid = new HostnameVerifier() {
						@Override
						public boolean verify(String hostname, SSLSession session) {
							return true;
						}
					};
					 log.debug("getServiceXmlFile2_0==allHostsValid ok==");
 
			        connection.setHostnameVerifier(allHostsValid);
			        connection.setSSLSocketFactory(sc.getSocketFactory());
			        log.debug("setHostnameVerifier==setSSLSocketFactory==ok");  
			        
					int responseCode = connection.getResponseCode();
					if (log.isDebugEnabled()) log.debug("=responseCode=" + responseCode);
					
					log.debug("==INICIANDO LECTURA DE STREAM==");  
			        InputStream is = connection.getInputStream();
			        buffer = new ByteArrayOutputStream();
			        
			        int nRead;
			        byte[] data = new byte[2048];
		
			        while ((nRead = is.read(data, 0, data.length)) != -1) {
			        		buffer.write(data, 0, nRead);
			        }
			        
			        log.debug("==FIN LECTURA DE STREAM==");
			        if (buffer.size() > 0) {
			        	if (log.isDebugEnabled()) log.debug("=====El buffer no esta vacio=====");
			        	return buffer.toByteArray();
					} else {
						if (log.isDebugEnabled()) log.debug("El buffer esta vacio, puede que no exista el comprobante consultado o hay un problema de conexion==" + uri + "==");
						//return new byte[0];
					} 
				} catch (SSLHandshakeException e) {
					log.debug(createErrorMessage(uri, "Ocurrio un error SSLHandshakeException", e));
					e.printStackTrace();
					//return new byte[0];         		
				} catch (MalformedURLException e) {
					log.debug(createErrorMessage(uri, "Ocurrio un error MalformedURLException al configurar el request", e));
					e.printStackTrace();
					//return new byte[0];
				} catch (IOException e) {
					log.debug(createErrorMessage(uri, "Ocurrio un error IOException al procesar el cpe, response status " + e.getMessage(), e));
					e.printStackTrace();
					//return new byte[0];
				}catch (Exception e) {
					log.debug(createErrorMessage(uri, "Ocurrio un error Exception  " + e.getMessage(), e));
					e.printStackTrace();
					//return new byte[0];
				}
		  }
		  return new byte[0];
	}

	/**
	 * getServiceXmlFile
	 * 
	 * @param token
	 * @param cpeid
	 * @param tipoDocument
	 * @return String[] Mensaje de exito o error: [1]-correcto [-1]-incorrecto [-2]-Otro error
	 */
	private String[] getServiceXmlFile(String token, String cpeid, String tipoDocument) {
		if (log.isDebugEnabled()) log.debug("getServiceXmlFile ==" + cpeid + "==");
		String[] result = new String[3];
		
		PortalClient client = new PortalClient(new URLConnectionPortalClient());

		PortalClientRequest request = null;
		try {
			if (log.isDebugEnabled()) log.debug("getServiceXmlFile ==" + resourceUrlCustodia.replace(":cpeid", cpeid) + "; tipoDocumento:" + tipoDocument);
			request = CpePortalClientRequest.resourceLocation(resourceUrlCustodia.replace(":cpeid", cpeid)).setParameter("type", tipoDocument).buildQueryMessage();

			request.addAuthorizationHeader(token);
		} catch (PortalSystemException e) {
			result[0] = "-2";
			result[1] = createErrorMessage(cpeid, "Ocurrio un error al configurar el request", e);
			return result;
		}

		PortalQueryXmlFileResponse portalCPEResponse = null;
		
		try {
			portalCPEResponse = client.callService(request, Portal.HttpMethod.GET, PortalQueryXmlFileResponse.class);
			if (portalCPEResponse.getBody() != null) {
				result[0] = "1";
				result[1] = "0"; //portalCPEResponse.getGuid();
				result[2] = portalCPEResponse.getBody();
			} else {
				result[0] = "-1";
				result[1] = "No existe el comprobante consultado";
			}

			return result;
			
		} catch (PortalSystemException e) {
			log.debug("PortalSystemException e");
            result[0] = "-2";
			result[1] = createErrorMessage(cpeid, "Ocurrio un error al realiza el llamado al servicio: ", e);
			return result;            
            
        } catch (PortalProblemException e) {
        	log.debug("PortalProblemException e");
            result[0] = "-2";
			result[1] = createErrorMessage(cpeid, "Ocurrio un error al procesar el cpe, response status " + e.getResponseStatus(), e);
			return result;
			
        }
	}

	private static String createErrorMessage(String cpeid, String mensaje, Throwable e) {
		StringBuilder stBuilder = new StringBuilder();

		stBuilder.append("\n\n==============================| ERROR CPE ").append(cpeid)
				.append(" |==============================\n\n").append(mensaje).append("-->").append(e.getMessage())
				.append("\n\n");

		return stBuilder.toString();
	}

	@Override
	public String[] firmarComprobanteCloud(String cpeid, String fileName, String cpeXml) throws IOException {
		String cpexmlInBase64 = new String(Base64.encodeBase64(cpeXml.getBytes("UTF-8")));
		if (log.isDebugEnabled()) log.debug("firmarComprobanteCloud cpeid==" + cpeid + "==");
		if (log.isDebugEnabled()) log.debug("firmarComprobanteCloud fileName==" + fileName + "==");
		if (log.isDebugEnabled()) log.debug("firmarComprobanteCloud cpexmlInBase64 (encoded)==" + cpexmlInBase64 + "==");

		String[] result = this.getGuidFromCpesfilesService(this.tokenCpes, cpeid, fileName, cpexmlInBase64);

		if (result[0].equals("1")) {
			log.info(cpeid + " CloudService - respuesta correcta GUID==" + result[1] + "==");
			
			if (log.isDebugEnabled()) log.debug(cpeid + " firmarComprobanteCloud - respuesta: XML Base64==" + result[2] + "==");
			result[2] = new String(Base64.decodeBase64(result[2].getBytes()),
					org.apache.commons.codec.CharEncoding.UTF_8);
			if (log.isDebugEnabled()) log.debug(cpeid + " firmarComprobanteCloud - respuesta: XML decoded (UTF-8)==" + result[2] + "==");
		} else {
			log.error(cpeid + " firmarComprobanteCloud respuesta incorrecta==" + result[1] + "==");
		}

		return result;
	}
	
	@Override
	public boolean rechazarComprobanteCloud(String cpeid) {
		if (log.isDebugEnabled()) log.debug("rechazarComprobanteCloud cpeid==" + cpeid + "==");
		String response = this.rejectByReciever(this.tokenOperaciones, cpeid);

		if (response.contains("true")) {
			log.info(cpeid + " rechazarComprobanteCloud response==" + response + "==");
			response = "true";
		} else {
			log.error(cpeid + " rechazarComprobanteCloud response==" + response + "==");
			response = "false";
		}
		
		return Boolean.parseBoolean(response);
	}
	
	/**
	 * consultarComprobanteCloud
	 * Permite realizar la consulta a cloud siempre y cuando se haya inicializado inicializarVariablesCustodia()
	 * 
	 * @param cpeid
	 * @return String[] Mensaje de exito o error: [1]-correcto [-1]-incorrecto [-2]-Otro error
	 */
	@Override
	public String[] consultarComprobanteCloud(String cpeid) {
		if (log.isDebugEnabled()) log.debug("consultarComprobanteCloud cpeid==" + cpeid + "==");
		String tipoDocument = "document";
		
		int pIntentos = 1;
		String[] result = new String[3];
		if (consultMaxRetries <= 0) consultMaxRetries = 1;
		
		while(pIntentos <= consultMaxRetries) {
			log.debug(cpeid + " consultarComprobanteCloud Intento==" + pIntentos + "==");
			result = this.getServiceXmlFile(tokenCustodia, cpeid, tipoDocument);
			
			if (result[0].equals("1")) {
				log.debug(cpeid + " consultarComprobanteCloud response==" + result[2] + "==");
				break;
			} else {
				log.debug(cpeid + " consultarComprobanteCloud response==" + result[1] + "==");
			}
			pIntentos++;		
		}
		
		if (result[0].equals("1")) {
			log.info(cpeid + " consultarComprobanteCloud response: Se encontr� el comprobante");			
		} else {
			log.info(cpeid + " consultarComprobanteCloud response==" + result[1] + "==");
		}
		
		return result;
	}
	
	
	
	

	
	/**
	 * PAS20211U210700133
	 * consultarComprobanteCloudv2_0
	 * Permite realizar la consulta a cloud siempre y cuando se haya inicializado inicializarVariablesCloudv2_0()
	 * 
	 * @param cpeid
	 * @return String[] 
	 
	@Override
	public String[] consultarComprobanteCloudv2_0(String guid) {
		if (log.isDebugEnabled()) log.debug("consultarComprobanteCloudv2_0 guid==" + guid + "==");
		
		int pIntentos = 1;
		String[] result = new String[3];
		if (consultMaxRetries <= 0) consultMaxRetries = 1;
		
		while(pIntentos <= consultMaxRetries) {
			log.debug(guid + "=consultarComprobanteCloudv2_0 Intento==" + pIntentos + "==");
			result = this.getServiceXmlFile2_0(guid);
			
			if (result[0].equals("1")) {
				log.debug(guid + "=consultarComprobanteCloudv2_0 response==" + result[2] + "==");
				break;
			} else {
				log.debug(guid + "=consultarComprobanteCloudv2_0 response==" + result[1] + "==");
			}
			pIntentos++;		
		}
		
		if (result[0].equals("1")) {
			log.info(guid + "=consultarComprobanteCloudv2_0 response: Se encontr� el comprobante");			
		} else {
			log.info(guid + "=consultarComprobanteCloudv2_0 response==" + result[1] + "==");
		}
				
		return result;
	}
	*/
	
	
	
	public byte[] consultarComprobanteCloudv2_0(String guid) {
		if (log.isDebugEnabled()) log.debug("consultarComprobanteCloudv2_0 guid==" + guid + "==");
		
		int pIntentos = 1;
		byte[] result = null;
		if (consultMaxRetries <= 0) consultMaxRetries = 1;
		
		while(pIntentos <= consultMaxRetries) {
			log.debug(guid + "=consultarComprobanteCloudv2_0-Intento==" + pIntentos + "==");
			result = this.getServiceXmlFile2_0(guid);
			pIntentos++;		
		}
		/*
		if (result.length > 0) {
			log.info(guid + "=consultarComprobanteCloudv2_0 response==Se encontr� el comprobante");			
		} else {
			log.info(guid + "=consultarComprobanteCloudv2_0 response==No Se encontr� el comprobante==");
		}
			*/	
		return result;
	}
	
	
	@Override
	public boolean esVigenteTokenCpes() throws Exception {
		return esVigente(this.tokenCpes);
	}
	
	@Override
	public boolean esVigenteTokenOperaciones() throws Exception {
		return esVigente(this.tokenOperaciones);
	}
	
	@Override
	public boolean esVigenteTokenCustodia() throws Exception {
		return esVigente(this.tokenCustodia);
	}
	
	private boolean esVigente(String authcode) throws Exception {
		if (log.isDebugEnabled()) log.debug("esVigente authcode==" + authcode + "==");
		
		if (authcode == null || authcode.equals("")) return false;
		
		JWSObject jwtObject = JWSObject.parse(authcode);
		//JWSVerifier verifier = new RSASSAVerifier(rsapublickey);
		//boolean result = jwtObject.verify(verifier);
		
		boolean result = true;
		// Si la firma es correcta se valida si el auth code esta expirado
		JSONObject payload = jwtObject.getPayload().toJSONObject();
		String exp = payload.getAsString("exp");
		long expLong = Long.valueOf(exp)  * 1000;
		Date currentDate = new Date();
		long currentLong = currentDate.getTime();
		if(expLong < currentLong) {
			result = false;
		}
		
		return result;	
	}
	
	private String separarUrisFuncion(List<T01Bean> lista)
	{
		if (log.isDebugEnabled()) log.debug("separarUrisFuncion : " + lista.size());
		StringBuilder sb = new StringBuilder();

		for (T01Bean bean : lista) {
		    sb.append(bean.getFuncion().substring(30).trim());
		    sb.append(";");
		}
		String cadena = sb.toString();
		
		if (cadena.endsWith(";")) {
		    cadena = cadena.substring(0, cadena.length() - 1);
		}
		if (log.isDebugEnabled()) log.debug("separarUrisFuncion : " + cadena);
		return cadena;	
	}

}

class TrustAnyTrustManager implements X509TrustManager {

	@Override
	public void checkClientTrusted(java.security.cert.X509Certificate[] arg0, String arg1)
			throws java.security.cert.CertificateException {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void checkServerTrusted(java.security.cert.X509Certificate[] arg0, String arg1)
			throws java.security.cert.CertificateException {
		// TODO Auto-generated method stub
		
	}

	@Override
	public java.security.cert.X509Certificate[] getAcceptedIssuers() {
		// TODO Auto-generated method stub
		return null;
	}
}