package pe.gob.sunat.servicio2.registro.electronico.comppago.generatecdr;

import java.io.Serializable;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.GregorianCalendar;
import java.util.List;

import org.apache.commons.lang.Validate;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

public class ApplicationResponse implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = -2941744850627802136L;

	final Log logger = LogFactory.getLog(ApplicationResponse.class);// LoggerFactory.getLogger(ApplicationResponse.class);

	private String ticket;
	private Integer codeError;
	private boolean withException;
	private boolean voided;
	private String note;
	private String documentReference;
	private String documentTypeCode;
	private String senderParty;
	private String receiverParty;
	private String receiverName;
	private String issueDate;
	private String issueTime;
	private String responseDate;
	private String responseTime;
	private Long ticketPrecedent;
	private String signer;
	private String reference;

	/**
	 * Campos agregados para saber el tipo de documento de identidad y el numero
	 * del doc de identidad del receptor o cliente.
	 */
	private String customerAssignedAccountID;
	/** Numero de documento */
	private String additionalAccountID;
	/** Tipo de documento */

	private List<WarningComprobante> listaWarnings;
	private byte[] content;

	static DateFormat yearMontDayFormat = new SimpleDateFormat("yyyy-MM-dd");
	static DateFormat hourMinuteSecond = new SimpleDateFormat("HH:mm:ss");

	public ApplicationResponse(Builder builder) {
		this.ticket = builder.ticket;
		this.codeError = builder.codeError;
		this.withException = builder.exception;
		this.voided = builder.voided;
		this.note = builder.note;
		this.documentReference = builder.documentReference;
		this.documentTypeCode = builder.documentTypeCode;
		this.senderParty = builder.senderParty;
		this.receiverParty = builder.receiverParty;
		this.receiverName = builder.receiverName;
		this.issueDate = builder.issueDate;
		this.issueTime = builder.issueTime;
		this.responseDate = builder.responseDate;
		this.responseTime = builder.responseTime;
		this.ticketPrecedent = builder.ticketPrecedent;
		this.signer = builder.signer;
		this.reference = builder.reference;
		this.customerAssignedAccountID = builder.customerAssignedAccountID;
		this.additionalAccountID = builder.additionalAccountID;
		this.listaWarnings = builder.listaWarnings;
	}

	@SuppressWarnings("unused")
	private ApplicationResponse() {

	}

	public String getTicket() {
		return ticket;
	}

	public void setTicket(String ticket) {
		this.ticket = ticket;
	}

	public Integer getCodeError() {
		return codeError;
	}

	public void setCodeError(Integer codeError) {
		this.codeError = codeError;
	}

	public boolean isWithException() {
		return withException;
	}

	public void setWithException(boolean withException) {
		this.withException = withException;
	}

	public boolean isVoided() {
		return voided;
	}

	public void setVoided(boolean voided) {
		this.voided = voided;
	}

	public String getNote() {
		return note;
	}

	public void setNote(String note) {
		this.note = note;
	}

	public String getDocumentReference() {
		return documentReference;
	}

	public void setDocumentReference(String documentReference) {
		this.documentReference = documentReference;
	}

	public String getDocumentTypeCode() {
		return documentTypeCode;
	}

	public void setDocumentTypeCode(String documentTypeCode) {
		this.documentTypeCode = documentTypeCode;
	}

	public String getSenderParty() {
		return senderParty;
	}

	public void setSenderParty(String senderParty) {
		this.senderParty = senderParty;
	}

	public String getReceiverParty() {
		return receiverParty;
	}

	public void setReceiverParty(String receiverParty) {
		this.receiverParty = receiverParty;
	}

	public String getReceiverName() {
		return receiverName;
	}

	public void setReceiverName(String receiverName) {
		this.receiverName = receiverName;
	}

	public String getIssueDate() {
		return issueDate;
	}

	public void setIssueDate(String issueDate) {
		this.issueDate = issueDate;
	}

	public String getIssueTime() {
		return issueTime;
	}

	public void setIssueTime(String issueTime) {
		this.issueTime = issueTime;
	}

	public String getResponseDate() {
		return responseDate;
	}

	public void setResponseDate(String responseDate) {
		this.responseDate = responseDate;
	}

	public String getResponseTime() {
		return responseTime;
	}

	public void setResponseTime(String responseTime) {
		this.responseTime = responseTime;
	}

	public Long getTicketPrecedent() {
		return ticketPrecedent;
	}

	public void setTicketPrecedent(Long ticketPrecedent) {
		this.ticketPrecedent = ticketPrecedent;
	}

	public boolean hasPrecedent() {
		return (ticketPrecedent != null && ticketPrecedent != 0);
	}

	public String getSigner() {
		return signer;
	}

	public void setSigner(String signer) {
		this.signer = signer;
	}

	public String getReference() {
		return reference;
	}

	public void setReference(String reference) {
		this.reference = reference;
	}

	public String getCustomerAssignedAccountID() {
		if (customerAssignedAccountID != null
				&& customerAssignedAccountID.length() >= 1) {
			return customerAssignedAccountID;
		} else {
			return "";
		}
	}

	public void setCustomerAssignedAccountID(String customerAssignedAccountID) {
		this.customerAssignedAccountID = customerAssignedAccountID;
	}

	public String getAdditionalAccountID() {
		if (additionalAccountID != null && additionalAccountID.length() >= 1) {
			if (additionalAccountID.length() > 1
					&& additionalAccountID.charAt(0) == '0') {
				return additionalAccountID.substring(1);
			} else {
				return additionalAccountID;
			}
		} else {
			return "";
		}
	}

	public void setAdditionalAccountID(String additionalAccountID) {
		this.additionalAccountID = additionalAccountID;
	}

	public void addWarning(String codigo, String descripcion) {
		if (listaWarnings == null) {
			listaWarnings = new ArrayList<WarningComprobante>();
		}

		WarningComprobante m = new WarningComprobante(codigo, descripcion);
		listaWarnings.add(m);
	}

	public List<WarningComprobante> getListaWarnings() {
		return listaWarnings;
	}

	public void setListaWarnings(List<WarningComprobante> listaWarnings) {
		this.listaWarnings = listaWarnings;
	}

	public byte[] getContent() {
		return content;
	}

	public void setContent(byte[] content) {
		this.content = content;
	}

	/**
	 * Builder para la tabla rubros
	 * 
	 * @author fjonislla
	 * 
	 */
	public static class Builder {

		private String ticket;
		private Integer codeError;
		private boolean exception = false;
		private boolean voided = false;
		private String note;
		private String documentReference;
		private String documentTypeCode;
		private String senderParty;
		private String receiverParty;
		private String receiverName;
		private String issueDate;
		private String issueTime;
		private String responseDate;
		private String responseTime;
		private Long ticketPrecedent;
		private String signer;
		private String reference;
		private String customerAssignedAccountID;
		private String additionalAccountID;

		private List<WarningComprobante> listaWarnings;

		public Builder withCustomerAssignedAccountID(
				String customerAssignedAccountID) {
			this.customerAssignedAccountID = customerAssignedAccountID;
			return this;
		}

		public Builder withNote(String note) {
			this.note = note;
			return this;

		}

		public Builder withAdditionalAccountID(String additionalAccountID) {
			this.additionalAccountID = additionalAccountID;
			return this;
		}

		public Builder withTicket(String ticket) {
			this.ticket = ticket;
			return this;
		}

		public Builder withCodeError(Integer codeError) {
			this.codeError = codeError;
			return this;
		}

		public Builder withDocumentReference(String idComprobante) {

			this.documentReference = idComprobante;

			return this;
		}

		public Builder withSenderParty(String senderParty) {
			this.senderParty = senderParty;
			return this;
		}

		public Builder withReceiverParty(String receiverParty) {
			this.receiverParty = receiverParty;
			return this;
		}

		public Builder withReceiverName(String receiverName) {
			this.receiverName = receiverName;
			return this;
		}

		public Builder withIssueDate(String issueDate) {
			this.issueDate = issueDate;
			return this;
		}

		public Builder withIssueDateTime(Date issueDateTime) {

			if (issueDateTime == null) {
				issueDateTime = new Date();
			}

			this.issueDate = yearMontDayFormat.format(issueDateTime);

			this.issueTime = hourMinuteSecond.format(issueDateTime);

			return this;
		}

		public Builder withIssueTime(String issueTime) {
			this.issueTime = issueTime;
			return this;
		}

		public Builder withResponseDate(String responseDate) {
			this.responseDate = responseDate;
			return this;
		}

		public Builder withDocumentTypeCode(String documentTypeCode) {
			this.documentTypeCode = documentTypeCode;
			return this;
		}

		public Builder withResponseTime(String responseTime) {
			this.responseTime = responseTime;
			return this;
		}

		public Builder withTicketPrecedent(Long ticketPrecedent) {
			this.ticketPrecedent = ticketPrecedent;
			return this;
		}

		public Builder withSigner(String signer) {
			this.signer = signer;
			return this;
		}

		public Builder withReference(String reference) {
			this.reference = reference;
			return this;
		}

		public Builder withListaWarnings(List<WarningComprobante> listaWarnings) {
			this.listaWarnings = listaWarnings;
			return this;
		}

		public ApplicationResponse buildResponseError(Integer codigoError) {
			commonFields(codigoError);
			exception = false;
			voided = true;
			validateResponseError();
			return new ApplicationResponse(this);
		}

		public ApplicationResponse buildResponseOK() {
			commonFields(0);
			/** dentro del builder **/

			exception = false;
			voided = false;
			validateResponse();
			return new ApplicationResponse(this);
		}

		public ApplicationResponse buildResponseWithException(
				Integer codigoError) {
			commonFields(codigoError);
			exception = true;
			voided = false;
			validateResponseError();
			return new ApplicationResponse(this);
		}

		/**
		 * setea los campos genericos para una factura GEM
		 * 
		 * @param comprobante
		 */

		private void commonFields(Integer codigoError) {
			Calendar fechaactual = GregorianCalendar.getInstance();
			responseDate = yearMontDayFormat.format(fechaactual.getTime());
			responseTime = hourMinuteSecond.format(fechaactual.getTime());
			// del que envia la respuesta en esta caso la SUNAT
			senderParty = "20131312955";
			signer = "SUNAT";
			reference = "SignSUNAT";
			this.codeError = codigoError;
		}

		private void validateResponse() {
			Validate.notNull(ticket);
			Validate.notEmpty(receiverParty);
			// Validate.notEmpty(receiverName);
			Validate.notEmpty(issueDate);
			Validate.notEmpty(issueTime);
			// del nombre del archivo
			Validate.notEmpty(documentReference);
			Validate.notEmpty(customerAssignedAccountID);
			Validate.notEmpty(documentTypeCode);
			Validate.notEmpty(note);

		}

		private void validateResponseError() {
			Validate.notNull(ticket);
			Validate.notEmpty(receiverParty);
			// Validate.notEmpty(receiverName);
			Validate.notEmpty(issueDate);
			Validate.notEmpty(issueTime);
			// del nombre del archivo
			Validate.notEmpty(documentReference);
			// Validate.notEmpty(customerAssignedAccountID);
			// Validate.notEmpty(documentTypeCode);
			// Validate.notEmpty(note);

		}

	}

}
