package pe.gob.sunat.servicio2.registro.electronico.comppago.generatecdr;

import java.io.Serializable;
import java.math.BigDecimal;
import java.util.Date;
import java.util.List;

/**
 * Clase abstracta que representa al comprobante electronico los modelos de
 * comprobante electronico deberan de extender de esta clase
 * 
 * @author fjonisllap
 *
 */

public class ComprobanteElectronico implements Serializable {

	private static final long serialVersionUID = -1791677579287686383L;
	public static final String CODIGO_COMPROMBATE_FACTURA = "01";
	public static final String CODIGO_COMPROMBATE_SERVICIO_PUBLICO = "14";
	public static final String CODIGO_COMPROMBATE_BOLETA = "03";
	public static final String CODIGO_COMPROMBATE_NOTA_CREDITO = "07";
	public static final String CODIGO_COMPROMBATE_NOTA_DEBITO = "08";

	

	public static boolean isFactura(String codigoTipoComprobante) {
		return ComprobanteElectronico.CODIGO_COMPROMBATE_FACTURA
				.equals(codigoTipoComprobante);
	}

	public static boolean isServicioPublico(String codigoTipoComprobante) {
		return ComprobanteElectronico.CODIGO_COMPROMBATE_SERVICIO_PUBLICO
				.equals(codigoTipoComprobante);
	}

	public static boolean isBoleta(String codigoTipoComprobante) {
		return ComprobanteElectronico.CODIGO_COMPROMBATE_BOLETA
				.equals(codigoTipoComprobante);
	}

	public static boolean isNotaCredito(String codigoTipoComprobante) {
		return ComprobanteElectronico.CODIGO_COMPROMBATE_NOTA_CREDITO
				.equals(codigoTipoComprobante);
	}

	public static boolean isNotaDebito(String codigoTipoComprobante) {
		return ComprobanteElectronico.CODIGO_COMPROMBATE_NOTA_DEBITO
				.equals(codigoTipoComprobante);
	}

	public static String getCodigoComprobanteFromFilename(String filename) {
		return filename.substring(12, 14);
	}

	private Date fechaEmision;
	private PkComprobante pkComprobante;
	private Contribuyente emisor;
	private Contribuyente receptor;

	private String codMoneda;

	private BigDecimal totalIGV = new BigDecimal(0.0);
	private BigDecimal totalOtrosTributos = new BigDecimal(0.0);
	private BigDecimal totalISC = new BigDecimal(0.0);
	private BigDecimal totalOtrosCargos = new BigDecimal(0.0);
	private BigDecimal totalDescuentos = new BigDecimal(0.0);
	private BigDecimal totalAnticipos = new BigDecimal(0.0);
	private BigDecimal totalImporte = new BigDecimal(0.0);

	private BigDecimal subTotalValorVenta = new BigDecimal(0.0);

	private String nombreFichero;

	private boolean tieneExportacion;
	private boolean tieneVentaNetaGrabada;
	private boolean tieneVentaNetaNoGrabada;

	private boolean tieneVentaNetaExonerada;
	private boolean tieneISC;

	private BigDecimal ventaNetaGravadas = new BigDecimal(0.0);
	private BigDecimal ventaNetaNoGravadas = new BigDecimal(0.0);
	private BigDecimal ventaNetaExoneradas = new BigDecimal(0.0);
	private BigDecimal transferenciaGratuita = new BigDecimal(0.0);
	private BigDecimal montoPercepcion = new BigDecimal(0.0);

	// indicadores
	private boolean inafecto; // indica si hay inafectos //tipoBeneficio = TB02
	private boolean exportacion; // indica si hay exportaciones //tipoBeneficio
									// = TB04
	private boolean exonerado; // indica si hay exoneraciones //tipoBeneficio =
								// TB01
	private boolean gravada; // indica si es venta total gravada //tipoBeneficio
								// = TB01

	private List<String> lstCodLeyenda;
	
	
	public ComprobanteElectronico(PkComprobante pkComprobante, Contribuyente emisor,
			Contribuyente receptor, Date fechaEmision) {
		
		this.pkComprobante = pkComprobante;
		
		this.emisor = emisor;
		
		this.receptor = receptor;
		
		this.fechaEmision = fechaEmision;
		
	}
	

	public boolean isFactura() {
		return CODIGO_COMPROMBATE_FACTURA.equals(getCodigoTipoComprobante());
	}

	public boolean isBoleta() {
		return CODIGO_COMPROMBATE_BOLETA.equals(getCodigoTipoComprobante());
	}

	public boolean isServicioPublico() {
		return CODIGO_COMPROMBATE_SERVICIO_PUBLICO
				.equals(getCodigoTipoComprobante());
	}

	public boolean isNotaCredito() {
		return CODIGO_COMPROMBATE_NOTA_CREDITO
				.equals(getCodigoTipoComprobante());
	}

	public boolean isNotaDebito() {
		return CODIGO_COMPROMBATE_NOTA_DEBITO
				.equals(getCodigoTipoComprobante());
	}

	/**
	 * Verifica que sea un comprobante valido
	 * 
	 * @return
	 */
	// public abstract boolean isCpeValido();

	// Retorna el codigo del tipo de comprobante
	public String getCodigoTipoComprobante() {
		return pkComprobante.getCodCpe();
	}

	// Retorna la fecha de emision del comprobante
	public Date getFechaEmision() {
		return fechaEmision;
	}

	public void setFechaEmision(Date fechaEmision) {
		this.fechaEmision = fechaEmision;
		;
	}

	// Retorna el identificador del comprobante
	// debe de implementarse en cada hijo del comprobante
	public String getIdComprobante() {
		return getPkComprobante().toString();
	}

	public boolean isInafecto() {
		return inafecto;
	}

	public boolean isExportacion() {
		return exportacion;
	}

	public boolean isExonerado() {
		return exonerado;
	}

	public boolean isVentaNetaGravada() {
		return gravada;
	}

	public PkComprobante getPkComprobante() {
		return pkComprobante;
	}

	public void setPkComprobante(PkComprobante pkComprobante) {
		this.pkComprobante = pkComprobante;
	}

	public Contribuyente getEmisor() {
		return emisor;
	}

	public void setEmisor(Contribuyente emisor) {
		this.emisor = emisor;
	}

	public Contribuyente getReceptor() {
		return receptor;
	}

	public void setReceptor(Contribuyente receptor) {
		this.receptor = receptor;
	}

	public BigDecimal getTotalDescuentos() {
		return totalDescuentos;
	}

	public void setTotalDescuentos(BigDecimal totalDescuentos) {
		this.totalDescuentos = totalDescuentos;
	}

	public BigDecimal getTotalISC() {
		return totalISC;
	}

	public void setTotalISC(BigDecimal totalISC) {
		this.totalISC = totalISC;
	}

	public BigDecimal getTotalIGV() {
		return totalIGV;
	}

	public void setTotalIGV(BigDecimal totalIGV) {
		this.totalIGV = totalIGV;
	}

	public BigDecimal getTotalOtrosCargos() {
		return totalOtrosCargos;
	}

	public void setTotalOtrosCargos(BigDecimal totalOtrosCargos) {
		this.totalOtrosCargos = totalOtrosCargos;
	}

	public BigDecimal getTotalOtrosTributos() {
		return totalOtrosTributos;
	}

	public void setTotalOtrosTributos(BigDecimal totalOtrosTributos) {
		this.totalOtrosTributos = totalOtrosTributos;
	}

	public BigDecimal getTotalAnticipos() {
		return totalAnticipos;
	}

	public void setTotalAnticipos(BigDecimal totalAnticipos) {
		this.totalAnticipos = totalAnticipos;
	}

	public BigDecimal getTotalImporte() {
		return totalImporte;
	}

	public void setTotalImporte(BigDecimal totalImporte) {
		this.totalImporte = totalImporte;
	}

	public String getCodMoneda() {
		return codMoneda;
	}

	public void setCodMoneda(String codMoneda) {
		this.codMoneda = codMoneda;
	}

	public String getNombreFichero() {
		return nombreFichero;
	}

	public void setNombreFichero(String nombreFichero) {
		this.nombreFichero = nombreFichero;
	}

	public boolean isGravada() {
		return gravada;
	}

	public void setGravada(boolean gravada) {
		this.gravada = gravada;
	}

	public void setInafecto(boolean inafecto) {
		this.inafecto = inafecto;
	}

	public void setExportacion(boolean exportacion) {
		this.exportacion = exportacion;
	}

	public void setExonerado(boolean exonerado) {
		this.exonerado = exonerado;
	}

	public boolean isTieneExportacion() {
		return tieneExportacion;
	}

	public void setTieneExportacion(boolean tieneExportacion) {
		this.tieneExportacion = tieneExportacion;
	}

	public boolean isTieneVentaNetaGrabada() {
		return tieneVentaNetaGrabada;
	}

	public void setTieneVentaNetaGrabada(boolean tieneVentaNetaGrabada) {
		this.tieneVentaNetaGrabada = tieneVentaNetaGrabada;
	}

	public boolean isTieneVentaNetaNoGrabada() {
		return tieneVentaNetaNoGrabada;
	}

	public void setTieneVentaNetaNoGrabada(boolean tieneVentaNetaNoGrabada) {
		this.tieneVentaNetaNoGrabada = tieneVentaNetaNoGrabada;
	}

	public boolean isTieneVentaNetaExonerada() {
		return tieneVentaNetaExonerada;
	}

	public void setTieneVentaNetaExonerada(boolean tieneVentaNetaExonerada) {
		this.tieneVentaNetaExonerada = tieneVentaNetaExonerada;
	}

	public boolean isTieneISC() {
		return tieneISC;
	}

	public void setTieneISC(boolean tieneISC) {
		this.tieneISC = tieneISC;
	}

	public BigDecimal getVentaNetaGravadas() {
		return ventaNetaGravadas;
	}

	public void setVentaNetaGravadas(BigDecimal ventaNetaGravadas) {
		this.ventaNetaGravadas = ventaNetaGravadas;
	}

	public BigDecimal getVentaNetaNoGravadas() {
		return ventaNetaNoGravadas;
	}

	public void setVentaNetaNoGravadas(BigDecimal ventaNetaNoGravadas) {
		this.ventaNetaNoGravadas = ventaNetaNoGravadas;
	}

	public BigDecimal getVentaNetaExoneradas() {
		return ventaNetaExoneradas;
	}

	public void setVentaNetaExoneradas(BigDecimal ventaNetaExoneradas) {
		this.ventaNetaExoneradas = ventaNetaExoneradas;
	}

	public BigDecimal getTransferenciaGratuita() {
		return transferenciaGratuita;
	}

	public void setTransferenciaGratuita(BigDecimal transferenciaGratuita) {
		this.transferenciaGratuita = transferenciaGratuita;
	}

	public BigDecimal getMontoPercepcion() {
		return montoPercepcion;
	}

	public void setMontoPercepcion(BigDecimal montoPercepcion) {
		this.montoPercepcion = montoPercepcion;
	}

	public List<String> getLstCodLeyenda() {
		return lstCodLeyenda;
	}

	public void setLstCodLeyenda(List<String> lstLeyendas) {
		this.lstCodLeyenda = lstLeyendas;
	}

	public BigDecimal getSubTotalValorVenta() {
		return subTotalValorVenta;
	}

	public void setSubTotalValorVenta(BigDecimal subTotalValorVenta) {
		this.subTotalValorVenta = subTotalValorVenta;
	}

}
