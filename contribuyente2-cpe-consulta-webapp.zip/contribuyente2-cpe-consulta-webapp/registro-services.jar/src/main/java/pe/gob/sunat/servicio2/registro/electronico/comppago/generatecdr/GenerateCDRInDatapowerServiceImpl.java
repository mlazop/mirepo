package pe.gob.sunat.servicio2.registro.electronico.comppago.generatecdr;

import org.springframework.http.converter.json.MappingJackson2HttpMessageConverter;
import org.springframework.web.client.RestTemplate;



public class GenerateCDRInDatapowerServiceImpl implements GenerateCDRService {

	public static final String MPGW_GENERATE_CDR_URL = "http://virtualdp:2073/servicio-util-genCDR/genConstancia";

	RestTemplate template = new RestTemplate();

	public GenerateCDRInDatapowerServiceImpl() {

		template.getMessageConverters().add(
				new MappingJackson2HttpMessageConverter());
	}

	@Override
	public ConstanciaEnvio generate(Envio envio) {

		return genCdrMpgwOK(envio);
	}

	@Override
	public ConstanciaEnvio generate(ErrorDetail error,
			ComprobanteElectronico cpe, String filename, String usuarioEnvio) {

		return genCdrMpgwError(error, cpe, filename, usuarioEnvio);
	}

	private ConstanciaEnvio genCdrMpgwError(ErrorDetail error,
			ComprobanteElectronico cpe, String filename, String usuarioEnvio) {

		ApplicationResponse.Builder builder;

		builder = cdrBuilderFromComprobante(cpe);

		builder.withTicket(error.getNumTicket());

		ApplicationResponse appResponse = builder.buildResponseError(error
				.getErrorCode());

		ConstanciaEnvio constanciaEnvio = template.postForObject(
				MPGW_GENERATE_CDR_URL, new ConstaciaWrapper(filename,
						appResponse), ConstanciaEnvio.class);

		constanciaEnvio.setApplicationResponse(appResponse);

		constanciaEnvio.setCorrelativo(error.getCorrelativo());

		constanciaEnvio.setUsuarioEnvio(usuarioEnvio);

		return constanciaEnvio;
	}

	private ConstanciaEnvio genCdrMpgwOK(Envio envio) {

		ComprobanteElectronico comprobante = envio.getComprobante();

		ApplicationResponse.Builder builder = cdrBuilderFromComprobante(comprobante);

		builder.withTicket(envio.getNumTicket());

		builder.withListaWarnings(envio.getLstWarning());

		String descripcion = "El Comprobante %s, ha sido aceptado";

		builder.withNote(String.format(descripcion,
				comprobante.getIdComprobante()));

		ApplicationResponse appResponse = builder.buildResponseOK();

		ConstanciaEnvio constanciaEnvio = template.postForObject(
				MPGW_GENERATE_CDR_URL, new ConstaciaWrapper(
						envio.getFilename(), appResponse),
				ConstanciaEnvio.class);

		constanciaEnvio.setApplicationResponse(appResponse);

		constanciaEnvio.setCorrelativo(envio.getCorrelativo());

		constanciaEnvio.setUsuarioEnvio(envio.getUsuarioEnvio());

		return constanciaEnvio;
	}

	private ApplicationResponse.Builder cdrBuilderFromComprobante(ComprobanteElectronico comprobante) {

		ApplicationResponse.Builder builder = new ApplicationResponse.Builder();

		builder.withReceiverParty(comprobante.getEmisor().getNumDocIdentidad());

		builder.withReceiverName(comprobante.getEmisor().getRazonSocial());

		builder.withDocumentReference(comprobante.getIdComprobante());

		builder.withIssueDateTime(comprobante.getFechaEmision());

		builder.withCustomerAssignedAccountID(comprobante.getReceptor()
				.getNumDocIdentidad());

		builder.withAdditionalAccountID(comprobante.getReceptor()
				.getCodTipoDoc());

		return builder.withDocumentTypeCode(comprobante
				.getCodigoTipoComprobante());
	}

	public static class ConstaciaWrapper {
		private ApplicationResponse constancia;

		private String filename;

		public ConstaciaWrapper(String filename, ApplicationResponse constancia) {
			this.constancia = constancia;
			this.filename = filename;
		}

		public ApplicationResponse getConstancia() {
			return constancia;
		}

		public void setConstancia(ApplicationResponse constancia) {
			this.constancia = constancia;
		}

		public String getFilename() {
			return filename;
		}

		public void setFilename(String filename) {
			this.filename = filename;
		}
	}

}
