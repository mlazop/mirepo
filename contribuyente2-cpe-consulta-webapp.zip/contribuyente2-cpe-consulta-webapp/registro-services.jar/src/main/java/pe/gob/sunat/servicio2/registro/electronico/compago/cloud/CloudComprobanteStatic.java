package pe.gob.sunat.servicio2.registro.electronico.compago.cloud;

public class CloudComprobanteStatic{
	
	private static CloudComprobanteServiceImpl comprobanteServiceImpl;
	
	public static synchronized  void setComprobanteService (CloudComprobanteServiceImpl comprobanteServiceImpl) {
		CloudComprobanteStatic.comprobanteServiceImpl = comprobanteServiceImpl;
	}
	
	public static synchronized  CloudComprobanteServiceImpl getComprobanteService () {
		return CloudComprobanteStatic.comprobanteServiceImpl;
	}
	
}
