package pe.gob.sunat.servicio2.registro.electronico.comppago.consulta.service;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
//import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.Date;
import java.util.GregorianCalendar;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.zip.ZipEntry;
import java.util.zip.ZipInputStream;
import java.util.zip.ZipOutputStream;
import javax.naming.InitialContext;
import javax.naming.NamingException;
import javax.transaction.HeuristicMixedException;
import javax.transaction.HeuristicRollbackException;
import javax.transaction.NotSupportedException;
import javax.transaction.RollbackException;
import javax.transaction.SystemException;
import javax.transaction.UserTransaction;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import pe.gob.sunat.contribuyente.cpe.facturagem.model.BillStore;
import pe.gob.sunat.framework.spring.util.bean.MensajeBean;
import pe.gob.sunat.framework.spring.util.date.FechaBean;
import pe.gob.sunat.framework.spring.util.exception.ServiceException;
import pe.gob.sunat.servicio2.registro.electronico.compago.cloud.CloudComprobanteStatic;
import pe.gob.sunat.servicio2.registro.electronico.compago.cloud.CloudComprobanteServiceImpl;
import pe.gob.sunat.servicio2.registro.electronico.comppago.factura.bean.ComprobanteUtilBean;
import pe.gob.sunat.servicio2.registro.electronico.comppago.factura.consultar.bean.ConsultarFacturaBean;
import pe.gob.sunat.servicio2.registro.electronico.comppago.factura.model.dao.T2816DAO;
import pe.gob.sunat.servicio2.registro.electronico.comppago.factura.model.dao.T4241DAO;
import pe.gob.sunat.servicio2.registro.electronico.comppago.factura.model.dao.T4243DAO;
import pe.gob.sunat.servicio2.registro.electronico.comppago.factura.model.dao.T4283DAO;
import pe.gob.sunat.servicio2.registro.electronico.comppago.factura.model.dao.T4429DAO;
import pe.gob.sunat.servicio2.registro.electronico.comppago.factura.model.dao.T4534DAO;
import pe.gob.sunat.servicio2.registro.electronico.comppago.factura.model.dao.T4536DAO;
import pe.gob.sunat.servicio2.registro.electronico.comppago.factura.model.dao.T4541DAO;
import pe.gob.sunat.servicio2.registro.electronico.comppago.factura.model.dao.T4703DAO;
import pe.gob.sunat.servicio2.registro.electronico.comppago.factura.model.dao.T4993DAO;
import pe.gob.sunat.servicio2.registro.electronico.comppago.factura.model.domain.T4241Bean;
import pe.gob.sunat.servicio2.registro.electronico.comppago.factura.model.domain.T4243Bean;
import pe.gob.sunat.servicio2.registro.electronico.comppago.factura.model.domain.T4283Bean;
import pe.gob.sunat.servicio2.registro.electronico.comppago.factura.model.domain.T4429Bean;
import pe.gob.sunat.servicio2.registro.electronico.comppago.factura.model.domain.T4534Bean;
import pe.gob.sunat.servicio2.registro.electronico.comppago.factura.model.domain.T4536Bean;
import pe.gob.sunat.servicio2.registro.electronico.comppago.factura.model.domain.T4541Bean;
import pe.gob.sunat.servicio2.registro.electronico.comppago.factura.model.domain.T4993Bean;
import pe.gob.sunat.servicio2.registro.electronico.comppago.guiaremision.controlbienes.bean.T5229Bean;
import pe.gob.sunat.servicio2.registro.electronico.comppago.guiaremision.controlbienes.model.dao.T5229DAO;
import pe.gob.sunat.servicio2.registro.model.dao.DdpDAO;
import pe.gob.sunat.servicio2.registro.model.dao.T01DAO;
import pe.gob.sunat.servicio2.registro.model.dao.T1331DAO;
import pe.gob.sunat.servicio2.registro.model.domain.DdpBean;
import pe.gob.sunat.servicio2.registro.model.domain.T01Bean;
import pe.gob.sunat.servicio2.registro.model.domain.T1331Bean;

/**
 * <p>
 * Title: ConsultaCoprobanteElectronicoServiceImpl
 * </p>
 * <p>
 * Description: Implementaci�n del Servicio de consulta de comprobantes
 * electr�nicos.
 * </p>
 * 
 * @author jchuquitaype
 */
public class ConsultaCPEServiceImpl implements ConsultaCPEService {

	private static final String FACTURA_GEM = "01";
	private static final String BOLETA_VENTA_GEM = "03";
	private static final String NOTA_CREDITO_GEM = "07";
	private static final String NOTA_DEBITO_GEM = "08";
	// PAS20211U210700133
	private static final Integer IND_RUBRO_CLOUD_GUID = 32001;

	protected final static Log log = LogFactory.getLog(ConsultaCPEServiceImpl.class);

	private DdpDAO daoDdp;
	private T01DAO daoT01;
	private T4241DAO daoT4241;
	private T4243DAO daoT4243;
	private T4243DAO daoT4243Ibatis;
	private T4243DAO t4243DAOSpring;
	private T4429DAO daoT4429;
	private T4541DAO daoT4541;
	private T4703DAO t4703DAO;
	private T1331DAO daoT1331;
	private T4993DAO daoT4993;
	private T4283DAO daoT4283;
	private T5229DAO daoT5229;
	private pe.gob.sunat.servicio2.registro.electronico.comppago.factura.service.ProcesaArchivoComprobanteService archivoService;
	private pe.gob.sunat.servicio2.registro.electronico.comppago.boleta.service.ProcesaArchivoComprobanteService archivoServiceBVE;
	private T2816DAO daoT2816;

	private T4534DAO t4534DAO;

	/*
	 * PAS20171U210300083 peticion al cpehist
	 */
	private T4536DAO daoT4536Hist; // historico
	private T4536DAO daoT4536; // cpe
	private T01DAO t01DAO; // PAS20191U210300059

	public T01DAO getT01DAO() {
		return t01DAO;
	}

	public void setT01DAO(T01DAO t01dao) {
		t01DAO = t01dao;
	}

	public T4536DAO getDaoT4536Hist() {
		return daoT4536Hist;
	}

	public void setDaoT4536Hist(T4536DAO daoT4536Hist) {
		this.daoT4536Hist = daoT4536Hist;
	}

	public T4536DAO getDaoT4536() {
		return daoT4536;
	}

	public void setDaoT4536(T4536DAO daoT4536) {
		this.daoT4536 = daoT4536;
	}

	public T4243DAO getDaoT4243Ibatis() {
		return daoT4243Ibatis;
	}

	public void setDaoT4243Ibatis(T4243DAO daoT4243Ibatis) {
		this.daoT4243Ibatis = daoT4243Ibatis;
	}

	public T2816DAO getDaoT2816() {
		return daoT2816;
	}

	public void setDaoT2816(T2816DAO daoT2816) {
		this.daoT2816 = daoT2816;
	}

	public T4283DAO getDaoT4283() {
		return daoT4283;
	}

	public void setDaoT4283(T4283DAO daoT4283) {
		this.daoT4283 = daoT4283;
	}

	public T5229DAO getDaoT5229() {
		return daoT5229;
	}

	public void setDaoT5229(T5229DAO daoT5229) {
		this.daoT5229 = daoT5229;
	}

	public T4534DAO getT4534DAO() {
		return t4534DAO;
	}

	public void setT4534DAO(T4534DAO t4534dao) {
		t4534DAO = t4534dao;
	}

	public T4243DAO getT4243DAOSpring() {
		return t4243DAOSpring;
	}

	public void setT4243DAOSpring(T4243DAO t4243daoSpring) {
		t4243DAOSpring = t4243daoSpring;
	}

	private T4241Bean t4541BeanTOT4241Bean(T4541Bean t4541Bean) {
		T4241Bean t4241Bean = new T4241Bean();
		t4241Bean.setNum_ruc(t4541Bean.getNum_ruc());
		t4241Bean.setNum_serie_cpe(t4541Bean.getNum_serie_cpe());
		t4241Bean.setNum_cpe(t4541Bean.getNum_cpe());
		// La t4541anulados no tiene los siguientes datos, poner null
		t4241Bean.setCod_docide_recep(null);
		t4241Bean.setNum_docide_recep(null);
		t4241Bean.setCod_moneda(null);
		t4241Bean.setNum_id_xml(null);
		t4241Bean.setMto_importe_total(null);
		// Desde t4241 0 = activo, 2 = baja , y desde t5441 3 = anulado, 1 =
		// rechazado,
		t4241Bean.setInd_estado(t4541Bean.getInd_estado_cpe().equals("0") ? "3" : t4541Bean.getInd_estado_cpe());
		t4241Bean.setFec_emision(t4541Bean.getFec_emision());
		// Vendria a ser la fecha de anulacion o de rechazo, segun el estado.
		t4241Bean.setFechaEstado(t4541Bean.getFec_registro_doc());

		return t4241Bean;
	}

	@Override
	/**
	 * Ejecuta la consulta de busqueda.
	 * 
	 * @param params:
	 *            <ul>
	 *            <li>nroRUC
	 *            <li>tipoConsulta
	 *            <li>buscarPor : porDoc, porFch, porPer
	 *            <li>rucEmisor
	 *            <li>serie
	 *            <li>numero
	 *            <li>fchDesde
	 *            <li>fchHasta
	 *            <ul>
	 * @return
	 */
	public List<ConsultarFacturaBean> ejecutarConsulta(Map<String, String> params) throws Exception {
		if (log.isDebugEnabled()) {
			log.debug(">> ejecutarConsulta :: " + params);
		}

		List<ConsultarFacturaBean> response = new ArrayList<ConsultarFacturaBean>();
		try {
			String nroRUC = params.get("numRUC");
			String tipoConsulta = params.get("tipoConsulta");
			String buscarPor = null == params.get("buscarPor") ? "porDoc" : params.get("buscarPor");

			List<T4241Bean> result = new ArrayList<T4241Bean>();
			String xtipo = "10";
			int iTipo = Integer.parseInt(tipoConsulta);

			if ("porDoc".equals(buscarPor)) {
				if (log.isInfoEnabled())
					log.info(">> ejecutarConsulta :: Busqueda porDoc.");

				String numSerie = params.get("serie") != null ? params.get("serie").toString() : "";
				Integer numero = params.get("numero") != null ? Integer.parseInt(params.get("numero")) : 0;

				// LRUIZI 25/04/2007
				String fecDesde = params.get("fecDesde") != null ? params.get("fecDesde").toString() : "";
				String fecHasta = params.get("fecHasta") != null ? params.get("fecHasta").toString() : "";

				params.put("fecDesde", "");
				params.put("fecHasta", "");

				if (!"".equals(fecDesde) && !"".equals(fecHasta)) {

					FechaBean fechaIni = ComprobanteUtilBean.getFecha(fecDesde, "dd/MM/yyyy", "yyyy/MM/dd");
					FechaBean fechaFin = ComprobanteUtilBean.getFecha(fecHasta, "dd/MM/yyyy", "yyyy/MM/dd");
					fechaFin.getCalendar().add(GregorianCalendar.DATE, 1);

					log.debug("fechaIni sql2:" + fechaIni.getSQLDate());
					log.debug("fechaFin sql2:" + fechaFin.getSQLDate());

					params.put("fecDesde", fechaIni.getSQLDate().toString());
					params.put("fecHasta", fechaFin.getSQLDate().toString());

				}

				// FIN LRUIZI 25/04/2007

				String numDocideRecep = params.get("numDocideRecep") != null ? params.get("numDocideRecep").toString()
						: "";
				params.put("numDocideRecep", numDocideRecep);

				if (log.isInfoEnabled())
					log.info(">> ejecutarConsulta :: Busqueda  numSerie=" + numSerie + ", numero=" + numero + ", tipo="
							+ iTipo);

				if (log.isDebugEnabled()) {
					log.debug(">> ejecutarConsulta paramsfinal:: " + params);
				}

				if (iTipo == 10) {
					/** Facturas emitidas */
					/*
					 * Busca en facturas activas (ind_estado = 0 ) o baja
					 * (ind_estado = 2)
					 */
					result = daoT4241.buscarFacturaEmitida(params);
					/*
					 * Busca en facturas rechazadas (ind_estado = 1) o anuladas
					 * (ind_estado = 0 )
					 */
					if (result == null || result.isEmpty()) {
						T4541Bean t4541Bean = daoT4541.findByPK(nroRUC, numSerie, FACTURA_GEM, numero);
						result = new ArrayList<T4241Bean>();
						if (null != t4541Bean)
							result.add(t4541BeanTOT4241Bean(t4541Bean));
					}
					xtipo = "10";
				} else if (iTipo == 11) {
					/** Facturas recibidas */
					result = daoT4241.buscarFacturaRecibida(params);
					xtipo = "10";
				} else if (iTipo == 13) {
					/** NC emitida */
					params.put("codCpe", NOTA_CREDITO_GEM);
					result = daoT4241.buscarNCNDEmitida(params);
					if (result == null || result.isEmpty()) {
						T4541Bean t4541Bean = daoT4541.findByPK(nroRUC, numSerie, NOTA_CREDITO_GEM, numero);
						result = new ArrayList<T4241Bean>();
						if (null != t4541Bean)
							result.add(t4541BeanTOT4241Bean(t4541Bean));
					}
					xtipo = "13";
				} else if (iTipo == 14) {
					/** NC recibida */
					params.put("codCpe", NOTA_CREDITO_GEM);
					xtipo = "13";
					result = daoT4241.buscarNCNDRecibida(params);
				} else if (iTipo == 15) {
					/** ND emitida */
					params.put("codCpe", NOTA_DEBITO_GEM);
					result = daoT4241.buscarNCNDEmitida(params);
					if (result == null || result.isEmpty()) {
						T4541Bean t4541Bean = daoT4541.findByPK(nroRUC, numSerie, NOTA_DEBITO_GEM, numero);
						result = new ArrayList<T4241Bean>();
						if (null != t4541Bean)
							result.add(t4541BeanTOT4241Bean(t4541Bean));
					}
					xtipo = "15";
				} else if (iTipo == 16) {
					/** ND recibida */
					params.put("codCpe", NOTA_DEBITO_GEM);
					result = daoT4241.buscarNCNDRecibida(params);
					xtipo = "15";
				} else if (iTipo == 17) {
					/** Boleta de Venta emitidas */
					/*
					 * Busca en Boleta de Venta activas (ind_estado = 0 ) o baja
					 * (ind_estado = 2)
					 */
					// result = daoT4241.buscarBoletaEmitida(params);
					params.put("codCpe", BOLETA_VENTA_GEM);
					result = daoT4241.buscarCPEEmitidoOSE(params);

					/*
					 * Busca en Boleta de Venta rechazadas (ind_estado = 1) o
					 * anuladas (ind_estado = 0 )
					 */
					if (result == null || result.isEmpty()) {
						T4541Bean t4541Bean = daoT4541.findByPK(nroRUC, numSerie, BOLETA_VENTA_GEM, numero);
						result = new ArrayList<T4241Bean>();
						if (null != t4541Bean)
							result.add(t4541BeanTOT4241Bean(t4541Bean));
					}
					xtipo = "17";
				} else if (iTipo == 18) {
					/** Facturas recibidas */
					result = daoT4241.buscarBoletaRecibida(params);
					xtipo = "17";
				} else if (iTipo == 20) {
					/** NC-BVE emitida */
					params.put("codCpe", NOTA_CREDITO_GEM);
					// result = daoT4241.buscarNCNDEmitida(params);
					result = daoT4241.buscarCPEEmitidoOSE(params);
					if (result == null || result.isEmpty()) {
						T4541Bean t4541Bean = daoT4541.findByPK(nroRUC, numSerie, NOTA_CREDITO_GEM, numero);
						result = new ArrayList<T4241Bean>();
						if (null != t4541Bean)
							result.add(t4541BeanTOT4241Bean(t4541Bean));
					}
					xtipo = "20";
				} else if (iTipo == 21) {
					/** NC-BVE recibida */
					params.put("codCpe", NOTA_CREDITO_GEM);
					xtipo = "20";
					result = daoT4241.buscarNCNDRecibida(params);
				} else if (iTipo == 22) {
					/** ND-BVE emitida */
					params.put("codCpe", NOTA_DEBITO_GEM);
					result = daoT4241.buscarCPEEmitidoOSE(params);
					// result = daoT4241.buscarNCNDEmitida(params);
					if (result == null || result.isEmpty()) {
						T4541Bean t4541Bean = daoT4541.findByPK(nroRUC, numSerie, NOTA_DEBITO_GEM, numero);
						result = new ArrayList<T4241Bean>();
						if (null != t4541Bean)
							result.add(t4541BeanTOT4241Bean(t4541Bean));
					}
					xtipo = "22";
				} else if (iTipo == 23) {
					/** ND-BVE recibida */
					params.put("codCpe", NOTA_DEBITO_GEM);
					result = daoT4241.buscarNCNDRecibida(params);
					xtipo = "22";
				}
			} else if ("porPer".equals(buscarPor)) {
				if (log.isInfoEnabled())
					log.info(">> ejecutarConsulta :: Busqueda porPer.");
				FechaBean fechaIni = ComprobanteUtilBean.getFechaInicial(params.get("periodo"));
				FechaBean fechaFin = ComprobanteUtilBean.getFechaFinal(params.get("periodo"));

				switch (iTipo) {
				case 10: // facturas Emitidas
					result = daoT4241.findByNroRUCEmitidas(nroRUC, fechaIni, fechaFin, FACTURA_GEM);
					break;
				case 11: // facturas Recibidas
					result = daoT4241.findByNroRUCRecibidas(nroRUC, fechaIni, fechaFin, FACTURA_GEM);
					break;
				case 12: // facturas Rechazadas
					result = daoT4241.findByNroRUCRechazadas(nroRUC, fechaIni, fechaFin, FACTURA_GEM);
					break;
				case 13: // NC Emitidas
					xtipo = "13";
					result = daoT4241.findByNroRUCNCNDEmitidas(nroRUC, fechaIni, fechaFin, NOTA_CREDITO_GEM);
					break;
				case 14: // NC recibidas
					xtipo = "13";
					result = daoT4241.findByNroRUCNCNDRecibidas(nroRUC, fechaIni, fechaFin, NOTA_CREDITO_GEM);
					break;
				case 15: // ND Emitidas
					xtipo = "15";
					result = daoT4241.findByNroRUCNCNDEmitidas(nroRUC, fechaIni, fechaFin, NOTA_DEBITO_GEM);
					break;
				case 16: // ND Recibidas
					xtipo = "15";
					result = daoT4241.findByNroRUCNCNDRecibidas(nroRUC, fechaIni, fechaFin, NOTA_DEBITO_GEM);
					break;
				case 17: // ND Recibidas
					xtipo = "17";
					result = daoT4241.findByNroRUCBVEEmitidas(nroRUC, fechaIni, fechaFin, BOLETA_VENTA_GEM);
					break;
				case 18: // ND Recibidas
					xtipo = "17";
					result = daoT4241.findByNroRUCBVERecibidas(nroRUC, fechaIni, fechaFin, BOLETA_VENTA_GEM);
					break;
				case 20: // NC Emitidas
					xtipo = "20";
					result = daoT4241.findByNroRUCNCNDBVEEmitidas(nroRUC, fechaIni, fechaFin, NOTA_CREDITO_GEM);
					break;
				case 21: // NC recibidas
					xtipo = "20";
					result = daoT4241.findByNroRUCNCNDBVERecibidas(nroRUC, fechaIni, fechaFin, NOTA_CREDITO_GEM);
					break;
				case 22: // ND Emitidas
					xtipo = "22";
					result = daoT4241.findByNroRUCNCNDBVEEmitidas(nroRUC, fechaIni, fechaFin, NOTA_DEBITO_GEM);
					break;
				case 23: // ND Recibidas
					xtipo = "22";
					result = daoT4241.findByNroRUCNCNDBVERecibidas(nroRUC, fechaIni, fechaFin, NOTA_DEBITO_GEM);
					break;
				}
			}
			// Formatear resultado de la consulta
			if (result != null) {
				response = this.formatResponse(result, xtipo);
			}
		} catch (Exception e) {
			log.error(e, e);
			throw new ServiceException(this,
					"Ocurrio un error al buscar el comprobante electr�nico.\n" + e.getMessage());
		}

		return response;
	}

	@Override
	public void validarFiltro(Map<String, String> map) {
		if (log.isDebugEnabled()) {
			log.debug("validarFiltro( " + map + " )");
		}

		// Valida periodo
		this.validarPeriodo(map);

		// Valida el nro de ruc
		this.validarRUC(map);
	}

	@Override
	public DdpBean verificarRUC(String nroRUC) {
		if (log.isDebugEnabled()) {
			log.debug("verificarRUC( " + nroRUC + " )");
		}

		// MensajeBean msg = new MensajeBean();
		DdpBean beanDdp = daoDdp.findByNroRUC(nroRUC.trim());
		log.debug("DdpBean: " + beanDdp);

		return beanDdp;

	}

	@Override
	public pe.gob.sunat.servicio2.registro.electronico.comppago.factura.bean.ArchivoComprobanteBean descargarFactura(
			Map<String, String> params) throws IOException {
		if (log.isDebugEnabled()) {
			log.debug("descargarFactura( " + params + " )");
		}
		/**
		 * Modificacion agregada por NAA el 2010-12-09 para que pueda
		 * consultarse NC y ND aparte de la factura
		 */
		boolean isGem = params.get("isGEM") != null ? true : false;
		// T4243Bean bean =
		// daoT4243.findFileXmlJoinTCabCPETArcXmlByPrimaryKey(params.get("ruc"),
		// "01", params.get("serie"), new Integer(params.get("numero")));

		String xtipo = FACTURA_GEM;
		if (params.get("tipo").toString().trim().equals("13")) {
			xtipo = NOTA_CREDITO_GEM;
		}
		if (params.get("tipo").toString().trim().equals("15")) {
			xtipo = NOTA_DEBITO_GEM;
		}
		/*
		 * PAS20171U210300083 buscar en historico
		 */
		String p_num_ruc = params.get("ruc");
		String p_num_serie_cpe = params.get("serie");
		Integer p_num_cpe = new Integer(params.get("numero"));

		byte[] xmlCloud = null;
		T4243Bean bean = null;

		if (isGem) {
			T4536Bean t4536bean = daoT4243.findFileZipJoinTCabCPETRelcompelecByPrimaryKey(p_num_ruc, xtipo,
					p_num_serie_cpe, p_num_cpe);

			if (t4536bean != null) {

				// buscar en cpe
				T4536Bean t4536Festore = daoT4536.findFileZipTFESTOREByPrimaryKey(t4536bean);

				if (t4536Festore != null) {
					bean = new T4243Bean();
					if (log.isDebugEnabled())
						log.debug("t4536Festore : " + t4536Festore.getContenido());
					bean.setArc_zip(t4536Festore.getContenido());
					bean.setDes_nombre(daoT4536.findNombre(t4536bean.getTicket()));
				} else {
					/*
					 * PAS20171U210300083 buscar en hist�rico
					 */
					T4536Bean t4536storeHistorico = daoT4536Hist.findFileZipTFESTOREByPrimaryKey(t4536bean);

					if (t4536storeHistorico != null) {
						bean = new T4243Bean();
						if (log.isDebugEnabled())
							log.debug("t4536storeHistorico : " + t4536storeHistorico.getContenido());
						bean.setArc_zip(t4536storeHistorico.getContenido());
						bean.setDes_nombre(daoT4536Hist.findNombre(t4536bean.getTicket()));

					} else {
						if (log.isDebugEnabled())
							log.debug("Consultando cloud - get xml");

						T4283Bean buscarT4283 = new T4283Bean();
						buscarT4283.setNum_ruc(p_num_ruc);
						buscarT4283.setCod_cpe(xtipo);
						buscarT4283.setNum_serie_cpe(p_num_serie_cpe);
						buscarT4283.setNum_cpe(p_num_cpe);
						buscarT4283.setCod_rubro(IND_RUBRO_CLOUD_GUID);

						T4283Bean rubro = daoT4283.findRubroCabecera_ByRUC_codCPE_Serie_CPE_Rubro(buscarT4283);
						String guid = "";
						if (rubro != null) {
							guid = rubro.getDes_detalle_rubro();
						}

						try {
							log.debug("llamada cloud version 2.0");
							xmlCloud = this.procesarComprobanteNubev2_0(guid);
							log.debug("Obtuvo XML");

							if (xmlCloud.length > 0) {
								String nombreZip = p_num_ruc+"-"+xtipo+"-"+p_num_serie_cpe+"-"+p_num_cpe+".xml";
								bean = new T4243Bean();
								bean.setArc_zip(xmlCloud);
								//log.debug("zipeando===" + nombreZip);
								//bean.setArc_zip(zipBytes( nombreZip, xmlCloud ));
								log.debug("inicia procedimiento T4534Bean");
								T4534Bean T4534Bean = t4534DAO.findByPK(p_num_ruc, p_num_serie_cpe, xtipo, p_num_cpe);
								log.debug("T4534Bean.toString()==" + T4534Bean.toString());
								log.debug("inicia procedimiento BillStore");
								
								BillStore BillStore_ = new BillStore();
								BillStore_.setTicket(T4534Bean.getNum_ticket());
								BillStore_.setModo("1");
								BillStore_.setContenido(xmlCloud);
								BillStore_.setCorrelativo(T4534Bean.getNum_correl_ticket());
								BillStore_.setUsuarioModificador(T4534Bean.getCod_usumodif());
								log.debug("BillStore_.toString()==" + BillStore_.toString());

								log.debug("registrando en t4243DAOSpring.insert_ticket_CPE");
								t4243DAOSpring.insert_ticket_CPE(BillStore_);
								log.debug("Fin registrando en t4243DAOSpring.insert_ticket_CPE");
							}

						} catch (Exception e1) {
							log.debug("Exception===" + e1.getMessage());
							e1.fillInStackTrace();
							throw new ServiceException(this, "El documento con n�mero de serie " + p_num_serie_cpe + "-"
									+ p_num_cpe + " no ha sido informado a SUNAT.");
						}
					}
				}
				// PAS20191U210100231
			} else {

				T4283Bean buscarT4283 = new T4283Bean();
				buscarT4283.setNum_ruc(p_num_ruc);
				buscarT4283.setCod_cpe(xtipo);
				buscarT4283.setNum_serie_cpe(p_num_serie_cpe);
				buscarT4283.setNum_cpe(p_num_cpe);
				buscarT4283.setCod_rubro(IND_RUBRO_CLOUD_GUID);

				T4283Bean rubro = daoT4283.findRubroCabecera_ByRUC_codCPE_Serie_CPE_Rubro(buscarT4283);
				String guid = "";
				if (rubro != null) {
					guid = rubro.getDes_detalle_rubro();
				}

				try {
					xmlCloud = this.procesarComprobanteNubev2_0(guid);

					if (xmlCloud.length > 0) {
						bean = new T4243Bean();
						log.debug("t4536bean==null==");
						// bean.setArc_zip( zipBytes( "ArchivoZip", xmlCloud) );
						String nombreZip = p_num_ruc+"-"+xtipo+"-"+p_num_serie_cpe+"-"+p_num_cpe+".xml";
						
						bean.setArc_zip(xmlCloud);
						
						log.debug("inicia procedimiento T4534Bean");
						T4534Bean T4534Bean = t4534DAO.findByPK(p_num_ruc, p_num_serie_cpe, xtipo, p_num_cpe);
						log.debug("T4534Bean.toString()==" + T4534Bean.toString());
						log.debug("inicia procedimiento BillStore");

						BillStore BillStore_ = new BillStore();
						BillStore_.setTicket(T4534Bean.getNum_ticket());
						BillStore_.setModo("1");
						BillStore_.setContenido(xmlCloud);
						BillStore_.setCorrelativo(T4534Bean.getNum_correl_ticket());
						BillStore_.setUsuarioModificador(T4534Bean.getCod_usumodif());
						log.debug("BillStore_.toString()==" + BillStore_.toString());

						log.debug("registrando en t4243DAOSpring.insert_ticket_CPE");
						t4243DAOSpring.insert_ticket_CPE(BillStore_);
						log.debug("Fin registrando en t4243DAOSpring.insert_ticket_CPE");
					}
				} catch (Exception e) {
					e.printStackTrace();
				}
			}

		} else {
			bean = daoT4243Ibatis.findFileXmlJoinTCabCPETArcXmlByPrimaryKeyISO88591(p_num_ruc, xtipo, p_num_serie_cpe,
					p_num_cpe);
		}

		if (bean != null) {
			log.debug("Mostrar XML ===");
			pe.gob.sunat.servicio2.registro.electronico.comppago.factura.bean.ArchivoComprobanteBean beanFile = new pe.gob.sunat.servicio2.registro.electronico.comppago.factura.bean.ArchivoComprobanteBean();
			beanFile.setNumeroRuc(params.get("ruc"));
			beanFile.setTipoComprobante(params.get("tipo"));
			beanFile.setSerieComprobante(params.get("serie"));
			beanFile.setNumeroComprobante(new Integer(params.get("numero")));
			if (isGem) {
				beanFile.setContenidoArchivoXml(new String(decompress(bean.getArc_zip()))); // PAS20171U210300083
																							// tildes
				log.debug(beanFile.getContenidoArchivoXml());
			} else {
				beanFile.setContenidoArchivoXml(bean.getArc_xml());
			}

			if (params.get("adjuntaVisor") != null)
				beanFile.setAdjuntaVisor(Boolean.parseBoolean(params.get("adjuntaVisor")));

			// ComprobanteUtilBean.FACTURA
			if (xtipo.equals(FACTURA_GEM)) {
				beanFile.setTipoComprobante(ComprobanteUtilBean.FACTURA);
			}
			if (xtipo.equals(NOTA_CREDITO_GEM)) {
				beanFile.setTipoComprobante(ComprobanteUtilBean.NOTA_CREDITO);
			}
			if (xtipo.equals(NOTA_DEBITO_GEM)) {
				beanFile.setTipoComprobante(ComprobanteUtilBean.NOTA_DEBITO);
			}

			log.debug("procesando metodos en la descarga");
			beanFile.setArchivoXml(archivoService.generarArchivoXML(beanFile));
			log.debug("termino generarArchivoXML");
			beanFile.setArchivoZip(archivoService.generarArchivoZip(beanFile));
			log.debug("termino generarArchivoZip");
			beanFile.setContenidoArchivoZip(archivoService.getContenidoArchivoBin(beanFile.getArchivoZip()));
			log.debug("termino getContenidoArchivoBin");

			return beanFile;
		} else {
			MensajeBean msg = new MensajeBean();
			msg.setError(false);
			msg.setMensajeerror("No existe factura a descargar.");
			throw new ServiceException(this, msg);
		}
	}

	@Override
	public pe.gob.sunat.servicio2.registro.electronico.comppago.boleta.bean.ArchivoComprobanteBean descargarBoleta(
			Map<String, String> params) throws IOException {
		if (log.isDebugEnabled()) {
			log.debug("descargarBoleta( " + params + " )");
		}

		boolean isGem = params.get("isGEM") != null ? true : false;

		String xtipo = BOLETA_VENTA_GEM;
		if (params.get("tipo").toString().trim().equals("20")) {
			xtipo = NOTA_CREDITO_GEM;
		}
		if (params.get("tipo").toString().trim().equals("22")) {
			xtipo = NOTA_DEBITO_GEM;
		}

		String p_num_ruc = params.get("ruc");
		String p_num_serie_cpe = params.get("serie");
		Integer p_num_cpe = new Integer(params.get("numero"));

		byte[] xmlCloud = null;

		T4243Bean bean = null;

		if (isGem) {
			T4536Bean t4536bean = daoT4243.findFileZipJoinTCabCPETRelcompelecByPrimaryKey(p_num_ruc, xtipo,
					p_num_serie_cpe, p_num_cpe);

			if (t4536bean != null) {

				// buscar en cpe
				T4536Bean t4536Festore = daoT4536.findFileZipTFESTOREByPrimaryKey(t4536bean);

				if (t4536Festore != null) {
					bean = new T4243Bean();
					bean.setArc_zip(t4536Festore.getContenido());
					bean.setDes_nombre(daoT4536.findNombre(t4536bean.getTicket()));
				} else {
					// PAS20171U210300083 buscar en hist�rico
					T4536Bean t4536storeHistorico = daoT4536Hist.findFileZipTFESTOREByPrimaryKey(t4536bean);

					if (t4536storeHistorico != null) {
						bean = new T4243Bean();
						bean.setArc_zip(t4536storeHistorico.getContenido());
						bean.setDes_nombre(daoT4536Hist.findNombre(t4536bean.getTicket()));
					} else {
						if (log.isDebugEnabled())
							log.debug("Consultando cloud - get xml");

						T4283Bean buscarT4283 = new T4283Bean();
						buscarT4283.setNum_ruc(p_num_ruc);
						buscarT4283.setCod_cpe(xtipo);
						buscarT4283.setNum_serie_cpe(p_num_serie_cpe);
						buscarT4283.setNum_cpe(p_num_cpe);
						buscarT4283.setCod_rubro(IND_RUBRO_CLOUD_GUID);

						T4283Bean rubro = daoT4283.findRubroCabecera_ByRUC_codCPE_Serie_CPE_Rubro(buscarT4283);
						String guid = "";
						if (rubro != null) {
							guid = rubro.getDes_detalle_rubro();
						}

						try {
							xmlCloud = this.procesarComprobanteNubev2_0(guid);
							if (xmlCloud.length > 0) {
								bean = new T4243Bean();
								// bean.setArc_xml(xmlCloud);
								log.debug("t4536storeHistorico==null");
								String nombreZip = p_num_ruc + "-" + xtipo + "-" + p_num_serie_cpe + "-" + p_num_cpe
										+ ".xml";
								// bean.setArc_zip(zipBytes( nombreZip, bytes
								// ));
								bean.setArc_zip(xmlCloud);
								
								log.debug("inicia procedimiento T4534Bean");
								T4534Bean T4534Bean = t4534DAO.findByPK(p_num_ruc, p_num_serie_cpe, xtipo, p_num_cpe);
								log.debug("T4534Bean.toString()==" + T4534Bean.toString());
								log.debug("inicia procedimiento BillStore");

								BillStore BillStore_ = new BillStore();
								BillStore_.setTicket(T4534Bean.getNum_ticket());
								BillStore_.setModo("1");
								BillStore_.setContenido(xmlCloud);
								BillStore_.setCorrelativo(T4534Bean.getNum_correl_ticket());
								BillStore_.setUsuarioModificador(T4534Bean.getCod_usumodif());
								log.debug("BillStore_.toString()==" + BillStore_.toString());

								log.debug("registrando en t4243DAOSpring.insert_ticket_CPE");
								t4243DAOSpring.insert_ticket_CPE(BillStore_);
								log.debug("Fin registrando en t4243DAOSpring.insert_ticket_CPE");
							}
						} catch (Exception e1) {
							throw new ServiceException(this, "El documento con n�mero de serie " + p_num_serie_cpe + "-"
									+ p_num_cpe + " no ha sido informado a SUNAT.");
						}
					}
				}
				// PAS20191U210100231
			} else {
				T4283Bean buscarT4283 = new T4283Bean();
				buscarT4283.setNum_ruc(p_num_ruc);
				buscarT4283.setCod_cpe(xtipo);
				buscarT4283.setNum_serie_cpe(p_num_serie_cpe);
				buscarT4283.setNum_cpe(p_num_cpe);
				buscarT4283.setCod_rubro(IND_RUBRO_CLOUD_GUID);

				T4283Bean rubro = daoT4283.findRubroCabecera_ByRUC_codCPE_Serie_CPE_Rubro(buscarT4283);
				String guid = "";
				if (rubro != null) {
					guid = rubro.getDes_detalle_rubro();
				}

				try {
					xmlCloud = this.procesarComprobanteNubev2_0(guid);
					if (xmlCloud.length > 0) {

						log.debug("t4536bean==null");
						bean = new T4243Bean();
						// bean.setArc_zip( zipBytes( "ArchivoZip", xmlCloud )
						// );
						bean.setArc_zip(xmlCloud);
						
						log.debug("inicia procedimiento T4534Bean");
						T4534Bean T4534Bean = t4534DAO.findByPK(p_num_ruc, p_num_serie_cpe, xtipo, p_num_cpe);
						log.debug("T4534Bean.toString()==" + T4534Bean.toString());
						log.debug("inicia procedimiento BillStore");

						BillStore BillStore_ = new BillStore();
						BillStore_.setTicket(T4534Bean.getNum_ticket());
						BillStore_.setModo("1");
						BillStore_.setContenido(xmlCloud);
						BillStore_.setCorrelativo(T4534Bean.getNum_correl_ticket());
						BillStore_.setUsuarioModificador(T4534Bean.getCod_usumodif());
						log.debug("BillStore_.toString()==" + BillStore_.toString());

						log.debug("registrando en t4243DAOSpring.insert_ticket_CPE");
						t4243DAOSpring.insert_ticket_CPE(BillStore_);
						log.debug("Fin registrando en t4243DAOSpring.insert_ticket_CPE");
					}
				} catch (Exception e) {
					e.printStackTrace();
				}
			}

		} else {
			bean = daoT4243Ibatis.findFileXmlJoinTCabCPETArcXmlByPrimaryKeyISO88591(p_num_ruc, xtipo, p_num_serie_cpe,
					p_num_cpe);
		}

		if (bean != null) {
			pe.gob.sunat.servicio2.registro.electronico.comppago.boleta.bean.ArchivoComprobanteBean beanFile = new pe.gob.sunat.servicio2.registro.electronico.comppago.boleta.bean.ArchivoComprobanteBean();
			beanFile.setNumeroRuc(params.get("ruc"));
			beanFile.setTipoComprobante(params.get("tipo"));
			beanFile.setSerieComprobante(params.get("serie"));
			beanFile.setNumeroComprobante(new Integer(params.get("numero")));
			if (isGem) {
				beanFile.setContenidoArchivoXml(new String(decompress(bean.getArc_zip())));
			} else {
				beanFile.setContenidoArchivoXml(bean.getArc_xml());
			}

			if (params.get("adjuntaVisor") != null)
				beanFile.setAdjuntaVisor(Boolean.parseBoolean(params.get("adjuntaVisor")));

			if (xtipo.equals(BOLETA_VENTA_GEM)) {
				beanFile.setTipoComprobante(ComprobanteUtilBean.BOLETA);
			}
			if (xtipo.equals(NOTA_CREDITO_GEM)) {
				beanFile.setTipoComprobante(ComprobanteUtilBean.NOTA_CREDITO);
			}
			if (xtipo.equals(NOTA_DEBITO_GEM)) {
				beanFile.setTipoComprobante(ComprobanteUtilBean.NOTA_DEBITO);
			}

			beanFile.setArchivoXml(archivoServiceBVE.generarArchivoXML(beanFile));
			beanFile.setArchivoZip(archivoServiceBVE.generarArchivoZip(beanFile));
			beanFile.setContenidoArchivoZip(archivoServiceBVE.getContenidoArchivoBin(beanFile.getArchivoZip()));

			return beanFile;
		} else {
			MensajeBean msg = new MensajeBean();
			msg.setError(false);
			msg.setMensajeerror("No existe factura a descargar.");
			throw new ServiceException(this, msg);
		}
	}

	@Override
	public pe.gob.sunat.servicio2.registro.electronico.comppago.factura.bean.ComprobanteBean recuperarInfoFactura(
			Map<String, String> params) throws IOException {

		if (log.isDebugEnabled()) {
			log.debug("recuperarInfoFactura( " + params + " )");
		}

		pe.gob.sunat.servicio2.registro.electronico.comppago.factura.bean.ComprobanteBean comprobante = null;

		boolean isGem = params.get("isGEM") != null ? true : false;
		String xtipo = FACTURA_GEM;// factura
		String p_tipo = "01";

		if ((params.get("tipo").toString().trim().equals("13"))
				|| (params.get("tipo").toString().trim().equals("14"))) {
			xtipo = NOTA_CREDITO_GEM;
			p_tipo = "07";
		}
		if ((params.get("tipo").toString().trim().equals("15"))
				|| (params.get("tipo").toString().trim().equals("16"))) {
			xtipo = NOTA_DEBITO_GEM;
			p_tipo = "08";
		}

		String p_num_ruc = params.get("ruc");
		String p_num_serie_cpe = params.get("serie");
		Integer p_num_cpe = new Integer(params.get("numero"));

		T4243Bean bean = null;
		byte[] xmlCloud = null;

		if (isGem) {
			// xml gem
			T4536Bean t4536bean = daoT4243.findFileZipJoinTCabCPETRelcompelecByPrimaryKey(p_num_ruc, xtipo,
					p_num_serie_cpe, p_num_cpe);

			if (t4536bean != null) {

				// buscar en cpe
				T4536Bean t4536Festore = daoT4536.findFileZipTFESTOREByPrimaryKey(t4536bean);

				if (t4536Festore != null) {
					bean = new T4243Bean();
					if (log.isDebugEnabled())
						log.debug("t4536Festore.getContenido() : " + t4536Festore.getContenido());

					bean.setArc_zip(t4536Festore.getContenido());
					bean.setDes_nombre(daoT4536.findNombre(t4536bean.getTicket()));

				} else {
					// PAS20171U210300083 buscar en hist�rico
					T4536Bean t4536storeHistorico = daoT4536Hist.findFileZipTFESTOREByPrimaryKey(t4536bean);

					if (t4536storeHistorico != null) {
						bean = new T4243Bean();
						bean.setArc_zip(t4536storeHistorico.getContenido());

					} else { // PAS20191U210300059; buscar en nube
						if (log.isDebugEnabled())
							log.debug("Consultando cloud - get xml t4536storeHistorico=null");

						/*
						 * log.debug("numRuc " + p_num_ruc); log.debug("codCPe "
						 * + xtipo); log.debug("numSerieCpe " +
						 * p_num_serie_cpe); log.debug("numCpe " + p_num_cpe);
						 */

						T4283Bean buscarT4283 = new T4283Bean();
						buscarT4283.setNum_ruc(p_num_ruc);
						buscarT4283.setCod_cpe(xtipo);
						buscarT4283.setNum_serie_cpe(p_num_serie_cpe);
						buscarT4283.setNum_cpe(p_num_cpe);
						buscarT4283.setCod_rubro(IND_RUBRO_CLOUD_GUID);

						if (log.isDebugEnabled())
							log.debug("buscarT4283 : " + buscarT4283.toString());
						T4283Bean rubro = daoT4283.findRubroCabecera_ByRUC_codCPE_Serie_CPE_Rubro(buscarT4283);
						if (log.isDebugEnabled())
							log.debug("T4283Bean : " + rubro.toString());
						String guid = "";
						if (rubro != null) {
							guid = rubro.getDes_detalle_rubro();
						}

						try {
							log.debug("llamada cloud version 2.0 t4536storeHistorico=null");
							xmlCloud = this.procesarComprobanteNubev2_0(guid);
							log.debug("xml::::obtuvo xml t4536storeHistorico=null");

							if (xmlCloud.length > 0) {
								bean = new T4243Bean();
								// byte[] bytes =
								// xmlCloud.getBytes("ISO-8859-1");
								String nombreZip = p_num_ruc + "-" + p_tipo + "-" + p_num_serie_cpe + "-" + p_num_cpe
										+ ".xml";
								// bean.setArc_zip(zipBytes( nombreZip, xmlCloud
								// )); jm
								bean.setArc_zip(xmlCloud);
								
								log.debug("inicia procedimiento T4534Bean");
								T4534Bean T4534Bean = t4534DAO.findByPK(p_num_ruc, p_num_serie_cpe, xtipo, p_num_cpe);
								log.debug("T4534Bean.toString()==" + T4534Bean.toString());
								log.debug("inicia procedimiento BillStore");

								BillStore BillStore_ = new BillStore();
								BillStore_.setTicket(T4534Bean.getNum_ticket());
								BillStore_.setModo("1");
								BillStore_.setContenido(xmlCloud);
								BillStore_.setCorrelativo(T4534Bean.getNum_correl_ticket());
								BillStore_.setUsuarioModificador(T4534Bean.getCod_usumodif());
								log.debug("BillStore_.toString()==" + BillStore_.toString());

								log.debug("registrando en t4243DAOSpring.insert_ticket_CPE");
								t4243DAOSpring.insert_ticket_CPE(BillStore_);
								log.debug("Fin registrando en t4243DAOSpring.insert_ticket_CPE");
								
								
								if (log.isDebugEnabled())
									log.debug("Comprobante comprimido ISO-8859-1 : " + nombreZip);
							}
						} catch (Exception e1) {
							throw new ServiceException(this, "El documento con n�mero de serie " + p_num_serie_cpe + "-"
									+ p_num_cpe + " no ha sido informado a SUNAT.");
						}
					}
				}
				// PAS20191U210100231
			} else {

				T4283Bean buscarT4283 = new T4283Bean();
				buscarT4283.setNum_ruc(p_num_ruc);
				buscarT4283.setCod_cpe(xtipo);
				buscarT4283.setNum_serie_cpe(p_num_serie_cpe);
				buscarT4283.setNum_cpe(p_num_cpe);
				buscarT4283.setCod_rubro(IND_RUBRO_CLOUD_GUID);

				T4283Bean rubro = daoT4283.findRubroCabecera_ByRUC_codCPE_Serie_CPE_Rubro(buscarT4283);
				String guid = "";
				if (rubro != null) {
					guid = rubro.getDes_detalle_rubro();
				}

				try {
					log.debug("llamada cloud version 2.0 else t4536bean=null");
					xmlCloud = this.procesarComprobanteNubev2_0(guid);
					log.debug("xml :::: obtuvo xml else t4536bean=null");
					if (xmlCloud.length > 0) {
						bean = new T4243Bean();
						String nombreZip = p_num_ruc + "-" + p_tipo + "-" + p_num_serie_cpe + "-" + p_num_cpe + ".xml";
						// bean.setArc_zip(zipBytes( nombreZip, xmlCloud ));
						// bean.setArc_zip( zipBytes( nombreZip,
						// decompress(bytes) ));
						bean.setArc_zip(xmlCloud);
						
						log.debug("inicia procedimiento T4534Bean");
						T4534Bean T4534Bean = t4534DAO.findByPK(p_num_ruc, p_num_serie_cpe, xtipo, p_num_cpe);
						log.debug("T4534Bean.toString()==" + T4534Bean.toString());
						log.debug("inicia procedimiento BillStore");

						BillStore BillStore_ = new BillStore();
						BillStore_.setTicket(T4534Bean.getNum_ticket());
						BillStore_.setModo("1");
						BillStore_.setContenido(xmlCloud);
						BillStore_.setCorrelativo(T4534Bean.getNum_correl_ticket());
						BillStore_.setUsuarioModificador(T4534Bean.getCod_usumodif());
						log.debug("BillStore_.toString()==" + BillStore_.toString());

						log.debug("registrando en t4243DAOSpring.insert_ticket_CPE");
						t4243DAOSpring.insert_ticket_CPE(BillStore_);
						log.debug("Fin registrando en t4243DAOSpring.insert_ticket_CPE");
					}
				} catch (Exception e) {
					throw new ServiceException(this, "El documento con n�mero de serie " + p_num_serie_cpe + "-"
							+ p_num_cpe + " no ha sido informado a SUNAT.");
				}
			}

		} else {
			// xml portal
			bean = daoT4243Ibatis.findFileXmlJoinTCabCPETArcXmlByPrimaryKeyISO88591(p_num_ruc, xtipo, p_num_serie_cpe,
					p_num_cpe);
		}

		if (bean != null) {
			pe.gob.sunat.servicio2.registro.electronico.comppago.factura.bean.ArchivoComprobanteBean beanFile = new pe.gob.sunat.servicio2.registro.electronico.comppago.factura.bean.ArchivoComprobanteBean();
			beanFile.setNumeroRuc(p_num_ruc);
			beanFile.setTipoComprobante(params.get("tipo"));
			beanFile.setSerieComprobante(p_num_serie_cpe);
			beanFile.setNumeroComprobante(p_num_cpe);

			if (isGem) {
				// beanFile.setContenidoArchivoXml(new
				// String(decompress(bean.getArc_zip())));
				// obtenerArchivoXmlDesdeZip
				// beanFile.setContenidoArchivoXml(new
				// String(bean.getArc_zip()));
				beanFile.setContenidoArchivoXml(new String(decompress(bean.getArc_zip()), "ISO-8859-1"));
				if (log.isDebugEnabled())
					log.debug("getContenidoArchivoXml+ : " + beanFile.getContenidoArchivoXml());
			} else {
				if (log.isDebugEnabled())
					log.debug("getArc_xml : " + bean.getArc_xml());
				beanFile.setContenidoArchivoXml(bean.getArc_xml());
			}
			log.debug("marca xtipo:" + xtipo);

			if (xtipo.equals(FACTURA_GEM)) {
				beanFile.setTipoComprobante(ComprobanteUtilBean.FACTURA);
			}
			if (xtipo.equals(NOTA_CREDITO_GEM)) {
				beanFile.setTipoComprobante(ComprobanteUtilBean.NOTA_CREDITO);
			}
			if (xtipo.equals(NOTA_DEBITO_GEM)) {
				beanFile.setTipoComprobante(ComprobanteUtilBean.NOTA_DEBITO);
			}

			try {
				log.debug("Mostrar XML==" + beanFile.getContenidoArchivoXml());
				comprobante = archivoService.generaComprobanteBean(archivoService.generarArchivoXML(beanFile), false,
						false);
				log.debug("Termina generaComprobanteBean");
				// En caso se haya guardado el establecimiento del emisor, se
				// recupera
				// id_estab_emisor y cod_estab
				if (comprobante.getIndicadorEstabEmisor() != null
						&& comprobante.getIndicadorEstabEmisor().equals("1")) {
					T4283Bean buscarT4283 = new T4283Bean();
					buscarT4283.setNum_ruc(comprobante.getNumeroRuc());
					buscarT4283.setCod_cpe("01");
					buscarT4283.setNum_serie_cpe(comprobante.getSerieComprobante());
					buscarT4283.setNum_cpe(comprobante.getNumeroComprobante());
					buscarT4283.setCod_rubro(165); // INDICADOR DE
													// ESTABLECIMIENTO DEL
													// EMISOR

					T4283Bean rubro = daoT4283.findRubroCabecera_ByRUC_codCPE_Serie_CPE_Rubro(buscarT4283);
					if (rubro != null) {
						comprobante.getEstabEmisor().setId_estab_emisor(rubro.getDes_detalle_rubro());
					}

					T5229Bean direccion = daoT5229.selectByPrimaryKey("01", 11, comprobante.getNumeroComprobante(), 1,
							comprobante.getNumeroRuc(), comprobante.getSerieComprobante());
					if (direccion != null) {
						comprobante.getEstabEmisor().setCod_estab(direccion.getCod_estab());
					}
				}

				// valido documento relacionado
				// PAS20201U210100101
				// considera notas recibidas y emitidas de facturas gem
				if (p_num_serie_cpe.toUpperCase().startsWith("F")
						&& (xtipo.equals(NOTA_CREDITO_GEM) || xtipo.equals(NOTA_DEBITO_GEM))) {
					if (comprobante.getSerieDocumentoPorElQueSeEmite() != null
							&& !comprobante.getSerieDocumentoPorElQueSeEmite().equals("")) {
						String numSerieDocRel = comprobante.getSerieDocumentoPorElQueSeEmite().substring(0, 4);
						String numDocRel = comprobante.getSerieDocumentoPorElQueSeEmite().substring(5);

						// log.debug("comprobante:::"+comprobante.toString());
						log.debug("comprobante_a_consultar==>" + p_num_ruc + "-" + xtipo + "-" + p_num_serie_cpe + "-"
								+ p_num_cpe);
						// log.debug("comprobante.getSerieComprobante():"+comprobante.getSerieComprobante());
						// F116-00000044

						T4429Bean beanT4429 = new T4429Bean();
						beanT4429.setNum_ruc(p_num_ruc);
						beanT4429.setCod_cpe(xtipo);
						beanT4429.setNum_serie_cpe(p_num_serie_cpe);
						beanT4429.setNum_cpe(p_num_cpe);

						beanT4429.setNum_ruc_rel(p_num_ruc);
						beanT4429.setCod_doc_rel(FACTURA_GEM);// solo para
																// facturas Gem
						beanT4429.setNum_serie_doc_rel(numSerieDocRel);
						beanT4429.setNum_doc_rel(numDocRel);

						beanT4429.setCod_relacion("02");
						beanT4429.setCod_usumodif("SUNAT");
						beanT4429.setFec_modif(new FechaBean());

						log.debug("Datos emisor:" + beanT4429.getNum_ruc() + "-" + beanT4429.getCod_cpe() + "-"
								+ beanT4429.getNum_serie_cpe() + "-" + beanT4429.getNum_cpe());
						log.debug("Datos doc_rel:" + beanT4429.getNum_ruc_rel() + "-" + beanT4429.getNum_serie_doc_rel()
								+ "-" + beanT4429.getNum_serie_doc_rel() + "-" + beanT4429.getNum_doc_rel());

						// T4429Bean docRel =
						// daoT4429.findBy_RucTipoSerieNumeroRelacion(xtipo,
						// p_num_ruc, p_num_serie_cpe, p_num_cpe.toString(),
						// "02");
						// PAS20201U210100114
						T4429Bean docRel = daoT4429.findBy_RucTipoSerieNumeroDocRel(p_num_ruc, xtipo, p_num_serie_cpe,
								p_num_cpe.toString(), p_num_ruc, FACTURA_GEM, numSerieDocRel, numDocRel);

						log.info("docRel:" + docRel);

						if (docRel == null) {
							log.info("Nota sin docRel - procede a insertar");
							daoT4429.insert(beanT4429);
						} else {
							log.debug("Nota con docRel - no procede a insertar");
						}

					}
				}

				comprobante.setSimboloMoneda(ComprobanteUtilBean.getSimboloMoneda(comprobante.getCodigoMoneda()));

				int countUnidadMedidaItem = 0;
				int countCodigoItem = 0;

				Map<String, String> unidadMedida = null;
				List<pe.gob.sunat.servicio2.registro.electronico.comppago.factura.bean.DetalleComprobanteBean> lstDetalleComprobante = new ArrayList<pe.gob.sunat.servicio2.registro.electronico.comppago.factura.bean.DetalleComprobanteBean>();
				if (comprobante.getDetalleComprobanteBean() != null) {
					for (pe.gob.sunat.servicio2.registro.electronico.comppago.factura.bean.DetalleComprobanteBean detalleComprobante : comprobante
							.getDetalleComprobanteBean()) {

						if (!"-".equals(detalleComprobante.getUnidadMedida().trim())) {
							countUnidadMedidaItem++;
						}
						if (!"".equals(detalleComprobante.getCodigoItem().trim())) {
							countCodigoItem++;
						}

						unidadMedida = obtieneUnidadMedida(detalleComprobante.getUnidadMedida());
						detalleComprobante.setUnidadMedidaDesc(
								(unidadMedida != null ? unidadMedida.get("descripcionMedida").toString()
										: detalleComprobante.getUnidadMedida()));
						lstDetalleComprobante.add(detalleComprobante);
					}
				}

				comprobante.setCountUnidadMedidaItem(countUnidadMedidaItem);
				comprobante.setCountCodigoItem(countCodigoItem);
				comprobante.setDetalleComprobanteBean(lstDetalleComprobante);

				if (log.isDebugEnabled())
					log.debug(" >> ComprobanteBean :: " + comprobante);
			} catch (Exception e) {
				log.debug(">>ConsultarServiceImpl Error !! " + e.getMessage());
				MensajeBean msg = new MensajeBean();
				msg.setError(true);
				msg.setMensajeerror(e.getMessage());
				throw new ServiceException(this, msg);
			}
		} else {
			MensajeBean msg = new MensajeBean();
			msg.setError(false);
			msg.setMensajeerror("No existe factura a descargar.");
			throw new ServiceException(this, msg);
		}
		return comprobante;
	}

	@Override
	public pe.gob.sunat.servicio2.registro.electronico.comppago.boleta.bean.ComprobanteBean recuperarInfoBoleta(
			Map<String, String> params) throws IOException {
		if (log.isDebugEnabled()) {
			log.debug("recuperarInfoBoleta( " + params + " )");
		}

		pe.gob.sunat.servicio2.registro.electronico.comppago.boleta.bean.ComprobanteBean comprobante = null;
		boolean isGem = params.get("isGEM") != null ? true : false;
		String xtipo = BOLETA_VENTA_GEM; // boleta
		String p_tipo = "03";

		if ((params.get("tipo").toString().trim().equals("20"))
				|| (params.get("tipo").toString().trim().equals("21"))) {
			xtipo = NOTA_CREDITO_GEM;
			p_tipo = "07";
		}
		if ((params.get("tipo").toString().trim().equals("22"))
				|| (params.get("tipo").toString().trim().equals("23"))) {
			xtipo = NOTA_DEBITO_GEM;
			p_tipo = "08";
		}

		String p_num_ruc = params.get("ruc");
		String p_num_serie_cpe = params.get("serie");
		Integer p_num_cpe = new Integer(params.get("numero"));

		T4243Bean bean = null;
		byte[] xmlCloud = null;

		if (isGem) {
			// xml gem
			T4536Bean t4536bean = daoT4243.findFileZipJoinTCabCPETRelcompelecByPrimaryKey(p_num_ruc, xtipo,
					p_num_serie_cpe, p_num_cpe);

			if (t4536bean != null) {

				// buscar en cpe
				T4536Bean t4536Festore = daoT4536.findFileZipTFESTOREByPrimaryKey(t4536bean);

				if (t4536Festore != null) {
					bean = new T4243Bean();
					bean.setArc_zip(t4536Festore.getContenido());
					bean.setDes_nombre(daoT4536.findNombre(t4536bean.getTicket()));

				} else {
					T4536Bean t4536storeHistorico = daoT4536Hist.findFileZipTFESTOREByPrimaryKey(t4536bean);

					if (t4536storeHistorico != null) {
						bean = new T4243Bean();
						bean.setArc_zip(t4536storeHistorico.getContenido());

					} else {
						if (log.isDebugEnabled())
							log.debug("Consultando cloud - get xml");

						T4283Bean buscarT4283 = new T4283Bean();
						buscarT4283.setNum_ruc(p_num_ruc);
						buscarT4283.setCod_cpe(xtipo);
						buscarT4283.setNum_serie_cpe(p_num_serie_cpe);
						buscarT4283.setNum_cpe(p_num_cpe);
						buscarT4283.setCod_rubro(IND_RUBRO_CLOUD_GUID);

						T4283Bean rubro = daoT4283.findRubroCabecera_ByRUC_codCPE_Serie_CPE_Rubro(buscarT4283);
						String guid = "";
						if (rubro != null) {
							guid = rubro.getDes_detalle_rubro();
						}
						try {
							xmlCloud = this.procesarComprobanteNubev2_0(guid);
							if (xmlCloud.length > 0) {
								bean = new T4243Bean();
								// bean.setArc_xml(xmlCloud);
								// ("ISO-8859-1")
								String nombreZip = p_num_ruc + "-" + p_tipo + "-" + p_num_serie_cpe + "-" + p_num_cpe
										+ ".xml";
								// bean.setArc_zip(zipBytes( nombreZip, xmlCloud
								// ));
								bean.setArc_zip(xmlCloud);
								
								log.debug("inicia procedimiento T4534Bean");
								T4534Bean T4534Bean = t4534DAO.findByPK(p_num_ruc, p_num_serie_cpe, xtipo, p_num_cpe);
								log.debug("T4534Bean.toString()==" + T4534Bean.toString());
								log.debug("inicia procedimiento BillStore");

								BillStore BillStore_ = new BillStore();
								BillStore_.setTicket(T4534Bean.getNum_ticket());
								BillStore_.setModo("1");
								BillStore_.setContenido(xmlCloud);
								BillStore_.setCorrelativo(T4534Bean.getNum_correl_ticket());
								BillStore_.setUsuarioModificador(T4534Bean.getCod_usumodif());
								log.debug("BillStore_.toString()==" + BillStore_.toString());

								log.debug("registrando en t4243DAOSpring.insert_ticket_CPE");
								t4243DAOSpring.insert_ticket_CPE(BillStore_);
								log.debug("Fin registrando en t4243DAOSpring.insert_ticket_CPE");
							}
						} catch (Exception e1) {
							throw new ServiceException(this, "El documento con n�mero de serie " + p_num_serie_cpe + "-"
									+ p_num_cpe + " no ha sido informado a SUNAT.");
						}
					}
				}
				// PAS20191U210100231
			} else {

				T4283Bean buscarT4283 = new T4283Bean();
				buscarT4283.setNum_ruc(p_num_ruc);
				buscarT4283.setCod_cpe(xtipo);
				buscarT4283.setNum_serie_cpe(p_num_serie_cpe);
				buscarT4283.setNum_cpe(p_num_cpe);
				buscarT4283.setCod_rubro(IND_RUBRO_CLOUD_GUID);

				T4283Bean rubro = daoT4283.findRubroCabecera_ByRUC_codCPE_Serie_CPE_Rubro(buscarT4283);
				String guid = "";
				if (rubro != null) {
					guid = rubro.getDes_detalle_rubro();
				}

				try {
					xmlCloud = this.procesarComprobanteNubev2_0(guid);

					if (xmlCloud.length > 0) {
						bean = new T4243Bean();
						// bean.setArc_xml(xmlCloud);
						String nombreZip = p_num_ruc + "-" + p_tipo + "-" + p_num_serie_cpe + "-" + p_num_cpe + ".xml";
						// bean.setArc_zip(zipBytes( nombreZip, xmlCloud ));
						bean.setArc_zip(xmlCloud);
						
						log.debug("inicia procedimiento T4534Bean");
						T4534Bean T4534Bean = t4534DAO.findByPK(p_num_ruc, p_num_serie_cpe, xtipo, p_num_cpe);
						log.debug("T4534Bean.toString()==" + T4534Bean.toString());
						log.debug("inicia procedimiento BillStore");

						BillStore BillStore_ = new BillStore();
						BillStore_.setTicket(T4534Bean.getNum_ticket());
						BillStore_.setModo("1");
						BillStore_.setContenido(xmlCloud);
						BillStore_.setCorrelativo(T4534Bean.getNum_correl_ticket());
						BillStore_.setUsuarioModificador(T4534Bean.getCod_usumodif());
						log.debug("BillStore_.toString()==" + BillStore_.toString());

						log.debug("registrando en t4243DAOSpring.insert_ticket_CPE");
						t4243DAOSpring.insert_ticket_CPE(BillStore_);
						log.debug("Fin registrando en t4243DAOSpring.insert_ticket_CPE");
					}
				} catch (Exception e) {
					log.debug("Error linea 809");
					throw new ServiceException(this, "El documento con n�mero de serie " + p_num_serie_cpe + "-"
							+ p_num_cpe + " no ha sido informado a SUNAT.");
				}
			}

		} else {
			bean = daoT4243Ibatis.findFileXmlJoinTCabCPETArcXmlByPrimaryKeyISO88591(params.get("ruc"), xtipo,
					params.get("serie"), new Integer(params.get("numero")));
		}

		if (bean != null) {
			log.debug("bean != null");
			pe.gob.sunat.servicio2.registro.electronico.comppago.boleta.bean.ArchivoComprobanteBean beanFile = new pe.gob.sunat.servicio2.registro.electronico.comppago.boleta.bean.ArchivoComprobanteBean();
			beanFile.setNumeroRuc(params.get("ruc"));
			beanFile.setTipoComprobante(params.get("tipo"));
			beanFile.setSerieComprobante(params.get("serie"));
			beanFile.setNumeroComprobante(new Integer(params.get("numero")));
			if (isGem) {

				beanFile.setContenidoArchivoXml(new String(decompress(bean.getArc_zip())));
				// beanFile.setContenidoArchivoXml(new
				// String(decompress(bean.getArc_zip()),
				// StandardCharsets.ISO_8859_1));
			} else {
				beanFile.setContenidoArchivoXml(bean.getArc_xml());
			}

			if (xtipo.equals(BOLETA_VENTA_GEM)) {
				beanFile.setTipoComprobante(ComprobanteUtilBean.BOLETA);
			}
			if (xtipo.equals(NOTA_CREDITO_GEM)) {
				beanFile.setTipoComprobante(ComprobanteUtilBean.NOTA_CREDITO);
			}
			if (xtipo.equals(NOTA_DEBITO_GEM)) {
				beanFile.setTipoComprobante(ComprobanteUtilBean.NOTA_DEBITO);
			}
			try {
				comprobante = archivoServiceBVE.generaComprobanteBean(archivoServiceBVE.generarArchivoXML(beanFile),
						false, false);

				// En caso se haya guardado el establecimiento del emisor, se
				// recupera
				// id_estab_emisor y cod_estab
				if (comprobante.getIndicadorEstabEmisor() != null
						&& comprobante.getIndicadorEstabEmisor().equals("1")) {
					T4283Bean buscarT4283 = new T4283Bean();
					buscarT4283.setNum_ruc(comprobante.getNumeroRuc());
					buscarT4283.setCod_cpe("03");
					buscarT4283.setNum_serie_cpe(comprobante.getSerieComprobante());
					buscarT4283.setNum_cpe(comprobante.getNumeroComprobante());
					buscarT4283.setCod_rubro(165); // INDICADOR DE
													// ESTABLECIMIENTO DEL
													// EMISOR

					T4283Bean rubro = daoT4283.findRubroCabecera_ByRUC_codCPE_Serie_CPE_Rubro(buscarT4283);
					if (rubro != null) {
						comprobante.getEstabEmisor().setId_estab_emisor(rubro.getDes_detalle_rubro());
					}

					T5229Bean direccion = daoT5229.selectByPrimaryKey("03", 11, comprobante.getNumeroComprobante(), 1,
							comprobante.getNumeroRuc(), comprobante.getSerieComprobante());
					if (direccion != null) {
						comprobante.getEstabEmisor().setCod_estab(direccion.getCod_estab());
					}
				}

				comprobante.setSimboloMoneda(ComprobanteUtilBean.getSimboloMoneda(comprobante.getCodigoMoneda()));

				int countUnidadMedidaItem = 0;
				int countCodigoItem = 0;

				Map<String, String> unidadMedida = null;
				List<pe.gob.sunat.servicio2.registro.electronico.comppago.boleta.bean.DetalleComprobanteBean> lstDetalleComprobante = new ArrayList<pe.gob.sunat.servicio2.registro.electronico.comppago.boleta.bean.DetalleComprobanteBean>();
				if (comprobante.getDetalleComprobanteBean() != null) {
					for (pe.gob.sunat.servicio2.registro.electronico.comppago.boleta.bean.DetalleComprobanteBean detalleComprobante : comprobante
							.getDetalleComprobanteBean()) {
						log.debug("unidadMedidaItem: " + detalleComprobante.getUnidadMedida());
						log.debug("codigoItem: " + detalleComprobante.getCodigoItem());

						if (!"-".equals(detalleComprobante.getUnidadMedida().trim())) {
							countUnidadMedidaItem++;
						}
						if (!"".equals(detalleComprobante.getCodigoItem().trim())) {
							countCodigoItem++;
						}

						unidadMedida = obtieneUnidadMedida(detalleComprobante.getUnidadMedida());
						detalleComprobante.setUnidadMedidaDesc(
								(unidadMedida != null ? unidadMedida.get("descripcionMedida").toString()
										: detalleComprobante.getUnidadMedida()));
						lstDetalleComprobante.add(detalleComprobante);
					}
				}

				comprobante.setCountUnidadMedidaItem(countUnidadMedidaItem);
				comprobante.setCountCodigoItem(countCodigoItem);
				comprobante.setDetalleComprobanteBean(lstDetalleComprobante);

				if (log.isDebugEnabled())
					log.debug(" >> ComprobanteBean :: " + comprobante);
			} catch (Exception e) {
				log.debug(">>ConsultarServiceImpl Error !! " + e.getMessage());
				MensajeBean msg = new MensajeBean();
				msg.setError(true);
				msg.setMensajeerror(e.getMessage());
				throw new ServiceException(this, msg);
			}
		} else {
			MensajeBean msg = new MensajeBean();
			msg.setError(false);
			msg.setMensajeerror("No existe boleta a descargar.");
			throw new ServiceException(this, msg);
		}
		return comprobante;
	}

	// METODOS PRIVADOS//
	private Map<String, String> obtieneUnidadMedida(String unidadMedida) {
		unidadMedida = unidadMedida.toUpperCase();

		if ("-".equals(unidadMedida.trim())) {
			return null;
		}

		for (Map<String, String> m : this.listadoUnidadMedida()) {
			if (unidadMedida.equals(m.get("unidadMedida"))) {
				return m;
			}
		}
		return null;
		// throw new ServiceException(this, "La unidad de medida no existe");
	}

	private List<Map<String, String>> listadoUnidadMedida() {
		List<Map<String, String>> lsMedidas = new ArrayList<Map<String, String>>();

		Map<String, String> unidaMedida = new HashMap<String, String>();
		List<T01Bean> listado = null;

		listado = (ArrayList<T01Bean>) daoT01.findUnidadMedidaVigente("677");

		for (T01Bean bean : listado) {
			unidaMedida = new HashMap<String, String>();
			unidaMedida.put("unidadMedida", bean.getArgumento().trim());
			unidaMedida.put("descripcionMedida", bean.getFuncion());
			lsMedidas.add(unidaMedida);
		}

		return lsMedidas;
	}

	private void validarRUC(Map<String, String> map) {
		if (log.isDebugEnabled()) {
			log.debug("verificarRUC( " + map + " )");
		}

		String ruc = (map.containsKey("nroRUC") ? map.get("nroRUC") : "0");
		this.verificarRUC(ruc);
	}

	private void validarPeriodo(Map<String, String> map) {
		if (log.isDebugEnabled()) {
			log.debug("validarPeriodo( " + map + " )");
		}

		MensajeBean msg = new MensajeBean();

		String periodo = (map.containsKey("periodo") ? map.get("periodo") : "0");

		// Valida el periodo
		if (!ComprobanteUtilBean.isNumber(periodo)) {
			msg.setError(false);
			msg.setMensajeerror("Valor ingresado no corresponde a un periodo valido.");
			throw new ServiceException(this, msg);
		}

		if (new Long(periodo).longValue() < 6) {
			msg.setError(false);
			msg.setMensajeerror("Valor ingresado no corresponde a un periodo valido.");
			throw new ServiceException(this, msg);
		}

		if (!ComprobanteUtilBean.validarMesDelPeriodo(periodo)) {
			msg.setError(false);
			msg.setMensajeerror("Valor ingresado no corresponde a un periodo valido.");
			throw new ServiceException(this, msg);
		}

		if (new Long(periodo).longValue() < 200607) {
			msg.setError(false);
			msg.setMensajeerror("Valor ingresado debe ser mayor al periodo 200607.");
			throw new ServiceException(this, msg);
		}
	}

	// private List <ConsultarFacturaBean> formatResponse (List <T4241Bean>
	// lista) throws Exception {
	// if (log.isDebugEnabled()) {log.debug("formatResponse( " + lista + " )");
	// }
	//
	// List <ConsultarFacturaBean> resp = new ArrayList
	// <ConsultarFacturaBean>();
	// ConsultarFacturaBean bean = null;
	// int id = 0;
	// for(T4241Bean t4241 : lista) {
	// bean = new ConsultarFacturaBean();
	// bean.setId(Integer.toString(id++));
	// bean.setNroSerie(t4241.getNum_serie_cpe());
	// bean.setNroFactura(t4241.getNum_cpe().toString());
	// bean.setNroRucEmisor(t4241.getNum_ruc());
	// bean.setNroRucReceptor(t4241.getNum_docide_recep());
	// bean.setCodigoMoneda(t4241.getCod_moneda());
	// bean.setNumeroIdXml(t4241.getNum_id_xml().toString());
	// bean.setCodFactura("10");
	//
	// bean.setNroFacturaDesc(t4241.getNum_serie_cpe().concat(" -
	// ").concat(t4241.getNum_cpe().toString()));
	// bean.setNroRucEmisorDesc(this.getRUCDesc(t4241.getNum_ruc().trim()));
	// bean.setNroRucReceptorDesc((
	// "-".equals(t4241.getNum_docide_recep().trim()) ?
	// t4241.getDes_nombre_recep() :
	// this.getRUCDesc(t4241.getNum_docide_recep())));
	//
	// if (log.isDebugEnabled()) {
	// log.debug("Get simbolos Modena"); }
	// bean.setCodigoMonedaDesc(ComprobanteUtilBean.getSimboloMoneda(t4241.getCod_moneda()));
	// bean.setImporteTotalDesc(ComprobanteUtilBean.getSimboloMoneda(t4241.getCod_moneda())
	// +
	// ComprobanteUtilBean.formatTwoDecimal(t4241.getMto_importe_total().toString()));
	// bean.setFechaEmisionDesc(
	// t4241.getFec_emision().getFormatDate("dd/MM/yyyy") );
	//
	// //log.debug(t4241.getFec_rubro().getFormatDate("yyyyMMdd"));
	// //log.debug(("00010101".equals(t4241.getFec_rubro().getFormatDate("yyyyMMdd"))
	// ? "": t4241.getFec_rubro().getFormatDate("dd/MM/yyyy") ));
	//
	// bean.setFechaRechazoDesc((t4241.getFec_rubro()== null ||
	// "00010101".equals(t4241.getFec_rubro().getFormatDate("yyyyMMdd")) ? "":
	// t4241.getFec_rubro().getFormatDate("dd/MM/yyyy") ));
	//
	// resp.add(bean);
	// }
	//
	// return resp;
	// }

	private String getRUCDesc(String nroRUC) {
		if (log.isDebugEnabled()) {
			log.debug("getRUCDesc( " + nroRUC + " )");
		}

		DdpBean bean = this.verificarRUC(nroRUC.trim());
		if (null == bean)
			return "";
		else
			return bean.getDdp_numruc() + " - " + bean.getDdp_nombre().trim();
	}

	// GETTERS AND SETTERS//

	public DdpDAO getDaoDdp() {
		return daoDdp;
	}

	public void setDaoDdp(DdpDAO daoDdp) {
		this.daoDdp = daoDdp;
	}

	public T4241DAO getDaoT4241() {
		return daoT4241;
	}

	public void setDaoT4241(T4241DAO daoT4241) {
		this.daoT4241 = daoT4241;
	}

	public T4243DAO getDaoT4243() {
		return daoT4243;
	}

	public void setDaoT4243(T4243DAO daoT4243) {
		this.daoT4243 = daoT4243;
	}

	public T01DAO getDaoT01() {
		return daoT01;
	}

	public void setDaoT01(T01DAO daoT01) {
		this.daoT01 = daoT01;
	}

	public T4429DAO getDaoT4429() {
		return daoT4429;
	}

	public void setDaoT4429(T4429DAO daoT4429) {
		this.daoT4429 = daoT4429;
	}

	/**
	 * metodo agregado el 2010-12-09 por NAA para que la transformacion funcione
	 * con NC y ND aparte de factura
	 */
	private List<ConsultarFacturaBean> formatResponse(List<T4241Bean> lista, String tipo) throws Exception {
		if (log.isDebugEnabled()) {
			log.debug("formatResponse( " + lista + " )");
		}

		List<ConsultarFacturaBean> resp = new ArrayList<ConsultarFacturaBean>();

		ConsultarFacturaBean bean = null;
		int id = 0;
		Map<String, Object> mFecPres = null;

		for (T4241Bean t4241 : lista) {

			bean = new ConsultarFacturaBean();

			bean.setId(Integer.toString(id++));
			bean.setNroSerie(t4241.getNum_serie_cpe());
			bean.setNroFactura(t4241.getNum_cpe().toString());
			bean.setNroRucEmisor(t4241.getNum_ruc());
			bean.setNroRucReceptor(t4241.getNum_docide_recep());

			bean.setNumeroIdXml(t4241.getNum_id_xml() == null ? "0" : t4241.getNum_id_xml().toString());
			bean.setCodFactura(tipo); // 10 FACTURA, 13: ND 15 : NC
			bean.setTipoCPE(t4241.getCod_tipo_cpe()); // Para saber el tipo de
			// nota de credito o
			// debito
			bean.setNroFacturaDesc(t4241.getNum_serie_cpe().concat(" - ").concat(t4241.getNum_cpe().toString()));
			bean.setNroRucEmisorDesc(this.getRUCDesc(t4241.getNum_ruc().trim()));

			String nroRucReceptorDesc = "";
			// codigo de documento receptor
			String cod_docide_recep = t4241.getCod_docide_recep() != null ? t4241.getCod_docide_recep().trim() : "";
			// nombre de receptor
			String des_nombre_recep = t4241.getDes_nombre_recep() != null ? t4241.getDes_nombre_recep().trim() : "";
			// numero de documento de receptor
			String num_docide_recep = t4241.getNum_docide_recep() != null ? t4241.getNum_docide_recep().trim() : "";

			if (!"".equals(num_docide_recep) && ("06".equals(cod_docide_recep) || "6".equals(cod_docide_recep))) {

				if ("-".equals(num_docide_recep)) {
					if (!"".equals(des_nombre_recep))
						nroRucReceptorDesc = des_nombre_recep;
				} else {
					nroRucReceptorDesc = this.getRUCDesc(num_docide_recep);
				}

				// bean.setNroRucReceptorDesc(("-".equals(t4241.getNum_docide_recep().trim())
				// ?
				// t4241.getDes_nombre_recep() :
				// this.getRUCDesc(t4241.getNum_docide_recep())));

			} else if (!"".equals(num_docide_recep)) {

				if ("-".equals(num_docide_recep)) {
					if (!"".equals(des_nombre_recep))
						nroRucReceptorDesc = des_nombre_recep;
				} else {
					nroRucReceptorDesc = num_docide_recep;
					if (!"".equals(des_nombre_recep))
						nroRucReceptorDesc = nroRucReceptorDesc + " - " + des_nombre_recep;
				}
				// bean.setNroRucReceptorDesc(("-".equals(t4241.getNum_docide_recep().trim())
				// ?
				// t4241.getDes_nombre_recep() : t4241.getNum_docide_recep() + "
				// - " +
				// t4241.getDes_nombre_recep()));

			} else {
				if (!"".equals(des_nombre_recep))
					nroRucReceptorDesc = des_nombre_recep;
				// bean.setNroRucReceptorDesc(t4241.getDes_nombre_recep());
			}

			bean.setNroRucReceptorDesc(nroRucReceptorDesc);

			if (t4241.getCod_moneda() != null) {
				bean.setCodigoMoneda(t4241.getCod_moneda());
				bean.setCodigoMonedaDesc(ComprobanteUtilBean.getSimboloMoneda(t4241.getCod_moneda()));
			} else {
				bean.setCodigoMoneda("");
				bean.setCodigoMonedaDesc("");
			}

			if (null != t4241.getMto_importe_total())
				bean.setImporteTotalDesc(ComprobanteUtilBean.getSimboloMoneda(t4241.getCod_moneda())
						+ ComprobanteUtilBean.formatTwoDecimalComa(t4241.getMto_importe_total()));
			else
				bean.setImporteTotalDesc("");

			bean.setFechaEmisionDesc(t4241.getFec_emision().getFormatDate("dd/MM/yyyy"));
			bean.setFechaRechazoDesc(
					(t4241.getFec_rubro() == null || "00010101".equals(t4241.getFec_rubro().getFormatDate("yyyyMMdd"))
							? "" : t4241.getFec_rubro().getFormatDate("dd/MM/yyyy")));

			log.debug("Tipo de Consulta-->" + tipo);
			if (tipo.equals("13") || tipo.equals("14") || tipo.equals("15") || tipo.equals("16") || tipo.equals("20")
					|| tipo.equals("22")) {
				// obtener factura o boleta por la cual se emite la nota
				if (log.isInfoEnabled())
					log.info(">> formatResponse :: t4241.getNum_serie_cpe()=" + t4241.getNum_serie_cpe()
							+ ", t4241.getNum_serie_cpe()=" + t4241.getNum_serie_cpe() + ", t4241.getNum_cpe()="
							+ t4241.getNum_cpe() + ", t4241.getInd_estado()=" + t4241.getInd_estado());
				T4429Bean beanDocRel = null;
				/**
				 * JCZ May2012 :: Cuando es GEM para factura el cod_doc_rel es
				 * "01", cuando es MYPE cod_doc_rel es "06"
				 */
				if (bean.getNroSerie().startsWith("E") || bean.getNroSerie().startsWith("EB"))
					beanDocRel = daoT4429.findBy_RucTipoSerieNumeroRelacion(
							((tipo.equals("13") || tipo.equals("14") || tipo.equals("20") || tipo.equals("22"))
									? NOTA_CREDITO_GEM : NOTA_DEBITO_GEM),
							t4241.getNum_ruc(), t4241.getNum_serie_cpe(), t4241.getNum_cpe().toString(), "02");
				else if (bean.getNroSerie().startsWith("F") || bean.getNroSerie().startsWith("B")) {
					beanDocRel = daoT4429.findByRucTipDocSerieDocRelacion(t4241.getNum_ruc(),
							((tipo.equals("13") || tipo.equals("14") || tipo.equals("20")) ? NOTA_CREDITO_GEM
									: NOTA_DEBITO_GEM),
							t4241.getNum_serie_cpe(), t4241.getNum_cpe(), "02",
							((tipo.equals("20") || tipo.equals("22"))) ? BOLETA_VENTA_GEM : FACTURA_GEM);
				}
				if (beanDocRel != null) {
					bean.setComprobantePorElQueSeEmite(
							beanDocRel.getNum_serie_doc_rel().concat(" - ").concat(beanDocRel.getNum_doc_rel()));
				} else {
					bean.setComprobantePorElQueSeEmite("");
				}
			} else {
				bean.setComprobantePorElQueSeEmite("");
				if (this.obtenerNCAnulacion21(t4241.getNum_ruc(), t4241.getNum_serie_cpe(),
						t4241.getNum_cpe().toString()) > 0) {
					bean.setInd_emisionNC21("1");
				} else {
					bean.setInd_emisionNC21("0");
				}
				if ("03".equals(t4241.getCod_tipo_cpe())) {

					log.debug(":t4241.getNum_ruc():" + t4241.getNum_ruc());
					log.debug(":t4241.getNum_id_xml():" + t4241.getNum_id_xml());

					T4993Bean t4993 = daoT4993.findByPrimaryKey(t4241.getNum_ruc(), t4241.getNum_id_xml(), 1);

					if (t4993 != null) {
						bean.setIdPDF(t4993.getNum_id_firma().toString());
						bean.setNombrePDF(t4993.getDes_nombre());
					} else {
						bean.setIdPDF("0");
						bean.setNombrePDF("");
					}

				} else {
					bean.setIdPDF("0");
					bean.setNombrePDF("");
				}

			}
			// 0 = activo, 1 = rechazado, 2 = baja , 3 = anulado
			String estadoDesc = "";
			if (t4241.getInd_estado().trim().equals("0"))
				estadoDesc = "Activo";
			else if (t4241.getInd_estado().trim().equals("1"))
				estadoDesc = "Rechazado";
			else if (t4241.getInd_estado().trim().equals("2")) {
				estadoDesc = "Baja";
			} else if (t4241.getInd_estado().trim().equals("3"))
				estadoDesc = "Anulado";

			if (t4241.getInd_estado().trim().equals("2")) {
				mFecPres = t4703DAO.buscarFechaPresentacion(t4241.getNum_ruc(), t4241.getCod_cpe(),
						t4241.getNum_serie_cpe().trim(), t4241.getNum_cpe());
				bean.setFechaEstado(mFecPres == null ? ""
						: new FechaBean((java.sql.Date) mFecPres.get("fec_registro")).getFormatDate("dd/MM/yyyy"));
			} else
				bean.setFechaEstado(
						t4241.getFechaEstado() == null ? "" : t4241.getFechaEstado().getFormatDate("dd/MM/yyyy"));

			bean.setIndEstado(t4241.getInd_estado().trim());
			bean.setEstadoDesc(estadoDesc);

			resp.add(bean);
		}
		return resp;
	}

	private int obtenerNCAnulacion21(String numRUC, String serieDocRel, String numeroDocRel) {
		if (log.isDebugEnabled())
			log.debug("obtenerNCAnulacion21");
		int totalNc = 0;
		List<T4429Bean> NCEmitidasPorFE = this.obtenerDocsRelacionadosAFE(numRUC, NOTA_CREDITO_GEM, serieDocRel,
				numeroDocRel);
		if (NCEmitidasPorFE != null) {
			if (log.isDebugEnabled())
				log.debug("obtenerNCAnulacion21: Docs Relacionados:" + NCEmitidasPorFE.size());

			for (T4429Bean docRelacionado : NCEmitidasPorFE) {
				T4241Bean notaCredito = daoT4241.findByPK(numRUC, docRelacionado.getNum_serie_cpe(),
						docRelacionado.getNum_cpe(), NOTA_CREDITO_GEM);
				if (notaCredito.getCod_tipo_cpe().equals("21")) {
					totalNc++;
				}
			}
		}
		return totalNc;
	}

	private List<T4429Bean> obtenerDocsRelacionadosAFE(String numRUC, String tipoCPE, String serieDocRel,
			String numeroDocRel) {
		return daoT4429.findDocsEmitidosPorFETipo_By_Ruc_CodCP_SerieNumDocrel(tipoCPE, numRUC, serieDocRel,
				numeroDocRel);
	}

	public void setDaoT1331(T1331DAO daoT1331) {
		this.daoT1331 = daoT1331;
	}

	/* Ini :: JCZ jul-2011 */
	public boolean verificaAfiliacionFactGEM(String nroRUC) {
		boolean afiliado = false;
		T1331Bean t1331bean = daoT1331.findByRucEstadoProceso(nroRUC, "00", 25);
		if (null != t1331bean) {
			if (log.isDebugEnabled())
				log.debug(".:: daoT1313 ::. " + t1331bean);
			afiliado = true;
		}
		return afiliado;
	}

	/* End :: JCZ jul-2011 */

	public T4541DAO getDaoT4541() {
		return daoT4541;
	}

	public void setDaoT4541(T4541DAO daoT4541) {
		this.daoT4541 = daoT4541;
	}

	public void setT4703DAO(T4703DAO t4703dao) {
		t4703DAO = t4703dao;
	}

	public T4993DAO getDaoT4993() {
		return daoT4993;
	}

	public void setDaoT4993(T4993DAO daoT4993) {
		this.daoT4993 = daoT4993;
	}

	public pe.gob.sunat.servicio2.registro.electronico.comppago.factura.service.ProcesaArchivoComprobanteService getArchivoService() {
		return archivoService;
	}

	public void setArchivoService(
			pe.gob.sunat.servicio2.registro.electronico.comppago.factura.service.ProcesaArchivoComprobanteService archivoService) {
		this.archivoService = archivoService;
	}

	public pe.gob.sunat.servicio2.registro.electronico.comppago.boleta.service.ProcesaArchivoComprobanteService getArchivoServiceBVE() {
		return archivoServiceBVE;
	}

	public void setArchivoServiceBVE(
			pe.gob.sunat.servicio2.registro.electronico.comppago.boleta.service.ProcesaArchivoComprobanteService archivoServiceBVE) {
		this.archivoServiceBVE = archivoServiceBVE;
	}

	@Override
	public boolean verificarAcceso(String num_docum, String cod_acceso, String cod_detalle)
			throws NamingException, SystemException, NotSupportedException, SecurityException, IllegalStateException,
			RollbackException, HeuristicMixedException, HeuristicRollbackException {
		if (log.isDebugEnabled())
			log.debug("verificarAcceso");
		boolean retVal = false;

		UserTransaction tx = null;

		tx = (UserTransaction) new InitialContext().lookup("java:comp/UserTransaction");
		tx.begin();

		int nroFilas = daoT2816.update(num_docum, cod_acceso, cod_detalle);
		if (log.isDebugEnabled())
			log.debug("verificarAcceso: filas " + nroFilas);
		if (nroFilas == 1) {
			if (log.isDebugEnabled())
				log.debug("verificarAcceso: ok");
			retVal = true;
			tx.commit();
		} else {
			if (log.isDebugEnabled())
				log.debug("verificarAcceso: no ok");
			retVal = false;
			tx.rollback();
		}
		return retVal;
	}

	// PAS20211U210700267 - Ajuste en la url para la nueva versi�n de nube
	private byte[] procesarComprobanteNubev2_0(String guid) throws Exception {
		byte[] respCloudConsulta = null;
		if (log.isDebugEnabled())
			log.debug("procesarComprobanteNubev2_0 : guid");
		try {

			log.info(guid + " CloudService - inicio cloudComprobanteService v2-0");

			synchronized (CloudComprobanteStatic.class) {
				if (CloudComprobanteStatic.getComprobanteService() == null) {
					log.info(guid + " CloudComprobanteStatic - creacion cloudComprobanteServiceImpl");
					CloudComprobanteServiceImpl cloudComprobanteServiceImpl = new CloudComprobanteServiceImpl();
					cloudComprobanteServiceImpl.setDaoT01(daoT01);
					cloudComprobanteServiceImpl.inicializarVariablesConsultasCloud();
					CloudComprobanteStatic.setComprobanteService(cloudComprobanteServiceImpl);
				}
			}
			respCloudConsulta = CloudComprobanteStatic.getComprobanteService().consultarComprobanteCloudv2_0(guid);
		} catch (Exception e) {
			throw new ServiceException(this, "Se presento un error al consumir el servicio de MS.");
		}
		log.info(guid + " CloudService - final cloudComprobanteService");
		return respCloudConsulta;
	}

	// PAS20191U210100231
	private String procesarComprobanteNube(String numRuc, String codCpe, String numSerieCpe, Integer numCpe)
			throws Exception {

		if (log.isDebugEnabled())
			log.debug(
					"procesarComprobanteNube : cpeid = numRuc + \"-\" + codCpe + \"-\" + numSerieCpe + \"-\" + numCpe");
		String cpeid = numRuc + "-" + codCpe + "-" + numSerieCpe + "-" + numCpe;

		String response = "";
		try {

			log.info(cpeid + " CloudService - inicio cloudComprobanteService");

			synchronized (CloudComprobanteStatic.class) {
				if (CloudComprobanteStatic.getComprobanteService() == null
						|| !CloudComprobanteStatic.getComprobanteService().esVigenteTokenCustodia()) {
					log.info(cpeid + " CloudComprobanteStatic - creacion cloudComprobanteServiceImpl");
					CloudComprobanteServiceImpl cloudComprobanteServiceImpl = new CloudComprobanteServiceImpl();
					cloudComprobanteServiceImpl.setDaoT01(daoT01);
					cloudComprobanteServiceImpl.inicializarVariablesCustodia();
					CloudComprobanteStatic.setComprobanteService(cloudComprobanteServiceImpl);
				} else {
					if (log.isDebugEnabled())
						log.debug(
								cpeid + " CloudComprobanteStatic.getComprobanteService().esVigenteTokenCpes() = true");
				}
			}

			// [1]-correcto [-1]-no encontro [-2]-Otro error
			String[] respCloudConsulta = CloudComprobanteStatic.getComprobanteService()
					.consultarComprobanteCloud(cpeid);

			if (respCloudConsulta[0].equals("-2")) {
				String msmError = cpeid
						+ " Se present� un error al momento de consultar. Vuelva a intentar en unos minutos.";
				log.info(msmError);
				throw new Exception(msmError);
			} else if (respCloudConsulta[0].equals("1")) {
				response = respCloudConsulta[2];
			} else if (respCloudConsulta[0].equals("-1")) {
				String msmError = cpeid + " No se encontro el comprobante en la nube.";
				log.info(msmError);
				throw new Exception(msmError);
			}

		} catch (Exception e) {
			throw new ServiceException(this, "Se presento un error al consumir el servicio de MS.");
		}

		log.info(cpeid + " CloudService - final cloudComprobanteService");
		log.info("response:" + response);

		return response;
	}

	/*
	 * public String PortalGetCPEResponse(String numRuc, String codCpe, String
	 * numSerieCpe, Integer numCpe) throws AccessTokenException,
	 * PortalSystemException {
	 * 
	 * if (log.isDebugEnabled()) log.debug("Ini PortalGetCPEResponse");
	 * 
	 * String response = ""; try {
	 * 
	 * String cpeId = numRuc + "-" + codCpe + "-" + numSerieCpe + "-" + numCpe;
	 * String token = this.getAccessToken(false, numSerieCpe, numCpe);
	 * 
	 * if (log.isDebugEnabled()) log.debug("token = " + token); response =
	 * this.getServiceXmlFile(token, cpeId, "document", numSerieCpe, numCpe);
	 * 
	 * } catch (AccessTokenException e) { log.error(
	 * "Error AccessTokenException :" + e); throw new ServiceException(this,
	 * "El documento con n�mero de serie " + numSerieCpe + "-" + numCpe +
	 * " no ha sido informado a SUNAT."); } catch (PortalSystemException e) {
	 * log.error("Error PortalSystemException :" + e); throw new
	 * ServiceException(this, "El documento con n�mero de serie " + numSerieCpe
	 * + "-" + numCpe + " no ha sido informado a SUNAT."); } catch (Exception e)
	 * { log.error("Error Exception :" + e); throw new ServiceException(this,
	 * "El documento con n�mero de serie " + numSerieCpe + "-" + numCpe +
	 * " no ha sido informado a SUNAT."); }
	 * 
	 * if (log.isDebugEnabled()) log.debug("Fin PortalGetCPEResponse");
	 * 
	 * return response; }
	 * 
	 * private String getAccessToken(boolean esOperacion, String numSerieCpe,
	 * Integer numCpe) throws AccessTokenException {
	 * 
	 * log.debug("Ini getAccessToken");
	 * 
	 * String tokenRequestUrl =
	 * t01DAO.findByArgumento(UConstante.NUM_PARAMETRO_API_CPES_NUBE,
	 * "01").substring(29, 130).trim(); String clientId_query_xml =
	 * t01DAO.findByArgumento(UConstante.NUM_PARAMETRO_API_CPES_NUBE,
	 * "09").substring(29, 130).trim(); String clientSecret_query_xml =
	 * t01DAO.findByArgumento(UConstante.NUM_PARAMETRO_API_CPES_NUBE,
	 * "10").substring(29, 130).trim();
	 * 
	 * if (log.isDebugEnabled()) log.debug("tokenRequestUrl==" + tokenRequestUrl
	 * + "=="); if (log.isDebugEnabled()) log.debug("clientId_query_xml==" +
	 * clientId_query_xml + "=="); if (log.isDebugEnabled())
	 * log.debug("clientSecret_query_xml==" + clientSecret_query_xml + "==");
	 * 
	 * OAuthClientRequest request = null; try {
	 * 
	 * if (!esOperacion) { request =
	 * OAuthClientRequest.tokenLocation(tokenRequestUrl).setGrantType(GrantType.
	 * CLIENT_CREDENTIALS)
	 * .setClientId(clientId_query_xml).setClientSecret(clientSecret_query_xml)
	 * .setParameter("resource", clientId_query_xml).buildBodyMessage(); }
	 * 
	 * } catch (OAuthSystemException e) { log.error("Error getAccessToken :" +
	 * e); throw new ServiceException(this, "El documento con n�mero de serie "
	 * + numSerieCpe + "-" + numCpe + " no ha sido informado a SUNAT."); } catch
	 * (Exception e) { ; log.error("Error getAccessToken Exception :" + e);
	 * throw new ServiceException(this, "El documento con n�mero de serie " +
	 * numSerieCpe + "-" + numCpe + " no ha sido informado a SUNAT."); }
	 * 
	 * OAuthJSONAzureAccessToken azureAccessToken =
	 * OAuthJSONAzureAccessToken.getInstance();
	 * 
	 * return azureAccessToken.getAccessToken(request);
	 * 
	 * }
	 * 
	 * private String getServiceXmlFile(String token, String cpeid, String
	 * tipoDocument, String numSerieCpe, Integer numCpe) throws
	 * PortalSystemException {
	 * 
	 * PortalClient client = new PortalClient(new URLConnectionPortalClient());
	 * 
	 * String resourceUrlCpesFiles =
	 * t01DAO.findByArgumento(UConstante.NUM_PARAMETRO_API_CPES_NUBE,
	 * "11").substring(29, 130).trim();
	 * 
	 * if (log.isDebugEnabled()) log.debug("resourceUrlCpes==" +
	 * resourceUrlCpesFiles + "=="); log.debug("resourceUrlCpes==" +
	 * resourceUrlCpesFiles.replace(":cpeid", cpeid) + "==");
	 * 
	 * PortalClientRequest request = null; try {
	 * 
	 * request =
	 * CpePortalClientRequest.resourceLocation(resourceUrlCpesFiles.replace(
	 * ":cpeid", cpeid)) .setParameter("type",
	 * tipoDocument).buildQueryMessage();
	 * 
	 * request.addAuthorizationHeader(token);
	 * 
	 * } catch (PortalSystemException e) { log.error(
	 * "Error al configurar el cliente Portal = ", e); throw new
	 * ServiceException(this, "El documento con n�mero de serie " + numSerieCpe
	 * + "-" + numCpe + " no ha sido informado a SUNAT."); }
	 * 
	 * PortalQueryXmlFileResponse portalCPEResponse = null; try {
	 * 
	 * portalCPEResponse = client.callService(request, Portal.HttpMethod.GET,
	 * PortalQueryXmlFileResponse.class);
	 * 
	 * String respuesta = portalCPEResponse.getBody(); //String respuesta =
	 * "<?xml version=\"1.0\" encoding=\"iso-8859-1\" standalone=\"no\"?><Invoice xmlns:cbc=\"urn:oasis:names:specification:ubl:schema:xsd:CommonBasicComponents-2\" xmlns:udt=\"urn:un:unece:uncefact:data:specification:UnqualifiedDataTypesSchemaModule:2\" xmlns:xsi=\"http://www.w3.org/2001/XMLSchema-instance\" xmlns:ccts=\"urn:un:unece:uncefact:documentation:2\" xmlns:cac=\"urn:oasis:names:specification:ubl:schema:xsd:CommonAggregateComponents-2\" xmlns:ds=\"http://www.w3.org/2000/09/xmldsig#\" xmlns:qdt=\"urn:oasis:names:specification:ubl:schema:xsd:QualifiedDatatypes-2\" xmlns:ext=\"urn:oasis:names:specification:ubl:schema:xsd:CommonExtensionComponents-2\" xmlns=\"urn:oasis:names:specification:ubl:schema:xsd:Invoice-2\"><ext:UBLExtensions><ext:UBLExtension><ext:ExtensionContent><Signature Id=\"DT\" xmlns=\"http://www.w3.org/2000/09/xmldsig#\"><SignedInfo><CanonicalizationMethod Algorithm=\"http://www.w3.org/TR/2001/REC-xml-c14n-20010315\" /><SignatureMethod Algorithm=\"http://www.w3.org/2000/09/xmldsig#rsa-sha1\" /><Reference URI=\"\"><Transforms><Transform Algorithm=\"http://www.w3.org/2000/09/xmldsig#enveloped-signature\" /></Transforms><DigestMethod Algorithm=\"http://www.w3.org/2000/09/xmldsig#sha1\" /><DigestValue>feVI9lPULkypKXOgT3e1K+tm3mI=</DigestValue></Reference></SignedInfo><SignatureValue>S6S7M6lUNZps2i/YIqaQBE7YDHZP3Dp2nH80i438HkkX6ouLpDpDSyH7LCPRII69gwc0d6G9fQIqGZxs+d2sLLb8q77xBQuVYGXA+XMBZBvPmUOXjRjsvx929HIszVS1BOMTjs3zfFaaO5ZhqLih6wT6VbJXaj57bjAu2ZD/bIJ+NxxiIiB7wWWSLiG8Q3fJvbsR3Xtrghlf1aOm+qI4gY0ZKpQkVy+wsLiL4a5ZEYyUcDjTfYEy8M2GspA0OtPQKFEwHBtyP8KsFzJdaAK8gdBXhKrh8jpwgQS7j94gm2wKKVC1OKN2mgzRWmDPGfsw05xTAQM4Ej8qdu8PL8fzjQ==</SignatureValue><KeyInfo><X509Data><X509SubjectName>C=PE, CN=BRUNO HERNANDO ZUMAETA CHAVEZ, G=BRUNO HERNANDO, SN=ZUMAETA CHAVEZ, T=GERENTE CENTRAL, OU=20253319403, OU=LIMA, O=NEW TRANSPORT S.A., OID.1.3.6.1.4.1.17326.30.4=DNI, OID.1.3.6.1.4.1.17326.30.3=20253319403, OID.1.3.6.1.4.1.17326.30.2=RUC, SERIALNUMBER=42295805, S=LIMA-LIMA, L=MIRAFLORES, E=juan.lizama@gnt.pe</X509SubjectName><X509Certificate>MIIHcjCCBlqgAwIBAgIJG6wFWouK1DxLMA0GCSqGSIb3DQEBCwUAMIG4MQswCQYDVQQGEwJFUzElMCMGCSqGSIb3DQEJARYWY2FyYWNlckBjYW1lcmZpcm1hLmNvbTFDMEEGA1UEBxM6TWFkcmlkIChzZWUgY3VycmVudCBhZGRyZXNzIGF0IHd3dy5jYW1lcmZpcm1hLmNvbS9hZGRyZXNzKTESMBAGA1UEBRMJQTgyNzQzMjg3MRkwFwYDVQQKExBBQyBDYW1lcmZpcm1hIFNBMQ4wDAYDVQQDEwVSQUNFUjAeFw0xODA1MTQyMDIyNDRaFw0yMDA1MTMyMDIyNDRaMIIBaTEhMB8GCSqGSIb3DQEJARYSanVhbi5saXphbWFAZ250LnBlMRMwEQYDVQQHDApNSVJBRkxPUkVTMRIwEAYDVQQIDAlMSU1BLUxJTUExETAPBgNVBAUTCDQyMjk1ODA1MRMwEQYKKwYBBAGBhy4eAgwDUlVDMRswGQYKKwYBBAGBhy4eAwwLMjAyNTMzMTk0MDMxEzARBgorBgEEAYGHLh4EDANETkkxGzAZBgNVBAoMEk5FVyBUUkFOU1BPUlQgUy5BLjENMAsGA1UECwwETElNQTEUMBIGA1UECwwLMjAyNTMzMTk0MDMxGDAWBgNVBAwMD0dFUkVOVEUgQ0VOVFJBTDEXMBUGA1UEBAwOWlVNQUVUQSBDSEFWRVoxFzAVBgNVBCoMDkJSVU5PIEhFUk5BTkRPMSYwJAYDVQQDDB1CUlVOTyBIRVJOQU5ETyBaVU1BRVRBIENIQVZFWjELMAkGA1UEBhMCUEUwggEiMA0GCSqGSIb3DQEBAQUAA4IBDwAwggEKAoIBAQDd0xuO5hiWL6iFR5aBcWIMTrpr44069mzKPyjsKuu+vz4vg7rbt/s/0XFgCM6dp6kno1Uk5OyuYLTzD2K0pJZw2sHQDcDT5AzEhHEcAtnjRYUytulI/8ls3optXKfKaNBnIQ0bj33ggxOhcJamdEoa7NhhFi0QsgejxD0OixJfvPLvcMDz2I76f6eLM+sjk/wjwSqDo2SFHy3LSD/XqAjfspf13PGIRArwkQm4S3p0ImkOFXfN1aP0+QMH/EJ5zkVDG6eWRZWrij7exx64WR+PdCvVT0m9Edb8WQ7A6G/2XCh0uTzeDnBWQO1bwK3E2jh3z+/wecfcWSQ8odnKMPy5AgMBAAGjggLJMIICxTAMBgNVHRMBAf8EAjAAMBEGCWCGSAGG+EIBAQQEAwIFoDAOBgNVHQ8BAf8EBAMCBsAwHQYDVR0lBBYwFAYIKwYBBQUHAwIGCCsGAQUFBwMEMB0GA1UdDgQWBBTxV10WX2aXQ4qxUR7K784d+Qdb0zBtBggrBgEFBQcBAQRhMF8wNQYIKwYBBQUHMAKGKWh0dHA6Ly93d3cuY2FtZXJmaXJtYS5jb20vY2VydHMvcmFjZXIuY3J0MCYGCCsGAQUFBzABhhpodHRwOi8vb2NzcC5jYW1lcmZpcm1hLmNvbTCB8wYDVR0jBIHrMIHogBS+vAjULroATIDcJme0pdjdw0oa+aGBzKSByTCBxjELMAkGA1UEBhMCRVMxKzApBgkqhkiG9w0BCQEWHGFjX2NhbWVyZmlybWFAY2FtZXJmaXJtYS5jb20xEjAQBgNVBAUTCUE4Mjc0MzI4NzFDMEEGA1UEBxM6TWFkcmlkIChzZWUgY3VycmVudCBhZGRyZXNzIGF0IHd3dy5jYW1lcmZpcm1hLmNvbS9hZGRyZXNzKTEZMBcGA1UEChMQQUMgQ2FtZXJmaXJtYSBTQTEWMBQGA1UEAxMNQUMgQ2FtZXJmaXJtYYIBATBkBgNVHR8EXTBbMCugKaAnhiVodHRwOi8vY3JsLmNhbWVyZmlybWEuY29tL3JhY2VyX2YuY3JsMCygKqAohiZodHRwOi8vY3JsMS5jYW1lcmZpcm1hLmNvbS9yYWNlcl9mLmNybDAhBgNVHRIEGjAYgRZjYXJhY2VyQGNhbWVyZmlybWEuY29tMB0GA1UdEQQWMBSBEmp1YW4ubGl6YW1hQGdudC5wZTBHBgNVHSAEQDA+MDwGDSsGAQQBgYcuCggCAQEwKzApBggrBgEFBQcCARYdaHR0cHM6Ly9wb2xpY3kuY2FtZXJmaXJtYS5jb20wDQYJKoZIhvcNAQELBQADggEBAHNQ1HSt1pZlnJfU+9nrKtUTB26yrDxn4OWUCZQEemsSbzeYjmBDspeVIfLSBaqLwjaR0yJO5iydB3N2ZCx8pbsDjnDRliOW3UbYsGYfDMuWSql0FypW9AerKbecPIhdenlL5GrpIyWkY6kpgyTz1qH7i27qtOWUVl5WtJ9OHKBg3p8OOkgNyRfi4QuZG7BClJU5IK6mRR6sar+JMnh/zR6kN5yw9DkYYSEOd7i2OJqLPx4Ms2nu2TWcRnfNSXRIDCc33xA1xxJS3NgUZTFuiIBzJm7JCtMTbPkZFD+Qgki6cS0EY2SdpgD0NNwkRxX+GEXr7ea5n9QkE1SitwjdfhU=</X509Certificate></X509Data></KeyInfo></Signature></ext:ExtensionContent></ext:UBLExtension></ext:UBLExtensions><cbc:UBLVersionID>2.1</cbc:UBLVersionID><cbc:CustomizationID>2.0</cbc:CustomizationID><cbc:ID>F011-00000824</cbc:ID><cbc:IssueDate>2018-06-27</cbc:IssueDate><cbc:DueDate>2018-07-12</cbc:DueDate><cbc:InvoiceTypeCode listAgencyName=\"PE:SUNAT\" listName=\"SUNAT:Identificador de Tipo de Documento\" listURI=\"urn:pe:gob:sunat:cpe:see:gem:catalogos:catalogo01\" listID=\"0101\" name=\"Tipo de Operacion\" listSchemeURI=\"urn:pe:gob:sunat:cpe:see:gem:catalogos:catalogo51\">01</cbc:InvoiceTypeCode><cbc:Note languageLocaleID=\"1000\">CIENTO SESENTA  CON 48.00/100 SOLES</cbc:Note><cbc:DocumentCurrencyCode listID=\"ISO 4217 Alpha\" listName=\"Currency\" listAgencyName=\"United Nations Economic Commission for Europe\">PEN</cbc:DocumentCurrencyCode><cbc:LineCountNumeric>2</cbc:LineCountNumeric><cac:Signature><cbc:ID>IDSign20253319403</cbc:ID><cac:SignatoryParty><cac:PartyIdentification><cbc:ID>20253319403</cbc:ID></cac:PartyIdentification><cac:PartyName><cbc:Name><![CDATA[NEW TRANSPORT S.A.]]></cbc:Name></cac:PartyName></cac:SignatoryParty><cac:DigitalSignatureAttachment><cac:ExternalReference><cbc:URI>Signature20253319403</cbc:URI></cac:ExternalReference></cac:DigitalSignatureAttachment></cac:Signature><cac:AccountingSupplierParty><cac:Party><cac:PartyName><cbc:Name><![CDATA[NEW]]></cbc:Name></cac:PartyName><cac:PartyTaxScheme><cbc:RegistrationName><![CDATA[NEW TRANSPORT S.A.]]></cbc:RegistrationName><cbc:CompanyID schemeID=\"6\" schemeName=\"SUNAT:Identificador de Documento de Identidad\" schemeAgencyName=\"PE:SUNAT\" schemeURI=\"urn:pe:gob:sunat:cpe:see:gem:catalogos:catalogo06\">20253319403</cbc:CompanyID><cac:RegistrationAddress><cbc:AddressTypeCode>0001</cbc:AddressTypeCode></cac:RegistrationAddress><cac:TaxScheme><cbc:ID>-</cbc:ID></cac:TaxScheme></cac:PartyTaxScheme><cac:PartyLegalEntity><cbc:RegistrationName><![CDATA[NEW TRANSPORT S.A.]]></cbc:RegistrationName><cac:RegistrationAddress><cbc:ID schemeName=\"Ubigeos\" schemeAgencyName=\"PE:INEI\">150122</cbc:ID><cbc:AddressTypeCode>0001</cbc:AddressTypeCode><cbc:CityName>LIMA</cbc:CityName><cbc:CountrySubentity>LIMA</cbc:CountrySubentity><cbc:District>MIRAFLORES</cbc:District><cac:AddressLine><cbc:Line>AV. ROOSEVELT N� 5790 INT. 5</cbc:Line></cac:AddressLine><cac:Country><cbc:IdentificationCode listID=\"ISO 3166-1\" listAgencyName=\"United Nations Economic Commission for Europe\" listName=\"Country\">PE</cbc:IdentificationCode></cac:Country></cac:RegistrationAddress></cac:PartyLegalEntity></cac:Party></cac:AccountingSupplierParty><cac:AccountingCustomerParty><cac:Party><cac:PostalAddress><cbc:ID schemeID=\"GLN\" schemeAgencyID=\"9\">1238764941386</cbc:ID><cbc:StreetName><![CDATA[CAL.LOS GORRIONES NRO. 150 URB. LIMATAMBO SAN ISIDRO]]></cbc:StreetName></cac:PostalAddress><cac:PartyTaxScheme><cbc:RegistrationName><![CDATA[JDA INTERNATIONAL S.A.C.]]></cbc:RegistrationName><cbc:CompanyID schemeID=\"6\" schemeName=\"SUNAT:Identificador de Documento de Identidad\" schemeAgencyName=\"PE:SUNAT\" schemeURI=\"urn:pe:gob:sunat:cpe:see:gem:catalogos:catalogo06\">20600521579</cbc:CompanyID><cac:TaxScheme><cbc:ID>-</cbc:ID></cac:TaxScheme></cac:PartyTaxScheme></cac:Party></cac:AccountingCustomerParty><cac:TaxTotal><cbc:TaxAmount currencyID=\"PEN\">24.48</cbc:TaxAmount><cac:TaxSubtotal><cbc:TaxableAmount currencyID=\"PEN\">136.00</cbc:TaxableAmount><cbc:TaxAmount currencyID=\"PEN\">24.48</cbc:TaxAmount><cac:TaxCategory><cbc:ID schemeID=\"UN/ECE 5305\" schemeName=\"Tax Category Identifier\" schemeAgencyName=\"United Nations Economic Commission for Europe\">S</cbc:ID><cac:TaxScheme><cbc:ID schemeID=\"UN/ECE 5305\" schemeAgencyID=\"6\">1000</cbc:ID><cbc:Name>IGV</cbc:Name><cbc:TaxTypeCode>VAT</cbc:TaxTypeCode></cac:TaxScheme></cac:TaxCategory></cac:TaxSubtotal></cac:TaxTotal><cac:LegalMonetaryTotal><cbc:LineExtensionAmount currencyID=\"PEN\">136.00</cbc:LineExtensionAmount><cbc:TaxInclusiveAmount currencyID=\"PEN\">160.48</cbc:TaxInclusiveAmount><cbc:PayableAmount currencyID=\"PEN\">160.48</cbc:PayableAmount></cac:LegalMonetaryTotal><cac:InvoiceLine><cbc:ID>1</cbc:ID><cbc:InvoicedQuantity unitCode=\"C81\" unitCodeListID=\"UN/ECE rec 20\" unitCodeListAgencyName=\"United Nations Economic Commission for Europe\">1.000</cbc:InvoicedQuantity><cbc:LineExtensionAmount currencyID=\"PEN\">55.00</cbc:LineExtensionAmount><cac:PricingReference><cac:AlternativeConditionPrice><cbc:PriceAmount currencyID=\"PEN\">64.90</cbc:PriceAmount><cbc:PriceTypeCode listName=\"SUNAT:Indicador de Tipo de Precio\" listAgencyName=\"PE:SUNAT\" listURI=\"urn:pe:gob:sunat:cpe:see:gem:catalogos:catalogo16\">01</cbc:PriceTypeCode></cac:AlternativeConditionPrice></cac:PricingReference><cac:TaxTotal><cbc:TaxAmount currencyID=\"PEN\">9.90</cbc:TaxAmount><cac:TaxSubtotal><cbc:TaxableAmount currencyID=\"PEN\">55.00</cbc:TaxableAmount><cbc:TaxAmount currencyID=\"PEN\">9.90</cbc:TaxAmount><cac:TaxCategory><cbc:ID schemeID=\"UN/ECE 5305\" schemeName=\"Tax Category Identifier\" schemeAgencyName=\"United Nations Economic Commission for Europe\">S</cbc:ID><cbc:Percent>18.00</cbc:Percent><cbc:TaxExemptionReasonCode listAgencyName=\"PE:SUNAT\" listName=\"SUNAT:Codigo de Tipo de Afectaci�n del IGV\" listURI=\"urn:pe:gob:sunat:cpe:see:gem:catalogos:catalogo07\">10</cbc:TaxExemptionReasonCode><cac:TaxScheme><cbc:ID schemeID=\"UN/ECE 5153\" schemeName=\"Tax Scheme Identifier\" schemeAgencyName=\"United Nations Economic Commission for Europe\">1000</cbc:ID><cbc:Name>IGV</cbc:Name><cbc:TaxTypeCode>VAT</cbc:TaxTypeCode></cac:TaxScheme></cac:TaxCategory></cac:TaxSubtotal></cac:TaxTotal><cac:Item><cbc:Description><![CDATA[HANDLING EXPORTACION]]></cbc:Description><cac:SellersItemIdentification><cbc:ID>424</cbc:ID></cac:SellersItemIdentification></cac:Item><cac:Price><cbc:PriceAmount currencyID=\"PEN\">55.000000</cbc:PriceAmount></cac:Price></cac:InvoiceLine><cac:InvoiceLine><cbc:ID>2</cbc:ID><cbc:InvoicedQuantity unitCode=\"C81\" unitCodeListID=\"UN/ECE rec 20\" unitCodeListAgencyName=\"United Nations Economic Commission for Europe\">1.000</cbc:InvoicedQuantity><cbc:LineExtensionAmount currencyID=\"PEN\">81.00</cbc:LineExtensionAmount><cac:PricingReference><cac:AlternativeConditionPrice><cbc:PriceAmount currencyID=\"PEN\">95.58</cbc:PriceAmount><cbc:PriceTypeCode listName=\"SUNAT:Indicador de Tipo de Precio\" listAgencyName=\"PE:SUNAT\" listURI=\"urn:pe:gob:sunat:cpe:see:gem:catalogos:catalogo16\">01</cbc:PriceTypeCode></cac:AlternativeConditionPrice></cac:PricingReference><cac:TaxTotal><cbc:TaxAmount currencyID=\"PEN\">14.58</cbc:TaxAmount><cac:TaxSubtotal><cbc:TaxableAmount currencyID=\"PEN\">81.00</cbc:TaxableAmount><cbc:TaxAmount currencyID=\"PEN\">14.58</cbc:TaxAmount><cac:TaxCategory><cbc:ID schemeID=\"UN/ECE 5305\" schemeName=\"Tax Category Identifier\" schemeAgencyName=\"United Nations Economic Commission for Europe\">S</cbc:ID><cbc:Percent>18.00</cbc:Percent><cbc:TaxExemptionReasonCode listAgencyName=\"PE:SUNAT\" listName=\"SUNAT:Codigo de Tipo de Afectaci�n del IGV\" listURI=\"urn:pe:gob:sunat:cpe:see:gem:catalogos:catalogo07\">10</cbc:TaxExemptionReasonCode><cac:TaxScheme><cbc:ID schemeID=\"UN/ECE 5153\" schemeName=\"Tax Scheme Identifier\" schemeAgencyName=\"United Nations Economic Commission for Europe\">1000</cbc:ID><cbc:Name>IGV</cbc:Name><cbc:TaxTypeCode>VAT</cbc:TaxTypeCode></cac:TaxScheme></cac:TaxCategory></cac:TaxSubtotal></cac:TaxTotal><cac:Item><cbc:Description><![CDATA[ADUANA]]></cbc:Description><cbc:Description><![CDATA[AWB/HAWB: 36970942616]]></cbc:Description><cbc:Description><![CDATA[FECHA EMBARQUE: 26/06/2018]]></cbc:Description><cbc:Description><![CDATA[CONSIGNATARIO: CONSOLIDATED FARMS INC.DBA]]></cbc:Description><cbc:Description><![CDATA[FACTURA COMERCIAL:]]></cbc:Description><cac:SellersItemIdentification><cbc:ID>437</cbc:ID></cac:SellersItemIdentification></cac:Item><cac:Price><cbc:PriceAmount currencyID=\"PEN\">81.000000</cbc:PriceAmount></cac:Price></cac:InvoiceLine></Invoice>"
	 * ;
	 * 
	 * return respuesta;
	 * 
	 * } catch (PortalSystemException e) { log.error(
	 * "Error PortalSystemException : ", e); throw new ServiceException(this,
	 * "El documento con n�mero de serie " + numSerieCpe + "-" + numCpe +
	 * " no ha sido informado a SUNAT."); } catch (PortalProblemException e) {
	 * log.error("Error PortalProblemException : ", e); throw new
	 * ServiceException(this, "El documento con n�mero de serie " + numSerieCpe
	 * + "-" + numCpe + " no ha sido informado a SUNAT."); }
	 * 
	 * }
	 */

	public static byte[] zipBytes(String filename, byte[] input) throws IOException {
		ByteArrayOutputStream baos = new ByteArrayOutputStream();
		ZipOutputStream zos = new ZipOutputStream(baos);
		ZipEntry entry = new ZipEntry(filename);
		entry.setSize(input.length);
		zos.putNextEntry(entry);
		zos.write(input);
		zos.closeEntry();
		zos.close();
		return baos.toByteArray();
	}

	public byte[] decompress(byte[] data) {

		try {

			InputStream theFile = new ByteArrayInputStream(data);
			ZipInputStream stream = new ZipInputStream(theFile);
			log.debug("decompress data.length: (" + data.length + "). stream : (" + stream.toString().length()
					+ "). stream string : (" + stream.toString() + ")");
			byte[] buffer = new byte[2048];
			ByteArrayOutputStream outputStream = new ByteArrayOutputStream(data.length);

			ZipEntry entry;
			while ((entry = stream.getNextEntry()) != null) {
				String s = String.format("Entry: %s len %d added %TD", entry.getName(), entry.getSize(),
						new Date(entry.getTime()));
				if (log.isDebugEnabled())
					log.debug(s);
				/*
				 * PAS20171U210300083 En el caso del OSE ademas del XML envia su
				 * CDR por ello debemos extraer solo el CPE
				 */
				if (entry.getName().indexOf("R-") == -1) {
					if (log.isDebugEnabled())
						log.debug("decompress Ingresa el xml");
					try {
						outputStream = new ByteArrayOutputStream();
						int len = 0;
						while ((len = stream.read(buffer)) > 0) {
							outputStream.write(buffer, 0, len);
							log.debug("decompress outputStream.write: (" + outputStream.toString("ISO-8859-1") + ")");
						}
					} finally {
						if (outputStream != null)
							outputStream.close();
					}
				} //
			}

			byte[] output = outputStream.toByteArray();
			log.debug("decompress output: (" + new ByteArrayInputStream(output).toString() + ")");
			return output;
		} catch (IOException e) {
			log.error(">>decompress ConsultarServiceImpl Error !! " + e.getMessage(), e);
			MensajeBean msg = new MensajeBean();
			msg.setError(true);
			msg.setMensajeerror("decompress Error al tratar de descomprimir el archivo ZIP");
			throw new ServiceException(this, msg);
		}

	}
}
