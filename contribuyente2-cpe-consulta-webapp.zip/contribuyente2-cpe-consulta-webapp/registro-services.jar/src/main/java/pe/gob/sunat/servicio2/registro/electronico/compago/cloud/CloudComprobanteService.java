package pe.gob.sunat.servicio2.registro.electronico.compago.cloud;

import java.io.IOException;

import pe.gob.sunat.cpe.portal.cloud.exception.AccessTokenException;

public interface CloudComprobanteService {
	public void inicializarVariablesCpes() throws AccessTokenException;
	public void inicializarVariablesOperaciones() throws AccessTokenException;
	public void inicializarVariablesCustodia() throws AccessTokenException;
	public void inicializarVariablesConsultasCloud();
	public String[] firmarComprobanteCloud(String cpeid, String fileName, String cpeXml) throws IOException;
	public boolean rechazarComprobanteCloud(String cpeid);
	public String[] consultarComprobanteCloud(String cpeid);
	public byte[] consultarComprobanteCloudv2_0(String cpeid);
	public boolean esVigenteTokenCpes() throws Exception;
	public boolean esVigenteTokenOperaciones() throws Exception;
	public boolean esVigenteTokenCustodia() throws Exception;
}