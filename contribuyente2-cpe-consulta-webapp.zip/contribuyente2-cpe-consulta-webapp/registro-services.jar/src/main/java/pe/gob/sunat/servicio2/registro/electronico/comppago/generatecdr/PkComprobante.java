package pe.gob.sunat.servicio2.registro.electronico.comppago.generatecdr;

public class PkComprobante {

	public PkComprobante () {
		
	}
	
	public PkComprobante(String numRuc, String codCpe, String numSerieCpe,
			String numCpe) {
		super();
		this.numRuc = numRuc;
		this.codCpe = codCpe;
		this.numSerieCpe = numSerieCpe;
		this.numCpe = numCpe;
	}

	private String numRuc;
	private String codCpe;
	private String numSerieCpe;
	private String numCpe;

	public String getNumRuc() {
		return numRuc;
	}

	public void setNumRuc(String numRuc) {
		this.numRuc = numRuc;
	}

	public String getCodCpe() {
		return codCpe;
	}

	public void setCodCpe(String codCpe) {
		this.codCpe = codCpe;
	}

	public String getNumSerieCpe() {
		return numSerieCpe;
	}

	public void setNumSerieCpe(String numSerieCpe) {
		this.numSerieCpe = numSerieCpe;
	}

	public String getNumCpe() {
		return numCpe;
	}

	public void setNumCpe(String numCpe) {
		this.numCpe = numCpe;
	}

	@Override
	public String toString() {
		// ruc-cpdcpe-numserie-numcpe
		String pkFromat = "%s-%s-%s-%s";
		return String.format(pkFromat, numRuc, codCpe, numSerieCpe, numCpe);
	}

}
