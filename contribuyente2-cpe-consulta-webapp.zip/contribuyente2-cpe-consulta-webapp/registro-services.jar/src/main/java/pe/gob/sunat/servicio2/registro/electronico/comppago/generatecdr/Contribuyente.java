package pe.gob.sunat.servicio2.registro.electronico.comppago.generatecdr;

import java.io.Serializable;

public class Contribuyente implements Serializable{

	private static final long serialVersionUID = 7506897816577645269L;
	
	private String numDocIdentidad;
	
	private String codTipoDoc;
	
	private String desTipoDoc;
	
	private String razonSocial;
	
	private String nombreComercial;
	
	//private Ubigeo ubigeo;

	
	public Contribuyente(String codTipoDoc,
			String numDocIdentidad, String razonSocial) {
		this.codTipoDoc = codTipoDoc;
		this.numDocIdentidad = numDocIdentidad;
		this.razonSocial = razonSocial;
	}

	public String getNumDocIdentidad() {
		return numDocIdentidad;
	}

	public void setNumDocIdentidad(String numDocIdentidad) {
		this.numDocIdentidad = numDocIdentidad;
	}

	public String getCodTipoDoc() {
		return codTipoDoc;
	}

	public void setCodTipoDoc(String codTipoDoc) {
		this.codTipoDoc = codTipoDoc;
	}

	public String getDesTipoDoc() {
		return desTipoDoc;
	}

	public void setDesTipoDoc(String desTipoDoc) {
		this.desTipoDoc = desTipoDoc;
	}

	public String getRazonSocial() {
		return razonSocial;
	}

	public void setRazonSocial(String razonSocial) {
		this.razonSocial = razonSocial;
	}

	public String getNombreComercial() {
		return nombreComercial;
	}

	public void setNombreComercial(String nombreComercial) {
		this.nombreComercial = nombreComercial;
	}

//	public Ubigeo getUbigeo() {
//		return ubigeo;
//	}
//
//	public void setUbigeo(Ubigeo ubigeo) {
//		this.ubigeo = ubigeo;
//	}


}
