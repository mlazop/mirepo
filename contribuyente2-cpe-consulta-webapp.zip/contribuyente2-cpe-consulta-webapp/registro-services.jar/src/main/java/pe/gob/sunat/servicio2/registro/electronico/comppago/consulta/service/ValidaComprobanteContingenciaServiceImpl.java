package pe.gob.sunat.servicio2.registro.electronico.comppago.consulta.service;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import pe.gob.sunat.framework.spring.util.date.FechaBean;
import pe.gob.sunat.framework.spring.util.exception.ServiceException;
import pe.gob.sunat.servicio2.registro.comppago.factura.gem.contingencia.model.dao.T5676DAO;
import pe.gob.sunat.servicio2.registro.comppago.factura.gem.contingencia.model.domain.T5676Bean;
import pe.gob.sunat.servicio2.registro.comppago.factura.gem.contingencia.model.domain.T5676QueryParameterBean;
import pe.gob.sunat.servicio2.registro.electronico.comppago.model.domain.T3639Bean;

@SuppressWarnings({"rawtypes"})
public class ValidaComprobanteContingenciaServiceImpl implements ValidaComprobanteContingenciaService {

	private static final Log log = LogFactory.getLog(ValidaCoprobanteElectronicoServiceImpl.class);
    private T5676DAO t5676DAO  ;   
	
	public T5676DAO getT5676DAO() {
		return t5676DAO;
	}

	public void setT5676DAO(T5676DAO t5676dao) {
		t5676DAO = t5676dao;
	}

	@Override
	public Map consultaValidezCPC(Map<String, String> data) {
		
		if(log.isDebugEnabled()) log.debug("ValidaComprobanteContingenciaServiceImpl.consultaValidezCPC - Inic");
		
		String tipoComprobante = data.get("tipocomprobante").toString();
		
		Map<String,Object> result = null ;
    	try {
    		if (tipoComprobante != null && tipoComprobante.length()>0){
 
    			Map<String,String> rptaValidez = new HashMap<String, String>();
    			// Valida que sea uno de los tipos de comprobante regisrados en contingencia 
    			if ("01".equals(tipoComprobante) || "03".equals(tipoComprobante)|| "07".equals(tipoComprobante)|| "08".equals(tipoComprobante) || "12".equals(tipoComprobante) ) {
    				rptaValidez = buscarCPC(data);
    			}else 
    				throw new ServiceException(this, "El tipo de comprobante para la consulta no es el correcto, por favor seleccione uno de los tipos de comprobante valido.");
    			result=new HashMap<String, Object>();
    			result.put("resp", rptaValidez);
    		}else
    			throw new ServiceException(this, "Por favor seleccionar el tipo de comprobante para realizar la consulta");
    		
		}catch(ServiceException se){
			log.error(se,se);
			throw new ServiceException(this,se.getMessage());
    	}catch (Exception e) {
    		log.error(e,e);
    		throw new ServiceException(this,e.getMessage());
		}
    	
    	if(log.isDebugEnabled()) log.debug("ValidaComprobanteContingenciaServiceImpl.consultaValidezCPC - Fin");
    	
    	return result ;
	}
	
	private List<String> cerosIzquierda(String nroCpe) {
		if(log.isDebugEnabled()) log.debug("cerosIzq - Inic : " + nroCpe);
		int maxLenght = 20;
		List auxValores = new ArrayList<String>();
		
		int size = nroCpe.length();
		
		int count = 0;
		for (int i = size; i < maxLenght; i++) {
			String aux = "";
			for (int j = 0; j < count; j++) {
				aux = "0" + aux;
			}
			aux = aux + nroCpe;
			auxValores.add(aux);
			count++;
			
		}
		
		if(log.isDebugEnabled()) log.debug("cerosIzq - Fin : " + auxValores.toArray().toString());
		
		return auxValores;
	}
	
	private Map<String,String> buscarCPC(Map<String,String> datos)throws ServiceException{
		
		if(log.isDebugEnabled()) log.debug("ValidaComprobanteContingenciaServiceImpl.buscarCPC - Inic");
		
	    	Map<String,String> result = new HashMap<String, String>() ;
	    	T3639Bean  beanIn = new T3639Bean();
	    	//T3639Bean  beanOu = new T3639Bean();
	    	beanIn.setNum_ruc(datos.get("num_ruc"));
	    	beanIn.setCod_docide(datos.get("cod_docide")!=null && !datos.get("cod_docide").toString().trim().equals("-") ? datos.get("cod_docide") : null );
	    	beanIn.setNum_docide(datos.get("num_docide")!=null && !datos.get("num_docide").toString().trim().equals("-") ? datos.get("num_docide") : null );
	    	beanIn.setNum_serie(datos.get("num_serie").trim());
	    	beanIn.setNum_comprob(new Integer(datos.get("num_comprob")));
	    	beanIn.setFec_emision_rec(new FechaBean(datos.get("fec_emision")).getSQLDate());
	    	beanIn.setMto_bruto(new BigDecimal(datos.get("cantidad")));
	    	
		    try {
				
		    
			    T5676QueryParameterBean t5676QueryParameterBean = new T5676QueryParameterBean();
			    t5676QueryParameterBean.setNumeroRUC(datos.get("num_ruc"));
			    t5676QueryParameterBean.setTipoComprobante(datos.get("tipocomprobante"));
			    t5676QueryParameterBean.setSerieComprobante(datos.get("num_serie"));
			    if (t5676QueryParameterBean.getTipoComprobante().equals("12")){
			    	t5676QueryParameterBean.setNumeComprobanteDesde(datos.get("num_comprob"));
			    } else {
			    	t5676QueryParameterBean.setNumeComprobante(cerosIzquierda(datos.get("num_comprob")));
			    }
			    
			    String strCantidad=datos.get("cantidad");
			    BigDecimal bdcCantidad=new BigDecimal(strCantidad);
			    t5676QueryParameterBean.setMontoTotal(bdcCantidad);
			    
			    t5676QueryParameterBean.setTipoDocumentoIdentidad(datos.get("cod_docide"));
			    t5676QueryParameterBean.setNumeroDocuIdencliente(datos.get("num_docide"));
			    t5676QueryParameterBean.setNumeroRUC(datos.get("num_ruc"));
			    
			    FechaBean fecEmi = new FechaBean(datos.get("fec_emision"));
			    t5676QueryParameterBean.setFechaEmision(fecEmi);

			    
		    	List<T5676Bean> lstT5676Bean  =  t5676DAO.obtenerValidacionComprobantesContingencia(t5676QueryParameterBean);
		    	
			    if (lstT5676Bean.size()>0)
			    {
			    	 result.put("titulo", "EL COMPROBANTE CARGADO COMO ENVIO RESUMEN(CONTINGENCIA)  Nro." +beanIn.getNum_serie()+ "-" +beanIn.getNum_comprob()+ " CONSULTADO, ES VALIDO.");
			    }
			    else
			    {
			    	result.put("titulo", "No se encontro registrado el comprobante con los criterios ingresados.");
			    }
			} catch (Exception e) {
				result.put("titulo", "No se encontro registrado el comprobante con los criterios ingresados.");
			}

		if(log.isDebugEnabled()) log.debug("ValidaComprobanteContingenciaServiceImpl.buscarCPC - Fin");
		    
	    return result ;
	}
}
