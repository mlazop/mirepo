package pe.gob.sunat.framework.spring.web.util;

import net.sf.json.JsonConfig;
import net.sf.json.util.PropertyFilter;

public class JsonUtil {
	public static JsonConfig getJsonNoNull() {
		JsonConfig jsonConfig = new JsonConfig();
		jsonConfig.setJsonPropertyFilter(new PropertyFilter() {   
			public boolean apply(Object source, String name, Object value) {   
				if(value == null) return true;
				return false;   
			}
		});
		return jsonConfig;
	}
	
	public static JsonConfig getJsonNoNameVar(String var) {
		JsonConfig jsonConfig = new JsonConfig();
		final String element = var; 
		jsonConfig.setJsonPropertyFilter(new PropertyFilter() {   
			public boolean apply(Object source, String name, Object value) {   
				if(value == null || name.equals(element)) return true;
				return false;   
			}
		});
		return jsonConfig;
	}
	
	public static JsonConfig getJsonNoClass(Class<?> aClass) {
		JsonConfig jsonConfig = new JsonConfig();
		final Class<?> tClass = aClass; 
		jsonConfig.setJsonPropertyFilter(new PropertyFilter() {   
			public boolean apply(Object source, String name, Object value) {
				if(value == null || tClass.isInstance(value)) return true;
				return false;   
			}
		});
		return jsonConfig;
	}
}
