package pe.gob.sunat.framework.spring.security.service;

import java.util.Map;

import org.w3c.dom.Document;
import org.w3c.dom.Node;

import pe.gob.sunat.framework.spring.security.util.SignAndValid;

@SuppressWarnings("rawtypes")
public class DigitalCertificateServiceImpl implements DigitalCertificateService {
	private SignAndValid signAndValid;
	
	public SignAndValid getSignAndValid() {
		return this.signAndValid;
	}

	public void setSignAndValid(SignAndValid signAndValid) {
		this.signAndValid = signAndValid;
	}
	
	public DigitalCertificateServiceImpl() {
		
	}
	
	public void firmaDocumentoXml(Document doc, Node nodeSign, String idReference) {
		this.signAndValid.sign(new Object[]{doc, nodeSign, idReference});
	}
	public void firmaDocumentoXmlLibro(Document doc, Node nodeSign, String idReference) {
		this.signAndValid.signLibro(new Object[]{doc, nodeSign, idReference});
	}
	
	public void firmaDocumentoXmlLibro(Document doc, Node nodeSign, String idReference, Map mldap) {
		this.signAndValid.signLibro(new Object[]{doc, nodeSign,  mldap,idReference});
	}
	
	
}
