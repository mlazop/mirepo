package pe.gob.sunat.servicio2.registro.electronico.comppago.factura.consultar.bean;

import java.io.Serializable;


public class ConsultarFacturaBean implements Serializable {
	private static final long serialVersionUID = -454024842399649320L;
	
	String id;
	String nroSerie;
	String nroFactura;
	String codFactura;
	String nroRucEmisor;
	String nroRucReceptor;
	String codigoMoneda;
	String numeroIdXml;
	
	String nroFacturaDesc;
	String nroRucEmisorDesc;
	String nroRucReceptorDesc;
	String importeTotalDesc;
	String codigoMonedaDesc;
	String fechaEmisionDesc;
	String fechaRechazoDesc;	

	String tipoCPE;	

	String comprobantePorElQueSeEmite;
	/* Ini :: JFCZ Mayo 2012 */
	String indEstado ; 
	String estadoDesc ;  
	String fechaEstado ; 
	/* Fin :: JFCZ Mayo 2012 */
	
	//PCR 10/2012
	String ind_emisionNC21;
	String idPDF;
	String nombrePDF;
	
	public String getNombrePDF() {
		return nombrePDF;
	}
	public void setNombrePDF(String nombrePDF) {
		this.nombrePDF = nombrePDF;
	}
	public String getIdPDF() {
		return idPDF;
	}
	public void setIdPDF(String idPDF) {
		this.idPDF = idPDF;
	}
	public String getInd_emisionNC21() {
		return ind_emisionNC21;
	}
	public void setInd_emisionNC21(String indEmisionNC21) {
		ind_emisionNC21 = indEmisionNC21;
	}
	public String getComprobantePorElQueSeEmite() {
		return comprobantePorElQueSeEmite;
	}
	public void setComprobantePorElQueSeEmite(
			String comprobantePorElQueSeEmite) {
		this.comprobantePorElQueSeEmite = comprobantePorElQueSeEmite;
	}
	
	public String getTipoCPE() {
		return tipoCPE;
	}
	public void setTipoCPE(String tipoCPE) {
		this.tipoCPE = tipoCPE;
	}
	public String getNroSerie() {
		return nroSerie;
	}
	public void setNroSerie(String nroSerie) {
		this.nroSerie = nroSerie;
	}
	public String getNroRucEmisor() {
		return nroRucEmisor;
	}
	public void setNroRucEmisor(String nroRucEmisor) {
		this.nroRucEmisor = nroRucEmisor;
	}
	public String getNroRucEmisorDesc() {
		return nroRucEmisorDesc;
	}
	public void setNroRucEmisorDesc(String nroRucEmisorDesc) {
		this.nroRucEmisorDesc = nroRucEmisorDesc;
	}
	public String getCodigoMoneda() {
		return codigoMoneda;
	}
	public void setCodigoMoneda(String codigoMoneda) {
		this.codigoMoneda = codigoMoneda;
	}
	public String getImporteTotalDesc() {
		return importeTotalDesc;
	}
	public void setImporteTotalDesc(String importeTotalDesc) {
		this.importeTotalDesc = importeTotalDesc;
	}
	public String getCodigoMonedaDesc() {
		return codigoMonedaDesc;
	}
	public void setCodigoMonedaDesc(String codigoMonedaDesc) {
		this.codigoMonedaDesc = codigoMonedaDesc;
	}
	public String getFechaEmisionDesc() {
		return fechaEmisionDesc;
	}
	public void setFechaEmisionDesc(String fechaEmisionDesc) {
		this.fechaEmisionDesc = fechaEmisionDesc;
	}
	public String getFechaRechazoDesc() {
		return fechaRechazoDesc;
	}
	public void setFechaRechazoDesc(String fechaRechazoDesc) {
		this.fechaRechazoDesc = fechaRechazoDesc;
	}
	public String getNroFactura() {
		return nroFactura;
	}
	public void setNroFactura(String nroFactura) {
		this.nroFactura = nroFactura;
	}
	public String getNroFacturaDesc() {
		return nroFacturaDesc;
	}
	public void setNroFacturaDesc(String nroFacturaDesc) {
		this.nroFacturaDesc = nroFacturaDesc;
	}
	public String getNumeroIdXml() {
		return numeroIdXml;
	}
	public void setNumeroIdXml(String numeroIdXml) {
		this.numeroIdXml = numeroIdXml;
	}
	public String getId() {
		return id;
	}
	public String getIndEstado() {
		return indEstado;
	}
	public void setIndEstado(String indEstado) {
		this.indEstado = indEstado;
	}
	public void setId(String id) {
		this.id = id;
	}
	public String getCodFactura() {
		return codFactura;
	}
	public void setCodFactura(String codFactura) {
		this.codFactura = codFactura;
	}
	public String getNroRucReceptor() {
		return nroRucReceptor;
	}
	public void setNroRucReceptor(String nroRucReceptor) {
		this.nroRucReceptor = nroRucReceptor;
	}
	public String getNroRucReceptorDesc() {
		return nroRucReceptorDesc;
	}
	public void setNroRucReceptorDesc(String nroRucReceptorDesc) {
		this.nroRucReceptorDesc = nroRucReceptorDesc;
	}
	public String getEstadoDesc() {
		return estadoDesc;
	}
	public String getFechaEstado() {
		return fechaEstado;
	}
	public void setEstadoDesc(String estadoDesc) {
		this.estadoDesc = estadoDesc;
	}
	public void setFechaEstado(String fechaEstado) {
		this.fechaEstado = fechaEstado;
	}

}
