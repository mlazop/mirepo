package pe.gob.sunat.tecnologia2.validadoc.exception;

import java.util.Date;

/**
 * @author fjonislla
 *
 */
public class ValidateSignException extends Exception{
	
	private static final long serialVersionUID = -5163797866509123743L;
	private int resultCode;
	private Date certificateLastValidDate;
	
	public ValidateSignException(int resultCode, String message, Date certificateLastValidDate) {
		super(message);
		this.resultCode = resultCode;
		this.certificateLastValidDate = certificateLastValidDate;
	}

	public ValidateSignException(int resultCode, String message) {
		super(message);
		this.resultCode = resultCode;
	}

	public int getResultCode() {
		return resultCode;
	}

	public Date getCertificateLastValidDate() {
		return certificateLastValidDate;
	}
	
	
	

}
