package pe.gob.sunat.servicio2.registro.electronico.comppago.util;

import java.math.BigDecimal;
import java.math.BigInteger;
import java.text.DecimalFormat;
import java.text.DecimalFormatSymbols;
import java.text.NumberFormat;
import java.text.ParseException;
import java.util.Locale;

import org.apache.commons.lang.StringUtils;

import pe.gob.sunat.framework.spring.util.date.FechaBean;

public final class ComprobanteUtil {
	public static final String FACTURA = "01";
	public static final String BOLETA = "03";
	public static final String NOTA_CREDITO = "07";
	public static final String NOTA_DEBITO = "08";
	public static final String IGV = "010101";
	public static final String ISC = "020000";
	public static final String IVAP = "010106";
	public static final String GUIA_REMISION = "01";
	public static final String GUIA_TRANSPORTISTA = "02";
	public static final int LONGITUD_DECIMAL = 2;
	private static String[] cCero = {"CERO"};
	private static String[] cUnidades = {"UNO","DOS","TRES","CUATRO","CINCO","SEIS","SIETE","OCHO","NUEVE"};
	private static String[] cEspeciales = {"ONCE","DOCE","TRECE","CATORCE","QUINCE","DIECISEIS","DIECISIETE","DIECIOCHO","DIECINUEVE"};
	private static String[] cEspeciales2 = {"VEINTIUNO","VEINTIDOS","VEINTITRES","VEINTICUATRO","VEINTICINCO","VEINTISEIS","VEINTISIETE","VEINTIOCHO","VEINTINUEVE"}; 
	private static String[] cDecenas = {"DIEZ","VEINTE","TREINTA","CUARENTA","CINCUENTA","SESENTA","SETENTA","OCHENTA","NOVENTA"};
	private static String[] cCentenas = {"CIENTO","DOSCIENTOS","TRESCIENTOS","CUATROCIENTOS","QUINIENTOS","SEISCIENTOS","SETECIENTOS","OCHOCIENTOS","NOVECIENTOS"};    
	private static String[] cMiles = {"MIL"};
	private static String[] cMillones = {"MILLON","MILLONES"};
	private static String[] cBillones = {"BILLON","BILLONES"};
	private static String[] cTrillones = {"TRILLON","TRILLONES"};
	
	public static boolean isStringValid(Object obj) {
		if(obj != null)
			if(obj instanceof String)
				if(((String)obj).trim().length() > 0) return true;
		
		return false;
	}
	
	public static String assignString(Object obj, boolean upperCase) {
		if(isStringValid(obj)) {
			if(upperCase) return ((String)obj).trim().toUpperCase();
			else return ((String)obj).trim();
		}
		else return null;
	}
	
	public static String assignString(Object obj) {
		return assignString(obj, false);
	}

	public static boolean isNumber(String value) {
		return (isStringValid(value) ? StringUtils.isNumeric(value) : false);
	}
	
	public static boolean isNumber(Object obj) {
		if(obj instanceof String) {
			return isNumber((String)obj);
		}
		else return false;
	}

	public static boolean isValidRUC(String ruc) {
		if(isNumber(ruc)) {
			int suma = 0;
			if(ruc.length() == 8) {
				for(int i = 0; i < ruc.length() - 1; i++) {
					int digito = ruc.charAt(i) - '0';
					suma += (i == 0 ? (digito * 2) : (digito * (ruc.length() - i)));
				}
				int resto = suma % 11;
				if(resto == 1) resto = 11;
				if(resto + (ruc.charAt(ruc.length() - 1) - '0') == 11) return true;
			}
			else if(ruc.length() == 11) {
				for(int i = 0, x = 6; i < ruc.length() - 1; i++) {
					if(i == 4) x = 8;
					int digito = ruc.charAt(i) - '0';
					x--;
					suma += (i == 0 ? (digito * x) : (digito * x));
				}
				int resto = (11 - (suma % 11));
				if(resto >= 10) resto = resto - 10;
				if(resto == ruc.charAt(ruc.length() - 1) - '0') return true;
			}
			else return false;
		}
		return false;
	}
	
	public static String rightPad(String s, int length, char pad) {
		return StringUtils.rightPad(s, length, pad);
	}
	
	public static String leftPad(String s, int length, char pad) {
		return StringUtils.leftPad(s, length, pad);
	}
	
	public static BigDecimal toBigDecimal(Object obj) throws ParseException {
		BigDecimal bigDecimal = null;
		if(obj instanceof BigDecimal) {
			bigDecimal = (BigDecimal)obj;
		}
		else if(obj instanceof String) {
			NumberFormat nf = new DecimalFormat("#,##0.##", new DecimalFormatSymbols(Locale.ENGLISH));
			bigDecimal = new BigDecimal(nf.parse((String)obj).doubleValue());
		}
		else return null;

		bigDecimal = bigDecimal.setScale(LONGITUD_DECIMAL, BigDecimal.ROUND_HALF_UP);
		return bigDecimal;
	}
	
	public static double toDoubleValue(Object obj) throws ParseException {
		return toBigDecimal(obj).doubleValue();
	}

	public static String formatRoundDecimalComa(BigDecimal decimal) {
        NumberFormat nf = new DecimalFormat("#,##0.###", new DecimalFormatSymbols(Locale.ENGLISH));
		return nf.format(decimal.doubleValue());
	}
	
	public static String formatRoundDecimalComa(String decimal) throws ParseException {
		NumberFormat nf = new DecimalFormat("#0.000", new DecimalFormatSymbols(Locale.ENGLISH));
		NumberFormat nf2 = new DecimalFormat("#,##0.###", new DecimalFormatSymbols(Locale.ENGLISH));
		return nf2.format(nf.parse((String)decimal).doubleValue());
	}
	
	public static String formatThreeDecimalComa(BigDecimal decimal) {
        NumberFormat nf = new DecimalFormat("#,##0.000", new DecimalFormatSymbols(Locale.ENGLISH));
		return nf.format(decimal.doubleValue());
	}
	public static String formatTwoDecimalComa(BigDecimal decimal) {
        NumberFormat nf = new DecimalFormat("#,##0.00", new DecimalFormatSymbols(Locale.ENGLISH));
		return nf.format(decimal.doubleValue());
	}
	public static String formatThreeDecimal(BigDecimal decimal) {
        NumberFormat nf = new DecimalFormat("#0.000", new DecimalFormatSymbols(Locale.ENGLISH));
		return nf.format(decimal.doubleValue());
	}
	public static String formatTwoDecimal(BigDecimal decimal) {
        NumberFormat nf = new DecimalFormat("#0.00", new DecimalFormatSymbols(Locale.ENGLISH));
		return nf.format(decimal.doubleValue());
	}

	public static String formatThreeDecimal(String decimal) throws ParseException {
		NumberFormat nf = new DecimalFormat("#,##0.###", new DecimalFormatSymbols(Locale.ENGLISH));
		NumberFormat nf2 = new DecimalFormat("#0.000", new DecimalFormatSymbols(Locale.ENGLISH));
		return nf2.format(nf.parse((String)decimal).doubleValue());
	}
	public static String formatTwoDecimal(String decimal) throws ParseException {
		NumberFormat nf = new DecimalFormat("#,##0.##", new DecimalFormatSymbols(Locale.ENGLISH));
		NumberFormat nf2 = new DecimalFormat("#0.00", new DecimalFormatSymbols(Locale.ENGLISH));
		return nf2.format(nf.parse((String)decimal).doubleValue());
	}
	public static String validateDate(String date) {
		String tDate = date;
		if(tDate != null) {
			tDate = tDate.trim();
			if(tDate.length() == 0) {
				tDate = null;
			}
			else {
				FechaBean fb = new FechaBean(tDate, "yyyy-MM-dd");
				tDate = fb.getFormatDate("dd/MM/yyyy");
			}
		}
		return tDate;
	}
	
	public static String getTypeFactura() {
		return FACTURA;
	}
	
	public static String getTypeBoleta() { 
		return BOLETA;
	}

	public static String getTypeNotaCredito() { 
		return NOTA_CREDITO;
	}
	
	public static String getTypeNotaDebito() { 
		return NOTA_DEBITO;
	}
	
	public static String getCodeIgv() { 
		return IGV;
	}
	
	public static String getCodeIsc() { 
		return ISC;
	}
	
	public static String getCodeIvap() { 
		return IVAP;
	}
	
	public static String getCodeGuiaRemision() { 
		return GUIA_REMISION;
	}
	
	public static String getCodeGuiaTransporte() { 
		return GUIA_TRANSPORTISTA;
	}
	  
	public static String numberToLetter(BigDecimal ex_Number) {
		String cLetters = null;
		BigInteger cNumber = new BigInteger("0");
		BigInteger cTmpNum = new BigInteger("0");
		BigInteger cTmpAux = new BigInteger("0");
		String cFraccion = "0";
		BigInteger cFactor = new BigInteger("0");
		BigInteger tmpentero = new BigInteger("0");
		//Hacemos Positivo si en caso el Numero Ingresado sea Negativo 
		if((ex_Number.compareTo(new BigDecimal(0.0))) == -1) {
			ex_Number = ex_Number.abs();
		}
		// Obtenemos la Parte Entera 
		NumberFormat nf = new DecimalFormat("#0.###", new DecimalFormatSymbols(Locale.ENGLISH));
		String aux = nf.format(ex_Number);
		int pos = -1;
		pos = aux.indexOf(".");
		if(pos > 0) {
			cNumber = new BigInteger(aux.substring(0, pos));
			tmpentero = cNumber;
			cFraccion = aux.substring(pos + 1).trim();
			if(cFraccion.length() == 3)
				cFraccion += "/1000";
			else {
				if(cFraccion.length() == 1)
					cFraccion = "0" + cFraccion + "/100";
				else
					cFraccion += "/100";
			}
		}
		cLetters = "";
		cFactor = new BigInteger("1000000000000000000");
		for(int i = 1; i <= 4; i++) {
			cTmpNum = (cNumber.divide(cFactor));
			if(cTmpNum.compareTo(new BigInteger("999")) == 1) {
				cTmpAux = (cTmpNum.divide(new BigInteger("1000")));
				cLetters = cLetters + " " + eval(cTmpAux, 1).trim();
				cLetters = cLetters + " " + cMiles[0];
			}
			cTmpAux = (cTmpNum.divide(new BigInteger("1000")));
			cTmpNum = cTmpNum.add((cTmpAux.multiply(new BigInteger("1000"))).negate());
			if(cTmpNum.compareTo(new BigInteger("0")) == 1) {
				cLetters = cLetters + " " + eval(cTmpNum, i).trim();
			}
			cTmpNum = (cNumber.divide(cFactor));
			// Trillones
			if((cTmpNum.compareTo(new BigInteger("1")) >= 0) && i == 1) {
				if(cTmpNum.compareTo(new BigInteger("1")) == 1) {
					cLetters = cLetters + " " + cTrillones[1];
				}
				else {
					cLetters = cLetters + " " + cTrillones[0];
				}
			}
			// Billones 
			if((cTmpNum.compareTo(new BigInteger("1")) >= 0) && i == 2) {
				if(cTmpNum.compareTo(new BigInteger("1")) == 1) {
					cLetters = cLetters + " " + cBillones[1];
				}
				else {
					cLetters = cLetters + " " + cBillones[0];
				}
			}
			// Millones
			if((cTmpNum.compareTo(new BigInteger("1")) >= 0) && i == 3) {
				if(cTmpNum.compareTo(new BigInteger("1")) == 1) {
					cLetters = cLetters + " " + cMillones[1];
				}
				else {
					cLetters = cLetters + " " + cMillones[0];
				}
			}
			cNumber = cNumber.add((cTmpNum.multiply(cFactor)).negate());
			cFactor = cFactor.divide(new BigInteger("1000000"));
		}
		if(tmpentero.compareTo(new BigInteger("0")) == 0) {
			cLetters = cLetters + " " + cCero[0];
		}
		cLetters = cLetters + " Y " + cFraccion;
		return cLetters.trim();
	}

	private static String eval(BigInteger xnumber, int ex_Return) {
		String cLetters = null;
		BigInteger cNumber = new BigInteger("0");
		BigInteger cTmpNum = new BigInteger("0");
		BigInteger cTmpAux = new BigInteger("0");
		BigInteger cFactor = new BigInteger("0");
		cNumber = xnumber;
		if(cNumber.compareTo(new BigInteger("0")) == 0)
			return cCero[0];
		cLetters = "";
		cFactor = new BigInteger("100");
		cTmpNum = cNumber.divide(cFactor);
		if(cTmpNum.compareTo(new BigInteger("1")) >= 0) {
			if(cNumber.compareTo(new BigInteger("100")) == 0) {
				cLetters = "CIEN";
			}
			else {
				cLetters = cCentenas[Integer.parseInt(String.valueOf(cTmpNum.intValue() - 1))];
			}
		}
		cTmpNum = cNumber.add((cTmpNum.multiply(new BigInteger("100"))).negate());
		if(cTmpNum.compareTo(new BigInteger("0")) == 1) {
			if(cTmpNum.compareTo(new BigInteger("10")) == 1 && cTmpNum.compareTo(new BigInteger("20")) == -1) {
				cLetters = cLetters + " " + cEspeciales[Integer.parseInt(String.valueOf(cTmpNum.intValue() - 11))];
			}
			else if(cTmpNum.compareTo(new BigInteger("20")) == 1 && cTmpNum.compareTo(new BigInteger("30")) == -1) {
				cLetters = cLetters + " " + cEspeciales2[Integer.parseInt(String.valueOf(cTmpNum.intValue() - 21))];
			}
			else {
				cTmpAux = cTmpNum.divide(new BigInteger("10"));
				if(cTmpAux.compareTo(new BigInteger("1")) >= 0) {
					cLetters = cLetters + " " + cDecenas[Integer.parseInt(String.valueOf(cTmpAux.intValue() - 1))];
				}
				cTmpAux = cTmpNum.add((cTmpAux.multiply(new BigInteger("10"))).negate());
				if(cTmpAux.compareTo(new BigInteger("0")) == 1) {
					if(cTmpNum.compareTo(new BigInteger("9")) == 1) {
						cLetters = cLetters + " Y";
					}
					if(cNumber.compareTo(new BigInteger("1")) == 0 && ex_Return < 4) {
						cLetters = cLetters + " UN";
					}
					else {
						cLetters = cLetters + " " + cUnidades[Integer.parseInt(String.valueOf(cTmpAux.intValue() - 1))];
					}
				}
			}
		}
		return cLetters;
	}
}
