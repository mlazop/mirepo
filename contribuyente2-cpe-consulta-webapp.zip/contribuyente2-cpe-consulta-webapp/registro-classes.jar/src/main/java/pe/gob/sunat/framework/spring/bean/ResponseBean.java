package pe.gob.sunat.framework.spring.bean;

import java.io.Serializable;
import java.util.List;

import net.sf.json.JSONArray;
import net.sf.json.JSONObject;
import net.sf.json.JsonConfig;
import pe.gob.sunat.framework.spring.web.util.JsonUtil;

/**
 * Bean que sirve para devolver datos a la aplicacion cliente en formato JSON,
 * tiene cuatro atributos
 * 		codeError: normalmente (0)No error, (1) Error
 * 		messageError: la descripcion del error
 * 		data: data es el objeto que se retorna en caso de no error
 * 		stringData: este campo guarda el objeto data en formato json
 * 
 * Finalmente el atributo data se retorna como String en formato json y para 
 * obtener el objeto real se utiliza el metodo toObjectData()
 * 
 * @author Carlos Enrique Quispe Salazar
 * */
public class ResponseBean implements Serializable {
	private static final long serialVersionUID = 1L;
	private int codeError;
	private String messageError;
	private Object data;
	private String stringData;

	public ResponseBean() {}
	
	public ResponseBean(int codeError) {
		this.setCodeError(codeError);
		this.setMessageError(null);
		this.setData(null);
	}
	
	public ResponseBean(int codeError, String  messageError) {
		this.setCodeError(codeError);
		this.setMessageError(messageError);
		this.setData(null);
	}
	
	public ResponseBean(int codeError, String  messageError, Object data) {
		this.setCodeError(codeError);
		this.setMessageError(messageError);
		this.setData(data);
	}
	
	public int getCodeError() {
		return codeError;
	}
	
	public void setCodeError(int codeError) {
		this.codeError = codeError;
	}
	
	public String getMessageError() {
		return messageError;
	}
	
	public void setMessageError(String messageError) {
		this.messageError = messageError;
	}
	
	public void setCodeAndMessageError(int codeError, String messageError) {
		this.setCodeError(codeError);
		this.setMessageError(messageError);
	}

	public String getData() {
		return this.stringData;
	}
	
	public Object toObjectData() {
		return this.data;
	}

	public void setData(Object data) {
		this.setData(data, JsonUtil.getJsonNoNull());
	}
	
	public void setData(Object data, JsonConfig jsonConfig) {
		this.data = data;
		if(data != null) {
			if(data instanceof String) {
				this.stringData = (String)data;
			}
			else if(data instanceof List || data instanceof Object[]) {
				JSONArray jsonArray = JSONArray.fromObject(data, jsonConfig);
				this.stringData = jsonArray.toString();
			}
			else {
				JSONObject jsonObject = JSONObject.fromObject(data, jsonConfig);
				this.stringData = jsonObject.toString();
			}
		}
		else this.stringData = null;
	}
}
