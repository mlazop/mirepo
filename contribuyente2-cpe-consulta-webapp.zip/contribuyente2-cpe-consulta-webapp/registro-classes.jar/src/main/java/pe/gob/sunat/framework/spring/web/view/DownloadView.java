package pe.gob.sunat.framework.spring.web.view;

import java.io.BufferedOutputStream;
import java.io.ByteArrayInputStream;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.web.servlet.view.AbstractView;

/**
 * Devuelve en el request los datos recibidos por parametro,
 * a una cadena de formato JSON.
 * @author Carlos Enrique Quispe Salazar
 * @since 17/10/2007
 * @version 1.0
 */
@SuppressWarnings({"rawtypes"})
public class DownloadView extends AbstractView {
	protected final Log log = LogFactory.getLog(getClass());
	
	protected void renderMergedOutputModel(Map map, HttpServletRequest request, HttpServletResponse response)
	throws Exception {      
		log.debug("Convirtiendo a JSON el Bean: " + this.getBeanName());
		Map model = (Map)map.get("datamodel");
		log.debug("Parametro: " + model.toString());
        BufferedOutputStream bos = new BufferedOutputStream(response.getOutputStream());
        try {
    	    response.setContentType("application/octet-stream");
    	    response.setHeader("Content-Disposition", "attachment; filename=" + (String)model.get("fileName"));
			
    	    ByteArrayInputStream bais = new ByteArrayInputStream((byte[])model.get("dataBytes"));
			for(int b = 0;(b = bais.read()) != -1;) bos.write(b);
			bais.close();
		    bos.flush();
        }
        catch(Exception e) {
        }
        finally {
            bos.close();
        }
	}
}
