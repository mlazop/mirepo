package pe.gob.sunat.tecnologia2.validadoc.bean;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;

import pe.gob.sunat.tecnologia2.validadoc.exception.ValidateSignException;

/**
 * @author fjonislla
 *
 */
public class VerifySignResult {
	
	public static final int RESPUESTA_CERTIFICADO_NO_VALIDO = 0;
	public static final int RESPUESTA_DOCUMENTO_FIRMADO_VALIDO = 1;
	public static final int RESPUESTA_DOCUMENTO_NO_FIRMADO = 2;
	public static final int RESPUESTA_DOCUMENTO_MODIFICADO = 3;
	public static final int RESPUESTA_CERTIFICADO_CADUCO = 4;
	
	private int resultCode;
	private Date certificateLastValidDate;
	private String message;
	
	public VerifySignResult() {
		
	}
	
	public VerifySignResult(int resultCode, String mensaje) {
		super();
		this.resultCode = resultCode;
		this.message = mensaje;
	}
	
	public VerifySignResult(int resultCode, Date certificateLastValidDate) {
		super();
		this.resultCode = resultCode;
		this.certificateLastValidDate = certificateLastValidDate;
	}

	public VerifySignResult(ValidateSignException e) {
		resultCode = e.getResultCode();
		certificateLastValidDate = e.getCertificateLastValidDate();
		message = e.getMessage();
	}

	public int getResultCode() {
		return resultCode;
	}
	public Date getCertificateLastValidDate() {
		return certificateLastValidDate;
	}

	public String getMessage() {
		return message;
	}

	public void setResultCode(int resultCode) {
		this.resultCode = resultCode;
	}

	public void setCertificateLastValidDate(Date certificateLastValidDate) {
		this.certificateLastValidDate = certificateLastValidDate;
	}

	public void setMessage(String mensaje) {
		this.message = mensaje;
	}
	
	public String getCertificateLastValidDateString() {
		DateFormat df = new SimpleDateFormat("dd/MM/yyyy HH:mm");
		return df.format(certificateLastValidDate);
	}
	

}
