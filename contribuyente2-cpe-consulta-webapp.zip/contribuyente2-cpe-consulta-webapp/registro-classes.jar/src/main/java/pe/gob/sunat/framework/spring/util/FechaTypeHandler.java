package pe.gob.sunat.framework.spring.util;

import java.sql.SQLException;
import java.sql.Timestamp;
import java.sql.Types;

import pe.gob.sunat.framework.spring.util.date.FechaBean;

import com.ibatis.sqlmap.client.extensions.ParameterSetter;
import com.ibatis.sqlmap.client.extensions.ResultGetter;
import com.ibatis.sqlmap.client.extensions.TypeHandlerCallback;

/**
 * Clase que define el tipo de datos fecha
 * @author Carlos Enrique Quispe Salazar
 * @since 01-06-2009
 * */
public class FechaTypeHandler implements TypeHandlerCallback {

	@Override
	public Object getResult(ResultGetter getter) throws SQLException {
        Timestamp value = getter.getTimestamp();
        if(getter.wasNull()) {
            return null;
        }
        return new FechaBean(value);
	}

	@Override
	public void setParameter(ParameterSetter setter, Object parameter)
	throws SQLException {
        if(parameter == null) {
            setter.setNull(Types.TIMESTAMP);
        }
        else {
        	FechaBean fecha = (FechaBean)parameter;
            setter.setTimestamp(fecha.getTimestamp());
        }
	}

	@Override
	public Object valueOf(String s) {
		return new FechaBean(s);
	}
}
