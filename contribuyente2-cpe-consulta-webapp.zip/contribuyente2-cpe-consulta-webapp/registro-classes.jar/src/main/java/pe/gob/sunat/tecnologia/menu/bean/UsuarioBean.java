package pe.gob.sunat.tecnologia.menu.bean;

import java.io.Serializable;
import java.util.HashMap;
import java.util.Map;

/**
 * 
 * Bean con la informacion del usuario
 * 
 * Clase : UsuarioBean
 * Proyecto : Menu
 * Descripcion :
 * Autor : CGARRATT
 * Fecha : 15/09/2005
 */
@SuppressWarnings("rawtypes")
public class UsuarioBean implements Serializable {

	//Datos comunes
	private String id = "";				// ID de ingreso al menu
	private String ticket = "";			// Ticket de ingreso al menu
	private String login = "";			// RUC + Usuario SOL / Login LDAP / Id.Usuario  
	private String correo = ""; 		// Correo electronico	
	private String nombres = ""; 		// Nombres 
	private String apePaterno = ""; 	// Apellido paterno 	
	private String apeMaterno = ""; 	// Apellido materno 
	private String nombreCompleto = "";	// Nombres completos
	//Datos Intranet
	private String nroRegistro = ""; 	// Numero de registro de personal
	private String codUO = ""; 			// Unidad organizacional de personal 
	private String desUO = ""; 			// Descripcion de la unidad organizacional	
	private String codCate = ""; 		// Codigo de categoria
	private String desCate = ""; 		// Descripcion de la categoria
	private short nivelUO = 0; 			// Nivel de la unidad organizacional

	//Datos Internet / Extranet
	private String numRUC = "";			// Numero de RUC
	private String usuarioSOL = "";		// Usuario SOL
	private String codDepend = "";		// Codigo de la dependencia
	//Datos WAP
	private String idCelular; 			// Id de celular
	//Datos Aduanas
	private String codTOpeComer = ""; 	// Codigo de Tipo de Operador de Comercio		
	/**
	 * Parametros adicionales del usuario
	 * jndiPool  : 	Valor del pool por defecto para dependencias (pXXXX)
	 * tipOrigen : 	Indica el origen de la invocacion
	 * 				IT - Internet / IA - Intranet / ET - Extranet
	 */
	private Map map;					// Mapa con datos adicionales del usuario

	public UsuarioBean() {
		map = new HashMap();
	}

	/**
	 * @deprecated Se debe utilizar el atributo ticket
	 * @return
	 */
	public String getId() {
		return id;
	}
	/**
	 * @deprecated Se debe utilizar el atributo ticket
	 * @return
	 */
	public void setId(String id) {
		this.id = id;
	}

	public String getTicket() {
		return ticket;
	}

	public void setTicket(String ticket) {
		this.ticket = ticket;
	}
	
	public String getApeMaterno() {
		return apeMaterno;
	}

	public void setApeMaterno(String apeMaterno) {
		this.apeMaterno = apeMaterno;
	}

	public String getApePaterno() {
		return apePaterno;
	}

	public void setApePaterno(String apePaterno) {
		this.apePaterno = apePaterno;
	}

	public String getCodCate() {
		return codCate;
	}

	public void setCodCate(String codCate) {
		this.codCate = codCate;
	}

	public String getCodUO() {
		return codUO;
	}

	public void setCodUO(String codUO) {
		this.codUO = codUO;
	}

	public String getCorreo() {
		return correo;
	}

	public void setCorreo(String correo) {
		this.correo = correo;
	}

	public String getDesCate() {
		return desCate;
	}

	public void setDesCate(String desCate) {
		this.desCate = desCate;
	}

	public String getDesUO() {
		return desUO;
	}

	public void setDesUO(String desUO) {
		this.desUO = desUO;
	}

	public String getLogin() {
		return login;
	}

	public void setLogin(String login) {
		this.login = login;
	}

	public short getNivelUO() {
		return nivelUO;
	}
	
	public void setNivelUO(short nivelUO) {
		this.nivelUO = nivelUO;
	}
	
	public String getNombreCompleto() {
		return nombreCompleto;
	}

	public void setNombreCompleto(String nombreCompleto) {
		this.nombreCompleto = nombreCompleto;
	}

	public String getNombres() {
		return nombres;
	}

	public void setNombres(String nombres) {
		this.nombres = nombres;
	}

	public String getNroRegistro() {
		return nroRegistro;
	}

	public void setNroRegistro(String nroRegistro) {
		this.nroRegistro = nroRegistro;
	}

	public String getVisibilidad() {
		return nivelUO > 0 ? getCodUO().substring(0, nivelUO + 1).concat("%") : "%";
		//return nivelUO != null && nivelUO.shortValue() > 0 ? getCodUO().substring(0, nivelUO.shortValue() + 1).concat("%") : "%";
	}

	public String getCodDepend() {
		return codDepend;
	}

	public void setCodDepend(String codDepend) {
		this.codDepend = codDepend;
	}

	public String getNumRUC() {
		return numRUC;
	}

	public void setNumRUC(String numRUC) {
		this.numRUC = numRUC;
	}

	public String getUsuarioSOL() {
		return usuarioSOL;
	}

	public void setUsuarioSOL(String usuarioSOL) {
		this.usuarioSOL = usuarioSOL;
	}

	public String getIdCelular() {
		return idCelular;
	}

	public void setIdCelular(String idCelular) {
		this.idCelular = idCelular;
	}

	public Map getMap() {
		return map;
	}

	public void setMap(Map map) {
		this.map = map;
	}

	public String getCodTOpeComer() {
		return codTOpeComer;
	}

	public void setCodTOpeComer(String codTOpeComer) {
		this.codTOpeComer = codTOpeComer;
	}
	
	private static final long serialVersionUID = -6214534626139219912L;

}