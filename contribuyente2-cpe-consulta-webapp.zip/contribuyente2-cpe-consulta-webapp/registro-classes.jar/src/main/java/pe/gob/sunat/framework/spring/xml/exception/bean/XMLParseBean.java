package pe.gob.sunat.framework.spring.xml.exception.bean;

public class XMLParseBean {
	private int type;	
	private int line;
	private String message;

	public int getType() {
		return type;
	}
	public void setType(int type) {
		this.type = type;
	}
	public int getLine() {
		return line;
	}
	public void setLine(int line) {
		this.line = line;
	}
	public String getMessage() {
		return message;
	}
	public void setMessage(String message) {
		this.message = message;
	}
}
