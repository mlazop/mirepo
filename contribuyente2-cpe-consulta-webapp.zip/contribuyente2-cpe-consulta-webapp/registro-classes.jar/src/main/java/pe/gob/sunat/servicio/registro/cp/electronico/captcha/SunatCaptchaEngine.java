package pe.gob.sunat.servicio.registro.cp.electronico.captcha;

import java.awt.Color;
import java.awt.Font;
import java.awt.image.ImageFilter;
import java.security.SecureRandom;
import java.util.Random;

import com.jhlabs.image.WaterFilter;
import com.octo.captcha.CaptchaException;
import com.octo.captcha.component.image.backgroundgenerator.BackgroundGenerator;
import com.octo.captcha.component.image.backgroundgenerator.UniColorBackgroundGenerator;
import com.octo.captcha.component.image.color.RandomRangeColorGenerator;
import com.octo.captcha.component.image.deformation.ImageDeformation;
import com.octo.captcha.component.image.deformation.ImageDeformationByFilters;
import com.octo.captcha.component.image.fontgenerator.FontGenerator;
import com.octo.captcha.component.image.textpaster.DecoratedRandomTextPaster;
import com.octo.captcha.component.image.textpaster.TextPaster;
import com.octo.captcha.component.image.textpaster.textdecorator.BaffleTextDecorator;
import com.octo.captcha.component.image.textpaster.textdecorator.TextDecorator;
import com.octo.captcha.component.image.wordtoimage.DeformedComposedWordToImage;
import com.octo.captcha.component.image.wordtoimage.WordToImage;
import com.octo.captcha.component.word.wordgenerator.RandomWordGenerator;
import com.octo.captcha.component.word.wordgenerator.WordGenerator;

/**
 * @author Carlos Enrique Quispe Salazar
 * */
public class SunatCaptchaEngine {
    
    public SunatCaptchaEngine() {}
    
    public static CaptchaInformation generateCaptcha() {
        //WordGenerator wordGenerator = new RandomWordGenerator("ABCDEFGHIJKLMNPQRSTUVWXYZ123456789");
       WordGenerator wordGenerator = new RandomWordGenerator("ABCDEFGHIJKLMNPQRSTUVWXYZ");

        WaterFilter water = new WaterFilter();
        water.setAmplitude(3D);
        water.setAntialias(true);
        water.setPhase(20D);
        water.setWavelength(70D);
        ImageDeformation backDef = new ImageDeformationByFilters(new ImageFilter[0]);
        ImageDeformation textDef = new ImageDeformationByFilters(new ImageFilter[0]);
        ImageDeformation postDef = new ImageDeformationByFilters(new ImageFilter[] {water});
        
        TextPaster randomPaster = new DecoratedRandomTextPaster(new Integer(4), 
                new Integer(4), 
                new RandomRangeColorGenerator(new int[] {1, 250}, new int[] {1, 250}, new int[] {1, 250}), Boolean.TRUE,
                new TextDecorator[] {new BaffleTextDecorator(new Integer(0), Color.BLUE)});
        
        BackgroundGenerator back = new UniColorBackgroundGenerator(new Integer(100), 
                new Integer(50), 
                Color.white);
        
        /*FontGenerator shearedFont = new RandomFontGenerator(new Integer(30), 
                new Integer(30),
                new Font[]{new Font("Times New Roman", Font.BOLD, 30)});*/
        FontGenerator shearedFont = new SimpleFontGenerator(new Integer(30), 
              new Integer(30), new Font("Times New Roman", Font.BOLD, 30));
        
        WordToImage word2image = new DeformedComposedWordToImage(shearedFont, back, randomPaster, backDef, textDef, postDef);
        
        Integer wordLength = getRandomLength(word2image);
        String word = wordGenerator.getWord(wordLength/*, locale*/);
        java.awt.image.BufferedImage image = null;

        try {
            image = word2image.getImage(word);
        }
        catch(Throwable e) {
            throw new CaptchaException(e);
        }

        return new CaptchaInformation(image, word);
    }
    
    protected static Integer getRandomLength(WordToImage word2image) {
        Random	myRandom = new SecureRandom();
        int range = word2image.getMaxAcceptedWordLength() - word2image.getMinAcceptedWordLength();
        int randomRange = range == 0 ? 0 : myRandom.nextInt(range + 1);
        Integer wordLength = new Integer(randomRange + word2image.getMinAcceptedWordLength());
        return wordLength;
    }
}