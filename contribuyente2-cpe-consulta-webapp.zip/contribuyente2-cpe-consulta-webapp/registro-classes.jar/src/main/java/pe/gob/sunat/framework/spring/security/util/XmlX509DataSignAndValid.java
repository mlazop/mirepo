package pe.gob.sunat.framework.spring.security.util;

import java.io.FileInputStream;
import java.security.KeyStore;
import java.security.PrivateKey;
import java.security.Provider;
import java.security.cert.X509Certificate;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.xml.crypto.dsig.CanonicalizationMethod;
import javax.xml.crypto.dsig.DigestMethod;
import javax.xml.crypto.dsig.Reference;
import javax.xml.crypto.dsig.SignatureMethod;
import javax.xml.crypto.dsig.SignedInfo;
import javax.xml.crypto.dsig.Transform;
import javax.xml.crypto.dsig.XMLSignature;
import javax.xml.crypto.dsig.XMLSignatureFactory;
import javax.xml.crypto.dsig.dom.DOMSignContext;
import javax.xml.crypto.dsig.keyinfo.KeyInfo;
import javax.xml.crypto.dsig.keyinfo.KeyInfoFactory;
import javax.xml.crypto.dsig.keyinfo.X509Data;
import javax.xml.crypto.dsig.spec.C14NMethodParameterSpec;
import javax.xml.crypto.dsig.spec.TransformParameterSpec;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;

import pe.gob.sunat.framework.spring.util.exception.ServiceException;
import pe.gob.sunat.framework.util.io.dao.LdapDAO;




@SuppressWarnings({"rawtypes", "unchecked"})
public class XmlX509DataSignAndValid extends SignAndValid {
	protected final Log log = LogFactory.getLog(getClass());	


	@Override
	public Object[] sign(Object[] objs) {
		try {
			if(objs.length < 2) throw new ServiceException(this, "Muy pocos parametros para firmar");
			Document doc = (Document)objs[0];
			Node parentNode = (Node)objs[1];
			String idReference = null;
			if(objs.length == 3) idReference = (String)objs[2];
			
	        String providerName = System.getProperty("jsr105Provider", "org.jcp.xml.dsig.internal.dom.XMLDSigRI");
			XMLSignatureFactory fac = XMLSignatureFactory.getInstance("DOM", (Provider)Class.forName(providerName).newInstance());
			
			Reference ref = fac.newReference("", fac.newDigestMethod(DigestMethod.SHA1, null),
							Collections.singletonList(fac.newTransform(Transform.ENVELOPED,
							(TransformParameterSpec) null)), null, null);
	
			SignedInfo si = fac.newSignedInfo(fac.newCanonicalizationMethod(CanonicalizationMethod.INCLUSIVE,
							(C14NMethodParameterSpec) null), fac.newSignatureMethod(
							SignatureMethod.RSA_SHA1, null), Collections.singletonList(ref));
			
//			KeyStore ks = KeyStore.getInstance("JKS");
//			ks.load(new FileInputStream(this.storage), this.storagePassword.toCharArray());
//			PrivateKey keyEntry = (PrivateKey)ks.getKey(this.certAlias, this.certPassword.toCharArray());
//			X509Certificate cert = (X509Certificate) ks.getCertificate(this.certAlias);
			
			LdapDAO ldapdao = new LdapDAO("ldapinternet");
			log.debug("ldapdao: " + ldapdao);
			
			Map emisorCert =  ldapdao.getCertificado("emisorrhcert");
			PrivateKey keyEntry = (PrivateKey)emisorCert.get("pkey");
            X509Certificate cert = (X509Certificate) emisorCert.get("certificado");
				
			KeyInfoFactory kif = fac.getKeyInfoFactory();
			List<X509Certificate> x509Content = new ArrayList<X509Certificate>();
			x509Content.add(cert);
			X509Data xd = kif.newX509Data(x509Content);
			KeyInfo ki = kif.newKeyInfo(Collections.singletonList(xd));
	
			DOMSignContext dsc = new DOMSignContext(keyEntry, doc.getDocumentElement());
			XMLSignature signature = fac.newXMLSignature(si, ki);
			if(parentNode != null) dsc.setParent(parentNode);
			dsc.setDefaultNamespacePrefix("ds");
			signature.sign(dsc);
			Element elementParent = (Element)dsc.getParent();
			if(idReference != null && elementParent.getElementsByTagName("ds:Signature") != null) {
				Element elementSignature = (Element)elementParent.getElementsByTagName("ds:Signature").item(0);
				elementSignature.setAttribute("Id", idReference);
			}
			return new Object[]{};
		}
		catch(ServiceException e) {
			throw e;
		}
		catch(Exception e) {
			throw new ServiceException(this, e);
		}
	}

	@Override
	public Object[] validate(Object[] objs) {
		return null;
	}
	
	public Object[] signLibro(Object[] objs) {
		log.info("ENTRO EN METODO  sign  de XmlX509DataSignAndValid ");
		try {
			if(objs.length < 3) throw new ServiceException(this, "Muy pocos parametros para firmar");
			Document doc = (Document)objs[0];
			//Node parentNode = doc.getParentNode();
			Node parentNode = (Node)objs[1];
			Map  mldap = (HashMap)objs[2]; 
			String idReference = null;
			if(objs.length == 4) idReference = (String)objs[3];
			
	        String providerName = System.getProperty("jsr105Provider", "org.jcp.xml.dsig.internal.dom.XMLDSigRI");
			XMLSignatureFactory fac = XMLSignatureFactory.getInstance("DOM", (Provider)Class.forName(providerName).newInstance());
			
			Reference ref = fac.newReference("", fac.newDigestMethod(DigestMethod.SHA1, null),
							Collections.singletonList(fac.newTransform(Transform.ENVELOPED,
							(TransformParameterSpec) null)), null, null);
	
			SignedInfo si = fac.newSignedInfo(fac.newCanonicalizationMethod(CanonicalizationMethod.INCLUSIVE,
							(C14NMethodParameterSpec) null), fac.newSignatureMethod(
							SignatureMethod.RSA_SHA1, null), Collections.singletonList(ref));
			
			//KeyStore ks = KeyStore.getInstance("JKS");
			
			/*ks.load(new FileInputStream(this.storage), this.storagePassword.toCharArray());
			
			PrivateKey keyEntry = (PrivateKey)ks.getKey(this.certAlias, this.certPassword.toCharArray());
			X509Certificate cert = (X509Certificate) ks.getCertificate(this.certAlias);
	
			KeyInfoFactory kif = fac.getKeyInfoFactory();
			List<X509Certificate> x509Content = new ArrayList<X509Certificate>();
			x509Content.add(cert);
			X509Data xd = kif.newX509Data(x509Content);
			KeyInfo ki = kif.newKeyInfo(Collections.singletonList(xd));
	
			DOMSignContext dsc = new DOMSignContext(keyEntry, doc.getDocumentElement());
			XMLSignature signature = fac.newXMLSignature(si, ki);
			
			if(parentNode != null) dsc.setParent(parentNode);
			dsc.setDefaultNamespacePrefix("ds");
			signature.sign(dsc);
			Element elementParent = (Element)dsc.getParent();
			if(idReference != null && elementParent.getElementsByTagName("ds:Signature") != null) {
				Element elementSignature = (Element)elementParent.getElementsByTagName("ds:Signature").item(0);
				elementSignature.setAttribute("Id", idReference);
			}
			*/
			PrivateKey keyEntry = (PrivateKey)mldap.get("pkey");
			X509Certificate cert = (X509Certificate) mldap.get("certificado");
			
			KeyInfoFactory kif = fac.getKeyInfoFactory();
			List x509Content = new ArrayList();
			x509Content.add(cert);
			X509Data xd = kif.newX509Data(x509Content);
			KeyInfo ki = kif.newKeyInfo(Collections.singletonList(xd));

			DOMSignContext dsc = new DOMSignContext(keyEntry, doc.getDocumentElement());
			XMLSignature signature = fac.newXMLSignature(si, ki);
			
			if(parentNode != null) dsc.setParent(parentNode);
			dsc.setDefaultNamespacePrefix("ds");
			signature.sign(dsc);
			Element elementParent = (Element)dsc.getParent();
			if(idReference!=null && elementParent.getElementsByTagName("ds:Signature") != null) {
				Element elementSignature = (Element)elementParent.getElementsByTagName("ds:Signature").item(0);
				elementSignature.setAttribute("Id", idReference);
			}
		
			
			/////
			return new Object[]{};
		}
		catch(ServiceException e) {
			e.printStackTrace(); 
			throw e;
		}
		catch(Exception e) {
			e.printStackTrace(); 
			throw new ServiceException(this, e);
		}
	}
	public Object[] signLibroREPLOCAL(Object[] objs) {
		log.info("ENTRO EN METODO  sign  de XmlX509DataSignAndValid ");
		try {
			if(objs.length < 2) throw new ServiceException(this, "Muy pocos parametros para firmar");
			Document doc = (Document)objs[0];
			//Node parentNode = doc.getParentNode();
			Node parentNode = (Node)objs[1];
			String idReference = null;
			if(objs.length == 3) idReference = (String)objs[2];
			
	        String providerName = System.getProperty("jsr105Provider", "org.jcp.xml.dsig.internal.dom.XMLDSigRI");
			XMLSignatureFactory fac = XMLSignatureFactory.getInstance("DOM", (Provider)Class.forName(providerName).newInstance());
			
			Reference ref = fac.newReference("", fac.newDigestMethod(DigestMethod.SHA1, null),
							Collections.singletonList(fac.newTransform(Transform.ENVELOPED,
							(TransformParameterSpec) null)), null, null);
	
			SignedInfo si = fac.newSignedInfo(fac.newCanonicalizationMethod(CanonicalizationMethod.INCLUSIVE,
							(C14NMethodParameterSpec) null), fac.newSignatureMethod(
							SignatureMethod.RSA_SHA1, null), Collections.singletonList(ref));
			
			KeyStore ks = KeyStore.getInstance("JKS");
			ks.load(new FileInputStream(this.storage), this.storagePassword.toCharArray());
			
			PrivateKey keyEntry = (PrivateKey)ks.getKey(this.certAlias, this.certPassword.toCharArray());
			X509Certificate cert = (X509Certificate) ks.getCertificate(this.certAlias);
	
			KeyInfoFactory kif = fac.getKeyInfoFactory();
			List<X509Certificate> x509Content = new ArrayList<X509Certificate>();
			x509Content.add(cert);
			X509Data xd = kif.newX509Data(x509Content);
			KeyInfo ki = kif.newKeyInfo(Collections.singletonList(xd));
	
			DOMSignContext dsc = new DOMSignContext(keyEntry, doc.getDocumentElement());
			XMLSignature signature = fac.newXMLSignature(si, ki);
			
			if(parentNode != null) dsc.setParent(parentNode);
			dsc.setDefaultNamespacePrefix("ds");
			signature.sign(dsc);
			Element elementParent = (Element)dsc.getParent();
			if(idReference != null && elementParent.getElementsByTagName("ds:Signature") != null) {
				Element elementSignature = (Element)elementParent.getElementsByTagName("ds:Signature").item(0);
				elementSignature.setAttribute("Id", idReference);
			}
			return new Object[]{};
		}
		catch(ServiceException e) {
			e.printStackTrace(); 
			throw e;
		}
		catch(Exception e) {
			e.printStackTrace(); 
			throw new ServiceException(this, e);
		}
	}
	
	
}
