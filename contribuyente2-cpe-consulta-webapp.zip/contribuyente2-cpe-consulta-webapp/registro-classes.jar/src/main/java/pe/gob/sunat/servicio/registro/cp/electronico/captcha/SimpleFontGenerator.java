package pe.gob.sunat.servicio.registro.cp.electronico.captcha;

import java.awt.Font;

import com.octo.captcha.component.image.fontgenerator.FontGenerator;

/**
 * @author Carlos Enrique Quispe Salazar
 * @version 1.0
 */
public class SimpleFontGenerator implements FontGenerator {
    private int minFontSize;
    private int maxFontSize;
    private Font font;

    public SimpleFontGenerator(Integer minFontSize, Integer maxFontSize) {
        Font font = new Font("Times New Roman", Font.BOLD, 30);
        setFontSize(minFontSize, maxFontSize, font);
    }
    
    public SimpleFontGenerator(Integer minFontSize, Integer maxFontSize, Font font) {
        setFontSize(minFontSize, maxFontSize, font);
    }
    
    private void setFontSize(Integer minFontSize, Integer maxFontSize, Font font) {
        this.minFontSize = 10;
        this.maxFontSize = 14;
        this.minFontSize = minFontSize == null ? this.minFontSize : minFontSize.intValue();
        this.maxFontSize = maxFontSize == null || maxFontSize.intValue() < this.minFontSize ? Math.max(this.maxFontSize, this.minFontSize + 1) : maxFontSize.intValue();
        this.font = font;
    }

    public Font getFont() {
        return font;
    }
    
    public int getMinFontSize() {
        return minFontSize;
    }

    public int getMaxFontSize() {
        return maxFontSize;
    }
}


