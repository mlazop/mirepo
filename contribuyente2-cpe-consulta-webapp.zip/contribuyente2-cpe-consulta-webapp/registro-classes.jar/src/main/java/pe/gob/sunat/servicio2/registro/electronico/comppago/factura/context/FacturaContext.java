package pe.gob.sunat.servicio2.registro.electronico.comppago.factura.context;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import javax.xml.namespace.NamespaceContext;
import javax.xml.xpath.XPath;
import javax.xml.xpath.XPathConstants;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.w3c.dom.Document;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;

import pe.gob.sunat.framework.spring.util.date.FechaBean;
import pe.gob.sunat.framework.spring.util.exception.ServiceException;
import pe.gob.sunat.servicio2.registro.electronico.comppago.factura.bean.ComprobanteBean;
import pe.gob.sunat.servicio2.registro.electronico.comppago.factura.bean.ComprobanteUtilBean;
import pe.gob.sunat.servicio2.registro.electronico.comppago.factura.bean.DetalleComprobanteBean;
import pe.gob.sunat.servicio2.registro.electronico.comppago.factura.bean.DireccionComprobanteBean;
import pe.gob.sunat.servicio2.registro.electronico.comppago.factura.bean.DocumentoRelacionadoBean;
import pe.gob.sunat.servicio2.registro.electronico.comppago.factura.bean.OtroDocumentoRelacionadoBean;
import pe.gob.sunat.servicio2.registro.electronico.comppago.util.ComprobanteUtil;

@SuppressWarnings({"rawtypes","unchecked"})
public class FacturaContext extends ComprobanteContext {
	protected final Log log = LogFactory.getLog(getClass());

	private static final String NODE_DOCUMENT = "/sunat:Invoice";
	private static final String FILE_SCHEMA = "UBL-Invoice-2.0.xsd"; //"UBLPE-Invoice-1.0"; //"UBL-Invoice-2.0.xsd"
	private static final String FILE_TEMPLATE = "Invoice-2.0-Template.vm";
	
	public String getMainNodeValue() {
		return NODE_DOCUMENT;
	}
	
	public String getSchema() {
		return FILE_SCHEMA;
	}
	
	public String getTemplate() {
		return FILE_TEMPLATE;
	}

	public NamespaceContext getNamespaceContext() {
		return new FacturaNamespace();
	}
	
	public Node getNodeToSign(Document doc, XPath xpath) {
		return this.addExtensionContent(doc, xpath);
	}

	public Node getNodeSigned(Document doc, XPath xpath) {
		try {
			String expresion = this.getMainNodeValue() + "/cac:Signature/cac:DigitalSignatureAttachment/cac:ExternalReference/cbc:URI";
			String reference = (String)xpath.evaluate(expresion, doc, XPathConstants.STRING);
			if(reference == null) throw new Exception(expresion + " not found");
			else if(reference.trim().length() == 0) throw new Exception(expresion + " is empty");
			Node nodeSign = (Node)xpath.evaluate(this.getMainNodeValue() + "/ext:UBLExtensions/ext:UBLExtension/ext:ExtensionContent/ds:Signature", doc, XPathConstants.NODE);
			if(nodeSign == null) throw new Exception("Cannot find Signature element");
			return nodeSign;
		}
		catch(Exception e) {
			throw new ServiceException(this, e);
		}
	}

	public Node getNodeExtensions(Document doc, XPath xpath) {
		try {
			Node extensions = (Node)xpath.evaluate(this.getMainNodeValue() + "/ext:UBLExtensions",  doc, XPathConstants.NODE);
			return extensions;
		}
		catch(Exception e) {
			throw new ServiceException(this, e);
		}
	}

	public class FacturaNamespace implements NamespaceContext {

		public String getNamespaceURI(String prefix) {
			if(prefix.equals("qdt"))
				return "urn:oasis:names:specification:ubl:schema:xsd:QualifiedDatatypes-2";
			else if(prefix.equals("ccts"))
				return "urn:oasis:names:specification:ubl:schema:xsd:CoreComponentParameters-2";
			else if(prefix.equals("stat"))
				return "urn:oasis:names:specification:ubl:schema:xsd:DocumentStatusCode-1.0";
			else if(prefix.equals("cbc"))
				return "urn:oasis:names:specification:ubl:schema:xsd:CommonBasicComponents-2";
			else if(prefix.equals("cac"))
				return "urn:oasis:names:specification:ubl:schema:xsd:CommonAggregateComponents-2";
			else if(prefix.equals("udt"))
				return "urn:un:unece:uncefact:data:draft:UnqualifiedDataTypesSchemaModule:2";
			else if(prefix.equals("ext"))
				return "urn:oasis:names:specification:ubl:schema:xsd:CommonExtensionComponents-2";
			else if(prefix.equals("sac"))
				return "urn:sunat:names:specification:ubl:peru:schema:xsd:SunatAggregateComponents-1";
			else if(prefix.equals("ds"))
				return "http://www.w3.org/2000/09/xmldsig#";
			else return "urn:oasis:names:specification:ubl:schema:xsd:Invoice-2";
		}

		public String getPrefix(String p) {
			return null;
		}

		public Iterator<Object> getPrefixes(String p) {
			return null;
		}
	}

	@Override
	public ComprobanteBean generaComprobanteBean(Document doc, XPath xpath) {
		
		ComprobanteBean comprobante = new ComprobanteBean();
		
		try {
			String nm = this.getMainNodeValue();

			Object serieNum = xpath.evaluate(nm + "/cbc:ID", doc, XPathConstants.STRING);
			
			if(serieNum.toString().trim().toUpperCase().startsWith("E")){
				comprobante = generaComprobantePortal(doc, xpath);
			}else if(serieNum.toString().trim().toUpperCase().startsWith("F")||serieNum.toString().trim().toUpperCase().startsWith("B")){
				comprobante = generaComprobanteGEM(doc, xpath);
			}
			
		} catch(ServiceException e) {
			log.error(e,e);
			throw e;
		} catch(Exception e) {			
			log.error(e,e);
			throw new ServiceException(this, e.getLocalizedMessage());
		}
		return comprobante;
	}
	
	private ComprobanteBean generaComprobanteGEM(Document doc, XPath xpath){
		ComprobanteBean comprobante = new ComprobanteBean();
		try {
			String nm = this.getMainNodeValue();
			String version = (String)xpath.evaluate(nm + "/cbc:CustomizationID", doc, XPathConstants.STRING);
			if(log.isDebugEnabled()) log.debug(">> Version del documento = "+version) ;
			if(Double.parseDouble(version)<2)
				comprobante = generaComprobanteGEMV1(doc, xpath) ;
			else 			
				comprobante = generaComprobanteGEMV2(doc, xpath) ;			
		}catch(ServiceException se){
			log.error(se, se) ; 
			throw se ; 
		}catch (Exception e) {
			log.error(e, e) ; 
			throw new ServiceException(this, "Ocurrio un error generando el ComprobanteBean de comprobante GEM.") ; 
		}
		return comprobante;
	}
	
	/**
	 * Genera comprobante de Factura GEM UBL 2.1
	 * @param doc
	 * @param xpath
	 * @return
	 */
	private ComprobanteBean generaComprobanteGEMV2(Document doc, XPath xpath){
		ComprobanteBean comprobante = new ComprobanteBean();
		if(log.isInfoEnabled()) log.info(" >> Generando ComprobanteBean de GEM generaComprobanteGEMV2.");
		try {
			String nm = this.getMainNodeValue();
			Object tmpObj = null ;
			Object tmpObjAlt = null ;
			Node nodeItem = null ; 
			String identifier = "" ;
			
			tmpObj = xpath.evaluate(nm + "/cac:AccountingSupplierParty/cac:Party/cac:PartyTaxScheme/cbc:CompanyID", doc, XPathConstants.STRING) ;
			tmpObjAlt = xpath.evaluate(nm + "/cac:AccountingSupplierParty/cac:Party/cac:PartyIdentification/cbc:ID", doc, XPathConstants.STRING) ;
			comprobante.setNumeroRuc( tmpObj!=null && tmpObj.toString().length()>0 ? tmpObj.toString() : tmpObjAlt.toString() );
			comprobante.setRazonSocial(xpath.evaluate(nm + "/cac:AccountingSupplierParty/cac:Party/cac:PartyLegalEntity/cbc:RegistrationName", doc, XPathConstants.STRING).toString());			
						
			tmpObj = xpath.evaluate(nm + "/cac:AccountingSupplierParty/cac:Party/cac:PartyLegalEntity/cac:RegistrationAddress/cac:AddressLine/cbc:Line", doc, XPathConstants.STRING) ;  
			comprobante.setNombreCalle( tmpObj!=null && tmpObj.toString().length()>0 ? tmpObj.toString() : "" );
			
			tmpObj = xpath.evaluate(nm + "/cac:AccountingSupplierParty/cac:Party/cac:PartyLegalEntity/cac:RegistrationAddress/cbc:CitySubdivisionName", doc, XPathConstants.STRING) ;  
			comprobante.setNombreUrbanizacion( tmpObj!=null && tmpObj.toString().length()>0 ? tmpObj.toString() : "" );
			
			tmpObj = xpath.evaluate(nm + "/cac:AccountingSupplierParty/cac:Party/cac:PartyLegalEntity/cac:RegistrationAddress/cbc:District", doc, XPathConstants.STRING) ;  
			comprobante.setNombreDistrito( tmpObj!=null && tmpObj.toString().length()>0 ? tmpObj.toString() : "" );
			
			tmpObj = xpath.evaluate(nm + "/cac:AccountingSupplierParty/cac:Party/cac:PartyLegalEntity/cac:RegistrationAddress/cbc:CityName", doc, XPathConstants.STRING) ;  
			comprobante.setNombreProvincia( tmpObj!=null && tmpObj.toString().length()>0 ? tmpObj.toString() : "" );
			
			tmpObj = xpath.evaluate(nm + "/cac:AccountingSupplierParty/cac:Party/cac:PartyLegalEntity/cac:RegistrationAddress/cbc:CountrySubentity", doc, XPathConstants.STRING) ;  
			comprobante.setNombreDepartamento( tmpObj!=null && tmpObj.toString().length()>0 ? tmpObj.toString() : "" );
			
			tmpObj = xpath.evaluate(nm + "/cac:AccountingSupplierParty/cac:Party/cac:PartyLegalEntity/cac:RegistrationAddress/cac:Country/cbc:IdentificationCode", doc, XPathConstants.STRING) ;  
			comprobante.setCodigoPais( tmpObj!=null && tmpObj.toString().length()>0 ? tmpObj.toString() : "" );
	
			tmpObj = comprobante.getNombreCalle()+comprobante.getNombreUrbanizacion()+comprobante.getNombreDistrito()+comprobante.getNombreProvincia()+comprobante.getNombreDepartamento();
			
			comprobante.setDireccionCompleta( tmpObj.toString().length()==0 ? "" 
												: comprobante.getNombreCalle()+", "+comprobante.getNombreUrbanizacion()+", "+
												  comprobante.getNombreDistrito()+", "+comprobante.getNombreProvincia()+", "+
												  comprobante.getNombreDepartamento()+", "+comprobante.getCodigoPais()
											);
			
			if(log.isDebugEnabled()) log.debug(">> Step 1 :: Complet� Datos del emisor.") ;
			
			comprobante.setNombreCliente(xpath.evaluate(nm + "/cac:AccountingCustomerParty/cac:Party/cac:PartyLegalEntity/cbc:RegistrationName", doc, XPathConstants.STRING).toString());

			tmpObj = xpath.evaluate(nm + "/cac:AccountingCustomerParty/cac:Party/cac:PartyTaxScheme/cbc:CompanyID/@schemeID", doc, XPathConstants.STRING) ;
			tmpObjAlt = xpath.evaluate(nm + "/cac:AccountingCustomerParty/cac:Party/cac:PartyIdentification/cbc:ID/@schemeID", doc, XPathConstants.STRING) ;
			comprobante.setTipoDocumentoCliente( tmpObj!=null && tmpObj.toString().length()>0 ? tmpObj.toString() : tmpObjAlt.toString() );
			comprobante.setDesTipoDocumentoCliente( obtenerDescCatalogo06( comprobante.getTipoDocumentoCliente() ));
			
			tmpObj = xpath.evaluate(nm + "/cac:AccountingCustomerParty/cac:Party/cac:PartyTaxScheme/cbc:CompanyID", doc, XPathConstants.STRING) ;
			tmpObjAlt = xpath.evaluate(nm + "/cac:AccountingCustomerParty/cac:Party/cac:PartyIdentification/cbc:ID", doc, XPathConstants.STRING) ;
			comprobante.setNumeroDocumentoCliente( tmpObj!=null && tmpObj.toString().length()>0 ? tmpObj.toString() : tmpObjAlt.toString() );
			
			if(log.isDebugEnabled()) log.debug(">> Step 2 :: Complet� Datos del comprador.") ;
						
			comprobante.setSerieComprobante( xpath.evaluate(nm + "/cbc:ID", doc, XPathConstants.STRING).toString() );
			comprobante.setFechaEmision(xpath.evaluate(nm + "/cbc:IssueDate", doc, XPathConstants.STRING).toString()) ;
			comprobante.setCodigoMoneda(xpath.evaluate(nm + "/cbc:DocumentCurrencyCode", doc, XPathConstants.STRING).toString());
			
			if(log.isDebugEnabled()) log.debug(">> Step 3 :: Complet� Datos del comprobante") ;
			
			NodeList nlItems = (NodeList)xpath.evaluate(nm + "/cac:InvoiceLine",  doc, XPathConstants.NODESET);
			if(nlItems.getLength() > 0) {
				List <DetalleComprobanteBean> aDetalleComprobante = new ArrayList<DetalleComprobanteBean>();
				DetalleComprobanteBean linea = null;
				for(int i = 0; i < nlItems.getLength(); i++) {
					nodeItem = (Node)nlItems.item(i);
					linea = new DetalleComprobanteBean();	
					
					tmpObj = xpath.evaluate("cbc:InvoicedQuantity", nodeItem, XPathConstants.STRING) ;
					linea.setCantidad( tmpObj!=null && tmpObj.toString().length()>0 ? ComprobanteUtilBean.formatTwoDecimal(tmpObj.toString()) : "" );
					
					tmpObj = xpath.evaluate("cbc:InvoicedQuantity/@unitCode", nodeItem, XPathConstants.STRING) ;
					linea.setUnidadMedida( tmpObj!=null && tmpObj.toString().length()>0 ? tmpObj.toString() : "" );
					
					tmpObj = xpath.evaluate("cac:Item/cac:SellersItemIdentification/cbc:ID", nodeItem, XPathConstants.STRING) ; 
					linea.setCodigoItem( tmpObj!=null && tmpObj.toString().length()>0 ? tmpObj.toString() : "" );
					
					tmpObj = xpath.evaluate("cac:Item/cbc:Description", nodeItem, XPathConstants.STRING) ;
					linea.setDescripcion( tmpObj!=null && tmpObj.toString().length()>0 ? tmpObj.toString() : "" );
					
					tmpObj = xpath.evaluate("cac:Price/cbc:PriceAmount", nodeItem, XPathConstants.STRING);
					linea.setValorVtaUnitario(tmpObj!=null && tmpObj.toString().length()>0 ? ComprobanteUtilBean.formatTwoDecimal(tmpObj.toString()) : "" );
					/** El valor de venta total (V.V.U * Cantidad) */
					tmpObj = xpath.evaluate("cbc:LineExtensionAmount", nodeItem, XPathConstants.STRING) ; 
					linea.setTotalVentaPorItem( tmpObj!=null && tmpObj.toString().length()>0 ? ComprobanteUtilBean.formatTwoDecimal(tmpObj.toString()) : "" );
					
					tmpObj = xpath.evaluate("cac:PricingReference/cac:AlternativeConditionPrice/cbc:PriceAmount", nodeItem, XPathConstants.STRING) ; 
					linea.setPrecioUnitario(tmpObj!=null && tmpObj.toString().length()>0 ? ComprobanteUtilBean.formatTwoDecimal(tmpObj.toString()) : "");
					
					// PAS20191U210100119
					linea.setImporteICBPER("0.00");
					linea.setNumeroBolsas(0);
					
					NodeList nodeTaxSubTotals = (NodeList) xpath.evaluate("cac:TaxTotal/cac:TaxSubtotal", nodeItem, XPathConstants.NODESET);
					for(int j = 0; j < nodeTaxSubTotals.getLength(); j++) {
						Node nodeTaxSubTotal = (Node)nodeTaxSubTotals.item(j);
						
						tmpObj = xpath.evaluate("cac:TaxCategory/cac:TaxScheme/cbc:ID", nodeTaxSubTotal, XPathConstants.STRING) ;
						if(tmpObj.toString().trim().equals("1000")){ 	/** Monto del IGV de la l�nea */
							tmpObj = xpath.evaluate("cbc:TaxAmount", nodeTaxSubTotal, XPathConstants.STRING) ;
							linea.setIgvMonto(tmpObj!=null && tmpObj.toString().length()>0 ? ComprobanteUtilBean.formatTwoDecimal(tmpObj.toString()) : "");
						}else if(tmpObj.toString().trim().equals("2000")){ /** Monto del ISC de la l�nea */
							tmpObj = xpath.evaluate("cbc:TaxAmount", nodeTaxSubTotal, XPathConstants.STRING) ;
							linea.setIscSistema(tmpObj!=null && tmpObj.toString().length()>0 ? ComprobanteUtilBean.formatTwoDecimal(tmpObj.toString()) : "");
						}
						// PAS20191U210100119
						else if(tmpObj.toString().trim().equals("7152")){ /** Monto del ICBPER */
							if(log.isDebugEnabled()) log.debug("Detalle - recupera ICBPER");
							tmpObj = xpath.evaluate("cac:TaxCategory/cbc:PerUnitAmount", nodeTaxSubTotal, XPathConstants.STRING);
							linea.setValorICBPER(tmpObj!=null && tmpObj.toString().length()>0 ? ComprobanteUtilBean.formatTwoDecimal(tmpObj.toString()) : "0.00");
							
							tmpObj = xpath.evaluate("cbc:BaseUnitMeasure", nodeTaxSubTotal, XPathConstants.STRING);
							linea.setNumeroBolsas(tmpObj!=null && tmpObj.toString().length()>0 ? Integer.parseInt(tmpObj.toString()): 0);
							
							//linea.setImporteICBPER(ComprobanteUtilBean.formatTwoDecimal((new BigDecimal(linea.getValorICBPER())).multiply(new BigDecimal(linea.getNumeroBolsas()))));
							tmpObj = xpath.evaluate("cbc:TaxAmount", nodeTaxSubTotal, XPathConstants.STRING);
							linea.setImporteICBPER(tmpObj!=null && tmpObj.toString().length()>0 ? ComprobanteUtilBean.formatTwoDecimal(tmpObj.toString()) : "0.00");
						}
					}
					
					aDetalleComprobante.add(linea);
				}
				comprobante.setDetalleComprobanteBean(aDetalleComprobante);
			}
			
			if(log.isDebugEnabled()) log.debug(">> Step 4 :: Complet� Datos del Items(lineas) de la Nota de d�bito.") ;
			
			NodeList additDocs = (NodeList)xpath.evaluate(nm + "/cac:DespatchDocumentReference", doc, XPathConstants.NODESET);
			if(additDocs.getLength() > 0) {					
				for(int i=0 ;i<additDocs.getLength(); i++){
					DocumentoRelacionadoBean docrel = new DocumentoRelacionadoBean() ; 
					nodeItem = (Node)additDocs.item(i);		
					identifier = xpath.evaluate("cbc:DocumentTypeCode", nodeItem, XPathConstants.STRING).toString().trim() ;
					docrel.setTipoComprobante( identifier ) ; 
					docrel.setDescTipoComprobanteRelacionado( obtenerDescCatalogo01( identifier ) );
					docrel.setSerieComprobanteRelacionado( xpath.evaluate("cbc:ID", nodeItem, XPathConstants.STRING).toString() ) ;	
					comprobante.getDocumentoRelacionadoBean().add(docrel) ; 
				}
			}
			additDocs = (NodeList)xpath.evaluate(nm + "/cac:AdditionalDocumentReference", doc, XPathConstants.NODESET);
			if(additDocs.getLength() > 0) {					
				for(int i=0 ;i<additDocs.getLength(); i++){
					DocumentoRelacionadoBean docrel = new DocumentoRelacionadoBean() ; 
					nodeItem = (Node)additDocs.item(i);		
					identifier = xpath.evaluate("cbc:DocumentTypeCode", nodeItem, XPathConstants.STRING).toString().trim() ;
					docrel.setTipoComprobante( identifier ) ; 
					docrel.setDescTipoComprobanteRelacionado( obtenerDescCatalogo12( identifier ) );
					docrel.setSerieComprobanteRelacionado( xpath.evaluate("cbc:ID", nodeItem, XPathConstants.STRING).toString() ) ;	
					comprobante.getDocumentoRelacionadoBean().add(docrel) ; 
				}
			}	
			
			if(log.isDebugEnabled()) log.debug(">> Step 5 :: Complet� documentos relacionados de la factura.") ;
			
			NodeList aditionalProperty = (NodeList)xpath.evaluate(nm + "/ext:UBLExtensions/ext:UBLExtension/ext:ExtensionContent/sac:AdditionalInformation/sac:AdditionalProperty", doc, XPathConstants.NODESET);
			if(aditionalProperty.getLength() > 0) {
				List<Map<String,String>> leyenda = new ArrayList<Map<String,String>>();
				Map<String,String> map = null ;
				for(int i=0 ;i<aditionalProperty.getLength(); i++){
					nodeItem = (Node)aditionalProperty.item(i);					
					map = new HashMap<String, String>();					
					map.put("id", xpath.evaluate("cbc:ID", nodeItem, XPathConstants.STRING).toString()  );
					map.put("valor", xpath.evaluate("cbc:Value", nodeItem, XPathConstants.STRING).toString());
					 
					leyenda.add(map);
				}
				comprobante.setLeyenda(leyenda);
			}
			
			if(log.isDebugEnabled()) log.debug(">> Step 6 :: Complet� datos de leyenda.");
			
			// PAS20191U210100119
			comprobante.setTotalICBPER(BigDecimal.ZERO);
            
			NodeList totalesOtros = (NodeList)xpath.evaluate(nm + "/cac:TaxTotal/cac:TaxSubtotal",  doc, XPathConstants.NODESET);			
			if(totalesOtros.getLength() > 0) {
				for(int i=0 ;i<totalesOtros.getLength(); i++){
					nodeItem = (Node)totalesOtros.item(i);
					identifier = xpath.evaluate("cac:TaxCategory/cac:TaxScheme/cbc:ID", nodeItem, XPathConstants.STRING).toString() ;
					if("1000".equals(identifier)){
						comprobante.setTotalIGV(ComprobanteUtilBean.toBigDecimal(xpath.evaluate("cbc:TaxAmount", nodeItem, XPathConstants.STRING).toString()));
						comprobante.setTotalValorVenta(ComprobanteUtilBean.toBigDecimal(xpath.evaluate("cbc:TaxableAmount", nodeItem, XPathConstants.STRING).toString()));
					}else if("2000".equals(identifier)){ 
						comprobante.setTotalISC(ComprobanteUtilBean.toBigDecimal(xpath.evaluate("cbc:TaxAmount", nodeItem, XPathConstants.STRING).toString()));
					}else if("9999".equals(identifier)){
						comprobante.setTotalOtrosTributos(ComprobanteUtilBean.toBigDecimal(xpath.evaluate("cbc:TaxAmount", nodeItem, XPathConstants.STRING).toString()));
					}else if("9998".equals(identifier)){ 
						comprobante.setTotalValorVentaNoGravado(ComprobanteUtilBean.toBigDecimal(xpath.evaluate("cbc:TaxableAmount", nodeItem, XPathConstants.STRING).toString()));
					}else if("9997".equals(identifier)){ 
						comprobante.setTotalValorVentaExonerado(ComprobanteUtilBean.toBigDecimal(xpath.evaluate("cbc:TaxableAmount", nodeItem, XPathConstants.STRING).toString()));
					}else if("9996".equals(identifier)){ 
						comprobante.setTotalValorVentaOperaGratuitas(ComprobanteUtilBean.toBigDecimal(xpath.evaluate("cbc:TaxableAmount", nodeItem, XPathConstants.STRING).toString()));
					}else if("9995".equals(identifier)){ 
						comprobante.setTotalValorVentaExportacion(ComprobanteUtilBean.toBigDecimal(xpath.evaluate("cbc:TaxableAmount", nodeItem, XPathConstants.STRING).toString()));
					}
					// PAS20191U210100119
					else if("7152".equals(identifier)){
						if(log.isDebugEnabled()) log.debug("Total - recupera ICBPER");
						tmpObj = xpath.evaluate("cbc:TaxAmount", nodeItem, XPathConstants.STRING);
						comprobante.setTotalICBPER(tmpObj!=null && tmpObj.toString().length()>0 ? ComprobanteUtilBean.toBigDecimal(tmpObj.toString()): BigDecimal.ZERO);						
					}
				}				
			}
			
			NodeList descGlobales = (NodeList)xpath.evaluate(nm + "/cac:AllowanceCharge",  doc, XPathConstants.NODESET);			
			if(descGlobales.getLength() > 0) {
				for(int i=0 ;i<descGlobales.getLength(); i++){
					nodeItem = (Node)descGlobales.item(i);
					identifier = xpath.evaluate("cbc:AllowanceChargeReasonCode", nodeItem, XPathConstants.STRING).toString() ;
					if("02".equals(identifier)){
						comprobante.setTotalDescGlobalBI(ComprobanteUtilBean.toBigDecimal(xpath.evaluate("cbc:Amount", nodeItem, XPathConstants.STRING).toString()));
					}else if("03".equals(identifier)){ 
						comprobante.setTotalDescGlobalNBI(ComprobanteUtilBean.toBigDecimal(xpath.evaluate("cbc:Amount", nodeItem, XPathConstants.STRING).toString()));
					}
				}				
			}
			
			tmpObj = xpath.evaluate(nm+"/cac:LegalMonetaryTotal/cbc:ChargeTotalAmount", doc, XPathConstants.STRING);
			comprobante.setTotalOtrosCargos(tmpObj!=null && tmpObj.toString().length()>0 ? ComprobanteUtilBean.toBigDecimal(tmpObj.toString()) : new BigDecimal(0.00));
			
			tmpObj = xpath.evaluate(nm+"/cac:LegalMonetaryTotal/cbc:AllowanceTotalAmount", doc, XPathConstants.STRING);
			comprobante.setTotalDescuentos(tmpObj!=null && tmpObj.toString().length()>0 ? ComprobanteUtilBean.toBigDecimal(tmpObj.toString()) : new BigDecimal(0.00));
			
			comprobante.setMontoTotalGeneral(ComprobanteUtilBean.toBigDecimal((String)xpath.evaluate(nm + "/cac:LegalMonetaryTotal/cbc:PayableAmount", doc, XPathConstants.STRING)));
			
			if(log.isDebugEnabled()) log.debug(">> Step 6 :: Complet� datos de totales.");
			
		} catch(ServiceException e) {
			log.error(e);
			throw e;
		} catch(Exception e) {
			e.printStackTrace();
			log.error(e);
			throw new ServiceException(this, e.getLocalizedMessage());
		}
		return comprobante;
	}	
	
	
	/**
	 * Genera comprobante de Factura GEM
	 * @param doc
	 * @param xpath
	 * @return
	 */
	private ComprobanteBean generaComprobanteGEMV1(Document doc, XPath xpath){
		ComprobanteBean comprobante = new ComprobanteBean();
		if(log.isInfoEnabled()) log.info(" >> Generando ComprobanteBean de GEM .");
		try {
			String nm = this.getMainNodeValue();
			Object tmpObj = null ; 
			Node nodeItem = null ; 
			String identifier = "" ;
			
			comprobante.setNumeroRuc(xpath.evaluate(nm + "/cac:AccountingSupplierParty/cbc:CustomerAssignedAccountID", doc, XPathConstants.STRING).toString());
			comprobante.setRazonSocial(xpath.evaluate(nm + "/cac:AccountingSupplierParty/cac:Party/cac:PartyLegalEntity/cbc:RegistrationName", doc, XPathConstants.STRING).toString());
			
			tmpObj = xpath.evaluate(nm + "/cac:AccountingSupplierParty/cac:Party/cac:PostalAddress/cbc:StreetName", doc, XPathConstants.STRING) ;  
			comprobante.setNombreCalle( tmpObj!=null && tmpObj.toString().length()>0 ? tmpObj.toString() : "" );
			
			tmpObj = xpath.evaluate(nm + "/cac:AccountingSupplierParty/cac:Party/cac:PostalAddress/cbc:CitySubdivisionName", doc, XPathConstants.STRING) ;  
			comprobante.setNombreUrbanizacion( tmpObj!=null && tmpObj.toString().length()>0 ? tmpObj.toString() : "" );
			
			tmpObj = xpath.evaluate(nm + "/cac:AccountingSupplierParty/cac:Party/cac:PostalAddress/cbc:District", doc, XPathConstants.STRING) ;  
			comprobante.setNombreDistrito( tmpObj!=null && tmpObj.toString().length()>0 ? tmpObj.toString() : "" );
			
			tmpObj = xpath.evaluate(nm + "/cac:AccountingSupplierParty/cac:Party/cac:PostalAddress/cbc:CityName", doc, XPathConstants.STRING) ;  
			comprobante.setNombreProvincia( tmpObj!=null && tmpObj.toString().length()>0 ? tmpObj.toString() : "" );
			
			tmpObj = xpath.evaluate(nm + "/cac:AccountingSupplierParty/cac:Party/cac:PostalAddress/cbc:CountrySubentity", doc, XPathConstants.STRING) ;  
			comprobante.setNombreDepartamento( tmpObj!=null && tmpObj.toString().length()>0 ? tmpObj.toString() : "" );
			
			tmpObj = xpath.evaluate(nm + "/cac:AccountingSupplierParty/cac:Party/cac:PostalAddress/cac:Country/cbc:IdentificationCode", doc, XPathConstants.STRING) ;  
			comprobante.setCodigoPais( tmpObj!=null && tmpObj.toString().length()>0 ? tmpObj.toString() : "" );
	
			tmpObj = comprobante.getNombreCalle()+comprobante.getNombreUrbanizacion()+comprobante.getNombreDistrito()+comprobante.getNombreProvincia()+comprobante.getNombreDepartamento();
			
			comprobante.setDireccionCompleta( tmpObj.toString().length()==0 ? "" 
												: comprobante.getNombreCalle()+", "+comprobante.getNombreUrbanizacion()+", "+
												  comprobante.getNombreDistrito()+", "+comprobante.getNombreProvincia()+", "+
												  comprobante.getNombreDepartamento()+", "+comprobante.getCodigoPais()
											);
			
			if(log.isDebugEnabled()) log.debug(">> Step 1 :: Complet� Datos del emisor.") ;
			
			comprobante.setTipoDocumentoCliente(xpath.evaluate(nm + "/cac:AccountingCustomerParty/cbc:AdditionalAccountID", doc, XPathConstants.STRING).toString());
			comprobante.setDesTipoDocumentoCliente( obtenerDescCatalogo06( comprobante.getTipoDocumentoCliente() ));
			
			comprobante.setNumeroDocumentoCliente(xpath.evaluate(nm + "/cac:AccountingCustomerParty/cbc:CustomerAssignedAccountID", doc, XPathConstants.STRING).toString());			                                               
			comprobante.setNombreCliente(xpath.evaluate(nm + "/cac:AccountingCustomerParty/cac:Party/cac:PartyLegalEntity/cbc:RegistrationName", doc, XPathConstants.STRING).toString());
			
			if(log.isDebugEnabled()) log.debug(">> Step 2 :: Complet� Datos del comprador.") ;
						
			comprobante.setSerieComprobante( xpath.evaluate(nm + "/cbc:ID", doc, XPathConstants.STRING).toString() );
			comprobante.setFechaEmision(xpath.evaluate(nm + "/cbc:IssueDate", doc, XPathConstants.STRING).toString()) ;
			comprobante.setCodigoMoneda(xpath.evaluate(nm + "/cbc:DocumentCurrencyCode", doc, XPathConstants.STRING).toString());
			
			if(log.isDebugEnabled()) log.debug(">> Step 3 :: Complet� Datos del comprobante") ;
			
			NodeList nlItems = (NodeList)xpath.evaluate(nm + "/cac:InvoiceLine",  doc, XPathConstants.NODESET);
			if(nlItems.getLength() > 0) {
				List <DetalleComprobanteBean> aDetalleComprobante = new ArrayList<DetalleComprobanteBean>();
				DetalleComprobanteBean linea = null;
				for(int i = 0; i < nlItems.getLength(); i++) {
					nodeItem = (Node)nlItems.item(i);
					linea = new DetalleComprobanteBean();	
					
					tmpObj = xpath.evaluate("cbc:InvoicedQuantity", nodeItem, XPathConstants.STRING) ;
					linea.setCantidad( tmpObj!=null && tmpObj.toString().length()>0 ? ComprobanteUtilBean.formatTwoDecimal(tmpObj.toString()) : "" );
					
					tmpObj = xpath.evaluate("cbc:InvoicedQuantity/@unitCode", nodeItem, XPathConstants.STRING) ;
					linea.setUnidadMedida( tmpObj!=null && tmpObj.toString().length()>0 ? tmpObj.toString() : "" );
					
					tmpObj = xpath.evaluate("cac:Item/cac:SellersItemIdentification/cbc:ID", nodeItem, XPathConstants.STRING) ; 
					linea.setCodigoItem( tmpObj!=null && tmpObj.toString().length()>0 ? tmpObj.toString() : "" );
					
					tmpObj = xpath.evaluate("cac:Item/cbc:Description", nodeItem, XPathConstants.STRING) ;
					linea.setDescripcion( tmpObj!=null && tmpObj.toString().length()>0 ? tmpObj.toString() : "" );
					
					tmpObj = xpath.evaluate("cac:Price/cbc:PriceAmount", nodeItem, XPathConstants.STRING);
					linea.setValorVtaUnitario(tmpObj!=null && tmpObj.toString().length()>0 ? ComprobanteUtilBean.formatTwoDecimal(tmpObj.toString()) : "" );
					/** El valor de venta total (V.V.U * Cantidad) */
					tmpObj = xpath.evaluate("cbc:LineExtensionAmount", nodeItem, XPathConstants.STRING) ; 
					linea.setTotalVentaPorItem( tmpObj!=null && tmpObj.toString().length()>0 ? ComprobanteUtilBean.formatTwoDecimal(tmpObj.toString()) : "" );
					
					tmpObj = xpath.evaluate("cac:PricingReference/cac:AlternativeConditionPrice/cbc:PriceAmount", nodeItem, XPathConstants.STRING) ; 
					linea.setPrecioUnitario(tmpObj!=null && tmpObj.toString().length()>0 ? ComprobanteUtilBean.formatTwoDecimal(tmpObj.toString()) : "");
										
					tmpObj = xpath.evaluate("cac:TaxTotal/cac:TaxSubtotal/cac:TaxCategory/cac:TaxScheme/cbc:ID", nodeItem, XPathConstants.STRING) ;
					if(tmpObj.toString().trim().equals("1000")){ 	/** Monto del IGV de la l�nea */
						tmpObj = xpath.evaluate("cac:TaxTotal/cbc:TaxAmount", nodeItem, XPathConstants.STRING) ;
						linea.setIgvMonto(tmpObj!=null && tmpObj.toString().length()>0 ? ComprobanteUtilBean.formatTwoDecimal(tmpObj.toString()) : "");
					}else if(tmpObj.toString().trim().equals("2000")){ /** Monto del ISC de la l�nea */
						tmpObj = xpath.evaluate("cac:TaxTotal/cbc:TaxAmount", nodeItem, XPathConstants.STRING) ;
						linea.setIscSistema(tmpObj!=null && tmpObj.toString().length()>0 ? ComprobanteUtilBean.formatTwoDecimal(tmpObj.toString()) : "");
					}					
					aDetalleComprobante.add(linea);
				}
				comprobante.setDetalleComprobanteBean(aDetalleComprobante);
			}
			
			if(log.isDebugEnabled()) log.debug(">> Step 4 :: Complet� Datos del Items(lineas) de la Nota de d�bito.") ;
			
			NodeList additDocs = (NodeList)xpath.evaluate(nm + "/cac:DespatchDocumentReference", doc, XPathConstants.NODESET);
			if(additDocs.getLength() > 0) {					
				for(int i=0 ;i<additDocs.getLength(); i++){
					DocumentoRelacionadoBean docrel = new DocumentoRelacionadoBean() ; 
					nodeItem = (Node)additDocs.item(i);		
					identifier = xpath.evaluate("cbc:DocumentTypeCode", nodeItem, XPathConstants.STRING).toString().trim() ;
					docrel.setTipoComprobante( identifier ) ; 
					docrel.setDescTipoComprobanteRelacionado( obtenerDescCatalogo01( identifier ) );
					docrel.setSerieComprobanteRelacionado( xpath.evaluate("cbc:ID", nodeItem, XPathConstants.STRING).toString() ) ;	
					comprobante.getDocumentoRelacionadoBean().add(docrel) ; 
				}
			}
			additDocs = (NodeList)xpath.evaluate(nm + "/cac:AdditionalDocumentReference", doc, XPathConstants.NODESET);
			if(additDocs.getLength() > 0) {					
				for(int i=0 ;i<additDocs.getLength(); i++){
					DocumentoRelacionadoBean docrel = new DocumentoRelacionadoBean() ; 
					nodeItem = (Node)additDocs.item(i);		
					identifier = xpath.evaluate("cbc:DocumentTypeCode", nodeItem, XPathConstants.STRING).toString().trim() ;
					docrel.setTipoComprobante( identifier ) ; 
					docrel.setDescTipoComprobanteRelacionado( obtenerDescCatalogo12( identifier ) );
					docrel.setSerieComprobanteRelacionado( xpath.evaluate("cbc:ID", nodeItem, XPathConstants.STRING).toString() ) ;	
					comprobante.getDocumentoRelacionadoBean().add(docrel) ; 
				}
			}	
			
			if(log.isDebugEnabled()) log.debug(">> Step 5 :: Complet� documentos relacionados de la factura.") ;
			
			NodeList aditionalProperty = (NodeList)xpath.evaluate(nm + "/ext:UBLExtensions/ext:UBLExtension/ext:ExtensionContent/sac:AdditionalInformation/sac:AdditionalProperty", doc, XPathConstants.NODESET);
			if(aditionalProperty.getLength() > 0) {
				List<Map<String,String>> leyenda = new ArrayList<Map<String,String>>();
				Map<String,String> map = null ;
				for(int i=0 ;i<aditionalProperty.getLength(); i++){
					nodeItem = (Node)aditionalProperty.item(i);					
					map = new HashMap<String, String>();					
					map.put("id", xpath.evaluate("cbc:ID", nodeItem, XPathConstants.STRING).toString()  );
					map.put("valor", xpath.evaluate("cbc:Value", nodeItem, XPathConstants.STRING).toString());
					 
					leyenda.add(map);
				}
				comprobante.setLeyenda(leyenda);
			}
			
			if(log.isDebugEnabled()) log.debug(">> Step 6 :: Complet� datos de leyenda.");
			
			NodeList totalesVenta = (NodeList)xpath.evaluate(nm + "/ext:UBLExtensions/ext:UBLExtension/ext:ExtensionContent/sac:AdditionalInformation/sac:AdditionalMonetaryTotal", doc, XPathConstants.NODESET);
			if(totalesVenta.getLength() > 0) {					
				for(int i=0 ;i<totalesVenta.getLength(); i++){
					nodeItem = (Node)totalesVenta.item(i);
					identifier = xpath.evaluate("cbc:ID", nodeItem, XPathConstants.STRING).toString() ;
					if("1001".equals(identifier)){
						comprobante.setTotalValorVenta(ComprobanteUtilBean.toBigDecimal(xpath.evaluate("cbc:PayableAmount", nodeItem, XPathConstants.STRING).toString()));
					}else if("1002".equals(identifier)){ // valor de venta inafecta
						comprobante.setTotalValorVentaNoGravado(ComprobanteUtilBean.toBigDecimal(xpath.evaluate("cbc:PayableAmount", nodeItem, XPathConstants.STRING).toString()));
					}else if("1003".equals(identifier)){
						comprobante.setTotalValorVentaExonerado(ComprobanteUtilBean.toBigDecimal(xpath.evaluate("cbc:PayableAmount", nodeItem, XPathConstants.STRING).toString()));					
					}else if("2001".equals(identifier)){						
						comprobante.setImporteDePercepcion(ComprobanteUtilBean.toBigDecimal(xpath.evaluate("cbc:PayableAmount", nodeItem, XPathConstants.STRING).toString()));
					}else if("2005".equals(identifier)){
						comprobante.setTotalDescuentos(ComprobanteUtilBean.toBigDecimal(xpath.evaluate("cbc:PayableAmount", nodeItem, XPathConstants.STRING).toString()));
					}
				}
			}
            
			NodeList totalesOtros = (NodeList)xpath.evaluate(nm + "/cac:TaxTotal/cac:TaxSubtotal",  doc, XPathConstants.NODESET);			
			if(totalesOtros.getLength() > 0) {
				for(int i=0 ;i<totalesOtros.getLength(); i++){
					nodeItem = (Node)totalesOtros.item(i);
					identifier = xpath.evaluate("cac:TaxCategory/cac:TaxScheme/cbc:ID", nodeItem, XPathConstants.STRING).toString() ;
					if("1000".equals(identifier)){
						comprobante.setTotalIGV(ComprobanteUtilBean.toBigDecimal(xpath.evaluate("cbc:TaxAmount", nodeItem, XPathConstants.STRING).toString()));
					}else if("2000".equals(identifier)){ 
						comprobante.setTotalISC(ComprobanteUtilBean.toBigDecimal(xpath.evaluate("cbc:TaxAmount", nodeItem, XPathConstants.STRING).toString()));
					}else if("9999".equals(identifier)){
						comprobante.setTotalOtrosTributos(ComprobanteUtilBean.toBigDecimal(xpath.evaluate("cbc:TaxAmount", nodeItem, XPathConstants.STRING).toString()));
					}
				}				
			}
			
			tmpObj = xpath.evaluate(nm+"/cac:LegalMonetaryTotal/cbc:ChargeTotalAmount", doc, XPathConstants.STRING);
			comprobante.setTotalOtrosCargos(tmpObj!=null && tmpObj.toString().length()>0 ? ComprobanteUtilBean.toBigDecimal(tmpObj.toString()) : new BigDecimal(0.00));
			  
			comprobante.setMontoTotalGeneral(ComprobanteUtilBean.toBigDecimal((String)xpath.evaluate(nm + "/cac:LegalMonetaryTotal/cbc:PayableAmount", doc, XPathConstants.STRING)));		
			
			if(log.isDebugEnabled()) log.debug(">> Step 6 :: Complet� datos de totales.");
			
		} catch(ServiceException e) {
			log.error(e);
			throw e;
		} catch(Exception e) {
			e.printStackTrace();
			log.error(e);
			throw new ServiceException(this, e.getLocalizedMessage());
		}
		return comprobante;
	}	
	
	
	/**
	 * Catalogo de Nro. 01 C�digo de tipo de documento autorizado para efectos tributarios.
	 * @param codigo
	 * @return
	 */
	private String obtenerDescCatalogo01(String codigo){
		String result = "";
		if ("01".equals(codigo)) result= "FACTURA"; 
		else if ("03".equals(codigo) ) result= "BOLETA DE VENTA"; 
		else if ("07".equals(codigo) ) result= "NOTA DE CREDITO"; 
		else if ("08".equals(codigo) ) result= "NOTA DE DEBITO"; 
		else if ("09".equals(codigo) ) result= "GUIA DE REMISI�N REMITENTE";		
		else if ("12".equals(codigo) ) result= "TICKET DE MAQUINA REGISTRADORA";
		else if ("31".equals(codigo) ) result= "GUIA DE REMISI�N TRANSPORTISTA";
		return result ; 
	}
	
	/**
	 * Catalogo de Nro. 06 Tipo de Documento de Identificaci�n. 
	 * @param codigo
	 * @return
	 */
	private String obtenerDescCatalogo06(String codigo){
		String result = "";
		if ("06".equals(codigo) || "6".equals(codigo) ) result= "RUC"; 
		else if ("01".equals(codigo) || "1".equals(codigo) ) result= "DNI"; 
		else if ("04".equals(codigo) || "4".equals(codigo) ) result= "CARNET EXTRANJERIA"; 
		else if ("07".equals(codigo) || "7".equals(codigo) ) result= "PASAPORTE"; 
		else if ("00".equals(codigo) || "0".equals(codigo) ) result= "DOC.TRIB.NO.DOM.SIN.RUC";		
		return result ; 
	}
	
	/**
	 * Catalogo de Nro. 10 Tipo de nota de d�bito seg�n motivo. 
	 * @param codigo
	 * @return
	 */
	@SuppressWarnings("unused")
	private String obtenerDescCatalogo10(String codigo){
		String result = "";
		if(codigo.trim().equals("01")){
			result = "Intereses por mora";
		}else if(codigo.trim().equals("02")){
			result = "Aumento en el valor";
		}
		return result ; 
	}

	/**
	 * Catalogo de Nro. 12 C�digo del tipo de documentos tributarios de referencia. 
	 * @param codigo
	 * @return
	 */
	private String obtenerDescCatalogo12(String codigo){
		String result = "";
		if(codigo.equals("04")){
			result = "Ticket de Salida - ENAPU";
		}else if(codigo.equals("05")){
			result = "C�digo SCOP";
		}else if(codigo.equals("99")){
			result = "Otros";
		}else if(codigo.equals("01")){
			result = "Factura � emitida para corregir error en el RUC";
		}
		return result ; 
	}

	private ComprobanteBean generaComprobantePortal(Document doc, XPath xpath){
		ComprobanteBean comprobante = new ComprobanteBean();
		try {
			String nm = this.getMainNodeValue();
			String version = (String)xpath.evaluate(nm + "/cbc:CustomizationID", doc, XPathConstants.STRING);
			if(log.isDebugEnabled()) log.debug(">> Version del documento = "+version) ;
			if(Double.parseDouble(version)<2)
				comprobante = generaComprobantePortalV1(doc, xpath) ;
			else 			
				comprobante = generaComprobantePortalV2(doc, xpath) ;			
		}catch(ServiceException se){
			log.error(se, se) ; 
			throw se ; 
		}catch (Exception e) {
			log.error(e, e) ; 
			throw new ServiceException(this, "Ocurrio un error generando el ComprobanteBean de factura PORTAL.") ; 
		}
		return comprobante;
	}
	
	
	
	/**
	 * Es una factura de exportacion si el tipo de documento y el n�mero de documento del cliente son "-".
	 * @param doc
	 * @param xpath
	 * @return
	 */
	private boolean isCpeExportacion(Document doc, XPath xpath){
		boolean result = false ; 
		try {
			String nm = this.getMainNodeValue();
			String tipDoc = (String)xpath.evaluate(nm + "/cac:AccountingCustomerParty/cbc:AdditionalAccountID", doc, XPathConstants.STRING);
			String numDoc = (String)xpath.evaluate(nm + "/cac:AccountingCustomerParty/cbc:CustomerAssignedAccountID", doc, XPathConstants.STRING);
			
			if(tipDoc.trim().equals("-") && numDoc.trim().equals("-"))
				result = true ; 
		}catch(ServiceException se ){
			log.error(se,se) ;
			throw se ; 
		}catch (Exception e) {
			log.error(e,e) ;
			throw new ServiceException(this, "Ocurrio un error al verificar si la factura es de exportaci�n.") ; 
		}
		return result ; 
	}
	
	/**
	 * Genera el ComprobanteBean a partir de la version 2.0 de la estructura del documento XMl. 
	 * @param doc
	 * @param xpath
	 * @return
	 */
	private ComprobanteBean generaComprobantePortalV2(Document doc, XPath xpath){
		ComprobanteBean comprobante = new ComprobanteBean();
		
		try {
			if(log.isDebugEnabled()) log.debug("generaComprobantePortalV2") ; 
			log.debug("Document : " + doc.getNodeName());
			log.debug("XPath    : " + xpath);
			String nm = this.getMainNodeValue();
			Object tmpObj = null ; 
			Node nodeItem = null ; 
			String identifier = "" ;
			String id = (String)xpath.evaluate(nm + "/cbc:ID", doc, XPathConstants.STRING);
			
			/** -- Obtenemos el tipo y subtipo de comprobante --*/
			Object oTipoComprobante = xpath.evaluate(nm + "/cbc:InvoiceTypeCode", doc, XPathConstants.STRING);
			if(ComprobanteUtilBean.isStringValid(oTipoComprobante)) {
				String tipoComprobante = ((String)oTipoComprobante).trim();
//				if(tipoComprobante.length() < 4) {
//					throw new ServiceException(this, "El tipo de comprobante debe tener 4 digitos");
//				}
//				else {
					comprobante.setTipoComprobante(tipoComprobante.substring(0, 2));
					if(isCpeExportacion(doc, xpath))
						comprobante.setSubTipoComprobante("02");	// Factura Exportacion					
					else 
						comprobante.setSubTipoComprobante("01");	// Factura Basica
					
					comprobante.setIndicadorExportacion("0");
					if (comprobante.getTipoComprobante().equals("01")){
						if (comprobante.getSubTipoComprobante().equals("02")){
							comprobante.setIndicadorExportacion("1");
						}
					}
//				}				
			}else {
				throw new ServiceException(this, "El XML no contiene el tipo de comprobante");
			}
			/**--------------------------------------------------*/
			comprobante.setVersionXML(2.0);
			comprobante.setNumeroComprobante(new Integer(id.substring(id.indexOf("-") + 1)));
			comprobante.setSerieComprobante(id.substring(0, id.indexOf("-")));
			comprobante.setNumeroRuc((String)xpath.evaluate(nm + "/cac:AccountingSupplierParty/cbc:CustomerAssignedAccountID", doc, XPathConstants.STRING));
			FechaBean fb = new FechaBean((String)xpath.evaluate(nm + "/cbc:IssueDate", doc, XPathConstants.STRING), "yyyy-MM-dd");
			comprobante.setFechaEmision(fb.getFormatDate("dd/MM/yyyy"));
			comprobante.setFechaEmisionOriginal(fb.getFormatDate("dd/MM/yyyy"));
			
			fb.setFecha((String)xpath.evaluate(nm + "/cbc:IssueTime", doc, XPathConstants.STRING), "HH:mm:ss");
			comprobante.setHoraEmision(fb.getFormatDate("HH:mm:ss"));
			
			
			if (xpath.evaluate(nm + "/cbc:ExpiryDate", doc, XPathConstants.STRING) != null ){
				String  fvStr= (String)xpath.evaluate(nm + "/cbc:ExpiryDate", doc, XPathConstants.STRING);
				if (fvStr != null && !fvStr.equals("")){
					if (!((String)xpath.evaluate(nm + "/cbc:ExpiryDate", doc, XPathConstants.STRING)).equals("$cp.getFechaVencimiento()")){
						FechaBean fvenc = new FechaBean((String)xpath.evaluate(nm + "/cbc:ExpiryDate", doc, XPathConstants.STRING), "yyyy-MM-dd");
						comprobante.setFechaVencimiento(fvenc.getFormatDate("dd/MM/yyyy"));
					}
				}
			}
			tmpObj = xpath.evaluate(nm + "/cbc:Note", doc, XPathConstants.STRING) ;  
			comprobante.setObservacion( tmpObj!=null && tmpObj.toString().length()>0 ? tmpObj.toString() : "" );			
						
//			comprobante.setObservacion((String)xpath.evaluate(nm + "/cbc:Note", doc, XPathConstants.STRING));
			comprobante.setTotalValorVentaOperaGratuitas(ComprobanteUtilBean.toBigDecimal("0"));
			comprobante.setTotalSubTotalValorVenta(ComprobanteUtilBean.toBigDecimal("0"));	
			comprobante.setIndicadorVentaNodomic("0");
			comprobante.setDescripcionVentaGratuita("");
			NodeList nodeExtensiones = (NodeList)xpath.evaluate(nm + "/ext:UBLExtensions/ext:UBLExtension/ext:ExtensionContent",  doc, XPathConstants.NODESET);

			if (xpath.evaluate(nm + "/cac:OrderReference/cbc:ID", doc, XPathConstants.STRING) != null){
						comprobante.setOrdenCompra((String)xpath.evaluate(nm + "/cac:OrderReference/cbc:ID", doc, XPathConstants.STRING));
			}
			if(nodeExtensiones.getLength() > 0) {
				nodeItem = null;
				for(int i = 0; i < nodeExtensiones.getLength(); i++) {
					nodeItem = (Node)nodeExtensiones.item(i);
					String codNodo="";
					NodeList nodeProperties = (NodeList)xpath.evaluate("sac:AdditionalInformation/sac:AdditionalProperty",  nodeItem, XPathConstants.NODESET);
					if(nodeProperties.getLength() > 0) {

						for(int j = 0; j < nodeProperties.getLength(); j++) {					
							codNodo=(String)xpath.evaluate("cbc:ID", nodeProperties.item(j), XPathConstants.STRING);
							log.debug("codNodo ----> "  +codNodo);
							if (codNodo != null){
								if (codNodo.equals("1000")){
									comprobante.setMontoTotalTexto((String)xpath.evaluate("cbc:Value", nodeProperties.item(j), XPathConstants.STRING));
								}
								if (codNodo.equals("1002")){
									comprobante.setGlosa((String)xpath.evaluate("cbc:Value", nodeProperties.item(j), XPathConstants.STRING));
									comprobante.setDescripcionVentaGratuita((String)xpath.evaluate("cbc:Value", nodeProperties.item(j), XPathConstants.STRING));
								}
								if (codNodo.equals("1003")){
									comprobante.setDescripcionVentaNoDomic((String)xpath.evaluate("cbc:Value", nodeProperties.item(j), XPathConstants.STRING));
									if (!comprobante.getDescripcionVentaNoDomic().equals("")){
										comprobante.setIndicadorVentaNodomic("1");
									}else{
										comprobante.setIndicadorVentaNodomic("0");
									}
								}
								if (codNodo.equals("5000")){
									comprobante.setNumeroExpediente((String)xpath.evaluate("cbc:Value", nodeProperties.item(j), XPathConstants.STRING));
								}	
								if (codNodo.equals("5001")){
									comprobante.setCodigoUnidadEjecutora((String)xpath.evaluate("cbc:Value", nodeProperties.item(j), XPathConstants.STRING));
								}		
								if (codNodo.equals("5002")){
									comprobante.setNumeroProcesoSeleccion((String)xpath.evaluate("cbc:Value", nodeProperties.item(j), XPathConstants.STRING));
								}	
								if (codNodo.equals("5003")){
									comprobante.setNumeroContrato((String)xpath.evaluate("cbc:Value", nodeProperties.item(j), XPathConstants.STRING));
								}									
							}
						}
					}
					
					nodeProperties = (NodeList)xpath.evaluate("sac:AdditionalInformation/sac:SUNATEmbededDespatchAdvice",  nodeItem, XPathConstants.NODESET);
					if(nodeProperties.getLength() > 0) {
						comprobante.setIndicadorTrasladoBienes("1");
						comprobante.setPuntoPartida(new DireccionComprobanteBean());
						comprobante.setPuntoLlegada(new DireccionComprobanteBean());
						codNodo=(String)xpath.evaluate("cac:OriginAddress/cbc:StreetName", nodeProperties.item(0), XPathConstants.STRING);
						log.debug("Punto Partida ----> "  +codNodo);
						comprobante.getPuntoPartida().setDireccion(codNodo);
						
						codNodo=(String)xpath.evaluate("cac:DeliveryAddress/cbc:StreetName",  nodeProperties.item(0), XPathConstants.STRING);
						log.debug("Punto Llegada ----> "  +codNodo);
						comprobante.getPuntoLlegada().setDireccion(codNodo);
						
						Node nodeItem2 = (Node)nodeProperties.item(i);
						NodeList nodeProperties2 = (NodeList)xpath.evaluate("sac:DriverParty",  nodeItem2, XPathConstants.NODESET);
						if(nodeProperties2.getLength() > 0) {
							
							comprobante.setIndicadorSujetoRealizaTraslado("1");
							codNodo="";
							
							List<String> nroLicenciasConducir= new ArrayList();
							for(int j = 0; j < nodeProperties2.getLength(); j++) {	
								codNodo=(String)xpath.evaluate("cac:Party/cac:PartyIdentification/cbc:ID", nodeProperties2.item(j), XPathConstants.STRING);
								nroLicenciasConducir.add(codNodo);
							}
							
							comprobante.setNroLicenciasConducir(nroLicenciasConducir);
						}
						
						codNodo=(String)xpath.evaluate("sac:SUNATCarrierParty/cbc:CustomerAssignedAccountID",  nodeProperties.item(0), XPathConstants.STRING);
						log.debug("RUC Transportista----> "  +codNodo);
						comprobante.setRucTransportista(codNodo);
						codNodo=(String)xpath.evaluate("sac:SUNATCarrierParty/cac:Party/cac:PartyLegalEntity/cbc:RegistrationName",  nodeProperties.item(0), XPathConstants.STRING);
						log.debug("Razon Social Transportista----> "  +codNodo);
						comprobante.setRazonSocialTransportista(codNodo);

						codNodo=(String)xpath.evaluate("sac:SUNATRoadTransport/cbc:LicensePlateID",  nodeProperties.item(0), XPathConstants.STRING);
						log.debug("Placa----> "  +codNodo);
						comprobante.setPlacaVehiculo(codNodo);
						
						codNodo=(String)xpath.evaluate("sac:SUNATRoadTransport/cbc:BrandName",  nodeProperties.item(0), XPathConstants.STRING);
						log.debug("Marca ----> "  +codNodo);
						comprobante.setMarcaVehiculo(codNodo);

	
					}

			
					nodeProperties = (NodeList)xpath.evaluate("sac:AdditionalInformation/sac:SUNATCosts",  nodeItem, XPathConstants.NODESET);
					if(nodeProperties.getLength() > 0) {
						codNodo=(String)xpath.evaluate("cac:RoadTransport/cbc:LicensePlateID",  nodeProperties.item(0), XPathConstants.STRING);
						log.debug("Placa Venta Combustible----> "  +codNodo);
						comprobante.setPlacaPorVentaCombustible(codNodo);
						
					}	
					
				}
			}
			
			nodeExtensiones = (NodeList)xpath.evaluate(nm + "/ext:UBLExtensions/ext:UBLExtension/ext:ExtensionContent",  doc, XPathConstants.NODESET);

			if(nodeExtensiones.getLength() > 0) {
				nodeItem = null;
				for(int i = 0; i < nodeExtensiones.getLength(); i++) {
					nodeItem = (Node)nodeExtensiones.item(i);
					String codNodo="";
					NodeList nodeProperties = (NodeList)xpath.evaluate("sac:AdditionalInformation/sac:AdditionalMonetaryTotal",  nodeItem, XPathConstants.NODESET);
					if(nodeProperties.getLength() > 0) {
						for(int j = 0; j < nodeProperties.getLength(); j++) {	

							codNodo=(String)xpath.evaluate("cbc:ID", nodeProperties.item(j), XPathConstants.STRING);

							if (codNodo != null){
								if (codNodo.equals("1004")){
									comprobante.setTotalValorVentaOperaGratuitas(ComprobanteUtilBean.toBigDecimal((String)xpath.evaluate("cbc:PayableAmount", nodeProperties.item(j), XPathConstants.STRING)));
								}
								if (codNodo.equals("1005")){
									comprobante.setTotalSubTotalValorVenta(ComprobanteUtilBean.toBigDecimal((String)xpath.evaluate("cbc:PayableAmount", nodeProperties.item(j), XPathConstants.STRING)));	
								}
								//if (codNodo.equals("2005")){
								//	comprobante.setTotalDescuentos(ComprobanteUtilBean.toBigDecimal((String)xpath.evaluate("cbc:PayableAmount", nodeProperties.item(j), XPathConstants.STRING)));	
								//}
							}
						}
					}
				}

			}			
			/////////
//			comprobante.setMontoTotalTexto((String)xpath.evaluate(nm + "/cbc:Note", doc, XPathConstants.STRING));
			log.debug("Buscamos documentos relacionados");
			/**------ Obtenemos los documentos relacionados -----*/
			NodeList nlGuias = (NodeList)xpath.evaluate(nm + "/cac:DespatchDocumentReference",  doc, XPathConstants.NODESET);
			NodeList nlOtrosDocs = (NodeList)xpath.evaluate(nm + "/cac:AdditionalDocumentReference",  doc, XPathConstants.NODESET);
			if(nlGuias.getLength() > 0 || nlOtrosDocs.getLength() > 0) {
				int lengthArray = nlGuias.getLength() + nlOtrosDocs.getLength();
				List <OtroDocumentoRelacionadoBean> aOtrosDocs = new ArrayList<OtroDocumentoRelacionadoBean>();
				OtroDocumentoRelacionadoBean docRel = null;
				
				for(int j = 0, x = 0, y = 0; j < lengthArray; j++) {
					nodeItem = (j < nlGuias.getLength() ? (Node)nlGuias.item(x++) : (Node)nlOtrosDocs.item(y++));
					docRel = new OtroDocumentoRelacionadoBean();
					docRel.setTipoComprobante(comprobante.getTipoComprobante());
					docRel.setNumeroComprobante(comprobante.getNumeroComprobante());
					docRel.setSerieComprobante(comprobante.getSerieComprobante());
					docRel.setTipoDocumentoRelacionado((String)xpath.evaluate("cbc:cbc:DocumentTypeCode", nodeItem, XPathConstants.STRING));
					docRel.setDesTipoDocuRela((String)xpath.evaluate("cbc:DocumentType", nodeItem, XPathConstants.STRING));
					docRel.setNumeroDocumentoRelacionadoInicial((String)xpath.evaluate("cbc:ID", nodeItem, XPathConstants.STRING));
					aOtrosDocs.add(docRel);
				}
				comprobante.setOtroDocumentoRelacionadoBean(aOtrosDocs);
			}
			

			/**--------------------------------------------------*/
			log.debug("Buscamos datos generales");
//			comprobante.setRazonSocial((String)xpath.evaluate(nm + "/cac:AccountingSupplierParty/cac:Party/cac:PartyName/cbc:Name", doc, XPathConstants.STRING));
			comprobante.setRazonComercial((String)xpath.evaluate(nm + "/cac:AccountingSupplierParty/cac:Party/cac:PartyName/cbc:Name", doc, XPathConstants.STRING));
			comprobante.setRazonSocial((String)xpath.evaluate(nm + "/cac:AccountingSupplierParty/cac:Party/cac:PartyLegalEntity/cbc:RegistrationName", doc, XPathConstants.STRING));

			comprobante.setUbigeoEmisor((String)xpath.evaluate(nm + "/cac:AccountingSupplierParty/cac:Party/cac:PostalAddress/cbc:ID", doc, XPathConstants.STRING));
			comprobante.setNombreCalle((String)xpath.evaluate(nm + "/cac:AccountingSupplierParty/cac:Party/cac:PostalAddress/cbc:StreetName", doc, XPathConstants.STRING));
			comprobante.setNumeroDireccion((String)xpath.evaluate(nm + "/cac:AccountingSupplierParty/cac:Party/cac:PostalAddress/cbc:BuildingNumber", doc, XPathConstants.STRING));
			comprobante.setNombreDistrito((String)xpath.evaluate(nm + "/cac:AccountingSupplierParty/cac:Party/cac:PostalAddress/cbc:District", doc, XPathConstants.STRING));
			comprobante.setNombreProvincia((String)xpath.evaluate(nm + "/cac:AccountingSupplierParty/cac:Party/cac:PostalAddress/cbc:CityName", doc, XPathConstants.STRING));
			comprobante.setNombreDepartamento((String)xpath.evaluate(nm + "/cac:AccountingSupplierParty/cac:Party/cac:PostalAddress/cbc:CountrySubentity", doc, XPathConstants.STRING));
			comprobante.setCodigoPais((String)xpath.evaluate(nm + "/cac:AccountingSupplierParty/cac:Party/cac:PostalAddress/cac:Country/cbc:IdentificationCode", doc, XPathConstants.STRING));
			comprobante.setCodigoEstablecimiento(Short.valueOf((String)xpath.evaluate(nm + "/cac:AccountingSupplierParty/cac:Party/cac:PhysicalLocation/cbc:ID", doc, XPathConstants.STRING)));
			
			comprobante.setIndicadorEstabEmisor("0");
			if (((NodeList)xpath.evaluate(nm + "/cac:SellerSupplierParty/cac:Party/cac:PostalAddress", doc, XPathConstants.NODESET)).getLength() > 0){
				log.debug("Establecimiento del emisor");
				comprobante.setIndicadorEstabEmisor("1");
				comprobante.setEstabEmisor(new DireccionComprobanteBean());
				comprobante.getEstabEmisor().setCod_ubigeo((String)xpath.evaluate(nm + "/cac:SellerSupplierParty/cac:Party/cac:PostalAddress/cbc:ID", doc, XPathConstants.STRING));
				comprobante.getEstabEmisor().setDireccion((String)xpath.evaluate(nm + "/cac:SellerSupplierParty/cac:Party/cac:PostalAddress/cbc:StreetName", doc, XPathConstants.STRING));				
				comprobante.getEstabEmisor().setTip_zona_desc((String)xpath.evaluate(nm + "/cac:SellerSupplierParty/cac:Party/cac:PostalAddress/cbc:CitySubdivisionName", doc, XPathConstants.STRING));
				comprobante.getEstabEmisor().setDes_prov((String)xpath.evaluate(nm + "/cac:SellerSupplierParty/cac:Party/cac:PostalAddress/cbc:CityName", doc, XPathConstants.STRING));
				comprobante.getEstabEmisor().setDes_dpto((String)xpath.evaluate(nm + "/cac:SellerSupplierParty/cac:Party/cac:PostalAddress/cbc:CountrySubentity", doc, XPathConstants.STRING));
				comprobante.getEstabEmisor().setDes_dist((String)xpath.evaluate(nm + "/cac:SellerSupplierParty/cac:Party/cac:PostalAddress/cbc:District", doc, XPathConstants.STRING));				
			}

			comprobante.setNumeroDocumentoCliente((String)xpath.evaluate(nm + "/cac:AccountingCustomerParty/cbc:CustomerAssignedAccountID", doc, XPathConstants.STRING));
			comprobante.setTipoDocumentoCliente((String)xpath.evaluate(nm + "/cac:AccountingCustomerParty/cbc:AdditionalAccountID", doc, XPathConstants.STRING));
	
			comprobante.setDesTipoDocumentoCliente( obtenerDescCatalogo06(comprobante.getTipoDocumentoCliente().trim()));
			comprobante.setNombreCliente((String)xpath.evaluate(nm + "/cac:AccountingCustomerParty/cac:Party/cac:PartyLegalEntity/cbc:RegistrationName", doc, XPathConstants.STRING));
			
			comprobante.setIndicadorDomicilioCliente("0");
			if (((NodeList)xpath.evaluate(nm + "/cac:AccountingCustomerParty/cac:Party/cac:PostalAddress", doc, XPathConstants.NODESET)).getLength() > 0){
				log.debug("Establecimiento del cliente");
				comprobante.setIndicadorDomicilioCliente("1");
				comprobante.setDomicilioCliente(new DireccionComprobanteBean());
				comprobante.getDomicilioCliente().setCod_ubigeo((String)xpath.evaluate(nm + "/cac:AccountingCustomerParty/cac:Party/cac:PostalAddress/cbc:ID", doc, XPathConstants.STRING));
				comprobante.getDomicilioCliente().setDireccion((String)xpath.evaluate(nm + "/cac:AccountingCustomerParty/cac:Party/cac:PostalAddress/cbc:StreetName", doc, XPathConstants.STRING));				
				comprobante.getDomicilioCliente().setTip_zona_desc((String)xpath.evaluate(nm + "/cac:AccountingCustomerParty/cac:Party/cac:PostalAddress/cbc:CitySubdivisionName", doc, XPathConstants.STRING));
				comprobante.getDomicilioCliente().setDes_prov((String)xpath.evaluate(nm + "/cac:AccountingCustomerParty/cac:Party/cac:PostalAddress/cbc:CityName", doc, XPathConstants.STRING));
				comprobante.getDomicilioCliente().setDes_dpto((String)xpath.evaluate(nm + "/cac:AccountingCustomerParty/cac:Party/cac:PostalAddress/cbc:CountrySubentity", doc, XPathConstants.STRING));
				comprobante.getDomicilioCliente().setDes_dist((String)xpath.evaluate(nm + "/cac:AccountingCustomerParty/cac:Party/cac:PostalAddress/cbc:District", doc, XPathConstants.STRING));				
			}
			
			log.debug("Buscamos montos totales");
			comprobante.setMontoSubTotal(ComprobanteUtil.toBigDecimal((String)xpath.evaluate(nm + "/cac:LegalMonetaryTotal/cbc:LineExtensionAmount", doc, XPathConstants.STRING)));
			
			comprobante.setTotalValorVenta(ComprobanteUtilBean.toBigDecimal((String)xpath.evaluate(nm + "/cac:LegalMonetaryTotal/cbc:LineExtensionAmount", doc, XPathConstants.STRING)));
			if (!xpath.evaluate(nm + "/cac:LegalMonetaryTotal/cbc:AllowanceTotalAmount", doc, XPathConstants.STRING).equals("")){
				comprobante.setTotalDescuentos(ComprobanteUtilBean.toBigDecimal((String)xpath.evaluate(nm + "/cac:LegalMonetaryTotal/cbc:AllowanceTotalAmount", doc, XPathConstants.STRING)));
			}
			//comprobante.setTotalSubTotalValorVenta(comprobante.getTotalValorVenta().add(comprobante.getTotalDescuentos()));		//OJO - retirar porque debe grabarse el valor
			
			comprobante.setMontoTotalGeneral(ComprobanteUtilBean.toBigDecimal((String)xpath.evaluate(nm + "/cac:LegalMonetaryTotal/cbc:PayableAmount", doc, XPathConstants.STRING)));
			if (xpath.evaluate(nm + "/cac:LegalMonetaryTotal/cbc:PrepaidAmount", doc, XPathConstants.STRING) ==null || xpath.evaluate(nm + "/cac:LegalMonetaryTotal/cbc:PrepaidAmount", doc, XPathConstants.STRING).equals("") ){
				 comprobante.setTotalAnticipos(new BigDecimal(0));
			}else{
				 if(((String)xpath.evaluate(nm + "/cac:LegalMonetaryTotal/cbc:PrepaidAmount", doc, XPathConstants.STRING)).equals("$util.formatTwoDecimal($cp.getTotalAnticipos())")){
					 comprobante.setTotalAnticipos(new BigDecimal(0));
				 }else{
					 comprobante.setTotalAnticipos(ComprobanteUtilBean.toBigDecimal((String)xpath.evaluate(nm + "/cac:LegalMonetaryTotal/cbc:PrepaidAmount", doc, XPathConstants.STRING)));
				 }
			}
			comprobante.setTotalOtrosTributos(new BigDecimal(0));
			comprobante.setTotalOtrosCargos(new BigDecimal(0));
			if ( !xpath.evaluate(nm + "/cac:LegalMonetaryTotal/cbc:ChargeTotalAmount", doc, XPathConstants.STRING).equals("") ){
				comprobante.setTotalOtrosCargos(ComprobanteUtilBean.toBigDecimal((String)xpath.evaluate(nm + "/cac:LegalMonetaryTotal/cbc:ChargeTotalAmount", doc, XPathConstants.STRING)));
			}
			if ( !xpath.evaluate(nm + "/cbc:DocumentCurrencyCode", doc, XPathConstants.STRING).equals("") ){
				comprobante.setCodigoMoneda((String)xpath.evaluate(nm + "/cbc:DocumentCurrencyCode", doc, XPathConstants.STRING));
			}else{
				comprobante.setCodigoMoneda((String)xpath.evaluate(nm + "/cac:LegalMonetaryTotal/cbc:PayableAmount/@currencyID", doc, XPathConstants.STRING));
			}
			
			NodeList totalesOtros = (NodeList)xpath.evaluate(nm + "/cac:TaxTotal/cac:TaxSubtotal",  doc, XPathConstants.NODESET);			
			if(totalesOtros.getLength() > 0) {
				for(int i=0 ;i<totalesOtros.getLength(); i++){
					nodeItem = (Node)totalesOtros.item(i);
					identifier = xpath.evaluate("cac:TaxCategory/cac:TaxScheme/cbc:ID", nodeItem, XPathConstants.STRING).toString() ;
					if("1000".equals(identifier)){
						comprobante.setTotalIGV(ComprobanteUtilBean.toBigDecimal(xpath.evaluate("cbc:TaxAmount", nodeItem, XPathConstants.STRING).toString()));
					}else if("2000".equals(identifier)){ 
						comprobante.setTotalISC(ComprobanteUtilBean.toBigDecimal(xpath.evaluate("cbc:TaxAmount", nodeItem, XPathConstants.STRING).toString()));
					}else if("9999".equals(identifier)){
						comprobante.setTotalOtrosTributos(ComprobanteUtilBean.toBigDecimal(xpath.evaluate("cbc:TaxAmount", nodeItem, XPathConstants.STRING).toString()));
					}
				}				
			}
	
			comprobante.setMontoImpuestos(comprobante.getTotalISC().add(comprobante.getTotalIGV()).add(comprobante.getTotalOtrosTributos()));

			log.debug("Buscamos los detalles");
			NodeList nlItems = (NodeList)xpath.evaluate(nm + "/cac:InvoiceLine",  doc, XPathConstants.NODESET);
			if(nlItems.getLength() > 0) {
				List <DetalleComprobanteBean> aDetalleComprobante = new ArrayList<DetalleComprobanteBean>();
				DetalleComprobanteBean detalle = null;
				for(int i = 0; i < nlItems.getLength(); i++) {
					nodeItem = (Node)nlItems.item(i);
					 detalle = new DetalleComprobanteBean();
//					 if (i == 0) {
//						comprobante.setObservacion((String)xpath.evaluate("cbc:Note", nodeItem, XPathConstants.STRING));						 
//					 }
					 detalle.setIdentificador(Integer.parseInt((String)xpath.evaluate("cbc:ID", nodeItem, XPathConstants.STRING)));
					 detalle.setIdentificadorOriginal(Integer.parseInt((String)xpath.evaluate("cbc:ID", nodeItem, XPathConstants.STRING)));
//					 detalle.setNumeroLinea(Integer.parseInt((String)xpath.evaluate("cac:OrderLineReference/cbc:LineID", nodeItem, XPathConstants.STRING)));
					 detalle.setUnidadMedida((String)xpath.evaluate("cbc:InvoicedQuantity/@unitCode", nodeItem, XPathConstants.STRING));
					 detalle.setCodigoItem((String)xpath.evaluate("cac:Item/cac:SellersItemIdentification/cbc:ID", nodeItem, XPathConstants.STRING));
					 String operacionGratuita = (String)xpath.evaluate("cbc:FreeOfChargeIndicator", nodeItem, XPathConstants.STRING);
					 if (operacionGratuita.equals("true")){
						 detalle.setTipoBonificacion("BO01"); //Es operaci�n gratuita
					 }else{
						 detalle.setTipoBonificacion("BO00");
					 }
					 if (detalle.getCodigoItem() == null) { detalle.setCodigoItem("");}
					 if (((String)xpath.evaluate("cbc:InvoicedQuantity", nodeItem, XPathConstants.STRING)).equals("$util.formatTenDecimal($dc.getCantidad())")){
						 detalle.setCantidad("1.00");
					 }else{
						 detalle.setCantidad((String)xpath.evaluate("cbc:InvoicedQuantity", nodeItem, XPathConstants.STRING));
					 }
					 detalle.setDescripcion((String)xpath.evaluate("cac:Item/cbc:Description", nodeItem, XPathConstants.STRING));
					 //if(detalle.getDescripcion().contains("\""))
					 //	 detalle.setDescripcion(detalle.getDescripcion().replaceAll("\"", "''"));
					 detalle.setPrecioUnitario((String)xpath.evaluate("cac:PricingReference/cac:AlternativeConditionPrice/cbc:PriceAmount", nodeItem, XPathConstants.STRING));
					BigDecimal cantidad = new BigDecimal(0);
					if (detalle.getCantidad() == null || detalle.getCantidad().equals("") || detalle.getCantidad().equals("0")){
						cantidad = new BigDecimal(1);
					}else{
						cantidad= new BigDecimal(detalle.getCantidad() );
					}
					 detalle.setValorVenta(ComprobanteUtilBean.formatTwoDecimal(new BigDecimal(detalle.getPrecioUnitario()).multiply(cantidad)));
					 detalle.setMontoBruto(ComprobanteUtilBean.formatTwoDecimal((String)xpath.evaluate("cbc:LineExtensionAmount", nodeItem, XPathConstants.STRING)));
					 detalle.setImporteVenta(ComprobanteUtilBean.formatTwoDecimal((String)xpath.evaluate("cbc:LineExtensionAmount", nodeItem, XPathConstants.STRING)));
					Object oTotalImpuesto = (String)xpath.evaluate("cac:TaxTotal/cbc:TaxAmount", nodeItem, XPathConstants.STRING);
					detalle.setTotalImpuestos(ComprobanteUtilBean.isNumber(oTotalImpuesto) ? ComprobanteUtilBean.formatTwoDecimal((String)oTotalImpuesto) : "0");
					//String oDescuento = (String)xpath.evaluate("cac:AllowanceCharge/cbc:Amount", nodeItem, XPathConstants.STRING);
					detalle.setDescuentoMonto((String)xpath.evaluate("cac:AllowanceCharge/cbc:Amount", nodeItem, XPathConstants.STRING));
//					detalle.setValorVtaUnitario(ComprobanteUtilBean.formatTwoDecimal((new BigDecimal(detalle.getValorVenta())).subtract(new BigDecimal(detalle.getDescuentoMonto()))));
					if (((String)xpath.evaluate("cac:Price/cbc:PriceAmount", nodeItem, XPathConstants.STRING)).equals("$util.formatTenDecimal($dc.getPrecioUnitario())")){
						detalle.setValorVtaUnitario(detalle.getImporteVenta());
					}else{
						detalle.setValorVtaUnitario((String)xpath.evaluate("cac:Price/cbc:PriceAmount", nodeItem, XPathConstants.STRING));
					}
					detalle.setDescuentoMontoOriginal(detalle.getDescuentoMonto());
					detalle.setIgvMonto("0");
					detalle.setIscMonto("0");
					detalle.setOtroMonto("0");
					detalle.setTipoBeneficio("TB00"); 
					detalle.setOtrosTributos("0.00");
					detalle.setOtrosTributosOriginal("0.00");
					detalle.setOtrosCargosTributos("0.00");
			
					detalle.setTipoOtrosCargosTributos("");
					detalle.setTipoItem("TI01");  //Quitar cuando se pueda diferencias si el item es bien o servicio
					NodeList nodeTaxSubTotals = (NodeList)xpath.evaluate("cac:TaxTotal/cac:TaxSubtotal",  nodeItem, XPathConstants.NODESET);
					
					//BigDecimal otrosCargosTributos = new BigDecimal(0);
					for(int j = 0; j < nodeTaxSubTotals.getLength(); j++) {
						Node nodeTaxSubTotal = (Node)nodeTaxSubTotals.item(j);
						String tributo = (String)xpath.evaluate("cac:TaxCategory/cac:TaxScheme/cbc:ID", nodeTaxSubTotal, XPathConstants.STRING);
//						if(tributo.equals(ComprobanteUtilBean.IGV)) {
						if("1000".equals(tributo)) {
							detalle.setIgvPorcentaje(ComprobanteUtilBean.formatTwoDecimal(String.valueOf(xpath.evaluate("cbc:Percent", nodeTaxSubTotal, XPathConstants.STRING))));
							detalle.setIgvMonto(ComprobanteUtilBean.formatTwoDecimal((String)xpath.evaluate("cbc:TaxAmount", nodeTaxSubTotal, XPathConstants.STRING)));
//							detalle.setIgvPorcentaje(ComprobanteUtilBean.formatTwoDecimal((String)xpath.evaluate("cbc:Percent", nodeTaxSubTotal, XPathConstants.STRING)));
							String afectacion = (String)xpath.evaluate("cac:TaxCategory/cbc:TaxExemptionReasonCode", nodeTaxSubTotal, XPathConstants.STRING);
							if (afectacion.equals("10")){ 
								detalle.setTipoBeneficio("TB00"); //Gravado
								comprobante.setIgvPorcentaje(ComprobanteUtilBean.toBigDecimal(String.valueOf(xpath.evaluate("cbc:Percent", nodeTaxSubTotal, XPathConstants.STRING))).multiply(new BigDecimal("100.00")));
							}
							if (afectacion.equals("20")){ 
								detalle.setTipoBeneficio("TB01"); //Exonerado
							}		
							if (afectacion.equals("30")){ 
								detalle.setTipoBeneficio("TB02"); //Inafecto
							}							
//						}else if(tributo.equals(ComprobanteUtilBean.ISC)) {
						}else if("2000".equals(tributo)) {
							detalle.setIscMonto(ComprobanteUtilBean.formatTwoDecimal((String)xpath.evaluate("cbc:TaxAmount", nodeTaxSubTotal, XPathConstants.STRING)));
							detalle.setIscMontoOriginal(ComprobanteUtilBean.formatTwoDecimal((String)xpath.evaluate("cbc:TaxAmount", nodeTaxSubTotal, XPathConstants.STRING)));
							detalle.setIscPorcentaje(ComprobanteUtilBean.formatTwoDecimal((String)xpath.evaluate("cbc:Percent", nodeTaxSubTotal, XPathConstants.STRING)));
						}

					}
					
					
					aDetalleComprobante.add(detalle);
				}
				comprobante.setDetalleComprobanteBean(aDetalleComprobante);
			}
			
			
		} catch(ServiceException e) {
			log.error(e,e);
			throw e;
		} catch(Exception e) {
			log.error(e,e);
			throw new ServiceException(this, e.getLocalizedMessage());
		}
		return comprobante;
	}
	
	/**
	 * Genera el ComprobanteBean a partir de la version 1.1 de la estructura del documento XMl. 
	 * @param doc
	 * @param xpath
	 * @return
	 */
	private ComprobanteBean generaComprobantePortalV1(Document doc, XPath xpath){
		ComprobanteBean comprobante = new ComprobanteBean();
		
		try {
			if(log.isDebugEnabled()) log.debug("generaComprobantePortalV1") ; 
			
			log.debug("Document : " + doc.getNodeName());
			log.debug("XPath    : " + xpath);
			String nm = this.getMainNodeValue();
			String id = (String)xpath.evaluate(nm + "/cbc:ID", doc, XPathConstants.STRING);
			
			/** -- Obtenemos el tipo y subtipo de comprobante --*/
			Object oTipoComprobante = xpath.evaluate(nm + "/cbc:InvoiceTypeCode", doc, XPathConstants.STRING);
			if(ComprobanteUtilBean.isStringValid(oTipoComprobante)) {
				String tipoComprobante = ((String)oTipoComprobante).trim();
				if(tipoComprobante.length() < 4) {
					throw new ServiceException(this, "El tipo de comprobante debe tener 4 digitos");
				}
				else {
					comprobante.setTipoComprobante(tipoComprobante.substring(0, 2));
					comprobante.setSubTipoComprobante(tipoComprobante.substring(2, 4));
					comprobante.setIndicadorExportacion("0");
					if (comprobante.getTipoComprobante().equals("01")){
						if (comprobante.getSubTipoComprobante().equals("02")){
							comprobante.setIndicadorExportacion("1");
						}
						if (comprobante.getSubTipoComprobante().equals("03")){
							comprobante.setIndicadorVentaNodomic("1");
						}						
					}
				}				
			}
			else {
				throw new ServiceException(this, "El XML no contiene el tipo de comprobante");
			}
			/**--------------------------------------------------*/
			comprobante.setVersionXML(1.0);
			comprobante.setNumeroComprobante(new Integer(id.substring(id.indexOf("-") + 1)));
			comprobante.setSerieComprobante(id.substring(0, id.indexOf("-")));
			comprobante.setNumeroRuc((String)xpath.evaluate(nm + "/cac:AccountingSupplierParty/cbc:CustomerAssignedAccountID", doc, XPathConstants.STRING));
			FechaBean fb = new FechaBean((String)xpath.evaluate(nm + "/cbc:IssueDate", doc, XPathConstants.STRING), "yyyy-MM-dd");
			comprobante.setFechaEmision(fb.getFormatDate("dd/MM/yyyy"));
			comprobante.setFechaEmisionOriginal(fb.getFormatDate("dd/MM/yyyy"));
			
			fb.setFecha((String)xpath.evaluate(nm + "/cbc:IssueTime", doc, XPathConstants.STRING), "HH:mm:ss");
			comprobante.setHoraEmision(fb.getFormatDate("HH:mm:ss"));
//			comprobante.setObservacion((String)xpath.evaluate(nm + "/cbc:Note", doc, XPathConstants.STRING));
			comprobante.setTotalValorVentaOperaGratuitas(ComprobanteUtilBean.toBigDecimal("0"));
			comprobante.setTotalSubTotalValorVenta(ComprobanteUtilBean.toBigDecimal("0"));	
			comprobante.setIndicadorVentaNodomic("0");
			comprobante.setDescripcionVentaGratuita("");
			NodeList nodeExtensiones = (NodeList)xpath.evaluate(nm + "/ext:UBLExtensions/ext:UBLExtension/ext:ExtensionContent",  doc, XPathConstants.NODESET);
			comprobante.setIndicadorEstabEmisor("0");
			comprobante.setIndicadorDomicilioCliente("0");
			if(nodeExtensiones.getLength() > 0) {
				Node nodeItem = null;
				for(int i = 0; i < nodeExtensiones.getLength(); i++) {
					nodeItem = (Node)nodeExtensiones.item(i);
					String codNodo="";
					NodeList nodeProperties = (NodeList)xpath.evaluate("sac:AdditionalInformationInvoice/sac:AdditionalInvoiceProperty",  nodeItem, XPathConstants.NODESET);
					if(nodeProperties.getLength() > 0) {

						for(int j = 0; j < nodeProperties.getLength(); j++) {					
							codNodo=(String)xpath.evaluate("cbc:ID", nodeProperties.item(j), XPathConstants.STRING);
							log.debug("codNodo ----> "  +codNodo);
							if (codNodo != null){
								if (codNodo.equals("1000")){
									comprobante.setMontoTotalTexto((String)xpath.evaluate("cbc:Value", nodeProperties.item(j), XPathConstants.STRING));
								}
								if (codNodo.equals("1002")){
									comprobante.setGlosa((String)xpath.evaluate("cbc:Value", nodeProperties.item(j), XPathConstants.STRING));
									comprobante.setDescripcionVentaGratuita((String)xpath.evaluate("cbc:Value", nodeProperties.item(j), XPathConstants.STRING));
								}
								if (codNodo.equals("1003")){
									comprobante.setDescripcionVentaNoDomic((String)xpath.evaluate("cbc:Value", nodeProperties.item(j), XPathConstants.STRING));
									if (!comprobante.getDescripcionVentaNoDomic().equals("")){
										comprobante.setIndicadorVentaNodomic("1");
									}else{
										comprobante.setIndicadorVentaNodomic("0");
									}
								}
							}
						}
					}

				}

			}
			
			nodeExtensiones = (NodeList)xpath.evaluate(nm + "/ext:UBLExtensions/ext:UBLExtension/ext:ExtensionContent",  doc, XPathConstants.NODESET);

			if(nodeExtensiones.getLength() > 0) {
				Node nodeItem = null;
				for(int i = 0; i < nodeExtensiones.getLength(); i++) {
					nodeItem = (Node)nodeExtensiones.item(i);
					String codNodo="";
					NodeList nodeProperties = (NodeList)xpath.evaluate("sac:AdditionalInformation/sac:AdditionalMonetaryTotal",  nodeItem, XPathConstants.NODESET);
					if(nodeProperties.getLength() > 0) {
						for(int j = 0; j < nodeProperties.getLength(); j++) {	

							codNodo=(String)xpath.evaluate("cbc:ID", nodeProperties.item(j), XPathConstants.STRING);

							if (codNodo != null){
								if (codNodo.equals("1004")){
									comprobante.setTotalValorVentaOperaGratuitas(ComprobanteUtilBean.toBigDecimal((String)xpath.evaluate("cbc:PayableAmount", nodeProperties.item(j), XPathConstants.STRING)));
								}
								if (codNodo.equals("1005")){
									comprobante.setTotalSubTotalValorVenta(ComprobanteUtilBean.toBigDecimal((String)xpath.evaluate("cbc:PayableAmount", nodeProperties.item(j), XPathConstants.STRING)));	
								}
							}
						}
					}
				}

			}			
			/////////
			comprobante.setMontoTotalTexto((String)xpath.evaluate(nm + "/cbc:Note", doc, XPathConstants.STRING));
			log.debug("Buscamos documentos relacionados");
			/**------ Obtenemos los documentos relacionados -----*/
			NodeList nlGuias = (NodeList)xpath.evaluate(nm + "/cac:DespatchDocumentReference",  doc, XPathConstants.NODESET);
			NodeList nlOtrosDocs = (NodeList)xpath.evaluate(nm + "/cac:AdditionalDocumentReference",  doc, XPathConstants.NODESET);
			if(nlGuias.getLength() > 0 || nlOtrosDocs.getLength() > 0) {
				int lengthArray = nlGuias.getLength() + nlOtrosDocs.getLength();
				List <OtroDocumentoRelacionadoBean> aOtrosDocs = new ArrayList<OtroDocumentoRelacionadoBean>();
				OtroDocumentoRelacionadoBean docRel = null;
				
				for(int j = 0, x = 0, y = 0; j < lengthArray; j++) {
					Node nodeItem = (j < nlGuias.getLength() ? (Node)nlGuias.item(x++) : (Node)nlOtrosDocs.item(y++));
					docRel = new OtroDocumentoRelacionadoBean();
					docRel.setTipoDocumentoRelacionado((String)xpath.evaluate("cbc:cbc:DocumentTypeCode", nodeItem, XPathConstants.STRING));
					docRel.setDesTipoDocuRela((String)xpath.evaluate("cbc:DocumentType", nodeItem, XPathConstants.STRING));
					docRel.setNumeroDocumentoRelacionadoInicial((String)xpath.evaluate("cbc:ID", nodeItem, XPathConstants.STRING));
					aOtrosDocs.add(docRel);
				}
				comprobante.setOtroDocumentoRelacionadoBean(aOtrosDocs);
			}
			

			/**--------------------------------------------------*/
			log.debug("Buscamos datos generales");
//			comprobante.setRazonSocial((String)xpath.evaluate(nm + "/cac:AccountingSupplierParty/cac:Party/cac:PartyName/cbc:Name", doc, XPathConstants.STRING));
			comprobante.setRazonComercial((String)xpath.evaluate(nm + "/cac:AccountingSupplierParty/cac:Party/cac:PartyName/cbc:Name", doc, XPathConstants.STRING));
			comprobante.setRazonSocial((String)xpath.evaluate(nm + "/cac:AccountingSupplierParty/cac:Party/cac:PartyLegalEntity/cbc:RegistrationName", doc, XPathConstants.STRING));

			comprobante.setUbigeoEmisor((String)xpath.evaluate(nm + "/cac:AccountingSupplierParty/cac:Party/cac:PostalAddress/cbc:ID", doc, XPathConstants.STRING));
			comprobante.setNombreCalle((String)xpath.evaluate(nm + "/cac:AccountingSupplierParty/cac:Party/cac:PostalAddress/cbc:StreetName", doc, XPathConstants.STRING));
			comprobante.setNumeroDireccion((String)xpath.evaluate(nm + "/cac:AccountingSupplierParty/cac:Party/cac:PostalAddress/cbc:BuildingNumber", doc, XPathConstants.STRING));
			comprobante.setNombreDistrito((String)xpath.evaluate(nm + "/cac:AccountingSupplierParty/cac:Party/cac:PostalAddress/cbc:District", doc, XPathConstants.STRING));
			comprobante.setNombreProvincia((String)xpath.evaluate(nm + "/cac:AccountingSupplierParty/cac:Party/cac:PostalAddress/cbc:CityName", doc, XPathConstants.STRING));
			comprobante.setNombreDepartamento((String)xpath.evaluate(nm + "/cac:AccountingSupplierParty/cac:Party/cac:PostalAddress/cbc:CountrySubentity", doc, XPathConstants.STRING));
			comprobante.setCodigoPais((String)xpath.evaluate(nm + "/cac:AccountingSupplierParty/cac:Party/cac:PostalAddress/cac:Country/cbc:IdentificationCode", doc, XPathConstants.STRING));
			comprobante.setCodigoEstablecimiento(Short.valueOf((String)xpath.evaluate(nm + "/cac:AccountingSupplierParty/cac:Party/cac:PhysicalLocation/cbc:ID", doc, XPathConstants.STRING)));

			comprobante.setNumeroDocumentoCliente((String)xpath.evaluate(nm + "/cac:AccountingCustomerParty/cbc:CustomerAssignedAccountID", doc, XPathConstants.STRING));
			comprobante.setTipoDocumentoCliente((String)xpath.evaluate(nm + "/cac:AccountingCustomerParty/cbc:AdditionalAccountID", doc, XPathConstants.STRING));
			String  descdoc ="-";
			if ("06".equals(comprobante.getTipoDocumentoCliente())) descdoc= "RUC"; 
			else if ("01".equals(comprobante.getTipoDocumentoCliente())) descdoc= "DNI"; 
			else if ("04".equals(comprobante.getTipoDocumentoCliente())) descdoc= "CARNET EXTRANJERIA"; 
			else if ("07".equals(comprobante.getTipoDocumentoCliente())) descdoc= "PASAPORTE"; 
			comprobante.setDesTipoDocumentoCliente(descdoc);			
			comprobante.setNombreCliente((String)xpath.evaluate(nm + "/cac:AccountingCustomerParty/cac:Party/cac:PartyName/cbc:Name", doc, XPathConstants.STRING));
			
			log.debug("Buscamos montos totales");

				comprobante.setMontoSubTotal(ComprobanteUtil.toBigDecimal((String)xpath.evaluate(nm + "/cac:LegalMonetaryTotal/cbc:LineExtensionAmount", doc, XPathConstants.STRING)));
			
			comprobante.setTotalValorVenta(ComprobanteUtilBean.toBigDecimal((String)xpath.evaluate(nm + "/cac:LegalMonetaryTotal/cbc:LineExtensionAmount", doc, XPathConstants.STRING)));
			if (! xpath.evaluate(nm + "/cac:LegalMonetaryTotal/cbc:AllowanceTotalAmount", doc, XPathConstants.STRING).equals("") ){
				comprobante.setTotalDescuentos(ComprobanteUtilBean.toBigDecimal((String)xpath.evaluate(nm + "/cac:LegalMonetaryTotal/cbc:AllowanceTotalAmount", doc, XPathConstants.STRING)));
			}
			//comprobante.setTotalSubTotalValorVenta(comprobante.getTotalValorVenta().add(comprobante.getTotalDescuentos()));		//OJO - retirar porque debe grabarse el valor
			
			comprobante.setMontoTotalGeneral(ComprobanteUtilBean.toBigDecimal((String)xpath.evaluate(nm + "/cac:LegalMonetaryTotal/cbc:PayableAmount", doc, XPathConstants.STRING)));		
			comprobante.setTotalOtrosTributos(new BigDecimal(0));
			comprobante.setTotalOtrosCargos(new BigDecimal(0));
			if ( !xpath.evaluate(nm + "/cac:LegalMonetaryTotal/cbc:ChargeTotalAmount", doc, XPathConstants.STRING).equals("") ){
				comprobante.setTotalOtrosCargos(ComprobanteUtilBean.toBigDecimal((String)xpath.evaluate(nm + "/cac:LegalMonetaryTotal/cbc:ChargeTotalAmount", doc, XPathConstants.STRING)));
			}
			if ( !xpath.evaluate(nm + "/cbc:DocumentCurrencyCode", doc, XPathConstants.STRING).equals("") ){
				comprobante.setCodigoMoneda((String)xpath.evaluate(nm + "/cbc:DocumentCurrencyCode", doc, XPathConstants.STRING));
			}else{
				comprobante.setCodigoMoneda((String)xpath.evaluate(nm + "/cac:LegalMonetaryTotal/cbc:PayableAmount/@currencyID", doc, XPathConstants.STRING));
			}
			
			

			NodeList nodeOtrosTot = (NodeList)xpath.evaluate(nm + "/cac:TaxTotal/cac:TaxSubtotal",  doc, XPathConstants.NODESET);
			if(nodeOtrosTot.getLength() > 0) {
				String nombre = "";
				String monto = "";
				String porcentaje="";
				Node nodeItem = null;
				for(int i = 0; i < nodeOtrosTot.getLength(); i++) {
					nodeItem = (Node)nodeOtrosTot.item(i);

					nombre =(String)xpath.evaluate("cac:TaxCategory/cbc:Name", nodeItem, XPathConstants.STRING);
					monto = (String)xpath.evaluate("cbc:TaxAmount", nodeItem, XPathConstants.STRING);
					porcentaje = (String)xpath.evaluate("cbc:Percent", nodeItem, XPathConstants.STRING);
					if ("ISC".equals(nombre.trim().toUpperCase())) {
						comprobante.setTotalISC(ComprobanteUtilBean.toBigDecimal(monto));
					}
					if ("IGV".equals(nombre.trim().toUpperCase())) {
						comprobante.setTotalIGV(ComprobanteUtilBean.toBigDecimal(monto));	
						comprobante.setIgvPorcentaje(ComprobanteUtilBean.toBigDecimal(porcentaje));
					}
					if ("OTROS TRIBUTOS".equals(nombre.trim().toUpperCase())) {
						comprobante.setTotalOtrosTributos(ComprobanteUtilBean.toBigDecimal(monto));												
					}		
					
					
				}
			}			
			comprobante.setMontoImpuestos(comprobante.getTotalISC().add(comprobante.getTotalIGV()).add(comprobante.getTotalOtrosTributos()));

			log.debug("Buscamos los detalles");
			NodeList nlItems = (NodeList)xpath.evaluate(nm + "/cac:InvoiceLine",  doc, XPathConstants.NODESET);
			if(nlItems.getLength() > 0) {
				List <DetalleComprobanteBean> aDetalleComprobante = new ArrayList<DetalleComprobanteBean>();
				DetalleComprobanteBean detalle = null;
				for(int i = 0; i < nlItems.getLength(); i++) {
					Node nodeItem = (Node)nlItems.item(i);
					 detalle = new DetalleComprobanteBean();
					 if (i == 0) {
						comprobante.setObservacion((String)xpath.evaluate("cbc:Note", nodeItem, XPathConstants.STRING));						 
					 }
					 detalle.setIdentificador(Integer.parseInt((String)xpath.evaluate("cbc:ID", nodeItem, XPathConstants.STRING)));
					 detalle.setIdentificadorOriginal(Integer.parseInt((String)xpath.evaluate("cbc:ID", nodeItem, XPathConstants.STRING)));
					 detalle.setNumeroLinea(Integer.parseInt((String)xpath.evaluate("cac:OrderLineReference/cbc:LineID", nodeItem, XPathConstants.STRING)));
					 detalle.setUnidadMedida((String)xpath.evaluate("cbc:InvoicedQuantity/@unitCode", nodeItem, XPathConstants.STRING));
					 detalle.setCodigoItem((String)xpath.evaluate("cac:Item/cac:CatalogueDocumentReference/cbc:ID", nodeItem, XPathConstants.STRING));
					 String operacionGratuita = (String)xpath.evaluate("cbc:FreeOfChargeIndicator", nodeItem, XPathConstants.STRING);
					 if (operacionGratuita.equals("true")){
						 detalle.setTipoBonificacion("BO01"); //Es operaci�n gratuita
					 }else{
						 detalle.setTipoBonificacion("BO00");
					 }
					 if (detalle.getCodigoItem() == null) { detalle.setCodigoItem("");}
					 detalle.setCantidad(ComprobanteUtilBean.formatTwoDecimal((String)xpath.evaluate("cbc:InvoicedQuantity", nodeItem, XPathConstants.STRING)));
					 detalle.setDescripcion((String)xpath.evaluate("cac:Item/cbc:Description", nodeItem, XPathConstants.STRING));
					 //if(detalle.getDescripcion().contains("\""))
					 //	 detalle.setDescripcion(detalle.getDescripcion().replaceAll("\"", "''"));
					 detalle.setPrecioUnitario(ComprobanteUtilBean.formatTwoDecimal((String)xpath.evaluate("cac:Price/cbc:PriceAmount", nodeItem, XPathConstants.STRING)));
						BigDecimal cantidad = new BigDecimal(0);
						if (detalle.getCantidad() == null || detalle.getCantidad().equals("") || detalle.getCantidad().equals("0")){
							cantidad = new BigDecimal(1);
						}else{
							cantidad= new BigDecimal(detalle.getCantidad() );
						}
					 detalle.setValorVenta(ComprobanteUtilBean.formatTwoDecimal(new BigDecimal(detalle.getPrecioUnitario()).multiply(cantidad)));
					 detalle.setMontoBruto(ComprobanteUtilBean.formatTwoDecimal((String)xpath.evaluate("cbc:LineExtensionAmount", nodeItem, XPathConstants.STRING)));
					 detalle.setImporteVenta(ComprobanteUtilBean.formatTwoDecimal((String)xpath.evaluate("cbc:LineExtensionAmount", nodeItem, XPathConstants.STRING)));
					Object oTotalImpuesto = (String)xpath.evaluate("cac:TaxTotal/cbc:TaxAmount", nodeItem, XPathConstants.STRING);
					detalle.setTotalImpuestos(ComprobanteUtilBean.isNumber(oTotalImpuesto) ? ComprobanteUtilBean.formatTwoDecimal((String)oTotalImpuesto) : "0");
					//String oDescuento = (String)xpath.evaluate("cac:AllowanceCharge/cbc:Amount", nodeItem, XPathConstants.STRING);
					detalle.setDescuentoMonto((String)xpath.evaluate("cac:AllowanceCharge/cbc:Amount", nodeItem, XPathConstants.STRING));
//					detalle.setValorVtaUnitario(ComprobanteUtilBean.formatTwoDecimal((new BigDecimal(detalle.getValorVenta())).subtract(new BigDecimal(detalle.getDescuentoMonto()))));
					detalle.setValorVtaUnitario((String)xpath.evaluate("cac:Price/cbc:PriceAmount", nodeItem, XPathConstants.STRING));
					detalle.setDescuentoMontoOriginal(detalle.getDescuentoMonto());
					detalle.setIgvMonto("0");
					detalle.setIscMonto("0");
					detalle.setOtroMonto("0");
					detalle.setTipoBeneficio("TB00"); 
					detalle.setOtrosTributos("0.00");
					detalle.setOtrosTributosOriginal("0.00");
					detalle.setOtrosCargosTributos("0.00");
			
					detalle.setTipoOtrosCargosTributos("");
					detalle.setTipoItem("TI01");  //Quitar cuando se pueda diferencias si el item es bien o servicio
					NodeList nodeTaxSubTotals = (NodeList)xpath.evaluate("cac:TaxTotal/cac:TaxSubtotal",  nodeItem, XPathConstants.NODESET);
					
					BigDecimal otrosCargosTributos = new BigDecimal(0);
					for(int j = 0; j < nodeTaxSubTotals.getLength(); j++) {
						Node nodeTaxSubTotal = (Node)nodeTaxSubTotals.item(j);
						String tributo = (String)xpath.evaluate("cac:TaxCategory/cbc:ID", nodeTaxSubTotal, XPathConstants.STRING);
						if(tributo.equals(ComprobanteUtilBean.IGV)) {
							detalle.setIgvMonto(ComprobanteUtilBean.formatTwoDecimal((String)xpath.evaluate("cbc:TaxAmount", nodeTaxSubTotal, XPathConstants.STRING)));
							if (detalle.getIgvMonto().equals("0") || detalle.getIgvMonto().equals("0.00")){
								detalle.setTipoBeneficio("TB02"); //Inafecto
							}
							detalle.setIgvPorcentaje(ComprobanteUtilBean.formatTwoDecimal((String)xpath.evaluate("cbc:Percent", nodeTaxSubTotal, XPathConstants.STRING)));
							String afectacion = (String)xpath.evaluate("cac:TaxCategory/cbc:TaxExemptionReasonCode", nodeTaxSubTotal, XPathConstants.STRING);
							if (afectacion.equals("10")){ 
								detalle.setTipoBeneficio("TB00"); //Gravado
							}
							if (afectacion.equals("20")){ 
								detalle.setTipoBeneficio("TB01"); //Exonerado
							}		
							if (afectacion.equals("30")){ 
								detalle.setTipoBeneficio("TB02"); //Inafecto
							}							
						}
						else if(tributo.equals(ComprobanteUtilBean.ISC)) {
							detalle.setIscMonto(ComprobanteUtilBean.formatTwoDecimal((String)xpath.evaluate("cbc:TaxAmount", nodeTaxSubTotal, XPathConstants.STRING)));
							detalle.setIscMontoOriginal(ComprobanteUtilBean.formatTwoDecimal((String)xpath.evaluate("cbc:TaxAmount", nodeTaxSubTotal, XPathConstants.STRING)));
							detalle.setIscPorcentaje(ComprobanteUtilBean.formatTwoDecimal((String)xpath.evaluate("cbc:Percent", nodeTaxSubTotal, XPathConstants.STRING)));
						}
						else {
							
							String tipoOtro = (String)xpath.evaluate("cac:TaxCategory/cbc:Name", nodeTaxSubTotal, XPathConstants.STRING);
							if (tipoOtro.equals("OTROS CARGOS")){
								//detalle.setOtroMonto(ComprobanteUtilBean.formatTwoDecimal((String)xpath.evaluate("cbc:TaxAmount", nodeTaxSubTotal, XPathConstants.STRING)));
								detalle.setOtrosCargos(ComprobanteUtilBean.formatTwoDecimal((String)xpath.evaluate("cbc:TaxAmount", nodeTaxSubTotal, XPathConstants.STRING)));
								detalle.setOtrosCargosOriginal(ComprobanteUtilBean.formatTwoDecimal((String)xpath.evaluate("cbc:TaxAmount", nodeTaxSubTotal, XPathConstants.STRING)));
								if (!detalle.getOtrosCargos().equals("0.00")){
									detalle.setTipoOtrosCargosTributos("1");
									otrosCargosTributos.add(new BigDecimal( detalle.getOtrosCargos()));
									
								}
								
							}
							if (tipoOtro.equals("OTROS TRIBUTOS")){
								//detalle.setOtroMonto(ComprobanteUtilBean.formatTwoDecimal((String)xpath.evaluate("cbc:TaxAmount", nodeTaxSubTotal, XPathConstants.STRING)));
								detalle.setOtrosTributos(ComprobanteUtilBean.formatTwoDecimal((String)xpath.evaluate("cbc:TaxAmount", nodeTaxSubTotal, XPathConstants.STRING)));
								detalle.setOtrosTributosOriginal(ComprobanteUtilBean.formatTwoDecimal((String)xpath.evaluate("cbc:TaxAmount", nodeTaxSubTotal, XPathConstants.STRING)));
								if (!detalle.getOtrosTributos().equals("0.00")){
									detalle.setTipoOtrosCargosTributos("2");
									otrosCargosTributos.add(new BigDecimal( detalle.getOtrosTributos()));
								}
							}
							if (otrosCargosTributos.compareTo(ComprobanteUtilBean.toBigDecimal("0.00")) == 1){
								detalle.setOtrosCargosTributos(ComprobanteUtilBean.formatTwoDecimal(otrosCargosTributos));
								detalle.setOtrosCargosTributosOriginal(ComprobanteUtilBean.formatTwoDecimal(otrosCargosTributos));
							}
						}
					}
					
					
					aDetalleComprobante.add(detalle);
				}
				comprobante.setDetalleComprobanteBean(aDetalleComprobante);
			}
			
			
		} catch(ServiceException e) {
			log.error(e);
			throw e;
		} catch(Exception e) {
			log.error(e);
			throw new ServiceException(this, e.getLocalizedMessage());
		}
		return comprobante;
	}
	
	
	
}
