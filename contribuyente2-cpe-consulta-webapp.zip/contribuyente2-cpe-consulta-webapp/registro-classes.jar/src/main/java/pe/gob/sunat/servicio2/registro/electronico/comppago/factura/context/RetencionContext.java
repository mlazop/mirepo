package pe.gob.sunat.servicio2.registro.electronico.comppago.factura.context;

import java.util.Iterator;

import javax.xml.namespace.NamespaceContext;
import javax.xml.xpath.XPath;
import javax.xml.xpath.XPathConstants;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.w3c.dom.Document;
import org.w3c.dom.Node;

import pe.gob.sunat.framework.spring.util.exception.ServiceException;
import pe.gob.sunat.servicio2.registro.electronico.comppago.factura.bean.ComprobanteBean;

@SuppressWarnings({"rawtypes","unchecked"})
public class RetencionContext extends ComprobanteContext {
	protected final Log log = LogFactory.getLog(getClass());

	private static final String NODE_DOCUMENT = "/sunat:Retention";
	private static final String FILE_SCHEMA = "UBL-Invoice-2.0.xsd"; //"UBLPE-Invoice-1.0"; //"UBL-Invoice-2.0.xsd"
	private static final String FILE_TEMPLATE = "Invoice-2.0-Template.vm";
	
	public String getMainNodeValue() {
		return NODE_DOCUMENT;
	}
	
	public String getSchema() {
		return FILE_SCHEMA;
	}
	
	public String getTemplate() {
		return FILE_TEMPLATE;
	}

	public NamespaceContext getNamespaceContext() {
		return new FacturaNamespace();
	}
	
	public Node getNodeToSign(Document doc, XPath xpath) {
		return this.addExtensionContent(doc, xpath);
	}

	public Node getNodeSigned(Document doc, XPath xpath) {
		try {
			String expresion = this.getMainNodeValue() + "/cac:Signature/cac:DigitalSignatureAttachment/cac:ExternalReference/cbc:URI";
			String reference = (String)xpath.evaluate(expresion, doc, XPathConstants.STRING);
			if(reference == null) throw new Exception(expresion + " not found");
			else if(reference.trim().length() == 0) throw new Exception(expresion + " is empty");
			Node nodeSign = (Node)xpath.evaluate(this.getMainNodeValue() + "/ext:UBLExtensions/ext:UBLExtension/ext:ExtensionContent/ds:Signature", doc, XPathConstants.NODE);
			if(nodeSign == null) throw new Exception("Cannot find Signature element");
			return nodeSign;
		}
		catch(Exception e) {
			throw new ServiceException(this, e);
		}
	}

	public Node getNodeExtensions(Document doc, XPath xpath) {
		try {
			Node extensions = (Node)xpath.evaluate(this.getMainNodeValue() + "/ext:UBLExtensions",  doc, XPathConstants.NODE);
			return extensions;
		}
		catch(Exception e) {
			throw new ServiceException(this, e);
		}
	}
	
	public void generaXml(Document doc, XPath xpath, ComprobanteBean comprobante) {
	      setTextNode(doc,
	                  xpath,
	                  doc,
	                  "/sunat:Retention/cbc:ID",
	                  comprobante.getSerieComprobante().trim() + "-" + comprobante.getNumeroComprobante());
	      setTextNode(doc, xpath, doc, "/sunat:Retention/cbc:IssueDate", comprobante.getFechaEmision().toString());
	   }

	public class FacturaNamespace implements NamespaceContext {

		public String getNamespaceURI(String prefix) {
			if(prefix.equals("qdt"))
				return "urn:oasis:names:specification:ubl:schema:xsd:QualifiedDatatypes-2";
			else if(prefix.equals("ccts"))
				return "urn:oasis:names:specification:ubl:schema:xsd:CoreComponentParameters-2";
			else if(prefix.equals("stat"))
				return "urn:oasis:names:specification:ubl:schema:xsd:DocumentStatusCode-1.0";
			else if(prefix.equals("cbc"))
				return "urn:oasis:names:specification:ubl:schema:xsd:CommonBasicComponents-2";
			else if(prefix.equals("cac"))
				return "urn:oasis:names:specification:ubl:schema:xsd:CommonAggregateComponents-2";
			else if(prefix.equals("udt"))
				return "urn:un:unece:uncefact:data:draft:UnqualifiedDataTypesSchemaModule:2";
			else if(prefix.equals("ext"))
				return "urn:oasis:names:specification:ubl:schema:xsd:CommonExtensionComponents-2";
			else if(prefix.equals("sac"))
				return "urn:sunat:names:specification:ubl:peru:schema:xsd:SunatAggregateComponents-1";
			else if(prefix.equals("ds"))
				return "http://www.w3.org/2000/09/xmldsig#";
			else return "urn:sunat:names:specification:ubl:peru:schema:xsd:Retention-1";
		}

		public String getPrefix(String p) {
			return null;
		}

		public Iterator<Object> getPrefixes(String p) {
			return null;
		}
	}
	
	
	@Override
	   public ComprobanteBean generaComprobanteBean(Document doc, XPath xpath) {
	      ComprobanteBean comprobante = new ComprobanteBean();
	      return comprobante;
	   }

	
	
	
}
