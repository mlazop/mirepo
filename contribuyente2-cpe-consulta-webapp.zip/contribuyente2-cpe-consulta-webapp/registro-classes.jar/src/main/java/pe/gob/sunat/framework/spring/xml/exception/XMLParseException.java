package pe.gob.sunat.framework.spring.xml.exception;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import pe.gob.sunat.framework.spring.xml.exception.bean.XMLParseBean;

public class XMLParseException extends RuntimeException {
    private static final long serialVersionUID = 0L;
    public static final int WARNING = 1;
    public static final int ERROR = 2;
    public static final int FATAL = 3;
    private XMLParseBean message;
    
    public XMLParseException() {}

    public XMLParseException(Object o, int type, int line, String msg) {
        super(msg);
        message = new XMLParseBean();
        message.setType(type);
        message.setLine(line);
        message.setMessage(msg);
        Log log = LogFactory.getLog(o.getClass());
        log.error(o.getClass().getName() + "|" + message);
        log.debug("Error", this);
    }

    public XMLParseException(Object o, XMLParseBean msg) {
        super(msg.getMessage());
        this.message = msg;
        
        if(msg.getType() != WARNING && msg.getType() != ERROR && msg.getType() != FATAL)
        	this.message.setType(ERROR);
        
        Log log = LogFactory.getLog(o.getClass());
        log.error(o.getClass().getName() + "|" + msg.getMessage());
        log.debug("Error", this);
    }

    public XMLParseBean getMessageBean(){
        return message;
    }
}

