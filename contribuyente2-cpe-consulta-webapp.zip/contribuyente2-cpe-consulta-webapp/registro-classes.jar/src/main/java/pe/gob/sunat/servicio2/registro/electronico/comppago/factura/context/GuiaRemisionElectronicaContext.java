package pe.gob.sunat.servicio2.registro.electronico.comppago.factura.context;

import java.util.Iterator;

import javax.xml.namespace.NamespaceContext;
import javax.xml.xpath.XPath;
import javax.xml.xpath.XPathConstants;

import org.w3c.dom.Document;
import org.w3c.dom.Node;

import pe.gob.sunat.framework.spring.util.exception.ServiceException;
import pe.gob.sunat.servicio2.registro.electronico.comppago.factura.bean.ComprobanteBean;

/**
 * @author jventura
 * @since 24.05.2016
 * 
 */
public class GuiaRemisionElectronicaContext extends ComprobanteContext {

   private static final String GUIA_REMISION_ELECTRONICA_REMITENTE = "09";
   private static final String GUIA_REMISION_ELECTRONICA_TRANSPORTISTA = "31";

   private static String NODE_DOCUMENT = "/sunat:DespatchAdvice";
   private static String FILE_SCHEMA_REMISION = "UBL-DespatchAdvice-2.1.xsd";
   private static final String FILE_TEMPLATE_REMITENTE = "CarrierDespatchAdvice-1.0-Template.vm";
   private static final String FILE_TEMPLATE_TRANSPOSTISTA = "ConsignorDespatchAdvice-1.0-Template.vm";
   private String tipoGuia;
//   private String[] arrayTipoGuia = new String[] { GUIA_REMISION_ELECTRONICA_REMITENTE, GUIA_REMISION_ELECTRONICA_TRANSPORTISTA };

//   public GuiaRemisionElectronicaContext(String tipoGuia) {
//      if (ArrayUtils.contains(arrayTipoGuia, tipoGuia)) {
//         this.tipoGuia = tipoGuia;
//      } else {
//         throw new IllegalArgumentException("El tipo de guia no es una guia electronica");
//      }
//   }
   
   public GuiaRemisionElectronicaContext() {
	      this.tipoGuia = GUIA_REMISION_ELECTRONICA_REMITENTE;
   }

   public String getMainNodeValue() {
      return NODE_DOCUMENT;
   }

   public String getSchema() {
      return FILE_SCHEMA_REMISION;
   }

   public String getTemplate() {
      if (tipoGuia.equals(GUIA_REMISION_ELECTRONICA_REMITENTE)) {
         return FILE_TEMPLATE_REMITENTE;
      } else if (tipoGuia.equals(GUIA_REMISION_ELECTRONICA_TRANSPORTISTA)) {
         return FILE_TEMPLATE_TRANSPOSTISTA;
      } else {
         return "";
      }
   }

   public NamespaceContext getNamespaceContext() {
      return new GuiaRemisionElectronicaNamespace();
   }

   public Node getNodeToSign(Document doc, XPath xpath) {
      return this.addExtensionContent(doc, xpath);
   }

   public Node getNodeSigned(Document doc, XPath xpath) {
      try {
         String expresion = this.getMainNodeValue() + "/cac:Signature/cac:DigitalSignatureAttachment/cac:ExternalReference/cbc:URI";
         String reference = (String) xpath.evaluate(expresion, doc, XPathConstants.STRING);
         if (reference == null)
            throw new Exception(expresion + " not found");
         else if (reference.trim().length() == 0)
            throw new Exception(expresion + " is empty");
         Node nodeSign = (Node) xpath.evaluate(this.getMainNodeValue() + "/ext:UBLExtensions/ext:UBLExtension/ext:ExtensionContent/ds:Signature",
                                               doc,
                                               XPathConstants.NODE);
         if (nodeSign == null)
            throw new Exception("Cannot find Signature element");
         return nodeSign;
      } catch (Exception e) {
         throw new ServiceException(this, e);
      }
   }

   public Node getNodeExtensions(Document doc, XPath xpath) {
      try { 
         Node extensions = (Node) xpath.evaluate(this.getMainNodeValue() + "/ext:UBLExtensions",
                                                 doc,
                                                 XPathConstants.NODE);
         return extensions;
      } catch (Exception e) {
         throw new ServiceException(this, e);
      }
   }

   public void generaXml(Document doc, XPath xpath, ComprobanteBean comprobante) {
      setTextNode(doc,
                  xpath,
                  doc,
                  "/sunat:DespatchAdvice/cbc:ID",
                  comprobante.getSerieComprobante().trim() + "-" + comprobante.getNumeroComprobante());
      setTextNode(doc, xpath, doc, "/sunat:DespatchAdvice/cbc:IssueDate", comprobante.getFechaEmision().toString());
   }

   public class GuiaRemisionElectronicaNamespace implements NamespaceContext {

      public String getNamespaceURI(String prefix) {
         if (prefix.equals("qdt"))
            return "urn:oasis:names:specification:ubl:schema:xsd:QualifiedDatatypes-2";
         else if (prefix.equals("ccts"))
            return "urn:oasis:names:specification:ubl:schema:xsd:CoreComponentParameters-2";
         else if (prefix.equals("stat"))
            return "urn:oasis:names:specification:ubl:schema:xsd:DocumentStatusCode-1.0";
         else if (prefix.equals("cbc"))
            return "urn:oasis:names:specification:ubl:schema:xsd:CommonBasicComponents-2";
         else if (prefix.equals("cac"))
            return "urn:oasis:names:specification:ubl:schema:xsd:CommonAggregateComponents-2";
         else if (prefix.equals("cac"))
            return "urn:un:unece:uncefact:data:draft:UnqualifiedDataTypesSchemaModule:2";
         else if (prefix.equals("ext"))
            return "urn:oasis:names:specification:ubl:schema:xsd:CommonExtensionComponents-2";
         else if (prefix.equals("sac"))
            return "urn:sunat:names:specification:ubl:peru:schema:xsd:SunatAggregateComponents-1";
         else if (prefix.equals("ds"))
            return "http://www.w3.org/2000/09/xmldsig#";
         else
            return "urn:oasis:names:specification:ubl:schema:xsd:DespatchAdvice-2";
      }

      public String getPrefix(String p) {
         return null;
      }

      public Iterator<Object> getPrefixes(String p) {
         return null;
      }
   }

   @Override
   public ComprobanteBean generaComprobanteBean(Document doc, XPath xpath) {
      ComprobanteBean comprobante = new ComprobanteBean();
      return comprobante;
   }

}
