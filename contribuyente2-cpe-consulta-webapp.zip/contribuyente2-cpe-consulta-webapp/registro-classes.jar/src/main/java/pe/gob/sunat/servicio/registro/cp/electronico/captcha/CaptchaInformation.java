package pe.gob.sunat.servicio.registro.cp.electronico.captcha;

import java.awt.image.BufferedImage;

/**
 * @author Carlos Enrique Quispe Salazar
 */
public class CaptchaInformation {
    
    public CaptchaInformation(BufferedImage image, String word) {
        this.image = image;
        this.word = word;
    }
    /**
     * @return Returns the image.
     */
    public BufferedImage getImage() {
        return image;
    }
    /**
     * @param image The image to set.
     */
    public void setImage(BufferedImage image) {
        this.image = image;
    }
    /**
     * @return Returns the word.
     */
    public String getWord() {
        return word;
    }
    /**
     * @param word The word to set.
     */
    public void setWord(String word) {
        this.word = word;
    }
    private String word;
    private BufferedImage image;
}
