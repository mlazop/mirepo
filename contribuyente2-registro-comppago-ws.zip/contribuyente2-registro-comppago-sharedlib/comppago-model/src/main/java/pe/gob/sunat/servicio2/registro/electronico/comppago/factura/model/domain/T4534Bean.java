//package pe.gob.sunat.servicio2.registro.electronico.comppago.factura.model.domain;
package pe.gob.sunat.servicio2.registro.electronico.comppago.factura.model.domain;


import pe.gob.sunat.framework.spring.util.date.FechaBean;

public class T4534Bean  implements java.io.Serializable{  
	private static final long serialVersionUID = 1L;
			    
	private String  num_ruc;    
    private String cod_cpe; 
    private String num_serie_cpe; 
    private Integer num_cpe; 
    private String num_ticket;     
    private Integer num_correl_ticket;   
    private String ind_origen;        
    private  FechaBean  fec_registro_doc; 
    private String cod_usumodif; 
    private FechaBean fec_modif;
	public String getNum_ruc() {
		return num_ruc;
	}
	public void setNum_ruc(String numRuc) {
		num_ruc = numRuc;
	}
	public String getCod_cpe() {
		return cod_cpe;
	}
	public void setCod_cpe(String codCpe) {
		cod_cpe = codCpe;
	}
	public String getNum_serie_cpe() {
		return num_serie_cpe;
	}
	public void setNum_serie_cpe(String numSerieCpe) {
		num_serie_cpe = numSerieCpe;
	}
	public Integer getNum_cpe() {
		return num_cpe;
	}
	public void setNum_cpe(Integer numCpe) {
		num_cpe = numCpe;
	}
	public String getNum_ticket() {
		return num_ticket;
	}
	public void setNum_ticket(String numTicket) {
		num_ticket = numTicket;
	}
	public Integer getNum_correl_ticket() {
		return num_correl_ticket;
	}
	public void setNum_correl_ticket(Integer numCorrelTicket) {
		num_correl_ticket = numCorrelTicket;
	}
	public String getInd_origen() {
		return ind_origen;
	}
	public void setInd_origen(String indOrigen) {
		ind_origen = indOrigen;
	}
	public FechaBean getFec_registro_doc() {
		return fec_registro_doc;
	}
	public void setFec_registro_doc(FechaBean fecRegistroDoc) {
		fec_registro_doc = fecRegistroDoc;
	}
	public String getCod_usumodif() {
		return cod_usumodif;
	}
	public void setCod_usumodif(String codUsumodif) {
		cod_usumodif = codUsumodif;
	}
	public FechaBean getFec_modif() {
		return fec_modif;
	}
	public void setFec_modif(FechaBean fecModif) {
		fec_modif = fecModif;
	}
	@Override
	public String toString() {
		return "T4534Bean [cod_cpe=" + cod_cpe + ", cod_usumodif="
				+ cod_usumodif + ", fec_modif=" + fec_modif
				+ ", fec_registro_doc=" + fec_registro_doc + ", ind_origen="
				+ ind_origen + ", num_correl_ticket=" + num_correl_ticket
				+ ", num_cpe=" + num_cpe + ", num_ruc=" + num_ruc
				+ ", num_serie_cpe=" + num_serie_cpe + ", num_ticket="
				+ num_ticket + "]";
	}
	public T4534Bean(String numRuc, String codCpe, String numSerieCpe,
			Integer numCpe, String numTicket, Integer numCorrelTicket,
			String indOrigen, FechaBean fecRegistroDoc, String codUsumodif,
			FechaBean fecModif) {
		super();
		num_ruc = numRuc;
		cod_cpe = codCpe;
		num_serie_cpe = numSerieCpe;
		num_cpe = numCpe;
		num_ticket = numTicket;
		num_correl_ticket = numCorrelTicket;
		ind_origen = indOrigen;
		fec_registro_doc = fecRegistroDoc;
		cod_usumodif = codUsumodif;
		fec_modif = fecModif;
	}
	public T4534Bean() {
		super();
	}
    
  
}
/*
 */
