package pe.gob.sunat.servicio2.registro.electronico.comppago.factura.context;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import javax.xml.namespace.NamespaceContext;
import javax.xml.xpath.XPath;
import javax.xml.xpath.XPathConstants;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.w3c.dom.Document;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;

import pe.gob.sunat.framework.spring.util.date.FechaBean;
import pe.gob.sunat.framework.spring.util.exception.ServiceException;
import pe.gob.sunat.servicio2.registro.electronico.comppago.factura.bean.ComprobanteBean;
import pe.gob.sunat.servicio2.registro.electronico.comppago.factura.bean.ComprobanteUtilBean;
import pe.gob.sunat.servicio2.registro.electronico.comppago.factura.bean.DetalleComprobanteBean;
import pe.gob.sunat.servicio2.registro.electronico.comppago.factura.bean.DocumentoRelacionadoBean;
import pe.gob.sunat.servicio2.registro.electronico.comppago.factura.bean.OtroDocumentoRelacionadoBean;

public class NotaDebitoContext extends ComprobanteContext {

    protected final Log log = LogFactory.getLog(getClass());

    private static String NODE_DOCUMENT = "/sunat:DebitNote";
    //PAS20181U210000122 UBL 2.1
    private static String FILE_SCHEMA = "UBLPE-DebitNote-2.0.xsd";  //Personalizado a peru UBLPE-DebitNote-1.0.xsd
    private static final String FILE_TEMPLATE = "DebitNote-2.1-Template.vm"; //DebitNote-2.0-Template.vm

    public String getMainNodeValue() {
        return NODE_DOCUMENT;
    }

    public String getSchema() {
        return FILE_SCHEMA;
    }

    public String getTemplate() {
        return FILE_TEMPLATE;
    }

    public NamespaceContext getNamespaceContext() {
        return new NotaDebitoNamespace();
    }

    public Node getNodeToSign(Document doc, XPath xpath) {
        return this.addExtensionContent(doc, xpath);
    }

    public Node getNodeSigned(Document doc, XPath xpath) {
        try {
            String expresion = this.getMainNodeValue() + "/cac:Signature/cac:DigitalSignatureAttachment/cac:ExternalReference/cbc:URI";
            String reference = (String) xpath.evaluate(expresion, doc, XPathConstants.STRING);
            if (reference == null) {
                throw new Exception(expresion + " not found");
            } else if (reference.trim().length() == 0) {
                throw new Exception(expresion + " is empty");
            }
            Node nodeSign = (Node) xpath.evaluate(this.getMainNodeValue() + "/ext:UBLExtensions/ext:UBLExtension/ext:ExtensionContent/ds:Signature", doc, XPathConstants.NODE);
            if (nodeSign == null) {
                throw new Exception("Cannot find Signature element");
            }
            return nodeSign;
        } catch (Exception e) {
            throw new ServiceException(this, e);
        }
    }

    public Node getNodeExtensions(Document doc, XPath xpath) {
        try {
            Node extensions = (Node) xpath.evaluate(this.getMainNodeValue() + "/ext:UBLExtensions", doc, XPathConstants.NODE);
            return extensions;
        } catch (Exception e) {
            throw new ServiceException(this, e);
        }
    }

    public void generaXml(Document doc, XPath xpath, ComprobanteBean comprobante) {
        setTextNode(doc, xpath, doc, "/sunat:Invoice/cbc:ID", comprobante.getSerieComprobante().trim() + "-"
                + comprobante.getNumeroComprobante());
        setTextNode(doc, xpath, doc, "/sunat:Invoice/cbc:IssueDate", comprobante.getFechaEmision().toString());
        setTextNode(doc, xpath, doc, "/sunat:Invoice/cbc:IssueTime", comprobante.getHoraEmision());

    }

    public class NotaDebitoNamespace implements NamespaceContext {

        public String getNamespaceURI(String prefix) {
            if (prefix.equals("qdt")) {
                return "urn:oasis:names:specification:ubl:schema:xsd:QualifiedDatatypes-2";
            } else if (prefix.equals("ccts")) {
                return "urn:oasis:names:specification:ubl:schema:xsd:CoreComponentParameters-2";
            } else if (prefix.equals("stat")) {
                return "urn:oasis:names:specification:ubl:schema:xsd:DocumentStatusCode-1.0";
            } else if (prefix.equals("cbc")) {
                return "urn:oasis:names:specification:ubl:schema:xsd:CommonBasicComponents-2";
            } else if (prefix.equals("cac")) {
                return "urn:oasis:names:specification:ubl:schema:xsd:CommonAggregateComponents-2";
            } else if (prefix.equals("cac")) {
                return "urn:un:unece:uncefact:data:draft:UnqualifiedDataTypesSchemaModule:2";
            } else if (prefix.equals("ext")) {
                return "urn:oasis:names:specification:ubl:schema:xsd:CommonExtensionComponents-2";
            } else if (prefix.equals("sac")) {
                return "urn:sunat:names:specification:ubl:peru:schema:xsd:SunatAggregateComponents-1";
            } else if (prefix.equals("ds")) {
                return "http://www.w3.org/2000/09/xmldsig#";
            } else {
                return "urn:oasis:names:specification:ubl:schema:xsd:DebitNote-2";
            }
        }

        public String getPrefix(String p) {
            return null;
        }

        public Iterator<Object> getPrefixes(String p) {
            return null;
        }
    }

    @Override
    public ComprobanteBean generaComprobanteBean(Document doc, XPath xpath) {
        ComprobanteBean comprobante = null;
        try {
            String nm = this.getMainNodeValue();
            String serieNumero = xpath.evaluate(nm + "/cbc:ID", doc, XPathConstants.STRING).toString();
            if (serieNumero.startsWith("E")) {
                comprobante = generaComprobantePortal(doc, xpath);
            } else if (serieNumero.startsWith("F") || serieNumero.startsWith("B")) {
                comprobante = generaComprobanteGEM(doc, xpath);
            }
        } catch (ServiceException e) {
            log.error(e.getLocalizedMessage());
            throw e;
        } catch (Exception e) {
            log.error(e, e);
            throw new ServiceException(this, e.getLocalizedMessage());
        }
        return comprobante;
    }

    /**
     * Genera comprobante para Notas de D�bito de GEM.
     *
     * @param doc
     * @param xpath
     * @return
     */
    private ComprobanteBean generaComprobanteGEM(Document doc, XPath xpath) {

        if (log.isInfoEnabled()) {
            log.info(">> generaComprobanteGEM :: Genera ComprobanteBean de la Nota de d�bito GEM");
        }

        ComprobanteBean comprobante = new ComprobanteBean();

        try {
            String nm = this.getMainNodeValue();
            Object tmpObj = null;
            Node nodeItem = null;
            String identifier = "";

            comprobante.setNumeroRuc(xpath.evaluate(nm + "/cac:AccountingSupplierParty/cbc:CustomerAssignedAccountID", doc, XPathConstants.STRING).toString());
            comprobante.setRazonSocial(xpath.evaluate(nm + "/cac:AccountingSupplierParty/cac:Party/cac:PartyLegalEntity/cbc:RegistrationName", doc, XPathConstants.STRING).toString());

            tmpObj = xpath.evaluate(nm + "/cac:AccountingSupplierParty/cac:Party/cac:PostalAddress/cbc:StreetName", doc, XPathConstants.STRING);
            comprobante.setNombreCalle(tmpObj != null && tmpObj.toString().length() > 0 ? tmpObj.toString() : "");

            tmpObj = xpath.evaluate(nm + "/cac:AccountingSupplierParty/cac:Party/cac:PostalAddress/cbc:CitySubdivisionName", doc, XPathConstants.STRING);
            comprobante.setNombreUrbanizacion(tmpObj != null && tmpObj.toString().length() > 0 ? tmpObj.toString() : "");

            tmpObj = xpath.evaluate(nm + "/cac:AccountingSupplierParty/cac:Party/cac:PostalAddress/cbc:District", doc, XPathConstants.STRING);
            comprobante.setNombreDistrito(tmpObj != null && tmpObj.toString().length() > 0 ? tmpObj.toString() : "");

            tmpObj = xpath.evaluate(nm + "/cac:AccountingSupplierParty/cac:Party/cac:PostalAddress/cbc:CityName", doc, XPathConstants.STRING);
            comprobante.setNombreProvincia(tmpObj != null && tmpObj.toString().length() > 0 ? tmpObj.toString() : "");

            tmpObj = xpath.evaluate(nm + "/cac:AccountingSupplierParty/cac:Party/cac:PostalAddress/cbc:CountrySubentity", doc, XPathConstants.STRING);
            comprobante.setNombreDepartamento(tmpObj != null && tmpObj.toString().length() > 0 ? tmpObj.toString() : "");

            tmpObj = xpath.evaluate(nm + "/cac:AccountingSupplierParty/cac:Party/cac:PostalAddress/cac:Country/cbc:IdentificationCode", doc, XPathConstants.STRING);
            comprobante.setCodigoPais(tmpObj != null && tmpObj.toString().length() > 0 ? tmpObj.toString() : "");

            tmpObj = comprobante.getNombreCalle() + comprobante.getNombreUrbanizacion() + comprobante.getNombreDistrito() + comprobante.getNombreProvincia() + comprobante.getNombreDepartamento();

            comprobante.setDireccionCompleta(tmpObj.toString().length() == 0 ? ""
                    : comprobante.getNombreCalle() + ", " + comprobante.getNombreUrbanizacion() + ", "
                    + comprobante.getNombreDistrito() + ", " + comprobante.getNombreProvincia() + ", "
                    + comprobante.getNombreDepartamento() + ", " + comprobante.getCodigoPais()
            );

            if (log.isDebugEnabled()) {
                log.debug(">> Step 1 :: Complet� Datos del emisor.");
            }

            comprobante.setTipoDocumentoCliente(xpath.evaluate(nm + "/cac:AccountingCustomerParty/cbc:AdditionalAccountID", doc, XPathConstants.STRING).toString());
            comprobante.setDesTipoDocumentoCliente(obtenerDescCatalogo06(comprobante.getTipoDocumentoCliente()));

            comprobante.setNumeroDocumentoCliente(xpath.evaluate(nm + "/cac:AccountingCustomerParty/cbc:CustomerAssignedAccountID", doc, XPathConstants.STRING).toString());
            comprobante.setNombreCliente(xpath.evaluate(nm + "/cac:AccountingCustomerParty/cac:Party/cac:PartyLegalEntity/cbc:RegistrationName", doc, XPathConstants.STRING).toString());

            if (log.isDebugEnabled()) {
                log.debug(">> Step 2 :: Complet� Datos del comprador.");
            }

            comprobante.setSerieComprobante(xpath.evaluate(nm + "/cbc:ID", doc, XPathConstants.STRING).toString());
            comprobante.setFechaEmision(xpath.evaluate(nm + "/cbc:IssueDate", doc, XPathConstants.STRING).toString());
            comprobante.setCodigoMoneda(xpath.evaluate(nm + "/cbc:DocumentCurrencyCode", doc, XPathConstants.STRING).toString());

            String tipoNota = xpath.evaluate(nm + "/cac:DiscrepancyResponse/cbc:ResponseCode", doc, XPathConstants.STRING).toString();
            comprobante.setGlosa(obtenerDescCatalogo10(tipoNota));

            comprobante.setMotivoEmisionNota(xpath.evaluate(nm + "/cac:DiscrepancyResponse/cbc:Description", doc, XPathConstants.STRING).toString());

            if (log.isDebugEnabled()) {
                log.debug(">> Step 3 :: Complet� Datos del comprobante");
            }

            comprobante.setSerieDocumentoPorElQueSeEmite(xpath.evaluate(nm + "/cac:BillingReference/cac:InvoiceDocumentReference/cbc:ID", doc, XPathConstants.STRING).toString());
            String tipComp = xpath.evaluate(nm + "/cac:BillingReference/cac:InvoiceDocumentReference/cbc:DocumentTypeCode", doc, XPathConstants.STRING).toString();
            comprobante.setDescTipoDocQueModifica(obtenerDescCatalogo01(tipComp.trim()));

            if (log.isDebugEnabled()) {
                log.debug(">> Step 4 :: Complet� Datos del comprobante que modifica");
            }

            NodeList nlItems = (NodeList) xpath.evaluate(nm + "/cac:DebitNoteLine", doc, XPathConstants.NODESET);
            if (nlItems.getLength() > 0) {
                List<DetalleComprobanteBean> aDetalleComprobante = new ArrayList<DetalleComprobanteBean>();
                DetalleComprobanteBean linea = null;
                for (int i = 0; i < nlItems.getLength(); i++) {
                    nodeItem = (Node) nlItems.item(i);
                    linea = new DetalleComprobanteBean();

                    tmpObj = xpath.evaluate("cbc:DebitedQuantity", nodeItem, XPathConstants.STRING);
                    linea.setCantidad(tmpObj != null && tmpObj.toString().length() > 0 ? ComprobanteUtilBean.formatTwoDecimal(tmpObj.toString()) : "");

                    tmpObj = xpath.evaluate("cbc:DebitedQuantity/@unitCode", nodeItem, XPathConstants.STRING);
                    linea.setUnidadMedida(tmpObj != null && tmpObj.toString().length() > 0 ? tmpObj.toString() : "");

                    tmpObj = xpath.evaluate("cac:Item/cac:SellersItemIdentification/cbc:ID", nodeItem, XPathConstants.STRING);
                    linea.setCodigoItem(tmpObj != null && tmpObj.toString().length() > 0 ? tmpObj.toString() : "");

                    tmpObj = xpath.evaluate("cac:Item/cbc:Description", nodeItem, XPathConstants.STRING);
                    linea.setDescripcion(tmpObj != null && tmpObj.toString().length() > 0 ? tmpObj.toString() : "");

                    tmpObj = xpath.evaluate("cac:Price/cbc:PriceAmount", nodeItem, XPathConstants.STRING);
                    linea.setValorVtaUnitario(tmpObj != null && tmpObj.toString().length() > 0 ? ComprobanteUtilBean.formatTwoDecimal(tmpObj.toString()) : "");
                    /**
                     * El valor de venta total (V.V.U * Cantidad)
                     */
                    tmpObj = xpath.evaluate("cbc:LineExtensionAmount", nodeItem, XPathConstants.STRING);
                    linea.setTotalVentaPorItem(tmpObj != null && tmpObj.toString().length() > 0 ? ComprobanteUtilBean.formatTwoDecimal(tmpObj.toString()) : "");

                    tmpObj = xpath.evaluate("cac:PricingReference/cac:AlternativeConditionPrice/cbc:PriceAmount", nodeItem, XPathConstants.STRING);
                    linea.setPrecioUnitario(tmpObj != null && tmpObj.toString().length() > 0 ? ComprobanteUtilBean.formatTwoDecimal(tmpObj.toString()) : "");

                    tmpObj = xpath.evaluate("cac:TaxTotal/cac:TaxSubtotal/cac:TaxCategory/cac:TaxScheme/cbc:ID", nodeItem, XPathConstants.STRING);
                    if (tmpObj.toString().trim().equals("1000")) {
                        /**
                         * Monto del IGV de la l�nea
                         */
                        tmpObj = xpath.evaluate("cac:TaxTotal/cbc:TaxAmount", nodeItem, XPathConstants.STRING);
                        linea.setIgvMonto(tmpObj != null && tmpObj.toString().length() > 0 ? ComprobanteUtilBean.formatTwoDecimal(tmpObj.toString()) : "");
                    } else if (tmpObj.toString().trim().equals("2000")) {
                        /**
                         * Monto del ISC de la l�nea
                         */
                        tmpObj = xpath.evaluate("cac:TaxTotal/cbc:TaxAmount", nodeItem, XPathConstants.STRING);
                        linea.setIscSistema(tmpObj != null && tmpObj.toString().length() > 0 ? ComprobanteUtilBean.formatTwoDecimal(tmpObj.toString()) : "");
                    }
                    aDetalleComprobante.add(linea);
                }
                comprobante.setDetalleComprobanteBean(aDetalleComprobante);
            }

            if (log.isDebugEnabled()) {
                log.debug(">> Step 5 :: Complet� Datos del Items(lineas) de la Nota de d�bito.");
            }

            NodeList additDocs = (NodeList) xpath.evaluate(nm + "/cac:DespatchDocumentReference", doc, XPathConstants.NODESET);
            if (additDocs.getLength() > 0) {
                for (int i = 0; i < additDocs.getLength(); i++) {
                    DocumentoRelacionadoBean docrel = new DocumentoRelacionadoBean();
                    nodeItem = (Node) additDocs.item(i);
                    identifier = xpath.evaluate("cbc:DocumentTypeCode", nodeItem, XPathConstants.STRING).toString().trim();
                    docrel.setTipoComprobante(identifier);
                    docrel.setDescTipoComprobanteRelacionado(obtenerDescCatalogo01(identifier));
                    docrel.setSerieComprobanteRelacionado(xpath.evaluate("cbc:ID", nodeItem, XPathConstants.STRING).toString());
                    comprobante.getDocumentoRelacionadoBean().add(docrel);
                }
            }
            additDocs = (NodeList) xpath.evaluate(nm + "/cac:AdditionalDocumentReference", doc, XPathConstants.NODESET);
            if (additDocs.getLength() > 0) {
                for (int i = 0; i < additDocs.getLength(); i++) {
                    DocumentoRelacionadoBean docrel = new DocumentoRelacionadoBean();
                    nodeItem = (Node) additDocs.item(i);
                    identifier = xpath.evaluate("cbc:DocumentTypeCode", nodeItem, XPathConstants.STRING).toString().trim();
                    docrel.setTipoComprobante(identifier);
                    docrel.setDescTipoComprobanteRelacionado(obtenerDescCatalogo12(identifier));
                    docrel.setSerieComprobanteRelacionado(xpath.evaluate("cbc:ID", nodeItem, XPathConstants.STRING).toString());
                    comprobante.getDocumentoRelacionadoBean().add(docrel);
                }
            }

            if (log.isDebugEnabled()) {
                log.debug(">> Step 6 :: Complet� documentos relacionados de la nota de d�bito.");
            }

            NodeList totalesVenta = (NodeList) xpath.evaluate(nm + "/ext:UBLExtensions/ext:UBLExtension/ext:ExtensionContent/sac:AdditionalInformation/sac:AdditionalMonetaryTotal", doc, XPathConstants.NODESET);
            if (totalesVenta.getLength() > 0) {
                for (int i = 0; i < totalesVenta.getLength(); i++) {
                    nodeItem = (Node) totalesVenta.item(i);
                    identifier = xpath.evaluate("cbc:ID", nodeItem, XPathConstants.STRING).toString();
                    if ("1001".equals(identifier)) {
                        comprobante.setTotalValorVenta(ComprobanteUtilBean.toBigDecimal(xpath.evaluate("cbc:PayableAmount", nodeItem, XPathConstants.STRING).toString()));
                    } else if ("1002".equals(identifier)) { // valor de venta inafecta
                        comprobante.setTotalValorVentaNoGravado(ComprobanteUtilBean.toBigDecimal(xpath.evaluate("cbc:PayableAmount", nodeItem, XPathConstants.STRING).toString()));
                    } else if ("1003".equals(identifier)) {
                        comprobante.setTotalValorVentaExonerado(ComprobanteUtilBean.toBigDecimal(xpath.evaluate("cbc:PayableAmount", nodeItem, XPathConstants.STRING).toString()));
                    } else if ("2005".equals(identifier)) {
                        comprobante.setTotalDescuentos(ComprobanteUtilBean.toBigDecimal(xpath.evaluate("cbc:PayableAmount", nodeItem, XPathConstants.STRING).toString()));
                    }
                }
            }

            NodeList totalesOtros = (NodeList) xpath.evaluate(nm + "/cac:TaxTotal/cac:TaxSubtotal", doc, XPathConstants.NODESET);
            if (totalesOtros.getLength() > 0) {
                for (int i = 0; i < totalesOtros.getLength(); i++) {
                    nodeItem = (Node) totalesOtros.item(i);
                    identifier = xpath.evaluate("cac:TaxCategory/cac:TaxScheme/cbc:ID", nodeItem, XPathConstants.STRING).toString();
                    if ("1000".equals(identifier)) {
                        comprobante.setTotalIGV(ComprobanteUtilBean.toBigDecimal(xpath.evaluate("cbc:TaxAmount", nodeItem, XPathConstants.STRING).toString()));
                    } else if ("2000".equals(identifier)) {
                        comprobante.setTotalISC(ComprobanteUtilBean.toBigDecimal(xpath.evaluate("cbc:TaxAmount", nodeItem, XPathConstants.STRING).toString()));
                    } else if ("9999".equals(identifier)) {
                        comprobante.setTotalOtrosTributos(ComprobanteUtilBean.toBigDecimal(xpath.evaluate("cbc:TaxAmount", nodeItem, XPathConstants.STRING).toString()));
                    }
                }
            }

            tmpObj = xpath.evaluate(nm + "/cac:RequestedMonetaryTotal/cbc:ChargeTotalAmount", doc, XPathConstants.STRING);
            comprobante.setTotalOtrosCargos(tmpObj != null && tmpObj.toString().length() > 0 ? ComprobanteUtilBean.toBigDecimal(tmpObj.toString()) : new BigDecimal(0.00));

            comprobante.setMontoTotalGeneral(ComprobanteUtilBean.toBigDecimal((String) xpath.evaluate(nm + "/cac:RequestedMonetaryTotal/cbc:PayableAmount", doc, XPathConstants.STRING)));

            if (log.isDebugEnabled()) {
                log.debug(">> Step 7 :: Complet� datos de totales de la nota de d�bito.");
            }

        } catch (ServiceException e) {
            log.error(e, e);
            throw e;
        } catch (Exception e) {
            log.error(e, e);
            throw new ServiceException(this, e.getLocalizedMessage());
        }
        return comprobante;
    }

    /**
     * Catalogo de Nro. 01 C�digo de tipo de documento autorizado para efectos
     * tributarios.
     *
     * @param codigo
     * @return
     */
    private String obtenerDescCatalogo01(String codigo) {
        String result = "";
        if ("01".equals(codigo)) {
            result = "FACTURA";
        } else if ("03".equals(codigo)) {
            result = "BOLETA DE VENTA";
        } else if ("07".equals(codigo)) {
            result = "NOTA DE CREDITO";
        } else if ("08".equals(codigo)) {
            result = "NOTA DE DEBITO";
        } else if ("09".equals(codigo)) {
            result = "GUIA DE REMISI�N REMITENTE";
        } else if ("12".equals(codigo)) {
            result = "TICKET DE MAQUINA REGISTRADORA";
        } else if ("31".equals(codigo)) {
            result = "GUIA DE REMISI�N TRANSPORTISTA";
        }
        return result;
    }

    /**
     * Catalogo de Nro. 06 Tipo de Documento de Identificaci�n.
     *
     * @param codigo
     * @return
     */
    private String obtenerDescCatalogo06(String codigo) {
        String result = "";
        if ("06".equals(codigo) || "6".equals(codigo)) {
            result = "RUC";
        } else if ("01".equals(codigo) || "1".equals(codigo)) {
            result = "DNI";
        } else if ("04".equals(codigo) || "4".equals(codigo)) {
            result = "CARNET EXTRANJERIA";
        } else if ("07".equals(codigo) || "7".equals(codigo)) {
            result = "PASAPORTE";
        } else if ("00".equals(codigo) || "0".equals(codigo)) {
            result = "DOC.TRIB.NO.DOM.SIN.RUC";
        }
        return result;
    }

    /**
     * Catalogo de Nro. 10 Tipo de nota de d�bito seg�n motivo.
     *
     * @param codigo
     * @return
     */
    private String obtenerDescCatalogo10(String codigo) {
        String result = "";
        if (codigo.trim().equals("01")) {
            result = "INTERESES POR MORA";
        } else if (codigo.trim().equals("02")) {
            result = "AUMENTO EN EL VALOR";
        } else if (codigo.trim().equals("03")) {
            result = "PENALIDAD";
        }
        return result;
    }

    /**
     * Catalogo de Nro. 12 C�digo del tipo de documentos tributarios de
     * referencia.
     *
     * @param codigo
     * @return
     */
    private String obtenerDescCatalogo12(String codigo) {
        String result = "";
        if (codigo.equals("04")) {
            result = "Ticket de Salida - ENAPU";
        } else if (codigo.equals("05")) {
            result = "C�digo SCOP";
        } else if (codigo.equals("99")) {
            result = "Otros";
        } else if (codigo.equals("01")) {
            result = "Factura � emitida para corregir error en el RUC";
        }
        return result;
    }

    /**
     * Genera comprobante para Notas de D�bito emitidas desde PORTAL SOL.
     *
     * @param doc
     * @param xpath
     * @return
     */
    private ComprobanteBean generaComprobantePortal(Document doc, XPath xpath) {
        ComprobanteBean comprobante = new ComprobanteBean();
        try {
            String nm = this.getMainNodeValue();
            String version = (String) xpath.evaluate(nm + "/cbc:CustomizationID", doc, XPathConstants.STRING);
            if (log.isDebugEnabled()) {
                log.debug(">> Version del documento = " + version);
            }
            if (Double.parseDouble(version) < 2) {
                comprobante = generaComprobantePortalV1(doc, xpath);
            } else if (Double.parseDouble(version) == 2.0) {
                comprobante = generaComprobantePortalV2(doc, xpath);
            } else if (Double.parseDouble(version) == 2.1) {
                comprobante = generaComprobantePortalV3(doc, xpath);
            }
        } catch (ServiceException se) {
            log.error(se, se);
            throw se;
        } catch (Exception e) {
            log.error(e, e);
            throw new ServiceException(this, "Ocurrio un error generando el ComprobanteBean de factura PORTAL.");
        }
        return comprobante;
    }

    /**
     * Genera el ComprobanteBean a partir de la version 1.0 de la estructura del
     * documento XMl.
     *
     * @param doc
     * @param xpath
     * @return
     */
    private ComprobanteBean generaComprobantePortalV1(Document doc, XPath xpath) {
        if (log.isInfoEnabled()) {
            log.info(">> Genera comprobante Nota de d�bito PORTAL");
        }

        ComprobanteBean comprobante = new ComprobanteBean();
        // inicializando en valores  por defecto por ser  numericos

        comprobante.setTotalValorVenta(new BigDecimal(0.00));
        comprobante.setTotalDescuentos(new BigDecimal(0.00));
        comprobante.setTotalIGV(new BigDecimal(0.00));
        comprobante.setTotalISC(new BigDecimal(0.00));
        comprobante.setTotalOtrosCargos(new BigDecimal(0.00));
        comprobante.setTotalOtrosTributos(new BigDecimal(0.00));
        comprobante.setMontoDescuentos(new BigDecimal(0.00));
        comprobante.setMontoImpuestos(new BigDecimal(0.00));
        comprobante.setMontoSubTotal(new BigDecimal(0.00));
        comprobante.setMontoTotalGeneral(new BigDecimal(0.00));

        try {
            String nm = this.getMainNodeValue();
            String id = (String) xpath.evaluate(nm + "/cbc:ID", doc, XPathConstants.STRING);
            log.debug("generaComprobanteBean " + doc);//naa
            log.debug("xpath:" + xpath);//naa
            log.debug("id: " + id);//naa
            log.debug("id pos : " + id.substring(id.indexOf("-")));//naa
            comprobante.setNumeroComprobante(new Integer(id.substring(id.indexOf("-") + 1)));
            comprobante.setSerieComprobante(id.substring(0, id.indexOf("-")));
            comprobante.setNumeroRuc((String) xpath.evaluate(nm + "/cac:AccountingSupplierParty/cbc:CustomerAssignedAccountID", doc, XPathConstants.STRING));

            String tipoNota = (String) xpath.evaluate(nm + "/cac:DiscrepancyResponse/cbc:ResponseCode", doc, XPathConstants.STRING);
            if ("41".equals(tipoNota)) {
                comprobante.setGlosa("Intereses por Mora");
            }
            if ("42".equals(tipoNota)) {
                comprobante.setGlosa("Aumento en el Valor");
            }
            if ("43".equals(tipoNota)) {
                comprobante.setGlosa("Penalidad");
            }

            FechaBean fb = new FechaBean((String) xpath.evaluate(nm + "/cbc:IssueDate", doc, XPathConstants.STRING), "yyyy-MM-dd");
            comprobante.setFechaEmision(fb.getFormatDate("dd/MM/yyyy"));
            fb.setFecha((String) xpath.evaluate(nm + "/cbc:IssueTime", doc, XPathConstants.STRING), "HH:mm:ss");
            comprobante.setHoraEmision(fb.getFormatDate("HH:mm:ss"));
            comprobante.setObservacion((String) xpath.evaluate(nm + "/cbc:Note", doc, XPathConstants.STRING));
            String documoriginal = (String) xpath.evaluate(nm + "/cac:DiscrepancyResponse/cbc:ReferenceID", doc, XPathConstants.STRING);
            comprobante.setSerieDocumentoPorElQueSeEmite((documoriginal.substring(0, documoriginal.indexOf("-"))).trim());
            comprobante.setNumeroDocumentoPorElQueSeEmite((documoriginal.substring(documoriginal.indexOf("-") + 1)).trim());

            //comprobante.set
            log.debug("paso0 ");//naa
            String subtipo = (String) xpath.evaluate(nm + "/cac:DiscrepancyResponse/cbc:ResponseCode", doc, XPathConstants.STRING);
            comprobante.setSubTipoComprobante(subtipo);
            log.debug("VALOR DE  SUBTIPO:" + subtipo);//naa
            //MPCR buscar tag para monto en letras
            //comprobante.setMontoTotalTexto((String)xpath.evaluate(nm + "/cbc:Note", doc, XPathConstants.STRING));

            log.debug("paso1 ");//naa

            String s2 = (String) xpath.evaluate(nm + "/ext:UBLExtensions/ext:UBLExtension/ext:ExtensionContent/sac:AdditionalInformationInvoice/sac:AdditionalInvoiceProperty/cbc:Value", doc, XPathConstants.STRING);
            log.debug(" s2:" + s2);//naa

            // <tr><td><xsl:value-of select="DebitNote/ext:UBLExtensions/ext:UBLExtension/ext:ExtensionContent/sac:AdditionalInformationInvoice/sac:AdditionalInvoiceProperty/cbc:Value"/></td></tr>
            comprobante.setMontoTotalTexto(s2);
            log.debug("saliendo de paso1 ");//naa

            NodeList nlGuias = (NodeList) xpath.evaluate(nm + "/cac:DespatchDocumentReference", doc, XPathConstants.NODESET);
            NodeList nlOtrosDocs = (NodeList) xpath.evaluate(nm + "/cac:AdditionalDocumentReference", doc, XPathConstants.NODESET);
            log.debug("paso2 ");//naa
            if (nlGuias.getLength() > 0 || nlOtrosDocs.getLength() > 0) {

                log.debug("paso3 ");//naa	
                int lengthArray = nlGuias.getLength() + nlOtrosDocs.getLength();
                List<OtroDocumentoRelacionadoBean> aOtrosDocs = new ArrayList<OtroDocumentoRelacionadoBean>();
                OtroDocumentoRelacionadoBean docRel = null;
                log.debug("paso4 ");//naa
                for (int j = 0, x = 0, y = 0; j < lengthArray; j++) {
                    Node nodeItem = (j < nlGuias.getLength() ? (Node) nlGuias.item(x++) : (Node) nlOtrosDocs.item(y++));
                    docRel = new OtroDocumentoRelacionadoBean();
                    docRel.setTipoDocumentoRelacionado((String) xpath.evaluate("cbc:cbc:DocumentTypeCode", nodeItem, XPathConstants.STRING));
                    docRel.setDesTipoDocuRela((String) xpath.evaluate("cbc:DocumentType", nodeItem, XPathConstants.STRING));
                    docRel.setNumeroDocumentoRelacionadoInicial((String) xpath.evaluate("cbc:ID", nodeItem, XPathConstants.STRING));
                    aOtrosDocs.add(docRel);

                }
                log.debug("paso5 ");//naa
                comprobante.setOtroDocumentoRelacionadoBean(aOtrosDocs);
            }
            /**
             * --------------------------------------------------
             */
            log.debug("paso6 ");//naa
//			comprobante.setRazonSocial((String)xpath.evaluate(nm + "/cac:AccountingSupplierParty/cac:Party/cac:PartyName/cbc:Name", doc, XPathConstants.STRING));
            comprobante.setRazonComercial((String) xpath.evaluate(nm + "/cac:AccountingSupplierParty/cac:Party/cac:PartyName/cbc:Name", doc, XPathConstants.STRING));
            comprobante.setRazonSocial((String) xpath.evaluate(nm + "/cac:AccountingSupplierParty/cac:Party/cac:PartyLegalEntity/cbc:RegistrationName", doc, XPathConstants.STRING));

            //comprobante.setUbigeoEmisor((String)xpath.evaluate(nm + "/cac:AccountingSupplierParty/cac:Party/cac:PostalAddress/cbc:ID", doc, XPathConstants.STRING));
            //comprobante.setNombreCalle((String)xpath.evaluate(nm + "/cac:AccountingSupplierParty/cac:Party/cac:PostalAddress/cbc:StreetName", doc, XPathConstants.STRING));
            comprobante.setUbigeoEmisor((String) xpath.evaluate(nm + "/cac:AccountingSupplierParty/cac:Party/cac:RegistrationAddress/cbc:ID", doc, XPathConstants.STRING));
            comprobante.setNombreCalle((String) xpath.evaluate(nm + "/cac:AccountingSupplierParty/cac:Party/cac:PartyLegalEntity/cac:RegistrationAddress/cbc:StreetName", doc, XPathConstants.STRING));
            //	/cac:AccountingSupplierParty/cac:Party/cac:PartyLegalEntity/cac:RegistrationAddress/
            /////comprobante.setNumeroDireccion((String)xpath.evaluate(nm + "/cac:AccountingSupplierParty/cac:Party/cac:PostalAddress/cbc:BuildingNumber", doc, XPathConstants.STRING));
            comprobante.setNombreDistrito((String) xpath.evaluate(nm + "/cac:AccountingSupplierParty/cac:Party/cac:PartyLegalEntity/cac:RegistrationAddress/cbc:District", doc, XPathConstants.STRING));
            comprobante.setNombreProvincia((String) xpath.evaluate(nm + "/cac:AccountingSupplierParty/cac:Party/cac:PartyLegalEntity/cac:RegistrationAddress/cbc:CountrySubentity", doc, XPathConstants.STRING));
            comprobante.setNombreDepartamento((String) xpath.evaluate(nm + "/cac:AccountingSupplierParty/cac:Party/cac:PartyLegalEntity/cac:RegistrationAddress/cbc:CityName", doc, XPathConstants.STRING));
            comprobante.setCodigoPais((String) xpath.evaluate(nm + "/cac:AccountingSupplierParty/cac:Party/cac:PartyLegalEntity/cac:RegistrationAddress/cac:Country/cbc:IdentificationCode", doc, XPathConstants.STRING));

            //	comprobante.setNombreDistrito((String)xpath.evaluate(nm + "/cac:AccountingSupplierParty/cac:Party/cac:PostalAddress/cbc:District", doc, XPathConstants.STRING));
            //comprobante.setNombreProvincia((String)xpath.evaluate(nm + "/cac:AccountingSupplierParty/cac:Party/cac:PostalAddress/cbc:CityName", doc, XPathConstants.STRING));
            //comprobante.setNombreDepartamento((String)xpath.evaluate(nm + "/cac:AccountingSupplierParty/cac:Party/cac:PostalAddress/cbc:CountrySubentity", doc, XPathConstants.STRING));
            //comprobante.setCodigoPais((String)xpath.evaluate(nm + "/cac:AccountingSupplierParty/cac:Party/cac:PostalAddress/cac:Country/cbc:IdentificationCode", doc, XPathConstants.STRING));
            log.debug("paso6_01 ");//naa
            //comprobante.setCodigoEstablecimiento(Short.valueOf((String)xpath.evaluate(nm + "/cac:AccountingSupplierParty/cac:Party/cac:PhysicalLocation/cbc:ID", doc, XPathConstants.STRING)));
            log.debug("paso6_02 ");//naa
            comprobante.setNumeroDocumentoCliente((String) xpath.evaluate(nm + "/cac:AccountingCustomerParty/cbc:CustomerAssignedAccountID", doc, XPathConstants.STRING));
            comprobante.setTipoDocumentoCliente((String) xpath.evaluate(nm + "/cac:AccountingCustomerParty/cbc:AdditionalAccountID", doc, XPathConstants.STRING));
            comprobante.setDesTipoDocumentoCliente(this.obtenerDescCatalogo06(comprobante.getTipoDocumentoCliente()));
            comprobante.setNombreCliente((String) xpath.evaluate(nm + "/cac:AccountingCustomerParty/cac:Party/cac:PartyLegalEntity/cbc:RegistrationName", doc, XPathConstants.STRING));
            //comprobante.setNombreCliente((String)xpath.evaluate(nm + "/cac:AccountingCustomerParty/cac:Party/cac:PartyName/cbc:Name", doc, XPathConstants.STRING));
            log.debug("paso6_1 ");//naa
            //[02:50:49 p.m.] patricia chacaliaza: RequestedMonetaryTotal
            //DEP	comprobante.setTotalValorVenta(ComprobanteUtilBean.toBigDecimal((String)xpath.evaluate(nm + "/cac:LegalMonetaryTotal/cbc:LineExtensionAmount", doc, XPathConstants.STRING)));
            comprobante.setTotalValorVenta(ComprobanteUtilBean.toBigDecimal((String) xpath.evaluate(nm + "/cac:RequestedMonetaryTotal/cbc:LineExtensionAmount", doc, XPathConstants.STRING)));
            log.debug("paso6_2 ");//naa
            //comprobante.setTotalDescuentos(ComprobanteUtilBean.toBigDecimal((String)xpath.evaluate(nm + "/cac:LegalMonetaryTotal/cbc:AllowanceTotalAmount", doc, XPathConstants.STRING)));
            //DEP	comprobante.setTotalDescuentos(ComprobanteUtilBean.toBigDecimal((String)xpath.evaluate(nm + "/cac:LegalMonetaryTotal/cbc:ChargeTotalAmount", doc, XPathConstants.STRING)));
            // NO VA   EN   ND comprobante.setTotalDescuentos(ComprobanteUtilBean.toBigDecimal((String)xpath.evaluate(nm + "/cac:RequestedMonetaryTotal/cbc:ChargeTotalAmount", doc, XPathConstants.STRING)));
            log.debug("paso6_3 ");//naa
            //DEP	comprobante.setMontoTotalGeneral(ComprobanteUtilBean.toBigDecimal((String)xpath.evaluate(nm + "/cac:LegalMonetaryTotal/cbc:PayableAmount", doc, XPathConstants.STRING)));
            comprobante.setMontoTotalGeneral(ComprobanteUtilBean.toBigDecimal((String) xpath.evaluate(nm + "/cac:RequestedMonetaryTotal/cbc:PayableAmount", doc, XPathConstants.STRING)));
            log.debug("paso7 ");//naa
            NodeList nodeOtrosTot = (NodeList) xpath.evaluate(nm + "/cac:TaxTotal/cac:TaxSubtotal", doc, XPathConstants.NODESET);
            log.debug("paso8 ");//naa
            if (nodeOtrosTot.getLength() > 0) {

                String nombre = "";
                String monto = "";
                String porcentaje = "";
                Node nodeItem = null;
                for (int i = 0; i < nodeOtrosTot.getLength(); i++) {
                    nodeItem = (Node) nodeOtrosTot.item(i);
                    log.debug("paso9 ");//naa
                    nombre = (String) xpath.evaluate("cac:TaxCategory/cac:TaxScheme/cbc:Name", nodeItem, XPathConstants.STRING);
                    monto = (String) xpath.evaluate("cbc:TaxAmount", nodeItem, XPathConstants.STRING);
                    porcentaje = (String) xpath.evaluate("cbc:Percent", nodeItem, XPathConstants.STRING);
                    log.debug("nombre:" + nombre + " monto:" + monto + " porcetaje:" + porcentaje);

                    if ("ISC".equals(nombre.trim().toUpperCase())) {
                        comprobante.setTotalISC(ComprobanteUtilBean.toBigDecimal(monto));
                    }
                    if ("IGV".equals(nombre.trim().toUpperCase())) {
                        comprobante.setIgvPorcentaje(ComprobanteUtilBean.toBigDecimal(porcentaje));
                        comprobante.setTotalIGV(ComprobanteUtilBean.toBigDecimal(monto));
                    }
                    if ("OTROS CARGOS".equals(nombre.trim().toUpperCase())) {
                        comprobante.setTotalOtrosCargos(ComprobanteUtilBean.toBigDecimal(monto));
                    }
                    if ("OTROS TRIBUTOS".equals(nombre.trim().toUpperCase())) {
                        comprobante.setTotalOtrosTributos(ComprobanteUtilBean.toBigDecimal(monto));
                    }
                }
            }

            /// DETALLE DE LA NOTA DE CREDITO
            //DEP	comprobante.setCodigoMoneda((String)xpath.evaluate(nm + "/cac:LegalMonetaryTotal/cbc:PayableAmount/@currencyID", doc, XPathConstants.STRING));
            comprobante.setCodigoMoneda((String) xpath.evaluate(nm + "/cac:RequestedMonetaryTotal/cbc:PayableAmount/@currencyID", doc, XPathConstants.STRING));

            NodeList nlItems = (NodeList) xpath.evaluate(nm + "/cac:DebitNoteLine", doc, XPathConstants.NODESET);
            if (nlItems.getLength() > 0) {
                List<DetalleComprobanteBean> aDetalleComprobante = new ArrayList<DetalleComprobanteBean>();
                DetalleComprobanteBean detalle = null;
                for (int i = 0; i < nlItems.getLength(); i++) {
                    log.debug("paso11 ");//naa
                    Node nodeItem = (Node) nlItems.item(i);
                    detalle = new DetalleComprobanteBean();
                    if (i == 0) {
                        // MPCR ya no va, se puso en cbc not de la cabecera
                        //comprobante.setObservacion((String)xpath.evaluate("cbc:Note", nodeItem, XPathConstants.STRING));						 
                    }
                    log.debug("paso11_0001 ");//naa
                    detalle.setIdentificador(Integer.parseInt((String) xpath.evaluate("cbc:ID", nodeItem, XPathConstants.STRING)));
                    log.debug("paso11_0002 ");//naa
                    detalle.setNumeroLinea(Integer.parseInt((String) xpath.evaluate("cbc:ID", nodeItem, XPathConstants.STRING)));
                    detalle.setIdentificadorOriginal(Integer.parseInt((String) xpath.evaluate("cbc:ID", nodeItem, XPathConstants.STRING)));
                    log.debug("paso11_1 ");//naa

                    detalle.setTotalImpuestos("0"); //  PARA  preguntar por este campo en la pagina jsp
                    String varTaxAmount = null;
                    varTaxAmount = (String) xpath.evaluate("cac:TaxTotal/cbc:TaxAmount", nodeItem, XPathConstants.STRING);
                    detalle.setUnidadMedida("-");
                    detalle.setCodigoItem("-");
                    detalle.setCantidad("-");
                    if (varTaxAmount != null && !varTaxAmount.trim().equals("")) { // TODOS LOS DATOS

                        detalle.setCantidad(ComprobanteUtilBean.formatTwoDecimal((String) xpath.evaluate("cbc:DebitedQuantity", nodeItem, XPathConstants.STRING)));
                        log.debug("paso11_2_1_T ");//naa
                        detalle.setUnidadMedida((String) xpath.evaluate("cbc:DebitedQuantity/@unitCode", nodeItem, XPathConstants.STRING));
                        log.debug("paso11_2_2_T ");//naa
                        detalle.setCodigoItem((String) xpath.evaluate("cac:Item/cac:CatalogueDocumentReference/cbc:ID", nodeItem, XPathConstants.STRING));
                        if (detalle.getCodigoItem() == null) {
                            detalle.setCodigoItem("");
                        }
                        log.debug("paso11_2_3_T ");//naa
                        detalle.setDescripcion((String) xpath.evaluate("cac:Item/cbc:Description", nodeItem, XPathConstants.STRING));
                        log.debug("paso11_2_4_T ");//naa
                        detalle.setPrecioUnitario(ComprobanteUtilBean.formatTwoDecimal((String) xpath.evaluate("cac:Price/cbc:PriceAmount", nodeItem, XPathConstants.STRING)));
                        log.debug("paso11_3_T");//naa	
                    } else { //  SOLO DESCRIPCION
                        log.debug("paso11_2_DESC ");//naa
                        detalle.setDescripcion((String) xpath.evaluate("cac:Item/cbc:Description", nodeItem, XPathConstants.STRING));
                        log.debug("paso11_2_1_DESC ");//naa
                        detalle.setPrecioUnitario(ComprobanteUtilBean.formatTwoDecimal((String) xpath.evaluate("cac:Price/cbc:PriceAmount", nodeItem, XPathConstants.STRING)));
                        log.debug("paso11_3_DESC");//naa	
                    }

                    aDetalleComprobante.add(detalle);
                }

                comprobante.setDetalleComprobanteBean(aDetalleComprobante);
                log.debug("paso13 ");//naa
            }

        } catch (ServiceException e) {
            log.error(e);
            e.printStackTrace();
            log.error(e.getLocalizedMessage());
            throw e;
        } catch (Exception e) {
            log.error(e);
            e.printStackTrace();
            throw new ServiceException(this, e.getLocalizedMessage());
        }
        return comprobante;
    }

    /**
     * Genera el ComprobanteBean a partir de la version 2.0 de la estructura del
     * documento XMl.
     *
     * @param doc
     * @param xpath
     * @return
     */
    private ComprobanteBean generaComprobantePortalV2(Document doc, XPath xpath) {
        if (log.isInfoEnabled()) {
            log.info(">> Genera comprobante Nota de d�bito PORTAL");
        }
        ComprobanteBean comprobante = new ComprobanteBean();
        // inicializando en valores  por defecto por ser  numericos

        comprobante.setTotalValorVenta(new BigDecimal(0.00));
        comprobante.setTotalDescuentos(new BigDecimal(0.00));
        comprobante.setTotalIGV(new BigDecimal(0.00));
        comprobante.setTotalISC(new BigDecimal(0.00));
        comprobante.setTotalOtrosCargos(new BigDecimal(0.00));
        comprobante.setTotalOtrosTributos(new BigDecimal(0.00));
        comprobante.setMontoDescuentos(new BigDecimal(0.00));
        comprobante.setMontoImpuestos(new BigDecimal(0.00));
        comprobante.setMontoSubTotal(new BigDecimal(0.00));
        comprobante.setMontoTotalGeneral(new BigDecimal(0.00));

        try {
            Object tmpObj = null;
            Node nodeItem = null;
            String identifier = "";
            String nm = this.getMainNodeValue();
            String id = (String) xpath.evaluate(nm + "/cbc:ID", doc, XPathConstants.STRING);
            log.debug("generaComprobanteBean " + doc);//naa
            log.debug("xpath:" + xpath);//naa
            log.debug("id: " + id);//naa
            log.debug("id pos : " + id.substring(id.indexOf("-")));//naa
            comprobante.setNumeroComprobante(new Integer(id.substring(id.indexOf("-") + 1)));
            comprobante.setSerieComprobante(id.substring(0, id.indexOf("-")));
            comprobante.setNumeroRuc((String) xpath.evaluate(nm + "/cac:AccountingSupplierParty/cbc:CustomerAssignedAccountID", doc, XPathConstants.STRING));

            //PAS20175E210300040 FacturaNotaDebito Penalidad
            FechaBean fb = null;
            if (xpath.evaluate(nm + "/cbc:IssueDate", doc, XPathConstants.STRING) != null) {
                fb = new FechaBean((String) xpath.evaluate(nm + "/cbc:IssueDate", doc, XPathConstants.STRING), "yyyy-MM-dd");
                comprobante.setFechaEmision(fb.getFormatDate("dd/MM/yyyy"));
            }
            if (xpath.evaluate(nm + "/cbc:IssueTime", doc, XPathConstants.STRING) != null
                    && !((String) xpath.evaluate(nm + "/cbc:IssueTime", doc, XPathConstants.STRING)).equals("")) {
                fb.setFecha((String) xpath.evaluate(nm + "/cbc:IssueTime", doc, XPathConstants.STRING), "HH:mm:ss");
                comprobante.setHoraEmision(fb.getFormatDate("HH:mm:ss"));
            }

            if (xpath.evaluate(nm + "/cbc:Note/@languageLocaleID", doc, XPathConstants.STRING) == null) {
                if (!((String) xpath.evaluate(nm + "/cbc:Note", doc, XPathConstants.STRING)).equals("")) {
                    comprobante.setObservacion((String) xpath.evaluate(nm + "/cbc:Note", doc, XPathConstants.STRING));
                    log.debug("@languageLocaleID:" + comprobante.getObservacion());
                }
            }
			
            String documoriginal = (String) xpath.evaluate(nm + "/cac:DiscrepancyResponse/cbc:ReferenceID", doc, XPathConstants.STRING);
            comprobante.setSerieDocumentoPorElQueSeEmite((documoriginal.substring(0, documoriginal.indexOf("-"))).trim());
            comprobante.setNumeroDocumentoPorElQueSeEmite((documoriginal.substring(documoriginal.indexOf("-") + 1)).trim());

            //comprobante.set
            log.debug("paso0 ");//naa
            String subtipo = (String) xpath.evaluate(nm + "/cac:DiscrepancyResponse/cbc:ResponseCode", doc, XPathConstants.STRING);
            String subtipoTemp = subtipo;
            if ("01".equals(subtipo)) {
                subtipo = "41";
            }
            if ("02".equals(subtipo)) {
                subtipo = "42";
            }
            if ("03".equals(subtipo)) {
                subtipo = "43";
            }
            comprobante.setSubTipoComprobante(subtipo);
            comprobante.setGlosa(obtenerDescCatalogo10(subtipoTemp));
            log.debug("VALOR DE  SUBTIPO:" + subtipo);//naa
            //MPCR buscar tag para monto en letras
            //comprobante.setMontoTotalTexto((String)xpath.evaluate(nm + "/cbc:Note", doc, XPathConstants.STRING));

            log.debug("paso1 ");//naa

            //String s2 = (String)xpath.evaluate(nm + "/ext:UBLExtensions/ext:UBLExtension/ext:ExtensionContent/sac:AdditionalInformationInvoice/sac:AdditionalInvoiceProperty/cbc:Value", doc, XPathConstants.STRING);
            String s2 = (String) xpath.evaluate(nm + "/ext:UBLExtensions/ext:UBLExtension/ext:ExtensionContent/sac:AdditionalInformation/sac:AdditionalProperty/cbc:Value", doc, XPathConstants.STRING);
            log.debug(" s2:" + s2);//naa

            // <tr><td><xsl:value-of select="DebitNote/ext:UBLExtensions/ext:UBLExtension/ext:ExtensionContent/sac:AdditionalInformationInvoice/sac:AdditionalInvoiceProperty/cbc:Value"/></td></tr>
            comprobante.setMontoTotalTexto(s2);
            log.debug("saliendo de paso1 ");//naa

            NodeList nlGuias = (NodeList) xpath.evaluate(nm + "/cac:DespatchDocumentReference", doc, XPathConstants.NODESET);
            NodeList nlOtrosDocs = (NodeList) xpath.evaluate(nm + "/cac:AdditionalDocumentReference", doc, XPathConstants.NODESET);
            log.debug("paso2 ");//naa
            if (nlGuias.getLength() > 0 || nlOtrosDocs.getLength() > 0) {

                log.debug("paso3 ");//naa	
                int lengthArray = nlGuias.getLength() + nlOtrosDocs.getLength();
                List<OtroDocumentoRelacionadoBean> aOtrosDocs = new ArrayList<OtroDocumentoRelacionadoBean>();
                OtroDocumentoRelacionadoBean docRel = null;
                log.debug("paso4 ");//naa
                for (int j = 0, x = 0, y = 0; j < lengthArray; j++) {
                    nodeItem = (j < nlGuias.getLength() ? (Node) nlGuias.item(x++) : (Node) nlOtrosDocs.item(y++));
                    docRel = new OtroDocumentoRelacionadoBean();
                    docRel.setTipoDocumentoRelacionado((String) xpath.evaluate("cbc:cbc:DocumentTypeCode", nodeItem, XPathConstants.STRING));
                    docRel.setDesTipoDocuRela((String) xpath.evaluate("cbc:DocumentType", nodeItem, XPathConstants.STRING));
                    docRel.setNumeroDocumentoRelacionadoInicial((String) xpath.evaluate("cbc:ID", nodeItem, XPathConstants.STRING));
                    aOtrosDocs.add(docRel);

                }
                log.debug("paso5 ");//naa
                comprobante.setOtroDocumentoRelacionadoBean(aOtrosDocs);
            }
            /**
             * --------------------------------------------------
             */
            log.debug("paso6 ");//naa
//			comprobante.setRazonSocial((String)xpath.evaluate(nm + "/cac:AccountingSupplierParty/cac:Party/cac:PartyName/cbc:Name", doc, XPathConstants.STRING));
            comprobante.setRazonComercial((String) xpath.evaluate(nm + "/cac:AccountingSupplierParty/cac:Party/cac:PartyName/cbc:Name", doc, XPathConstants.STRING));
            comprobante.setRazonSocial((String) xpath.evaluate(nm + "/cac:AccountingSupplierParty/cac:Party/cac:PartyLegalEntity/cbc:RegistrationName", doc, XPathConstants.STRING));

            //comprobante.setUbigeoEmisor((String)xpath.evaluate(nm + "/cac:AccountingSupplierParty/cac:Party/cac:PostalAddress/cbc:ID", doc, XPathConstants.STRING));
            //comprobante.setNombreCalle((String)xpath.evaluate(nm + "/cac:AccountingSupplierParty/cac:Party/cac:PostalAddress/cbc:StreetName", doc, XPathConstants.STRING));
            comprobante.setUbigeoEmisor((String) xpath.evaluate(nm + "/cac:AccountingSupplierParty/cac:Party/cac:PostalAddress/cbc:ID", doc, XPathConstants.STRING));
            comprobante.setNombreCalle((String) xpath.evaluate(nm + "/cac:AccountingSupplierParty/cac:Party/cac:PostalAddress/cbc:StreetName", doc, XPathConstants.STRING));
            //	/cac:AccountingSupplierParty/cac:Party/cac:PartyLegalEntity/cac:RegistrationAddress/
            /////comprobante.setNumeroDireccion((String)xpath.evaluate(nm + "/cac:AccountingSupplierParty/cac:Party/cac:PostalAddress/cbc:BuildingNumber", doc, XPathConstants.STRING));
            comprobante.setNombreDistrito((String) xpath.evaluate(nm + "/cac:AccountingSupplierParty/cac:Party/cac:PostalAddress/cbc:District", doc, XPathConstants.STRING));
            comprobante.setNombreProvincia((String) xpath.evaluate(nm + "/cac:AccountingSupplierParty/cac:Party/cac:PostalAddress/cbc:CountrySubentity", doc, XPathConstants.STRING));
            comprobante.setNombreDepartamento((String) xpath.evaluate(nm + "/cac:AccountingSupplierParty/cac:Party/cac:PostalAddress/cbc:CityName", doc, XPathConstants.STRING));
            comprobante.setCodigoPais((String) xpath.evaluate(nm + "/cac:AccountingSupplierParty/cac:Party/cac:PostalAddress/cac:Country/cbc:IdentificationCode", doc, XPathConstants.STRING));

            log.debug("paso6_01 ");//naa
            //comprobante.setCodigoEstablecimiento(Short.valueOf((String)xpath.evaluate(nm + "/cac:AccountingSupplierParty/cac:Party/cac:PhysicalLocation/cbc:ID", doc, XPathConstants.STRING)));
            log.debug("paso6_02 ");//naa
            comprobante.setNumeroDocumentoCliente((String) xpath.evaluate(nm + "/cac:AccountingCustomerParty/cbc:CustomerAssignedAccountID", doc, XPathConstants.STRING));
            comprobante.setTipoDocumentoCliente((String) xpath.evaluate(nm + "/cac:AccountingCustomerParty/cbc:AdditionalAccountID", doc, XPathConstants.STRING));
            String descdoc = "-";
            if ("06".equals(comprobante.getTipoDocumentoCliente()) || "6".equals(comprobante.getTipoDocumentoCliente())) {
                descdoc = "RUC";
            } else if ("01".equals(comprobante.getTipoDocumentoCliente()) || "1".equals(comprobante.getTipoDocumentoCliente())) {
                descdoc = "DNI";
            } else if ("04".equals(comprobante.getTipoDocumentoCliente()) || "4".equals(comprobante.getTipoDocumentoCliente())) {
                descdoc = "CARNET EXTRANJERIA";
            } else if ("07".equals(comprobante.getTipoDocumentoCliente()) || "7".equals(comprobante.getTipoDocumentoCliente())) {
                descdoc = "PASAPORTE";
            }
            comprobante.setDesTipoDocumentoCliente(descdoc);
            comprobante.setNombreCliente((String) xpath.evaluate(nm + "/cac:AccountingCustomerParty/cac:Party/cac:PartyLegalEntity/cbc:RegistrationName", doc, XPathConstants.STRING));
            //comprobante.setNombreCliente((String)xpath.evaluate(nm + "/cac:AccountingCustomerParty/cac:Party/cac:PartyName/cbc:Name", doc, XPathConstants.STRING));
            log.debug("paso6_1 ");//naa
            //[02:50:49 p.m.] patricia chacaliaza: RequestedMonetaryTotal
            //DEP	comprobante.setTotalValorVenta(ComprobanteUtilBean.toBigDecimal((String)xpath.evaluate(nm + "/cac:LegalMonetaryTotal/cbc:LineExtensionAmount", doc, XPathConstants.STRING)));
            comprobante.setTotalValorVenta(ComprobanteUtilBean.toBigDecimal((String) xpath.evaluate(nm + "/cac:RequestedMonetaryTotal/cbc:LineExtensionAmount", doc, XPathConstants.STRING)));
            log.debug("paso6_2 ");//naa
            //comprobante.setTotalDescuentos(ComprobanteUtilBean.toBigDecimal((String)xpath.evaluate(nm + "/cac:LegalMonetaryTotal/cbc:AllowanceTotalAmount", doc, XPathConstants.STRING)));
            //DEP	comprobante.setTotalDescuentos(ComprobanteUtilBean.toBigDecimal((String)xpath.evaluate(nm + "/cac:LegalMonetaryTotal/cbc:ChargeTotalAmount", doc, XPathConstants.STRING)));
            // NO VA   EN   ND comprobante.setTotalDescuentos(ComprobanteUtilBean.toBigDecimal((String)xpath.evaluate(nm + "/cac:RequestedMonetaryTotal/cbc:ChargeTotalAmount", doc, XPathConstants.STRING)));
            log.debug("paso6_3 ");//naa
            //DEP	comprobante.setMontoTotalGeneral(ComprobanteUtilBean.toBigDecimal((String)xpath.evaluate(nm + "/cac:LegalMonetaryTotal/cbc:PayableAmount", doc, XPathConstants.STRING)));
            comprobante.setMontoTotalGeneral(ComprobanteUtilBean.toBigDecimal((String) xpath.evaluate(nm + "/cac:RequestedMonetaryTotal/cbc:PayableAmount", doc, XPathConstants.STRING)));
            log.debug("paso7 ");//naa

            if (!xpath.evaluate(nm + "/cac:LegalMonetaryTotal/cbc:ChargeTotalAmount", doc, XPathConstants.STRING).equals("")) {
                comprobante.setTotalOtrosCargos(ComprobanteUtilBean.toBigDecimal((String) xpath.evaluate(nm + "/cac:LegalMonetaryTotal/cbc:ChargeTotalAmount", doc, XPathConstants.STRING)));
            }
            NodeList totalesOtros = (NodeList) xpath.evaluate(nm + "/cac:TaxTotal/cac:TaxSubtotal", doc, XPathConstants.NODESET);
            if (totalesOtros.getLength() > 0) {
                for (int i = 0; i < totalesOtros.getLength(); i++) {
                    nodeItem = (Node) totalesOtros.item(i);
                    identifier = xpath.evaluate("cac:TaxCategory/cac:TaxScheme/cbc:ID", nodeItem, XPathConstants.STRING).toString();
                    if ("1000".equals(identifier)) {
                        comprobante.setTotalIGV(ComprobanteUtilBean.toBigDecimal(xpath.evaluate("cbc:TaxAmount", nodeItem, XPathConstants.STRING).toString()));
                    } else if ("2000".equals(identifier)) {
                        comprobante.setTotalISC(ComprobanteUtilBean.toBigDecimal(xpath.evaluate("cbc:TaxAmount", nodeItem, XPathConstants.STRING).toString()));
                    } else if ("9999".equals(identifier)) {
                        comprobante.setTotalOtrosTributos(ComprobanteUtilBean.toBigDecimal(xpath.evaluate("cbc:TaxAmount", nodeItem, XPathConstants.STRING).toString()));
                    }
                }
            }

            /// DETALLE DE LA NOTA DE CREDITO
            //DEP	comprobante.setCodigoMoneda((String)xpath.evaluate(nm + "/cac:LegalMonetaryTotal/cbc:PayableAmount/@currencyID", doc, XPathConstants.STRING));
            comprobante.setCodigoMoneda((String) xpath.evaluate(nm + "/cac:RequestedMonetaryTotal/cbc:PayableAmount/@currencyID", doc, XPathConstants.STRING));

            NodeList nlItems = (NodeList) xpath.evaluate(nm + "/cac:DebitNoteLine", doc, XPathConstants.NODESET);
            if (nlItems.getLength() > 0) {
                List<DetalleComprobanteBean> aDetalleComprobante = new ArrayList<DetalleComprobanteBean>();
                DetalleComprobanteBean detalle = null;
                for (int i = 0; i < nlItems.getLength(); i++) {
                    log.debug("paso11 ");//naa
                    nodeItem = (Node) nlItems.item(i);
                    detalle = new DetalleComprobanteBean();
                    if (i == 0) {
                        // MPCR ya no va, se puso en cbc not de la cabecera
                        //comprobante.setObservacion((String)xpath.evaluate("cbc:Note", nodeItem, XPathConstants.STRING));						 
                    }
                    log.debug("paso11_0001 ");//naa
                    detalle.setIdentificador(Integer.parseInt((String) xpath.evaluate("cbc:ID", nodeItem, XPathConstants.STRING)));
                    log.debug("paso11_0002 ");//naa
                    detalle.setNumeroLinea(Integer.parseInt((String) xpath.evaluate("cbc:ID", nodeItem, XPathConstants.STRING)));
                    detalle.setIdentificadorOriginal(Integer.parseInt((String) xpath.evaluate("cbc:ID", nodeItem, XPathConstants.STRING)));
                    log.debug("paso11_1 ");//naa

                    detalle.setTotalImpuestos("0"); //  PARA  preguntar por este campo en la pagina jsp
                    String varTaxAmount = null;
                    varTaxAmount = (String) xpath.evaluate("cac:TaxTotal/cbc:TaxAmount", nodeItem, XPathConstants.STRING);
                    detalle.setUnidadMedida("-");
                    detalle.setCodigoItem("-");
                    detalle.setCantidad("-");
                    if (varTaxAmount != null && !varTaxAmount.trim().equals("")) { // TODOS LOS DATOS

                        //detalle.setCantidad((String)xpath.evaluate("cbc:DebitedQuantity", nodeItem, XPathConstants.STRING));
                        if (((String) xpath.evaluate("cbc:DebitedQuantity", nodeItem, XPathConstants.STRING)).equals("$util.formatTenDecimal($dc.getCantidad())")) {
                            detalle.setCantidad("1.00");
                        } else {
                            detalle.setCantidad((String) xpath.evaluate("cbc:DebitedQuantity", nodeItem, XPathConstants.STRING));
                        }
                        log.debug("paso11_2_1_T ");//naa
                        detalle.setUnidadMedida((String) xpath.evaluate("cbc:DebitedQuantity/@unitCode", nodeItem, XPathConstants.STRING));
                        log.debug("paso11_2_2_T ");//naa
                        detalle.setCodigoItem((String) xpath.evaluate("cac:Item/cac:CatalogueDocumentReference/cbc:ID", nodeItem, XPathConstants.STRING));
                        if (detalle.getCodigoItem() == null) {
                            detalle.setCodigoItem("");
                        }
                        log.debug("paso11_2_3_T ");//naa
                        detalle.setDescripcion((String) xpath.evaluate("cac:Item/cbc:Description", nodeItem, XPathConstants.STRING));
                        log.debug("paso11_2_4_T ");//naa
                        //detalle.setPrecioUnitario((String)xpath.evaluate("cac:Price/cbc:PriceAmount", nodeItem, XPathConstants.STRING));
                        if (((String) xpath.evaluate("cac:Price/cbc:PriceAmount", nodeItem, XPathConstants.STRING)).equals("$util.formatTenDecimal($dc.getPrecioUnitario())")) {
                            detalle.setValorVtaUnitario(detalle.getImporteVenta());
                            detalle.setPrecioUnitario(detalle.getImporteVenta());
                        } else {
                            detalle.setValorVtaUnitario((String) xpath.evaluate("cac:Price/cbc:PriceAmount", nodeItem, XPathConstants.STRING));
                            detalle.setPrecioUnitario((String) xpath.evaluate("cac:Price/cbc:PriceAmount", nodeItem, XPathConstants.STRING));
                        }
                        log.debug("paso11_3_T");//naa	
                    } else { //  SOLO DESCRIPCION
                        log.debug("paso11_2_DESC ");//naa
                        detalle.setDescripcion((String) xpath.evaluate("cac:Item/cbc:Description", nodeItem, XPathConstants.STRING));
                        log.debug("paso11_2_1_DESC ");//naa
                        detalle.setPrecioUnitario((String) xpath.evaluate("cac:Price/cbc:PriceAmount", nodeItem, XPathConstants.STRING));
                        log.debug("paso11_3_DESC");//naa	
                    }

                    aDetalleComprobante.add(detalle);
                }

                comprobante.setDetalleComprobanteBean(aDetalleComprobante);
                log.debug("paso13 ");//naa
            }

        } catch (ServiceException e) {
            log.error(e, e);
            e.printStackTrace();
            log.error(e.getLocalizedMessage());
            throw e;
        } catch (Exception e) {
            log.error(e, e);
            e.printStackTrace();
            throw new ServiceException(this, e.getLocalizedMessage());
        }
        return comprobante;
    }

    /**
     * Genera el ComprobanteBean a partir de la version 3.0 de la estructura del
     * documento XMl.
     *
     * @param doc
     * @param xpath
     * @return
     */
    private ComprobanteBean generaComprobantePortalV3(Document doc, XPath xpath) {
        if (log.isInfoEnabled()) {
            log.info(">> Genera comprobante Nota de d�bito PORTAL");
        }
        ComprobanteBean comprobante = new ComprobanteBean();
        // inicializando en valores  por defecto por ser  numericos

        comprobante.setTotalValorVenta(new BigDecimal(0.00));
        comprobante.setTotalDescuentos(new BigDecimal(0.00));
        comprobante.setTotalIGV(new BigDecimal(0.00));
        comprobante.setTotalISC(new BigDecimal(0.00));
        comprobante.setTotalOtrosCargos(new BigDecimal(0.00));
        comprobante.setTotalOtrosTributos(new BigDecimal(0.00));
        comprobante.setMontoDescuentos(new BigDecimal(0.00));
        comprobante.setMontoImpuestos(new BigDecimal(0.00));
        comprobante.setMontoSubTotal(new BigDecimal(0.00));
        comprobante.setMontoTotalGeneral(new BigDecimal(0.00));

        try {
            Object tmpObj = null;
            Node nodeItem = null;
            String identifier = "";
            String nm = this.getMainNodeValue();
            String id = (String) xpath.evaluate(nm + "/cbc:ID", doc, XPathConstants.STRING);
            log.debug("generaComprobanteBean " + doc);//naa
            log.debug("xpath:" + xpath);//naa
            log.debug("id: " + id);//naa
            log.debug("id pos : " + id.substring(id.indexOf("-")));//naa
            comprobante.setNumeroComprobante(new Integer(id.substring(id.indexOf("-") + 1)));
            comprobante.setSerieComprobante(id.substring(0, id.indexOf("-")));
            comprobante.setNumeroRuc((String) xpath.evaluate(nm + "/cac:AccountingSupplierParty/cac:Party/cac:PartyIdentification/cbc:ID", doc, XPathConstants.STRING));

            //PAS20175E210300040 FacturaNotaDebito Penalidad
            FechaBean fb = null;
            if (xpath.evaluate(nm + "/cbc:IssueDate", doc, XPathConstants.STRING) != null) {
                fb = new FechaBean((String) xpath.evaluate(nm + "/cbc:IssueDate", doc, XPathConstants.STRING), "yyyy-MM-dd");
                comprobante.setFechaEmision(fb.getFormatDate("dd/MM/yyyy"));
            }
            if (xpath.evaluate(nm + "/cbc:IssueTime", doc, XPathConstants.STRING) != null
                    && !((String) xpath.evaluate(nm + "/cbc:IssueTime", doc, XPathConstants.STRING)).equals("")) {
                fb.setFecha((String) xpath.evaluate(nm + "/cbc:IssueTime", doc, XPathConstants.STRING), "HH:mm:ss");
                comprobante.setHoraEmision(fb.getFormatDate("HH:mm:ss"));
            }

            tmpObj = xpath.evaluate(nm + "/cbc:Note[not(@*)]", doc, XPathConstants.STRING);
            comprobante.setObservacion(tmpObj != null && tmpObj.toString().length() > 0 ? tmpObj.toString() : "");

            String documoriginal = (String) xpath.evaluate(nm + "/cac:DiscrepancyResponse/cbc:ReferenceID", doc, XPathConstants.STRING);
            comprobante.setSerieDocumentoPorElQueSeEmite((documoriginal.substring(0, documoriginal.indexOf("-"))).trim());
            comprobante.setNumeroDocumentoPorElQueSeEmite((documoriginal.substring(documoriginal.indexOf("-") + 1)).trim());

            //comprobante.set
            log.debug("paso0 ");//naa
            String subtipo = (String) xpath.evaluate(nm + "/cac:DiscrepancyResponse/cbc:ResponseCode", doc, XPathConstants.STRING);
            String subtipoTemp = subtipo;
            if ("01".equals(subtipo)) {
                subtipo = "41";
            }
            if ("02".equals(subtipo)) {
                subtipo = "42";
            }
            if ("03".equals(subtipo)) {
                subtipo = "43";
            }
            comprobante.setSubTipoComprobante(subtipo);
            comprobante.setGlosa(obtenerDescCatalogo10(subtipoTemp));
            log.debug("VALOR DE  SUBTIPO:" + subtipo);//naa
            //MPCR buscar tag para monto en letras
            //comprobante.setMontoTotalTexto((String)xpath.evaluate(nm + "/cbc:Note", doc, XPathConstants.STRING));

            log.debug("paso1 ");//naa

            //String s2 = (String)xpath.evaluate(nm + "/ext:UBLExtensions/ext:UBLExtension/ext:ExtensionContent/sac:AdditionalInformationInvoice/sac:AdditionalInvoiceProperty/cbc:Value", doc, XPathConstants.STRING);
            String s2 = (String) xpath.evaluate(nm + "/cbc:Note[@languageLocaleID='1000']", doc, XPathConstants.STRING);
            log.debug(" s2:" + s2);//naa

            // <tr><td><xsl:value-of select="DebitNote/ext:UBLExtensions/ext:UBLExtension/ext:ExtensionContent/sac:AdditionalInformationInvoice/sac:AdditionalInvoiceProperty/cbc:Value"/></td></tr>
            comprobante.setMontoTotalTexto(s2);
            log.debug("saliendo de paso1 ");//naa

            NodeList nlGuias = (NodeList) xpath.evaluate(nm + "/cac:DespatchDocumentReference", doc, XPathConstants.NODESET);
            NodeList nlOtrosDocs = (NodeList) xpath.evaluate(nm + "/cac:AdditionalDocumentReference", doc, XPathConstants.NODESET);
            log.debug("paso2 ");//naa
            if (nlGuias.getLength() > 0 || nlOtrosDocs.getLength() > 0) {

                log.debug("paso3 ");//naa	
                int lengthArray = nlGuias.getLength() + nlOtrosDocs.getLength();
                List<OtroDocumentoRelacionadoBean> aOtrosDocs = new ArrayList<OtroDocumentoRelacionadoBean>();
                OtroDocumentoRelacionadoBean docRel = null;
                log.debug("paso4 ");//naa
                for (int j = 0, x = 0, y = 0; j < lengthArray; j++) {
                    nodeItem = (j < nlGuias.getLength() ? (Node) nlGuias.item(x++) : (Node) nlOtrosDocs.item(y++));
                    docRel = new OtroDocumentoRelacionadoBean();
                    docRel.setTipoDocumentoRelacionado((String) xpath.evaluate("cbc:cbc:DocumentTypeCode", nodeItem, XPathConstants.STRING));
                    docRel.setDesTipoDocuRela((String) xpath.evaluate("cbc:DocumentType", nodeItem, XPathConstants.STRING));
                    docRel.setNumeroDocumentoRelacionadoInicial((String) xpath.evaluate("cbc:ID", nodeItem, XPathConstants.STRING));
                    aOtrosDocs.add(docRel);

                }
                log.debug("paso5 ");//naa
                comprobante.setOtroDocumentoRelacionadoBean(aOtrosDocs);
            }
            /**
             * --------------------------------------------------
             */
            log.debug("paso6 ");//naa
//			comprobante.setRazonSocial((String)xpath.evaluate(nm + "/cac:AccountingSupplierParty/cac:Party/cac:PartyName/cbc:Name", doc, XPathConstants.STRING));
            comprobante.setRazonComercial((String) xpath.evaluate(nm + "/cac:AccountingSupplierParty/cac:Party/cac:PartyName/cbc:Name", doc, XPathConstants.STRING));
            comprobante.setRazonSocial((String) xpath.evaluate(nm + "/cac:AccountingSupplierParty/cac:Party/cac:PartyLegalEntity/cbc:RegistrationName", doc, XPathConstants.STRING));

            //comprobante.setUbigeoEmisor((String)xpath.evaluate(nm + "/cac:AccountingSupplierParty/cac:Party/cac:PostalAddress/cbc:ID", doc, XPathConstants.STRING));
            //comprobante.setNombreCalle((String)xpath.evaluate(nm + "/cac:AccountingSupplierParty/cac:Party/cac:PostalAddress/cbc:StreetName", doc, XPathConstants.STRING));
            comprobante.setUbigeoEmisor((String) xpath.evaluate(nm + "/cac:AccountingSupplierParty/cac:Party/cac:PartyLegalEntity/cac:RegistrationAddress/cbc:ID", doc, XPathConstants.STRING));
            comprobante.setNombreCalle((String) xpath.evaluate(nm + "/cac:AccountingSupplierParty/cac:Party/cac:PartyLegalEntity/cac:RegistrationAddress/cac:AddressLine/cbc:Line", doc, XPathConstants.STRING));
            //	/cac:AccountingSupplierParty/cac:Party/cac:PartyLegalEntity/cac:RegistrationAddress/
            /////comprobante.setNumeroDireccion((String)xpath.evaluate(nm + "/cac:AccountingSupplierParty/cac:Party/cac:PostalAddress/cbc:BuildingNumber", doc, XPathConstants.STRING));
            comprobante.setNombreDistrito((String) xpath.evaluate(nm + "/cac:AccountingSupplierParty/cac:Party/cac:PartyLegalEntity/cac:RegistrationAddress/cbc:District", doc, XPathConstants.STRING));
            comprobante.setNombreProvincia((String) xpath.evaluate(nm + "/cac:AccountingSupplierParty/cac:Party/cac:PartyLegalEntity/cac:RegistrationAddress/cbc:CountrySubentity", doc, XPathConstants.STRING));
            comprobante.setNombreDepartamento((String) xpath.evaluate(nm + "/cac:AccountingSupplierParty/cac:Party/cac:PartyLegalEntity/cac:RegistrationAddress/cbc:CityName", doc, XPathConstants.STRING));
            comprobante.setCodigoPais((String) xpath.evaluate(nm + "/cac:AccountingSupplierParty/cac:Party/cac:PartyLegalEntity/cac:RegistrationAddress/cac:Country/cbc:IdentificationCode", doc, XPathConstants.STRING));

            log.debug("paso6_01 ");//naa
            //comprobante.setCodigoEstablecimiento(Short.valueOf((String)xpath.evaluate(nm + "/cac:AccountingSupplierParty/cac:Party/cac:PhysicalLocation/cbc:ID", doc, XPathConstants.STRING)));
            log.debug("paso6_02 ");//naa
            comprobante.setNumeroDocumentoCliente((String) xpath.evaluate(nm + "/cac:AccountingCustomerParty/cac:Party/cac:PartyIdentification/cbc:ID", doc, XPathConstants.STRING));
            comprobante.setTipoDocumentoCliente((String) xpath.evaluate(nm + "/cac:AccountingCustomerParty/cac:Party/cac:PartyIdentification/cbc:ID/@schemeID", doc, XPathConstants.STRING));
            String descdoc = "-";
            if ("06".equals(comprobante.getTipoDocumentoCliente()) || "6".equals(comprobante.getTipoDocumentoCliente())) {
                descdoc = "RUC";
            } else if ("01".equals(comprobante.getTipoDocumentoCliente()) || "1".equals(comprobante.getTipoDocumentoCliente())) {
                descdoc = "DNI";
            } else if ("04".equals(comprobante.getTipoDocumentoCliente()) || "4".equals(comprobante.getTipoDocumentoCliente())) {
                descdoc = "CARNET EXTRANJERIA";
            } else if ("07".equals(comprobante.getTipoDocumentoCliente()) || "7".equals(comprobante.getTipoDocumentoCliente())) {
                descdoc = "PASAPORTE";
            }
            comprobante.setDesTipoDocumentoCliente(descdoc);
            comprobante.setNombreCliente((String) xpath.evaluate(nm + "/cac:AccountingCustomerParty/cac:Party/cac:PartyLegalEntity/cbc:RegistrationName", doc, XPathConstants.STRING));
            //comprobante.setNombreCliente((String)xpath.evaluate(nm + "/cac:AccountingCustomerParty/cac:Party/cac:PartyName/cbc:Name", doc, XPathConstants.STRING));
            log.debug("paso6_1 ");//naa
            //[02:50:49 p.m.] patricia chacaliaza: RequestedMonetaryTotal
            //DEP	comprobante.setTotalValorVenta(ComprobanteUtilBean.toBigDecimal((String)xpath.evaluate(nm + "/cac:LegalMonetaryTotal/cbc:LineExtensionAmount", doc, XPathConstants.STRING)));
            comprobante.setTotalValorVenta(ComprobanteUtilBean.toBigDecimal((String) xpath.evaluate(nm + "/cac:RequestedMonetaryTotal/cbc:LineExtensionAmount", doc, XPathConstants.STRING)));
            log.debug("paso6_2 ");//naa
            //comprobante.setTotalDescuentos(ComprobanteUtilBean.toBigDecimal((String)xpath.evaluate(nm + "/cac:LegalMonetaryTotal/cbc:AllowanceTotalAmount", doc, XPathConstants.STRING)));
            //DEP	comprobante.setTotalDescuentos(ComprobanteUtilBean.toBigDecimal((String)xpath.evaluate(nm + "/cac:LegalMonetaryTotal/cbc:ChargeTotalAmount", doc, XPathConstants.STRING)));
            // NO VA   EN   ND comprobante.setTotalDescuentos(ComprobanteUtilBean.toBigDecimal((String)xpath.evaluate(nm + "/cac:RequestedMonetaryTotal/cbc:ChargeTotalAmount", doc, XPathConstants.STRING)));
            log.debug("paso6_3 ");//naa
            //DEP	comprobante.setMontoTotalGeneral(ComprobanteUtilBean.toBigDecimal((String)xpath.evaluate(nm + "/cac:LegalMonetaryTotal/cbc:PayableAmount", doc, XPathConstants.STRING)));
            comprobante.setMontoTotalGeneral(ComprobanteUtilBean.toBigDecimal((String) xpath.evaluate(nm + "/cac:RequestedMonetaryTotal/cbc:PayableAmount", doc, XPathConstants.STRING)));
            log.debug("paso7 ");//naa

            if (!xpath.evaluate(nm + "/cac:RequestedMonetaryTotal/cbc:ChargeTotalAmount", doc, XPathConstants.STRING).equals("")) {
                comprobante.setTotalOtrosCargos(ComprobanteUtilBean.toBigDecimal((String) xpath.evaluate(nm + "/cac:RequestedMonetaryTotal/cbc:ChargeTotalAmount", doc, XPathConstants.STRING)));
            }
            NodeList totalesOtros = (NodeList) xpath.evaluate(nm + "/cac:TaxTotal/cac:TaxSubtotal", doc, XPathConstants.NODESET);
            if (totalesOtros.getLength() > 0) {
                for (int i = 0; i < totalesOtros.getLength(); i++) {
                    nodeItem = (Node) totalesOtros.item(i);
                    identifier = xpath.evaluate("cac:TaxCategory/cac:TaxScheme/cbc:ID", nodeItem, XPathConstants.STRING).toString();
                    if ("1000".equals(identifier)) {
                        comprobante.setTotalIGV(ComprobanteUtilBean.toBigDecimal(xpath.evaluate("cbc:TaxAmount", nodeItem, XPathConstants.STRING).toString()));
                    } else if ("2000".equals(identifier)) {
                        comprobante.setTotalISC(ComprobanteUtilBean.toBigDecimal(xpath.evaluate("cbc:TaxAmount", nodeItem, XPathConstants.STRING).toString()));
                    } else if ("9999".equals(identifier)) {
                        comprobante.setTotalOtrosTributos(ComprobanteUtilBean.toBigDecimal(xpath.evaluate("cbc:TaxAmount", nodeItem, XPathConstants.STRING).toString()));
                    }
                }
            }

            /// DETALLE DE LA NOTA DE CREDITO
            //DEP	comprobante.setCodigoMoneda((String)xpath.evaluate(nm + "/cac:LegalMonetaryTotal/cbc:PayableAmount/@currencyID", doc, XPathConstants.STRING));
            comprobante.setCodigoMoneda((String) xpath.evaluate(nm + "/cac:RequestedMonetaryTotal/cbc:PayableAmount/@currencyID", doc, XPathConstants.STRING));
            //PAS20181U210000122 UBL 2.1 - Cambios x Inicio cambio UBL 2.1
            //comprobante.setTotalSubTotalValorVenta(ComprobanteUtilBean.toBigDecimal((String) xpath.evaluate(nm + "/cac:RequestedMonetaryTotal/cbc:LineExtensionAmount", doc, XPathConstants.STRING)));
            //comprobante.setTotalValorVenta(comprobante.getTotalSubTotalValorVenta());

            // Inicio cambio UBL 2.1
            comprobante.setTotalValorVenta(ComprobanteUtilBean.toBigDecimal((String) xpath.evaluate(nm + "/cac:RequestedMonetaryTotal/cbc:LineExtensionAmount", doc, XPathConstants.STRING)));
            if (!xpath.evaluate(nm + "/cac:RequestedMonetaryTotal/cbc:AllowanceTotalAmount", doc, XPathConstants.STRING).equals("")) {
            	comprobante.setTotalDescuentos(ComprobanteUtilBean.toBigDecimal((String) xpath.evaluate(nm + "/cac:RequestedMonetaryTotal/cbc:AllowanceTotalAmount", doc, XPathConstants.STRING)));
            }           
            comprobante.setTotalSubTotalValorVenta(comprobante.getTotalValorVenta().add(comprobante.getTotalDescuentos())); //.add(comprobante.getTotalAnticipos()));           //OJO - retirar porque debe grabarse el valor
            // Fin cambio UBL 2.1

            NodeList nlItems = (NodeList) xpath.evaluate(nm + "/cac:DebitNoteLine", doc, XPathConstants.NODESET);
            if (nlItems.getLength() > 0) {
                List<DetalleComprobanteBean> aDetalleComprobante = new ArrayList<DetalleComprobanteBean>();
                DetalleComprobanteBean detalle = null;
                for (int i = 0; i < nlItems.getLength(); i++) {
                    log.debug("paso11 ");//naa
                    nodeItem = (Node) nlItems.item(i);
                    detalle = new DetalleComprobanteBean();
                    if (i == 0) {
                        // MPCR ya no va, se puso en cbc not de la cabecera
                        //comprobante.setObservacion((String)xpath.evaluate("cbc:Note", nodeItem, XPathConstants.STRING));						 
                    }
                    log.debug("paso11_0001 ");//naa
                    detalle.setIdentificador(Integer.parseInt((String) xpath.evaluate("cbc:ID", nodeItem, XPathConstants.STRING)));
                    log.debug("paso11_0002 ");//naa
                    detalle.setNumeroLinea(Integer.parseInt((String) xpath.evaluate("cbc:ID", nodeItem, XPathConstants.STRING)));
                    detalle.setIdentificadorOriginal(Integer.parseInt((String) xpath.evaluate("cbc:ID", nodeItem, XPathConstants.STRING)));
                    log.debug("paso11_1 ");//naa

                    detalle.setTotalImpuestos("0"); //  PARA  preguntar por este campo en la pagina jsp
                    String varTaxAmount = null;
                    varTaxAmount = (String) xpath.evaluate("cac:TaxTotal/cbc:TaxAmount", nodeItem, XPathConstants.STRING);
                    detalle.setUnidadMedida("-");
                    detalle.setCodigoItem("-");
                    detalle.setCantidad("-");
                    if (varTaxAmount != null && !varTaxAmount.trim().equals("")) { // TODOS LOS DATOS

                        //detalle.setCantidad((String)xpath.evaluate("cbc:DebitedQuantity", nodeItem, XPathConstants.STRING));
                        if (((String) xpath.evaluate("cbc:DebitedQuantity", nodeItem, XPathConstants.STRING)).equals("$util.formatTenDecimal($dc.getCantidad())")) {
                            detalle.setCantidad("1.00");
                        } else {
                            detalle.setCantidad((String) xpath.evaluate("cbc:DebitedQuantity", nodeItem, XPathConstants.STRING));
                        }
                        log.debug("paso11_2_1_T ");//naa
                        detalle.setUnidadMedida((String) xpath.evaluate("cbc:DebitedQuantity/@unitCode", nodeItem, XPathConstants.STRING));
                        log.debug("paso11_2_2_T ");//naa
                        detalle.setCodigoItem((String) xpath.evaluate("cac:Item/cac:CatalogueDocumentReference/cbc:ID", nodeItem, XPathConstants.STRING));
                        if (detalle.getCodigoItem() == null) {
                            detalle.setCodigoItem("");
                        }
                        log.debug("paso11_2_3_T ");//naa
                        detalle.setDescripcion((String) xpath.evaluate("cac:Item/cbc:Description", nodeItem, XPathConstants.STRING));
                        log.debug("paso11_2_4_T ");//naa
                        //detalle.setPrecioUnitario((String)xpath.evaluate("cac:Price/cbc:PriceAmount", nodeItem, XPathConstants.STRING));
                        if (((String) xpath.evaluate("cac:Price/cbc:PriceAmount", nodeItem, XPathConstants.STRING)).equals("$util.formatTenDecimal($dc.getPrecioUnitario())")) {
                            detalle.setValorVtaUnitario(detalle.getImporteVenta());
                            detalle.setPrecioUnitario(detalle.getImporteVenta());
                        } else {
                            detalle.setValorVtaUnitario((String) xpath.evaluate("cac:Price/cbc:PriceAmount", nodeItem, XPathConstants.STRING));
                            detalle.setPrecioUnitario((String) xpath.evaluate("cac:Price/cbc:PriceAmount", nodeItem, XPathConstants.STRING));
                        }
                        log.debug("paso11_3_T");//naa	
                    } else { //  SOLO DESCRIPCION
                        log.debug("paso11_2_DESC ");//naa
                        detalle.setDescripcion((String) xpath.evaluate("cac:Item/cbc:Description", nodeItem, XPathConstants.STRING));
                        log.debug("paso11_2_1_DESC ");//naa
                        detalle.setPrecioUnitario((String) xpath.evaluate("cac:Price/cbc:PriceAmount", nodeItem, XPathConstants.STRING));
                        log.debug("paso11_3_DESC");//naa	
                    }

                    aDetalleComprobante.add(detalle);
                }

                comprobante.setDetalleComprobanteBean(aDetalleComprobante);
                log.debug("paso13 ");//naa
            }

        } catch (ServiceException e) {
            log.error(e, e);
            e.printStackTrace();
            log.error(e.getLocalizedMessage());
            throw e;
        } catch (Exception e) {
            log.error(e, e);
            e.printStackTrace();
            throw new ServiceException(this, e.getLocalizedMessage());
        }
        return comprobante;
    }

}
