package pe.gob.sunat.servicio2.registro.electronico.comppago.util;

import java.io.File;
import java.io.InputStream;
import java.io.OutputStream;
import java.io.StringReader;
import java.io.StringWriter;
import java.util.Properties;

import javax.xml.XMLConstants;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.transform.Source;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;
import javax.xml.transform.stream.StreamSource;
import javax.xml.validation.Schema;
import javax.xml.validation.SchemaFactory;
import javax.xml.validation.Validator;
import javax.xml.xpath.XPath;
import javax.xml.xpath.XPathFactory;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.apache.velocity.Template;
import org.apache.velocity.VelocityContext;
import org.apache.velocity.app.VelocityEngine;
import org.w3c.dom.Document;
import org.w3c.dom.Node;
import org.xml.sax.InputSource;

import pe.gob.sunat.framework.spring.util.exception.ServiceException;
import pe.gob.sunat.framework.spring.util.date.FechaBean;
import pe.gob.sunat.framework.spring.xml.util.ConfigErrorHandler;
import pe.gob.sunat.servicio2.registro.electronico.comppago.factura.bean.ComprobanteBean;
import pe.gob.sunat.servicio2.registro.electronico.comppago.model.ComprobanteContext;


public class ComprobanteParser {
	protected final Log log = LogFactory.getLog(getClass());
	private Document doc;
	private XPath xPath;
	private ComprobanteContext context;
	private String directorioTemplate;
	private Source schemaSource;
	
	public ComprobanteParser() {}
	
	public ComprobanteParser(ComprobanteContext context) {
		this.context = context;
	}
	
	public void setComprobanteContext(ComprobanteContext context) {
		this.context = context;
		if(this.doc != null) {
			XPathFactory factory = XPathFactory.newInstance();
			this.xPath = factory.newXPath();
			this.xPath.setNamespaceContext(this.context.getNamespaceContext());
		}
	}
	
	public Document getDocument() {
		return this.doc;
	}
	
	public XPath getXPath() {
		return this.xPath;
	}
	
	public Node getNodeToSign() {
		return this.context.getNodeToSign(this.doc, this.xPath); 
	}

	public void setDirectorioTemplate(String directorioTemplate) {
		File dirTempo = new File(directorioTemplate);
		this.directorioTemplate = dirTempo.getAbsolutePath();
	}

	public void setSchemaSource(File schema) {
		this.setSchemaSource(new StreamSource(schema));
	}

	public void setSchemaSource(Source schema) {
		this.schemaSource =  schema;
	}	
	
	public Source getSchemaSource() {
		return this.schemaSource;
	}
	
	public String getSchema() {
		return this.context.getSchema();
	}
	
	public Document parse(InputStream in) {	
		try {
			DocumentBuilderFactory dbf = DocumentBuilderFactory.newInstance();
			dbf.setNamespaceAware(true);
			DocumentBuilder builder = dbf.newDocumentBuilder();
			builder.setErrorHandler(new ConfigErrorHandler());
			doc = builder.parse(new InputSource(in));
			return doc;
		}
		catch(Exception e) {
			e.printStackTrace();
			throw new ServiceException(this, "El Comprobante ingresado no cumple con el estandar establecido.");
		}
	}
	
	public Document parserXml(ComprobanteBean comprobante) {
		try {
			Properties props = new Properties();
			props.setProperty("file.resource.loader.path", this.directorioTemplate);
			
	        VelocityEngine ve = new VelocityEngine();
	        ve.init(props);
	        
	        Template t = ve.getTemplate(this.context.getTemplate());
	        VelocityContext context = new VelocityContext();
	        context.put("cp", comprobante);
	        context.put("util", ComprobanteUtil.class);
	        context.put("fb", new FechaBean(comprobante.getFechaEmision(), "dd/MM/yyyy"));
	        
	        StringWriter writer = new StringWriter();
	        t.merge(context, writer);
	        
			DocumentBuilderFactory dbf = DocumentBuilderFactory.newInstance();
			dbf.setNamespaceAware(true);
			DocumentBuilder db = dbf.newDocumentBuilder();
			InputSource is = new InputSource(new StringReader(writer.toString()));
			this.doc = db.parse(is);
			
			if(this.doc != null) {
				XPathFactory factory = XPathFactory.newInstance();
				this.xPath = factory.newXPath();
				this.xPath.setNamespaceContext(this.context.getNamespaceContext());
			}
			
			return this.doc; 
		}
		catch(ServiceException e) {
			throw e;
		}
		catch(Exception e) {
			throw new ServiceException(this, e);
		}
	}

	/*
	public Document parserXml(ComprobanteBean comprobante) {
		try {
			DocumentBuilderFactory dbf = DocumentBuilderFactory.newInstance();
			dbf.setNamespaceAware(true);
			DocumentBuilder db = dbf.newDocumentBuilder();
			InputStream is = new FileInputStream(this.directorioTemplate + "/" +this.context.getTemplate());
			this.doc = db.parse(is);
			
			if(this.doc != null) {
				XPathFactory factory = XPathFactory.newInstance();
				this.xPath = factory.newXPath();
				this.xPath.setNamespaceContext(this.context.getNamespaceContext());
				this.context.generaXml(this.doc, this.xPath, comprobante);
			}
			return this.doc; 
		}
		catch(ServiceException e) {
			throw e;
		}
		catch(Exception e) {
			throw new ServiceException(this, e);
		}
	}
	
	*/
	
	public void validate() {
		if(this.getSchemaSource() == null)
			throw new ServiceException(this, "Se tiene que asignar un SchemaSource a ParseContext");
		this.validate(this.getSchemaSource());
	}
	
	public void validate(Source schemaSource) {
		if(context == null) throw new ServiceException(this, "No se asigno un ParserContext para el documento");
		
		try {
			SchemaFactory factory = SchemaFactory.newInstance(XMLConstants.W3C_XML_SCHEMA_NS_URI);
			Schema schema = factory.newSchema(schemaSource);
			Validator validator = schema.newValidator();
			validator.validate(new DOMSource(this.doc));
		}
		catch(Exception e) {
			e.printStackTrace();
			throw new ServiceException(this, "El Documento Electr�nico ingresado no cumple con el estandar establecido.");
		}
	}
	
	public void generaArchivoXml(OutputStream out) {
		try {
			DOMSource source = new DOMSource(this.doc);
			StreamResult result = new StreamResult(out);
			TransformerFactory transformerFactory = TransformerFactory.newInstance();
			Transformer transformer = transformerFactory.newTransformer();
			transformer.transform(source, result);
		}
		catch(Exception e) {
			throw new ServiceException(this, e);
		}
	}
	
	public ComprobanteBean generaComprobanteBean() {
		return this.context.generaComprobanteBean(this.doc, this.xPath);
	}
}
