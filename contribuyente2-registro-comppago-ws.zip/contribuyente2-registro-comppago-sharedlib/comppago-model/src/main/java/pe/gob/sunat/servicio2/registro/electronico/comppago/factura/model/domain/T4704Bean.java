//package pe.gob.sunat.servicio2.registro.electronico.comppago.factura.model.domain;
package pe.gob.sunat.servicio2.registro.electronico.comppago.factura.model.domain;


import java.math.BigDecimal;

import pe.gob.sunat.framework.spring.util.date.FechaBean;
/*
 * detalle  del resumen de boleta
 */
public class T4704Bean  implements java.io.Serializable{  
	private static final long serialVersionUID = 1L;
	
	
	private String    num_ticket;
	private Integer   num_linea;
	private String    num_ruc; 	
	private String    cod_cpe; 	
	private String    num_serie_cpe; 	
	private Integer    num_desde; 
	private Integer    num_hasta; 
	private FechaBean fec_emision;
	private  String   ind_estado;  
    private  BigDecimal   mto_importe_total; 
    private  BigDecimal   mto_gravado_igv;
    private  BigDecimal   mto_exonerado_igv; 
    private  BigDecimal   mto_inafecto_igv; 
    private  BigDecimal   mto_exportaciones; 
    private  BigDecimal   mto_total_cargos; 
    private  BigDecimal   mto_total_igv; 
    private  BigDecimal   mto_total_isc; 
    private  BigDecimal  mto_total_otros; 
    private String    cod_usumodif; 
    private FechaBean fec_modif;
    
     
	public T4704Bean() {
		super();
	}

	public T4704Bean(String numTicket, Integer numLinea, String numRuc,
			String codCpe, String numSerieCpe, Integer numDesde,
			Integer numHasta, FechaBean fecEmision, String indEstado,
			BigDecimal mtoImporteTotal, BigDecimal mtoGravadoIgv,
			BigDecimal mtoExoneradoIgv, BigDecimal mtoInafectoIgv,
			BigDecimal mtoExportaciones, BigDecimal mtoTotalCargos,
			BigDecimal mtoTotalIgv, BigDecimal mtoTotalIsc,
			BigDecimal mtoTotalOtros, String codUsumodif, FechaBean fecModif) {
		super();
		num_ticket = numTicket;
		num_linea = numLinea;
		num_ruc = numRuc;
		cod_cpe = codCpe;
		num_serie_cpe = numSerieCpe;
		num_desde = numDesde;
		num_hasta = numHasta;
		fec_emision = fecEmision;
		ind_estado = indEstado;
		mto_importe_total = mtoImporteTotal;
		mto_gravado_igv = mtoGravadoIgv;
		mto_exonerado_igv = mtoExoneradoIgv;
		mto_inafecto_igv = mtoInafectoIgv;
		mto_exportaciones = mtoExportaciones;
		mto_total_cargos = mtoTotalCargos;
		mto_total_igv = mtoTotalIgv;
		mto_total_isc = mtoTotalIsc;
		mto_total_otros = mtoTotalOtros;
		cod_usumodif = codUsumodif;
		fec_modif = fecModif;
	}





	public String getNum_ticket() {
		return num_ticket;
	}





	public void setNum_ticket(String numTicket) {
		num_ticket = numTicket;
	}





	public Integer getNum_linea() {
		return num_linea;
	}





	public void setNum_linea(Integer numLinea) {
		num_linea = numLinea;
	}





	public String getNum_ruc() {
		return num_ruc;
	}





	public void setNum_ruc(String numRuc) {
		num_ruc = numRuc;
	}





	public String getCod_cpe() {
		return cod_cpe;
	}





	public void setCod_cpe(String codCpe) {
		cod_cpe = codCpe;
	}





	public String getNum_serie_cpe() {
		return num_serie_cpe;
	}





	public void setNum_serie_cpe(String numSerieCpe) {
		num_serie_cpe = numSerieCpe;
	}





	public Integer getNum_desde() {
		return num_desde;
	}





	public void setNum_desde(Integer numDesde) {
		num_desde = numDesde;
	}





	public Integer getNum_hasta() {
		return num_hasta;
	}





	public void setNum_hasta(Integer numHasta) {
		num_hasta = numHasta;
	}


	public String getInd_estado() {
		return ind_estado;
	}





	public void setInd_estado(String indEstado) {
		ind_estado = indEstado;
	}





	public BigDecimal getMto_importe_total() {
		return mto_importe_total;
	}





	public void setMto_importe_total(BigDecimal mtoImporteTotal) {
		mto_importe_total = mtoImporteTotal;
	}





	public BigDecimal getMto_gravado_igv() {
		return mto_gravado_igv;
	}





	public void setMto_gravado_igv(BigDecimal mtoGravadoIgv) {
		mto_gravado_igv = mtoGravadoIgv;
	}





	public BigDecimal getMto_exonerado_igv() {
		return mto_exonerado_igv;
	}





	public void setMto_exonerado_igv(BigDecimal mtoExoneradoIgv) {
		mto_exonerado_igv = mtoExoneradoIgv;
	}





	public BigDecimal getMto_inafecto_igv() {
		return mto_inafecto_igv;
	}





	public void setMto_inafecto_igv(BigDecimal mtoInafectoIgv) {
		mto_inafecto_igv = mtoInafectoIgv;
	}





	public BigDecimal getMto_exportaciones() {
		return mto_exportaciones;
	}





	public void setMto_exportaciones(BigDecimal mtoExportaciones) {
		mto_exportaciones = mtoExportaciones;
	}





	public BigDecimal getMto_total_cargos() {
		return mto_total_cargos;
	}





	public void setMto_total_cargos(BigDecimal mtoTotalCargos) {
		mto_total_cargos = mtoTotalCargos;
	}





	public BigDecimal getMto_total_igv() {
		return mto_total_igv;
	}





	public void setMto_total_igv(BigDecimal mtoTotalIgv) {
		mto_total_igv = mtoTotalIgv;
	}





	public BigDecimal getMto_total_isc() {
		return mto_total_isc;
	}





	public void setMto_total_isc(BigDecimal mtoTotalIsc) {
		mto_total_isc = mtoTotalIsc;
	}





	public BigDecimal getMto_total_otros() {
		return mto_total_otros;
	}





	public void setMto_total_otros(BigDecimal mtoTotalOtros) {
		mto_total_otros = mtoTotalOtros;
	}





	public String getCod_usumodif() {
		return cod_usumodif;
	}





	public void setCod_usumodif(String codUsumodif) {
		cod_usumodif = codUsumodif;
	}





	public FechaBean getFec_modif() {
		return fec_modif;
	}





	public void setFec_modif(FechaBean fecModif) {
		fec_modif = fecModif;
	}





	@Override
	public String toString() {
		return "T4704Bean [cod_cpe=" + cod_cpe + ", cod_usumodif="
				+ cod_usumodif + ", fec_emision=" + fec_emision
				+ ", fec_modif=" + fec_modif + ", ind_estado=" + ind_estado
				+ ", mto_exonerado_igv=" + mto_exonerado_igv
				+ ", mto_exportaciones=" + mto_exportaciones
				+ ", mto_gravado_igv=" + mto_gravado_igv
				+ ", mto_importe_total=" + mto_importe_total
				+ ", mto_inafecto_igv=" + mto_inafecto_igv
				+ ", mto_total_cargos=" + mto_total_cargos + ", mto_total_igv="
				+ mto_total_igv + ", mto_total_isc=" + mto_total_isc
				+ ", mto_total_otros=" + mto_total_otros + ", num_desde="
				+ num_desde + ", num_hasta=" + num_hasta + ", num_linea="
				+ num_linea + ", num_ruc=" + num_ruc + ", num_serie_cpe="
				+ num_serie_cpe + ", num_ticket=" + num_ticket + "]";
	}

	public FechaBean getFec_emision() {
		return fec_emision;
	}

	public void setFec_emision(FechaBean fecEmision) {
		fec_emision = fecEmision;
	}


   
  
    
    
    
}
/*
 * 
create table T4704DETRESBOL  (
NUM_TICKET           CHAR(15)                        not null,
NUM_LINEA            INTEGER                         not null,
NUM_RUC              CHAR(11)                        not null,
COD_CPE              CHAR(2)                         not null,
NUM_SERIE_CPE        VARCHAR(20)                     not null,
NUM_DESDE            INTEGER                         not null,
NUM_HASTA            INTEGER                         not null,
FEC_EMISION          DATE                            not null,
IND_ESTADO           CHAR(1)                         not null,
MTO_IMPORTE_TOTAL    DECIMAL(15,2)                   not null,
MTO_GRAVADO_IGV      DECIMAL(15,2)                   not null,
MTO_EXONERADO_IGV    DECIMAL(15,2)                   not null,
MTO_INAFECTO_IGV     DECIMAL(15,2)                   not null,
MTO_EXPORTACIONES    DECIMAL(15,2)                   not null,
MTO_TOTAL_CARGOS     DECIMAL(15,2)                   not null,
MTO_TOTAL_IGV        DECIMAL(15,2)                   not null,
MTO_TOTAL_ISC        DECIMAL(15,2)                   not null,
MTO_TOTAL_OTROS      DECIMAL(15,2)                   not null,
COD_USUMODIF         VARCHAR(20)                     not null,
FEC_MODIF            DATETIME YEAR TO SECOND         not null
);
/*
 create table TXXX_DET_RES_BOL  (
  NUM_RUC              CHAR(8)                         not null,
  NUM_TICKET           INTEGER                         not null,
  NUM_CORREL_TICKET    INTEGER                         not null,
  FEC_EMISION          DATE                            not null,
  NUM_SERIE            CHAR(4),
  COD_TIPCOMP          char(1),
  NUM_DESDE            INTEGER,
  NUM_HASTA            INTEGER,
  IND_ESTADO       CHAR(1),
  MTO_IMPORTE_TOTAL    DECIMAL,
  MTO_GRAVADO_IGV      DECIMAL,
  MTO_EXONERADO_IGV    DECIMAL,
  MTO_INAFECTO_IGV     DECIMAL,
  MTO_EXPORTACIONES    DECIMAL,
  MTO_TOTAL_CARGOS     DECIMAL,
  MTO_TOTAL_DESC   DECIMAL,
  MTO_PAGAR_IGV        DECIMAL,
  MTO_PAGAR_ISC        DECIMAL,
  MTO_PAGAR_OTROS      DECIMAL,
  COD_USERMODIF        VARCHAR(20),
  FEC_MODIF            DATETIME YEAR TO SECOND,
primary key (NUM_RUC, NUM_TICKET, NUM_CORREL_TICKET)
      constraint PK_TXXX_DET_RES_BO
);

 */

