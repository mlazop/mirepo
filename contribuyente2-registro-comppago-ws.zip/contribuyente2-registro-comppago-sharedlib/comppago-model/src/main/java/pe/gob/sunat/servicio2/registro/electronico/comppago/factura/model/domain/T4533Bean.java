//package pe.gob.sunat.servicio2.registro.electronico.comppago.factura.model.domain;
package pe.gob.sunat.servicio2.registro.electronico.comppago.factura.model.domain;

import pe.gob.sunat.framework.spring.util.date.FechaBean;
import java.io.Serializable;

public class T4533Bean implements Serializable {
	private static final long serialVersionUID = 1L;
	
	private String ticket;
	private String ruc;
	private String usuarioSol;
	private String nombreArchivo;
	private Integer tamanioArchivo;
	private Integer cantidadArchivos;
	private FechaBean fechaInicio;
	private FechaBean fechaFin;
	private Integer estadoProceso;
	private String canalEnvio;
	private String servidorProceso;
	private String tipoProceso;
	private String usuarioModificador;
	private FechaBean fechaModificacion;

	
	public String getTicket() {
		return ticket;
	}

	public void setTicket(String ticket) {
		this.ticket = ticket;
	}

	public String getRuc() {
		return ruc;
	}

	public void setRuc(String ruc) {
		this.ruc = ruc;
	}

	public String getUsuarioSol() {
		return usuarioSol;
	}

	public void setUsuarioSol(String usuarioSol) {
		this.usuarioSol = usuarioSol;
	}

	public String getNombreArchivo() {
		return nombreArchivo;
	}

	public void setNombreArchivo(String nombreArchivo) {
		this.nombreArchivo = nombreArchivo;
	}

	public Integer getTamanioArchivo() {
		return tamanioArchivo;
	}

	public void setTamanioArchivo(Integer tamanioArchivo) {
		this.tamanioArchivo = tamanioArchivo;
	}

	public Integer getCantidadArchivos() {
		return cantidadArchivos;
	}

	public void setCantidadArchivos(Integer cantidadArchivos) {
		this.cantidadArchivos = cantidadArchivos;
	}

	public FechaBean getFechaInicio() {
		return fechaInicio;
	}

	public void setFechaInicio(FechaBean fechaInicio) {
		this.fechaInicio = fechaInicio;
	}

	public FechaBean getFechaFin() {
		return fechaFin;
	}

	public void setFechaFin(FechaBean fechaFin) {
		this.fechaFin = fechaFin;
	}

	public Integer getEstadoProceso() {
		return estadoProceso;
	}

	public void setEstadoProceso(Integer estadoProceso) {
		this.estadoProceso = estadoProceso;
	}

	public String getCanalEnvio() {
		return canalEnvio;
	}

	public void setCanalEnvio(String canalEnvio) {
		this.canalEnvio = canalEnvio;
	}

	public String getServidorProceso() {
		return servidorProceso;
	}

	public void setServidorProceso(String servidorProceso) {
		this.servidorProceso = servidorProceso;
	}

	public String getTipoProceso() {
		return tipoProceso;
	}

	public void setTipoProceso(String tipoProceso) {
		this.tipoProceso = tipoProceso;
	}

	public String getUsuarioModificador() {
		return usuarioModificador;
	}

	public void setUsuarioModificador(String usuarioModificador) {
		this.usuarioModificador = usuarioModificador;
	}

	public FechaBean getFechaModificacion() {
		return fechaModificacion;
	}

	public void setFechaModificacion(FechaBean fechaModificacion) {
		this.fechaModificacion = fechaModificacion;
	}

}
