package pe.gob.sunat.framework.spring.xml.util;

import org.xml.sax.ErrorHandler;
import org.xml.sax.SAXParseException;

import pe.gob.sunat.framework.spring.xml.exception.XMLParseException;

/**
 * Bean que captura el mensaje de error al parsear el archivo "config.xml"
 * y validarlo contra el schema "config.xsd".
 * @author Carlos Enrique Quispe Salazar
 * @since 15/05/2006
 * @version 1.0
 */
public class ConfigErrorHandler implements ErrorHandler {
        public void warning(SAXParseException e) throws XMLParseException {
        	System.out.println("warning");
            throw new XMLParseException(this, XMLParseException.WARNING, e.getLineNumber(), e.getMessage());
        }
        public void error(SAXParseException e) throws XMLParseException {
        	System.out.println("error");
        	throw new XMLParseException(this, XMLParseException.ERROR, e.getLineNumber(), e.getMessage());
        }
        public void fatalError(SAXParseException e) throws XMLParseException {
        	System.out.println("fatal");
        	throw new XMLParseException(this, XMLParseException.FATAL, e.getLineNumber(), e.getMessage());
        }
    }

