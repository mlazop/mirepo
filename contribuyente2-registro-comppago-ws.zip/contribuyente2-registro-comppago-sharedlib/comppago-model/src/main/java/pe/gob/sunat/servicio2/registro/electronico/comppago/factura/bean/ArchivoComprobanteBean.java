package pe.gob.sunat.servicio2.registro.electronico.comppago.factura.bean;

import java.io.File;
import java.io.Serializable;

/**
 * POJO de los datos del archivo.
 * Ambito: Base de datos.
 * @author Carlos Enrique Quispe Salazar
 * */
public class ArchivoComprobanteBean implements Serializable {
	private static final long serialVersionUID = -1735593148221931789L;
	
	private String numeroRuc;
	private String tipoComprobante;
	private String serieComprobante;
	private Integer numeroComprobante;
	private String nombreArchivoXml;
	private File archivoZip;
	private File archivoXml;
//	private byte[] contenidoArchivo;
	private String contenidoArchivoXml;
	private byte[] contenidoArchivoZip;
	
	private Long numIdArchivoXml;
	
	private boolean adjuntaVisor ; // Indica si para la descarga del XML se adjunta el visor. 
	
	public ArchivoComprobanteBean(){
		this.setAdjuntaVisor(true) ; 
	}
	
	public String getNumeroRuc() {
		return numeroRuc;
	}
	
	public void setNumeroRuc(String numeroRuc) {
		this.numeroRuc = numeroRuc;
	}
	
	public String getTipoComprobante() {
		return tipoComprobante;
	}
	
	public void setTipoComprobante(String tipoComprobante) {
		this.tipoComprobante = tipoComprobante;
	}
	
	public String getSerieComprobante() {
		return serieComprobante;
	}
	
	public void setSerieComprobante(String serieComprobante) {
		this.serieComprobante = serieComprobante;
	}
	
	public Integer getNumeroComprobante() {
		return numeroComprobante;
	}
	
	public void setNumeroComprobante(Integer numeroComprobante) {
		this.numeroComprobante = numeroComprobante;
	}
	
	public File getArchivoZip() {
		return archivoZip;
	}

	public void setArchivoZip(File nombreArchivoZip) {
		this.archivoZip = nombreArchivoZip;
	}

	public File getArchivoXml() {
		return archivoXml;
	}

	public void setArchivoXml(File nombreArchivoXml) {
		this.archivoXml = nombreArchivoXml;
	}

	public Long getNumIdArchivoXml() {
		return numIdArchivoXml;
	}

	public void setNumIdArchivoXml(Long numIdArchivoXml) {
		this.numIdArchivoXml = numIdArchivoXml;
	}

//	public byte[] getContenidoArchivo() {
//		return contenidoArchivo;
//	}
//
//	public void setContenidoArchivo(byte[] contenidoArchivo) {
//		this.contenidoArchivo = contenidoArchivo;
//	}

	public String getContenidoArchivoXml() {
		return contenidoArchivoXml;
	}

	public void setContenidoArchivoXml(String contenidoArchivoXml) {
		this.contenidoArchivoXml = contenidoArchivoXml;
	}

	public byte[] getContenidoArchivoZip() {
		return contenidoArchivoZip;
	}

	public void setContenidoArchivoZip(byte[] contenidoArchivoZip) {
		this.contenidoArchivoZip = contenidoArchivoZip;
	}

	public String getNombreArchivoXml() {
		return nombreArchivoXml;
	}

	public void setNombreArchivoXml(String nombreArchivoXml) {
		this.nombreArchivoXml = nombreArchivoXml;
	}

	public boolean isAdjuntaVisor() {
		return adjuntaVisor;
	}

	public void setAdjuntaVisor(boolean adjuntaVisor) {
		this.adjuntaVisor = adjuntaVisor;
	}
	
}
