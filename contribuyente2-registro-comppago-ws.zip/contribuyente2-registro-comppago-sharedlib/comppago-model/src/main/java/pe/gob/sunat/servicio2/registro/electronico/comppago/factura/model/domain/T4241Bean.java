//package pe.gob.sunat.servicio2.registro.electronico.comppago.factura.model.domain;
package pe.gob.sunat.servicio2.registro.electronico.comppago.factura.model.domain;

import java.io.Serializable;
import java.math.BigDecimal;

import pe.gob.sunat.framework.spring.util.date.FechaBean;

public class T4241Bean implements Serializable {
	
	
    /**
	 * 
	 */
	private static final long serialVersionUID = -2363237513123236515L;
	
	private String num_ruc;
    private String cod_cpe;
    private String num_serie_cpe ;
    private Integer num_cpe;
    private String cod_tipo_cpe ;
    private String cod_docide_recep;
    private String num_docide_recep;
    private String des_nombre_recep;
    private String cod_moneda;
    private String des_observacion;
    private String ind_estado;  
    private String ind_rechazo;  
    private BigDecimal mto_importe_total;
    private Long num_id_xml;
    private FechaBean fec_emision;
    private Integer cod_est_anexo;
    private String ind_procedencia;
    private BigDecimal mto_total_igv;
    private BigDecimal mto_total_venta;
    private String num_per_regven;
    private String num_per_regcom;
    private Integer num_cuo_regven;

	private String cod_usumodif;
    private FechaBean fec_modif;
    
    private String des_detalle_rubro; 
    private FechaBean fec_rubro; 
    
    private FechaBean fechaEstado ; 
    
	public String getInd_procedencia() {
		return ind_procedencia;
	}
	public void setInd_procedencia(String indProcedencia) {
		ind_procedencia = indProcedencia;
	}
	public BigDecimal getMto_total_igv() {
		return mto_total_igv;
	}
	public void setMto_total_igv(BigDecimal mtoTotalIgv) {
		mto_total_igv = mtoTotalIgv;
	}
	public BigDecimal getMto_total_venta() {
		return mto_total_venta;
	}
	public void setMto_total_venta(BigDecimal mtoTotalVenta) {
		mto_total_venta = mtoTotalVenta;
	}
	public String getNum_per_regven() {
		return num_per_regven;
	}
	public void setNum_per_regven(String numPerRegven) {
		num_per_regven = numPerRegven;
	}
	public String getNum_per_regcom() {
		return num_per_regcom;
	}
	public void setNum_per_regcom(String numPerRegcom) {
		num_per_regcom = numPerRegcom;
	}
	public FechaBean getFec_rubro() {
		return fec_rubro;
	}
	public void setFec_rubro(FechaBean fecRubro) {
		fec_rubro = fecRubro;
	}
	public String getDes_detalle_rubro() {
		return des_detalle_rubro;
	}
	public void setDes_detalle_rubro(String desDetalleRubro) {
		des_detalle_rubro = desDetalleRubro;
	}

	public String getNum_ruc() {
		return num_ruc;
	}
	public void setNum_ruc(String numRuc) {
		num_ruc = numRuc;
	}
	public String getCod_cpe() {
		return cod_cpe;
	}
	public void setCod_cpe(String codCpe) {
		cod_cpe = codCpe;
	}
	public String getNum_serie_cpe() {
		return num_serie_cpe;
	}
	public void setNum_serie_cpe(String numSerieCpe) {
		num_serie_cpe = numSerieCpe;
	}
	public Integer getNum_cpe() {
		return num_cpe;
	}
	public void setNum_cpe(Integer numCpe) {
		num_cpe = numCpe;
	}
	public String getCod_tipo_cpe() {
		return cod_tipo_cpe;
	}
	public void setCod_tipo_cpe(String codTipoCpe) {
		cod_tipo_cpe = codTipoCpe;
	}
	public String getCod_docide_recep() {
		return cod_docide_recep;
	}
	public void setCod_docide_recep(String codDocideRecep) {
		cod_docide_recep = codDocideRecep;
	}
	public String getNum_docide_recep() {
		return num_docide_recep;
	}
	public void setNum_docide_recep(String numDocideRecep) {
		num_docide_recep = numDocideRecep;
	}
	public String getDes_nombre_recep() {
		return des_nombre_recep;
	}
	public void setDes_nombre_recep(String desNombreRecep) {
		des_nombre_recep = desNombreRecep;
	}
	public String getCod_moneda() {
		return cod_moneda;
	}
	public void setCod_moneda(String codMoneda) {
		cod_moneda = codMoneda;
	}
	public String getDes_observacion() {
		return des_observacion;
	}
	public void setDes_observacion(String desObservacion) {
		des_observacion = desObservacion;
	}
	public String getInd_estado() {
		return ind_estado;
	}
	public void setInd_estado(String indEstado) {
		ind_estado = indEstado;
	}
	public String getInd_rechazo() {
		return ind_rechazo;
	}
	public void setInd_rechazo(String indRechazo) {
		ind_rechazo = indRechazo;
	}
	public BigDecimal getMto_importe_total() {
		return mto_importe_total;
	}
	public void setMto_importe_total(BigDecimal mtoImporteTotal) {
		mto_importe_total = mtoImporteTotal;
	}
	public Long getNum_id_xml() {
		return num_id_xml;
	}
	public void setNum_id_xml(Long numIdXml) {
		num_id_xml = numIdXml;
	}
	public FechaBean getFec_emision() {
		return fec_emision;
	}
	public void setFec_emision(FechaBean fecEmision) {
		fec_emision = fecEmision;
	}
	public Integer getCod_est_anexo() {
		return cod_est_anexo;
	}
	public void setCod_est_anexo(Integer codEstAnexo) {
		cod_est_anexo = codEstAnexo;
	}
    public Integer getNum_cuo_regven() {
		return num_cuo_regven;
	}
	public void setNum_cuo_regven(Integer numCuoRegven) {
		num_cuo_regven = numCuoRegven;
	}
	public String getCod_usumodif() {
		return cod_usumodif;
	}
	public void setCod_usumodif(String codUsumodif) {
		cod_usumodif = codUsumodif;
	}
	public FechaBean getFec_modif() {
		return fec_modif;
	}
	public void setFec_modif(FechaBean fecModif) {
		fec_modif = fecModif;
	}
	public FechaBean getFechaEstado() {
		return fechaEstado;
	}
	public void setFechaEstado(FechaBean fechaEstado) {
		this.fechaEstado = fechaEstado;
	}
	

}
