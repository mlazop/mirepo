package pe.gob.sunat.servicio2.registro.electronico.comppago.factura.model.domain;

import java.io.Serializable;
import java.math.BigDecimal;

import pe.gob.sunat.framework.spring.util.date.FechaBean;

public class T4283Bean_old2 implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = -1857454074948953525L;
	private String num_ruc;
    private String cod_cpe;
    private String num_serie_cpe ;
    private Integer num_cpe;
    private Integer num_fila_item ;
    private String ind_cab_det;
    private Integer cod_rubro;
    private BigDecimal mto_rubro;
    private String des_detalle_rubro;
    private FechaBean fec_rubro;
    private String cod_usumodif;
    private FechaBean fec_modif;
    
	public String getNum_ruc() {
		return num_ruc;
	}
	public void setNum_ruc(String numRuc) {
		num_ruc = numRuc;
	}
	public String getCod_cpe() {
		return cod_cpe;
	}
	public void setCod_cpe(String codCpe) {
		cod_cpe = codCpe;
	}
	public String getNum_serie_cpe() {
		return num_serie_cpe;
	}
	public void setNum_serie_cpe(String numSerieCpe) {
		num_serie_cpe = numSerieCpe;
	}
	public Integer getNum_cpe() {
		return num_cpe;
	}
	public void setNum_cpe(Integer numCpe) {
		num_cpe = numCpe;
	}
	public Integer getNum_fila_item() {
		return num_fila_item;
	}
	public void setNum_fila_item(Integer numFilaItem) {
		num_fila_item = numFilaItem;
	}
	public String getInd_cab_det() {
		return ind_cab_det;
	}
	public void setInd_cab_det(String indCabDet) {
		ind_cab_det = indCabDet;
	}
	public Integer getCod_rubro() {
		return cod_rubro;
	}
	public void setCod_rubro(Integer codRubro) {
		cod_rubro = codRubro;
	}
	public BigDecimal getMto_rubro() {
		return mto_rubro;
	}
	public void setMto_rubro(BigDecimal mtoRubro) {
		mto_rubro = mtoRubro;
	}
	public String getDes_detalle_rubro() {
		return des_detalle_rubro;
	}
	public void setDes_detalle_rubro(String desDetalleRubro) {
		des_detalle_rubro = desDetalleRubro;
	}
	public FechaBean getFec_rubro() {
		return fec_rubro;
	}
	public void setFec_rubro(FechaBean fecRubro) {
		fec_rubro = fecRubro;
	}
	public String getCod_usumodif() {
		return cod_usumodif;
	}
	public void setCod_usumodif(String codUsumodif) {
		cod_usumodif = codUsumodif;
	}
	public FechaBean getFec_modif() {
		return fec_modif;
	}
	public void setFec_modif(FechaBean fecModif) {
		fec_modif = fecModif;
	}

}
