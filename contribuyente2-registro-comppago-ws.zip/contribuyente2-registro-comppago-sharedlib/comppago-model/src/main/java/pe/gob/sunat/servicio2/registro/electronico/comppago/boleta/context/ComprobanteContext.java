package pe.gob.sunat.servicio2.registro.electronico.comppago.boleta.context;

import java.io.StringReader;

import javax.xml.namespace.NamespaceContext;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.xpath.XPath;
import javax.xml.xpath.XPathConstants;

import org.w3c.dom.Document;
import org.w3c.dom.Node;
import org.xml.sax.InputSource;

import pe.gob.sunat.framework.spring.util.exception.ServiceException;
import pe.gob.sunat.servicio2.registro.electronico.comppago.boleta.bean.ComprobanteBean;

public abstract class ComprobanteContext {
	public abstract String getMainNodeValue();
	public abstract String getSchema();
	public abstract String getTemplate();
	public abstract NamespaceContext getNamespaceContext();
	public abstract Node getNodeSigned(Document doc, XPath xpath);
	public abstract Node getNodeToSign(Document doc, XPath xpath);
	public abstract Node getNodeExtensions(Document doc, XPath xpath);
	public abstract ComprobanteBean generaComprobanteBean(Document doc, XPath xpath);

	protected void setTextNode(Document doc, XPath xpath, Node node, String expresion, String text) {
		try {
			if(text != null) {
				if(text.trim().length() > 0) {
			    	Node n = (Node)xpath.evaluate(expresion,  node, XPathConstants.NODE);
					n.appendChild(doc.createTextNode(text));
				}
			}
		}
		catch(Exception e) {
			throw new ServiceException(this, e);
		}
	}
	
	protected void setAmountNode(Document doc, XPath xpath, Node node, String expresion,
								 String amount, String currencyID) {
		setDecimalNode(doc, xpath, node, expresion, amount, "/@currencyID", currencyID);
	}
	
	protected void setQuantityNode(Document doc, XPath xpath, Node node, String expresion,
								   String quantity, String unitCode) {
		setDecimalNode(doc, xpath, node, expresion, quantity, "/@unitCode", unitCode);
	}
	
	protected void setDecimalNode(Document doc, XPath xpath, Node node, String expresion,
								  String decimal, String attrib, String attribValue) {
		if(decimal == null) throw new ServiceException(this, expresion + " el valor decimal es invalido");
		if(decimal.trim().length() == 0) throw new ServiceException(this, expresion + " el valor decimal es invalido");
		
		if(attrib == null) throw new ServiceException(this, attrib + " el valor es invalido");
		if(attrib.trim().length() == 0) throw new ServiceException(this, attrib + " el valor es invalido");
	 
		setTextNode(doc, xpath, node, expresion, decimal);
		setTextNode(doc, xpath, node, expresion + attrib, attribValue);
	}
	
	protected Node addExtensionContent(Document doc, XPath xpath) {
		try {
			Node extensions = (Node)xpath.evaluate(this.getMainNodeValue() + "/ext:UBLExtensions",  doc, XPathConstants.NODE);
			extensions.appendChild(doc.createTextNode("\n\t\t"));
			Node extension = doc.createElement("ext:UBLExtension");
			extension.appendChild(doc.createTextNode("\n\t\t\t"));
			Node content = doc.createElement("ext:ExtensionContent");
			extension.appendChild(content);
			extension.appendChild(doc.createTextNode("\n\t\t"));
			extensions.appendChild(extension);
			extensions.appendChild(doc.createTextNode("\n\t"));
			return content;
		}
		catch(Exception e) {
			throw new ServiceException(this, e);
		}
	}
	
	protected Node toNodeTaxSubTotal(Document doc, String codigoMoneda, String montoImpuesto,
									 String porcentajeImpuesto, String codigoTributo, String descripcionTributo) {
		try {
			StringBuilder sb = new StringBuilder();
			sb.append("<cac:TaxSubtotal>\n\t\t\t\t<cbc:TaxAmount currencyID=\"");
			sb.append(codigoMoneda);
			sb.append("\">");
			sb.append(montoImpuesto);
			sb.append("</cbc:TaxAmount>\n\t\t\t\t<cbc:Percent>");
			sb.append(porcentajeImpuesto);
			sb.append("</cbc:Percent>\n\t\t\t\t<cac:TaxCategory>\n\t\t\t\t\t<cbc:ID>");
			sb.append(codigoTributo);
			sb.append("</cbc:ID>\n\t\t\t\t\t<cbc:Name>");
			sb.append(descripcionTributo);
			sb.append("</cbc:Name>\n\t\t\t\t\t<cac:TaxScheme/>\n\t\t\t\t</cac:TaxCategory>\n\t\t\t</cac:TaxSubtotal>\n");
			DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();
			DocumentBuilder builder = factory.newDocumentBuilder();
			InputSource is = new InputSource(new StringReader(sb.toString()));
			Document docTmp = builder.parse(is);
			return doc.importNode(docTmp.getDocumentElement(), true);
		}
		catch (Exception ex) {
			ex.printStackTrace();
			throw new ServiceException(this, "No se pudo generar la etiqueta TaxSubTotal");
		}
	}
	
	protected Node toNodeOthersDocs(Document doc, boolean isGuia, String numeroDoc, String tipoDoc, String descripcion) {
		try {
			StringBuilder sb = new StringBuilder();
			sb.append((isGuia ? "<cac:DespatchDocumentReference>" : "<cac:AdditionalDocumentReference>"));
			sb.append("\n\t\t\t\t<cbc:ID>");
			sb.append(numeroDoc);
			sb.append("</cbc:ID>\n\t\t\t\t<cbc:DocumentTypeCode>");
			sb.append(tipoDoc);
			sb.append("</cbc:DocumentTypeCode>\n\t\t\t\t<cbc:DocumentType>");
			sb.append(descripcion);
			sb.append("</cbc:DocumentType>\n\t\t\t");
			sb.append((isGuia ? "</cac:DespatchDocumentReference>\n" : "</cac:AdditionalDocumentReference\n"));
			DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();
			DocumentBuilder builder = factory.newDocumentBuilder();
			InputSource is = new InputSource(new StringReader(sb.toString()));
			Document docTmp = builder.parse(is);
			return doc.importNode(docTmp.getDocumentElement(), true);
		}
		catch (Exception ex) {
			ex.printStackTrace();
			throw new ServiceException(this, "No se pudo generar la etiqueta TaxSubTotal");
		}
	}
}
