package pe.gob.sunat.servicio2.registro.electronico.comppago.factura.context;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import javax.xml.namespace.NamespaceContext;
import javax.xml.xpath.XPath;
import javax.xml.xpath.XPathConstants;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.w3c.dom.Document;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;

import pe.gob.sunat.framework.spring.util.date.FechaBean;
import pe.gob.sunat.framework.spring.util.exception.ServiceException;
import pe.gob.sunat.servicio2.registro.electronico.comppago.factura.bean.ComprobanteBean;
import pe.gob.sunat.servicio2.registro.electronico.comppago.factura.bean.ComprobanteUtilBean;
import pe.gob.sunat.servicio2.registro.electronico.comppago.factura.bean.DetalleComprobanteBean;
import pe.gob.sunat.servicio2.registro.electronico.comppago.factura.bean.DocumentoRelacionadoBean;
import pe.gob.sunat.servicio2.registro.electronico.comppago.factura.bean.OtroDocumentoRelacionadoBean;

public class NotaCreditoContext extends ComprobanteContext {

    protected final Log log = LogFactory.getLog(getClass());
    private static final String NODE_DOCUMENT = "/sunat:CreditNote";
    private static final String FILE_SCHEMA = "UBLPE-CreditNote-2.1.xsd"; //UBLPE-CreditNote-1.0.xsd
    private static final String FILE_TEMPLATE = "CreditNote-2.1-Template.vm"; // CreditNote-2.0-Template.vm

    public String getMainNodeValue() {
        return NODE_DOCUMENT;
    }

    public String getSchema() {
        return FILE_SCHEMA;
    }

    public String getTemplate() {
        return FILE_TEMPLATE;
    }

    public NamespaceContext getNamespaceContext() {
        return new NotaCreditoNamespace();
    }

    public Node getNodeToSign(Document doc, XPath xpath) {
        return this.addExtensionContent(doc, xpath);
    }

    public Node getNodeSigned(Document doc, XPath xpath) {
        try {
            String expresion = this.getMainNodeValue() + "/cac:Signature/cac:DigitalSignatureAttachment/cac:ExternalReference/cbc:URI";
            String reference = (String) xpath.evaluate(expresion, doc, XPathConstants.STRING);
            if (reference == null) {
                throw new Exception(expresion + " not found");
            } else if (reference.trim().length() == 0) {
                throw new Exception(expresion + " is empty");
            }
            Node nodeSign = (Node) xpath.evaluate(this.getMainNodeValue() + "/ext:UBLExtensions/ext:UBLExtension/ext:ExtensionContent/ds:Signature", doc, XPathConstants.NODE);
            if (nodeSign == null) {
                throw new Exception("Cannot find Signature element");
            }
            return nodeSign;
        } catch (Exception e) {
            throw new ServiceException(this, e);
        }
    }

    public Node getNodeExtensions(Document doc, XPath xpath) {
        try {
            Node extensions = (Node) xpath.evaluate(this.getMainNodeValue() + "/ext:UBLExtensions", doc, XPathConstants.NODE);
            return extensions;
        } catch (Exception e) {
            throw new ServiceException(this, e);
        }
    }

    public class NotaCreditoNamespace implements NamespaceContext {

        public String getNamespaceURI(String prefix) {
            if (prefix.equals("qdt")) {
                return "urn:oasis:names:specification:ubl:schema:xsd:QualifiedDatatypes-2";
            } else if (prefix.equals("ccts")) {
                return "urn:oasis:names:specification:ubl:schema:xsd:CoreComponentParameters-2";
            } else if (prefix.equals("stat")) {
                return "urn:oasis:names:specification:ubl:schema:xsd:DocumentStatusCode-1.0";
            } else if (prefix.equals("cbc")) {
                return "urn:oasis:names:specification:ubl:schema:xsd:CommonBasicComponents-2";
            } else if (prefix.equals("cac")) {
                return "urn:oasis:names:specification:ubl:schema:xsd:CommonAggregateComponents-2";
            } else if (prefix.equals("cac")) {
                return "urn:un:unece:uncefact:data:draft:UnqualifiedDataTypesSchemaModule:2";
            } else if (prefix.equals("ext")) {
                return "urn:oasis:names:specification:ubl:schema:xsd:CommonExtensionComponents-2";
            } else if (prefix.equals("sac")) {
                return "urn:sunat:names:specification:ubl:peru:schema:xsd:SunatAggregateComponents-1";
            } else if (prefix.equals("ds")) {
                return "http://www.w3.org/2000/09/xmldsig#";
            } else {
                return "urn:oasis:names:specification:ubl:schema:xsd:CreditNote-2";
            }
        }

        public String getPrefix(String p) {
            return null;
        }

        public Iterator<Object> getPrefixes(String p) {
            return null;
        }
    }

    @Override
    public ComprobanteBean generaComprobanteBean(Document doc, XPath xpath) {
        ComprobanteBean comprobante = null;
        try {
            String nm = this.getMainNodeValue();
            String serieNumero = xpath.evaluate(nm + "/cbc:ID", doc, XPathConstants.STRING).toString();
            if (serieNumero.startsWith("E")) {
                comprobante = generaComprobantePortal(doc, xpath);
            } else if (serieNumero.startsWith("F") || serieNumero.startsWith("B")) {
                comprobante = generaComprobanteGEM(doc, xpath);
            }
        } catch (ServiceException e) {
            log.error(e.getLocalizedMessage());
            throw e;
        } catch (Exception e) {
            log.error(e, e);
            throw new ServiceException(this, e.getLocalizedMessage());
        }
        return comprobante;
    }

    /**
     * Genera comprobante para Notas de Credito de GEM.
     *
     * @param doc
     * @param xpath
     * @return
     */
    private ComprobanteBean generaComprobanteGEM(Document doc, XPath xpath) {

        if (log.isInfoEnabled()) {
            log.info(">> Genera comprobante Nota de cr�dito GEM");
        }

        ComprobanteBean comprobante = new ComprobanteBean();

        try {
            String nm = this.getMainNodeValue();
            Object tmpObj = null;
            Node nodeItem = null;
            String identifier = "";

            comprobante.setNumeroRuc(xpath.evaluate(nm + "/cac:AccountingSupplierParty/cbc:CustomerAssignedAccountID", doc, XPathConstants.STRING).toString());
            comprobante.setRazonSocial(xpath.evaluate(nm + "/cac:AccountingSupplierParty/cac:Party/cac:PartyLegalEntity/cbc:RegistrationName", doc, XPathConstants.STRING).toString());

            tmpObj = xpath.evaluate(nm + "/cac:AccountingSupplierParty/cac:Party/cac:PostalAddress/cbc:StreetName", doc, XPathConstants.STRING);
            comprobante.setNombreCalle(tmpObj != null && tmpObj.toString().length() > 0 ? tmpObj.toString() : "");

            tmpObj = xpath.evaluate(nm + "/cac:AccountingSupplierParty/cac:Party/cac:PostalAddress/cbc:CitySubdivisionName", doc, XPathConstants.STRING);
            comprobante.setNombreUrbanizacion(tmpObj != null && tmpObj.toString().length() > 0 ? tmpObj.toString() : "");

            tmpObj = xpath.evaluate(nm + "/cac:AccountingSupplierParty/cac:Party/cac:PostalAddress/cbc:District", doc, XPathConstants.STRING);
            comprobante.setNombreDistrito(tmpObj != null && tmpObj.toString().length() > 0 ? tmpObj.toString() : "");

            tmpObj = xpath.evaluate(nm + "/cac:AccountingSupplierParty/cac:Party/cac:PostalAddress/cbc:CityName", doc, XPathConstants.STRING);
            comprobante.setNombreProvincia(tmpObj != null && tmpObj.toString().length() > 0 ? tmpObj.toString() : "");

            tmpObj = xpath.evaluate(nm + "/cac:AccountingSupplierParty/cac:Party/cac:PostalAddress/cbc:CountrySubentity", doc, XPathConstants.STRING);
            comprobante.setNombreDepartamento(tmpObj != null && tmpObj.toString().length() > 0 ? tmpObj.toString() : "");

            tmpObj = xpath.evaluate(nm + "/cac:AccountingSupplierParty/cac:Party/cac:PostalAddress/cac:Country/cbc:IdentificationCode", doc, XPathConstants.STRING);
            comprobante.setCodigoPais(tmpObj != null && tmpObj.toString().length() > 0 ? tmpObj.toString() : "");

            tmpObj = comprobante.getNombreCalle() + comprobante.getNombreUrbanizacion() + comprobante.getNombreDistrito() + comprobante.getNombreProvincia() + comprobante.getNombreDepartamento();

            comprobante.setDireccionCompleta(tmpObj.toString().length() == 0 ? ""
                    : comprobante.getNombreCalle() + ", " + comprobante.getNombreUrbanizacion() + ", "
                    + comprobante.getNombreDistrito() + ", " + comprobante.getNombreProvincia() + ", "
                    + comprobante.getNombreDepartamento() + ", " + comprobante.getCodigoPais()
            );

            if (log.isDebugEnabled()) {
                log.debug(">> Step 1 :: Complet� Datos del emisor.");
            }

            comprobante.setTipoDocumentoCliente(xpath.evaluate(nm + "/cac:AccountingCustomerParty/cbc:AdditionalAccountID", doc, XPathConstants.STRING).toString());
            comprobante.setDesTipoDocumentoCliente(obtenerDescCatalogo06(comprobante.getTipoDocumentoCliente()));

            comprobante.setNumeroDocumentoCliente(xpath.evaluate(nm + "/cac:AccountingCustomerParty/cbc:CustomerAssignedAccountID", doc, XPathConstants.STRING).toString());
            comprobante.setNombreCliente(xpath.evaluate(nm + "/cac:AccountingCustomerParty/cac:Party/cac:PartyLegalEntity/cbc:RegistrationName", doc, XPathConstants.STRING).toString());

            if (log.isDebugEnabled()) {
                log.debug(">> Step 2 :: Complet� Datos del comprador.");
            }

            comprobante.setSerieComprobante(xpath.evaluate(nm + "/cbc:ID", doc, XPathConstants.STRING).toString());
            comprobante.setFechaEmision(xpath.evaluate(nm + "/cbc:IssueDate", doc, XPathConstants.STRING).toString());
            comprobante.setCodigoMoneda(xpath.evaluate(nm + "/cbc:DocumentCurrencyCode", doc, XPathConstants.STRING).toString());

            String tipoNota = xpath.evaluate(nm + "/cac:DiscrepancyResponse/cbc:ResponseCode", doc, XPathConstants.STRING).toString();
            comprobante.setGlosa(obtenerDescCatalogo09(tipoNota));

            comprobante.setMotivoEmisionNota(xpath.evaluate(nm + "/cac:DiscrepancyResponse/cbc:Description", doc, XPathConstants.STRING).toString());

            if (log.isDebugEnabled()) {
                log.debug(">> Step 3 :: Complet� Datos del comprobante");
            }

            comprobante.setSerieDocumentoPorElQueSeEmite(xpath.evaluate(nm + "/cac:BillingReference/cac:InvoiceDocumentReference/cbc:ID", doc, XPathConstants.STRING).toString());
            String tipComp = xpath.evaluate(nm + "/cac:BillingReference/cac:InvoiceDocumentReference/cbc:DocumentTypeCode", doc, XPathConstants.STRING).toString();
            comprobante.setDescTipoDocQueModifica(obtenerDescCatalogo01(tipComp.trim()));

            if (log.isDebugEnabled()) {
                log.debug(">> Step 4 :: Complet� Datos del comprobante que modifica");
            }

            NodeList nlItems = (NodeList) xpath.evaluate(nm + "/cac:CreditNoteLine", doc, XPathConstants.NODESET);
            if (nlItems.getLength() > 0) {
                List<DetalleComprobanteBean> aDetalleComprobante = new ArrayList<DetalleComprobanteBean>();
                DetalleComprobanteBean linea = null;
                for (int i = 0; i < nlItems.getLength(); i++) {
                    nodeItem = (Node) nlItems.item(i);
                    linea = new DetalleComprobanteBean();

                    tmpObj = xpath.evaluate("cbc:CreditedQuantity", nodeItem, XPathConstants.STRING);
                    linea.setCantidad(tmpObj != null && tmpObj.toString().length() > 0 ? ComprobanteUtilBean.formatTwoDecimal(tmpObj.toString()) : "");

                    tmpObj = xpath.evaluate("cbc:CreditedQuantity/@unitCode", nodeItem, XPathConstants.STRING);
                    linea.setUnidadMedida(tmpObj != null && tmpObj.toString().length() > 0 ? tmpObj.toString() : "");

                    tmpObj = xpath.evaluate("cac:Item/cac:SellersItemIdentification/cbc:ID", nodeItem, XPathConstants.STRING);
                    linea.setCodigoItem(tmpObj != null && tmpObj.toString().length() > 0 ? tmpObj.toString() : "");

                    tmpObj = xpath.evaluate("cac:Item/cbc:Description", nodeItem, XPathConstants.STRING);
                    linea.setDescripcion(tmpObj != null && tmpObj.toString().length() > 0 ? tmpObj.toString() : "");

                    tmpObj = xpath.evaluate("cac:Price/cbc:PriceAmount", nodeItem, XPathConstants.STRING);
                    linea.setValorVtaUnitario(tmpObj != null && tmpObj.toString().length() > 0 ? ComprobanteUtilBean.formatTwoDecimal(tmpObj.toString()) : "");
                    /**
                     * El valor de venta total (V.V.U * Cantidad)
                     */
                    tmpObj = xpath.evaluate("cbc:LineExtensionAmount", nodeItem, XPathConstants.STRING);
                    linea.setTotalVentaPorItem(tmpObj != null && tmpObj.toString().length() > 0 ? ComprobanteUtilBean.formatTwoDecimal(tmpObj.toString()) : "");

                    tmpObj = xpath.evaluate("cac:PricingReference/cac:AlternativeConditionPrice/cbc:PriceAmount", nodeItem, XPathConstants.STRING);
                    linea.setPrecioUnitario(tmpObj != null && tmpObj.toString().length() > 0 ? ComprobanteUtilBean.formatTwoDecimal(tmpObj.toString()) : "");

                    tmpObj = xpath.evaluate("cac:TaxTotal/cac:TaxSubtotal/cac:TaxCategory/cac:TaxScheme/cbc:ID", nodeItem, XPathConstants.STRING);
                    if (tmpObj.toString().trim().equals("1000")) {
                        /**
                         * Monto del IGV de la l�nea
                         */
                        tmpObj = xpath.evaluate("cac:TaxTotal/cbc:TaxAmount", nodeItem, XPathConstants.STRING);
                        linea.setIgvMonto(tmpObj != null && tmpObj.toString().length() > 0 ? ComprobanteUtilBean.formatTwoDecimal(tmpObj.toString()) : "");
                    } else if (tmpObj.toString().trim().equals("2000")) {
                        /**
                         * Monto del ISC de la l�nea
                         */
                        tmpObj = xpath.evaluate("cac:TaxTotal/cbc:TaxAmount", nodeItem, XPathConstants.STRING);
                        linea.setIscSistema(tmpObj != null && tmpObj.toString().length() > 0 ? ComprobanteUtilBean.formatTwoDecimal(tmpObj.toString()) : "");
                    }
                    aDetalleComprobante.add(linea);
                }
                comprobante.setDetalleComprobanteBean(aDetalleComprobante);
            }

            if (log.isDebugEnabled()) {
                log.debug(">> Step 5 :: Paso Datos del Items de la Nota de credito.");
            }

            NodeList additDocs = (NodeList) xpath.evaluate(nm + "/cac:DespatchDocumentReference", doc, XPathConstants.NODESET);
            if (additDocs.getLength() > 0) {
                for (int i = 0; i < additDocs.getLength(); i++) {
                    DocumentoRelacionadoBean docrel = new DocumentoRelacionadoBean();
                    nodeItem = (Node) additDocs.item(i);
                    identifier = xpath.evaluate("cbc:DocumentTypeCode", nodeItem, XPathConstants.STRING).toString().trim();
                    docrel.setTipoComprobante(identifier);
                    docrel.setDescTipoComprobanteRelacionado(obtenerDescCatalogo01(identifier));
                    docrel.setSerieComprobanteRelacionado(xpath.evaluate("cbc:ID", nodeItem, XPathConstants.STRING).toString());
                    comprobante.getDocumentoRelacionadoBean().add(docrel);
                }
            }
            additDocs = (NodeList) xpath.evaluate(nm + "/cac:AdditionalDocumentReference", doc, XPathConstants.NODESET);
            if (additDocs.getLength() > 0) {
                for (int i = 0; i < additDocs.getLength(); i++) {
                    DocumentoRelacionadoBean docrel = new DocumentoRelacionadoBean();
                    nodeItem = (Node) additDocs.item(i);
                    identifier = xpath.evaluate("cbc:DocumentTypeCode", nodeItem, XPathConstants.STRING).toString().trim();
                    docrel.setTipoComprobante(identifier);
                    docrel.setDescTipoComprobanteRelacionado(obtenerDescCatalogo12(identifier));
                    docrel.setSerieComprobanteRelacionado(xpath.evaluate("cbc:ID", nodeItem, XPathConstants.STRING).toString());
                    comprobante.getDocumentoRelacionadoBean().add(docrel);
                }
            }

            if (log.isDebugEnabled()) {
                log.debug(">> Step 6 :: Complet� documentos relacionados de la nota de d�bito.");
            }

            NodeList totalesVenta = (NodeList) xpath.evaluate(nm + "/ext:UBLExtensions/ext:UBLExtension/ext:ExtensionContent/sac:AdditionalInformation/sac:AdditionalMonetaryTotal", doc, XPathConstants.NODESET);
            if (totalesVenta.getLength() > 0) {
                for (int i = 0; i < totalesVenta.getLength(); i++) {
                    nodeItem = (Node) totalesVenta.item(i);
                    identifier = xpath.evaluate("cbc:ID", nodeItem, XPathConstants.STRING).toString();
                    if ("1001".equals(identifier)) {
                        comprobante.setTotalValorVenta(ComprobanteUtilBean.toBigDecimal(xpath.evaluate("cbc:PayableAmount", nodeItem, XPathConstants.STRING).toString()));
                    } else if ("1002".equals(identifier)) { // valor de venta inafecta
                        comprobante.setTotalValorVentaNoGravado(ComprobanteUtilBean.toBigDecimal(xpath.evaluate("cbc:PayableAmount", nodeItem, XPathConstants.STRING).toString()));
                    } else if ("1003".equals(identifier)) {
                        comprobante.setTotalValorVentaExonerado(ComprobanteUtilBean.toBigDecimal(xpath.evaluate("cbc:PayableAmount", nodeItem, XPathConstants.STRING).toString()));
                    } else if ("2005".equals(identifier)) {
                        comprobante.setTotalDescuentos(ComprobanteUtilBean.toBigDecimal(xpath.evaluate("cbc:PayableAmount", nodeItem, XPathConstants.STRING).toString()));
                    }
                }
            }

            NodeList totalesOtros = (NodeList) xpath.evaluate(nm + "/cac:TaxTotal/cac:TaxSubtotal", doc, XPathConstants.NODESET);
            if (totalesOtros.getLength() > 0) {
                for (int i = 0; i < totalesOtros.getLength(); i++) {
                    nodeItem = (Node) totalesOtros.item(i);
                    identifier = xpath.evaluate("cac:TaxCategory/cac:TaxScheme/cbc:ID", nodeItem, XPathConstants.STRING).toString();
                    if ("1000".equals(identifier)) {
                        comprobante.setTotalIGV(ComprobanteUtilBean.toBigDecimal(xpath.evaluate("cbc:TaxAmount", nodeItem, XPathConstants.STRING).toString()));
                    } else if ("2000".equals(identifier)) {
                        comprobante.setTotalISC(ComprobanteUtilBean.toBigDecimal(xpath.evaluate("cbc:TaxAmount", nodeItem, XPathConstants.STRING).toString()));
                    } else if ("9999".equals(identifier)) {
                        comprobante.setTotalOtrosTributos(ComprobanteUtilBean.toBigDecimal(xpath.evaluate("cbc:TaxAmount", nodeItem, XPathConstants.STRING).toString()));
                    }
                }
            }

            tmpObj = xpath.evaluate(nm + "/cac:LegalMonetaryTotal/cbc:ChargeTotalAmount", doc, XPathConstants.STRING);
            comprobante.setTotalOtrosCargos(tmpObj != null && tmpObj.toString().length() > 0 ? ComprobanteUtilBean.toBigDecimal(tmpObj.toString()) : new BigDecimal(0.00));

            comprobante.setMontoTotalGeneral(ComprobanteUtilBean.toBigDecimal((String) xpath.evaluate(nm + "/cac:LegalMonetaryTotal/cbc:PayableAmount", doc, XPathConstants.STRING)));

            if (log.isDebugEnabled()) {
                log.debug(">> Step 7 :: Complet� Datos del totales de la nota de credito.");
            }

        } catch (ServiceException e) {
            log.error(e, e);
            throw e;
        } catch (Exception e) {
            log.error(e, e);
            throw new ServiceException(this, e.getLocalizedMessage());
        }
        return comprobante;
    }

    /**
     * Catalogo de Nro. 01 C�digo de tipo de documento autorizado para efectos
     * tributarios.
     *
     * @param codigo
     * @return
     */
    private String obtenerDescCatalogo01(String codigo) {
        String result = "";
        if ("01".equals(codigo)) {
            result = "FACTURA";
        } else if ("03".equals(codigo)) {
            result = "BOLETA DE VENTA";
        } else if ("07".equals(codigo)) {
            result = "NOTA DE CREDITO";
        } else if ("08".equals(codigo)) {
            result = "NOTA DE DEBITO";
        } else if ("09".equals(codigo)) {
            result = "GUIA DE REMISI�N REMITENTE";
        } else if ("12".equals(codigo)) {
            result = "TICKET DE MAQUINA REGISTRADORA";
        } else if ("31".equals(codigo)) {
            result = "GUIA DE REMISI�N TRANSPORTISTA";
        }
        return result;
    }

    /**
     * Catalogo de Nro. 06 Tipo de Documento de Identificaci�n.
     *
     * @param codigo
     * @return
     */
    private String obtenerDescCatalogo06(String codigo) {
        String result = "";
        if ("06".equals(codigo) || "6".equals(codigo)) {
            result = "RUC";
        } else if ("01".equals(codigo) || "1".equals(codigo)) {
            result = "DNI";
        } else if ("04".equals(codigo) || "4".equals(codigo)) {
            result = "CARNET EXTRANJERIA";
        } else if ("07".equals(codigo) || "7".equals(codigo)) {
            result = "PASAPORTE";
        } else if ("00".equals(codigo) || "0".equals(codigo)) {
            result = "DOC.TRIB.NO.DOM.SIN.RUC";
        }
        return result;
    }

    /**
     * Catalogo de Nro. 10 Tipo de nota de d�bito seg�n motivo.
     *
     * @param codigo
     * @return
     */
    private String obtenerDescCatalogo09(String codigo) {
        String result = "";
        if (codigo.equals("01")) {
            result = "ANULACI�N DE LA OPERACI�N";
        } else if (codigo.equals("02")) {
            result = "ANULACI�N POR ERROR EN EL RUC";
        } else if (codigo.equals("03")) {
            result = "CORRECCI�N POR ERROR EN LA DESCRIPCI�N";
        } else if (codigo.equals("04")) {
            result = "DESCUENTO GLOBAL";
        } else if (codigo.equals("05")) {
            result = "DESCUENTO POR �TEM";
        } else if (codigo.equals("06")) {
            result = "DEVOLUCI�N TOTAL";
        } else if (codigo.equals("07")) {
            result = "DEVOLUCI�N POR �TEM";
        } else if (codigo.equals("08")) {
            result = "BONIFICACI�N";
        } else if (codigo.equals("09")) {
            result = "DISMINUCI�N EN EL VALOR";
        }
        return result;
    }

    /**
     * Catalogo de Nro. 10 Tipo de nota de d�bito seg�n motivo.
     *
     * @param codigo
     * @return
     */
    @SuppressWarnings("unused")
    private String obtenerDescCatalogo10(String codigo) {
        String result = "";
        if (codigo.trim().equals("01")) {
            result = "Intereses por mora";
        } else if (codigo.trim().equals("02")) {
            result = "Aumento en el valor";
        }
        return result;
    }

    /**
     * Catalogo de Nro. 12 C�digo del tipo de documentos tributarios de
     * referencia.
     *
     * @param codigo
     * @return
     */
    private String obtenerDescCatalogo12(String codigo) {
        String result = "";
        if (codigo.equals("04")) {
            result = "Ticket de Salida - ENAPU";
        } else if (codigo.equals("05")) {
            result = "C�digo SCOP";
        } else if (codigo.equals("99")) {
            result = "Otros";
        } else if (codigo.equals("01")) {
            result = "Factura � emitida para corregir error en el RUC";
        }
        return result;
    }

    /**
     * Genera comprobante para Notas de Credito emitidas desde PORTAL SOL.
     *
     * @param doc
     * @param xpath
     * @return
     */
    private ComprobanteBean generaComprobantePortal(Document doc, XPath xpath) {
        ComprobanteBean comprobante = new ComprobanteBean();
        try {
            String nm = this.getMainNodeValue();
            String version = (String) xpath.evaluate(nm + "/cbc:CustomizationID", doc, XPathConstants.STRING);
            if (log.isDebugEnabled()) {
                log.debug(">> Version del documento = " + version);
            }
             if (Double.parseDouble(version) < 2) {
                comprobante = generaComprobantePortalV1(doc, xpath);
            } else if (Double.parseDouble(version) == 2.0) {
                comprobante = generaComprobantePortalV2(doc, xpath);
            } else if (Double.parseDouble(version) == 2.1) {
                comprobante = generaComprobantePortalV3(doc, xpath);
            }
        } catch (ServiceException se) {
            log.error(se, se);
            throw se;
        } catch (Exception e) {
            log.error(e, e);
            throw new ServiceException(this, "Ocurrio un error generando el ComprobanteBean de factura PORTAL.");
        }
        return comprobante;
    }

    /**
     * Es una factura de exportacion si el tipo de documento y el n�mero de
     * documento del cliente son "-".
     *
     * @param doc
     * @param xpath
     * @return
     */
    private boolean isCpeExportacion(Document doc, XPath xpath) {
        boolean result = false;
        try {
            String nm = this.getMainNodeValue();
            String tipDoc = (String) xpath.evaluate(nm + "/cac:AccountingCustomerParty/cbc:AdditionalAccountID", doc, XPathConstants.STRING);
            String numDoc = (String) xpath.evaluate(nm + "/cac:AccountingCustomerParty/cbc:CustomerAssignedAccountID", doc, XPathConstants.STRING);

            if (tipDoc.trim().equals("-") && numDoc.trim().equals("-")) {
                result = true;
            }
        } catch (ServiceException se) {
            log.error(se, se);
            throw se;
        } catch (Exception e) {
            log.error(e, e);
            throw new ServiceException(this, "Ocurrio un error al verificar si la factura es de exportaci�n.");
        }
        return result;
    }
	
	/**
     * Genera el ComprobanteBean a partir de la version 3.0 de la estructura del
     * documento XMl.
     *
     * @param doc
     * @param xpath
     * @return
     */
    private ComprobanteBean generaComprobantePortalV3(Document doc, XPath xpath) {

        if (log.isInfoEnabled()) {
            log.info(">> Genera comprobante Nota de credito PORTAL V3.0 **");
        }

        ComprobanteBean comprobante = new ComprobanteBean();
        // inicializando en valores  por defecto por ser  numericos
        comprobante.setTotalValorVenta(new BigDecimal(0.00));
        comprobante.setTotalDescuentos(new BigDecimal(0.00));
        comprobante.setTotalIGV(new BigDecimal(0.00));
        comprobante.setTotalISC(new BigDecimal(0.00));
        comprobante.setTotalOtrosCargos(new BigDecimal(0.00));
        comprobante.setTotalOtrosTributos(new BigDecimal(0.00));
        comprobante.setMontoDescuentos(new BigDecimal(0.00));
        comprobante.setMontoImpuestos(new BigDecimal(0.00));
        comprobante.setMontoSubTotal(new BigDecimal(0.00));
        comprobante.setMontoTotalGeneral(new BigDecimal(0.00));

        try {
            String nm = this.getMainNodeValue();
            Object tmpObj = null;
            Node nodeItem = null;
            String identifier = "";

            String id = (String) xpath.evaluate(nm + "/cbc:ID", doc, XPathConstants.STRING);
            comprobante.setNumeroComprobante(new Integer(id.substring(id.indexOf("-") + 1)));
            comprobante.setSerieComprobante(id.substring(0, id.indexOf("-")));
            comprobante.setNumeroRuc((String) xpath.evaluate(nm + "/cac:AccountingSupplierParty/cac:Party/cac:PartyIdentification/cbc:ID", doc, XPathConstants.STRING));
            String tipoNota = (String) xpath.evaluate(nm + "/cac:DiscrepancyResponse/cbc:ResponseCode", doc, XPathConstants.STRING);
            String tipoNotaTemp = tipoNota;
            if ("01".equals(tipoNota.trim())) {
                tipoNota = "21";
            }
            if ("02".equals(tipoNota.trim())) {
                tipoNota = "22";
            }
            if ("03".equals(tipoNota.trim())) {
                tipoNota = "25";
            }
            if ("04".equals(tipoNota.trim())) {
                tipoNota = "23";
            }
            if ("05".equals(tipoNota.trim())) {
                tipoNota = "27";
            }
            if ("06".equals(tipoNota.trim())) {
                tipoNota = "24";
            }
            if ("07".equals(tipoNota.trim())) {
                tipoNota = "26";
            }
            comprobante.setSubTipoComprobante(tipoNota);
            comprobante.setGlosa(obtenerDescCatalogo09(tipoNotaTemp));

            FechaBean fb = new FechaBean((String) xpath.evaluate(nm + "/cbc:IssueDate", doc, XPathConstants.STRING), "yyyy-MM-dd");
            comprobante.setFechaEmision(fb.getFormatDate("dd/MM/yyyy"));
            fb.setFecha((String) xpath.evaluate(nm + "/cbc:IssueTime", doc, XPathConstants.STRING), "HH:mm:ss");
            comprobante.setHoraEmision(fb.getFormatDate("HH:mm:ss"));
            
            
            tmpObj = xpath.evaluate(nm + "/cbc:Note[not(@*)]", doc, XPathConstants.STRING);
            comprobante.setObservacion(tmpObj != null && tmpObj.toString().length() > 0 ? tmpObj.toString() : "");
            log.debug("comprobante.getObservacion:" + comprobante.getObservacion());
            
            

            String documoriginal = (String) xpath.evaluate(nm + "/cac:DiscrepancyResponse/cbc:ReferenceID", doc, XPathConstants.STRING);
            comprobante.setSerieDocumentoPorElQueSeEmite((documoriginal.substring(0, documoriginal.indexOf("-"))).trim());
            comprobante.setNumeroDocumentoPorElQueSeEmite((documoriginal.substring(documoriginal.indexOf("-") + 1)).trim());

            log.debug("paso0 ");//naa			
            //MPCR buscar tag para monto en letras
            //comprobante.setMontoTotalTexto((String)xpath.evaluate(nm + "/cbc:Note", doc, XPathConstants.STRING));
            String s2 = (String) xpath.evaluate(nm + "/cbc:Note[@languageLocaleID='1000']", doc, XPathConstants.STRING);
            comprobante.setMontoTotalTexto(s2);
            log.debug("saliendo de paso1 ");//naa    
            
////////////////////
            NodeList nodeExtensiones = (NodeList) xpath.evaluate(nm + "/ext:UBLExtensions/ext:UBLExtension/ext:ExtensionContent", doc, XPathConstants.NODESET);

            if (nodeExtensiones.getLength() > 0) {
                nodeItem = null;
                for (int i = 0; i < nodeExtensiones.getLength(); i++) {
                    nodeItem = (Node) nodeExtensiones.item(i);
                    String codNodo = "";
                    NodeList nodeProperties = (NodeList) xpath.evaluate("sac:AdditionalInformation/sac:AdditionalMonetaryTotal", nodeItem, XPathConstants.NODESET);
                    if (nodeProperties.getLength() > 0) {
                        for (int j = 0; j < nodeProperties.getLength(); j++) {

                            codNodo = (String) xpath.evaluate("cbc:ID", nodeProperties.item(j), XPathConstants.STRING);

                            if (codNodo != null) {
                                if (codNodo.equals("1004")) {
                                    comprobante.setTotalValorVentaOperaGratuitas(ComprobanteUtilBean.toBigDecimal((String) xpath.evaluate("cbc:PayableAmount", nodeProperties.item(j), XPathConstants.STRING)));
                                }
                                if (codNodo.equals("1005")) {
                                    comprobante.setTotalSubTotalValorVenta(ComprobanteUtilBean.toBigDecimal((String) xpath.evaluate("cbc:PayableAmount", nodeProperties.item(j), XPathConstants.STRING)));
                                }
                                //if (codNodo.equals("2005")){
                                //	comprobante.setTotalDescuentos(ComprobanteUtilBean.toBigDecimal((String)xpath.evaluate("cbc:PayableAmount", nodeProperties.item(j), XPathConstants.STRING)));	
                                //}
                            }
                        }
                    }
                }

            }
////////////////////			

            NodeList nlGuias = (NodeList) xpath.evaluate(nm + "/cac:DespatchDocumentReference", doc, XPathConstants.NODESET);
            NodeList nlOtrosDocs = (NodeList) xpath.evaluate(nm + "/cac:AdditionalDocumentReference", doc, XPathConstants.NODESET);
            log.debug("paso2 ");//naa
            if (nlGuias.getLength() > 0 || nlOtrosDocs.getLength() > 0) {

                log.debug("paso3 ");//naa	
                int lengthArray = nlGuias.getLength() + nlOtrosDocs.getLength();
                List<OtroDocumentoRelacionadoBean> aOtrosDocs = new ArrayList<OtroDocumentoRelacionadoBean>();
                OtroDocumentoRelacionadoBean docRel = null;
                log.debug("paso4 ");//naa
                for (int j = 0, x = 0, y = 0; j < lengthArray; j++) {
                    nodeItem = (j < nlGuias.getLength() ? (Node) nlGuias.item(x++) : (Node) nlOtrosDocs.item(y++));
                    docRel = new OtroDocumentoRelacionadoBean();
                    docRel.setTipoDocumentoRelacionado((String) xpath.evaluate("cbc:cbc:DocumentTypeCode", nodeItem, XPathConstants.STRING));
                    docRel.setDesTipoDocuRela((String) xpath.evaluate("cbc:DocumentType", nodeItem, XPathConstants.STRING));
                    docRel.setNumeroDocumentoRelacionadoInicial((String) xpath.evaluate("cbc:ID", nodeItem, XPathConstants.STRING));
                    aOtrosDocs.add(docRel);

                }
                log.debug("paso5 ");//naa
                comprobante.setOtroDocumentoRelacionadoBean(aOtrosDocs);
            }
            /**
             * --------------------------------------------------
             */
            log.debug("paso6 ");//naa
//			comprobante.setRazonSocial((String)xpath.evaluate(nm + "/cac:AccountingSupplierParty/cac:Party/cac:PartyName/cbc:Name", doc, XPathConstants.STRING));
            comprobante.setRazonComercial((String) xpath.evaluate(nm + "/cac:AccountingSupplierParty/cac:Party/cac:PartyName/cbc:Name", doc, XPathConstants.STRING));
            comprobante.setRazonSocial((String) xpath.evaluate(nm + "/cac:AccountingSupplierParty/cac:Party/cac:PartyLegalEntity/cbc:RegistrationName", doc, XPathConstants.STRING));

            //comprobante.setUbigeoEmisor((String)xpath.evaluate(nm + "/cac:AccountingSupplierParty/cac:Party/cac:PostalAddress/cbc:ID", doc, XPathConstants.STRING));
            //comprobante.setNombreCalle((String)xpath.evaluate(nm + "/cac:AccountingSupplierParty/cac:Party/cac:PostalAddress/cbc:StreetName", doc, XPathConstants.STRING));
            comprobante.setUbigeoEmisor((String) xpath.evaluate(nm + "/cac:AccountingSupplierParty/cac:Party/cac:PartyLegalEntity/cac:RegistrationAddress/cbc:ID", doc, XPathConstants.STRING));
            comprobante.setNombreCalle((String) xpath.evaluate(nm + "/cac:AccountingSupplierParty/cac:Party/cac:PartyLegalEntity/cac:RegistrationAddress/cac:AddressLine/cbc:Line", doc, XPathConstants.STRING));
            //	/cac:AccountingSupplierParty/cac:Party/cac:PartyLegalEntity/cac:RegistrationAddress/
            /////comprobante.setNumeroDireccion((String)xpath.evaluate(nm + "/cac:AccountingSupplierParty/cac:Party/cac:PostalAddress/cbc:BuildingNumber", doc, XPathConstants.STRING));
            comprobante.setNombreDistrito((String) xpath.evaluate(nm + "/cac:AccountingSupplierParty/cac:Party/cac:PartyLegalEntity/cac:RegistrationAddress/cbc:District", doc, XPathConstants.STRING));
            comprobante.setNombreProvincia((String) xpath.evaluate(nm + "/cac:AccountingSupplierParty/cac:Party/cac:PartyLegalEntity/cac:RegistrationAddress/cbc:CountrySubentity", doc, XPathConstants.STRING));
            comprobante.setNombreDepartamento((String) xpath.evaluate(nm + "/cac:AccountingSupplierParty/cac:Party/cac:PartyLegalEntity/cac:RegistrationAddress/cbc:CityName", doc, XPathConstants.STRING));
            comprobante.setCodigoPais((String) xpath.evaluate(nm + "/cac:AccountingSupplierParty/cac:Party/cac:PartyLegalEntity/cac:RegistrationAddress/cac:Country/cbc:IdentificationCode", doc, XPathConstants.STRING));

            comprobante.setNumeroDocumentoCliente((String) xpath.evaluate(nm + "/cac:AccountingCustomerParty/cac:Party/cac:PartyIdentification/cbc:ID", doc, XPathConstants.STRING));
            comprobante.setTipoDocumentoCliente((String) xpath.evaluate(nm + "/cac:AccountingCustomerParty/cac:Party/cac:PartyIdentification/cbc:ID/@schemeID", doc, XPathConstants.STRING));

            comprobante.setDesTipoDocumentoCliente(this.obtenerDescCatalogo06(comprobante.getTipoDocumentoCliente()));
            comprobante.setNombreCliente((String) xpath.evaluate(nm + "/cac:AccountingCustomerParty/cac:Party/cac:PartyLegalEntity/cbc:RegistrationName", doc, XPathConstants.STRING));
            //comprobante.setNombreCliente((String)xpath.evaluate(nm + "/cac:AccountingCustomerParty/cac:Party/cac:PartyName/cbc:Name", doc, XPathConstants.STRING));
            
            if (xpath.evaluate(nm + "/cac:LegalMonetaryTotal/cbc:PrepaidAmount", doc, XPathConstants.STRING) == null || xpath.evaluate(nm + "/cac:LegalMonetaryTotal/cbc:PrepaidAmount", doc, XPathConstants.STRING).equals("")) {
                comprobante.setTotalAnticipos(new BigDecimal(0));
            } else {
                //comprobante.setTotalAnticipos(ComprobanteUtilBean.toBigDecimal((String)xpath.evaluate(nm + "/cac:LegalMonetaryTotal/cbc:PrepaidAmount", doc, XPathConstants.STRING)));
                if (((String) xpath.evaluate(nm + "/cac:LegalMonetaryTotal/cbc:PrepaidAmount", doc, XPathConstants.STRING)).equals("$util.formatTwoDecimal($cp.getTotalAnticipos())")) {
                    comprobante.setTotalAnticipos(new BigDecimal(0));
                } else {
                    comprobante.setTotalAnticipos(ComprobanteUtilBean.toBigDecimal((String) xpath.evaluate(nm + "/cac:LegalMonetaryTotal/cbc:PrepaidAmount", doc, XPathConstants.STRING)));
                }
            }

            //comprobante.setTotalDescuentos(ComprobanteUtilBean.toBigDecimal((String)xpath.evaluate(nm + "/cac:LegalMonetaryTotal/cbc:AllowanceTotalAmount", doc, XPathConstants.STRING)));
            if (xpath.evaluate(nm + "/cac:LegalMonetaryTotal/cbc:AllowanceTotalAmount", doc, XPathConstants.STRING) != null && !xpath.evaluate(nm + "/cac:LegalMonetaryTotal/cbc:AllowanceTotalAmount", doc, XPathConstants.STRING).equals("")) {
                comprobante.setTotalDescuentos(ComprobanteUtilBean.toBigDecimal((String) xpath.evaluate(nm + "/cac:LegalMonetaryTotal/cbc:AllowanceTotalAmount", doc, XPathConstants.STRING)));
            }

            comprobante.setTotalOtrosCargos(new BigDecimal(0));
            if (!xpath.evaluate(nm + "/cac:LegalMonetaryTotal/cbc:ChargeTotalAmount", doc, XPathConstants.STRING).equals("")) {
                comprobante.setTotalOtrosCargos(ComprobanteUtilBean.toBigDecimal((String) xpath.evaluate(nm + "/cac:LegalMonetaryTotal/cbc:ChargeTotalAmount", doc, XPathConstants.STRING)));
            }
            
            //PAS20181U210000122 UBL 2.1 cambio x Inicio cambio UBL 2.1
            //comprobante.setTotalSubTotalValorVenta(ComprobanteUtilBean.toBigDecimal((String) xpath.evaluate(nm + "/cac:LegalMonetaryTotal/cbc:LineExtensionAmount", doc, XPathConstants.STRING)));
            //comprobante.setTotalValorVenta(comprobante.getTotalSubTotalValorVenta().subtract(comprobante.getTotalAnticipos()).subtract(comprobante.getTotalDescuentos()));

            // Inicio cambio UBL 2.1
            comprobante.setTotalValorVenta(ComprobanteUtilBean.toBigDecimal((String) xpath.evaluate(nm + "/cac:LegalMonetaryTotal/cbc:LineExtensionAmount", doc, XPathConstants.STRING)));
            comprobante.setTotalSubTotalValorVenta(comprobante.getTotalValorVenta().add(comprobante.getTotalDescuentos())); //.add(comprobante.getTotalAnticipos()));           //OJO - retirar porque debe grabarse el valor             
            // Fin cambio UBL 2.1

            comprobante.setMontoTotalGeneral(ComprobanteUtilBean.toBigDecimal((String) xpath.evaluate(nm + "/cac:LegalMonetaryTotal/cbc:PayableAmount", doc, XPathConstants.STRING)));
            log.debug("paso7 ");//naa

            NodeList totalesOtros = (NodeList) xpath.evaluate(nm + "/cac:TaxTotal/cac:TaxSubtotal", doc, XPathConstants.NODESET);
            if (totalesOtros.getLength() > 0) {
                for (int i = 0; i < totalesOtros.getLength(); i++) {
                    nodeItem = (Node) totalesOtros.item(i);
                    identifier = xpath.evaluate("cac:TaxCategory/cac:TaxScheme/cbc:ID", nodeItem, XPathConstants.STRING).toString();
                    if ("1000".equals(identifier)) {
                        comprobante.setTotalIGV(ComprobanteUtilBean.toBigDecimal(xpath.evaluate("cbc:TaxAmount", nodeItem, XPathConstants.STRING).toString()));
                    } else if ("2000".equals(identifier)) {
                        comprobante.setTotalISC(ComprobanteUtilBean.toBigDecimal(xpath.evaluate("cbc:TaxAmount", nodeItem, XPathConstants.STRING).toString()));
                    } else if ("9999".equals(identifier)) {
                        comprobante.setTotalOtrosTributos(ComprobanteUtilBean.toBigDecimal(xpath.evaluate("cbc:TaxAmount", nodeItem, XPathConstants.STRING).toString()));
                    }else if ("9996".equals(identifier)) {
                        comprobante.setTotalOtrosTributos(ComprobanteUtilBean.toBigDecimal(xpath.evaluate("cbc:TaxAmount", nodeItem, XPathConstants.STRING).toString()));
                        comprobante.setTotalValorVentaOperaGratuitas(ComprobanteUtilBean.toBigDecimal(xpath.evaluate("cbc:TaxableAmount", nodeItem, XPathConstants.STRING).toString()));
                    }
                }
            }

            log.debug("paso10 ");//naa

            /// DETALLE DE LA NOTA DE CREDITO
            comprobante.setCodigoMoneda((String) xpath.evaluate(nm + "/cac:LegalMonetaryTotal/cbc:PayableAmount/@currencyID", doc, XPathConstants.STRING));

            NodeList nlItems = (NodeList) xpath.evaluate(nm + "/cac:CreditNoteLine", doc, XPathConstants.NODESET);
            if (nlItems.getLength() > 0) {
                List<DetalleComprobanteBean> aDetalleComprobante = new ArrayList<DetalleComprobanteBean>();
                DetalleComprobanteBean detalle = null;
                for (int i = 0; i < nlItems.getLength(); i++) {
                    log.debug("paso11 ");//naa
                    nodeItem = (Node) nlItems.item(i);
                    detalle = new DetalleComprobanteBean();
                    if (i == 0) {
                        // MPCR ya no va, se puso en cbc not de la cabecera
                        //comprobante.setObservacion((String)xpath.evaluate("cbc:Note", nodeItem, XPathConstants.STRING));						 
                    }

                    detalle.setIdentificador(Integer.parseInt((String) xpath.evaluate("cbc:ID", nodeItem, XPathConstants.STRING)));
                    detalle.setNumeroLinea(Integer.parseInt((String) xpath.evaluate("cbc:ID", nodeItem, XPathConstants.STRING)));
                    detalle.setIdentificadorOriginal(Integer.parseInt((String) xpath.evaluate("cbc:ID", nodeItem, XPathConstants.STRING)));

                    if (comprobante.getSubTipoComprobante() != null && comprobante.getSubTipoComprobante().trim().equals("23")) {
                        detalle.setCodigoItem((String) xpath.evaluate("cac:Item/cac:CatalogueDocumentReference/cbc:ID", nodeItem, XPathConstants.STRING));
                        if (detalle.getCodigoItem() == null) {
                            detalle.setCodigoItem("");
                        }
                        detalle.setDescripcion((String) xpath.evaluate("cac:Item/cbc:Description", nodeItem, XPathConstants.STRING));
                        detalle.setIgvMonto("0");
                        detalle.setIscMonto("0");
                        detalle.setOtroMonto("0");

                        //detalle.setPrecioUnitario("0");
                        if (((String) xpath.evaluate("cac:Price/cbc:PriceAmount", nodeItem, XPathConstants.STRING)).equals("$util.formatTenDecimal($dc.getPrecioUnitario())")) {
                            detalle.setValorVtaUnitario(detalle.getImporteVenta());
                        } else {
                            detalle.setValorVtaUnitario((String) xpath.evaluate("cac:Price/cbc:PriceAmount", nodeItem, XPathConstants.STRING));
                        }

                        detalle.setUnidadMedida("-");
                    } else {
                        detalle.setUnidadMedida(String.valueOf(xpath.evaluate("cbc:CreditedQuantity/@unitCode", nodeItem, XPathConstants.STRING)));
                        //detalle.setCantidad((String)xpath.evaluate("cbc:CreditedQuantity", nodeItem, XPathConstants.STRING));
                        if (((String) xpath.evaluate("cbc:CreditedQuantity", nodeItem, XPathConstants.STRING)).equals("$util.formatTenDecimal($dc.getCantidad())")) {
                            detalle.setCantidad("1.00");
                        } else {
                            detalle.setCantidad((String) xpath.evaluate("cbc:CreditedQuantity", nodeItem, XPathConstants.STRING));
                        }
                        //detalle.setPrecioUnitario((String)xpath.evaluate("cac:Price/cbc:PriceAmount", nodeItem, XPathConstants.STRING));
                        if (((String) xpath.evaluate("cac:Price/cbc:PriceAmount", nodeItem, XPathConstants.STRING)).equals("$util.formatTenDecimal($dc.getPrecioUnitario())")) {
                            detalle.setValorVtaUnitario(detalle.getImporteVenta());
                        } else {
                            detalle.setValorVtaUnitario((String) xpath.evaluate("cac:Price/cbc:PriceAmount", nodeItem, XPathConstants.STRING));
                        }

                        detalle.setCodigoItem((String) xpath.evaluate("cac:Item/cac:CatalogueDocumentReference/cbc:ID", nodeItem, XPathConstants.STRING));
                        detalle.setDescripcion((String) xpath.evaluate("cac:Item/cbc:Description", nodeItem, XPathConstants.STRING));

                        detalle.setMontoBruto(ComprobanteUtilBean.formatTwoDecimal((String) xpath.evaluate("cbc:LineExtensionAmount", nodeItem, XPathConstants.STRING)));

                        Object oTotalImpuesto = (String) xpath.evaluate("cac:TaxTotal/cbc:TaxAmount", nodeItem, XPathConstants.STRING);

                        detalle.setTotalImpuestos(ComprobanteUtilBean.isNumber(oTotalImpuesto) ? ComprobanteUtilBean.formatTwoDecimal((String) oTotalImpuesto) : "0");

                        // Object oDescuento = xpath.evaluate("cac:AllowanceCharge/cbc:Amount", nodeItem, XPathConstants.STRING);
                        //detalle.setDescuentoMonto((ComprobanteUtilBean.isNumber(oDescuento) ? ComprobanteUtilBean.formatTwoDecimal((String)oDescuento) : "0"));
                        detalle.setIgvMonto("0");
                        detalle.setIscMonto("0");
                        detalle.setOtroMonto("0");

                        NodeList nodeTaxSubTotals = (NodeList) xpath.evaluate("cac:TaxTotal/cac:TaxSubtotal", nodeItem, XPathConstants.NODESET);
                        log.debug("nodeTaxSubTotals.getLength(): " + nodeTaxSubTotals.getLength());//naa
                        for (int j = 0; j < nodeTaxSubTotals.getLength(); j++) {
                            log.debug("paso12 ");//naa
                            Node nodeTaxSubTotal = (Node) nodeTaxSubTotals.item(j);
                            String tributo = (String) xpath.evaluate("cac:TaxCategory/cbc:ID", nodeTaxSubTotal, XPathConstants.STRING);
                            log.debug("tributo: " + tributo);//naa
                            if (tributo.equals(ComprobanteUtilBean.IGV)) {
                                detalle.setIgvMonto(ComprobanteUtilBean.formatTwoDecimal((String) xpath.evaluate("cbc:TaxAmount", nodeTaxSubTotal, XPathConstants.STRING)));
                            } else if (tributo.equals(ComprobanteUtilBean.ISC)) {
                                detalle.setIscMonto(ComprobanteUtilBean.formatTwoDecimal((String) xpath.evaluate("cbc:TaxAmount", nodeTaxSubTotal, XPathConstants.STRING)));
                            } else {
                                //detalle.setOtroMonto(ComprobanteUtilBean.formatTwoDecimal((String)xpath.evaluate("cbc:TaxAmount", nodeTaxSubTotal, XPathConstants.STRING)));
                            }
                        }
                    }
                    aDetalleComprobante.add(detalle);
                }
                comprobante.setDetalleComprobanteBean(aDetalleComprobante);
                log.debug("paso13 ");//naa
            }

        } catch (ServiceException e) {
            log.error(e, e);
            log.error(e.getLocalizedMessage());
            throw e;
        } catch (Exception e) {
            log.error(e, e);
            throw new ServiceException(this, e.getLocalizedMessage());
        }
        return comprobante;
    }

    /**
     * Genera el ComprobanteBean a partir de la version 2.0 de la estructura del
     * documento XMl.
     *
     * @param doc
     * @param xpath
     * @return
     */
    private ComprobanteBean generaComprobantePortalV2(Document doc, XPath xpath) {

        if (log.isInfoEnabled()) {
            log.info(">> Genera comprobante Nota de credito PORTAL V2.0");
        }

        ComprobanteBean comprobante = new ComprobanteBean();
        // inicializando en valores  por defecto por ser  numericos
        comprobante.setTotalValorVenta(new BigDecimal(0.00));
        comprobante.setTotalDescuentos(new BigDecimal(0.00));
        comprobante.setTotalIGV(new BigDecimal(0.00));
        comprobante.setTotalISC(new BigDecimal(0.00));
        comprobante.setTotalOtrosCargos(new BigDecimal(0.00));
        comprobante.setTotalOtrosTributos(new BigDecimal(0.00));
        comprobante.setMontoDescuentos(new BigDecimal(0.00));
        comprobante.setMontoImpuestos(new BigDecimal(0.00));
        comprobante.setMontoSubTotal(new BigDecimal(0.00));
        comprobante.setMontoTotalGeneral(new BigDecimal(0.00));

        try {
            String nm = this.getMainNodeValue();
            Object tmpObj = null;
            Node nodeItem = null;
            String identifier = "";

            String id = (String) xpath.evaluate(nm + "/cbc:ID", doc, XPathConstants.STRING);
            comprobante.setNumeroComprobante(new Integer(id.substring(id.indexOf("-") + 1)));
            comprobante.setSerieComprobante(id.substring(0, id.indexOf("-")));
            comprobante.setNumeroRuc((String) xpath.evaluate(nm + "/cac:AccountingSupplierParty/cbc:CustomerAssignedAccountID", doc, XPathConstants.STRING));
            String tipoNota = (String) xpath.evaluate(nm + "/cac:DiscrepancyResponse/cbc:ResponseCode", doc, XPathConstants.STRING);
            String tipoNotaTemp = tipoNota;
            if ("01".equals(tipoNota.trim())) {
                tipoNota = "21";
            }
            if ("02".equals(tipoNota.trim())) {
                tipoNota = "22";
            }
            if ("03".equals(tipoNota.trim())) {
                tipoNota = "25";
            }
            if ("04".equals(tipoNota.trim())) {
                tipoNota = "23";
            }
            if ("05".equals(tipoNota.trim())) {
                tipoNota = "27";
            }
            if ("06".equals(tipoNota.trim())) {
                tipoNota = "24";
            }
            if ("07".equals(tipoNota.trim())) {
                tipoNota = "26";
            }
            comprobante.setSubTipoComprobante(tipoNota);
            comprobante.setGlosa(obtenerDescCatalogo09(tipoNotaTemp));

            FechaBean fb = new FechaBean((String) xpath.evaluate(nm + "/cbc:IssueDate", doc, XPathConstants.STRING), "yyyy-MM-dd");
            comprobante.setFechaEmision(fb.getFormatDate("dd/MM/yyyy"));
            fb.setFecha((String) xpath.evaluate(nm + "/cbc:IssueTime", doc, XPathConstants.STRING), "HH:mm:ss");
            comprobante.setHoraEmision(fb.getFormatDate("HH:mm:ss"));
            comprobante.setObservacion((String) xpath.evaluate(nm + "/cbc:Note", doc, XPathConstants.STRING));
            String documoriginal = (String) xpath.evaluate(nm + "/cac:DiscrepancyResponse/cbc:ReferenceID", doc, XPathConstants.STRING);
            comprobante.setSerieDocumentoPorElQueSeEmite((documoriginal.substring(0, documoriginal.indexOf("-"))).trim());
            comprobante.setNumeroDocumentoPorElQueSeEmite((documoriginal.substring(documoriginal.indexOf("-") + 1)).trim());

            log.debug("paso0 ");//naa			
            //MPCR buscar tag para monto en letras
            //comprobante.setMontoTotalTexto((String)xpath.evaluate(nm + "/cbc:Note", doc, XPathConstants.STRING));

            String s2 = (String) xpath.evaluate(nm + "/ext:UBLExtensions/ext:UBLExtension/ext:ExtensionContent/sac:AdditionalInformation/sac:AdditionalProperty/cbc:Value", doc, XPathConstants.STRING);

            comprobante.setMontoTotalTexto(s2);
            log.debug("saliendo de paso1 ");//naa
////////////////////
            NodeList nodeExtensiones = (NodeList) xpath.evaluate(nm + "/ext:UBLExtensions/ext:UBLExtension/ext:ExtensionContent", doc, XPathConstants.NODESET);

            if (nodeExtensiones.getLength() > 0) {
                nodeItem = null;
                for (int i = 0; i < nodeExtensiones.getLength(); i++) {
                    nodeItem = (Node) nodeExtensiones.item(i);
                    String codNodo = "";
                    NodeList nodeProperties = (NodeList) xpath.evaluate("sac:AdditionalInformation/sac:AdditionalMonetaryTotal", nodeItem, XPathConstants.NODESET);
                    if (nodeProperties.getLength() > 0) {
                        for (int j = 0; j < nodeProperties.getLength(); j++) {

                            codNodo = (String) xpath.evaluate("cbc:ID", nodeProperties.item(j), XPathConstants.STRING);

                            if (codNodo != null) {
                                if (codNodo.equals("1004")) {
                                    comprobante.setTotalValorVentaOperaGratuitas(ComprobanteUtilBean.toBigDecimal((String) xpath.evaluate("cbc:PayableAmount", nodeProperties.item(j), XPathConstants.STRING)));
                                }
                                if (codNodo.equals("1005")) {
                                    comprobante.setTotalSubTotalValorVenta(ComprobanteUtilBean.toBigDecimal((String) xpath.evaluate("cbc:PayableAmount", nodeProperties.item(j), XPathConstants.STRING)));
                                }
                                //if (codNodo.equals("2005")){
                                //	comprobante.setTotalDescuentos(ComprobanteUtilBean.toBigDecimal((String)xpath.evaluate("cbc:PayableAmount", nodeProperties.item(j), XPathConstants.STRING)));	
                                //}
                            }
                        }
                    }
                }

            }
////////////////////			

            NodeList nlGuias = (NodeList) xpath.evaluate(nm + "/cac:DespatchDocumentReference", doc, XPathConstants.NODESET);
            NodeList nlOtrosDocs = (NodeList) xpath.evaluate(nm + "/cac:AdditionalDocumentReference", doc, XPathConstants.NODESET);
            log.debug("paso2 ");//naa
            if (nlGuias.getLength() > 0 || nlOtrosDocs.getLength() > 0) {

                log.debug("paso3 ");//naa	
                int lengthArray = nlGuias.getLength() + nlOtrosDocs.getLength();
                List<OtroDocumentoRelacionadoBean> aOtrosDocs = new ArrayList<OtroDocumentoRelacionadoBean>();
                OtroDocumentoRelacionadoBean docRel = null;
                log.debug("paso4 ");//naa
                for (int j = 0, x = 0, y = 0; j < lengthArray; j++) {
                    nodeItem = (j < nlGuias.getLength() ? (Node) nlGuias.item(x++) : (Node) nlOtrosDocs.item(y++));
                    docRel = new OtroDocumentoRelacionadoBean();
                    docRel.setTipoDocumentoRelacionado((String) xpath.evaluate("cbc:cbc:DocumentTypeCode", nodeItem, XPathConstants.STRING));
                    docRel.setDesTipoDocuRela((String) xpath.evaluate("cbc:DocumentType", nodeItem, XPathConstants.STRING));
                    docRel.setNumeroDocumentoRelacionadoInicial((String) xpath.evaluate("cbc:ID", nodeItem, XPathConstants.STRING));
                    aOtrosDocs.add(docRel);

                }
                log.debug("paso5 ");//naa
                comprobante.setOtroDocumentoRelacionadoBean(aOtrosDocs);
            }
            /**
             * --------------------------------------------------
             */
            log.debug("paso6 ");//naa
//			comprobante.setRazonSocial((String)xpath.evaluate(nm + "/cac:AccountingSupplierParty/cac:Party/cac:PartyName/cbc:Name", doc, XPathConstants.STRING));
            comprobante.setRazonComercial((String) xpath.evaluate(nm + "/cac:AccountingSupplierParty/cac:Party/cac:PartyName/cbc:Name", doc, XPathConstants.STRING));
            comprobante.setRazonSocial((String) xpath.evaluate(nm + "/cac:AccountingSupplierParty/cac:Party/cac:PartyLegalEntity/cbc:RegistrationName", doc, XPathConstants.STRING));

            //comprobante.setUbigeoEmisor((String)xpath.evaluate(nm + "/cac:AccountingSupplierParty/cac:Party/cac:PostalAddress/cbc:ID", doc, XPathConstants.STRING));
            //comprobante.setNombreCalle((String)xpath.evaluate(nm + "/cac:AccountingSupplierParty/cac:Party/cac:PostalAddress/cbc:StreetName", doc, XPathConstants.STRING));
            comprobante.setUbigeoEmisor((String) xpath.evaluate(nm + "/cac:AccountingSupplierParty/cac:Party/cac:PostalAddress/cbc:ID", doc, XPathConstants.STRING));
            comprobante.setNombreCalle((String) xpath.evaluate(nm + "/cac:AccountingSupplierParty/cac:Party/cac:PostalAddress/cbc:StreetName", doc, XPathConstants.STRING));
            //	/cac:AccountingSupplierParty/cac:Party/cac:PartyLegalEntity/cac:RegistrationAddress/
            /////comprobante.setNumeroDireccion((String)xpath.evaluate(nm + "/cac:AccountingSupplierParty/cac:Party/cac:PostalAddress/cbc:BuildingNumber", doc, XPathConstants.STRING));
            comprobante.setNombreDistrito((String) xpath.evaluate(nm + "/cac:AccountingSupplierParty/cac:Party/cac:PostalAddress/cbc:District", doc, XPathConstants.STRING));
            comprobante.setNombreProvincia((String) xpath.evaluate(nm + "/cac:AccountingSupplierParty/cac:Party/cac:PostalAddress/cbc:CountrySubentity", doc, XPathConstants.STRING));
            comprobante.setNombreDepartamento((String) xpath.evaluate(nm + "/cac:AccountingSupplierParty/cac:Party/cac:PostalAddress/cbc:CityName", doc, XPathConstants.STRING));
            comprobante.setCodigoPais((String) xpath.evaluate(nm + "/cac:AccountingSupplierParty/cac:Party/cac:PostalAddress/cac:Country/cbc:IdentificationCode", doc, XPathConstants.STRING));

            comprobante.setNumeroDocumentoCliente((String) xpath.evaluate(nm + "/cac:AccountingCustomerParty/cbc:CustomerAssignedAccountID", doc, XPathConstants.STRING));
            comprobante.setTipoDocumentoCliente((String) xpath.evaluate(nm + "/cac:AccountingCustomerParty/cbc:AdditionalAccountID", doc, XPathConstants.STRING));

            comprobante.setDesTipoDocumentoCliente(this.obtenerDescCatalogo06(comprobante.getTipoDocumentoCliente()));
            comprobante.setNombreCliente((String) xpath.evaluate(nm + "/cac:AccountingCustomerParty/cac:Party/cac:PartyLegalEntity/cbc:RegistrationName", doc, XPathConstants.STRING));
            //comprobante.setNombreCliente((String)xpath.evaluate(nm + "/cac:AccountingCustomerParty/cac:Party/cac:PartyName/cbc:Name", doc, XPathConstants.STRING));
            comprobante.setTotalValorVenta(ComprobanteUtilBean.toBigDecimal((String) xpath.evaluate(nm + "/cac:LegalMonetaryTotal/cbc:LineExtensionAmount", doc, XPathConstants.STRING)));
            if (xpath.evaluate(nm + "/cac:LegalMonetaryTotal/cbc:PrepaidAmount", doc, XPathConstants.STRING) == null || xpath.evaluate(nm + "/cac:LegalMonetaryTotal/cbc:PrepaidAmount", doc, XPathConstants.STRING).equals("")) {
                comprobante.setTotalAnticipos(new BigDecimal(0));
            } else {
                //comprobante.setTotalAnticipos(ComprobanteUtilBean.toBigDecimal((String)xpath.evaluate(nm + "/cac:LegalMonetaryTotal/cbc:PrepaidAmount", doc, XPathConstants.STRING)));
                if (((String) xpath.evaluate(nm + "/cac:LegalMonetaryTotal/cbc:PrepaidAmount", doc, XPathConstants.STRING)).equals("$util.formatTwoDecimal($cp.getTotalAnticipos())")) {
                    comprobante.setTotalAnticipos(new BigDecimal(0));
                } else {
                    comprobante.setTotalAnticipos(ComprobanteUtilBean.toBigDecimal((String) xpath.evaluate(nm + "/cac:LegalMonetaryTotal/cbc:PrepaidAmount", doc, XPathConstants.STRING)));
                }
            }

            //comprobante.setTotalDescuentos(ComprobanteUtilBean.toBigDecimal((String)xpath.evaluate(nm + "/cac:LegalMonetaryTotal/cbc:AllowanceTotalAmount", doc, XPathConstants.STRING)));
            if (xpath.evaluate(nm + "/cac:LegalMonetaryTotal/cbc:AllowanceTotalAmount", doc, XPathConstants.STRING) != null && !xpath.evaluate(nm + "/cac:LegalMonetaryTotal/cbc:AllowanceTotalAmount", doc, XPathConstants.STRING).equals("")) {
                comprobante.setTotalDescuentos(ComprobanteUtilBean.toBigDecimal((String) xpath.evaluate(nm + "/cac:LegalMonetaryTotal/cbc:AllowanceTotalAmount", doc, XPathConstants.STRING)));
            }

            comprobante.setTotalOtrosCargos(new BigDecimal(0));
            if (!xpath.evaluate(nm + "/cac:LegalMonetaryTotal/cbc:ChargeTotalAmount", doc, XPathConstants.STRING).equals("")) {
                comprobante.setTotalOtrosCargos(ComprobanteUtilBean.toBigDecimal((String) xpath.evaluate(nm + "/cac:LegalMonetaryTotal/cbc:ChargeTotalAmount", doc, XPathConstants.STRING)));
            }

            comprobante.setMontoTotalGeneral(ComprobanteUtilBean.toBigDecimal((String) xpath.evaluate(nm + "/cac:LegalMonetaryTotal/cbc:PayableAmount", doc, XPathConstants.STRING)));
            log.debug("paso7 ");//naa

            NodeList totalesOtros = (NodeList) xpath.evaluate(nm + "/cac:TaxTotal/cac:TaxSubtotal", doc, XPathConstants.NODESET);
            if (totalesOtros.getLength() > 0) {
                for (int i = 0; i < totalesOtros.getLength(); i++) {
                    nodeItem = (Node) totalesOtros.item(i);
                    identifier = xpath.evaluate("cac:TaxCategory/cac:TaxScheme/cbc:ID", nodeItem, XPathConstants.STRING).toString();
                    if ("1000".equals(identifier)) {
                        comprobante.setTotalIGV(ComprobanteUtilBean.toBigDecimal(xpath.evaluate("cbc:TaxAmount", nodeItem, XPathConstants.STRING).toString()));
                    } else if ("2000".equals(identifier)) {
                        comprobante.setTotalISC(ComprobanteUtilBean.toBigDecimal(xpath.evaluate("cbc:TaxAmount", nodeItem, XPathConstants.STRING).toString()));
                    } else if ("9999".equals(identifier)) {
                        comprobante.setTotalOtrosTributos(ComprobanteUtilBean.toBigDecimal(xpath.evaluate("cbc:TaxAmount", nodeItem, XPathConstants.STRING).toString()));
                    }
                }
            }

            log.debug("paso10 ");//naa

            /// DETALLE DE LA NOTA DE CREDITO
            comprobante.setCodigoMoneda((String) xpath.evaluate(nm + "/cac:LegalMonetaryTotal/cbc:PayableAmount/@currencyID", doc, XPathConstants.STRING));

            NodeList nlItems = (NodeList) xpath.evaluate(nm + "/cac:CreditNoteLine", doc, XPathConstants.NODESET);
            if (nlItems.getLength() > 0) {
                List<DetalleComprobanteBean> aDetalleComprobante = new ArrayList<DetalleComprobanteBean>();
                DetalleComprobanteBean detalle = null;
                for (int i = 0; i < nlItems.getLength(); i++) {
                    log.debug("paso11 ");//naa
                    nodeItem = (Node) nlItems.item(i);
                    detalle = new DetalleComprobanteBean();
                    if (i == 0) {
                        // MPCR ya no va, se puso en cbc not de la cabecera
                        //comprobante.setObservacion((String)xpath.evaluate("cbc:Note", nodeItem, XPathConstants.STRING));						 
                    }

                    detalle.setIdentificador(Integer.parseInt((String) xpath.evaluate("cbc:ID", nodeItem, XPathConstants.STRING)));
                    detalle.setNumeroLinea(Integer.parseInt((String) xpath.evaluate("cbc:ID", nodeItem, XPathConstants.STRING)));
                    detalle.setIdentificadorOriginal(Integer.parseInt((String) xpath.evaluate("cbc:ID", nodeItem, XPathConstants.STRING)));

                    if (comprobante.getSubTipoComprobante() != null && comprobante.getSubTipoComprobante().trim().equals("23")) {
                        detalle.setCodigoItem((String) xpath.evaluate("cac:Item/cac:CatalogueDocumentReference/cbc:ID", nodeItem, XPathConstants.STRING));
                        if (detalle.getCodigoItem() == null) {
                            detalle.setCodigoItem("");
                        }
                        detalle.setDescripcion((String) xpath.evaluate("cac:Item/cbc:Description", nodeItem, XPathConstants.STRING));
                        detalle.setIgvMonto("0");
                        detalle.setIscMonto("0");
                        detalle.setOtroMonto("0");

                        //detalle.setPrecioUnitario("0");
                        if (((String) xpath.evaluate("cac:Price/cbc:PriceAmount", nodeItem, XPathConstants.STRING)).equals("$util.formatTenDecimal($dc.getPrecioUnitario())")) {
                            detalle.setValorVtaUnitario(detalle.getImporteVenta());
                        } else {
                            detalle.setValorVtaUnitario((String) xpath.evaluate("cac:Price/cbc:PriceAmount", nodeItem, XPathConstants.STRING));
                        }

                        detalle.setUnidadMedida("-");
                    } else {
                        detalle.setUnidadMedida(String.valueOf(xpath.evaluate("cbc:CreditedQuantity/@unitCode", nodeItem, XPathConstants.STRING)));
                        //detalle.setCantidad((String)xpath.evaluate("cbc:CreditedQuantity", nodeItem, XPathConstants.STRING));
                        if (((String) xpath.evaluate("cbc:CreditedQuantity", nodeItem, XPathConstants.STRING)).equals("$util.formatTenDecimal($dc.getCantidad())")) {
                            detalle.setCantidad("1.00");
                        } else {
                            detalle.setCantidad((String) xpath.evaluate("cbc:CreditedQuantity", nodeItem, XPathConstants.STRING));
                        }
                        //detalle.setPrecioUnitario((String)xpath.evaluate("cac:Price/cbc:PriceAmount", nodeItem, XPathConstants.STRING));
                        if (((String) xpath.evaluate("cac:Price/cbc:PriceAmount", nodeItem, XPathConstants.STRING)).equals("$util.formatTenDecimal($dc.getPrecioUnitario())")) {
                            detalle.setValorVtaUnitario(detalle.getImporteVenta());
                        } else {
                            detalle.setValorVtaUnitario((String) xpath.evaluate("cac:Price/cbc:PriceAmount", nodeItem, XPathConstants.STRING));
                        }

                        detalle.setCodigoItem((String) xpath.evaluate("cac:Item/cac:CatalogueDocumentReference/cbc:ID", nodeItem, XPathConstants.STRING));
                        detalle.setDescripcion((String) xpath.evaluate("cac:Item/cbc:Description", nodeItem, XPathConstants.STRING));

                        detalle.setMontoBruto(ComprobanteUtilBean.formatTwoDecimal((String) xpath.evaluate("cbc:LineExtensionAmount", nodeItem, XPathConstants.STRING)));

                        Object oTotalImpuesto = (String) xpath.evaluate("cac:TaxTotal/cbc:TaxAmount", nodeItem, XPathConstants.STRING);

                        detalle.setTotalImpuestos(ComprobanteUtilBean.isNumber(oTotalImpuesto) ? ComprobanteUtilBean.formatTwoDecimal((String) oTotalImpuesto) : "0");

                        // Object oDescuento = xpath.evaluate("cac:AllowanceCharge/cbc:Amount", nodeItem, XPathConstants.STRING);
                        //detalle.setDescuentoMonto((ComprobanteUtilBean.isNumber(oDescuento) ? ComprobanteUtilBean.formatTwoDecimal((String)oDescuento) : "0"));
                        detalle.setIgvMonto("0");
                        detalle.setIscMonto("0");
                        detalle.setOtroMonto("0");

                        NodeList nodeTaxSubTotals = (NodeList) xpath.evaluate("cac:TaxTotal/cac:TaxSubtotal", nodeItem, XPathConstants.NODESET);
                        log.debug("nodeTaxSubTotals.getLength(): " + nodeTaxSubTotals.getLength());//naa
                        for (int j = 0; j < nodeTaxSubTotals.getLength(); j++) {
                            log.debug("paso12 ");//naa
                            Node nodeTaxSubTotal = (Node) nodeTaxSubTotals.item(j);
                            String tributo = (String) xpath.evaluate("cac:TaxCategory/cbc:ID", nodeTaxSubTotal, XPathConstants.STRING);
                            log.debug("tributo: " + tributo);//naa
                            if (tributo.equals(ComprobanteUtilBean.IGV)) {
                                detalle.setIgvMonto(ComprobanteUtilBean.formatTwoDecimal((String) xpath.evaluate("cbc:TaxAmount", nodeTaxSubTotal, XPathConstants.STRING)));
                            } else if (tributo.equals(ComprobanteUtilBean.ISC)) {
                                detalle.setIscMonto(ComprobanteUtilBean.formatTwoDecimal((String) xpath.evaluate("cbc:TaxAmount", nodeTaxSubTotal, XPathConstants.STRING)));
                            } else {
                                //detalle.setOtroMonto(ComprobanteUtilBean.formatTwoDecimal((String)xpath.evaluate("cbc:TaxAmount", nodeTaxSubTotal, XPathConstants.STRING)));
                            }
                        }
                    }
                    aDetalleComprobante.add(detalle);
                }
                comprobante.setDetalleComprobanteBean(aDetalleComprobante);
                log.debug("paso13 ");//naa
            }

        } catch (ServiceException e) {
            log.error(e, e);
            log.error(e.getLocalizedMessage());
            throw e;
        } catch (Exception e) {
            log.error(e, e);
            throw new ServiceException(this, e.getLocalizedMessage());
        }
        return comprobante;
    }

    /**
     * Genera el ComprobanteBean a partir de la version 1.1 o 1.0 de la
     * estructura del documento XMl.
     *
     * @param doc
     * @param xpath
     * @return
     */
    private ComprobanteBean generaComprobantePortalV1(Document doc, XPath xpath) {

        if (log.isInfoEnabled()) {
            log.info(">> Genera comprobante Nota de credito PORTAL V1.0");
        }

        ComprobanteBean comprobante = new ComprobanteBean();
        // inicializando en valores  por defecto por ser  numericos
        comprobante.setTotalValorVenta(new BigDecimal(0.00));
        comprobante.setTotalDescuentos(new BigDecimal(0.00));
        comprobante.setTotalIGV(new BigDecimal(0.00));
        comprobante.setTotalISC(new BigDecimal(0.00));
        comprobante.setTotalOtrosCargos(new BigDecimal(0.00));
        comprobante.setTotalOtrosTributos(new BigDecimal(0.00));
        comprobante.setMontoDescuentos(new BigDecimal(0.00));
        comprobante.setMontoImpuestos(new BigDecimal(0.00));
        comprobante.setMontoSubTotal(new BigDecimal(0.00));
        comprobante.setMontoTotalGeneral(new BigDecimal(0.00));

        try {
            String nm = this.getMainNodeValue();
            String id = (String) xpath.evaluate(nm + "/cbc:ID", doc, XPathConstants.STRING);
            log.debug("generaComprobanteBean " + doc);//naa
            log.debug("xpath:" + xpath);//naa
            log.debug("id: " + id);//naa
            log.debug("id pos : " + id.substring(id.indexOf("-")));//naa
            comprobante.setNumeroComprobante(new Integer(id.substring(id.indexOf("-") + 1)));
            comprobante.setSerieComprobante(id.substring(0, id.indexOf("-")));
            comprobante.setNumeroRuc((String) xpath.evaluate(nm + "/cac:AccountingSupplierParty/cbc:CustomerAssignedAccountID", doc, XPathConstants.STRING));
            String tipoNota = (String) xpath.evaluate(nm + "/cac:DiscrepancyResponse/cbc:ResponseCode", doc, XPathConstants.STRING);
            if ("21".equals(tipoNota)) {
                comprobante.setGlosa("Anulaci�n de la Operaci�n");
            }
            if ("22".equals(tipoNota)) {
                comprobante.setGlosa("Anulaci�n por Error en el RUC");
            }
            if ("23".equals(tipoNota)) {
                comprobante.setGlosa("Descuento Global");
            }
            if ("24".equals(tipoNota)) {
                comprobante.setGlosa("Devoluci�n Total");
            }
            if ("25".equals(tipoNota)) {
                comprobante.setGlosa("Correcci�n por Error en la Descripci�n");
            }
            if ("26".equals(tipoNota)) {
                comprobante.setGlosa("Devoluci�n por Item");
            }
            if ("27".equals(tipoNota)) {
                comprobante.setGlosa("Descuento por Item");
            }

            FechaBean fb = new FechaBean((String) xpath.evaluate(nm + "/cbc:IssueDate", doc, XPathConstants.STRING), "yyyy-MM-dd");
            comprobante.setFechaEmision(fb.getFormatDate("dd/MM/yyyy"));
            fb.setFecha((String) xpath.evaluate(nm + "/cbc:IssueTime", doc, XPathConstants.STRING), "HH:mm:ss");
            comprobante.setHoraEmision(fb.getFormatDate("HH:mm:ss"));
            comprobante.setObservacion((String) xpath.evaluate(nm + "/cbc:Note", doc, XPathConstants.STRING));
            String documoriginal = (String) xpath.evaluate(nm + "/cac:DiscrepancyResponse/cbc:ReferenceID", doc, XPathConstants.STRING);
            comprobante.setSerieDocumentoPorElQueSeEmite((documoriginal.substring(0, documoriginal.indexOf("-"))).trim());
            comprobante.setNumeroDocumentoPorElQueSeEmite((documoriginal.substring(documoriginal.indexOf("-") + 1)).trim());

            //comprobante.set
            log.debug("paso0 ");//naa
            String subtipo = (String) xpath.evaluate(nm + "/cac:DiscrepancyResponse/cbc:ResponseCode", doc, XPathConstants.STRING);
            comprobante.setSubTipoComprobante(subtipo);
            log.debug("VALOR DE  SUBTIPO:" + subtipo);//naa
            //MPCR buscar tag para monto en letras
            //comprobante.setMontoTotalTexto((String)xpath.evaluate(nm + "/cbc:Note", doc, XPathConstants.STRING));

            log.debug("paso1 ");//naa

            String s2 = (String) xpath.evaluate(nm + "/ext:UBLExtensions/ext:UBLExtension/ext:ExtensionContent/sac:AdditionalInformationInvoice/sac:AdditionalInvoiceProperty/cbc:Value", doc, XPathConstants.STRING);
            log.debug(" s2:" + s2);//naa

            comprobante.setMontoTotalTexto(s2);
            log.debug("saliendo de paso1 ");//naa
////////////////////
            NodeList nodeExtensiones = (NodeList) xpath.evaluate(nm + "/ext:UBLExtensions/ext:UBLExtension/ext:ExtensionContent", doc, XPathConstants.NODESET);

            if (nodeExtensiones.getLength() > 0) {
                Node nodeItem = null;
                for (int i = 0; i < nodeExtensiones.getLength(); i++) {
                    nodeItem = (Node) nodeExtensiones.item(i);
                    String codNodo = "";
                    NodeList nodeProperties = (NodeList) xpath.evaluate("sac:AdditionalInformation/sac:AdditionalMonetaryTotal", nodeItem, XPathConstants.NODESET);
                    if (nodeProperties.getLength() > 0) {
                        for (int j = 0; j < nodeProperties.getLength(); j++) {

                            codNodo = (String) xpath.evaluate("cbc:ID", nodeProperties.item(j), XPathConstants.STRING);

                            if (codNodo != null) {
                                if (codNodo.equals("1004")) {
                                    comprobante.setTotalValorVentaOperaGratuitas(ComprobanteUtilBean.toBigDecimal((String) xpath.evaluate("cbc:PayableAmount", nodeProperties.item(j), XPathConstants.STRING)));
                                }
                                if (codNodo.equals("1005")) {
                                    comprobante.setTotalSubTotalValorVenta(ComprobanteUtilBean.toBigDecimal((String) xpath.evaluate("cbc:PayableAmount", nodeProperties.item(j), XPathConstants.STRING)));
                                }
                            }
                        }
                    }
                }

            }
////////////////////			

            NodeList nlGuias = (NodeList) xpath.evaluate(nm + "/cac:DespatchDocumentReference", doc, XPathConstants.NODESET);
            NodeList nlOtrosDocs = (NodeList) xpath.evaluate(nm + "/cac:AdditionalDocumentReference", doc, XPathConstants.NODESET);
            log.debug("paso2 ");//naa
            if (nlGuias.getLength() > 0 || nlOtrosDocs.getLength() > 0) {

                log.debug("paso3 ");//naa	
                int lengthArray = nlGuias.getLength() + nlOtrosDocs.getLength();
                List<OtroDocumentoRelacionadoBean> aOtrosDocs = new ArrayList<OtroDocumentoRelacionadoBean>();
                OtroDocumentoRelacionadoBean docRel = null;
                log.debug("paso4 ");//naa
                for (int j = 0, x = 0, y = 0; j < lengthArray; j++) {
                    Node nodeItem = (j < nlGuias.getLength() ? (Node) nlGuias.item(x++) : (Node) nlOtrosDocs.item(y++));
                    docRel = new OtroDocumentoRelacionadoBean();
                    docRel.setTipoDocumentoRelacionado((String) xpath.evaluate("cbc:cbc:DocumentTypeCode", nodeItem, XPathConstants.STRING));
                    docRel.setDesTipoDocuRela((String) xpath.evaluate("cbc:DocumentType", nodeItem, XPathConstants.STRING));
                    docRel.setNumeroDocumentoRelacionadoInicial((String) xpath.evaluate("cbc:ID", nodeItem, XPathConstants.STRING));
                    aOtrosDocs.add(docRel);

                }
                log.debug("paso5 ");//naa
                comprobante.setOtroDocumentoRelacionadoBean(aOtrosDocs);
            }
            /**
             * --------------------------------------------------
             */
            log.debug("paso6 ");//naa
//			comprobante.setRazonSocial((String)xpath.evaluate(nm + "/cac:AccountingSupplierParty/cac:Party/cac:PartyName/cbc:Name", doc, XPathConstants.STRING));
            comprobante.setRazonComercial((String) xpath.evaluate(nm + "/cac:AccountingSupplierParty/cac:Party/cac:PartyName/cbc:Name", doc, XPathConstants.STRING));
            comprobante.setRazonSocial((String) xpath.evaluate(nm + "/cac:AccountingSupplierParty/cac:Party/cac:PartyLegalEntity/cbc:RegistrationName", doc, XPathConstants.STRING));

            //comprobante.setUbigeoEmisor((String)xpath.evaluate(nm + "/cac:AccountingSupplierParty/cac:Party/cac:PostalAddress/cbc:ID", doc, XPathConstants.STRING));
            //comprobante.setNombreCalle((String)xpath.evaluate(nm + "/cac:AccountingSupplierParty/cac:Party/cac:PostalAddress/cbc:StreetName", doc, XPathConstants.STRING));
            comprobante.setUbigeoEmisor((String) xpath.evaluate(nm + "/cac:AccountingSupplierParty/cac:Party/cac:RegistrationAddress/cbc:ID", doc, XPathConstants.STRING));
            comprobante.setNombreCalle((String) xpath.evaluate(nm + "/cac:AccountingSupplierParty/cac:Party/cac:PartyLegalEntity/cac:RegistrationAddress/cbc:StreetName", doc, XPathConstants.STRING));
            //	/cac:AccountingSupplierParty/cac:Party/cac:PartyLegalEntity/cac:RegistrationAddress/
            /////comprobante.setNumeroDireccion((String)xpath.evaluate(nm + "/cac:AccountingSupplierParty/cac:Party/cac:PostalAddress/cbc:BuildingNumber", doc, XPathConstants.STRING));
            comprobante.setNombreDistrito((String) xpath.evaluate(nm + "/cac:AccountingSupplierParty/cac:Party/cac:PartyLegalEntity/cac:RegistrationAddress/cbc:District", doc, XPathConstants.STRING));
            comprobante.setNombreProvincia((String) xpath.evaluate(nm + "/cac:AccountingSupplierParty/cac:Party/cac:PartyLegalEntity/cac:RegistrationAddress/cbc:CountrySubentity", doc, XPathConstants.STRING));
            comprobante.setNombreDepartamento((String) xpath.evaluate(nm + "/cac:AccountingSupplierParty/cac:Party/cac:PartyLegalEntity/cac:RegistrationAddress/cbc:CityName", doc, XPathConstants.STRING));
            comprobante.setCodigoPais((String) xpath.evaluate(nm + "/cac:AccountingSupplierParty/cac:Party/cac:PartyLegalEntity/cac:RegistrationAddress/cac:Country/cbc:IdentificationCode", doc, XPathConstants.STRING));

            comprobante.setNumeroDocumentoCliente((String) xpath.evaluate(nm + "/cac:AccountingCustomerParty/cbc:CustomerAssignedAccountID", doc, XPathConstants.STRING));
            comprobante.setTipoDocumentoCliente((String) xpath.evaluate(nm + "/cac:AccountingCustomerParty/cbc:AdditionalAccountID", doc, XPathConstants.STRING));
            String descdoc = "-";
            if ("06".equals(comprobante.getTipoDocumentoCliente()) || "6".equals(comprobante.getTipoDocumentoCliente())) {
                descdoc = "RUC";
            } else if ("01".equals(comprobante.getTipoDocumentoCliente()) || "1".equals(comprobante.getTipoDocumentoCliente())) {
                descdoc = "DNI";
            } else if ("04".equals(comprobante.getTipoDocumentoCliente()) || "4".equals(comprobante.getTipoDocumentoCliente())) {
                descdoc = "CARNET EXTRANJERIA";
            } else if ("07".equals(comprobante.getTipoDocumentoCliente()) || "7".equals(comprobante.getTipoDocumentoCliente())) {
                descdoc = "PASAPORTE";
            }
            comprobante.setDesTipoDocumentoCliente(descdoc);
            comprobante.setNombreCliente((String) xpath.evaluate(nm + "/cac:AccountingCustomerParty/cac:Party/cac:PartyLegalEntity/cbc:RegistrationName", doc, XPathConstants.STRING));
            //comprobante.setNombreCliente((String)xpath.evaluate(nm + "/cac:AccountingCustomerParty/cac:Party/cac:PartyName/cbc:Name", doc, XPathConstants.STRING));
            comprobante.setTotalValorVenta(ComprobanteUtilBean.toBigDecimal((String) xpath.evaluate(nm + "/cac:LegalMonetaryTotal/cbc:LineExtensionAmount", doc, XPathConstants.STRING)));
            //comprobante.setTotalDescuentos(ComprobanteUtilBean.toBigDecimal((String)xpath.evaluate(nm + "/cac:LegalMonetaryTotal/cbc:AllowanceTotalAmount", doc, XPathConstants.STRING)));
            if (comprobante.getSubTipoComprobante() != null && !comprobante.getSubTipoComprobante().trim().equals("23")) {
                comprobante.setTotalDescuentos(ComprobanteUtilBean.toBigDecimal((String) xpath.evaluate(nm + "/cac:LegalMonetaryTotal/cbc:ChargeTotalAmount", doc, XPathConstants.STRING)));

            }
            comprobante.setMontoTotalGeneral(ComprobanteUtilBean.toBigDecimal((String) xpath.evaluate(nm + "/cac:LegalMonetaryTotal/cbc:PayableAmount", doc, XPathConstants.STRING)));
            log.debug("paso7 ");//naa
            NodeList nodeOtrosTot = (NodeList) xpath.evaluate(nm + "/cac:TaxTotal/cac:TaxSubtotal", doc, XPathConstants.NODESET);
            log.debug("paso8 ");//naa
            if (nodeOtrosTot.getLength() > 0) {

                String nombre = "";
                String monto = "";
                String porcentaje = "";
                Node nodeItem = null;
                for (int i = 0; i < nodeOtrosTot.getLength(); i++) {
                    nodeItem = (Node) nodeOtrosTot.item(i);
                    log.debug("paso9 ");//naa
                    nombre = (String) xpath.evaluate("cac:TaxCategory/cac:TaxScheme/cbc:Name", nodeItem, XPathConstants.STRING);
                    monto = (String) xpath.evaluate("cbc:TaxAmount", nodeItem, XPathConstants.STRING);
                    porcentaje = (String) xpath.evaluate("cbc:Percent", nodeItem, XPathConstants.STRING);
                    log.debug("nombre:" + nombre + " monto:" + monto + " porcetaje:" + porcentaje);

                    if ("ISC".equals(nombre.trim().toUpperCase())) {
                        comprobante.setTotalISC(ComprobanteUtilBean.toBigDecimal(monto));
                    }
                    if ("IGV".equals(nombre.trim().toUpperCase())) {
                        comprobante.setIgvPorcentaje(ComprobanteUtilBean.toBigDecimal(porcentaje));
                        comprobante.setTotalIGV(ComprobanteUtilBean.toBigDecimal(monto));
                    }
                    if ("OTROS CARGOS".equals(nombre.trim().toUpperCase())) {
                        comprobante.setTotalOtrosCargos(ComprobanteUtilBean.toBigDecimal(monto));
                    }
                    if ("OTROS TRIBUTOS".equals(nombre.trim().toUpperCase())) {
                        comprobante.setTotalOtrosTributos(ComprobanteUtilBean.toBigDecimal(monto));
                    }
                }
            }
            log.debug("paso10 ");//naa

            /// DETALLE DE LA NOTA DE CREDITO
            comprobante.setCodigoMoneda((String) xpath.evaluate(nm + "/cac:LegalMonetaryTotal/cbc:PayableAmount/@currencyID", doc, XPathConstants.STRING));

            NodeList nlItems = (NodeList) xpath.evaluate(nm + "/cac:CreditNoteLine", doc, XPathConstants.NODESET);
            if (nlItems.getLength() > 0) {
                List<DetalleComprobanteBean> aDetalleComprobante = new ArrayList<DetalleComprobanteBean>();
                DetalleComprobanteBean detalle = null;
                for (int i = 0; i < nlItems.getLength(); i++) {
                    log.debug("paso11 ");//naa
                    Node nodeItem = (Node) nlItems.item(i);
                    detalle = new DetalleComprobanteBean();
                    if (i == 0) {
                        // MPCR ya no va, se puso en cbc not de la cabecera
                        //comprobante.setObservacion((String)xpath.evaluate("cbc:Note", nodeItem, XPathConstants.STRING));						 
                    }

                    detalle.setIdentificador(Integer.parseInt((String) xpath.evaluate("cbc:ID", nodeItem, XPathConstants.STRING)));
                    detalle.setNumeroLinea(Integer.parseInt((String) xpath.evaluate("cbc:ID", nodeItem, XPathConstants.STRING)));
                    detalle.setIdentificadorOriginal(Integer.parseInt((String) xpath.evaluate("cbc:ID", nodeItem, XPathConstants.STRING)));
                    if (comprobante.getSubTipoComprobante() != null && comprobante.getSubTipoComprobante().trim().equals("23")) {

                        detalle.setCodigoItem((String) xpath.evaluate("cac:Item/cac:CatalogueDocumentReference/cbc:ID", nodeItem, XPathConstants.STRING));
                        if (detalle.getCodigoItem() == null) {
                            detalle.setCodigoItem("");
                        }
                        detalle.setDescripcion((String) xpath.evaluate("cac:Item/cbc:Description", nodeItem, XPathConstants.STRING));
                        detalle.setIgvMonto("0");
                        detalle.setIscMonto("0");
                        detalle.setOtroMonto("0");
                        //detalle.setPrecioUnitario("0"); 
                        detalle.setUnidadMedida("-");

                    } else {
                        detalle.setUnidadMedida((String) xpath.evaluate("cbc:CreditedQuantity/@unitCode", nodeItem, XPathConstants.STRING));
                        detalle.setCantidad(ComprobanteUtilBean.formatTwoDecimal((String) xpath.evaluate("cbc:CreditedQuantity", nodeItem, XPathConstants.STRING)));
                        detalle.setPrecioUnitario(ComprobanteUtilBean.formatTwoDecimal((String) xpath.evaluate("cac:Price/cbc:PriceAmount", nodeItem, XPathConstants.STRING)));

                        detalle.setCodigoItem((String) xpath.evaluate("cac:Item/cac:CatalogueDocumentReference/cbc:ID", nodeItem, XPathConstants.STRING));
                        detalle.setDescripcion((String) xpath.evaluate("cac:Item/cbc:Description", nodeItem, XPathConstants.STRING));

                        detalle.setMontoBruto(ComprobanteUtilBean.formatTwoDecimal((String) xpath.evaluate("cbc:LineExtensionAmount", nodeItem, XPathConstants.STRING)));

                        Object oTotalImpuesto = (String) xpath.evaluate("cac:TaxTotal/cbc:TaxAmount", nodeItem, XPathConstants.STRING);

                        detalle.setTotalImpuestos(ComprobanteUtilBean.isNumber(oTotalImpuesto) ? ComprobanteUtilBean.formatTwoDecimal((String) oTotalImpuesto) : "0");

                        // Object oDescuento = xpath.evaluate("cac:AllowanceCharge/cbc:Amount", nodeItem, XPathConstants.STRING);
                        //detalle.setDescuentoMonto((ComprobanteUtilBean.isNumber(oDescuento) ? ComprobanteUtilBean.formatTwoDecimal((String)oDescuento) : "0"));
                        detalle.setIgvMonto("0");
                        detalle.setIscMonto("0");
                        detalle.setOtroMonto("0");

                        NodeList nodeTaxSubTotals = (NodeList) xpath.evaluate("cac:TaxTotal/cac:TaxSubtotal", nodeItem, XPathConstants.NODESET);
                        log.debug("nodeTaxSubTotals.getLength(): " + nodeTaxSubTotals.getLength());//naa
                        for (int j = 0; j < nodeTaxSubTotals.getLength(); j++) {
                            log.debug("paso12 ");//naa
                            Node nodeTaxSubTotal = (Node) nodeTaxSubTotals.item(j);
                            String tributo = (String) xpath.evaluate("cac:TaxCategory/cbc:ID", nodeTaxSubTotal, XPathConstants.STRING);
                            log.debug("tributo: " + tributo);//naa
                            if (tributo.equals(ComprobanteUtilBean.IGV)) {
                                detalle.setIgvMonto(ComprobanteUtilBean.formatTwoDecimal((String) xpath.evaluate("cbc:TaxAmount", nodeTaxSubTotal, XPathConstants.STRING)));
                            } else if (tributo.equals(ComprobanteUtilBean.ISC)) {
                                detalle.setIscMonto(ComprobanteUtilBean.formatTwoDecimal((String) xpath.evaluate("cbc:TaxAmount", nodeTaxSubTotal, XPathConstants.STRING)));
                            } else {
                                //detalle.setOtroMonto(ComprobanteUtilBean.formatTwoDecimal((String)xpath.evaluate("cbc:TaxAmount", nodeTaxSubTotal, XPathConstants.STRING)));
                            }
                        }
                    }
                    aDetalleComprobante.add(detalle);
                }
                comprobante.setDetalleComprobanteBean(aDetalleComprobante);
                log.debug("paso13 ");//naa
            }

        } catch (ServiceException e) {
            log.error(e);
            e.printStackTrace();
            log.error(e.getLocalizedMessage());

            throw e;
        } catch (Exception e) {
            log.error(e);
            e.printStackTrace();
            throw new ServiceException(this, e.getLocalizedMessage());
        }
        return comprobante;
    }

}
