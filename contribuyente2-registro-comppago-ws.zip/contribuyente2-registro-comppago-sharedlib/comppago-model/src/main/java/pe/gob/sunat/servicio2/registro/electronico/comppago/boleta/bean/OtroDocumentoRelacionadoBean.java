package pe.gob.sunat.servicio2.registro.electronico.comppago.boleta.bean;

import java.io.Serializable;
import java.sql.Timestamp;

import pe.gob.sunat.framework.spring.util.date.FechaBean;

/**
 * POJO de datos de otros documentos relacionados como
 * guias, scop, detracciones.
 * Ambito: Base de datos.
 * @author Carlos Enrique Quispe Salazar
 * DespatchDocumentReference
 * AdditionalDocumentReference
 * AdditionalDocumentReference
 **/

public class OtroDocumentoRelacionadoBean implements Serializable {
	private static final long serialVersionUID = 1L;
	private String identificador;
	private String numeroRuc;
	private String tipoComprobante;
	private String serieComprobante;
	private Integer numeroComprobante;
	
	/** Cuando son Guias, SCOP, Detracciones. */
	private Integer numeroCorrelativo;
	private String tipoDocumentoRelacionado;
	private String serieDocumentoRelacionado;
	private String desTipoDocuRela;
	private String numeroDocumentoRelacionadoInicial;
	private String numeroDocumentoRelacionadoFinal;
	
	private String codigoUsuarioModificador;
	private String fechaEmision;

	private String fechaModificacion;
	private String horaModificacion;
	
	public String getFechaEmision() {
		return fechaEmision;
	}

	public void setFechaEmision(String fechaEmision) {
		this.fechaEmision = fechaEmision;
	}

	public String getIdentificador() {
		return identificador;
	}

	public void setIdentificador(String identificador) {
		this.identificador = identificador;
	}
	
	public String getNumeroRuc() {
		return numeroRuc;
	}
	
	public void setNumeroRuc(String numeroRuc) {
		this.numeroRuc = numeroRuc;
	}
	
	public String getTipoComprobante() {
		return tipoComprobante;
	}
	
	public void setTipoComprobante(String tipoComprobante) {
		this.tipoComprobante = tipoComprobante;
	}
	
	public String getDesTipoDocuRela() {
		return desTipoDocuRela;
	}

	public void setDesTipoDocuRela(String desTipoDocuRela) {
		this.desTipoDocuRela = desTipoDocuRela;
	}

	public String getSerieComprobante() {
		return serieComprobante;
	}
	
	public void setSerieComprobante(String serieComprobante) {
		this.serieComprobante = serieComprobante;
	}
	
	public Integer getNumeroComprobante() {
		return numeroComprobante;
	}
	
	public void setNumeroComprobante(Integer numeroComprobante) {
		this.numeroComprobante = numeroComprobante;
	}

	public Integer getNumeroCorrelativo() {
		return numeroCorrelativo;
	}

	public void setNumeroCorrelativo(Integer numeroCorrelativo) {
		this.numeroCorrelativo = numeroCorrelativo;
	}

	public String getTipoDocumentoRelacionado() {
		return tipoDocumentoRelacionado;
	}

	public void setTipoDocumentoRelacionado(String tipoDocumentoRelacionado) {
		this.tipoDocumentoRelacionado = tipoDocumentoRelacionado;
	}

	public String getNumeroDocumentoRelacionadoInicial() {
		return numeroDocumentoRelacionadoInicial;
	}

	public void setNumeroDocumentoRelacionadoInicial(
			String numeroDocumentoRelacionadoInicial) {
		this.numeroDocumentoRelacionadoInicial = numeroDocumentoRelacionadoInicial;
	}

	public String getNumeroDocumentoRelacionadoFinal() {
		return numeroDocumentoRelacionadoFinal;
	}

	public void setNumeroDocumentoRelacionadoFinal(
			String numeroDocumentoRelacionadoFinal) {
		this.numeroDocumentoRelacionadoFinal = numeroDocumentoRelacionadoFinal;
	}

	public String getCodigoUsuarioModificador() {
		return codigoUsuarioModificador;
	}

	public void setCodigoUsuarioModificador(String codigoUsuarioModificador) {
		this.codigoUsuarioModificador = codigoUsuarioModificador;
	}

	public String getFechaModificacion() {
		return fechaModificacion;
	}

	public void setFechaModificacion(String fechaModificacion) {
		this.fechaModificacion = fechaModificacion;
	}

	public String getHoraModificacion() {
		return horaModificacion;
	}

	public void setHoraModificacion(String horaModificacion) {
		this.horaModificacion = horaModificacion;
	}
	
	public Timestamp getFechaHoraModificacion() {
		if(this.getFechaModificacion() == null || this.getHoraModificacion() == null) return null;
		FechaBean fb = new FechaBean(this.getFechaModificacion() + "-" + this.getHoraModificacion(), "dd/MM/yyyy-HH:mm:ss");
		return fb.getTimestamp();
	}

	public String getSerieDocumentoRelacionado() {
		return serieDocumentoRelacionado;
	}

	public void setSerieDocumentoRelacionado(String serieDocumentoRelacionado) {
		this.serieDocumentoRelacionado = serieDocumentoRelacionado;
	}
	
	public String toString(){
		StringBuilder datos = new StringBuilder();

    	datos.append("Documento Relacionado :").append("\n");
    	datos.append("Tipo Comprobante                     : " + (this.getTipoComprobante()!= null ? getTipoComprobante() : "null")).append("\n");
    	datos.append("Serie Comprobante                    : " + (this.getSerieComprobante()!= null ? getSerieComprobante() : "null")).append("\n");
    	datos.append("Numero Comprobante                   : " + (this.getNumeroComprobante()!= null ? getNumeroComprobante() : "null")).append("\n");
    	datos.append("Tipo Documento Relacionado           : " + (this.getTipoDocumentoRelacionado() != null ? getTipoDocumentoRelacionado() : "null")).append("\n");
    	datos.append("Serie Documento Relacionado          : " + (this.getSerieDocumentoRelacionado() != null ? getSerieDocumentoRelacionado() : "null")).append("\n");
    	datos.append("Numero Documento Relacionado Inicial : " + (this.getNumeroDocumentoRelacionadoInicial() != null ? getNumeroDocumentoRelacionadoInicial() : "null")).append("\n");
    	datos.append("Numero Documento Relacionado Final   : " + (this.getNumeroDocumentoRelacionadoFinal() != null ? getNumeroDocumentoRelacionadoFinal() : "null")).append("\n");
		return datos.toString();
	}
}
