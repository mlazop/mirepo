
package pe.gob.sunat.servicio2.registro.electronico.comppago.boleta.bean;

import java.beans.BeanInfo;
import java.beans.Introspector;
import java.beans.PropertyDescriptor;
import java.io.Serializable;
import java.lang.reflect.Method;
import java.math.BigDecimal;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import com.fasterxml.jackson.annotation.JsonIgnore;

import pe.gob.sunat.framework.spring.util.date.FechaBean;

/**
 * POJO que contiene el comprobante.
 * Ambito: XML y Base de datos.
 * @author Carlos Enrique Quispe Salazar
 * */
public class ComprobanteBean implements Serializable {
	@JsonIgnore
	protected final Log log = LogFactory.getLog(getClass());

	private static final long serialVersionUID = -5025969711520530977L;
	
	private String numeroRuc;				/** supplierID */
	private String razonSocial;
	private String razonComercial;
	private String tipoComprobante;			/** InvoiceTypeCode */
	private String tipoComprobanteDesc;
	private String serieComprobante;		/** ID */
	private Integer numeroComprobante;		/** ID */
		
	private String subTipoComprobante;		/** InvoiceTypeCode, complementando el tipo de comprobante */
	private String subTipoComprobanteTmp ;

	private String ubigeoEmisor;			/** postalAddres-ID */
	private Short codigoEstablecimiento;	/** PhisicalLocation-ID */
	private String nombreCalle;				/** streetName */
	private String nombreUrbanizacion ; 			/** cbc:CitySubdivisionName para GEM */
	private String numeroDireccion;			/** buildingNumber */
	private String nombreDistrito;			/** District */
	private String nombreProvincia;			/** cityName */
	private String nombreDepartamento;		/** CountrySubentityCode y countrySubentity */
	private String codigoPais;				/** countryIdentification */
	private String direccionCompleta ; 		/** Concadenacion de calle,urbanizacion,distrito, etc. */
	
	private String codigoMoneda;			/** currencyID */
	private String descripcionMoneda;
	private String simboloMoneda;

	private String fechaEmision;			/** issueDate */
	private String fechaEmisionOriginal;			
	/** issueDate */
	private String horaEmision;				/** issueTime */

	private String fechaRegistro;			/** issueDate */
	private String horaRegistro;			/** issueTime */
	
	private String fechaAceptada;
	private String horaAceptada;
	
	private String fechaRechazo;
	private String horaRechazo;

	private String tipoDocumentoCliente;	/** AdditionalAccountID */
	private String desTipoDocumentoCliente;
	private String numeroDocumentoCliente;	/** customerID */
	private String nombreCliente;			/** customerName */
	
	private String codigoFormaPago;
	private String descripcionFormaPago;
	private String observacion;
	private String bonificacion;
	private String glosa;

	private String identificadorFirma;		/** signatureID */
	private String idFirmante;

	private String nombreFirmante;			/** signatureParty */
	private String referenciaFirma;			/** signatureReference */

	private BigDecimal montoTotalGeneral;	/** payableamount */
	private BigDecimal montoSubTotal;		/** lineextensionamount */
	private BigDecimal montoDescuentos;		/** taxtotal y taxexclusiveamount */
	private BigDecimal montoImpuestos;		/** taxtotal y taxexclusiveamount */
	private BigDecimal saldoReferencial;	/** lineextensionamount */
	private String montoTotalTexto;			/** Monto total en letras */
	private String numeroDocumentoPorElQueSeEmite; /** Serie y numero del documento que modifica */
	private String descTipoDocQueModifica ; 		/** Descripcion del tipo de documento qu emodifica */
	private String serieDocumentoPorElQueSeEmite;
	
	private String indicadorAceptada;
	private String indicadorRechazo;
	private String indicadorMedioRegistro;

	private String codigoDependecia;
	private Short anioRegistro;
	private Long numeroIndice;
	private String codigoUsuarioModificador;
	private String fechaModificacion;
	private String horaModificacion;
	
	private String fechaVencimiento;
	
	private String numeroExpediente;
	private String ordenCompra;
	private String numeroProcesoSeleccion;
	private String numeroContrato;
	private String codigoUnidadEjecutora;
	
	/**20100215 ecg */
	private String codigoSitEspecial;
	private BigDecimal totalDescuentos;
	private BigDecimal totalAnticipos;
	private BigDecimal totalISC;
	private BigDecimal totalIGV;
	private BigDecimal totalOtrosCargos;
	private BigDecimal totalOtrosTributos;
	private BigDecimal totalValorVenta;	//  Gravada
	private BigDecimal totalSubTotalValorVenta;	
	/* Ini JCZ */
	private BigDecimal totalValorVentaNoGravado ; 	// No gravado � inafecta
	private BigDecimal totalValorVentaExonerado ;	// Exonerado
	private BigDecimal totalValorVentaInafecto ;	// Inafecto
	private BigDecimal importeDePercepcion ;
	private List<Map<String,String>> leyenda ;	// llaves "id" y "valor"
	private String codigoGuiaRemision ;	// Guia de remision	
	/* Fin JCZ */
	private Long numeroIndiceCabMov;
	private String correoPrincipal;
	private String correoSecundario;
	private BigDecimal igvPorcentaje;
	private String motivoEmisionNota;

	private Integer countUnidadMedidaItem;
	private Integer countCodigoItem;
	private Integer countOtrosCargosTributos;	
	private String indicadorVentaNodomic;
	private String descripcionVentaNoDomic;
	private String descripcionVentaGratuita;
	private String indicadorExportacion;
	private String indicadorProveedorEstado;
	private String indicadorPagoAnticipado;
	
	//Totales para RVI
	private BigDecimal totalInafOner;
	private BigDecimal totalExoOner ;
	private BigDecimal totalGravOner;	
	private BigDecimal totalInafGrat;
	private BigDecimal totalExoGrat;
	private BigDecimal totalGravGrat;			
	private BigDecimal totalValorVentaOperaGratuitas;	
	private BigDecimal totalTributosCargosOperaGratuitas ;
	private BigDecimal totalImporteTributosCargosOperaGratuitas ;
	private BigDecimal totalISCOperaGratuitas ;
	private BigDecimal totalIGVOperaGratuitas ;
		
	//Fin Totales para RVI

	//Datos para FE de No domiciliados
	private String nacionalidadNoDomiciliado;
	private String nacionalidadNoDomiciliadoDesc;
	private String tamNoDomiciliado;
	private String fechaIngresoPaisNoDomiciliado;
	private String tipoTarjetaNoDomiciliado;
	private String numeroTarjetaNoDomiciliado;
	private String bancoTarjetaNoDomiciliado;
	private String bancoTarjetaNoDomiciliadoDesc;
	private String numeroSuscripcionNoDomic;
	private Integer numeroFirma;		
	
	//* para domicilios adicionales
	private String indicadorEstabEmisor;	
	private String indicadorEstabEmisorEfectuaEmision;
	private String indicadorEstabEmisorRelacionDependencia;	
	private String indicadorDomicilioCliente;
	private String indicadorTrasladoBienes;
	private DireccionComprobanteBean estabEmisor;
	private DireccionComprobanteBean domicilioCliente;
	private DireccionComprobanteBean puntoPartida;
	private DireccionComprobanteBean puntoLlegada;

	private String indicadorSujetoRealizaTraslado;
	private String indicadorModalidadTraslado;
	private String placaVehiculo;
	private String marcaVehiculo;
	private String nroLicenciaConducir;
	private String rucTransportista;
	private String razonSocialTransportista;
	
	
	//
	//	private DetalleComprobanteBean detalleComprobanteBean[];
	private List<DetalleComprobanteBean> detalleComprobanteBean;
	private ArchivoComprobanteBean archivoComprobanteBean;
	private List<DocumentoRelacionadoBean> documentoRelacionadoBean;
	private List<OtroDocumentoRelacionadoBean> otroDocumentoRelacionadoBean;
	private double versionXML ;
	
	
	public String getIndicadorSujetoRealizaTraslado() {
		return indicadorSujetoRealizaTraslado;
	}

	public void setIndicadorSujetoRealizaTraslado(
			String indicadorSujetoRealizaTraslado) {
		this.indicadorSujetoRealizaTraslado = indicadorSujetoRealizaTraslado;
	}

	public String getIndicadorModalidadTraslado() {
		return indicadorModalidadTraslado;
	}

	public void setIndicadorModalidadTraslado(String indicadorModalidadTraslado) {
		this.indicadorModalidadTraslado = indicadorModalidadTraslado;
	}

	public String getPlacaVehiculo() {
		return placaVehiculo;
	}

	public void setPlacaVehiculo(String placaVehiculo) {
		this.placaVehiculo = placaVehiculo;
	}

	public String getMarcaVehiculo() {
		return marcaVehiculo;
	}

	public void setMarcaVehiculo(String marcaVehiculo) {
		this.marcaVehiculo = marcaVehiculo;
	}

	public String getNroLicenciaConducir() {
		return nroLicenciaConducir;
	}

	public void setNroLicenciaConducir(String nroLicenciaConducir) {
		this.nroLicenciaConducir = nroLicenciaConducir;
	}

	public String getRucTransportista() {
		return rucTransportista;
	}

	public void setRucTransportista(String rucTransportista) {
		this.rucTransportista = rucTransportista;
	}

	public String getRazonSocialTransportista() {
		return razonSocialTransportista;
	}

	public void setRazonSocialTransportista(String razonSocialTransportista) {
		this.razonSocialTransportista = razonSocialTransportista;
	}

	public String getIndicadorEstabEmisor() {
		return indicadorEstabEmisor;
	}

	public void setIndicadorEstabEmisor(String indicadorEstabEmisor) {
		this.indicadorEstabEmisor = indicadorEstabEmisor;
	}

	public String getIndicadorEstabEmisorEfectuaEmision() {
		return indicadorEstabEmisorEfectuaEmision;
	}

	public void setIndicadorEstabEmisorEfectuaEmision(
			String indicadorEstabEmisorEfectuaEmision) {
		this.indicadorEstabEmisorEfectuaEmision = indicadorEstabEmisorEfectuaEmision;
	}

	public String getIndicadorEstabEmisorRelacionDependencia() {
		return indicadorEstabEmisorRelacionDependencia;
	}

	public void setIndicadorEstabEmisorRelacionDependencia(
			String indicadorEstabEmisorRelacionDependencia) {
		this.indicadorEstabEmisorRelacionDependencia = indicadorEstabEmisorRelacionDependencia;
	}

	public String getIndicadorDomicilioCliente() {
		return indicadorDomicilioCliente;
	}

	public void setIndicadorDomicilioCliente(String indicadorDomicilioCliente) {
		this.indicadorDomicilioCliente = indicadorDomicilioCliente;
	}

	public String getIndicadorTrasladoBienes() {
		return indicadorTrasladoBienes;
	}

	public void setIndicadorTrasladoBienes(String indicadorTrasladoBienes) {
		this.indicadorTrasladoBienes = indicadorTrasladoBienes;
	}

	public DireccionComprobanteBean getEstabEmisor() {
		return estabEmisor;
	}

	public void setEstabEmisor(DireccionComprobanteBean estabEmisor) {
		this.estabEmisor = estabEmisor;
	}

	public DireccionComprobanteBean getDomicilioCliente() {
		return domicilioCliente;
	}

	public void setDomicilioCliente(DireccionComprobanteBean domicilioCliente) {
		this.domicilioCliente = domicilioCliente;
	}

	public DireccionComprobanteBean getPuntoPartida() {
		return puntoPartida;
	}

	public void setPuntoPartida(DireccionComprobanteBean puntoPartida) {
		this.puntoPartida = puntoPartida;
	}

	public DireccionComprobanteBean getPuntoLlegada() {
		return puntoLlegada;
	}

	public void setPuntoLlegada(DireccionComprobanteBean puntoLlegada) {
		this.puntoLlegada = puntoLlegada;
	}

	public Log getLog() {
		return log;
	}

	public BigDecimal getTotalAnticipos() {
		return totalAnticipos;
	}

	public void setTotalAnticipos(BigDecimal totalAnticipos) {
		this.totalAnticipos = totalAnticipos;
	}

	public String getIndicadorPagoAnticipado() {
		return indicadorPagoAnticipado;
	}

	public void setIndicadorPagoAnticipado(String indicadorPagoAnticipado) {
		this.indicadorPagoAnticipado = indicadorPagoAnticipado;
	}

	public String getIndicadorProveedorEstado() {
		return indicadorProveedorEstado;
	}

	public void setIndicadorProveedorEstado(String indicadorProveedorEstado) {
		this.indicadorProveedorEstado = indicadorProveedorEstado;
	}

	public String getCodigoUnidadEjecutora() {
		return codigoUnidadEjecutora;
	}

	public void setCodigoUnidadEjecutora(String codigoUnidadEjecutora) {
		this.codigoUnidadEjecutora = codigoUnidadEjecutora;
	}

	public String getNumeroExpediente() {
		return numeroExpediente;
	}

	public void setNumeroExpediente(String numeroExpediente) {
		this.numeroExpediente = numeroExpediente;
	}

	public String getOrdenCompra() {
		return ordenCompra;
	}

	public void setOrdenCompra(String ordenCompra) {
		this.ordenCompra = ordenCompra;
	}

	public String getNumeroProcesoSeleccion() {
		return numeroProcesoSeleccion;
	}

	public void setNumeroProcesoSeleccion(String numeroProcesoSeleccion) {
		this.numeroProcesoSeleccion = numeroProcesoSeleccion;
	}

	public String getNumeroContrato() {
		return numeroContrato;
	}

	public void setNumeroContrato(String numeroContrato) {
		this.numeroContrato = numeroContrato;
	}

	public ComprobanteBean(){
		this.setTotalValorVenta(new BigDecimal(0.00)); 
		this.setTotalValorVentaNoGravado(new BigDecimal(0.00)) ; 	
		this.setTotalValorVentaExonerado(new BigDecimal(0.00)); 
		this.setTotalDescuentos(new BigDecimal(0.00)); 
		this.setTotalOtrosTributos(new BigDecimal(0.00));
		this.setTotalOtrosCargos(new BigDecimal(0.00)); 		
		this.setTotalISC(new BigDecimal(0.00)); 
		this.setTotalIGV(new BigDecimal(0.00)); 
		this.setMontoTotalGeneral(new BigDecimal(0.00));
		this.setDocumentoRelacionadoBean(new ArrayList<DocumentoRelacionadoBean>());
//		this.setImporteDePercepcion(new BigDecimal(0.00)) ; 
		this.setImporteDePercepcion(null) ;
		this.setIgvPorcentaje(new BigDecimal(0.00));
		this.setLeyenda(new ArrayList<Map<String,String>>());
	}
	
	public String getFechaVencimiento() {
		return fechaVencimiento;
	}

	public void setFechaVencimiento(String fechaVencimiento) {
		this.fechaVencimiento = fechaVencimiento;
	}

	public Integer getNumeroFirma() {
		return numeroFirma;
	}

	public void setNumeroFirma(Integer numeroFirma) {
		this.numeroFirma = numeroFirma;
	}

	public Integer getCountOtrosCargosTributos() {
		return countOtrosCargosTributos;
	}

	public void setCountOtrosCargosTributos(Integer countOtrosCargosTributos) {
		this.countOtrosCargosTributos = countOtrosCargosTributos;
	}

	public BigDecimal getTotalInafOner() {
		return totalInafOner;
	}

	public void setTotalInafOner(BigDecimal totalInafOner) {
		this.totalInafOner = totalInafOner;
	}

	public BigDecimal getTotalExoOner() {
		return totalExoOner;
	}

	public void setTotalExoOner(BigDecimal totalExoOner) {
		this.totalExoOner = totalExoOner;
	}

	public BigDecimal getTotalGravOner() {
		return totalGravOner;
	}

	public void setTotalGravOner(BigDecimal totalGravOner) {
		this.totalGravOner = totalGravOner;
	}

	public BigDecimal getTotalInafGrat() {
		return totalInafGrat;
	}

	public void setTotalInafGrat(BigDecimal totalInafGrat) {
		this.totalInafGrat = totalInafGrat;
	}

	public BigDecimal getTotalExoGrat() {
		return totalExoGrat;
	}

	public void setTotalExoGrat(BigDecimal totalExoGrat) {
		this.totalExoGrat = totalExoGrat;
	}

	public BigDecimal getTotalGravGrat() {
		return totalGravGrat;
	}

	public void setTotalGravGrat(BigDecimal totalGravGrat) {
		this.totalGravGrat = totalGravGrat;
	}

	public BigDecimal getTotalValorVentaOperaGratuitas() {
		return totalValorVentaOperaGratuitas;
	}

	public void setTotalValorVentaOperaGratuitas(
			BigDecimal totalValorVentaOperaGratuitas) {
		this.totalValorVentaOperaGratuitas = totalValorVentaOperaGratuitas;
	}

	public BigDecimal getTotalTributosCargosOperaGratuitas() {
		return totalTributosCargosOperaGratuitas;
	}

	public void setTotalTributosCargosOperaGratuitas(
			BigDecimal totalTributosCargosOperaGratuitas) {
		this.totalTributosCargosOperaGratuitas = totalTributosCargosOperaGratuitas;
	}

	public BigDecimal getTotalImporteTributosCargosOperaGratuitas() {
		return totalImporteTributosCargosOperaGratuitas;
	}

	public void setTotalImporteTributosCargosOperaGratuitas(
			BigDecimal totalImporteTributosCargosOperaGratuitas) {
		this.totalImporteTributosCargosOperaGratuitas = totalImporteTributosCargosOperaGratuitas;
	}

	public BigDecimal getTotalISCOperaGratuitas() {
		return totalISCOperaGratuitas;
	}

	public void setTotalISCOperaGratuitas(BigDecimal totalISCOperaGratuitas) {
		this.totalISCOperaGratuitas = totalISCOperaGratuitas;
	}

	public BigDecimal getTotalIGVOperaGratuitas() {
		return totalIGVOperaGratuitas;
	}

	public void setTotalIGVOperaGratuitas(BigDecimal totalIGVOperaGratuitas) {
		this.totalIGVOperaGratuitas = totalIGVOperaGratuitas;
	}

	public String getIndicadorExportacion() {
		return indicadorExportacion;
	}

	public void setIndicadorExportacion(String indicadorExportacion) {
		this.indicadorExportacion = indicadorExportacion;
	}

	public BigDecimal getTotalSubTotalValorVenta() {
		return totalSubTotalValorVenta;
	}

	public void setTotalSubTotalValorVenta(BigDecimal totalSubTotalValorVenta) {
		this.totalSubTotalValorVenta = totalSubTotalValorVenta;
	}

	public String getDescripcionVentaGratuita() {
		return descripcionVentaGratuita;
	}

	public void setDescripcionVentaGratuita(String descripcionVentaGratuita) {
		this.descripcionVentaGratuita = descripcionVentaGratuita;
	}
	
	public String getDescripcionVentaNoDomic() {
		return descripcionVentaNoDomic;
	}

	public void setDescripcionVentaNoDomic(String descripcionVentaNoDomic) {
		this.descripcionVentaNoDomic = descripcionVentaNoDomic;
	}
	
	public String getIndicadorVentaNodomic() {
		return indicadorVentaNodomic;
	}

	public void setIndicadorVentaNodomic(String indicadorVentaNodomic) {
		this.indicadorVentaNodomic = indicadorVentaNodomic;
	}
	
	public String getIdFirmante() {
		return idFirmante;
	}

	public void setIdFirmante(String idFirmante) {
		this.idFirmante = idFirmante;
	}
	
	public String getNumeroDocumentoPorElQueSeEmite() {
		return numeroDocumentoPorElQueSeEmite;
	}

	public void setNumeroDocumentoPorElQueSeEmite(
			String numeroDocumentoPorElQueSeEmite) {
		this.numeroDocumentoPorElQueSeEmite = numeroDocumentoPorElQueSeEmite;
	}

	public String getSerieDocumentoPorElQueSeEmite() {
		return serieDocumentoPorElQueSeEmite;
	}

	public void setSerieDocumentoPorElQueSeEmite(
			String serieDocumentoPorElQueSeEmite) {
		this.serieDocumentoPorElQueSeEmite = serieDocumentoPorElQueSeEmite;
	}
	
	public String getMotivoEmisionNota() {
		return motivoEmisionNota;
	}

	public void setMotivoEmisionNota(String motivoEmisionNota) {
		this.motivoEmisionNota = motivoEmisionNota;
	}

	public List<OtroDocumentoRelacionadoBean> getOtroDocumentoRelacionadoBean() {
		return otroDocumentoRelacionadoBean;
	}

	public void setOtroDocumentoRelacionadoBean(
			List<OtroDocumentoRelacionadoBean> otroDocumentoRelacionadoBean) {
		this.otroDocumentoRelacionadoBean = otroDocumentoRelacionadoBean;
	}

	public String getNumeroRuc() {
		return numeroRuc;
	}

	public void setNumeroRuc(String numeroRuc) {
		this.numeroRuc = numeroRuc;
	}

	public String getRazonSocial() {
		return razonSocial;
	}

	public void setRazonSocial(String razonSocial) {
		this.razonSocial = razonSocial;
	}

	public String getTipoComprobante() {
		return tipoComprobante;
	}

	public void setTipoComprobante(String tipoComprobante) {
		this.tipoComprobante = tipoComprobante;
	}

	public String getSerieComprobante() {
		return serieComprobante;
	}

	public void setSerieComprobante(String serieComprobante) {
		this.serieComprobante = serieComprobante;
	}

	public Integer getNumeroComprobante() {
		return numeroComprobante;
	}

	public void setNumeroComprobante(Integer numeroComprobante) {
		this.numeroComprobante = numeroComprobante;
	}

	public String getSubTipoComprobante() {
		return subTipoComprobante;
	}

	public void setSubTipoComprobante(String subTipoComprobante) {
		this.subTipoComprobante = subTipoComprobante;
	}

	public String getUbigeoEmisor() {
		return ubigeoEmisor;
	}

	public void setUbigeoEmisor(String ubigeoEmisor) {
		this.ubigeoEmisor = ubigeoEmisor;
	}

	public Short getCodigoEstablecimiento() {
		return codigoEstablecimiento;
	}

	public void setCodigoEstablecimiento(Short codigoEstablecimiento) {
		this.codigoEstablecimiento = codigoEstablecimiento;
	}

	public String getNombreCalle() {
		return nombreCalle;
	}

	public void setNombreCalle(String nombreCalle) {
		this.nombreCalle = nombreCalle;
	}

	public String getNumeroDireccion() {
		return numeroDireccion;
	}

	public void setNumeroDireccion(String numeroDireccion) {
		this.numeroDireccion = numeroDireccion;
	}

	public String getNombreDistrito() {
		return nombreDistrito;
	}

	public void setNombreDistrito(String nombreDistrito) {
		this.nombreDistrito = nombreDistrito;
	}

	public String getNombreProvincia() {
		return nombreProvincia;
	}

	public void setNombreProvincia(String nombreProvincia) {
		this.nombreProvincia = nombreProvincia;
	}

	public String getNombreDepartamento() {
		return nombreDepartamento;
	}

	public void setNombreDepartamento(String nombreDepartamento) {
		this.nombreDepartamento = nombreDepartamento;
	}

	public String getCodigoPais() {
		return codigoPais;
	}

	public void setCodigoPais(String codigoPais) {
		this.codigoPais = codigoPais;
	}

	public String getCodigoMoneda() {
		return codigoMoneda;
	}

	public void setCodigoMoneda(String codigoMoneda) {
		this.codigoMoneda = codigoMoneda;
	}

	public String getDescripcionMoneda() {
		return descripcionMoneda;
	}

	public void setDescripcionMoneda(String descripcionMoneda) {
		this.descripcionMoneda = descripcionMoneda;
	}

	public String getSimboloMoneda() {
		return simboloMoneda;
	}

	public void setSimboloMoneda(String simboloMoneda) {
		this.simboloMoneda = simboloMoneda;
	}

	public String getFechaEmision() {
		return fechaEmision;
	}

	public void setFechaEmision(String fechaEmision) {
		this.fechaEmision = fechaEmision;
	}

	public String getHoraEmision() {
		return horaEmision;
	}

	public void setHoraEmision(String horaEmision) {
		this.horaEmision = horaEmision;
	}
	
	public Timestamp getFechaHoraEmision() {
		if(this.getFechaEmision() == null || this.getHoraEmision() == null) return null;
		FechaBean fb = new FechaBean(this.getFechaEmision() + "-" + this.getHoraEmision(), "dd/MM/yyyy-HH:mm:ss");
		return fb.getTimestamp();
	}

	public String getFechaRegistro() {
		return fechaRegistro;
	}

	public void setFechaRegistro(String fechaRegistro) {
		this.fechaRegistro = fechaRegistro;
	}

	public String getHoraRegistro() {
		return horaRegistro;
	}

	public void setHoraRegistro(String horaRegistro) {
		this.horaRegistro = horaRegistro;
	}
	
	public Timestamp getFechaHoraRegistro() {
		if(this.getFechaRegistro() == null || this.getHoraRegistro() == null) return null;
		FechaBean fb = new FechaBean(this.getFechaRegistro() + "-" + this.getHoraRegistro(), "dd/MM/yyyy-HH:mm:ss");
		return fb.getTimestamp();
	}
	
	public String getFechaAceptada() {
		return fechaAceptada;
	}

	public void setFechaAceptada(String fechaAceptada) {
		this.fechaAceptada = fechaAceptada;
	}

	public String getHoraAceptada() {
		return horaAceptada;
	}

	public void setHoraAceptada(String horaAceptada) {
		this.horaAceptada = horaAceptada;
	}
	
	public Timestamp getFechaHoraAceptada() {
		if(this.getFechaAceptada() == null || this.getHoraAceptada() == null) return null;
		FechaBean fb = new FechaBean(this.getFechaAceptada() + "-" + this.getHoraAceptada(), "dd/MM/yyyy-HH:mm:ss");
		return fb.getTimestamp();
	}
	
	public String getFechaRechazo() {
		return fechaRechazo;
	}

	public void setFechaRechazo(String fechaRechazo) {
		this.fechaRechazo = fechaRechazo;
	}

	public String getHoraRechazo() {
		return horaRechazo;
	}

	public void setHoraRechazo(String horaRechazo) {
		this.horaRechazo = horaRechazo;
	}
	
	public Timestamp getFechaHoraRechazo() {
		if(this.getFechaRechazo() == null || this.getHoraRechazo() == null) return null;
		FechaBean fb = new FechaBean(this.getFechaRechazo() + "-" + this.getHoraRechazo(), "dd/MM/yyyy-HH:mm:ss");
		return fb.getTimestamp();
	}

	public String getTipoDocumentoCliente() {
		return tipoDocumentoCliente;
	}

	public void setTipoDocumentoCliente(String tipoDocumentoCliente) {
		this.tipoDocumentoCliente = tipoDocumentoCliente;
	}

	public String getDesTipoDocumentoCliente() {
		return desTipoDocumentoCliente;
	}

	public void setDesTipoDocumentoCliente(String desTipoDocumentoCliente) {
		this.desTipoDocumentoCliente = desTipoDocumentoCliente;
	}

	public String getNumeroDocumentoCliente() {
		return numeroDocumentoCliente;
	}

	public void setNumeroDocumentoCliente(String numeroDocumentoCliente) {
		this.numeroDocumentoCliente = numeroDocumentoCliente;
	}

	public String getNombreCliente() {
		return nombreCliente;
	}

	public void setNombreCliente(String nombreCliente) {
		this.nombreCliente = nombreCliente;
	}
	
	public String getCodigoFormaPago() {
		return codigoFormaPago;
	}

	public void setCodigoFormaPago(String codigoFormaPago) {
		this.codigoFormaPago = codigoFormaPago;
	}

	public String getDescripcionFormaPago() {
		return descripcionFormaPago;
	}

	public void setDescripcionFormaPago(String descripcionFormaPago) {
		this.descripcionFormaPago = descripcionFormaPago;
	}

	public String getObservacion() {
		return observacion;
	}

	public void setObservacion(String observacion) {
		this.observacion = observacion;
	}

	public String getGlosa() {
		return glosa;
	}

	public void setGlosa(String glosa) {
		this.glosa = glosa;
	}

	public String getIdentificadorFirma() {
		return identificadorFirma;
	}

	public void setIdentificadorFirma(String identificadorFirma) {
		this.identificadorFirma = identificadorFirma;
	}

	public String getNombreFirmante() {
		return nombreFirmante;
	}

	public void setNombreFirmante(String nombreFirmante) {
		this.nombreFirmante = nombreFirmante;
	}

	public String getReferenciaFirma() {
		return referenciaFirma;
	}

	public void setReferenciaFirma(String referenciaFirma) {
		this.referenciaFirma = referenciaFirma;
	}

	public BigDecimal getMontoTotalGeneral() {
		return montoTotalGeneral;
	}

	public void setMontoTotalGeneral(BigDecimal montoTotalGeneral) {
		this.montoTotalGeneral = montoTotalGeneral;
	}

	public BigDecimal getMontoSubTotal() {
		return montoSubTotal;
	}

	public void setMontoSubTotal(BigDecimal montoSubTotal) {
		this.montoSubTotal = montoSubTotal;
	}

	public BigDecimal getMontoDescuentos() {
		return montoDescuentos;
	}

	public void setMontoDescuentos(BigDecimal montoDescuentos) {
		this.montoDescuentos = montoDescuentos;
	}

	public BigDecimal getMontoImpuestos() {
		return montoImpuestos;
	}

	public void setMontoImpuestos(BigDecimal montoImpuestos) {
		this.montoImpuestos = montoImpuestos;
	}

	public BigDecimal getSaldoReferencial() {
		return saldoReferencial;
	}

	public void setSaldoReferencial(BigDecimal saldoReferencial) {
		this.saldoReferencial = saldoReferencial;
	}

	public String getMontoTotalTexto() {
		return montoTotalTexto;
	}

	public void setMontoTotalTexto(String montoTotalTexto) {
		this.montoTotalTexto = montoTotalTexto;
	}

	public String getIndicadorAceptada() {
		return indicadorAceptada;
	}

	public void setIndicadorAceptada(String indicadorAceptada) {
		this.indicadorAceptada = indicadorAceptada;
	}

	public String getIndicadorRechazo() {
		return indicadorRechazo;
	}

	public void setIndicadorRechazo(String indicadorEstado) {
		this.indicadorRechazo = indicadorEstado;
	}

	public String getIndicadorMedioRegistro() {
		return indicadorMedioRegistro;
	}

	public void setIndicadorMedioRegistro(String indicadorMedio) {
		this.indicadorMedioRegistro = indicadorMedio;
	}

	public Short getAnioRegistro() {
		return anioRegistro;
	}

	public void setAnioRegistro(Short anioRegistro) {
		this.anioRegistro = anioRegistro;
	}

	public Long getNumeroIndice() {
		return numeroIndice;
	}

	public void setNumeroIndice(Long numeroIndice) {
		this.numeroIndice = numeroIndice;
	}

	public String getCodigoUsuarioModificador() {
		return codigoUsuarioModificador;
	}

	public void setCodigoUsuarioModificador(String codigoUsuarioModificador) {
		this.codigoUsuarioModificador = codigoUsuarioModificador;
	}

	public String getFechaModificacion() {
		return fechaModificacion;
	}

	public void setFechaModificacion(String fechaModificacion) {
		this.fechaModificacion = fechaModificacion;
	}

	public String getHoraModificacion() {
		return horaModificacion;
	}

	public void setHoraModificacion(String horaModificacion) {
		this.horaModificacion = horaModificacion;
	}
	
	public Timestamp getFechaHoraModificacion() {
		if(this.getFechaModificacion() == null || this.getHoraModificacion() == null) return null;
		FechaBean fb = new FechaBean(this.getFechaModificacion() + "-" + this.getHoraModificacion(), "dd/MM/yyyy-HH:mm:ss");
		return fb.getTimestamp();
	}

	public List<DetalleComprobanteBean> getDetalleComprobanteBean() {
		return detalleComprobanteBean;
	}
	
//	public void setDetalleComprobanteBean(DetalleComprobanteBean[] detalleComprobanteBean) {
//		this.detalleComprobanteBean = detalleComprobanteBean;
//	}
	
	public void setDetalleComprobanteBean(List<DetalleComprobanteBean> detalleComprobanteBean) {
		this.detalleComprobanteBean = detalleComprobanteBean;
	}	
	
	public List<DocumentoRelacionadoBean> getDocumentoRelacionadoBean() {
		return documentoRelacionadoBean;
	}

	public void setDocumentoRelacionadoBean(
			List<DocumentoRelacionadoBean> documentoRelacionadoBean) {
		this.documentoRelacionadoBean = documentoRelacionadoBean;
	}

	public ArchivoComprobanteBean getArchivoComprobanteBean() {
		return archivoComprobanteBean;
	}
	
	public void setArchivoComprobanteBean(ArchivoComprobanteBean archivoComprobanteBean) {
		this.archivoComprobanteBean = archivoComprobanteBean;
	}
	



	public String getBonificacion() {
		return bonificacion;
	}

	public void setBonificacion(String bonificacion) {
		this.bonificacion = bonificacion;
	}

	public BigDecimal getTotalDescuentos() {
		return totalDescuentos;
	}

	public void setTotalDescuentos(BigDecimal totalDescuentos) {
		this.totalDescuentos = totalDescuentos;
	}

	public BigDecimal getTotalISC() {
		return totalISC;
	}

	public void setTotalISC(BigDecimal totalISC) {
		this.totalISC = totalISC;
	}

	public BigDecimal getTotalIGV() {
		return totalIGV;
	}

	public void setTotalIGV(BigDecimal totalIGV) {
		this.totalIGV = totalIGV;
	}

	public BigDecimal getTotalOtrosCargos() {
		return totalOtrosCargos;
	}

	public void setTotalOtrosCargos(BigDecimal totalOtrosCargos) {
		this.totalOtrosCargos = totalOtrosCargos;
	}

	public BigDecimal getTotalValorVenta() {
		return totalValorVenta;
	}

	public void setTotalValorVenta(BigDecimal totalValorVenta) {
		this.totalValorVenta = totalValorVenta;
	}

	public String getCodigoSitEspecial() {
		return codigoSitEspecial;
	}

	public void setCodigoSitEspecial(String codigoSitEspecial) {
		this.codigoSitEspecial = codigoSitEspecial;
	}

	public String getCodigoDependecia() {
		return codigoDependecia;
	}

	public void setCodigoDependecia(String codigoDependecia) {
		this.codigoDependecia = codigoDependecia;
	}

	public Long getNumeroIndiceCabMov() {
		return numeroIndiceCabMov;
	}

	public void setNumeroIndiceCabMov(Long numeroIndiceCabMov) {
		this.numeroIndiceCabMov = numeroIndiceCabMov;
	}

	public String getCorreoPrincipal() {
		return correoPrincipal;
	}

	public void setCorreoPrincipal(String correoPrincipal) {
		this.correoPrincipal = correoPrincipal;
	}

	public String getCorreoSecundario() {
		return correoSecundario;
	}

	public void setCorreoSecundario(String correoSecundario) {
		this.correoSecundario = correoSecundario;
	}

	public BigDecimal getIgvPorcentaje() {
		return igvPorcentaje;
	}

	public void setIgvPorcentaje(BigDecimal igvPorcentaje) {
		this.igvPorcentaje = igvPorcentaje;
	}
	
	/*
	public Map getSumInafExoGrav(){
		BigDecimal totalInafOner = new BigDecimal(0);
		BigDecimal totalExoOner = new BigDecimal(0);
		BigDecimal totalGravOner = new BigDecimal(0);	
		BigDecimal totalInafGrat = new BigDecimal(0);
		BigDecimal totalExoGrat  = new BigDecimal(0);
		BigDecimal totalGravGrat  = new BigDecimal(0);			
		BigDecimal totalValorVentaOperaGratuitas = new BigDecimal(0);	
		BigDecimal totalTributosCargosOperaGratuitas = new BigDecimal(0);
		BigDecimal totalImporteTributosCargosOperaGratuitas = new BigDecimal(0);
		BigDecimal totalISCOperaGratuitas = new BigDecimal(0);
		BigDecimal totalIGVOperaGratuitas = new BigDecimal(0);
		
		String tipoBeneficio="";		
		
		if (detalleComprobanteBean!=null){
			for(DetalleComprobanteBean detalleComprobante : detalleComprobanteBean) {
				tipoBeneficio = detalleComprobante.getTipoBeneficio() ==null ? "" : detalleComprobante.getTipoBeneficio().trim();
				if (detalleComprobante.getTipoBonificacion().equals("BO00")){  //No es Operacion Gratuita
					if (!detalleComprobante.getTipoOtrosCargosTributos().equals("1") && !detalleComprobante.getTipoOtrosCargosTributos().equals("2")){	
						if ("TB01".equals(tipoBeneficio)){
							try {
								totalExoOner = totalExoOner.add(ComprobanteUtilBean.toBigDecimal(detalleComprobante.getImporteVenta()).add(ComprobanteUtilBean.toBigDecimal(detalleComprobante.getIscMonto()).multiply(new BigDecimal(-1))));
	
							} catch (ParseException e) {}
						} else if ("TB02".equals(tipoBeneficio)){
							try {
								totalInafOner = totalInafOner.add(ComprobanteUtilBean.toBigDecimal(detalleComprobante.getImporteVenta()).add(ComprobanteUtilBean.toBigDecimal(detalleComprobante.getIscMonto())).multiply(new BigDecimal(-1)));
							} catch (ParseException e) {}
						} else if ("TB00".equals(tipoBeneficio)){
							try {
								totalGravOner = totalGravOner.add(ComprobanteUtilBean.toBigDecimal(detalleComprobante.getImporteVenta()).add(ComprobanteUtilBean.toBigDecimal(detalleComprobante.getIscMonto()).multiply(new BigDecimal(-1))).add(ComprobanteUtilBean.toBigDecimal(detalleComprobante.getIgvMonto()).multiply(new BigDecimal(-1))));
							} catch (ParseException e) {}
						}else{
							
						}
					}
				}
				if (detalleComprobante.getTipoBonificacion().equals("BO01")){  // Operacion Gratuita
					
					try {
						totalValorVentaOperaGratuitas =  totalValorVentaOperaGratuitas.add(ComprobanteUtilBean.toBigDecimal(detalleComprobante.getImporteVenta()));
						totalISCOperaGratuitas = totalISCOperaGratuitas.add(ComprobanteUtilBean.toBigDecimal(detalleComprobante.getIscMonto()));
						totalIGVOperaGratuitas = totalIGVOperaGratuitas.add(ComprobanteUtilBean.toBigDecimal(detalleComprobante.getIgvMonto()));
					} catch (ParseException e) {}

					if (detalleComprobante.getTipoOtrosCargosTributos().equals("1") ){	
						try {
							totalTributosCargosOperaGratuitas = totalTributosCargosOperaGratuitas.add(ComprobanteUtilBean.toBigDecimal(detalleComprobante.getOtrosCargos()));
							totalImporteTributosCargosOperaGratuitas = totalImporteTributosCargosOperaGratuitas.add(ComprobanteUtilBean.toBigDecimal(detalleComprobante.getImporteVenta()));
						} catch (ParseException e) {}
					}
					if (detalleComprobante.getTipoOtrosCargosTributos().equals("2")){	
						try {
							totalTributosCargosOperaGratuitas = totalTributosCargosOperaGratuitas.add(ComprobanteUtilBean.toBigDecimal(detalleComprobante.getOtrosTributos()));
							totalImporteTributosCargosOperaGratuitas = totalImporteTributosCargosOperaGratuitas.add(ComprobanteUtilBean.toBigDecimal(detalleComprobante.getImporteVenta()));
						} catch (ParseException e) {}
					}					
					if (!detalleComprobante.getTipoOtrosCargosTributos().equals("1") && !detalleComprobante.getTipoOtrosCargosTributos().equals("2")){	
						if ("TB01".equals(tipoBeneficio)){
							try {
								totalExoGrat  = totalExoGrat.add(ComprobanteUtilBean.toBigDecimal(detalleComprobante.getImporteVenta()).add(ComprobanteUtilBean.toBigDecimal(detalleComprobante.getIscMonto()).multiply(new BigDecimal(-1))));
	
							} catch (ParseException e) {}
						} else if ("TB02".equals(tipoBeneficio)){
							try {
								totalInafGrat  = totalInafGrat.add(ComprobanteUtilBean.toBigDecimal(detalleComprobante.getImporteVenta()).add(ComprobanteUtilBean.toBigDecimal(detalleComprobante.getIscMonto())).multiply(new BigDecimal(-1)));
							} catch (ParseException e) {}
						} else if ("TB00".equals(tipoBeneficio)){
							try {
								totalGravGrat = totalGravGrat.add(ComprobanteUtilBean.toBigDecimal(detalleComprobante.getImporteVenta()).add(ComprobanteUtilBean.toBigDecimal(detalleComprobante.getIscMonto()).multiply(new BigDecimal(-1))).add(ComprobanteUtilBean.toBigDecimal(detalleComprobante.getIgvMonto()).multiply(new BigDecimal(-1))));
							} catch (ParseException e) {}
						}else{
							
						}
					}				
				}
			}
		}
		
		Map<String, BigDecimal> m = new HashMap<String, BigDecimal> ();
		m.put("totalInafOner", totalInafOner);
		m.put("totalExoOner", totalExoOner);
		m.put("totalGravOner", totalGravOner);
		m.put("totalInafGrat", totalInafOner);
		m.put("totalExoGrat", totalExoOner);
		m.put("totalGravGrat", totalGravOner);		
		m.put("totalValorVentaOperaGratuitas", totalValorVentaOperaGratuitas);
		m.put("totalTributosCargosOperaGratuitas", totalTributosCargosOperaGratuitas);
		m.put("totalImporteTributosCargosOperaGratuitas", totalImporteTributosCargosOperaGratuitas);
		m.put("totalISCOperaGratuitas", totalISCOperaGratuitas);
		m.put("totalIGVOperaGratuitas", totalIGVOperaGratuitas);	
		
		return m;
	}
*/
	public BigDecimal getTotalOtrosTributos() {
		return totalOtrosTributos;
	}

	public void setTotalOtrosTributos(BigDecimal totalOtrosTributos) {
		this.totalOtrosTributos = totalOtrosTributos;
	}

	public String getRazonComercial() {
		return razonComercial;
	}

	public void setRazonComercial(String razonComercial) {
		this.razonComercial = razonComercial;
	}

	public Integer getCountUnidadMedidaItem() {
		return countUnidadMedidaItem;
	}

	public void setCountUnidadMedidaItem(Integer countUnidadMedidaItem) {
		this.countUnidadMedidaItem = countUnidadMedidaItem;
	}

	public Integer getCountCodigoItem() {
		return countCodigoItem;
	}

	public void setCountCodigoItem(Integer countCodigoItem) {
		this.countCodigoItem = countCodigoItem;
	}	
	
	public BigDecimal getTotalValorVentaNoGravado() {
		return totalValorVentaNoGravado;
	}

	public void setTotalValorVentaNoGravado(BigDecimal totalValorVentaNoGravado) {
		this.totalValorVentaNoGravado = totalValorVentaNoGravado;
	}

	public BigDecimal getTotalValorVentaExonerado() {
		return totalValorVentaExonerado;
	}

	public void setTotalValorVentaExonerado(BigDecimal totalValorVentaExonerado) {
		this.totalValorVentaExonerado = totalValorVentaExonerado;
	}

	public BigDecimal getImporteDePercepcion() {
		return importeDePercepcion;
	}

	public void setImporteDePercepcion(BigDecimal importeDePercepcion) {
		this.importeDePercepcion = importeDePercepcion;
	}
	
	public String getCodigoGuiaRemision() {
		return codigoGuiaRemision;
	}

	public void setCodigoGuiaRemision(String codigoGuiaRemision) {
		this.codigoGuiaRemision = codigoGuiaRemision;
	}

	public String getDireccionCompleta() {
		return direccionCompleta;
	}

	public void setDireccionCompleta(String direccionCompleta) {
		this.direccionCompleta = direccionCompleta;
	}

	public String getNombreUrbanizacion() {
		return nombreUrbanizacion;
	}

	public void setNombreUrbanizacion(String nombreUrbanizacion) {
		this.nombreUrbanizacion = nombreUrbanizacion;
	}
/*
	public String toString(){
		StringBuilder datos = new StringBuilder();
		datos.append("Numero RUC                   :" + (this.numeroRuc != null? this.numeroRuc : "null")).append("\n");
		datos.append("Razon Social                 :" + (this.razonSocial!= null? this.razonSocial: "null")).append("\n");
		datos.append("Tipo Comprobante             :" + (this.tipoComprobante != null? this.tipoComprobante : "null")).append("\n");
		datos.append("Serie Comprobante            :" + (this.serieComprobante != null? this.serieComprobante : "null")).append("\n");
		datos.append("Numero Comprobante           :" + (this.numeroComprobante != null? this.numeroComprobante : "null")).append("\n");
		datos.append("Subtipo Comprobante          :" + (this.subTipoComprobante != null? this.subTipoComprobante : "null")).append("\n");
		datos.append("Numero por el que se emite   :" + (this.numeroDocumentoPorElQueSeEmite != null? this.numeroDocumentoPorElQueSeEmite : "null")).append("\n");
		datos.append("Ubigeo Emisor                :" + (this.ubigeoEmisor != null? this.ubigeoEmisor : "null")).append("\n");
		datos.append("Codigo Establecimiento       :" + (this.codigoEstablecimiento != null? this.codigoEstablecimiento : "null")).append("\n");
		datos.append("Calle                        :" + (this.nombreCalle != null? this.nombreCalle : "null")).append("\n");
		datos.append("Direcci�n                    :" + (this.numeroDireccion != null? this.numeroDireccion : "null")).append("\n");
		datos.append("Distrito                     :" + (this.nombreDistrito != null? this.nombreDistrito : "null")).append("\n");
		datos.append("Provincia                    :" + (this.nombreProvincia != null? this.nombreProvincia : "null")).append("\n");
		datos.append("Departamento                 :" + (this.nombreDepartamento != null? this.nombreDepartamento : "null")).append("\n");
		datos.append("Pais                         :" + (this.codigoPais != null? this.codigoPais : "null")).append("\n");
		datos.append("Codigo Moneda                :" + (this.codigoMoneda != null? this.codigoMoneda : "null")).append("\n");
		datos.append("Descripcion Moneda           :" + (this.descripcionMoneda != null? this.descripcionMoneda : "null")).append("\n");
		datos.append("Simbolo Moneda               :" + (this.simboloMoneda != null? this.simboloMoneda : "null")).append("\n");
		datos.append("Fecha Emision                :" + (this.fechaEmision != null? this.fechaEmision : "null")).append("\n");
		datos.append("Hora Emision                 :" + (this.horaEmision != null? this.horaEmision : "null")).append("\n");
		datos.append("Fecha Registro               :" + (this.fechaRegistro != null? this.fechaRegistro : "null")).append("\n");
		datos.append("Hora Registro                :" + (this.horaRegistro != null? this.horaRegistro : "null")).append("\n");
        datos.append("Fecha Aceptada               :" + (this.fechaAceptada != null? this.fechaAceptada : "null")).append("\n");
		datos.append("Hora Aceptada                :" + (this.horaAceptada != null? this.horaAceptada : "null")).append("\n");
		datos.append("Fecha Rechazo                :" + (this.fechaRechazo != null? this.fechaRechazo : "null")).append("\n");
		datos.append("Hora Rechazo                 :" + (this.horaRechazo != null? this.horaRechazo : "null")).append("\n");
		datos.append("Codigo Tipo Docum. Cliente   :" + (this.tipoDocumentoCliente != null? this.tipoDocumentoCliente : "null")).append("\n");
		datos.append("Descrip. Tipo Docum. Cliente :" + (this.desTipoDocumentoCliente != null? this.desTipoDocumentoCliente : "null")).append("\n");
		datos.append("Numero Documento Cliente     :" + (this.numeroDocumentoCliente != null? this.numeroDocumentoCliente : "null")).append("\n");
		datos.append("Nombre Cliente               :" + (this.nombreCliente != null? this.nombreCliente : "null")).append("\n");
		datos.append("Codigo Forma de Pago         :" + (this.codigoFormaPago != null? this.codigoFormaPago : "null")).append("\n");
		datos.append("Descripcion Forma de Pago    :" + (this.descripcionFormaPago != null? this.descripcionFormaPago : "null")).append("\n");
		datos.append("Observacion                  :" + (this.observacion != null? this.observacion : "null")).append("\n");
		datos.append("Bonificacion                 :" + (this.bonificacion != null? this.bonificacion : "null")).append("\n");
		datos.append("Glosa                        :" + (this.glosa != null? this.glosa : "null")).append("\n");
		datos.append("Identificador Firma          :" + (this.identificadorFirma != null? this.identificadorFirma : "null")).append("\n");
		datos.append("Nombre Firmante              :" + (this.nombreFirmante != null? this.nombreFirmante : "null")).append("\n");
		datos.append("Referencia Firma             :" + (this.referenciaFirma != null? this.referenciaFirma : "null")).append("\n");
		datos.append("Monto Total General          :" + (this.montoTotalGeneral != null? this.montoTotalGeneral : "null")).append("\n");
		datos.append("Monto Sub Total              :" + (this.montoSubTotal != null? this.montoSubTotal : "null")).append("\n");
		datos.append("Monto Descuentos             :" + (this.montoDescuentos != null? this.montoDescuentos : "null")).append("\n");
		datos.append("Monto Impuestos              :" + (this.montoImpuestos != null? this.montoImpuestos : "null")).append("\n");
		datos.append("Saldo Referencial            :" + (this.saldoReferencial != null? this.saldoReferencial : "null")).append("\n");
		datos.append("Monto Total Texto            :" + (this.montoTotalTexto != null? this.montoTotalTexto : "null")).append("\n");
		datos.append("Sub -total venta             :" + (this.totalSubTotalValorVenta != null? this.totalSubTotalValorVenta : "null")).append("\n");
		datos.append("Sub -total venta             :" + (this.totalSubTotalValorVenta != null? this.totalSubTotalValorVenta : "null")).append("\n");
		datos.append("Total Valor Vta. Operac.Grat.:" + (this.totalValorVentaOperaGratuitas != null? this.totalValorVentaOperaGratuitas : "null")).append("\n");
		datos.append("Indicador Rechazo            :" + (this.indicadorRechazo != null? this.indicadorRechazo : "null")).append("\n");
		datos.append("Indicador Medio Registro     :" + (this.indicadorMedioRegistro != null? this.indicadorMedioRegistro : "null")).append("\n");
		datos.append("Codigo Dependencia           :" + (this.codigoDependecia != null? this.codigoDependecia : "null")).append("\n");
		datos.append("Fecha Modificacion           :" + (this.fechaModificacion != null? this.fechaModificacion : "null")).append("\n");
		datos.append("Hora Modificacion            :" + (this.horaModificacion != null? this.horaModificacion : "null")).append("\n");		
        datos.append("CodigoSituacion Especial     :" + (this.codigoSitEspecial != null? this.codigoSitEspecial : "null")).append("\n");
        datos.append("Motivo Emision Nota          :" + (this.motivoEmisionNota != null? this.motivoEmisionNota : "null")).append("\n");
        datos.append("Total Descuentos             :" + (this.totalDescuentos != null? this.totalDescuentos : "null")).append("\n");
        datos.append("Total ISC                    :" + (this.totalISC != null? this.totalISC : "null")).append("\n");
        datos.append("Total IGV                    :" + (this.totalIGV != null? this.totalIGV : "null")).append("\n");
        datos.append("Total OtrosCargos            :" + (this.totalOtrosCargos != null? this.totalOtrosCargos : "null")).append("\n");
        datos.append("Total OtrosTributos          :" + (this.totalOtrosTributos != null? this.totalOtrosTributos : "null")).append("\n");
        datos.append("Total ValorVenta             :" + (this.totalValorVenta != null? this.totalValorVenta : "null")).append("\n");
        datos.append("IGV Porcentaje               :" + (this.igvPorcentaje != null? this.igvPorcentaje : "null")).append("\n");
        datos.append("Suma de inafectos Oper Grat  :" + (this.totalInafGrat != null? this.totalInafGrat : "null")).append("\n");
        datos.append("Suma de exonerados Oper Grat :" + (this.totalExoGrat != null? this.totalExoGrat : "null")).append("\n");
        datos.append("Suma de gravados Oper Grat   :" + (this.totalGravGrat != null? this.totalGravGrat : "null")).append("\n");
        datos.append("Tributos y Cargos Oper Grat  :" + (this.totalImporteTributosCargosOperaGratuitas != null? this.totalImporteTributosCargosOperaGratuitas : "null")).append("\n");
        
        datos.append("Items Detalle Comprobante    :").append("\n");
        if (this.detalleComprobanteBean != null && this.detalleComprobanteBean.size()>0){
	        for (int i =0;i < this.detalleComprobanteBean.size();i++ ){
	        	datos.append("Item Detalle :" +i  ).append("\n");
	        	datos.append("Tipo Item             : " + (this.detalleComprobanteBean.get(i).getTipoItem() != null ? detalleComprobanteBean.get(i).getTipoItem() : "null")).append("\n");
	        	datos.append("Identificador         : " + (this.detalleComprobanteBean.get(i).getIdentificador() != null ? detalleComprobanteBean.get(i).getIdentificador() : "null")).append("\n");
	        	datos.append("Identificador Original: " + (this.detalleComprobanteBean.get(i).getIdentificadorOriginal() != null ? detalleComprobanteBean.get(i).getIdentificadorOriginal() : "null")).append("\n");
	        	datos.append("N�mero de L�nea       : " + (this.detalleComprobanteBean.get(i).getNumeroLinea() != null ? detalleComprobanteBean.get(i).getNumeroLinea() : "null")).append("\n");
	        	datos.append("Codigo Item           : " + (this.detalleComprobanteBean.get(i).getCodigoItem() != null ? detalleComprobanteBean.get(i).getCodigoItem() : "null")).append("\n");
	        	datos.append("Es OperacionGratuita  : " + (this.detalleComprobanteBean.get(i).getTipoBonificacion() != null ? detalleComprobanteBean.get(i).getTipoBonificacion() : "null")).append("\n");
	        	datos.append("Cantidad              : " + (this.detalleComprobanteBean.get(i).getCantidad() != null ? detalleComprobanteBean.get(i).getCantidad() : "null")).append("\n");
	        	datos.append("Descripci�n           : " + (this.detalleComprobanteBean.get(i).getDescripcion()!= null ? detalleComprobanteBean.get(i).getDescripcion() : "null")).append("\n");
	        	datos.append("Descripci�n Nueva     : " + (this.detalleComprobanteBean.get(i).getDescripcionNueva()!= null ? detalleComprobanteBean.get(i).getDescripcionNueva() : "null")).append("\n");
	        	datos.append("Descripci�n Final     : " + (this.detalleComprobanteBean.get(i).getDescripcionFinal()!= null ? detalleComprobanteBean.get(i).getDescripcionFinal() : "null")).append("\n");
	        	datos.append("Valor Venta           : " + (this.detalleComprobanteBean.get(i).getValorVenta() != null ? detalleComprobanteBean.get(i).getValorVenta() : "null")).append("\n");
	        	datos.append("Precio Unitario       : " + (this.detalleComprobanteBean.get(i).getPrecioUnitario() != null ? detalleComprobanteBean.get(i).getPrecioUnitario() : "null")).append("\n");
	        	datos.append("Precio Unitario Original: " + (this.detalleComprobanteBean.get(i).getPrecioUnitarioOriginal() != null ? detalleComprobanteBean.get(i).getPrecioUnitarioOriginal() : "null")).append("\n");
	        	datos.append("Unidad de Medida      : " + (this.detalleComprobanteBean.get(i).getUnidadMedida()!= null ? detalleComprobanteBean.get(i).getUnidadMedida() : "null")).append("\n");
	        	datos.append("ISC                   : " + (this.detalleComprobanteBean.get(i).getIscMonto()!= null ? detalleComprobanteBean.get(i).getIscMonto() : "null")).append("\n");
	        	datos.append("Indicador afectacion  : " + (this.detalleComprobanteBean.get(i).getTipoBeneficio()!= null ? detalleComprobanteBean.get(i).getTipoBeneficio() : "null")).append("\n");
	        	datos.append("IGV                   : " + (this.detalleComprobanteBean.get(i).getIgvMonto()!= null ? detalleComprobanteBean.get(i).getIgvMonto() : "null")).append("\n");
	        	datos.append("Otros Cargos          : " + (this.detalleComprobanteBean.get(i).getOtrosCargos() != null ? detalleComprobanteBean.get(i).getOtrosCargos() : "null")).append("\n");
	        	datos.append("Otros Tributos        : " + (this.detalleComprobanteBean.get(i).getOtrosTributos() != null ? detalleComprobanteBean.get(i).getOtrosTributos() : "null")).append("\n");
	        	datos.append("Descuento             : " + (this.detalleComprobanteBean.get(i).getDescuentoMonto() != null ? detalleComprobanteBean.get(i).getDescuentoMonto() : "null")).append("\n");	        	
	        	datos.append("Importe Venta         : " + (this.detalleComprobanteBean.get(i).getImporteVenta()!= null ? detalleComprobanteBean.get(i).getImporteVenta() : "null")).append("\n");
	        }
        }
        datos.append("Items Otros Docs Relacionados    :").append("\n");
        if (this.otroDocumentoRelacionadoBean != null && this.otroDocumentoRelacionadoBean.size()>0){
	        for (int i =0;i < this.otroDocumentoRelacionadoBean.size();i++ ){
	        	datos.append("Documento Relacionado :" +i ).append("\n");
	        	datos.append("Tipo Comprobante             : " + (this.otroDocumentoRelacionadoBean.get(i).getTipoComprobante()!= null ? otroDocumentoRelacionadoBean.get(i).getTipoComprobante() : "null")).append("\n");
	        	datos.append("Serie Comprobante            : " + (this.otroDocumentoRelacionadoBean.get(i).getSerieComprobante()!= null ? otroDocumentoRelacionadoBean.get(i).getSerieComprobante() : "null")).append("\n");
	        	datos.append("Numero Comprobante           : " + (this.otroDocumentoRelacionadoBean.get(i).getNumeroComprobante()!= null ? otroDocumentoRelacionadoBean.get(i).getNumeroComprobante() : "null")).append("\n");
	        	datos.append("Tipo Documento Relacionado   : " + (this.otroDocumentoRelacionadoBean.get(i).getTipoDocumentoRelacionado() != null ? otroDocumentoRelacionadoBean.get(i).getTipoDocumentoRelacionado() : "null")).append("\n");
	        	datos.append("Serie Documento Relacionado  : " + (this.otroDocumentoRelacionadoBean.get(i).getSerieDocumentoRelacionado() != null ? otroDocumentoRelacionadoBean.get(i).getSerieDocumentoRelacionado() : "null")).append("\n");
	        	datos.append("Numero Documento Relacionado : " + (this.otroDocumentoRelacionadoBean.get(i).getNumeroDocumentoRelacionado() != null ? otroDocumentoRelacionadoBean.get(i).getNumeroDocumentoRelacionado() : "null")).append("\n");
	        }
        }
		return datos.toString();
	}
	*/
	
	@Override
	public String toString(){
		String result = "Valores del BEAN "+this.getClass()+"\r" ; 
		try {
			BeanInfo info =  Introspector.getBeanInfo(this.getClass());
			PropertyDescriptor[] pds  = info.getPropertyDescriptors() ;	
			Method getter = null  ; 
			Object valor = "" ; 
			for(PropertyDescriptor pd : pds){								
				if(!"class".equals(pd.getName())){
					try {
						getter = new PropertyDescriptor(pd.getName(), this.getClass()).getReadMethod();
						Object obj[] = null;
						valor = getter.invoke(this, obj) ;
						result = result +"[ "+ pd.getName()+" ] \t"+" : "+ (valor instanceof FechaBean?((FechaBean)valor).getTimestamp(): valor)+"\r" ;
					} catch (Exception e) {
						
					}					
				}
			}
		} catch (Exception e) {
			log.error(e, e) ; 
		}		
		return result ; 
	}
	
	public String getDescTipoDocQueModifica() {
		return descTipoDocQueModifica;
	}

	public void setDescTipoDocQueModifica(String descTipoDocQueModifica) {
		this.descTipoDocQueModifica = descTipoDocQueModifica;
	}

	public List<Map<String, String>> getLeyenda() {
		return leyenda;
	}

	public void setLeyenda(List<Map<String, String>> leyenda) {
		this.leyenda = leyenda;
	}

	public String getTipoComprobanteDesc() {
		return tipoComprobanteDesc;
	}

	public void setTipoComprobanteDesc(String tipoComprobanteDesc) {
		this.tipoComprobanteDesc = tipoComprobanteDesc;
	}


	public BigDecimal getTotalValorVentaInafecto() {
		return totalValorVentaInafecto;
	}

	public void setTotalValorVentaInafecto(BigDecimal totalValorVentaInafecto) {
		this.totalValorVentaInafecto = totalValorVentaInafecto;
	}

	
	public String getFechaEmisionOriginal() {
		return fechaEmisionOriginal;
	}

	public void setFechaEmisionOriginal(String fechaEmisionOriginal) {
		this.fechaEmisionOriginal = fechaEmisionOriginal;
	}

	public String getNacionalidadNoDomiciliado() {
		return nacionalidadNoDomiciliado;
	}

	public void setNacionalidadNoDomiciliado(String nacionalidadNoDomiciliado) {
		this.nacionalidadNoDomiciliado = nacionalidadNoDomiciliado;
	}

	public String getTamNoDomiciliado() {
		return tamNoDomiciliado;
	}

	public void setTamNoDomiciliado(String tamNoDomiciliado) {
		this.tamNoDomiciliado = tamNoDomiciliado;
	}

	public String getFechaIngresoPaisNoDomiciliado() {
		return fechaIngresoPaisNoDomiciliado;
	}

	public void setFechaIngresoPaisNoDomiciliado(
			String fechaIngresoPaisNoDomiciliado) {
		this.fechaIngresoPaisNoDomiciliado = fechaIngresoPaisNoDomiciliado;
	}

	public String getTipoTarjetaNoDomiciliado() {
		return tipoTarjetaNoDomiciliado;
	}

	public void setTipoTarjetaNoDomiciliado(String tipoTarjetaNoDomiciliado) {
		this.tipoTarjetaNoDomiciliado = tipoTarjetaNoDomiciliado;
	}

	public String getNumeroTarjetaNoDomiciliado() {
		return numeroTarjetaNoDomiciliado;
	}

	public void setNumeroTarjetaNoDomiciliado(String numeroTarjetaNoDomiciliado) {
		this.numeroTarjetaNoDomiciliado = numeroTarjetaNoDomiciliado;
	}

	public String getBancoTarjetaNoDomiciliado() {
		return bancoTarjetaNoDomiciliado;
	}

	public void setBancoTarjetaNoDomiciliado(String bancoTarjetaNoDomiciliado) {
		this.bancoTarjetaNoDomiciliado = bancoTarjetaNoDomiciliado;
	}

	public String getNacionalidadNoDomiciliadoDesc() {
		return nacionalidadNoDomiciliadoDesc;
	}

	public void setNacionalidadNoDomiciliadoDesc(
			String nacionalidadNoDomiciliadoDesc) {
		this.nacionalidadNoDomiciliadoDesc = nacionalidadNoDomiciliadoDesc;
	}

	public String getBancoTarjetaNoDomiciliadoDesc() {
		return bancoTarjetaNoDomiciliadoDesc;
	}

	public void setBancoTarjetaNoDomiciliadoDesc(
			String bancoTarjetaNoDomiciliadoDesc) {
		this.bancoTarjetaNoDomiciliadoDesc = bancoTarjetaNoDomiciliadoDesc;
	}

	public String getNumeroSuscripcionNoDomic() {
		return numeroSuscripcionNoDomic;
	}

	public void setNumeroSuscripcionNoDomic(String numeroSuscripcionNoDomic) {
		this.numeroSuscripcionNoDomic = numeroSuscripcionNoDomic;
	}
	public double getVersionXML() {
		return versionXML;
	}

	public void setVersionXML(double versionXML) {
		this.versionXML = versionXML;
	}

	public String getSubTipoComprobanteTmp() {
		return subTipoComprobanteTmp;
	}

	public void setSubTipoComprobanteTmp(String subTipoComprobanteTmp) {
		this.subTipoComprobanteTmp = subTipoComprobanteTmp;
	}
}
