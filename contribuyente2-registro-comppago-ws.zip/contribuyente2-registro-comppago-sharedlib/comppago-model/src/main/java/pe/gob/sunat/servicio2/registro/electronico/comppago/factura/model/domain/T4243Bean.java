//package pe.gob.sunat.servicio2.registro.electronico.comppago.factura.model.domain;
package pe.gob.sunat.servicio2.registro.electronico.comppago.factura.model.domain;
import java.io.Serializable;

import pe.gob.sunat.framework.spring.util.date.FechaBean;

public class T4243Bean implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = -5843889833667047706L;
	/**
	 * 
	 */
	private String num_ruc;
    private String cod_cpe;
    private String num_serie_cpe ;
    private Integer num_cpe;
    private Long num_id_xml;
    private String arc_xml;
    private byte[] arc_zip;
    private FechaBean fec_xml;
    private String ind_procedencia;
    private String des_nombre;
    private String cod_usumodif;
    private FechaBean fec_modif;
    
	public String getNum_ruc() {
		return num_ruc;
	}
	public void setNum_ruc(String numRuc) {
		num_ruc = numRuc;
	}
	public String getCod_cpe() {
		return cod_cpe;
	}
	public void setCod_cpe(String codCpe) {
		cod_cpe = codCpe;
	}
	public String getNum_serie_cpe() {
		return num_serie_cpe;
	}
	public void setNum_serie_cpe(String numSerieCpe) {
		num_serie_cpe = numSerieCpe;
	}
	public Integer getNum_cpe() {
		return num_cpe;
	}
	public void setNum_cpe(Integer numCpe) {
		num_cpe = numCpe;
	}
	public Long getNum_id_xml() {
		return num_id_xml;
	}
	public void setNum_id_xml(Long numIdXml) {
		num_id_xml = numIdXml;
	}
	public String getArc_xml() {
		return arc_xml;
	}
	public void setArc_xml(String arcXml) {
		arc_xml = arcXml;
	}
	public FechaBean getFec_xml() {
		return fec_xml;
	}
	public void setFec_xml(FechaBean fecXml) {
		fec_xml = fecXml;
	}
	public String getInd_procedencia() {
		return ind_procedencia;
	}
	public void setInd_procedencia(String indProcedencia) {
		ind_procedencia = indProcedencia;
	}
	public String getDes_nombre() {
		return des_nombre;
	}
	public void setDes_nombre(String desNombre) {
		des_nombre = desNombre;
	}
	public String getCod_usumodif() {
		return cod_usumodif;
	}
	public void setCod_usumodif(String codUsumodif) {
		cod_usumodif = codUsumodif;
	}
	public FechaBean getFec_modif() {
		return fec_modif;
	}
	public void setFec_modif(FechaBean fecModif) {
		fec_modif = fecModif;
	}
	public byte[] getArc_zip() {
	    return arc_zip;
	}
	public void setArc_zip(byte[] arc_zip) {
	    this.arc_zip = arc_zip;
	}
    

}
