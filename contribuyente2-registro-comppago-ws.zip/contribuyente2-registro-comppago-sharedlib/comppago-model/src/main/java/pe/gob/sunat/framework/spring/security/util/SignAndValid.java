package pe.gob.sunat.framework.spring.security.util;

public abstract class SignAndValid {
	protected String storage;
	protected String storagePassword;
	protected String certAlias;
	protected String certPassword;
	
	public String getStorage() {
		return storage;
	}  
	
	public void setStorage(String storage) {
		this.storage = storage;
	}
	
	public String getStoragePassword() {
		return storagePassword;
	}
	
	public void setStoragePassword(String storagePassword) {
		this.storagePassword = storagePassword;
	}
	
	public String getCertAlias() {
		return certAlias;
	}
	
	public void setCertAlias(String certAlias) {
		this.certAlias = certAlias;
	}
	
	public String getCertPassword() {
		return certPassword;
	}
	
	public void setCertPassword(String certPassword) {
		this.certPassword = certPassword;
	}
	
	public abstract Object[] sign(Object[] objs);
	public abstract Object[] signLibro(Object[] objs);
	public abstract Object[] validate(Object[] objs);
}