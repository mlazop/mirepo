package pe.gob.sunat.framework.spring.security.service;

import java.util.Map;

import org.w3c.dom.Document;
import org.w3c.dom.Node;

public interface DigitalCertificateService {
	public void firmaDocumentoXml(Document doc, Node nodeSign, String idReference);
	public void firmaDocumentoXmlLibro(Document doc, Node nodeSign, String idReference);
	public void firmaDocumentoXmlLibro(Document doc, Node nodeSign, String idReference, Map mldap);
}   
