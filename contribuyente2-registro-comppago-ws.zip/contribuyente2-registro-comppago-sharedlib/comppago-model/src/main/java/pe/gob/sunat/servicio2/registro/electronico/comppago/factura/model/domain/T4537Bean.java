//package pe.gob.sunat.servicio2.registro.electronico.comppago.factura.model.domain;
package pe.gob.sunat.servicio2.registro.electronico.comppago.factura.model.domain;

import pe.gob.sunat.framework.spring.util.date.FechaBean;
import java.io.Serializable;

public class T4537Bean implements Serializable {
	private static final long serialVersionUID = 1L;
	
	private String ticket;
	private Integer correlativo;
	private String nombreArchivo;
	private Integer tamanioArchivo;
	private FechaBean fechaInicio;
	private FechaBean fechaFin;
	private Integer estadoProceso;
	private Integer codigoResultado;	
	private String usuarioModificador;
	private FechaBean fechaModificacion;

	public String getTicket() {
		return ticket;
	}

	public void setTicket(String ticket) {
		this.ticket = ticket;
	}

	public Integer getCorrelativo() {
		return correlativo;
	}

	public void setCorrelativo(Integer correlativo) {
		this.correlativo = correlativo;
	}

	public String getNombreArchivo() {
		return nombreArchivo;
	}

	public void setNombreArchivo(String nombreArchivo) {
		this.nombreArchivo = nombreArchivo;
	}

	public Integer getTamanioArchivo() {
		return tamanioArchivo;
	}

	public void setTamanioArchivo(Integer tamanioArchivo) {
		this.tamanioArchivo = tamanioArchivo;
	}

	public FechaBean getFechaInicio() {
		return fechaInicio;
	}

	public void setFechaInicio(FechaBean fechaInicio) {
		this.fechaInicio = fechaInicio;
	}

	public FechaBean getFechaFin() {
		return fechaFin;
	}

	public void setFechaFin(FechaBean fechaFin) {
		this.fechaFin = fechaFin;
	}

	public Integer getEstadoProceso() {
		return estadoProceso;
	}

	public void setEstadoProceso(Integer estadoProceso) {
		this.estadoProceso = estadoProceso;
	}

	public Integer getCodigoResultado() {
		return codigoResultado;
	}

	public void setCodigoResultado(Integer codigoResultado) {
		this.codigoResultado = codigoResultado;
	}

	public String getUsuarioModificador() {
		return usuarioModificador;
	}

	public void setUsuarioModificador(String usuarioModificador) {
		this.usuarioModificador = usuarioModificador;
	}

	public FechaBean getFechaModificacion() {
		return fechaModificacion;
	}

	public void setFechaModificacion(FechaBean fechaModificacion) {
		this.fechaModificacion = fechaModificacion;
	}
}