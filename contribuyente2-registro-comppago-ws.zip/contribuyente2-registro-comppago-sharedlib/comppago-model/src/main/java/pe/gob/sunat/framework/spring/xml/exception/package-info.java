/**
 * 
 */
/**
 * @author maguilarac
 *
 */
package pe.gob.sunat.framework.spring.xml.exception;