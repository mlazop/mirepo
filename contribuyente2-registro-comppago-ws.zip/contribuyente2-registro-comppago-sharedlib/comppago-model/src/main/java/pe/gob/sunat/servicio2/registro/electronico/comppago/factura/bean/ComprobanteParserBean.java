package pe.gob.sunat.servicio2.registro.electronico.comppago.factura.bean;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.Reader;
import java.io.StringReader;
import java.io.StringWriter;
import java.math.BigDecimal;
import java.net.MalformedURLException;
import java.net.URL;
import java.rmi.RemoteException;
import java.security.Provider;
import java.util.Date;
import java.util.Map;
import java.util.Properties;

import javax.security.cert.X509Certificate;
import javax.xml.XMLConstants;
import javax.xml.crypto.dsig.XMLSignature;
import javax.xml.crypto.dsig.XMLSignatureFactory;
import javax.xml.crypto.dsig.dom.DOMValidateContext;
import javax.xml.namespace.QName;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
//import javax.xml.rpc.ParameterMode;
import javax.xml.transform.OutputKeys;
import javax.xml.transform.Result;
import javax.xml.transform.Source;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;
import javax.xml.transform.stream.StreamSource;
import javax.xml.validation.Schema;
import javax.xml.validation.SchemaFactory;
import javax.xml.validation.Validator;
import javax.xml.xpath.XPath;
import javax.xml.xpath.XPathFactory;

//import org.apache.axis.client.Call;
//import org.apache.axis.client.Service;
//import org.apache.axis.encoding.XMLType;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.apache.velocity.Template;
import org.apache.velocity.VelocityContext;
import org.apache.velocity.app.VelocityEngine;
import org.w3c.dom.Document;
import org.w3c.dom.Node;
import org.xml.sax.InputSource;
import org.xml.sax.SAXException;

import pe.gob.sunat.framework.spring.util.date.FechaBean;
import pe.gob.sunat.framework.spring.util.exception.ServiceException;
import pe.gob.sunat.framework.spring.xml.util.ConfigErrorHandler;
//import pe.gob.sunat.servicio2.registro.comppago.factura.gem.util.security.X509KeySelector;
import pe.gob.sunat.servicio2.registro.electronico.comppago.factura.context.ComprobanteContext;
//import pe.gob.sunat.tecnologia2.validadoc.bean.VerifySignResult;

public class ComprobanteParserBean {
	protected final Log log = LogFactory.getLog(getClass());
	private Document doc;
	private XPath xPath;
	private ComprobanteContext context;
	private String directorioTemplate;
	private Source schemaSource;
	
	public ComprobanteParserBean() {}
	
	public ComprobanteParserBean(ComprobanteContext context) {
		this.context = context;
	}
	
	public void setComprobanteContext(ComprobanteContext context) {
		this.context = context;
		if(this.doc != null) {
			XPathFactory factory = XPathFactory.newInstance();
			this.xPath = factory.newXPath();
			this.xPath.setNamespaceContext(this.context.getNamespaceContext());
		}
	}
	
	public Document getDocument() {
		return this.doc;
	}
	
	public XPath getXPath() {
		return this.xPath;
	}
	
	public Node getNodeToSign() {
		return this.context.getNodeToSign(this.doc, this.xPath); 
	}

	public void setDirectorioTemplate(String directorioTemplate) {
		File dirTempo = new File(directorioTemplate);
		this.directorioTemplate = dirTempo.getAbsolutePath();
	}

	public void setSchemaSource(File schema) {
		this.setSchemaSource(new StreamSource(schema));
	}

	public void setSchemaSource(Source schema) {
		this.schemaSource =  schema;
	}	
	
	public Source getSchemaSource() {
		return this.schemaSource;
	}
	
	public String getSchema() {
		return this.context.getSchema();
	}
	
	public Document parse(InputStream in) {	
		try {
//			Reader reader = new InputStreamReader(in, "ISO-8859-1") ;
//			InputSource is = new InputSource(reader) ;
			
			log.debug("ComprobanteParserBean parse");
			DocumentBuilderFactory dbf = DocumentBuilderFactory.newInstance();
			dbf.setNamespaceAware(true);
			DocumentBuilder builder = dbf.newDocumentBuilder();
			builder.setErrorHandler(new ConfigErrorHandler());			
			doc = builder.parse(in);
			return doc;
		}
		catch(Exception e) {
			log.error(e,e) ; 
			throw new ServiceException(this, "El Comprobante ingresado no cumple con el estandar establecido.");
		}
	}
	
	private String[] obtenerTipoNotaCredito(String cod){
		if("21".equals(cod))return new String[] {"01","Anulaci�n de la operaci�n"} ;
		if("22".equals(cod))return new String[] {"02","Anulaci�n por error en el RUC"} ;
		if("25".equals(cod))return new String[] {"03","Correcci�n por error en la descripci�n"} ;
		if("23".equals(cod))return new String[] {"04","Descuento global"} ;
		if("27".equals(cod))return new String[] {"05","Descuento por �tem"} ;
		if("24".equals(cod))return new String[] {"06","Devoluci�n total"} ;
		if("26".equals(cod))return new String[] {"07","Devoluci�n por �tem"} ;
	
		return new String[] {"",""} ; 
	}
	private ComprobanteBean valoresFactura(ComprobanteBean comprobante){
		log.debug(".:: Actualizacion de valores Factura ::.");
		for(DetalleComprobanteBean itemBean : comprobante.getDetalleComprobanteBean()){
			if("TI02".equals(itemBean.getTipoItem().trim())&& !"ZZ".equals(itemBean.getUnidadMedida().trim()))
				itemBean.setUnidadMedida("ZZ");
				
		}
		return comprobante ;
	}
	private ComprobanteBean valoresNC(ComprobanteBean comprobante){
		log.debug(".:: Actualizacion de valores NC ::.");
		String[] tipoComp = obtenerTipoNotaCredito(comprobante.getSubTipoComprobante().trim());
		comprobante.setSubTipoComprobanteTmp(tipoComp[0]) ;
		comprobante.setTipoComprobanteDesc(tipoComp[1]);
		if(null==comprobante.getTotalOtrosTributos())
			comprobante.setTotalOtrosTributos(new BigDecimal(0.0)) ;
		
		return comprobante ;
	}
	private ComprobanteBean valoresND(ComprobanteBean comprobante){
		log.debug(".:: Actualizacion de valores ND::.");
		String subTip = comprobante.getSubTipoComprobante().trim() ;
		if("41".equals(subTip)){
			comprobante.setSubTipoComprobanteTmp("01") ;
			comprobante.setTipoComprobanteDesc("Intereses por mora");	
		}else if("42".equals(subTip)){
			comprobante.setSubTipoComprobanteTmp("02") ;
			comprobante.setTipoComprobanteDesc("Aumento en el valor");
		}
		
		return comprobante ;
	}
	
	public Document parserXml(ComprobanteBean comprobante) {
		log.debug(".:: ComprobanteBean antes de paso al XML ::.");
		log.debug(comprobante);
		try {
			/** Antes de generar el XML se homologa los valores de los catalogos de GEM */
			if("10".equals(comprobante.getTipoComprobante().trim()))
				comprobante = valoresFactura(comprobante);
			else if("11".equals(comprobante.getTipoComprobante().trim()))
				comprobante = valoresNC(comprobante);
			else if("12".equals(comprobante.getTipoComprobante().trim()))
				comprobante = valoresND(comprobante);
			
			log.debug(".:: ComprobanteBean despues de la actualizacion de valores ::.");
			log.debug(comprobante);
			
			Properties props = new Properties();
			props.setProperty("file.resource.loader.path", this.directorioTemplate);
			
	        VelocityEngine ve = new VelocityEngine();
	        ve.init(props);
	        
	        Template t = ve.getTemplate(this.context.getTemplate());
	        VelocityContext context = new VelocityContext();
	        context.put("cp", comprobante);
	        context.put("util", ComprobanteUtilBean.class);
	        context.put("fb", new FechaBean(comprobante.getFechaEmision(), "dd/MM/yyyy"));
	        
	        StringWriter writer = new StringWriter();
	        t.merge(context, writer);
	        
			DocumentBuilderFactory dbf = DocumentBuilderFactory.newInstance();
			dbf.setNamespaceAware(true);
			DocumentBuilder db = dbf.newDocumentBuilder();
			InputSource is = new InputSource(new StringReader(writer.toString()));
			this.doc = db.parse(is);
			
			if(this.doc != null) {
				XPathFactory factory = XPathFactory.newInstance();
				this.xPath = factory.newXPath();
				this.xPath.setNamespaceContext(this.context.getNamespaceContext());
			}
			
			return this.doc; 
		}
		catch(ServiceException e) {
			log.error(e);
			throw e;
		}
		catch(Exception e) {
			log.error(e);
			throw new ServiceException(this, e);
		}
	}

	/*
	public Document parserXml(ComprobanteBean comprobante) {
		try {
			DocumentBuilderFactory dbf = DocumentBuilderFactory.newInstance();
			dbf.setNamespaceAware(true);
			DocumentBuilder db = dbf.newDocumentBuilder();
			InputStream is = new FileInputStream(this.directorioTemplate + "/" +this.context.getTemplate());
			this.doc = db.parse(is);
			
			if(this.doc != null) {
				XPathFactory factory = XPathFactory.newInstance();
				this.xPath = factory.newXPath();
				this.xPath.setNamespaceContext(this.context.getNamespaceContext());
				this.context.generaXml(this.doc, this.xPath, comprobante);
			}
			return this.doc; 
		}
		catch(ServiceException e) {
			throw e;
		}
		catch(Exception e) {
			throw new ServiceException(this, e);
		}
	}
	
	*/
	
	public Source validate() {
		if(this.getSchemaSource() == null)
			throw new ServiceException(this, "Se tiene que asignar un SchemaSource a ParseContext");
		return this.validate(this.getSchemaSource());
	}
	
	public Source validate(Source schemaSource) {
		if(context == null) throw new ServiceException(this, "No se asigno un ParserContext para el documento");
		
		try {
			Source xmlSource = new DOMSource(doc);
			log.debug("ComprobanteParserBean validate");
			SchemaFactory factory = SchemaFactory.newInstance(XMLConstants.W3C_XML_SCHEMA_NS_URI);
			Schema schema = factory.newSchema(schemaSource);
			Validator validator = schema.newValidator();
			validator.validate(new DOMSource(this.doc));
			return xmlSource;
		} catch (SAXException e) {
			//throw new RuntimeException("Ocurrio un error al validar el documento XML:", e);
			throw new ServiceException(this, "Ocurrio un error al validar el archivo XML: " + e.getLocalizedMessage());
		} catch (IOException e) {
			throw new ServiceException(this, "Ocurrio un error al tratar de abrir los archivos de schema");
		}
	}
	
		//Ini IMR
//	public int validate(boolean soloFirma) throws ServiceException, Exception {
//		return validate(soloFirma, null).getResultCode();
//	}
//	
//	public VerifySignResult validate(boolean soloFirma, Date signDate) throws ServiceException, Exception {
//		log.debug("context :" + context);
//		Source xmlSource = null;
//		if (!soloFirma){
//			xmlSource = validate();
//		} else {
//			xmlSource = new DOMSource(doc);
//		}
//
//		ByteArrayOutputStream outputStream = new ByteArrayOutputStream();
//		if(log.isDebugEnabled()) {
//			log.debug("-->Doc : " + doc);
//		}
//		
//		Result outputTarget = new StreamResult(outputStream);
//		TransformerFactory trans = TransformerFactory.newInstance();
//		Transformer transfor = trans.newTransformer();
//		
//		// Se usa el encoding del archivo XML de origen Guia usa el encodign "ISO-8859-1"
//		String encoding = doc.getXmlEncoding ();
//		if(encoding != null && !"".equals(encoding)) {
//			transfor.setOutputProperty(OutputKeys.ENCODING, encoding);
//		}
//		transfor.transform(xmlSource, outputTarget);
//		
//		return callWebservice(outputStream, signDate);
//	}
	//Fin IMR
	
//	private VerifySignResult callWebservice(ByteArrayOutputStream outputStream, Date signDate) {
//		byte[] archivo = outputStream.toByteArray();
//		String codApli = "ERHE";
//		String tipo = "xml";
//		Service service = new Service();
//		try {
//			Call callValidaXML = (Call)service.createCall();
//			//URL urlWebService = new URL("http://localhost:7020/cl-ti-itvalidadoc2-service/ValidadorFirmaDigitalService");//Desarrollo
//			//URL urlWebService = new URL("https://150.50.2.7/cl-ti-itvalidadoc2-service/ValidadorFirmaDigitalService");//Integracion
//			//URL urlWebService = new URL("http://192.168.34.11:80/cl-ti-itvalidadoc2-service/ValidadorFirmaDigitalService");//Calidad
//		    URL urlWebService = new URL("http://wssunat:8080/cl-ti-itvalidadoc2-service/ValidadorFirmaDigitalService");//Produccion
//			callValidaXML.setTargetEndpointAddress(urlWebService);
//			QName qname = new QName( "http://tempuri.org/", "result" );
//			callValidaXML.registerTypeMapping(VerifySignResult.class, qname,
//			new org.apache.axis.encoding.ser.BeanSerializerFactory(VerifySignResult.class, qname),
//			new org.apache.axis.encoding.ser.BeanDeserializerFactory(VerifySignResult.class, qname)); 
//			
//			callValidaXML.setOperationName(new QName("http://tempuri.org/", "valida1"));
//			callValidaXML.addParameter("codApli", XMLType.XSD_STRING, ParameterMode.IN);
//			callValidaXML.addParameter("tipo", XMLType.XSD_STRING, ParameterMode.IN);
//			callValidaXML.addParameter("archivo", XMLType.XSD_BASE64, ParameterMode.IN);
//			callValidaXML.addParameter("fecFirma", XMLType.XSD_DATE, ParameterMode.IN);
//			callValidaXML.setReturnClass(VerifySignResult.class);
//			Object[] params = new Object[] {codApli.toString(), tipo.toString(), archivo, signDate};
//			VerifySignResult verifySignResult = (VerifySignResult)callValidaXML.invoke(params);
//			return verifySignResult;
//		} catch (MalformedURLException e) {
//			throw new RuntimeException("La direccion del servicio web no fue escrita de forma correcta.", e);
//		} catch (RemoteException e) {
//			log.warn(e);
//			throw new ServiceException(this, "El servicio no se encuentra disponible.");
//		} catch (javax.xml.rpc.ServiceException e) {
//			throw new RuntimeException("Ocurrio un error al iniciar el servicio.", e);
//		}
//	}
	
//	public void validate(Map mldap, boolean soloFirma )throws ServiceException, Exception {
//
//		if(context == null) throw new Exception("No se asigno un ParserContext para el documento");
//		
//		if (!soloFirma){
//			try {
//				SchemaFactory factory = SchemaFactory.newInstance(XMLConstants.W3C_XML_SCHEMA_NS_URI);
//				Schema schema = factory.newSchema(getSchemaSource());	// Validacion contra el esquema XSD
//				Validator validator = schema.newValidator();
//				validator.validate(new DOMSource(doc));
//			}
//			catch(Exception e) {
//				e.printStackTrace(); 
//				throw new ServiceException(this,"El Documento Electronico ingresado no cumple con el estandar establecido.");
//			}
//		}
//		
//		log.debug("Doc : "+ doc);
//		log.debug("xpath :" + xPath.toString());
//		checkSign(context.getNodeSigned(doc, xPath), mldap);
//	}
	
//	public void checkSign(Node node, Map mldap)	throws ServiceException, Exception {
//		XMLSignature signature=null; 
//		boolean coreValidity =false;
//		String providerName = System.getProperty("jsr105Provider", "org.jcp.xml.dsig.internal.dom.XMLDSigRI");
//		XMLSignatureFactory fac = XMLSignatureFactory.getInstance("DOM", (Provider) Class.forName(providerName)
//				.newInstance());
//		X509KeySelector keySelector = new X509KeySelector();
//		DOMValidateContext valContext = new DOMValidateContext(keySelector, node);
//		try{
//			signature= fac.unmarshalXMLSignature(valContext);
//		    coreValidity = signature.validate(valContext);
//		}catch (Exception e){
//			e.printStackTrace(); 
//			throw new ServiceException(this,"El Documento Electr?nico ingresado ha sido alterado.");
//		}
// 
//		if(coreValidity == false) {
//			if(!signature.getSignatureValue().validate(valContext)) {
//				throw new ServiceException(this,"El Documento Electr?nico ingresado ha sido alterado.");
//			}
//			throw new ServiceException(this,"El Documento Electr?nico ingresado ha sido alterado.");
//		}
//		
//	//	KeyStore ks = KeyStore.getInstance("JKS");
//		//PrivateKey keyEntry = (PrivateKey)mldap.get("pkey");
//		X509Certificate cert = (X509Certificate) mldap.get("certificado");
//		
//		
//		//ks.load(new FileInputStream(storage), storagePassword.toCharArray());
//		//X509Certificate cert = (X509Certificate) ks.getCertificate(certAlias);
//		if(!cert.getPublicKey().equals(signature.getKeySelectorResult().getKey()))
//			throw new ServiceException(this,"El Documento Electr?nico ingresado no ha sido generado por el Sistema de Emisi?n Electr?nica de SUNAT.");
//	}
	
	public void generaArchivoXml(OutputStream out) {
		try {
			DOMSource source = new DOMSource(this.doc);
			StreamResult result = new StreamResult(out);
			TransformerFactory transformerFactory = TransformerFactory.newInstance();
			Transformer transformer = transformerFactory.newTransformer();
			transformer.setOutputProperty(OutputKeys.METHOD, "xml");
			transformer.setOutputProperty(OutputKeys.ENCODING,"ISO-8859-1");

			transformer.transform(source, result);
		}
		catch(Exception e) {
			throw new ServiceException(this, e);
		}
	}
	
	public ComprobanteBean generaComprobanteBean() {
		log.debug("ComprobanteBean generaComprobanteBean()");
		return this.context.generaComprobanteBean(this.doc, this.xPath);
	}
}
