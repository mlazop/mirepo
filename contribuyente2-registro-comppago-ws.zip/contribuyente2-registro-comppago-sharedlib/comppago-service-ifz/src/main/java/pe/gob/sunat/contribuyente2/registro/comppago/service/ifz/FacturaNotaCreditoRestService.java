package pe.gob.sunat.contribuyente2.registro.comppago.service.ifz;

import pe.gob.sunat.servicio2.registro.electronico.comppago.factura.bean.ComprobanteBean;

public interface FacturaNotaCreditoRestService {
	public ComprobanteBean recuperarInfoFacturaNotaCredito(String ruc,String serie,String numero,String tipo);
}
