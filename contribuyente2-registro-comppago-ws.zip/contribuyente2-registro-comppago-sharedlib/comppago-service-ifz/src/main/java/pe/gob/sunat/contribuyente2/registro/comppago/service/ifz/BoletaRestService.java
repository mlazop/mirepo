package pe.gob.sunat.contribuyente2.registro.comppago.service.ifz;

import java.io.IOException;
import java.util.List;
import java.util.Map;

import javax.naming.NamingException;

import pe.gob.sunat.servicio2.registro.electronico.comppago.boleta.bean.ArchivoComprobanteBean;
import pe.gob.sunat.servicio2.registro.electronico.comppago.boleta.bean.ComprobanteBean;

public interface BoletaRestService {
	public ComprobanteBean recuperarInfoBoleta(String ruc,String serie,String numero,String tipo);
}
