package pe.gob.sunat.contribuyente2.registro.comppago.service.imp;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.Date;
import java.util.zip.ZipEntry;
import java.util.zip.ZipInputStream;

import pe.gob.sunat.framework.spring.util.bean.MensajeBean;
import pe.gob.sunat.framework.spring.util.exception.ServiceException;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

public class ServiceCommonFunction {

    protected final static Log log = LogFactory.getLog(ServiceCommonFunction.class);
	 
	public byte[] decompress(byte[] data) {

		try {

			InputStream theFile = new ByteArrayInputStream(data);
			ZipInputStream stream = new ZipInputStream(theFile);
			byte[] buffer = new byte[2048];
			ByteArrayOutputStream outputStream = new ByteArrayOutputStream(data.length);

			ZipEntry entry;
			while ((entry = stream.getNextEntry()) != null) {
				String s = String.format("Entry: %s len %d added %TD", entry.getName(), entry.getSize(),
						new Date(entry.getTime()));
				if (log.isDebugEnabled())
					log.debug(s);

				try {
					outputStream = new ByteArrayOutputStream();
					;
					int len = 0;
					while ((len = stream.read(buffer)) > 0) {
						outputStream.write(buffer, 0, len);
					}
				} finally {
					if (outputStream != null)
						outputStream.close();
				}
			}

			byte[] output = outputStream.toByteArray();
			return output;
		} catch (IOException e) {
			log.error(">>ConsultarServiceImpl Error !! " + e.getMessage(), e);
			MensajeBean msg = new MensajeBean();
			msg.setError(true);
			msg.setMensajeerror("Error al tratar de descomprimir el archivo ZIP");
			throw new ServiceException(this, msg);
		}

	}
}
