package pe.gob.sunat.servicio2.registro.electronico.comppago.boleta.service;

import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.BufferedReader;
import java.io.ByteArrayInputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.IOException;
import java.io.OutputStream;
import java.util.ArrayList;
import java.util.List;
import java.util.zip.ZipEntry;
import java.util.zip.ZipInputStream;
import java.util.zip.ZipOutputStream;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.apache.commons.io.FileUtils;
import org.w3c.dom.Document;
import pe.gob.sunat.framework.spring.security.service.DigitalCertificateService;
import pe.gob.sunat.framework.spring.util.dao.SequenceDAO;
import pe.gob.sunat.framework.spring.util.exception.ServiceException;
import pe.gob.sunat.servicio2.registro.electronico.comppago.boleta.bean.ArchivoComprobanteBean;
import pe.gob.sunat.servicio2.registro.electronico.comppago.boleta.bean.ComprobanteBean;
import pe.gob.sunat.servicio2.registro.electronico.comppago.boleta.bean.ComprobanteParserBean;
import pe.gob.sunat.servicio2.registro.electronico.comppago.boleta.bean.ComprobanteUtilBean;
import pe.gob.sunat.servicio2.registro.electronico.comppago.boleta.context.BoletaContext;
import pe.gob.sunat.servicio2.registro.electronico.comppago.boleta.context.NotaCreditoContext;
import pe.gob.sunat.servicio2.registro.electronico.comppago.boleta.context.NotaDebitoContext;

public class ProcesaArchivoComprobanteServiceImpl implements ProcesaArchivoComprobanteService {
	protected final Log log = LogFactory.getLog(getClass());
	public static final int LENGTH_BUFFER = 1024;
	private String directorioTemporal;
	private String directorioTemplate;
	private String directorioSchemas;
	private String directorioResources;
	
	private String directorioTemporalBoleta;
	private String directorioTemplateBoleta;
	private String directorioSchemasBoleta;
	private String directorioResourcesBoleta;
	
	private String directorioTemporalNC;
	private String directorioTemplateNC;
	private String directorioSchemasNC;
	private String directorioResourcesNC;	
	
	private String directorioTemporalND;
	private String directorioTemplateND;
	private String directorioSchemasND;
	private String directorioResourcesND;	
	
	private DigitalCertificateService certificacionDigitalService;
	
	private SequenceDAO daoSequence;	
		
	public String getDirectorioTemporalBoleta() {
		return directorioTemporalBoleta;
	}

	public void setDirectorioTemporalBoleta(String directorioTemporalBoleta) {
		this.directorioTemporalBoleta = directorioTemporalBoleta;
	}

	public String getDirectorioTemplateBoleta() {
		return directorioTemplateBoleta;
	}

	public void setDirectorioTemplateBoleta(String directorioTemplateBoleta) {
		this.directorioTemplateBoleta = directorioTemplateBoleta;
	}

	public String getDirectorioSchemasBoleta() {
		return directorioSchemasBoleta;
	}

	public void setDirectorioSchemasBoleta(String directorioSchemasBoleta) {
		this.directorioSchemasBoleta = directorioSchemasBoleta;
	}

	public String getDirectorioResourcesBoleta() {
		return directorioResourcesBoleta;
	}

	public void setDirectorioResourcesBoleta(String directorioResourcesBoleta) {
		this.directorioResourcesBoleta = directorioResourcesBoleta;
	}

	public String getDirectorioTemporalNC() {
		return directorioTemporalNC;
	}

	public void setDirectorioTemporalNC(String directorioTemporalNC) {
		this.directorioTemporalNC = directorioTemporalNC;
	}

	public String getDirectorioTemplateNC() {
		return directorioTemplateNC;
	}

	public void setDirectorioTemplateNC(String directorioTemplateNC) {
		this.directorioTemplateNC = directorioTemplateNC;
	}

	public String getDirectorioSchemasNC() {
		return directorioSchemasNC;
	}

	public void setDirectorioSchemasNC(String directorioSchemasNC) {
		this.directorioSchemasNC = directorioSchemasNC;
	}

	public String getDirectorioResourcesNC() {
		return directorioResourcesNC;
	}

	public void setDirectorioResourcesNC(String directorioResourcesNC) {
		this.directorioResourcesNC = directorioResourcesNC;
	}

	public String getDirectorioTemporalND() {
		return directorioTemporalND;
	}

	public void setDirectorioTemporalND(String directorioTemporalND) {
		this.directorioTemporalND = directorioTemporalND;
	}

	public String getDirectorioTemplateND() {
		return directorioTemplateND;
	}

	public void setDirectorioTemplateND(String directorioTemplateND) {
		this.directorioTemplateND = directorioTemplateND;
	}

	public String getDirectorioSchemasND() {
		return directorioSchemasND;
	}

	public void setDirectorioSchemasND(String directorioSchemasND) {
		this.directorioSchemasND = directorioSchemasND;
	}

	public String getDirectorioResourcesND() {
		return directorioResourcesND;
	}

	public void setDirectorioResourcesND(String directorioResourcesND) {
		this.directorioResourcesND = directorioResourcesND;
	}

	public String getDirectorioTemporal() {
		return directorioTemporal;
	}

	public void setDirectorioTemporal(String directorioTemporal) {
		this.directorioTemporal = directorioTemporal;
	}

	public String getDirectorioTemplate() {
		return directorioTemplate;
	}

	public void setDirectorioTemplate(String directorioTemplate) {
		this.directorioTemplate = directorioTemplate;
	}

	public String getDirectorioSchemas() {
		return directorioSchemas;
	}

	public void setDirectorioSchemas(String directorioSchemas) {
		this.directorioSchemas = directorioSchemas;
	}

	public DigitalCertificateService getCertificacionDigitalService() {
		return certificacionDigitalService;
	}

	public String getDirectorioResources() {
		return directorioResources;
	}

	public void setDirectorioResources(String directorioResources) {
		this.directorioResources = directorioResources;
	}
	
	public void setCertificacionDigitalService(DigitalCertificateService certificacionDigitalService) {
		this.certificacionDigitalService = certificacionDigitalService;
	}
	
	public SequenceDAO getDaoSequence() {
		return daoSequence;
	}

	public void setDaoSequence(SequenceDAO daoSequence) {
		this.daoSequence = daoSequence;
	}	

	public ArchivoComprobanteBean generaComprobanteArchivo(ComprobanteBean comprobante) {
		if (log.isDebugEnabled()){ log.debug( "generaComprobanteArchivo(" + comprobante + " )");}
		ArchivoComprobanteBean archivo = new ArchivoComprobanteBean();
		archivo.setTipoComprobante(comprobante.getTipoComprobante());		
		asignaRutas(archivo); 
		try {
			File dirTempo = new File(this.directorioTemporal);
//			File dirResour   = new File(this.directorioResources);
			if(dirTempo.exists() && dirTempo.isDirectory()) {
				/** Generamos el nombre del archivo para el comprobante */
				/**
					String fileName = comprobante.getNumeroRuc().trim() +
								  comprobante.getTipoComprobante().trim() +
								  comprobante.getSerieComprobante().trim() +
								  comprobante.getNumeroComprobante().toString().trim();
				*/
				/** BOLETAEB01-NNNRRRRRRRRRRR.xml*/
				String fileName = "BOLETA" + comprobante.getSerieComprobante().trim() + "-" +
									comprobante.getNumeroComprobante().toString().trim() +
									comprobante.getNumeroRuc().trim();
				String tipoComprobante = comprobante.getTipoComprobante().trim();
				
				if(tipoComprobante.equals(ComprobanteUtilBean.BOLETA)) {
					fileName = "BOLETA" + comprobante.getSerieComprobante().trim() + "-" +
					comprobante.getNumeroComprobante().toString().trim() +
					comprobante.getNumeroRuc().trim();
				}
				else if(tipoComprobante.equals(ComprobanteUtilBean.NOTA_CREDITO)) {
					fileName = "NOTA_CREDITO" + comprobante.getSerieComprobante().trim() + "-" +
					comprobante.getNumeroComprobante().toString().trim() +
					comprobante.getNumeroRuc().trim();
				}
				else if(tipoComprobante.equals(ComprobanteUtilBean.NOTA_DEBITO)) {
					 fileName = "NOTA_DEBITO" + comprobante.getSerieComprobante().trim() + "-" +
					comprobante.getNumeroComprobante().toString().trim() +
					comprobante.getNumeroRuc().trim();
				}
				else {
					throw new ServiceException(this, "Tipo de comprobante no registrado.");
				}
				File fileXml = new File(dirTempo.getAbsolutePath() + "/" + fileName + ".xml");
				log.debug("fileXml.getName() --> " + fileXml.getName());
				
				this.generaArchivoComprobanteXml(comprobante, fileXml);	/** Generamos el archivo XML */

				log.debug("fileXml.getAbsolutePath() --> " + fileXml.getAbsolutePath());
				ArchivoComprobanteBean archivoComprobanteBean = new ArchivoComprobanteBean();
				archivoComprobanteBean.setNumeroRuc(comprobante.getNumeroRuc());
				archivoComprobanteBean.setSerieComprobante(comprobante.getSerieComprobante());
				archivoComprobanteBean.setTipoComprobante(comprobante.getTipoComprobante());
				archivoComprobanteBean.setNumeroComprobante(comprobante.getNumeroComprobante());
				archivoComprobanteBean.setContenidoArchivoXml(getContenidoArchivoTxt(fileXml));
				archivoComprobanteBean.setNombreArchivoXml(fileXml.getName());
				archivoComprobanteBean.setNumIdArchivoXml(this.getNumeroIdArchivoXml());
				return archivoComprobanteBean;
			} else {
				throw new ServiceException(this, "No existe el directorio temporal: " + this.directorioTemporal);
			}
		} catch(ServiceException e) {
			log.error(e);
			throw e;
		} catch(Exception e) {
			log.error(e);
			throw new ServiceException(this, e);
		}
	}
	
	/**
	 * Metodo que convierte el objeto Boleta en formato XML segun el estandar
	 * UBL, con y sin firma digital dependiendo del parametro properties.
	 * @author Carlos Enrique Quispe Salazar
	 * @since 28-08-2008
	 * */
	public void generaDocumentoXml(OutputStream out, ComprobanteBean comprobante, boolean isSigned)
	throws ServiceException {
		ArchivoComprobanteBean archivo = new ArchivoComprobanteBean();
		archivo.setTipoComprobante(comprobante.getTipoComprobante());
		if (log.isDebugEnabled()) { log.debug("generaDocumentoXml (" + out + ", " + comprobante + ", " + isSigned + " )");}
		asignaRutas(archivo); 
		try {
			String tipoComprobante = comprobante.getTipoComprobante().trim();
			ComprobanteParserBean parser = null;

			if(tipoComprobante.equals(ComprobanteUtilBean.BOLETA)) {
				parser = new ComprobanteParserBean(new BoletaContext());
			}
			else if(tipoComprobante.equals(ComprobanteUtilBean.NOTA_CREDITO)) {
				parser = new ComprobanteParserBean(new NotaCreditoContext());
			}
			
			else if(tipoComprobante.equals(ComprobanteUtilBean.NOTA_DEBITO)) {
				parser = new ComprobanteParserBean(new NotaDebitoContext());
			}
			else {
				throw new ServiceException(this, "Tipo de comprobante no registrado.");
			}
						
			parser.setDirectorioTemplate(this.getDirectorioTemplate());
			Document doc = parser.parserXml(comprobante);
			if(doc != null) {
				this.certificacionDigitalService.firmaDocumentoXml(parser.getDocument(),
																   parser.getNodeToSign(),
																   comprobante.getReferenciaFirma());
				parser.generaArchivoXml(out);
			}
		}
		catch(ServiceException e) {
			log.error(e);
			throw e;
		}
		catch(Exception e) {
			log.error(e);
			throw new ServiceException(this, e);
		}
	}
	
	public void generaArchivoComprobanteXml(ComprobanteBean comprobante, File fileXml) {
		if (log.isDebugEnabled()) { log.debug("generaArchivoComprobanteXml (" + comprobante + ", " + fileXml + " )");}

		FileOutputStream fos = null;
		try {
			fos = new FileOutputStream(fileXml);
			this.generaDocumentoXml(fos, comprobante, true);
		}
		catch(Exception e) {
			log.error(e);
			throw new ServiceException(this, e);
		}
		finally {
			if(fos != null) {
				try {
					fos.close();
				}
				catch (IOException e) {}
			}
		}
	}

//	public void generaArchivoComprobanteZip(File fileXml, File fileZip) {
//	    byte[] buf = new byte[LENGTH_BUFFER];
//	    ZipOutputStream out = null;
//	    FileInputStream in = null;
//	    
//	    try {
//	        out = new ZipOutputStream(new FileOutputStream(fileZip));
//	        in = new FileInputStream(fileXml);
//	        out.putNextEntry(new ZipEntry(fileXml.getName()));
//	        for(int len = 0; (len = in.read(buf, 0 , LENGTH_BUFFER)) > 0; out.write(buf, 0, len));
//	        out.closeEntry();
//	    }
//	    catch(IOException e) {
//	    	throw new ServiceException(this, e);
//	    }
//	    finally {
//	    	if(in != null) {
//				try {
//					in.close();
//				}
//				catch(IOException e) {}
//	    	}
//	    	
//	    	if(out != null) {
//				try {
//					out.close();
//				}
//				catch(IOException e) {}
//	    	}
//	    }
//	}
	
	private   void asignaRutas( ArchivoComprobanteBean archivoComprobante){
		directorioResources =   directorioResourcesBoleta; 
		directorioSchemas=  directorioSchemasBoleta; 
		directorioTemplate= directorioTemplateBoleta; 
		directorioTemporal=  directorioTemporalBoleta; 
		if  ( archivoComprobante.getTipoComprobante().equals(ComprobanteUtilBean.BOLETA)){
			directorioResources =   directorioResourcesBoleta; 
			directorioSchemas=  directorioSchemasBoleta; 
			directorioTemplate= directorioTemplateBoleta; 
			directorioTemporal=  directorioTemporalBoleta;
		}
		if  ( archivoComprobante.getTipoComprobante().equals(ComprobanteUtilBean.NOTA_CREDITO)){
			directorioResources =   directorioResourcesNC; 
			directorioSchemas=  directorioSchemasNC; 
			directorioTemplate= directorioTemplateNC; 
			directorioTemporal=  directorioTemporalNC;
		}
		if  ( archivoComprobante.getTipoComprobante().equals(ComprobanteUtilBean.NOTA_DEBITO)){
			directorioResources =   directorioResourcesND; 
			directorioSchemas=  directorioSchemasND; 
			directorioTemplate= directorioTemplateND; 
			directorioTemporal=  directorioTemporalND;
		}
		if (log.isDebugEnabled()) { log.debug("directorioResources (" + directorioResources + " )");}
		if (log.isDebugEnabled()) { log.debug("directorioSchemas (" + directorioSchemas + " )");}
		if (log.isDebugEnabled()) { log.debug("directorioTemplate (" + directorioTemplate + " )");}
		if (log.isDebugEnabled()) { log.debug("directorioTemporal (" + directorioTemporal + " )");}
	}

	
	
	public File generarArchivoZip(ArchivoComprobanteBean archivoComprobante) {
		if (log.isDebugEnabled()) { log.debug("generarArchivoZip (" + archivoComprobante + " )");}
		
		File dirTempo = new File(this.directorioTemporal);
		File dirResour   = new File(this.directorioResources);
		
		File fileXml = archivoComprobante.getArchivoXml();
		String fileName = fileXml.getName().substring(0, fileXml.getName().length()-4);

		File fileZip = new File(dirTempo.getAbsolutePath() + "/" + fileName + ".zip");
		List <File> files = new ArrayList<File>();
		files.add(fileXml);

		if(archivoComprobante.isAdjuntaVisor()){
			//TODO : Aqui se tiene que verificar la version del Comprobante para saber si se le pone el visor 2.0 o el antiguo.
			boolean isVersion2 = isVersion2(archivoComprobante.getContenidoArchivoXml());		
		
			File fileCss = new File(dirResour.getAbsolutePath() + "/" + "ebxml.css");
			File fileXsl = null;
			if (archivoComprobante.getTipoComprobante().equals(ComprobanteUtilBean.BOLETA)){   //Es boleta
				fileXsl = new File(dirResour.getAbsolutePath() + "/" + ("boleta2.0.xsl"));
			}
			if (archivoComprobante.getTipoComprobante().equals(ComprobanteUtilBean.NOTA_CREDITO)){   //Es nota de credito
				fileXsl = new File(dirResour.getAbsolutePath() + "/" + (isVersion2?"notacredito2.0.xsl":"notacredito.xsl"));
			}
			if (archivoComprobante.getTipoComprobante().equals(ComprobanteUtilBean.NOTA_DEBITO)){   //Es nota de debito
				fileXsl = new File(dirResour.getAbsolutePath() + "/" + (isVersion2?"notadebito2.0.xsl":"notadebito.xsl") );
			}		
		
			files.add(fileCss);
			files.add(fileXsl);
		}
						
		this.generaArchivoComprobanteZip(files, fileZip);		/** Generamos el archivo Zip */
		return fileZip;
		
	}
	
	private boolean isVersion2(String doc){
		boolean result = false ;
		if(doc.indexOf("<cbc:CustomizationID>2.0</cbc:CustomizationID>")>0)
			result = true ;
		return result ;	
	}
		
	public void generaArchivoComprobanteZip(List <File> files, File fileZip) {
	    byte[] buf = new byte[LENGTH_BUFFER];
	    ZipOutputStream out = null;
	    FileInputStream in = null;
	    
	    try {
	    	out = new ZipOutputStream(new FileOutputStream(fileZip));
	    	for(File archivo : files) {
		        in = new FileInputStream(archivo);
		        out.putNextEntry(new ZipEntry(archivo.getName()));
		        for(int len = 0; (len = in.read(buf, 0 , LENGTH_BUFFER)) > 0; out.write(buf, 0, len));
	    	}
	        out.closeEntry();
	    }
	    catch(IOException e) {
	    	throw new ServiceException(this, e);
	    }
	    finally {
	    	if(in != null) {
				try {
					in.close();
				}
				catch(IOException e) {}
	    	}
	    	
	    	if(out != null) {
				try {
					out.close();
				}
				catch(IOException e) {}
	    	}
	    }
	}	

	@Override
	public ComprobanteBean generaComprobanteBean(ArchivoComprobanteBean archivoComprobante) {
		if (log.isDebugEnabled()) { log.debug("generaComprobanteBean( " + archivoComprobante + " )"); }
		
		/** Considerar que se puede cruzar en concurrencia */
		File fileZip = this.generaContenidoArchivoZip(archivoComprobante);
		File fileXml = this.obtenerArchivoXmlDesdeZip(fileZip);
		return this.generaComprobanteBean(fileXml, false, false);
	}
	
	@Override
	public ComprobanteBean generaComprobanteBean(File fileXml, boolean validate, boolean sign) {
		if (log.isDebugEnabled()) { log.debug("generaComprobanteBean( " + fileXml + ", " + validate + ", " + sign + " )"); }
		
		FileInputStream fis = null;
		ComprobanteBean comprobante = null;
		try {
			fis = new FileInputStream(fileXml);
			ComprobanteParserBean parser = new ComprobanteParserBean();
			Document doc = parser.parse(fis);
			String documentName = doc.getDocumentElement().getNodeName();
			if(documentName != null) {
				documentName = documentName.trim();
				log.debug("Nombre de tipo de Documento : " + documentName );
				if(documentName.equals("Invoice")) {
					parser.setComprobanteContext(new BoletaContext());
				}
				else if(documentName.equals("DebitNote")) {
					parser.setComprobanteContext(new NotaDebitoContext());
				}
				else if(documentName.equals("CreditNote")) {
					parser.setComprobanteContext(new NotaCreditoContext());
				}
				else {
					throw new ServiceException(this, "Tipo de documento no registrado");
				}
				
				if(validate) {
					File dirSchema = new File(this.directorioSchemas);
					if(dirSchema.exists() && dirSchema.isDirectory()) {
						parser.setSchemaSource(new File(dirSchema.getAbsolutePath() + "/"+ parser.getSchema()));
						parser.validate();
					}
					else {
						throw new ServiceException(this, "No existe el directorio de schemas: " + this.directorioSchemas);
					}
				}
				
				if(sign) {
					log.debug("Debemos verificar la firma");
				}
				
				comprobante = parser.generaComprobanteBean();
			}
			else {
				throw new ServiceException(this, "No se encontro la ra�z documento");
			}
		}
		catch (FileNotFoundException e) {
			e.printStackTrace();
			throw new ServiceException(this, e);
		}
		catch(Exception e) {
			e.printStackTrace();
			throw new ServiceException(this, e);
		}
		finally {
			if(fis != null) {
				try {
					fis.close();
				}
				catch(IOException e) {}
			}
		}
		return comprobante;
	}
	
	public File obtenerArchivoXmlDesdeZip(File fileZip) {
		if (log.isDebugEnabled()) { log.debug("obtenerArchivoXmlDesdeZip( " + fileZip + " )"); }
		
		File fileXml = null;
		ZipInputStream zis = null;
		try {
			zis = new ZipInputStream(new BufferedInputStream(new FileInputStream(fileZip)));
			ZipEntry entry;
			File dirTempo = new File(this.directorioTemporal);
			if(dirTempo.exists() && dirTempo.isDirectory()) {
				boolean encontro = false;
				while((entry = zis.getNextEntry()) != null) {
					BufferedOutputStream bos = null;
					try {
						System.out.println("Extracting: " + entry);
						byte buf[] = new byte[LENGTH_BUFFER];
						fileXml = new File(dirTempo.getAbsolutePath() + "/" + entry.getName());
						bos = new BufferedOutputStream(new FileOutputStream(fileXml), LENGTH_BUFFER);
						for(int len = 0; (len = zis.read(buf, 0 , LENGTH_BUFFER)) > 0; bos.write(buf, 0, len));
						bos.flush();
						encontro = true;
						break;
					}
					finally {
						if(bos != null) {
							try {
								bos.close();
							}
							catch(IOException e) {}
						}
					}
				}
				if(!encontro) {
					throw new ServiceException(this, "No se encontro el XML dentro del archivo ZIP");
				}
			} else {
				throw new ServiceException(this, "No existe el directorio temporal: " + this.directorioTemporal);
			}
		}
		catch(Exception e) {
			e.printStackTrace();
			throw new ServiceException(this, e.getLocalizedMessage());
		}
		finally {
			if(zis != null) {
				try {
					zis.close();
				}
				catch(IOException e) {}
			}
		}
		return fileXml;
	}
	
	public File generaContenidoArchivoZip(ArchivoComprobanteBean archivoComprobante) {
		if (log.isDebugEnabled()) { log.debug("generaContenidoArchivoZip( " + archivoComprobante + " )"); }

		String fileName = archivoComprobante.getTipoComprobante().trim() +
		  				  archivoComprobante.getNumeroRuc().trim() +
		  				  archivoComprobante.getSerieComprobante().trim() +
		  				  archivoComprobante.getNumeroComprobante().toString().trim();

		File dirTempo = new File(this.directorioTemporal);
		File fileZip = null;
		byte[] buf = new byte[LENGTH_BUFFER];
		if(dirTempo.exists() && dirTempo.isDirectory()) {
			ByteArrayInputStream bais = null;
			BufferedOutputStream bos = null;
			try {
				fileZip = new File(dirTempo.getAbsolutePath() + "/" + fileName + ".zip");
				bos = new BufferedOutputStream(new FileOutputStream(fileZip));
				bais = new ByteArrayInputStream(archivoComprobante.getContenidoArchivoXml().getBytes());
				for(int len = 0; (len = bais.read(buf, 0 , LENGTH_BUFFER)) > 0; bos.write(buf, 0, len));
			} catch(Exception e) {
				throw new ServiceException(this, e.getLocalizedMessage());
			} finally {
				if(bais != null) {
					try {
						bais.close();
					} catch(IOException e) {}
				}
				
				if(bos != null) {
					try {
						bos.close();
					}
					catch(IOException e) {}
				}
			}
			return fileZip;
		}
		else {
			throw new ServiceException(this, "No existe el directorio temporal: " + this.directorioTemporal);
		}
	}
	
	public File generarArchivoXML(ArchivoComprobanteBean archivoComprobante) throws IOException {
		if (log.isDebugEnabled()) { log.debug("generarArchivoXML( " + archivoComprobante + " )"); }

		/** BOLETAEB01-NNNRRRRRRRRRRR.xml*/ 
		String fileName = createFileName(archivoComprobante);
		//byte[] xmlFile = archivoComprobante.getContenidoArchivoXml().getBytes();		
		//return createFileFromByteArray(archivoComprobante, fileName, xmlFile);
		File newFileXml = new File(fileName);
		asignaRutas(archivoComprobante);
		FileUtils.writeStringToFile(newFileXml, archivoComprobante.getContenidoArchivoXml(),"ISO-8859-1");
		return newFileXml;
		
	}

	private File createFileFromByteArray(ArchivoComprobanteBean archivoComprobante, String fileName, byte[] xmlFile) {
	    asignaRutas(archivoComprobante); 
	    File dirTempo = new File(this.directorioTemporal);
	    
	    File fileZip = null;
	    byte[] buf = new byte[LENGTH_BUFFER];
	    if(dirTempo.exists() && dirTempo.isDirectory()) {
	    	ByteArrayInputStream bais = null;
	    	BufferedOutputStream bos = null;
	    	try {
	    		fileZip = new File(dirTempo.getAbsolutePath() + "/" + fileName + ".xml");
	    		bos = new BufferedOutputStream(new FileOutputStream(fileZip));
	    		
	    		bais = new ByteArrayInputStream(xmlFile);
	    		for(int len = 0; (len = bais.read(buf, 0 , LENGTH_BUFFER)) > 0; bos.write(buf, 0, len));

	    	}
	    	catch(Exception e) {
	    		throw new ServiceException(this, e.getLocalizedMessage());
	    	}
	    	finally {
	    		if(bais != null) {
	    			try {
	    				bais.close();
	    			}
	    			catch(IOException e) {}
	    		}
	    		
	    		if(bos != null) {
	    			try {
	    				bos.close();
	    			}
	    			catch(IOException e) {}
	    		}
	    	}
	    	return fileZip;
	    }
	    else {
	    	throw new ServiceException(this, "No existe el directorio temporal: " + this.directorioTemporal);
	    }
	}

	private String createFileName(ArchivoComprobanteBean archivoComprobante) {
	    String fileName = "BOLETA" + archivoComprobante.getSerieComprobante().trim() + "-" +
	    archivoComprobante.getNumeroComprobante().toString().trim() +
	    archivoComprobante.getNumeroRuc().trim();	
	    String tipoComprobante = archivoComprobante.getTipoComprobante().trim();
	    if(tipoComprobante.equals(ComprobanteUtilBean.BOLETA)) {
	    	fileName = "BOLETA" + archivoComprobante.getSerieComprobante().trim() + "-" +
	    	archivoComprobante.getNumeroComprobante().toString().trim() +
	    	archivoComprobante.getNumeroRuc().trim() + ".XML";
	    }
	    else if(tipoComprobante.equals(ComprobanteUtilBean.NOTA_CREDITO)) {
	    	fileName = "NOTA_CREDITO" + archivoComprobante.getSerieComprobante().trim() + "-" +
	    	archivoComprobante.getNumeroComprobante().toString().trim() +
	    	archivoComprobante.getNumeroRuc().trim()+ ".XML";
	    }
	    else if(tipoComprobante.equals(ComprobanteUtilBean.NOTA_DEBITO)) {
	    	fileName = "NOTA_DEBITO" + archivoComprobante.getSerieComprobante().trim() + "-" +
	    	archivoComprobante.getNumeroComprobante().toString().trim() +
	    	archivoComprobante.getNumeroRuc().trim()+ ".XML";
	    }
	    else {
	    	throw new ServiceException(this, "Tipo de comprobante no registrado.");
	    }
	    return fileName;
	}	

	private Long getNumeroIdArchivoXml (){
		return daoSequence.getNextSequence("SESEEIDXML");
	}

	/*
	public String getContenidoArchivoTxt(File file) {
		StringBuilder xml = new StringBuilder();
		BufferedReader in = null;
		try {
			in = new BufferedReader(new FileReader(file));
		    String line = null;
            while ((line = in.readLine()) != null) {
                xml.append(line).append('\n');
            }
		} catch(Exception e) {
			throw new ServiceException(this, e.getLocalizedMessage());
		} finally {
			if (in != null){
				try {
					in.close();
				} catch (IOException e) {}
			}
		}

		return xml.toString();
	}*/
	
	public String getContenidoArchivoTxt(File file) {
		StringBuilder xml = new StringBuilder();
		BufferedReader in = null;
		
		FileInputStream fis = null;
		try {
			fis = new FileInputStream(file);
			InputStreamReader inputStreamReader = new InputStreamReader((InputStream)fis, "ISO-8859-1");
			BufferedReader br = new BufferedReader(inputStreamReader);
			String line = null;
			while ((line = br.readLine()) != null) {
				xml.append(line).append('\n');
			}
		} catch(Exception e) {
			throw new ServiceException(this, e.getLocalizedMessage());
		} finally {
			if (in != null){
				try {
					in.close();
				} catch (IOException e) {}
			}
			if (fis != null){
				try {
					fis.close();
				} catch (IOException e) {}
			}
		}
		return xml.toString();
	}
	
	public byte[] getContenidoArchivoBin(File file) {
		FileInputStream in = null;
		try {
            in = new FileInputStream(file);

            int numberBytes = in.available();
            byte bytearray[] = new byte[numberBytes];
            in.read(bytearray);

            return bytearray;
		} catch(Exception e) {
			throw new ServiceException(this, e.getLocalizedMessage());
		} finally {
			if (in != null){
				try {
					in.close();
				} catch (IOException e) {}
			}
		}
	}
}
