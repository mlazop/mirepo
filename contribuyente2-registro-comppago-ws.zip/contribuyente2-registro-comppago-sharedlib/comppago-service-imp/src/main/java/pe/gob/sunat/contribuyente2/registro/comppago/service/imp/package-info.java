/**
 * 
 */
/**
 * @author maguilarac
 *
 */
package pe.gob.sunat.contribuyente2.registro.comppago.service.imp;