package pe.gob.sunat.contribuyente2.registro.comppago.service.imp;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.zip.ZipEntry;
import java.util.zip.ZipInputStream;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import pe.gob.sunat.contribuyente2.registro.comppago.service.ifz.FacturaNotaDebitoRestService;
import pe.gob.sunat.framework.spring.util.bean.MensajeBean;
import pe.gob.sunat.framework.spring.util.exception.ServiceException;
import pe.gob.sunat.servicio2.registro.electronico.comppago.factura.model.domain.T4243Bean;
import pe.gob.sunat.servicio2.registro.electronico.comppago.factura.model.domain.T4283Bean;
import pe.gob.sunat.servicio2.registro.electronico.comppago.factura.model.dao.T4243DAO;
import pe.gob.sunat.servicio2.registro.electronico.comppago.factura.model.dao.T4283DAO;
import pe.gob.sunat.servicio2.registro.electronico.comppago.factura.bean.ArchivoComprobanteBean;
import pe.gob.sunat.servicio2.registro.electronico.comppago.factura.bean.ComprobanteBean;
import pe.gob.sunat.servicio2.registro.electronico.comppago.factura.bean.ComprobanteUtilBean;
import pe.gob.sunat.servicio2.registro.electronico.comppago.factura.service.ProcesaArchivoComprobanteService;
import pe.gob.sunat.servicio2.registro.electronico.comppago.guiaremision.controlbienes.bean.T5229Bean;
import pe.gob.sunat.servicio2.registro.electronico.comppago.guiaremision.controlbienes.model.dao.T5229DAO;
import pe.gob.sunat.servicio2.registro.model.dao.T01DAO;
import pe.gob.sunat.servicio2.registro.model.domain.T01Bean;

public class FacturaNotaDebitoRestServiceImpl implements FacturaNotaDebitoRestService {
	
	private static final String NOTA_DEBITO_GEM = "08";    
    
    protected final static Log log = LogFactory.getLog(FacturaNotaDebitoRestServiceImpl.class);
    
    private T4243DAO daoT4243;
    private T4283DAO daoT4283;
    private T5229DAO daoT5229;
    private T4243DAO daoT4243Ibatis;
	private T01DAO daoT01;    
    private ProcesaArchivoComprobanteService archivoService;
    private ServiceCommonFunction serviceCommonFunction;
    
	public T4283DAO getDaoT4283() {
		return daoT4283;
	}
	public T5229DAO getDaoT5229() {
		return daoT5229;
	}
	public ProcesaArchivoComprobanteService getArchivoService() {
		return archivoService;
	}
	public T4243DAO getDaoT4243Ibatis() {
		return daoT4243Ibatis;
	}
	public T4243DAO getDaoT4243() {
		return daoT4243;
	}
	public T01DAO getDaoT01() {
		return daoT01;
	}	
	public ServiceCommonFunction getServiceCommonFunction() {
		return serviceCommonFunction;
	}	
	public void setDaoT4283(T4283DAO daoT4283) {
		this.daoT4283 = daoT4283;
	}
	public void setArchivoService(ProcesaArchivoComprobanteService archivoService) {
		this.archivoService = archivoService;
	}
	public void setDaoT5229(T5229DAO daoT5229) {
		this.daoT5229 = daoT5229;
	}	
	public void setDaoT4243(T4243DAO daoT4243) {
		this.daoT4243 = daoT4243;
	} 	
	public void setDaoT4243Ibatis(T4243DAO daoT4243Ibatis) {
		this.daoT4243Ibatis = daoT4243Ibatis;
	}
	public void setServiceCommonFunction(ServiceCommonFunction serviceCommonFunction) {
		this.serviceCommonFunction = serviceCommonFunction;
	}
	public void setDaoT01(T01DAO daoT01) {
		this.daoT01 = daoT01;
	}
	
	@Override
	public ComprobanteBean recuperarInfoFacturaNotaDebito(String ruc, String serie, String numero, String tipo) {
			if (log.isDebugEnabled()) {
			    log.debug("recuperarInfoNotaDebito( Ruc : " + ruc + " - Serie : " + serie + "- Numero :  "+ numero +")");
			}
		
			ComprobanteBean comprobante = null;
			boolean isGem=true;
			String xtipo = NOTA_DEBITO_GEM;
			T4243Bean bean;
			
			//Se determina que es 'GEM' si la serie de la nota de debito comienza con F 'FXXX'
			//Se determina que es 'PYME-Portal' si la serie de la nota de debito  comienza con E 'EXXX'
			if (serie.substring(0, 1).equals("F")){
				isGem=true;
			};
			if (serie.substring(0, 1).equals("E")){
				isGem=false;
			};
			
			log.debug("xtipo : "+  xtipo + "serie " +  serie.substring(0, 1) );

			
			if (isGem) {
				bean = daoT4243.findFileZipJoinTCabCPETRelcompelecTFESTOREByPrimaryKey(ruc, xtipo, serie, new Integer(numero));
			} else {
				 bean = daoT4243Ibatis.findFileXmlJoinTCabCPETArcXmlByPrimaryKeyISO88591(ruc, xtipo, serie, new Integer(numero));
			}
		
			if (bean != null) {
				
				ArchivoComprobanteBean beanFile = new ArchivoComprobanteBean();

				beanFile.setNumeroRuc(ruc);
			    beanFile.setTipoComprobante(xtipo);
			    beanFile.setSerieComprobante(serie);
			    beanFile.setNumeroComprobante(new Integer(numero));
				
			    if (isGem) {
			    	beanFile.setContenidoArchivoXml(new String(serviceCommonFunction.decompress(bean.getArc_zip() )));
			    } else {
			    	beanFile.setContenidoArchivoXml(bean.getArc_xml());
			    }

		    	beanFile.setTipoComprobante(ComprobanteUtilBean.NOTA_DEBITO);

			    try {
			    	
			    	//TODO Reconstruir llamada
			    	comprobante = archivoService.generaComprobanteBean(archivoService.generarArchivoXML(beanFile), false, false);		    	
			
					//En caso se haya guardado el establecimiento del emisor, se recupera id_estab_emisor y cod_estab
					if (comprobante.getIndicadorEstabEmisor()!=null && comprobante.getIndicadorEstabEmisor().equals("1")){
						T4283Bean buscarT4283 = new T4283Bean();
						buscarT4283.setNum_ruc(comprobante.getNumeroRuc());
						buscarT4283.setCod_cpe("08");
						buscarT4283.setNum_serie_cpe(comprobante.getSerieComprobante());				
						buscarT4283.setNum_cpe(comprobante.getNumeroComprobante());
						buscarT4283.setCod_rubro(165); //INDICADOR DE ESTABLECIMIENTO DEL EMISOR
						
						
						T4283Bean rubro = daoT4283.findRubroCabecera_ByRUC_codCPE_Serie_CPE_Rubro(buscarT4283);				
						if (rubro != null){
							comprobante.getEstabEmisor().setId_estab_emisor(rubro.getDes_detalle_rubro());
						}
						
						T5229Bean direccion = daoT5229.selectByPrimaryKey("01", 11, comprobante.getNumeroComprobante(), 1, comprobante.getNumeroRuc(), comprobante.getSerieComprobante());	
						if (direccion != null){
							comprobante.getEstabEmisor().setCod_estab(direccion.getCod_estab());
						}
					}
			
					comprobante.setSimboloMoneda(ComprobanteUtilBean.getSimboloMoneda(comprobante.getCodigoMoneda()));
			
					int countUnidadMedidaItem = 0;
					int countCodigoItem = 0;
			
					Map<String, String> unidadMedida = null;
					List<pe.gob.sunat.servicio2.registro.electronico.comppago.factura.bean.DetalleComprobanteBean> lstDetalleComprobante = new ArrayList<pe.gob.sunat.servicio2.registro.electronico.comppago.factura.bean.DetalleComprobanteBean>();
					if (comprobante.getDetalleComprobanteBean() != null) {
					    for (pe.gob.sunat.servicio2.registro.electronico.comppago.factura.bean.DetalleComprobanteBean detalleComprobante : comprobante.getDetalleComprobanteBean()) {
							log.debug("unidadMedidaItem: " + detalleComprobante.getUnidadMedida());
							log.debug("codigoItem: " + detalleComprobante.getCodigoItem());
				
							if (!"-".equals(detalleComprobante.getUnidadMedida().trim())) {
							    countUnidadMedidaItem++;
							}
							if (!"".equals(detalleComprobante.getCodigoItem().trim())) {
							    countCodigoItem++;
							}
				
							unidadMedida = obtieneUnidadMedida(detalleComprobante.getUnidadMedida());
							detalleComprobante.setUnidadMedidaDesc((unidadMedida != null ? unidadMedida.get("descripcionMedida").toString() : detalleComprobante.getUnidadMedida()));
							lstDetalleComprobante.add(detalleComprobante);
					    }
					}
					
					comprobante.setCountUnidadMedidaItem(countUnidadMedidaItem);
					comprobante.setCountCodigoItem(countCodigoItem);				
					comprobante.setDetalleComprobanteBean(lstDetalleComprobante);
					
					if (log.isDebugEnabled())
					    log.debug(" >> ComprobanteBean :: " + comprobante);
			    } catch (Exception e) {
					log.debug(">>ConsultarServiceImpl Error !! " + e.getMessage());
					MensajeBean msg = new MensajeBean();
					msg.setError(true);
					msg.setMensajeerror(e.getMessage());
					throw new ServiceException(this, msg);
			    }
			} else {
			    MensajeBean msg = new MensajeBean();
			    msg.setError(false);
			    msg.setMensajeerror("No existe factura a descargar.");
			    throw new ServiceException(this, msg);
			}
			return comprobante;
	    }
	
	    private Map<String, String> obtieneUnidadMedida(String unidadMedida) {
			unidadMedida = unidadMedida.toUpperCase();
		
			if ("-".equals(unidadMedida.trim())) {
			    return null;
			}
		
			for (Map<String, String> m : this.listadoUnidadMedida()) {
			    if (unidadMedida.equals(m.get("unidadMedida"))) {
				return m;
			    }
			}
			return null;
	    }
	    
	    private List<Map<String, String>> listadoUnidadMedida() {
			List<Map<String, String>> lsMedidas = new ArrayList<Map<String, String>>();
		
			Map<String, String> unidaMedida = new HashMap<String, String>();
			List<T01Bean> listado = null;
		
			listado = (ArrayList<T01Bean>) daoT01.findUnidadMedidaVigente("677");
		
			for (T01Bean bean : listado) {
			    unidaMedida = new HashMap<String, String>();
			    unidaMedida.put("unidadMedida", bean.getArgumento().trim());
			    unidaMedida.put("descripcionMedida", bean.getFuncion());
			    lsMedidas.add(unidaMedida);
			}
		
			return lsMedidas;
	    }
}