package pe.gob.sunat.servicio2.registro.electronico.comppago.factura.model.dao.ibatis;


import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import pe.gob.sunat.framework.spring.util.dao.SqlMapDAOBase;
import pe.gob.sunat.framework.spring.util.date.FechaBean;
import pe.gob.sunat.servicio2.registro.electronico.comppago.factura.model.dao.T4704DAO;
import pe.gob.sunat.servicio2.registro.electronico.comppago.factura.model.domain.T4704Bean;

public class SqlMapT4704DAOImpl  extends SqlMapDAOBase implements T4704DAO {
	
	@Override
	public T4704Bean findByFiltro(T4704Bean bean){		
			Object obj = getSqlMapClientTemplate().queryForObject("detResumen.findByFiltro", bean);
			return (obj != null ? (T4704Bean) obj: null);		
	}
	
	@Override
	public boolean registraDetResumen(T4704Bean bean) {
		boolean  flag =  false;
		log.debug("entro a registraDetResumen");
		getSqlMapClientTemplate().insert("detResumen.registraDetResumen", bean);
		log.debug("detresumen registrado .");
		flag = true; 
		return flag; 
	}
    
	@Override 
	public List<T4704Bean> listaDetallesresumenRucfecha(String ruc, FechaBean fecha)  {
		log.debug("entro a listaDetallesresumenRucfecha)");		
		List<T4704Bean> lista = new ArrayList<T4704Bean>();		
		Map  m = new  HashMap(); 
		m.put("ruc", ruc); 
		m.put("femision", fecha); 
		lista=getSqlMapClientTemplate().queryForList("detResumen.findByRucFechaActivoDet", m);
		log.debug(" se encontraron : "+  lista.size()+" elementos");
		return lista;
	}

	@Override
	public boolean borradoLogicodetresumen(T4704Bean  bean)  {
		boolean  flag =  false;
		log.debug("entro a borradoLogicodetresumen");	
		getSqlMapClientTemplate().delete("detResumen.eliminaLogicoDetResumen", bean);	
		log.debug(" detResumen estados actualizados a  eliminados ");
		flag = true; 
		return flag; 
	}

	@Override
	public T4704Bean buscarComprobanteEspecifico(String ruc, String codcpe,
			String seriecpe, Integer numcpe) {	
		Map<String, Object>  m = new  HashMap<String, Object>(); 
		m.put("ruc", ruc); 
		m.put("codcpe", codcpe); 
		m.put("seriecpe", seriecpe); 
		m.put("desde", numcpe); 
		m.put("hasta", numcpe); 
		T4704Bean resp = null;			
		resp=(T4704Bean)getSqlMapClientTemplate().queryForObject ("detResumen.findByRucDocEspecifico", m);
	   return   resp; 
	}

	


	
	
}








