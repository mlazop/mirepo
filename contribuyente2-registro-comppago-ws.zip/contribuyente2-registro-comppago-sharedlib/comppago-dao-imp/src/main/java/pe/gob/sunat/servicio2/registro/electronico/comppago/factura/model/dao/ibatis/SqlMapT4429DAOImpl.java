package pe.gob.sunat.servicio2.registro.electronico.comppago.factura.model.dao.ibatis;

import java.util.ArrayList;
import java.util.List;

import pe.gob.sunat.framework.spring.util.dao.SqlMapDAOBase;
import pe.gob.sunat.servicio2.registro.electronico.comppago.factura.model.dao.T4429DAO;
import pe.gob.sunat.servicio2.registro.electronico.comppago.factura.model.domain.T4429Bean;

public class SqlMapT4429DAOImpl extends SqlMapDAOBase implements T4429DAO{

	@Override
	public int insert(T4429Bean bean) {
		if (log.isDebugEnabled()) {log.debug("insert (" + bean + ")");}
		getSqlMapClientTemplate().insert("T4429.insert", bean);
		return 0;
	}
	

	public Integer findTotalBy_TipoDocRel_RUC_Factura(String TipoCPE, String numRucEmisor, String serieDocRel, String numeroDocRel){
		if (log.isDebugEnabled()) {log.debug("findTotalBy_TipoDocRel_RUC_Factura (" + TipoCPE + ")");}
		T4429Bean docRel = new  T4429Bean();
		docRel.setCod_cpe(TipoCPE);
		docRel.setNum_ruc(numRucEmisor);
		docRel.setNum_serie_doc_rel(serieDocRel);
		docRel.setNum_doc_rel(numeroDocRel);
		Integer totDocs = (Integer) getSqlMapClientTemplate().queryForObject("T4429.findTotalBy_TipoDocRel_RUC_Factura", docRel);
		return totDocs;
	}
	
	public Integer findTotalBy_TipoDocRel_RUC_Boleta(String TipoCPE, String numRucEmisor, String serieDocRel, String numeroDocRel){
		if (log.isDebugEnabled()) {log.debug("findTotalBy_TipoDocRel_RUC_Boleta (" + TipoCPE + ")");}
		T4429Bean docRel = new  T4429Bean();
		docRel.setCod_cpe(TipoCPE);
		docRel.setNum_ruc(numRucEmisor);
		docRel.setNum_serie_doc_rel(serieDocRel);
		docRel.setNum_doc_rel(numeroDocRel);
		Integer totDocs = (Integer) getSqlMapClientTemplate().queryForObject("T4429.findTotalBy_TipoDocRel_RUC_Boleta", docRel);
		return totDocs;
	}
	
	public T4429Bean findBy_RucTipoSerieNumeroRelacion(String TipoCPE, String numRucEmisor, String serieDoc, String numeroDoc, String codRelacion){
		if (log.isDebugEnabled()) {log.debug("findBy_RucTipoSerieNumeroRelacion (" + TipoCPE + ")");}
		T4429Bean docRel = new  T4429Bean();
		docRel.setCod_cpe(TipoCPE);
		docRel.setNum_ruc(numRucEmisor);
		docRel.setNum_serie_cpe(serieDoc);
		docRel.setNum_cpe(new Integer(numeroDoc));
		docRel.setCod_relacion(codRelacion);
		Object obj = getSqlMapClientTemplate().queryForObject("T4429.findBy_RucTipoSerieNumeroRelacion", docRel);
		return (obj !=  null ? (T4429Bean) obj : null);
	}
	@Override
	public T4429Bean findByRucTipDocSerieDocRelacion(String numRuc, String codCpe, String numSerieCpe, Integer numCpe, String codRel, String codDocRel){
		T4429Bean t4429Bean = new T4429Bean();
		t4429Bean.setNum_ruc(numRuc); 
		t4429Bean.setCod_cpe(codCpe); 
		t4429Bean.setNum_serie_cpe(numSerieCpe); 
		t4429Bean.setNum_cpe(numCpe) ; 
		t4429Bean.setCod_relacion(codRel) ; 
		t4429Bean.setCod_doc_rel(codDocRel); 
		
		List obj = getSqlMapClientTemplate().queryForList("T4429.findByRucTipDocSerieDocRelacion", t4429Bean);
		 if (obj ==  null || obj.size() == 0) {
			 return null;
		 }
		
		return (T4429Bean) obj.get(0);
	}

	
	@SuppressWarnings("unchecked")
	public List<T4429Bean> findDocsEmitidosPorFETipo_By_Ruc_CodCP_SerieNumDocrel(String TipoCPE, String numRucEmisor, String serieDocRel, String numeroDocRel){
		if (log.isDebugEnabled()) {log.debug("findDocsEmitidosPorFETipo_By_Ruc_CodCP_SerieNumDocrel (" + TipoCPE + ")");}
		T4429Bean docRel = new  T4429Bean();
		docRel.setCod_cpe(TipoCPE);
		docRel.setNum_ruc(numRucEmisor);
		docRel.setNum_serie_doc_rel(serieDocRel);
		docRel.setNum_doc_rel(numeroDocRel);
		return  (ArrayList <T4429Bean>) getSqlMapClientTemplate().queryForList("T4429.findDocsEmitidosPorFETipo_By_Ruc_CodCP_SerieNumDocrel", docRel);
	}
	
	@SuppressWarnings("unchecked")
	public List<T4429Bean> findDocsEmitidosPorBVETipo_By_Ruc_CodCP_SerieNumDocrel(String TipoCPE, String numRucEmisor, String serieDocRel, String numeroDocRel){
		if (log.isDebugEnabled()) {log.debug("findDocsEmitidosPorBVETipo_By_Ruc_CodCP_SerieNumDocrel (" + TipoCPE + ")");}
		T4429Bean docRel = new  T4429Bean();
		docRel.setCod_cpe(TipoCPE);
		docRel.setNum_ruc(numRucEmisor);
		docRel.setNum_serie_doc_rel(serieDocRel);
		docRel.setNum_doc_rel(numeroDocRel);
		return (ArrayList <T4429Bean>) getSqlMapClientTemplate().queryForList("T4429.findDocsEmitidosPorBVETipo_By_Ruc_CodCP_SerieNumDocrel", docRel);
	}
}
