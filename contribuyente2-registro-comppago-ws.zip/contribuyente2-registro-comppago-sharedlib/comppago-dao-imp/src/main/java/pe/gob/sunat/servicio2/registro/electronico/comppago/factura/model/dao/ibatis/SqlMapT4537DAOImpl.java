package pe.gob.sunat.servicio2.registro.electronico.comppago.factura.model.dao.ibatis;

import java.util.HashMap;
import java.util.Map;
import pe.gob.sunat.framework.spring.util.dao.SqlMapDAOBase;
import pe.gob.sunat.servicio2.registro.electronico.comppago.factura.model.dao.T4537DAO;
import pe.gob.sunat.servicio2.registro.electronico.comppago.factura.model.domain.T4537Bean;

public class SqlMapT4537DAOImpl extends SqlMapDAOBase implements T4537DAO{

	@Override
	public T4537Bean findByPK(String ticket, Integer ticket_correl) {
	    Map < String , Object > m = new HashMap< String, Object >();
		 m.put("num_ticket", ticket);
		 m.put("num_correl", ticket_correl);
		 		 
		return (T4537Bean)getSqlMapClientTemplate().queryForObject("findByPK", m);
	}
}
