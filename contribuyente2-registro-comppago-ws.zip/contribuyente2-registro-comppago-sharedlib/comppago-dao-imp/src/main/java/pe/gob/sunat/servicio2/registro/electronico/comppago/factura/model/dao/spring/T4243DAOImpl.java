package pe.gob.sunat.servicio2.registro.electronico.comppago.factura.model.dao.spring;

import java.io.UnsupportedEncodingException;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import javax.sql.DataSource;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.dao.DataAccessException;
import org.springframework.dao.IncorrectResultSizeDataAccessException;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.jdbc.core.support.AbstractLobCreatingPreparedStatementCallback;
import org.springframework.jdbc.support.lob.LobCreator;
import org.springframework.jdbc.support.lob.LobHandler;

import pe.gob.sunat.servicio2.registro.electronico.comppago.factura.model.dao.T4243DAO;
import pe.gob.sunat.servicio2.registro.electronico.comppago.factura.model.domain.T4243Bean;

public class T4243DAOImpl implements T4243DAO {
	protected final Log log = LogFactory.getLog(getClass());
	private JdbcTemplate jdbcTemplate;
	private LobHandler lobHandler;
	
	private final String INSERT_SENTENCE = "insert into T4243xmlCPE(num_ruc , cod_cpe, num_serie_cpe , num_cpe , num_id_xml , arc_xml , fec_xml , ind_procedencia , des_nombre , cod_usumodif , fec_modif ) values (?,?,?,?,?,?,?,?,?,?,?);";	
	private final String findFileXmlJoinTCabCPETArcXmlByPrimaryKey = "select b.arc_xml, b.des_nombre as des_nombre from t4241cabcpe a,  T4243xmlCPE b where a.num_id_xml = b.num_id_xml and a.num_ruc = ? and a.cod_cpe = ? and a.num_serie_cpe = ? and a.num_cpe = ? ;";


	public void setDataSource(DataSource dataSource) {
		this.jdbcTemplate = new JdbcTemplate(dataSource);
	}
	
	public void setLobHandler(LobHandler lobHandler) {
		this.lobHandler = lobHandler;
	}	
	
	@Override
	public void insert(T4243Bean bean) throws Exception {
		if (log.isDebugEnabled()) { log.debug("insert( " + bean + " )");}
		
		final T4243Bean beanFile = bean;
		

		log.info("Objeto a insertar en T4243DAOImpl");
		log.debug(beanFile.getArc_xml());
		log.info(beanFile.getNum_ruc());
		log.info(beanFile.getNum_serie_cpe());
		log.info(beanFile.getNum_cpe());
		/*System.out.println("Objeto a insertar");
		System.out.println(beanFile.getArc_xml());
		System.out.println(beanFile.getCod_cpe());
		System.out.println(beanFile.getNum_ruc());
		System.out.println(beanFile.getNum_serie_cpe());
		System.out.println(beanFile.getNum_cpe());
		System.out.println(beanFile.getNum_id_xml());
		System.out.println(beanFile.getFec_xml().getTimestamp());
		System.out.println(beanFile.getInd_procedencia());
		System.out.println(beanFile.getDes_nombre());
		System.out.println(beanFile.getCod_usumodif());
		System.out.println(beanFile.getFec_modif().getTimestamp());
	*/
		
		jdbcTemplate.execute(this.INSERT_SENTENCE, new AbstractLobCreatingPreparedStatementCallback(lobHandler) {
		protected void setValues(PreparedStatement ps, LobCreator lobCreator)
		throws SQLException, DataAccessException {
 
			ps.setString(1, beanFile.getNum_ruc());
			ps.setString(2, beanFile.getCod_cpe());
			ps.setString(3, beanFile.getNum_serie_cpe());
			ps.setInt(4, beanFile.getNum_cpe());		
			ps.setLong(5, beanFile.getNum_id_xml());
            try {
                lobCreator.setBlobAsBytes(ps, 6, beanFile.getArc_xml().getBytes("ISO-8859-1"));
	         } catch (UnsupportedEncodingException e) {
	                lobCreator.setClobAsString(ps,6, beanFile.getArc_xml());
	                log.debug("ocurrio un error al ejecutar el encoding al insertar");
	         }

			//lobCreator.setClobAsString(ps,6, beanFile.getArc_xml());

			ps.setTimestamp(7, beanFile.getFec_xml().getTimestamp());
			ps.setString(8, beanFile.getInd_procedencia());
			ps.setString(9, beanFile.getDes_nombre());
			ps.setString(10, beanFile.getCod_usumodif());
			ps.setTimestamp(11, beanFile.getFec_modif().getTimestamp());
		}
	});
}

	
	public T4243Bean findFileXmlJoinTCabCPETArcXmlByPrimaryKey(String nroRUC, String codCPE, String nroSerie, Integer nroCPE) {
		if (log.isDebugEnabled()) { log.debug("findFileXmlJoinTCabCPETArcXmlByPrimaryKey( " + nroRUC + ", "  + nroSerie + ", " + nroCPE.intValue() + " )");}

		try {
		    RowMapper mapper = new RowMapper() {
		    	public Object mapRow(ResultSet rs, int rowNum) throws SQLException {
		    		T4243Bean bean = new T4243Bean();
		    		bean.setArc_xml(lobHandler.getClobAsString(rs, "arc_xml"));
		            return bean;
		        }
		    };

			return (T4243Bean)jdbcTemplate.queryForObject(this.findFileXmlJoinTCabCPETArcXmlByPrimaryKey,
					new Object[]{nroRUC, codCPE, nroSerie, nroCPE}, mapper);
		}
		catch(IncorrectResultSizeDataAccessException e) { return null; }
	}

	@Override
	public T4243Bean findByRUC_Serie_CPE_ID(T4243Bean bean) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public T4243Bean findFileXmlJoinTCabCPETArcXmlByPrimaryKeyISO88591(
			String nroRUC, String codCPE, String nroSerie, Integer nroCPE) {
		if (log.isDebugEnabled()) { log.debug("T4243DAOImpl Spring findFileXmlJoinTCabCPETArcXmlByPrimaryKey( " + nroRUC + ", " + codCPE + "," + nroSerie + ", " + nroCPE.intValue() + " )");}

		try {
		    RowMapper mapper = new RowMapper() {
		    	public Object mapRow(ResultSet rs, int rowNum) throws SQLException {
		    		T4243Bean bean = new T4243Bean();
		    		byte[] fileByte = lobHandler.getBlobAsBytes(rs, "arc_xml");
		    		try {
						bean.setArc_xml(new String(fileByte,"ISO-8859-1"));
					} catch (UnsupportedEncodingException e) {
						bean.setArc_xml(lobHandler.getClobAsString(rs, "arc_xml"));
						log.debug("ocurrio un error al ejecutar el encoding");
					}
		    		bean.setDes_nombre(rs.getString("des_nombre"));
		            return bean;
		        }
		    };

			return (T4243Bean)jdbcTemplate.queryForObject(this.findFileXmlJoinTCabCPETArcXmlByPrimaryKey,
					new Object[]{nroRUC, codCPE, nroSerie, nroCPE}, mapper);
		}
		catch(IncorrectResultSizeDataAccessException e) { return null; }
	}

	@Override
	public T4243Bean findFileZipJoinTCabCPETRelcompelecTFESTOREByPrimaryKey(
			String nroRUC, String codCPE, String nroSerie, Integer nroCPE) {
		// TODO Auto-generated method stub
		return null;
	}

}
