//INI: PAS20201U210100184
package pe.gob.sunat.servicio2.registro.electronico.comppago.factura.model.dao.ibatis;

import java.util.ArrayList;
import java.util.List;

import pe.gob.sunat.framework.spring.util.dao.SqlMapDAOBase;
import pe.gob.sunat.servicio2.registro.electronico.comppago.factura.model.dao.T4283hDAO;
import pe.gob.sunat.servicio2.registro.electronico.comppago.factura.model.domain.T4283Bean;
import pe.gob.sunat.servicio2.registro.electronico.comppago.factura.model.domain.T4283Bean_old;
import pe.gob.sunat.servicio2.registro.electronico.comppago.factura.model.domain.T4283Bean_old2;
public class SqlMapT4283hDAOImpl extends SqlMapDAOBase implements T4283hDAO{

	@Override
	public int insert(T4283Bean bean) {
		if (log.isDebugEnabled()) {log.debug("insert (" + bean + ")");}
		getSqlMapClientTemplate().insert("T4283h.insert", bean);
		return 0;
	}
	
	public T4283Bean_old recuperarRubrosTablaAnterior(T4283Bean_old bean) {
		if (log.isDebugEnabled()) log.debug("recuperarRubrosTablaAnterior (" + bean + ")");

		Object obj = getSqlMapClientTemplate().queryForObject("T4283h.findRubroCabecera_ByRUC_codCPE_Serie_CPE_Rubro_old",bean);
		return (obj != null ? (T4283Bean_old) obj : null);
	}

	public T4283Bean_old2 recuperarRubrosTablaAnterior2(T4283Bean_old2 bean) {
		if (log.isDebugEnabled()) log.debug("recuperarRubrosTablaAnterior (" + bean + ")");

		Object obj = getSqlMapClientTemplate().queryForObject("T4283h.findRubroCabecera_ByRUC_codCPE_Serie_CPE_Rubro_old2",bean);
		return (obj != null ? (T4283Bean_old2) obj : null);
	}
	
	public T4283Bean recuperarRubrosTablaRegular(T4283Bean bean) {
		if (log.isDebugEnabled()) log.debug("recuperarRubrosTablaRegular (" + bean + ")");

		Object obj = getSqlMapClientTemplate().queryForObject("T4283h.findRubroCabecera_ByRUC_codCPE_Serie_CPE_Rubro",bean);
		return (obj != null ? (T4283Bean) obj : null);
	}
	
	private T4283Bean convertirT4283Bean(T4283Bean_old t4283Bean_old) {
		T4283Bean result = new T4283Bean();
		
		result.setNum_ruc(t4283Bean_old.getNum_ruc());
		result.setCod_cpe(t4283Bean_old.getCod_cpe());
		result.setNum_serie_cpe(t4283Bean_old.getNum_serie_cpe());
		result.setNum_cpe(t4283Bean_old.getNum_cpe());
		result.setNum_fila_item(t4283Bean_old.getNum_fila_item());
		result.setInd_cab_det(t4283Bean_old.getInd_cab_det());
		result.setCod_rubro(t4283Bean_old.getCod_rubro());
		result.setMto_rubro(t4283Bean_old.getMto_rubro());
		result.setDes_detalle_rubro(t4283Bean_old.getDes_detalle_rubro());
		result.setFec_rubro(t4283Bean_old.getFec_rubro());
		result.setCod_usumodif(t4283Bean_old.getCod_usumodif());
		result.setFec_modif(t4283Bean_old.getFec_modif());
		
		return result;
	}
	
	private T4283Bean convertirT4283Bean_old2(T4283Bean_old2 t4283Bean_old2) {
		T4283Bean result = new T4283Bean();
		
		result.setNum_ruc(t4283Bean_old2.getNum_ruc());
		result.setCod_cpe(t4283Bean_old2.getCod_cpe());
		result.setNum_serie_cpe(t4283Bean_old2.getNum_serie_cpe());
		result.setNum_cpe(t4283Bean_old2.getNum_cpe());
		result.setNum_fila_item(t4283Bean_old2.getNum_fila_item());
		result.setInd_cab_det(t4283Bean_old2.getInd_cab_det());
		result.setCod_rubro(t4283Bean_old2.getCod_rubro());
		result.setMto_rubro(t4283Bean_old2.getMto_rubro());
		result.setDes_detalle_rubro(t4283Bean_old2.getDes_detalle_rubro());
		result.setFec_rubro(t4283Bean_old2.getFec_rubro());
		result.setCod_usumodif(t4283Bean_old2.getCod_usumodif());
		result.setFec_modif(t4283Bean_old2.getFec_modif());
		
		return result;
	}
	public T4283Bean findRubroCabecera_ByRUC_codCPE_Serie_CPE_Rubro(T4283Bean bean) {
		if (log.isDebugEnabled()) {log.debug("findRubroCabecera_ByRUC_codCPE_Serie_CPE_Rubro (" + bean + ")");}
		
		T4283Bean rubrosFinal = null;
		
		T4283Bean_old t4283Bean_old = new T4283Bean_old();
		
		t4283Bean_old.setNum_ruc(bean.getNum_ruc());
		t4283Bean_old.setCod_cpe(bean.getCod_cpe());
		t4283Bean_old.setNum_serie_cpe(bean.getNum_serie_cpe());				
		t4283Bean_old.setNum_cpe(bean.getNum_cpe());
		t4283Bean_old.setCod_rubro(bean.getCod_rubro());
		
		
		T4283Bean_old2 t4283Bean_old2 = new T4283Bean_old2();
		
		t4283Bean_old2.setNum_ruc(bean.getNum_ruc());
		t4283Bean_old2.setCod_cpe(bean.getCod_cpe());
		t4283Bean_old2.setNum_serie_cpe(bean.getNum_serie_cpe());				
		t4283Bean_old2.setNum_cpe(bean.getNum_cpe());
		t4283Bean_old2.setCod_rubro(bean.getCod_rubro());
		
		T4283Bean rubrosRegular = recuperarRubrosTablaRegular(bean);

		
		if (rubrosRegular != null) {
			rubrosFinal = rubrosRegular;
			if (log.isDebugEnabled()) {log.debug("Ingresado a rubros Regular");}
		}
		else
		{
			T4283Bean_old rubrosAnterior = recuperarRubrosTablaAnterior(t4283Bean_old);
			
			if (rubrosAnterior != null) {
				rubrosFinal = convertirT4283Bean(rubrosAnterior);
				if (log.isDebugEnabled()) {log.debug("Ingresado a rubros Anterior Old");}
			}
			else
			{
				T4283Bean_old2 rubrosAnterior2 = recuperarRubrosTablaAnterior2(t4283Bean_old2);
				if (rubrosAnterior2 != null) {
					rubrosFinal = convertirT4283Bean_old2(rubrosAnterior2);
					if (log.isDebugEnabled()) {log.debug("Ingresado a rubros Anterior Old2");}
				}
			}
		}
		return rubrosFinal;
	}


	@SuppressWarnings("unchecked")
	public List <T4283Bean> findRubroDetalle_ByRUC_codCPE_Serie_CPE_rubro(T4283Bean bean) {
		if (log.isDebugEnabled()) {log.debug("findRubroDetalle_ByRUC_codCPE_Serie_CPE_rubro (" + bean + ")");}
		
		return (ArrayList <T4283Bean>)  getSqlMapClientTemplate().queryForList("T4283h.findRubroDetalle_ByRUC_codCPE_Serie_CPE_rubro", bean);
	}

	public T4283Bean findRubro_ByRUC_codCPE_Serie_CPE_rubro_numFila_indcabdet(T4283Bean bean) {
		if (log.isDebugEnabled()) {log.debug("findRubro_ByRUC_codCPE_Serie_CPE_rubro_numFila_indcabdet (" + bean + ")");}
		Object obj = getSqlMapClientTemplate().queryForObject("T4283h.findRubro_ByRUC_codCPE_Serie_CPE_rubro_numFila_indcabdet", bean);
		return (obj != null ? (T4283Bean) obj: null);
	}
	
	public Integer findMaxFila_ByRUC_CPE_Indcabdet(T4283Bean bean) {
		if (log.isDebugEnabled()) {log.debug("findMaxFila_ByRUC_CPE_Indcabdet (" + bean + ")");}
		 
		return (Integer) getSqlMapClientTemplate().queryForObject("T4283h.findMaxFila_ByRUC_CPE_Indcabdet", bean);
	}
	
	@SuppressWarnings("unchecked")
	public List<T4283Bean> findRubros_ByRUC_codCPE_Serie_CPE_numFila_indcabdet(T4283Bean bean) {
		if (log.isDebugEnabled()) {log.debug("findRubros_ByRUC_codCPE_Serie_CPE_numFila_indcabdet (" + bean + ")");}
		return getSqlMapClientTemplate().queryForList("T4283h.findRubros_ByRUC_codCPE_Serie_CPE_numFila_indcabdet", bean);
	}
	
	@Override
	public void deleteByRUC_codCPE_Serie_CPE_indcabdet(T4283Bean bean) {
		if (log.isDebugEnabled()) {log.debug("deleteByRUC_codCPE_Serie_CPE_indcabdet (" +bean.getNum_ruc() + ")");}
		getSqlMapClientTemplate().delete("T4283h.deleteByRUC_codCPE_Serie_CPE_indcabdet",bean);
		return ;
	}
 
	@Override
	public void deleteByRUC_codCPE_Serie_CPE_indcabdet_rubro(T4283Bean bean) {
		if (log.isDebugEnabled()) {log.debug("deleteByRUC_codCPE_Serie_CPE_indcabdet_rubro (" +bean.getNum_ruc() + ")");}
		getSqlMapClientTemplate().delete("T4283h.deleteByRUC_codCPE_Serie_CPE_indcabdet_rubro",bean);
		return ;
	}


}
//FIN: PAS20201U210100184