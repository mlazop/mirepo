package pe.gob.sunat.servicio2.registro.electronico.comppago.factura.model.dao.ibatis;


import java.util.HashMap;
import java.util.Map;
import pe.gob.sunat.framework.spring.util.dao.SqlMapDAOBase;
import pe.gob.sunat.servicio2.registro.electronico.comppago.factura.model.dao.T4534DAO;
import pe.gob.sunat.servicio2.registro.electronico.comppago.factura.model.domain.T4534Bean;
  
public class SqlMapT4534DAOImpl extends SqlMapDAOBase implements T4534DAO {

	@Override
	public T4534Bean findByPK(String nroRUC, String serie, String tipocomp,Integer numcomp) {
		if (this.log.isDebugEnabled()) this.log.debug("SQLMap T4534.findByPK (" + nroRUC + "-" + serie+"-" +tipocomp +"-"+numcomp );
	    Map < String , Object > m = new HashMap< String, Object >();
		 m.put("num_ruc", nroRUC);
		 m.put("num_serie", serie);
		 m.put("cod_tipcomp", tipocomp);
		 m.put("num_comprobante", numcomp);		 
		return (T4534Bean)getSqlMapClientTemplate().queryForObject("T4534.findByFeGemRegistrado", m);
	}

	@Override
	public void insertar(T4534Bean t4534Bean) {
		 if (this.log.isDebugEnabled()) this.log.debug("SQLMap insertar   (" + t4534Bean + ")");
		    getSqlMapClientTemplate().insert("T4534.insertar", t4534Bean);		
	}	
}
