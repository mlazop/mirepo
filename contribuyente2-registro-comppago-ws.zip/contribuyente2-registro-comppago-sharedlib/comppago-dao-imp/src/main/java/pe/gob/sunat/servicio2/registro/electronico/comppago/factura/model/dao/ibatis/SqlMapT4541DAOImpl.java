package pe.gob.sunat.servicio2.registro.electronico.comppago.factura.model.dao.ibatis;


import java.util.HashMap;
import java.util.Map;
import pe.gob.sunat.framework.spring.util.dao.SqlMapDAOBase;
import pe.gob.sunat.servicio2.registro.electronico.comppago.factura.model.dao.T4541DAO;
import pe.gob.sunat.servicio2.registro.electronico.comppago.factura.model.domain.T4541Bean;

   
public class SqlMapT4541DAOImpl extends SqlMapDAOBase implements T4541DAO {
	
	@Override
	public T4541Bean findByFiltro(T4541Bean bean){		
			Object obj = getSqlMapClientTemplate().queryForObject("T4541.findByFiltro", bean);
			return (obj != null ? (T4541Bean) obj: null);		
	}
	
	@Override
	public T4541Bean findByPK(String nroRUC, String serie, String tipocomp,Integer numcomp) {
		if (this.log.isDebugEnabled()) this.log.debug("SQLMap T4541.findByPK (" + nroRUC + "-" + serie+"-" +tipocomp +"-"+numcomp );
	    Map < String , Object > m = new HashMap< String, Object >();
		 m.put("num_ruc", nroRUC);
		 m.put("num_serie", serie);
		 m.put("cod_tipcomp", tipocomp);
		 m.put("num_comprobante", numcomp);		 
		return (T4541Bean)getSqlMapClientTemplate().queryForObject("T4541.findByFeGemAnulado", m);
	}

	@Override
	public void insertar(T4541Bean bean) {
		 if (this.log.isDebugEnabled()) this.log.debug("SQLMap insertar   (" + bean + ")");
		    getSqlMapClientTemplate().insert("T4541.insertar", bean);		
	}

	
}
