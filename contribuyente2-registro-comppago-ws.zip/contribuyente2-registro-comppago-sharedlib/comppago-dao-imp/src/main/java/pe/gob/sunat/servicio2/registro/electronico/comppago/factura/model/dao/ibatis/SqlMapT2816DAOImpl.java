package pe.gob.sunat.servicio2.registro.electronico.comppago.factura.model.dao.ibatis;

import pe.gob.sunat.framework.spring.util.dao.SqlMapDAOBase;
import pe.gob.sunat.servicio2.registro.electronico.comppago.factura.model.dao.T2816DAO;
import pe.gob.sunat.servicio2.registro.electronico.comppago.factura.model.domain.T2816Bean;

public class SqlMapT2816DAOImpl extends SqlMapDAOBase implements T2816DAO {

	@Override
	public T2816Bean select(String num_docum, String cod_acceso, String cod_detalle) {
		
		T2816Bean bean = new T2816Bean();
		bean.setNum_docum(num_docum);
		bean.setCod_acceso(cod_acceso);
		bean.setCod_detalle(cod_detalle);
		
		return null;
	}

	@Override
	public int update(String num_docum, String cod_acceso, String cod_detalle) {
		int retval = 0;
		T2816Bean bean = new T2816Bean();
		bean.setNum_docum(num_docum);
		bean.setCod_acceso(cod_acceso);
		bean.setCod_detalle(cod_detalle);
		
		retval = getSqlMapClientTemplate().update("T2816.update",bean);
		
		return retval;	
	}

}
