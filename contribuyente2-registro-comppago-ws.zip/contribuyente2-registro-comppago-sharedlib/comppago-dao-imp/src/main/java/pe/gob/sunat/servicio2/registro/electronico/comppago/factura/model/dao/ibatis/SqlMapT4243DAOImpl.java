package pe.gob.sunat.servicio2.registro.electronico.comppago.factura.model.dao.ibatis;

import pe.gob.sunat.framework.spring.util.dao.SqlMapDAOBase;
import pe.gob.sunat.servicio2.registro.electronico.comppago.factura.model.dao.T4243DAO;
import pe.gob.sunat.servicio2.registro.electronico.comppago.factura.model.domain.T4243Bean;

public class SqlMapT4243DAOImpl extends SqlMapDAOBase implements T4243DAO{

	@Override
	public T4243Bean findByRUC_Serie_CPE_ID(T4243Bean bean) {
		if (log.isDebugEnabled()) {log.debug("SqlMapDAOBase findByRUC_Serie_CPE_ID (" + bean.getNum_ruc() + ")");}

		return (T4243Bean) getSqlMapClientTemplate().queryForObject("T4243.findByRUC_Serie_CPE_ID", bean);
	}

	@Override
	public T4243Bean findFileXmlJoinTCabCPETArcXmlByPrimaryKey(String nroRUC, String codCpe, String nroSerie, Integer nroCPE){
		
		T4243Bean bean = new T4243Bean();
		bean.setNum_ruc(nroRUC);
		bean.setCod_cpe(codCpe);
		bean.setNum_serie_cpe(nroSerie);
		bean.setNum_cpe(nroCPE);
		
		Object obj = getSqlMapClientTemplate().queryForObject("T4243.findFileXmlJoinTCabCPETArcXmlByPrimaryKey", bean);
		
		return (obj != null ? (T4243Bean) obj: null);		
	}

	@Override
	public T4243Bean findFileZipJoinTCabCPETRelcompelecTFESTOREByPrimaryKey(String nroRUC, String codCpe, String nroSerie, Integer nroCPE){
		
		T4243Bean bean = new T4243Bean();
		bean.setNum_ruc(nroRUC);
		bean.setCod_cpe(codCpe);
		bean.setNum_serie_cpe(nroSerie);
		bean.setNum_cpe(nroCPE);
		
		Object obj = getSqlMapClientTemplate().queryForObject("T4243.findFileZipJoinTCabCPETRelcompelecTFESTOREByPrimaryKey", bean);
		
		return (obj != null ? (T4243Bean) obj: null);		
	}
	
	@Override
	public void insert(T4243Bean bean) throws Exception {
		// TODO Auto-generated method stub
		
	}

	@Override
	public T4243Bean findFileXmlJoinTCabCPETArcXmlByPrimaryKeyISO88591(String nroRUC, String codCPE, String nroSerie, Integer nroCPE) {
		// TODO Auto-generated method stub
		return null;
	}
	
}
