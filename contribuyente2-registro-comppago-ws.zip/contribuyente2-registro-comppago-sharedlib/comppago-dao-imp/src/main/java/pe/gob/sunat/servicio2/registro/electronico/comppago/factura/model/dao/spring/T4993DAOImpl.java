package pe.gob.sunat.servicio2.registro.electronico.comppago.factura.model.dao.spring;

import java.sql.Blob;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import javax.sql.DataSource;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.dao.DataAccessException;
import org.springframework.dao.IncorrectResultSizeDataAccessException;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.jdbc.core.support.AbstractLobCreatingPreparedStatementCallback;
import org.springframework.jdbc.support.lob.LobCreator;
import org.springframework.jdbc.support.lob.LobHandler;

import pe.gob.sunat.framework.spring.util.date.FechaBean;
import pe.gob.sunat.servicio2.registro.electronico.comppago.factura.model.dao.T4993DAO;
import pe.gob.sunat.servicio2.registro.electronico.comppago.factura.model.domain.T4993Bean;


public class T4993DAOImpl implements T4993DAO {
	protected final Log log = LogFactory.getLog(getClass());
	private JdbcTemplate jdbcTemplate;
	private LobHandler lobHandler;
	
	private final String INSERT_SENTENCE = "insert into t4993arcadcpe(num_ruc , num_id_archivo, num_correl, arc_adjunto , fec_archivo , " +
			"ind_procedencia , des_nombre ,num_id_firma, cod_usumodif , fec_modif ) values (?,?,?,?,?,?,?,?,?,?);";	
	private final String findByPrimaryKey = "select num_ruc, num_id_archivo, num_correl, arc_adjunto , fec_archivo , ind_procedencia , des_nombre ,num_id_firma, cod_usumodif , fec_modif  from t4993arcadcpe where num_ruc = ? and num_id_archivo = ? and num_correl=? ;";
	//private final String findByNum_id_archivo = "select num_ruc, num_id_archivo, num_correl, arc_adjunto , fec_archivo , ind_procedencia , des_nombre ,num_id_firma, cod_usumodif , fec_modif  from t4993arcadcpe where num_id_archivo = ? ;";
	
	public void setDataSource(DataSource dataSource) {
		this.jdbcTemplate = new JdbcTemplate(dataSource);
	}
	
	public void setLobHandler(LobHandler lobHandler) {
		this.lobHandler = lobHandler;
	}	
	
	public JdbcTemplate getJdbcTemplate() {
		return jdbcTemplate;
	}

	public void setJdbcTemplate(JdbcTemplate jdbcTemplate) {
		this.jdbcTemplate = jdbcTemplate;
	}

	@Override
	public void insert(T4993Bean bean) {
		if (log.isDebugEnabled()) { log.debug("insert( " + bean + " )");}
		
		final T4993Bean beanFile = bean;
		
		if(log.isDebugEnabled()) {
			log.debug("Objeto a insertar");
			log.debug(beanFile.getNum_ruc());
			log.debug(beanFile.getNum_id_archivo());
			log.debug(beanFile.getNum_correl());
			log.debug(beanFile.getArc_adjunto());
			log.debug(beanFile.getFec_archivo().getTimestamp());
			log.debug(beanFile.getInd_procedencia());
			log.debug(beanFile.getDes_nombre());
			log.debug(beanFile.getNum_id_firma());
			log.debug(beanFile.getCod_usumodif());
			log.debug(beanFile.getFec_modif().getTimestamp());
		}
		
		
	
		jdbcTemplate.execute(this.INSERT_SENTENCE, new AbstractLobCreatingPreparedStatementCallback(lobHandler) {
		protected void setValues(PreparedStatement ps, LobCreator lobCreator)
				throws SQLException, DataAccessException {
		 
					ps.setString(1, beanFile.getNum_ruc());
					ps.setLong(2, beanFile.getNum_id_archivo());
					ps.setInt(3, beanFile.getNum_correl());
					lobCreator.setBlobAsBytes(ps,4,beanFile.getArc_adjunto());			
					ps.setTimestamp(5, beanFile.getFec_archivo().getTimestamp());		
					ps.setString(6, beanFile.getInd_procedencia());
					ps.setString(7, beanFile.getDes_nombre());
					ps.setInt(8, beanFile.getNum_id_firma());
					ps.setString(9, beanFile.getCod_usumodif());
					ps.setTimestamp(10, beanFile.getFec_modif().getTimestamp());

				}
		});
	}

	@Override
	public T4993Bean findByPrimaryKey(String nroRUC, Long id, Integer correl) {
		
		if (log.isDebugEnabled()) { log.debug("T4993DAOImpl Spring findByPrimaryKey( " + nroRUC + ", " + id + "," + correl+ ")");}
		try {
		    RowMapper mapper = new RowMapper() {
		    	public Object mapRow(ResultSet rs, int rowNum) throws SQLException {
		    		T4993Bean bean = new T4993Bean();
		    		if (log.isDebugEnabled()) { log.debug("T4993DAOImpl findByPrimaryKey :Mapeando datos");}

		    			bean.setNum_ruc(rs.getString("num_ruc"));
		    			bean.setNum_id_archivo(rs.getLong("num_id_archivo"));
		    			bean.setNum_correl(rs.getInt("num_correl"));
		    			bean.setFec_archivo(new FechaBean(rs.getTimestamp("fec_archivo")));
		    			bean.setInd_procedencia(rs.getString("ind_procedencia"));
		    			bean.setDes_nombre(rs.getString("des_nombre"));
		    			bean.setNum_id_firma(rs.getInt("num_id_firma"));
		    			bean.setCod_usumodif(rs.getString("cod_usumodif"));
		    			bean.setArc_adjunto(lobHandler.getBlobAsBytes(rs, "arc_adjunto"));
		    			bean.setFec_modif(new FechaBean(rs.getTimestamp("fec_modif")));

		            return bean;
		        }
		    };

			return (T4993Bean)jdbcTemplate.queryForObject(this.findByPrimaryKey,
					new Object[]{nroRUC, id, correl}, mapper);
		}
		catch(IncorrectResultSizeDataAccessException e) { log.error(e,e);return null; }
	}
	
	
	public T4993Bean descargaPDF(String nroRUC, Long id, Integer correl) {
	//public T4993Bean descargaPDF(String numIdXML) {
		
		if (log.isDebugEnabled()) { log.debug("T4993DAOImpl Spring findByPrimaryKey( " + nroRUC + ", " + id + "," + correl+ ")");}
		//if (log.isDebugEnabled()) { log.debug("T4993DAOImpl Spring findByNum_id_archivo( " + numIdXML + ")");}
		try {
		    RowMapper mapper = new RowMapper() {
		    	public Object mapRow(ResultSet rs, int rowNum) throws SQLException {
		    		T4993Bean bean = new T4993Bean();
		    		if (log.isDebugEnabled()) { log.debug("T4993DAOImpl findByPrimaryKey :Mapeando datos");}
		    		//if (log.isDebugEnabled()) { log.debug("T4993DAOImpl findByNum_id_archivo :Mapeando datos");}
		    		
		    			bean.setNum_ruc(rs.getString("num_ruc"));
		    			bean.setNum_id_archivo(rs.getLong("num_id_archivo"));
		    			bean.setNum_correl(rs.getInt("num_correl"));
		    			bean.setFec_archivo(new FechaBean(rs.getTimestamp("fec_archivo")));
		    			bean.setInd_procedencia(rs.getString("ind_procedencia"));
		    			bean.setDes_nombre(rs.getString("des_nombre"));
		    			bean.setNum_id_firma(rs.getInt("num_id_firma"));
		    			bean.setCod_usumodif(rs.getString("cod_usumodif"));
		    			Blob blob = rs.getBlob("arc_adjunto");
		    			int blobLength = (int) blob.length();  
		    			byte[] blobAsBytes = blob.getBytes(1, blobLength);

		    			//release the blob and free up memory. (since JDBC 4.0)
//		    			blob.free();
		    			
		    			bean.setArc_adjunto(blobAsBytes);
//		    			bean.setArc_adjunto(lobHandler.getBlobAsBytes(rs, "arc_adjunto"));
		    			bean.setFec_modif(new FechaBean(rs.getTimestamp("fec_modif")));

		            return bean;
		        }
		    };

			return (T4993Bean)jdbcTemplate.queryForObject(this.findByPrimaryKey,
					new Object[]{nroRUC, id, correl}, mapper);
//		    return (T4993Bean)jdbcTemplate.queryForObject(this.findByNum_id_archivo,
//		    		new Object[]{numIdXML}, mapper);
		}
		catch(IncorrectResultSizeDataAccessException e) { log.error(e,e);return null; }
	}
}
