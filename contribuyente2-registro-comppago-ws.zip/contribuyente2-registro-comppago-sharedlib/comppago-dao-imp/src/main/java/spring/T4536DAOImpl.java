package spring;

import java.sql.Blob;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import javax.sql.DataSource;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.dao.DataAccessException;
import org.springframework.dao.IncorrectResultSizeDataAccessException;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.jdbc.core.support.AbstractLobCreatingPreparedStatementCallback;
import org.springframework.jdbc.support.lob.LobCreator;
import org.springframework.jdbc.support.lob.LobHandler;

import pe.gob.sunat.framework.spring.util.date.FechaBean;
import pe.gob.sunat.servicio2.registro.electronico.comppago.factura.model.dao.T4536DAO;
import pe.gob.sunat.servicio2.registro.electronico.comppago.factura.model.domain.T4536Bean;


public class T4536DAOImpl implements T4536DAO {
	protected final Log log = LogFactory.getLog(getClass());
	private JdbcTemplate jdbcTemplate;
	private LobHandler lobHandler;
			
	private final String findBill = "SELECT num_ticket, ind_modo, arc_input, cod_usumodif, fec_modif FROM T4536FESTORE WHERE num_ticket = ? AND ind_modo = ? ;";
	
	public void setDataSource(DataSource dataSource) {
		this.jdbcTemplate = new JdbcTemplate(dataSource);
	}
	
	public void setLobHandler(LobHandler lobHandler) {
		this.lobHandler = lobHandler;
	}	
	
	public JdbcTemplate getJdbcTemplate() {
		return jdbcTemplate;
	}

	public void setJdbcTemplate(JdbcTemplate jdbcTemplate) {
		this.jdbcTemplate = jdbcTemplate;
	}

	@Override
	public T4536Bean getBillStore(String ticket, String mode){
		
		if (log.isDebugEnabled()) { log.debug("T4536DAOImpl Spring getBillStore( " + ticket + ", " + mode + ")");}
		try {
		    RowMapper mapper = new RowMapper() {
		    	public Object mapRow(ResultSet rs, int rowNum) throws SQLException {
		    		T4536Bean bean = new T4536Bean();
		    		if (log.isDebugEnabled()) { log.debug("T4536DAOImpl findBill :Mapeando datos");}

		    		bean.setTicket(rs.getString("num_ticket"));
	    			bean.setModo(rs.getString("ind_modo"));
	    			bean.setContenido(lobHandler.getBlobAsBytes(rs, "arc_input"));
		    		bean.setUsuarioModificador(rs.getString("cod_usumodif"));		    		
		    		bean.setFechaModificacion(new FechaBean(rs.getTimestamp("fec_modif")));
		            return bean;
		        }
		    };

			return (T4536Bean)jdbcTemplate.queryForObject(this.findBill,
					new Object[]{ticket, mode}, mapper);
		}
		catch(IncorrectResultSizeDataAccessException e) { log.error(e,e);return null; }
	}
	
}
