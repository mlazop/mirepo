/**
 * 
 */
/**
 * @author maguilarac
 *
 */
package pe.gob.sunat.servicio2.registro.electronico.comppago.factura.model.dao.ibatis.maps;