package pe.gob.sunat.servicio2.registro.electronico.comppago.factura.model.dao;

import pe.gob.sunat.servicio2.registro.electronico.comppago.factura.model.domain.T4533Bean;

public interface T4533DAO {
	
	public T4533Bean getLogPackStatus(String ticket);
	
}
