package pe.gob.sunat.servicio2.registro.electronico.comppago.factura.model.dao;

import pe.gob.sunat.servicio2.registro.electronico.comppago.factura.model.domain.T4536Bean;

public interface T4536DAO {

	public T4536Bean getBillStore(String ticket, String mode);
}
