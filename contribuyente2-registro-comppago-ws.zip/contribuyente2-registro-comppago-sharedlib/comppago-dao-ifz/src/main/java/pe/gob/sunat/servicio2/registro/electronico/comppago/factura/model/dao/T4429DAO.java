package pe.gob.sunat.servicio2.registro.electronico.comppago.factura.model.dao;

import java.util.List;

import pe.gob.sunat.servicio2.registro.electronico.comppago.factura.model.domain.T4429Bean;

public interface T4429DAO {
	public int insert (T4429Bean bean);
	public Integer findTotalBy_TipoDocRel_RUC_Factura(String TipoCPE, String numRucEmisor, String serieDocRel, String numeroDocRel);
	public Integer findTotalBy_TipoDocRel_RUC_Boleta(String TipoCPE, String numRucEmisor, String serieDocRel, String numeroDocRel);
	public T4429Bean findBy_RucTipoSerieNumeroRelacion(String TipoCPE, String numRucEmisor, String serieDoc, String numeroDoc, String codRelacion);
	public T4429Bean findByRucTipDocSerieDocRelacion(String numRuc, String codCpe, String numSerieCpe, Integer numCpe, String codRel, String codDocRel);
	public List<T4429Bean> findDocsEmitidosPorFETipo_By_Ruc_CodCP_SerieNumDocrel(String TipoCPE, String numRucEmisor, String serieDocRel, String numeroDocRel);
	public List<T4429Bean> findDocsEmitidosPorBVETipo_By_Ruc_CodCP_SerieNumDocrel(String TipoCPE, String numRucEmisor, String serieDocRel, String numeroDocRel);
}