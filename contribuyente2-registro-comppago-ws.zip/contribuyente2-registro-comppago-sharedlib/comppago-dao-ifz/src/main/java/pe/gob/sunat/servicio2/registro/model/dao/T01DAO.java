package pe.gob.sunat.servicio2.registro.model.dao;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.TreeMap;



import pe.gob.sunat.servicio2.registro.model.domain.T01Bean;

public interface T01DAO extends Serializable {
	public T01Bean findAllByNumeroArgumento (String numero, String argumento);
	public T01Bean findByNumeroArgumento (String numero, String argumento);
	public List<T01Bean> findUnidadMedidaVigente(String numero);
	
	public List<T01Bean> findUnidadMedidaExportacion(String numero);
	public List<T01Bean> findUnidadMedidaNoExportacion(String numero);
	public List<T01Bean> findTiposDocumentoActivos();
	public List<T01Bean> findTiposComprobante();
	
	//Inicio agregado fsantosl
	public TreeMap mbuscar(ArrayList v);
	public String findByArgumento(String numero, String argumento);
	public List findByArgumentoINfuncion(Map param);
	public List findByArgumentoPatron(String numero, String argumento);
	//Fin agregado fsantosl
		//metodos  para  factura grandes emisores 
		public List<T01Bean> findByNumeroCache(String numero);
		public T01Bean findByNumeroArgumentoCache(String numero, String argumento);
		// fin de metodos  para  factura grandes emisores 	
	
	//Inicio metodos para Transferencia de fondos
	public List buscaParametroLimiteEnte(Map param);
	public List buscaParametroPorEnte(Map param);
	public void updateMontoHoy(Map param);
	public void desacticaMontoVigente(Map param);
	public void insertNuevoMonto(Map param);
	//Fin metodos para Transferencia de fondos


	/*metodo para libros electronicos */
	public String findByNumero003Libros( String argumento);
	
	public List<T01Bean> findByNumero052Dependencia(String codDependencia);

}
