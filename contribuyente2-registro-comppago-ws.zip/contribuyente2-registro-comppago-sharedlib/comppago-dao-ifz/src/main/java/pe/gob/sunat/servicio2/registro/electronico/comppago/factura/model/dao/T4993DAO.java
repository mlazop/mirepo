package pe.gob.sunat.servicio2.registro.electronico.comppago.factura.model.dao;

import pe.gob.sunat.servicio2.registro.electronico.comppago.factura.model.domain.T4993Bean;


public interface T4993DAO {
	public void insert (T4993Bean bean);

	public T4993Bean findByPrimaryKey(String nroRUC, Long id, Integer correl);
}
