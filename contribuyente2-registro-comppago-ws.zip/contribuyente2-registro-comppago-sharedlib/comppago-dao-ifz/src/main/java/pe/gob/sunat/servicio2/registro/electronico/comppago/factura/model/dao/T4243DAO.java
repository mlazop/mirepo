package pe.gob.sunat.servicio2.registro.electronico.comppago.factura.model.dao;

import pe.gob.sunat.servicio2.registro.electronico.comppago.factura.model.domain.T4243Bean;

//Verificar
//import pe.gob.sunat.servicio2.registro.comppago.model.domain.T4243Bean;

public interface T4243DAO {
	public void insert(T4243Bean bean) throws Exception;
	public T4243Bean findFileXmlJoinTCabCPETArcXmlByPrimaryKey(String nroRUC, String codCPE, String nroSerie, Integer nroCPE);
	public T4243Bean findByRUC_Serie_CPE_ID(T4243Bean bean);
	public T4243Bean findFileXmlJoinTCabCPETArcXmlByPrimaryKeyISO88591(String nroRUC, String codCPE, String nroSerie, Integer nroCPE);
	public T4243Bean findFileZipJoinTCabCPETRelcompelecTFESTOREByPrimaryKey(String nroRUC, String codCPE, String nroSerie, Integer nroCPE);
}
