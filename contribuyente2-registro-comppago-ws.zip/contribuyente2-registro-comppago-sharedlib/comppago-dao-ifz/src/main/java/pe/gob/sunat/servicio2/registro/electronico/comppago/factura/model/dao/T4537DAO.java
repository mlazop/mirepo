package pe.gob.sunat.servicio2.registro.electronico.comppago.factura.model.dao;

import pe.gob.sunat.servicio2.registro.electronico.comppago.factura.model.domain.T4537Bean;

public interface T4537DAO {

	public abstract T4537Bean findByPK(String ticket, Integer  ticket_correl);
}
