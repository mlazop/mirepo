package pe.gob.sunat.servicio2.registro.electronico.comppago.factura.model.dao;

import java.util.List;
import java.util.Map;

import pe.gob.sunat.framework.spring.util.date.FechaBean;
import pe.gob.sunat.servicio2.registro.electronico.comppago.factura.model.domain.T4241Bean;

public interface T4241DAO {
	public T4241Bean findByFiltro(T4241Bean param) ;
	
	public int insert (T4241Bean bean);
	public void updateCPEAnular(T4241Bean factura);
	public List<T4241Bean> findByRUCRecepCPEPendientesAnulacion(String numeroDeRUC, String codCpe);
	public List<T4241Bean> findByNroRUCEmitidas(String nroRUC, FechaBean fechaIni, FechaBean fechaFin, String codCpe);
	public List<T4241Bean> findByNroRUCRechazadas(String nroRUC, FechaBean fechaIni, FechaBean fechaFin, String codCpe);	
	public List<T4241Bean> findByNroRUCRecibidas(String nroRUC, FechaBean fechaIni, FechaBean fechaFin, String codCpe);
	public List<T4241Bean> findByNroRUCBVERecibidas(String nroRUC, FechaBean fechaIni, FechaBean fechaFin, String codCpe);
	
	//public List<T4241Bean> findByNroRUCRecibidas(String nroRUC, FechaBean fechaIni, FechaBean fechaFin, String codCpe, String numSerieCpe);	
	public T4241Bean findByPK(String nroRUC, String nroSerie, Integer nroCPE, String codCpe);
	public List<T4241Bean> findFacturasByRUC (String nroRUC,  String codCpe) ;
	public List<T4241Bean> findCPEBy_RUCTipoProcedencia (String nroRUC,  String codCpe, String procedencia) ;
	public Integer findTotalFacturasByRUC (String nroRUC,  String codCpe) ;
	public Integer findTotalBoletasByRUC (String nroRUC,  String codCpe) ;
	
	// metodos agrgados  para las consultas de notas de credito y debito 23/11/2010  NAA
	public List<T4241Bean> findByNroRUCNCNDEmitidas(String nroRUC, FechaBean fechaIni, FechaBean fechaFin, String codCpe);
	public List<T4241Bean> findByNroRUCNCNDRecibidas(String nroRUC, FechaBean fechaIni, FechaBean fechaFin, String codCpe);
	public List<T4241Bean> findByNroRUCNCNDBVEEmitidas(String nroRUC, FechaBean fechaIni, FechaBean fechaFin, String codCpe);
	public List<T4241Bean> findByNroRUCNCNDBVERecibidas(String nroRUC, FechaBean fechaIni, FechaBean fechaFin, String codCpe);
	public List<T4241Bean> findByNroRUCBVEEmitidas(String nroRUC, FechaBean fechaIni, FechaBean fechaFin, String codCpe);
	public List<T4241Bean> buscarFacturaEmitida(Map parametros);
	public List<T4241Bean> buscarFacturaRecibida(Map parametros);
	public List<T4241Bean> buscarFacturaRechazada(Map parametros);
	public List<T4241Bean> buscarNCNDEmitida(Map parametros);
	public List<T4241Bean> buscarNCNDRecibida(Map parametros);
	public List<T4241Bean> buscarBoletaEmitida(Map parametros);
	public List<T4241Bean> buscarBoletaRecibida(Map parametros);
	
	//Metodos para consulta AGQY	
	public List<Map> buscarGreRecibida(Map parametros) ;	
	public List<Map> buscarGreEmitida(Map parametros) ;	
	public List<Map> buscarGreRelacionada(Map parametros) ;  
	public List<Map> consultarGreRelacionadasPadre(Map parametros) ;	
	public List<Map> consultarGreRelacionadasHijo(Map parametros) ;	
	
	//Metodos para RVI
	public Integer findMaxCuo_ByRUCPerRegVen(String nroRUC,	String periodoRegVen);	
	public List<T4241Bean> findByNroRUCCPCEmitidos(String nroRUC, FechaBean fechaIni, FechaBean fechaFin) ;
	public List<T4241Bean> findByNroRUCCPCEmitidosMonedaExtranjera(String nroRUC, FechaBean fechaIni, FechaBean fechaFin) ;
	public List<T4241Bean> findByNroRUCCPCEmitidos_RVI(String nroRUC, FechaBean fechaIni, FechaBean fechaFin) ;
	public void updateCPERVI(T4241Bean cpe);
	
	//metodo   fegem naa 
	public void updateCPEDeBajaFeGem(T4241Bean factura);	
	public List<Map> findByTiposRuc(Map parametros);	
	public List<Map> findByTiposRucSerieNumero(Map parametros);	
	public List<Map> findByPlaca(Map parametros);		
	public List<Map> findGuiaAsociada(Map parametros);
	
	//metodo gre-bf msantosf
	public T4241Bean findByFiltroGreBf(T4241Bean param);

}
