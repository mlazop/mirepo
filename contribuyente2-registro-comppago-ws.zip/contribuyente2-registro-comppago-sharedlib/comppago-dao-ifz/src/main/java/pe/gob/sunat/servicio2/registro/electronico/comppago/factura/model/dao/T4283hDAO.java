//INI: PAS20201U210100184
package pe.gob.sunat.servicio2.registro.electronico.comppago.factura.model.dao;

import java.util.List;

import pe.gob.sunat.servicio2.registro.electronico.comppago.factura.model.domain.T4283Bean;
import pe.gob.sunat.servicio2.registro.electronico.comppago.factura.model.domain.T4283Bean_old;
import pe.gob.sunat.servicio2.registro.electronico.comppago.factura.model.domain.T4283Bean_old2;

public interface T4283hDAO {
	public int insert (T4283Bean bean);
	
	public T4283Bean findRubroCabecera_ByRUC_codCPE_Serie_CPE_Rubro(T4283Bean bean);
	public List <T4283Bean>  findRubroDetalle_ByRUC_codCPE_Serie_CPE_rubro(T4283Bean bean);
	public T4283Bean findRubro_ByRUC_codCPE_Serie_CPE_rubro_numFila_indcabdet(T4283Bean bean);
	public Integer findMaxFila_ByRUC_CPE_Indcabdet(T4283Bean bean);
	public List<T4283Bean> findRubros_ByRUC_codCPE_Serie_CPE_numFila_indcabdet(T4283Bean bean) ;

	public void deleteByRUC_codCPE_Serie_CPE_indcabdet(T4283Bean bean);

	public void deleteByRUC_codCPE_Serie_CPE_indcabdet_rubro(T4283Bean bean);
	
	public T4283Bean_old recuperarRubrosTablaAnterior(T4283Bean_old bean);
	public T4283Bean_old2 recuperarRubrosTablaAnterior2(T4283Bean_old2 bean);
	public T4283Bean recuperarRubrosTablaRegular(T4283Bean bean);
}
//FIN: PAS20201U210100184
