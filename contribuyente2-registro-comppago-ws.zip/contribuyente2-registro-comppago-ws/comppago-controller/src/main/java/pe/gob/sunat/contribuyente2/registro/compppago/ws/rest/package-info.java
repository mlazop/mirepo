/**
 * 
 */
/**
 * @author maguilarac
 *
 */
package pe.gob.sunat.contribuyente2.registro.compppago.ws.rest;