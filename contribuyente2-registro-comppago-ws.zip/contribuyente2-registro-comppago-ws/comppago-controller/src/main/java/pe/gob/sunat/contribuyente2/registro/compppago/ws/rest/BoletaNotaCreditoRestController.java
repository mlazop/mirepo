package pe.gob.sunat.contribuyente2.registro.compppago.ws.rest;

/**
 * @author : maguilarac
 * @name   : BoletaNotaCreditoRestController
 * @Description : Entrada de peticiones de consulta de Boletas Portal 
 * @author      : Milton Aguilar
 * @version     : %I%, %G%
 * @since       : 1.0
 * @return
 **/

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.http.MediaType;

import pe.gob.sunat.contribuyente2.registro.comppago.service.imp.BoletaNotaCreditoRestServiceImpl;
import pe.gob.sunat.framework.spring.util.exception.BusinessValidationException;
import pe.gob.sunat.framework.spring.util.factory.FabricaDeServicios;
import pe.gob.sunat.servicio2.registro.electronico.comppago.boleta.bean.ComprobanteBean;
import pe.gob.sunat.tecnologia.menu.bean.UsuarioBean;

@Controller
@RequestMapping(value="/boletanotacredito")
public class BoletaNotaCreditoRestController {
	/**
	 * @description : Fabrica de Servicios
	 * @return
	 */
	@Autowired
	FabricaDeServicios fabricaDeServicios;

	/**
	 * @method : /boletanotacredito/{ruc}-{serie}-{numero}
	 * @param  : {ruc} validado que sean 11 numeros
	 * @param  : {serie} validado que sean entre 3 y 5 digitos
	 * @param  : {numero} numero de la factura
	 * @see    : validarParametrosConsulta
	 * @description : retorna JSON
	 * @return      : ComprobanteBean de tipo boleta
	 **/
	
	@RequestMapping(value = "/{ruc}-{serie}-{numero}",
			method=RequestMethod.GET,
			produces={MediaType.APPLICATION_JSON_VALUE})
			public 
			@ResponseBody ComprobanteBean obtenerBoletaNotaCreditoPorRucSerieNumero(
			@PathVariable("ruc") String ruc,
			@PathVariable("serie") String serie,
			@PathVariable("numero") String numero) 
	throws Exception {
		List<Map<String, String>> listaErrores =validarParametrosConsulta(ruc,serie,numero);
		if(!listaErrores.isEmpty()){
			//Lanzamos el BusinessValidationException
			throw new BusinessValidationException(listaErrores); 
		}
		else
		{
			try {
				//TODO Implementar la respuesta en caso no se consiga resultado de la consulta 
				String tipo="07";
				BoletaNotaCreditoRestServiceImpl boletaNotaCreditoRestService = fabricaDeServicios.getService("sharedlib.contribuyente2.registro.comppago.service.BoletaNotaCreditoRestServiceImpl");
				ComprobanteBean boleta= boletaNotaCreditoRestService.recuperarInfoBoletaNotaCredito(ruc, serie, numero,tipo);
				return boleta;

			} catch (Exception e) {
				Map<String, String> resp = new HashMap<String, String>();
				resp = new HashMap<String, String>();
				resp.put("cod", "50000");
				resp.put("msg", e.getMessage());
				listaErrores.add(resp);
				throw new BusinessValidationException(listaErrores);
			}
		}
	}
	
	//@Override
	private List<Map<String, String>> validarParametrosConsulta(String ruc,String serie,String numero) {

		List<Map<String, String>> listaErrores = new ArrayList<Map<String,String>>();
		Map<String, String> resp = new HashMap<String, String>();
		
		//Validar el RUC
		if(ruc.length()==0){
			resp = new HashMap<String, String>();
			resp.put("cod", "10001");
			resp.put("msg", "El numero de RUC es dato obligatorio");
			listaErrores.add(resp);
		}
		
		if(ruc.length()!=11){
			resp = new HashMap<String, String>();
			resp.put("cod", "10002");
			resp.put("msg", "El RUC "+ ruc+ " debe ser de 11 digitos");
			listaErrores.add(resp);
		}
		//Validar serie
		if(serie.length()==0){
			resp = new HashMap<String, String>();
			resp.put("cod", "20001");
			resp.put("msg", "La serie del comprobante es dato obligatorio");
			listaErrores.add(resp);
		}
		
		if(serie.length()!=4){
			resp = new HashMap<String, String>();
			resp.put("cod", "20002");
			resp.put("msg", "La serie "+serie+" debe ser de 4 caracteres");
			listaErrores.add(resp);
		}
		
		//Validar que se ingrese el numero
		if(numero.length()==0){
			resp = new HashMap<String, String>();
			resp.put("cod", "30001");
			resp.put("msg", "El numero del comprobante es dato Obligatorio");
			listaErrores.add(resp);
		}
		
		return listaErrores;

	}
	
	
}
