package pe.gob.sunat.contribuyente2.registro.compppago.ws.rest;

/**
 * @author maguilarac
 * @name : FacturaNotaDebitoRestController
 * @Description Entrada de peticiones de consulta de Facturas GEM y Portal 
 * @author      Milton Aguilar
 * @version     %I%, %G%
 * @since       1.0
 * @return
 **/

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.http.MediaType;

import pe.gob.sunat.servicio2.registro.electronico.comppago.factura.bean.ComprobanteBean;
import pe.gob.sunat.servicio2.registro.electronico.comppago.factura.bean.DetalleComprobanteBean;
import pe.gob.sunat.servicio2.registro.electronico.comppago.factura.bean.DireccionComprobanteBean;

import pe.gob.sunat.framework.spring.util.exception.BusinessValidationException;
import pe.gob.sunat.framework.spring.util.factory.FabricaDeServicios;
import pe.gob.sunat.contribuyente2.registro.comppago.service.imp.FacturaNotaDebitoRestServiceImpl;

/**
 * @class       : Controlador FacturaNotaDebitoRestController
 * @description : Controlador de peticiones factura 
 * @author      : maguilarac
 * @return
 **/

@Controller
@RequestMapping(value="/facturanotadebito")
public class FacturaNotaDebitoRestController {
	
	/**
	 * @description : Fabrica de Servicios
	 * @return
	 */
	@Autowired
	FabricaDeServicios fabricaDeServicios;

	/**
	 * @method : /facturanotadebito/{ruc}-{serie}-{numero}
	 * @param  : {ruc} validado que sean 11 numeros
	 * @param  : {serie} validado que sean entre 3 y 5 digitos
	 * @param  : {numero} numero de la nota de credito
	 * @see    : validarParametrosConsulta
	 * @description : retorna JSON
	 * @return      : ComprobanteBean de tipo factura
	 **/
	
	@RequestMapping(value = "/{ruc}-{serie}-{numero}", method = RequestMethod.GET, produces = {
			MediaType.APPLICATION_JSON_VALUE })
	public @ResponseBody ComprobanteBean obtenerNotaDebitoPorRucSerieNumero(@PathVariable("ruc") String ruc,
			@PathVariable("serie") String serie, 
			@PathVariable("numero") String numero) 
	throws Exception {

		List<Map<String, String>> listaErrores = validarParametrosConsulta(ruc, serie, numero);
		
		if (!listaErrores.isEmpty()) {
			throw new BusinessValidationException(listaErrores);
		}
		else
		{
			try {
				String tipo="08";

				FacturaNotaDebitoRestServiceImpl facturaNotaDebitoRestService = fabricaDeServicios.getService("sharedlib.contribuyente2.registro.comppago.service.FacturaNotaDebitoRestServiceImpl");
				ComprobanteBean notaDebito= facturaNotaDebitoRestService.recuperarInfoFacturaNotaDebito(ruc, serie, numero,tipo);
				return notaDebito;				
			} catch (Exception e) {
				Map<String, String> resp = new HashMap<String, String>();
				resp = new HashMap<String, String>();
				resp.put("cod", "50000");
				resp.put("msg", e.getMessage());
				listaErrores.add(resp);
				throw new BusinessValidationException(listaErrores);
			}

		}
	}

	/**
	 * @method: validarParametrosConsulta
	 * @description : funcion valida parametros enviados de la consulta
	 * @return list<<string><string>> lista de errores
	 **/
	private List<Map<String, String>> validarParametrosConsulta(String ruc, String serie, String numero) {

		List<Map<String, String>> listaErrores = new ArrayList<Map<String,String>>();
		Map<String, String> resp = new HashMap<String, String>();
		
		//Validar el RUC
		if(ruc.length()==0){
			resp = new HashMap<String, String>();
			resp.put("cod", "10001");
			resp.put("msg", "El numero de RUC es dato obligatorio");
			listaErrores.add(resp);
		}
		
		if(ruc.length()!=11){
			resp = new HashMap<String, String>();
			resp.put("cod", "10002");
			resp.put("msg", "El RUC "+ ruc+ " debe ser de 11 digitos");
			listaErrores.add(resp);
		}
		//Validar serie
		if(serie.length()==0){
			resp = new HashMap<String, String>();
			resp.put("cod", "20001");
			resp.put("msg", "La serie del comprobante es dato obligatorio");
			listaErrores.add(resp);
		}
		
		if(serie.length()!=4){
			resp = new HashMap<String, String>();
			resp.put("cod", "20002");
			resp.put("msg", "La serie "+serie+" debe ser de 4 caracteres");
			listaErrores.add(resp);
		}
		
		//Validar que se ingrese el numero
		if(numero.length()==0){
			resp = new HashMap<String, String>();
			resp.put("cod", "30001");
			resp.put("msg", "El numero del comprobante es dato Obligatorio");
			listaErrores.add(resp);
		}
		
		return listaErrores;
	}
	
}
