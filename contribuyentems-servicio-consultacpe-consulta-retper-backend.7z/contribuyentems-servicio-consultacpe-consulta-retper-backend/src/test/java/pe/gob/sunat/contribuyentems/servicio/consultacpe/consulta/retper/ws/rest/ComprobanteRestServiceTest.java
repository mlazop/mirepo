package pe.gob.sunat.contribuyentems.servicio.consultacpe.consulta.retper.ws.rest;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.MockitoJUnitRunner;

import pe.gob.sunat.contribuyentems.servicio.consultacpe.consulta.retper.services.ComprobanteService;
import pe.gob.sunat.contribuyentems.servicio.consultacpe.consulta.retper.ws.dto.ArchivoRequestDTO;
import pe.gob.sunat.contribuyentems.servicio.consultacpe.consulta.retper.ws.dto.ComprobanteIndividualRequestDTO;
import pe.gob.sunat.contribuyentems.servicio.consultacpe.consulta.retper.ws.dto.ComprobanteMasivaRequestDTO;

import pe.gob.sunat.tecnologiams.arquitectura.framework.core.util.UtilLog;

import javax.ws.rs.core.Response;

import static org.junit.Assert.assertEquals;
import static org.mockito.Mockito.when;

import java.util.Objects;
import pe.gob.sunat.contribuyentems.servicio.consultacpe.consulta.retper.ws.dto.ComprobanteIndividualResponseDTO;
import pe.gob.sunat.contribuyentems.servicio.consultacpe.consulta.retper.ws.dto.ComprobanteMasivaResponseDTO;

@RunWith(MockitoJUnitRunner.Silent.class)
public class ComprobanteRestServiceTest {

    @Mock
    private UtilLog utilLog;

    @Mock
    private ComprobanteService comprobanteService;

    @InjectMocks
    private ComprobanteRestService comprobanteRestService;

    @Test
    public void testObtenerComprobantesIndividual() throws Exception {
        String numRucHeader = "numRucHeader";
        String numRuc = "numRuc";
        String codCpe = "codCpe";
        String numSerie = "numSerie";
        Long numCpe = 123L;
        String codFiltroCpe = "codFiltroCpe";

        ComprobanteIndividualRequestDTO requestDTO = new ComprobanteIndividualRequestDTO.Builder()
                .setNumRucHeader(numRucHeader)
                .setNumRuc(numRuc)
                .setCodCpe(codCpe)
                .setNumSerie(numSerie)
                .setNumCpe(numCpe)
                .setCodFiltroCpe(codFiltroCpe)
                .build();

        when(comprobanteService.obtenerComprobanteIndividual(requestDTO)).thenReturn(new ComprobanteIndividualResponseDTO());

        Response response = comprobanteRestService.obtenerComprobantes(numRucHeader, numRuc, codCpe, numSerie, numCpe, codFiltroCpe);

        assertEquals(200, response.getStatus());
    }
    
    @Test
    public void testobtenerComprobantesMasiva() throws Exception {
        String numRucHeader = "numRucHeader";
        String numRuc = "numRuc";
        String codCpe = "codCpe";
        String numSerieCpe = "numSerieCpe";
        String codFiltroCpe = "codFiltroCpe";
        int numCpeInicio=123;
        int numCpeFin= 124;
        String codEstado="codEstado";
        String codDocIde="codDocIde";
        String numDocIde="numDocIde";
        String fecEmisionIni="fecEmisionIni";
        String fecEmisionFin="fecEmisionFin";

        ComprobanteMasivaRequestDTO requestDTO = new ComprobanteMasivaRequestDTO.Builder()
                .setNumRucHeader(numRucHeader)
                .setNumRucEmisor(numRuc)
                .setCodCpe(codCpe)
                .setCodFiltroCpe(codFiltroCpe)
                .setNumSerieCpe(numSerieCpe)
                .setNumCpeIni(numCpeInicio)
                .setNumCpeFin(numCpeFin)
                .setCodEstado(codEstado)
                .setCodDocIde(codDocIde)
                .setNumDocIde(numDocIde)
                .setFecEmisionIni(fecEmisionIni)
                .setFecEmisionFin(fecEmisionFin)
                .setCodFiltroCpe(codFiltroCpe)
                .build();

        when(comprobanteService.obtenerComprobanteMasiva(requestDTO)).thenReturn(new ComprobanteMasivaResponseDTO());

        Response response=comprobanteRestService.obtenerComprobantesMasiva(numRucHeader, numRuc, codCpe, codFiltroCpe, numSerieCpe, numCpeInicio+"", numCpeFin+"", codEstado, codDocIde, numDocIde, fecEmisionIni, fecEmisionFin);

        assertEquals(200, response.getStatus());
    }
    
    
    @Test
    public void testDescargaComprobanteCdr() throws Exception {
        String numRucHeader = "numRucHeader";
        String numRuc = "numRuc";
        String codCpe = "codCpe";
        String numSerie = "numSerie";
        Long numCpe = 123L;
        String codFiltroCpe = "codFiltroCpe";
        String codTipDes = "codTipDes";

        ArchivoRequestDTO requestDTO = new ArchivoRequestDTO.Builder()
                .setNumRucHeader(numRucHeader)
                .setNumRucEmisor(numRuc)
                .setCodCpe(codCpe)
                .setCodFiltroCpe(codFiltroCpe)
                .setNumSerieCpe(numSerie)
                .setNumCpe(numCpe)
                .setCodFiltroCpe(codFiltroCpe)
                .setCodTipDes(codTipDes)
                .build();
        
        ComprobanteIndividualRequestDTO request = new ComprobanteIndividualRequestDTO.Builder()
                .setNumRucHeader(numRucHeader)
                .setNumRuc(numRuc)
                .setCodCpe(codCpe)
                .setNumSerie(numSerie)
                .setNumCpe(numCpe)
                .setCodFiltroCpe(codFiltroCpe)
                .build();

        Response response = comprobanteRestService.descargaComprobante(numRucHeader, numRuc, codCpe, numSerie, numCpe, codFiltroCpe, codTipDes);

        assertEquals(200, response.getStatus());
    }
    
    @Test
    public void testDescargaComprobantePdf() throws Exception {
        String numRucHeader = "numRucHeader";
        String numRuc = "numRuc";
        String codCpe = "codCpe";
        String numSerie = "numSerie";
        Long numCpe = 123L;
        String codFiltroCpe = "codFiltroCpe";
        String codTipDes = "01";

        ArchivoRequestDTO requestDTO = new ArchivoRequestDTO.Builder()
                .setNumRucHeader(numRucHeader)
                .setNumRucEmisor(numRuc)
                .setCodCpe(codCpe)
                .setCodFiltroCpe(codFiltroCpe)
                .setNumSerieCpe(numSerie)
                .setNumCpe(numCpe)
                .setCodFiltroCpe(codFiltroCpe)
                .setCodTipDes(codTipDes)
                .build();
        
        ComprobanteIndividualRequestDTO request = new ComprobanteIndividualRequestDTO.Builder()
                .setNumRucHeader(numRucHeader)
                .setNumRuc(numRuc)
                .setCodCpe(codCpe)
                .setNumSerie(numSerie)
                .setNumCpe(numCpe)
                .setCodFiltroCpe(codFiltroCpe)
                .build();

        Response response = comprobanteRestService.descargaComprobante(numRucHeader, numRuc, codCpe, numSerie, numCpe, codFiltroCpe, codTipDes);

        assertEquals(200, response.getStatus());
    }
    
    @Test
    public void testDescargaComprobanteXML() throws Exception {
        String numRucHeader = "numRucHeader";
        String numRuc = "numRuc";
        String codCpe = "codCpe";
        String numSerie = "numSerie";
        Long numCpe = 123L;
        String codFiltroCpe = "codFiltroCpe";
        String codTipDes = "02";

        ArchivoRequestDTO requestDTO = new ArchivoRequestDTO.Builder()
                .setNumRucHeader(numRucHeader)
                .setNumRucEmisor(numRuc)
                .setCodCpe(codCpe)
                .setCodFiltroCpe(codFiltroCpe)
                .setNumSerieCpe(numSerie)
                .setNumCpe(numCpe)
                .setCodFiltroCpe(codFiltroCpe)
                .setCodTipDes(codTipDes)
                .build();
        
        ComprobanteIndividualRequestDTO request = new ComprobanteIndividualRequestDTO.Builder()
                .setNumRucHeader(numRucHeader)
                .setNumRuc(numRuc)
                .setCodCpe(codCpe)
                .setNumSerie(numSerie)
                .setNumCpe(numCpe)
                .setCodFiltroCpe(codFiltroCpe)
                .build();

        Response response = comprobanteRestService.descargaComprobante(numRucHeader, numRuc, codCpe, numSerie, numCpe, codFiltroCpe, codTipDes);

        assertEquals(200, response.getStatus());
    }
    
}