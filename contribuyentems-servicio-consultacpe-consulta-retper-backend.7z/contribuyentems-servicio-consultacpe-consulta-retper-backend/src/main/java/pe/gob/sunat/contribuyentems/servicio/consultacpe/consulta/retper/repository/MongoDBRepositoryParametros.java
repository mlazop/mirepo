package pe.gob.sunat.contribuyentems.servicio.consultacpe.consulta.retper.repository;

import java.util.List;

import org.bson.conversions.Bson;

import com.mongodb.client.MongoCollection;
import com.mongodb.client.model.UpdateOptions;

import pe.gob.sunat.tecnologia.arquitectura.framework.mongodb.client.MongoDBClient;

public class MongoDBRepositoryParametros{

    private static final String DS_LECTURA = "dcbdrheparametros";
    private static final String DS_ESCRITURA = "dcbdrheparametros";

    /*
    public <T> MongoCollection<T> getCollection(String colname, Class<T> t) {

        MongoCollection<T> collection = MongoDBClient.getCollection(DS_LECTURA, colname, t);
        return collection;
    }

    */
    public <T> MongoCollection<T> insertCollection(String colname, Class<T> t, List<T> l) {

        MongoCollection<T> collection = MongoDBClient.getCollection(DS_ESCRITURA, colname, t);
        collection.insertMany(l);

        collection = MongoDBClient.getCollection(DS_ESCRITURA, colname, t);
        return collection;
    }

    public <T> T findOne(String collectionName, Class<T> className) throws Exception {
        return MongoDBClient.getCollection(DS_LECTURA, collectionName, className).find().first();
    }

    public <T> T findOne(String collectionName, Class<T> className, Bson objFilter) throws Exception {

        return MongoDBClient.getCollection(DS_LECTURA, collectionName, className).find(objFilter).first();
    }

    public <T> void updateOne(String collectionName,Bson filter, Bson query, Class<T> className){
        MongoCollection<T> tcCollection = MongoDBClient.getCollection(DS_ESCRITURA, collectionName,className);
        tcCollection.updateOne(filter, query);
    }

    public <T> void updateOneOption(String collectionName, Bson filter, Bson query, UpdateOptions options,
                                    Class<T> className) {
        MongoCollection<T> tcCollection = MongoDBClient.getCollection(DS_ESCRITURA, collectionName, className);
        tcCollection.updateOne(filter, query, options);
    }

}

