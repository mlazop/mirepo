package pe.gob.sunat.contribuyentems.servicio.consultacpe.consulta.retper.ws.dto;

public class ComprobanteIndividualRequestDTO {
    private String codCpe;
    private String numRucEmisor;
    private String numRucHeader;
    private Long numCpe;
    private String numSerieCpe;
    private String codFiltroCpe;



    public ComprobanteIndividualRequestDTO( String numRucHeader, String numRucEmisor,String codCpe,String numSerieCpe, Long numCpe, String codFiltroCpe) {
        this.codCpe = codCpe;
        this.numRucEmisor = numRucEmisor;
        this.numRucHeader = numRucHeader;
        this.numCpe = numCpe;
        this.numSerieCpe = numSerieCpe;
        this.codFiltroCpe = codFiltroCpe;
    }

    public String getNumRucHeader() {
        return numRucHeader;
    }

    public void setNumRucHeader(String numRucHeader) {
        this.numRucHeader = numRucHeader;
    }

    public String getCodCpe() {
        return codCpe;
    }

    public void setCodCpe(String codCpe) {
        this.codCpe = codCpe;
    }

    public String getNumRucEmisor() {
        return numRucEmisor;
    }

    public void setNumRucEmisor(String numRucEmisor) {
        this.numRucEmisor = numRucEmisor;
    }

    public Long getNumCpe() {
        return numCpe;
    }

    public void setNumCpe(Long numCpe) {
        this.numCpe = numCpe;
    }

    public String getNumSerieCpe() {
        return numSerieCpe;
    }

    public void setNumSerieCpe(String numSerieCpe) {
        this.numSerieCpe = numSerieCpe;
    }

    public String getCodFiltroCpe() {
        return codFiltroCpe;
    }

    public void setCodFiltroCpe(String codFiltroCpe) {
        this.codFiltroCpe = codFiltroCpe;
    }

    public static class Builder {

        private String numRucHeader;

        private String numRuc;

        private String codCpe;

        private String numSerie;

        private Long numCpe;
        private String codFiltroCpe;

        public Builder setNumRucHeader(String numRucHeader) {
            this.numRucHeader = numRucHeader;
            return this;
        }


        public Builder setNumRuc(String numRuc) {
            this.numRuc = numRuc;
            return this;
        }

        public Builder setCodCpe(String codCpe) {
            this.codCpe = codCpe;
            return this;
        }

        public Builder setNumSerie(String numSerie) {
            this.numSerie = numSerie;
            return this;
        }

        public Builder setNumCpe(Long numCpe) {
            this.numCpe = numCpe;
            return this;
        }
        public Builder setCodFiltroCpe(String codFiltroCpe) {
            this.codFiltroCpe = codFiltroCpe;
            return this;
        }
        public ComprobanteIndividualRequestDTO build() {
            return new ComprobanteIndividualRequestDTO(numRucHeader,numRuc, codCpe, numSerie, numCpe,codFiltroCpe);
        }
    }
}
