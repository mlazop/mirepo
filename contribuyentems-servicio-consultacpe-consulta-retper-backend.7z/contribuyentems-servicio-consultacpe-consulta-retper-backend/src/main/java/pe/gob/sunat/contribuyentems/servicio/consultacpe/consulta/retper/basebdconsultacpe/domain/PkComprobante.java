package pe.gob.sunat.contribuyentems.servicio.consultacpe.consulta.retper.basebdconsultacpe.domain;

import java.io.Serializable;

public class PkComprobante implements Serializable{

	private static final long serialVersionUID = -160421403350223098L;
	
	private String numRuc;
	private String codCpe;
	private String numSerieCpe;
	private Integer numCpe;
	
	public PkComprobante () {
		
	}
	
	public PkComprobante (String numRuc, String codCpe, String numSerieCpe, Integer numCpe) {
		this.numRuc = numRuc;
		this.codCpe = codCpe;
		this.numSerieCpe = numSerieCpe;
		this.numCpe = numCpe;
	}
	
	public String getNumRuc() {
		return numRuc;
	}
	public String getCodCpe() {
		return codCpe;
	}
	public String getNumSerieCpe() {
		return numSerieCpe;
	}
	public Integer getNumCpe() {
		return numCpe;
	}

	public void setNumRuc(String numRuc) {
		this.numRuc = numRuc;
	}

	public void setCodCpe(String codCpe) {
		this.codCpe = codCpe;
	}

	public void setNumSerieCpe(String numSerieCpe) {
		this.numSerieCpe = numSerieCpe;
	}

	public void setNumCpe(Integer numCpe) {
		this.numCpe = numCpe;
	}
	
	
	

}
