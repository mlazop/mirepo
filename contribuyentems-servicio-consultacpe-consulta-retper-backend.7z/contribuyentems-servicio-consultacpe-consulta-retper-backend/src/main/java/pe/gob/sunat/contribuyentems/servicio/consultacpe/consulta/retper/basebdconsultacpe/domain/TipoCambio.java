package pe.gob.sunat.contribuyentems.servicio.consultacpe.consulta.retper.basebdconsultacpe.domain;

import java.io.Serializable;

public class TipoCambio implements Serializable{
	
	private static final long serialVersionUID = -3665492471055633216L;
	
	private String codMonedaReferencia;
	private String codMonedaObjetivo;
	private double montoTipoCambio;
	private String fechaCambio;
	
	public String getCodMonedaReferencia() {
		return codMonedaReferencia;
	}
	public void setCodMonedaReferencia(String codMonedaReferencia) {
		this.codMonedaReferencia = codMonedaReferencia;
	}
	public String getCodMonedaObjetivo() {
		return codMonedaObjetivo;
	}
	public void setCodMonedaObjetivo(String codMonedaObjetivo) {
		this.codMonedaObjetivo = codMonedaObjetivo;
	}
	public double getMontoTipoCambio() {
		return montoTipoCambio;
	}
	public void setMontoTipoCambio(double montoTipoCambio) {
		this.montoTipoCambio = montoTipoCambio;
	}
	public String getFechaCambio() {
		return fechaCambio;
	}
	public void setFechaCambio(String fechaCambio) {
		this.fechaCambio = fechaCambio;
	}
	
	
}
