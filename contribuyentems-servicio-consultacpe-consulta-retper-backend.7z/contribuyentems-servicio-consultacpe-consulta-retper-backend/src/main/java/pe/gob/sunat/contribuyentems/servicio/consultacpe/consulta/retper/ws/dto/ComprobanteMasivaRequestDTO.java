package pe.gob.sunat.contribuyentems.servicio.consultacpe.consulta.retper.ws.dto;

import java.util.Date;

public class ComprobanteMasivaRequestDTO {
    private String codCpe;
    private String numRucEmisor;
    private String numRucHeader;
    private String numSerieCpe;
    private String codFiltroCpe;
    private int numCpeIni;
    private int numCpeFin;
    private String codEstado;
    private String codDocIde;
    private String numDocIde;
    private String  fecEmisionIni;
    private String fecEmisionFin;

    public String getCodCpe() {
        return codCpe;
    }

    public void setCodCpe(String codCpe) {
        this.codCpe = codCpe;
    }

    public String getNumRucEmisor() {
        return numRucEmisor;
    }

    public void setNumRucEmisor(String numRucEmisor) {
        this.numRucEmisor = numRucEmisor;
    }

    public String getNumRucHeader() {
        return numRucHeader;
    }

    public void setNumRucHeader(String numRucHeader) {
        this.numRucHeader = numRucHeader;
    }

    public String getNumSerieCpe() {
        return numSerieCpe;
    }

    public void setNumSerieCpe(String numSerieCpe) {
        this.numSerieCpe = numSerieCpe;
    }

    public String getCodFiltroCpe() {
        return codFiltroCpe;
    }

    public void setCodFiltroCpe(String codFiltroCpe) {
        this.codFiltroCpe = codFiltroCpe;
    }

    public int getNumCpeIni() {
        return numCpeIni;
    }

    public void setNumCpeIni(int numCpeIni) {
        this.numCpeIni = numCpeIni;
    }

    public int getNumCpeFin() {
        return numCpeFin;
    }

    public void setNumCpeFin(int numCpeFin) {
        this.numCpeFin = numCpeFin;
    }

    public String getCodEstado() {
        return codEstado;
    }

    public void setCodEstado(String codEstado) {
        this.codEstado = codEstado;
    }

    public String getCodDocIde() {
        return codDocIde;
    }

    public void setCodDocIde(String codDocIde) {
        this.codDocIde = codDocIde;
    }

    public String getNumDocIde() {
        return numDocIde;
    }

    public void setNumDocIde(String numDocIde) {
        this.numDocIde = numDocIde;
    }

    public String getFecEmisionIni() {
        return fecEmisionIni;
    }

    public void setFecEmisionIni(String fecEmisionIni) {
        this.fecEmisionIni = fecEmisionIni;
    }

    public String getFecEmisionFin() {
        return fecEmisionFin;
    }

    public void setFecEmisionFin(String fecEmisionFin) {
        this.fecEmisionFin = fecEmisionFin;
    }

    public ComprobanteMasivaRequestDTO(String codCpe, String numRucEmisor, String numRucHeader, String numSerieCpe, String codFiltroCpe, int numCpeIni, int numCpeFin, String codEstado, String codDocIde, String numDocIde, String fecEmisionIni, String fecEmisionFin) {
        this.codCpe = codCpe;
        this.numRucEmisor = numRucEmisor;
        this.numRucHeader = numRucHeader;
        this.numSerieCpe = numSerieCpe;
        this.codFiltroCpe = codFiltroCpe;
        this.numCpeIni = numCpeIni;
        this.numCpeFin = numCpeFin;
        this.codEstado = codEstado;
        this.codDocIde = codDocIde;
        this.numDocIde = numDocIde;
        this.fecEmisionIni = fecEmisionIni;
        this.fecEmisionFin = fecEmisionFin;
    }

    public static class Builder {

        private String codCpe;
        private String numRucEmisor;
        private String numRucHeader;
        private String numSerieCpe;
        private String codFiltroCpe;
        private int numCpeIni;
        private int numCpeFin;
        private String codEstado;
        private String codDocIde;
        private String numDocIde;
        private String fecEmisionIni;
        private String fecEmisionFin;

        public Builder setCodCpe(String codCpe) {
            this.codCpe = codCpe;
            return this;
        }

        public Builder setNumRucEmisor(String numRucEmisor) {
            this.numRucEmisor = numRucEmisor;
            return this;
        }

        public Builder setNumRucHeader(String numRucHeader) {
            this.numRucHeader = numRucHeader;
            return this;
        }

        public Builder setNumSerieCpe(String numSerieCpe) {
            this.numSerieCpe = numSerieCpe;
            return this;
        }

        public Builder setCodFiltroCpe(String codFiltroCpe) {
            this.codFiltroCpe = codFiltroCpe;
            return this;
        }

        public Builder setNumCpeIni(int numCpeIni) {
            this.numCpeIni = numCpeIni;
            return this;
        }

        public Builder setNumCpeFin(int numCpeFin) {
            this.numCpeFin = numCpeFin;
            return this;
        }

        public Builder setCodEstado(String codEstado) {
            this.codEstado = codEstado;
            return this;
        }

        public Builder setCodDocIde(String codDocIde) {
            this.codDocIde = codDocIde;
            return this;
        }

        public Builder setNumDocIde(String numDocIde) {
            this.numDocIde = numDocIde;
            return this;
        }

        public Builder setFecEmisionIni(String fecEmisionIni) {
            this.fecEmisionIni = fecEmisionIni;
            return this;
        }

        public Builder setFecEmisionFin(String fecEmisionFin) {
            this.fecEmisionFin = fecEmisionFin;
            return this;
        }

        public ComprobanteMasivaRequestDTO build() {
            return new ComprobanteMasivaRequestDTO(codCpe,numRucEmisor, numRucHeader,numSerieCpe,codFiltroCpe, numCpeIni, numCpeFin, codEstado,  codDocIde,  numDocIde,fecEmisionIni, fecEmisionFin);
        }
    }
}
