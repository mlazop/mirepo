package pe.gob.sunat.contribuyentems.servicio.consultacpe.consulta.retper.basebdparametros.domain;

import com.fasterxml.jackson.databind.annotation.JsonSerialize;
import com.fasterxml.jackson.databind.ser.std.ToStringSerializer;
import org.bson.codecs.pojo.annotations.BsonId;
import org.bson.types.ObjectId;

import java.io.Serializable;

public class Contribuyentes implements Serializable{

	private static final long serialVersionUID = 1L;

	@BsonId
	@JsonSerialize(using = ToStringSerializer.class)
	private ObjectId id;
	private String numRuc;
	private String codLlttt;
	private Integer numSecuencia;
	private String desNombre;
	private String numRegistros;
	private String codTipEmp;
	private String codTamanio;
	private UbigeoContribuyente ubigeo;
	private Direccion direccion;
	
	public ObjectId getId() {
		return id;
	}
	public void setId(ObjectId id) {
		this.id = id;
	}
	public String getNumRuc() {
		return numRuc;
	}
	public void setNumRuc(String numRuc) {
		this.numRuc = numRuc;
	}
	public String getCodLlttt() {
		return codLlttt;
	}
	public void setCodLlttt(String codLlttt) {
		this.codLlttt = codLlttt;
	}
	public Integer getNumSecuencia() {
		return numSecuencia;
	}
	public void setNumSecuencia(Integer numSecuencia) {
		this.numSecuencia = numSecuencia;
	}
	public String getDesNombre() {
		return desNombre;
	}
	public void setDesNombre(String desNombre) {
		this.desNombre = desNombre;
	}
	public String getNumRegistros() {
		return numRegistros;
	}
	public void setNumRegistros(String numRegistros) {
		this.numRegistros = numRegistros;
	}
	public String getCodTipEmp() {
		return codTipEmp;
	}
	public void setCodTipEmp(String codTipEmp) {
		this.codTipEmp = codTipEmp;
	}
	public String getCodTamanio() {
		return codTamanio;
	}
	public void setCodTamanio(String codTamanio) {
		this.codTamanio = codTamanio;
	}
	public UbigeoContribuyente getUbigeo() {
		return ubigeo;
	}
	public void setUbigeo(UbigeoContribuyente ubigeo) {
		this.ubigeo = ubigeo;
	}
	public Direccion getDireccion() {
		return direccion;
	}
	public void setDireccion(Direccion direccion) {
		this.direccion = direccion;
	}
	
}
