package pe.gob.sunat.contribuyentems.servicio.consultacpe.consulta.retper.util;

import java.text.Format;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;

public class Utils {
	
    public String formatFecha(Date date) {
    	Format formatter = new SimpleDateFormat("dd/MM/yyyy");
    	
    	return formatter.format(date);
    }
    
    public static String descSimboloMoneda(String codMoneda) {   	
        HashMap<String, String> tipoSimboloMoneda = new HashMap<>();
        tipoSimboloMoneda.put("PEN","S/");
        tipoSimboloMoneda.put("USD","$");
        tipoSimboloMoneda.put("CAD","C$");
        tipoSimboloMoneda.put("GBP","£");
        tipoSimboloMoneda.put("JPY","¥");
        tipoSimboloMoneda.put("SEK","Kr");
        tipoSimboloMoneda.put("CHF","Fr");
        tipoSimboloMoneda.put("EUR","€");
    	return tipoSimboloMoneda.get(codMoneda);
    }
    
    public static String descCodDoc(String codDoc) {   	
        HashMap<String, String> tipoDoc = new HashMap<>();
        tipoDoc.put("0","Doc. Trib. no Domiciliados sin RUC");
        tipoDoc.put("1","DNI");
        tipoDoc.put("4","Carné de Extranjería");
        tipoDoc.put("6","RUC");
        tipoDoc.put("06","RUC");
        tipoDoc.put("6 ","RUC");
        tipoDoc.put("7","Pasaporte");
        tipoDoc.put("A","Cédula Diplomática de identidad");
        tipoDoc.put("B","Doc. Ident. del país de residencia no domiciliados");
        tipoDoc.put("C","Tax Identification Number");
        tipoDoc.put("D","Identification Number");
        tipoDoc.put("E","Tarjeta Andina de Migraci�n");
        tipoDoc.put("F","Permiso Temporal de Permanencia");
        tipoDoc.put("G","Salvoconducto");
        tipoDoc.put("H","Carné Permiso Temp.Perman");
    	return tipoDoc.get(codDoc);
    }
    
	


        

}
