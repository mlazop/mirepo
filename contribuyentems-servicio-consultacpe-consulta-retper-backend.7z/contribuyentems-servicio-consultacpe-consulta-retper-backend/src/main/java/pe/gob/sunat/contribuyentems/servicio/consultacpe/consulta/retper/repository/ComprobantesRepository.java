package pe.gob.sunat.contribuyentems.servicio.consultacpe.consulta.retper.repository;

import pe.gob.sunat.contribuyentems.servicio.consultacpe.consulta.retper.basebdcpe.PercepcionXML;
import pe.gob.sunat.contribuyentems.servicio.consultacpe.consulta.retper.domain.Comprobantes;
import pe.gob.sunat.contribuyentems.servicio.consultacpe.consulta.retper.util.exceptions.UnprocessableEntityException;
import pe.gob.sunat.contribuyentems.servicio.consultacpe.consulta.retper.ws.dto.ComprobanteIndividualRequestDTO;
import pe.gob.sunat.contribuyentems.servicio.consultacpe.consulta.retper.ws.dto.ComprobanteMasivaRequestDTO;

import java.io.File;
import java.text.ParseException;
import java.util.Date;
import java.util.List;

public interface ComprobantesRepository {

    List<Comprobantes> obtenerComprobanteIndividual(ComprobanteIndividualRequestDTO request) throws ParseException;
    
    List<Comprobantes> obtenerComprobanteMasiva(ComprobanteMasivaRequestDTO request) throws ParseException, UnprocessableEntityException;
    
    File recuperaComprobanteService(String numRuc, String numCpe, String codCpe, String numSerieCpe, String codTipDes, String codFiltro, String rucHeader) throws UnprocessableEntityException;
    
    Date obtenerFechaEmision(ComprobanteIndividualRequestDTO request) throws ParseException;
}
