package pe.gob.sunat.contribuyentems.servicio.consultacpe.consulta.retper.basebdparametros.domain;

import java.io.Serializable;

public class Direccion implements Serializable {

	private static final long serialVersionUID = 1L;

	private String codCiiu2;
	private String codCiiu3;
	private String numKilom;
	private String numManza;
	private String numDepar;
	private String numLote;
	private String indConleg;
	private String indProind;
	private String codCorreo1;
	private String codCorreo2;
	private String codPaicap;
	private String codPaiori;
	private String desParreg;
	private String indNotifi;
	private String desRefnot;
	public String getCodCiiu2() {
		return codCiiu2;
	}
	public void setCodCiiu2(String codCiiu2) {
		this.codCiiu2 = codCiiu2;
	}
	public String getCodCiiu3() {
		return codCiiu3;
	}
	public void setCodCiiu3(String codCiiu3) {
		this.codCiiu3 = codCiiu3;
	}
	public String getNumKilom() {
		return numKilom;
	}
	public void setNumKilom(String numKilom) {
		this.numKilom = numKilom;
	}
	public String getNumDepar() {
		return numDepar;
	}
	public void setNumDepar(String numDepar) {
		this.numDepar = numDepar;
	}
	public String getNumLote() {
		return numLote;
	}
	public void setNumLote(String numLote) {
		this.numLote = numLote;
	}
	public String getIndConleg() {
		return indConleg;
	}
	public void setIndConleg(String indConleg) {
		this.indConleg = indConleg;
	}
	public String getIndProind() {
		return indProind;
	}
	public void setIndProind(String indProind) {
		this.indProind = indProind;
	}
	public String getCodCorreo1() {
		return codCorreo1;
	}
	public void setCodCorreo1(String codCorreo1) {
		this.codCorreo1 = codCorreo1;
	}
	public String getCodCorreo2() {
		return codCorreo2;
	}
	public void setCodCorreo2(String codCorreo2) {
		this.codCorreo2 = codCorreo2;
	}
	public String getCodPaicap() {
		return codPaicap;
	}
	public void setCodPaicap(String codPaicap) {
		this.codPaicap = codPaicap;
	}
	public String getCodPaiori() {
		return codPaiori;
	}
	public void setCodPaiori(String codPaiori) {
		this.codPaiori = codPaiori;
	}
	public String getDesParreg() {
		return desParreg;
	}
	public void setDesParreg(String desParreg) {
		this.desParreg = desParreg;
	}
	public String getIndNotifi() {
		return indNotifi;
	}
	public void setIndNotifi(String indNotifi) {
		this.indNotifi = indNotifi;
	}
	public String getDesRefnot() {
		return desRefnot;
	}
	public void setDesRefnot(String desRefnot) {
		this.desRefnot = desRefnot;
	}
	public String getNumManza() {
		return numManza;
	}
	public void setNumManza(String numManza) {
		this.numManza = numManza;
	}

}
