package pe.gob.sunat.contribuyentems.servicio.consultacpe.consulta.retper.basebdconsultacpe.domain.dao.repository.impl;

import com.mongodb.client.MongoCollection;
import com.mongodb.client.model.Filters;
import pe.gob.sunat.contribuyentems.servicio.consultacpe.consulta.retper.basebdconsultacpe.domain.GrandesContribuyentes;
import pe.gob.sunat.contribuyentems.servicio.consultacpe.consulta.retper.basebdconsultacpe.domain.dao.repository.GranContribuyenteRepository;
import pe.gob.sunat.contribuyentems.servicio.consultacpe.consulta.retper.repository.MongoDBRepository;
import pe.gob.sunat.contribuyentems.servicio.consultacpe.consulta.retper.util.Constantes;
import pe.gob.sunat.tecnologia.arquitectura.framework.mongodb.client.MongoDBClient;

import java.util.Optional;

public class GranContribuyenteRepositoryImpl extends MongoDBRepository implements GranContribuyenteRepository {
    @Override
    public boolean validarContribuyente(String numRuc, String codigoComprobante, String codigoTipoContribuyente) {

        MongoCollection<GrandesContribuyentes> collection = MongoDBClient.getCollection(DS_LECTURA,
                    Constantes.COLLECTION_NAME_GRAN_CONTRIBUYENTE, GrandesContribuyentes.class);

        Optional<GrandesContribuyentes> grandesContribuyentes= Optional.ofNullable(collection
                .find(Filters.and(Filters.eq("numRuc", numRuc), Filters.eq("codCpe", codigoComprobante), Filters.eq("codTipContrib", codigoTipoContribuyente))).first());
        if (grandesContribuyentes.isPresent()) {

            GrandesContribuyentes document = grandesContribuyentes.get();
            return document.getisIndEstad();
        } else {
            return false;

        }
    }
}
