package pe.gob.sunat.contribuyentems.servicio.consultacpe.consulta.retper.core;


import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import pe.gob.sunat.tecnologiams.arquitectura.framework.core.app.SunatApplication;
import pe.gob.sunat.tecnologiams.arquitectura.framework.core.config.MicroserviceConfig;

public abstract class ConsultaCpeBaseApplication<T extends MicroserviceConfig> extends SunatApplication<T> {
    private static final Logger LOGGER = LoggerFactory.getLogger(pe.gob.sunat.contribuyentems.servicio.consultacpe.consulta.retper.core.ConsultaCpeBaseApplication.class);

    public static final String CURRENT_PASE =  SunatApplication.class.getPackage().getSpecificationTitle();

    public void printVersion(){
        LOGGER.info("Version: {} Pase: {}", CURRENT_VERSION, CURRENT_PASE);
    }

}
