package pe.gob.sunat.contribuyentems.servicio.consultacpe.consulta.retper.basebdconsultacpe.domain;

import java.io.Serializable;

public class Ubigeo implements Serializable{

	private static final long serialVersionUID = -9213362808219008292L;
	
	private String codUbigeo;
	
	private String direccion;
	
	private String urbanizacion;
	
	private String provincia;
	
	private String departamento;
	
	private String distrito;
	
	private String codPais;

	public String getCodUbigeo() {
		return codUbigeo;
	}

	public void setCodUbigeo(String codUbigeo) {
		this.codUbigeo = codUbigeo;
	}

	public String getDireccion() {
		return direccion;
	}

	public void setDireccion(String direccion) {
		this.direccion = direccion;
	}

	public String getUrbanizacion() {
		return urbanizacion;
	}

	public void setUrbanizacion(String urbanizacion) {
		this.urbanizacion = urbanizacion;
	}

	public String getProvincia() {
		return provincia;
	}

	public void setProvincia(String provincia) {
		this.provincia = provincia;
	}

	public String getDepartamento() {
		return departamento;
	}

	public void setDepartamento(String departamento) {
		this.departamento = departamento;
	}

	public String getDistrito() {
		return distrito;
	}

	public void setDistrito(String distrito) {
		this.distrito = distrito;
	}

	public String getCodPais() {
		return codPais;
	}

	public void setCodPais(String codPais) {
		this.codPais = codPais;
	}
	
	

}
