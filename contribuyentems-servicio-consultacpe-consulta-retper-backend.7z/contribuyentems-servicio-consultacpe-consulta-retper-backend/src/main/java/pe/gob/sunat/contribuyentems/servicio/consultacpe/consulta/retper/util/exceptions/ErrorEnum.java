package pe.gob.sunat.contribuyentems.servicio.consultacpe.consulta.retper.util.exceptions;

import org.apache.commons.lang3.StringUtils;

public enum ErrorEnum {

	ERROR_100(100, "N\u00FAmero de RUC Logueado no enviado o  o es vac\u00EDo"),
	ERROR_101(101, "Solo se permite dato num\u00E9rico de 11 d\u00EDgitos para el n\u00FAmero de RUC"),
	ERROR_102(102, "N\u00FAmero de RUC del emisor no enviado o es vacío"),
	ERROR_104(104, "El RUC del emisor debe ser diferente  al RUC logueado"),
	ERROR_105(105, "El RUC del emisor debe ser igual  al RUC logueado."),
	ERROR_106(106, "C\u00F3digo de comprobante no enviado o es vac\u00EDo."),
	ERROR_107(107, "C\u00F3digo de comprobante no permitido o no valido"),
	ERROR_108(108, "N\u00FAmero de serie del comprobante no enviado o es vac\u00EDo."),
	ERROR_109(109, "N\u00FAmero de serie del comprobante no permitido  o es vac\u00EDo."),
	ERROR_110(110, "N\u00FAmero de serie del comprobante no enviado o es vac\u00EDo."),

	ERROR_111(111, "N\u00FAmero  de comprobante tiene tipo de dato o formato no valido. Solo se permite dato num\u00E9rico de 1 hasta 8 dígitos."),
	ERROR_112(112, "La fecha de emisi\u00F3n del comprobante es mayor a 24 meses, se debe generar un n\u00FAmero de pedido."),
	ERROR_113(113, "No hay resultados para la consulta realizada. ."),
	ERROR_114(114, "El campo numCpe debe estar vac\u00EDo ."),
	ERROR_115(115, "Serie del comprobante no enviado o es vac\u00EDo"),
	ERROR_116(116, "El campo numSerieCpe debe estar vac\u00EDo"),
	ERROR_117(117, "N\u00FAmero  del comprobante Inicio no enviado o es vac\u00EDo."),
	ERROR_118(118, "N\u00FAmero  de comprobante inicio tiene tipo de dato o formato no valido. Solo se permite dato numérico de 1 hasta 8 d\u00EDgitos."),
	ERROR_119(119, "N\u00FAmero  del comprobante fin no enviado o es vac\u00EDo."),
	ERROR_120(120, "N\u00FAmero  de comprobante fin tiene tipo de dato o formato no valido. Solo se permite dato numérico de 1 hasta 8 d\u00EDgitos"),
	ERROR_121(121, "El campo numCpeFin debe estar vac\u00EDo"),
	ERROR_123(123, " El n\u00FAmero de comprobante inicio debe ser menor o igual al n\u00FAmero de comprobante fin"),
	ERROR_124(124, " La diferencia entre el rango máximo de n\u00FAmero de comprobante inicio y n\u00FAmero de comprobante fin debe ser de 1500."),
	ERROR_126(126, "El campo numCpe2 debe estar vacío"),
	ERROR_127(127, "C\u00F3digo del estado del comprobante  no enviado o vac\u00EDo"),
	ERROR_128(128, "C\u00F3digo del estado del comprobante no permitido o no valido."),

	ERROR_129(129, "C\u00F3digo del estado del comprobante  no enviado o es vac\u00EDo"),
	ERROR_130(130, " El campo codEstado debe estar vac\u00EDo.."),
	ERROR_131(131, "C\u00F3digo del estado del comprobante  no enviado o es vac\u00EDo."),
	ERROR_132(132, "numTipDocRecep del comprobante  no enviado o es vac\u00EDo.."),
	ERROR_133(133, "El n\u00FAmero de documento del receptor debe ser de 8 d\u00EDgitos"),
	ERROR_134(134, "El n\u00FAmero de documento del receptor debe ser de 11 d\u00EDgitos."),
	ERROR_135(135, "El n\u00FAmero  de documento no debe superar los 30 d\u00EDgitos."),
	ERROR_136(136, "El campo docIdeRecep debe estar vac\u00EDo."),
	ERROR_137(137, "La fecha de emisi\u00F3n de emisi\u00F3n inicio no enviado o es vac\u00EDo."),
	ERROR_138(138, "El formato de fechas es incorrecto."),
	ERROR_139(139, "El campo fecEmisionInicio debe estar vac\u00EDo."),
	ERROR_140(140, "El rango m\u00E1ximo de búsqueda es de 1 día."),
	ERROR_141(141, "El formato de fechas es incorrecto."),
	ERROR_142(142, "El rango m\u00E1ximo de b\u00FAsqueda es de 30 d\u00EDas."),
	ERROR_143(143, "La fecha de inicio debe ser menor o igual a la fecha fin."),
	ERROR_144(144, "El campo fecha de emisi\u00F3n inicio debe estar vac\u00EDo, el contribuyente es gran emisor."),
	ERROR_145(145, "El rango de fechas de emisi\u00F3n del comprobante es mayor a <6> meses, se debe generar un numero de pedido."),
	ERROR_146(146, "No hay comprobantes para el filtro enviado."),
	ERROR_147(147, " El campo fecEmision debe estar vac\u00EDo."),
	
	ERROR_148(148, "C\u00F3digo de filtro no enviado o no valido."),
	ERROR_149(149, "C\u00F3digo de filtro no permitido."),
	ERROR_150(150, "No se puede obtener CDR en CPE procedencia de Portal"),
	ERROR_230(230, "Se debe enviar ambas fechas inicio y fin."),

	ERROR_GENERICO(999, "Mensaje de error generico");

	private ErrorEnum(int code, String msg) {
		this.code = code;
		this.msg = msg;
	}

	private int code;
	private String msg;

	public int getCode() {
		return code;
	}

	public String getMsg() {
		return msg;
	}

	public static String getMsg(int code) {
		String msg = StringUtils.EMPTY;

		for (ErrorEnum enumValue : ErrorEnum.values()) {
			if (enumValue.code == code) {
				msg = enumValue.msg;
				break;
			}
		}

		return msg;
	}
}
