package pe.gob.sunat.contribuyentems.servicio.consultacpe.consulta.retper.basebdconsultacpe.domain;

import java.io.Serializable;
import java.util.Date;
import java.util.List;

import com.fasterxml.jackson.annotation.JsonFormat;

import pe.gob.sunat.contribuyentems.servicio.consultacpe.consulta.retper.util.Constantes;

public class Retencion implements Serializable {

	private static final long serialVersionUID = 1577456876627633730L;

	// datos de retencion
	private PkComprobante pkRetencion;
	private Contribuyente emisor;
	private Contribuyente receptor;
	@JsonFormat(shape = JsonFormat.Shape.STRING, pattern = Constantes.DATE_FORMAT)
	private Date fechaEmision;
	private String codRegimenRet;
	private String desRegimenRet;
	private double porcentajeRet;
	private String descObservacion;
	private double montoTotalRetenido;
	private String codMonedaMontoTotalRetenido;
	private double montoTotalPagado;
	private String codMonedaMontoTotalPagado;
	private String codEstadoCre;
	private String indProcedencia;
	private String indCompFisico;
	private String codCorreoRecep;
	private String codMotivoContin;
	// datos complementarios
	private String usuario;
	private long ticket;
	// hquispeon - Agregar revertido
	private String numPeriodo;
	private double montoBaseCalculo;
	private String indReemplazoReversion;
	// documentos relacionados
	private List<DocRelacionadoRet> lstDocRel;

	public PkComprobante getPkRetencion() {
		return pkRetencion;
	}

	public void setPkRetencion(PkComprobante pkRetencion) {
		this.pkRetencion = pkRetencion;
	}

	public Contribuyente getEmisor() {
		return emisor;
	}

	public void setEmisor(Contribuyente emisor) {
		this.emisor = emisor;
	}

	public Contribuyente getReceptor() {
		return receptor;
	}

	public void setReceptor(Contribuyente receptor) {
		this.receptor = receptor;
	}

	public Date getFechaEmision() {
		return fechaEmision;
	}

	public void setFechaEmision(Date fechaEmision) {
		this.fechaEmision = fechaEmision;
	}

	public String getCodRegimenRet() {
		return codRegimenRet;
	}

	public void setCodRegimenRet(String codRegimenRet) {
		this.codRegimenRet = codRegimenRet;
	}

	public String getDesRegimenRet() {
		return desRegimenRet;
	}

	public void setDesRegimenRet(String desRegimenRet) {
		this.desRegimenRet = desRegimenRet;
	}

	public double getPorcentajeRet() {
		return porcentajeRet;
	}

	public void setPorcentajeRet(double porcentajeRet) {
		this.porcentajeRet = porcentajeRet;
	}

	public String getDescObservacion() {
		return descObservacion;
	}

	public void setDescObservacion(String descObservacion) {
		this.descObservacion = descObservacion;
	}

	public double getMontoTotalRetenido() {
		return montoTotalRetenido;
	}

	public void setMontoTotalRetenido(double montoTotalRetenido) {
		this.montoTotalRetenido = montoTotalRetenido;
	}

	public String getCodMonedaMontoTotalRetenido() {
		return codMonedaMontoTotalRetenido;
	}

	public void setCodMonedaMontoTotalRetenido(
			String codMonedaMontoTotalRetenido) {
		this.codMonedaMontoTotalRetenido = codMonedaMontoTotalRetenido;
	}

	public double getMontoTotalPagado() {
		return montoTotalPagado;
	}

	public void setMontoTotalPagado(double montoTotalPagado) {
		this.montoTotalPagado = montoTotalPagado;
	}

	public String getCodMonedaMontoTotalPagado() {
		return codMonedaMontoTotalPagado;
	}

	public void setCodMonedaMontoTotalPagado(String codMonedaMontoTotalPagado) {
		this.codMonedaMontoTotalPagado = codMonedaMontoTotalPagado;
	}

	public String getCodEstadoCre() {
		return codEstadoCre;
	}

	public void setCodEstadoCre(String codEstadoCre) {
		this.codEstadoCre = codEstadoCre;
	}

	public String getIndProcedencia() {
		return indProcedencia;
	}

	public void setIndProcedencia(String indProcedencia) {
		this.indProcedencia = indProcedencia;
	}

	public String getIndCompFisico() {
		return indCompFisico;
	}

	public void setIndCompFisico(String indCompFisico) {
		this.indCompFisico = indCompFisico;
	}

	public String getCodCorreoRecep() {
		return codCorreoRecep;
	}

	public void setCodCorreoRecep(String codCorreoRecep) {
		this.codCorreoRecep = codCorreoRecep;
	}

	public String getCodMotivoContin() {
		return codMotivoContin;
	}

	public void setCodMotivoContin(String codMotivoContin) {
		this.codMotivoContin = codMotivoContin;
	}

	public String getUsuario() {
		return usuario;
	}

	public void setUsuario(String usuario) {
		this.usuario = usuario;
	}

	public long getTicket() {
		return ticket;
	}

	public void setTicket(long ticket) {
		this.ticket = ticket;
	}

	public List<DocRelacionadoRet> getLstDocRel() {
		return lstDocRel;
	}

	public void setLstDocRel(List<DocRelacionadoRet> lstDocRel) {
		this.lstDocRel = lstDocRel;
	}

	public String getNumPeriodo() {
		return numPeriodo;
	}

	public void setNumPeriodo(String numPeriodo) {
		this.numPeriodo = numPeriodo;
	}

	public double getMontoBaseCalculo() {
		return montoBaseCalculo;
	}

	public void setMontoBaseCalculo(double montoBaseCalculo) {
		this.montoBaseCalculo = montoBaseCalculo;
	}

	public String getIndReemplazoReversion() {
		return indReemplazoReversion;
	}

	public void setIndReemplazoReversion(String indReemplazoReversion) {
		this.indReemplazoReversion = indReemplazoReversion;
	}

}
