package pe.gob.sunat.contribuyentems.servicio.consultacpe.consulta.retper.basebdcpe.dao;
import pe.gob.sunat.contribuyentems.servicio.consultacpe.consulta.retper.basebdcpe.ComprobantePK;
import pe.gob.sunat.contribuyentems.servicio.consultacpe.consulta.retper.basebdcpe.RetDocRel;
import pe.gob.sunat.contribuyentems.servicio.consultacpe.consulta.retper.basebdcpe.Retencion;
import pe.gob.sunat.contribuyentems.servicio.consultacpe.consulta.retper.basebdcpe.RetencionPK;
import pe.gob.sunat.tecnologiams.arquitectura.framework.jpa.dao.BaseDao;

import java.util.Date;
import java.util.List;

public interface RetencionRepository extends BaseDao<Retencion, RetencionPK> {
    public Date obtenerFechaEmision(ComprobantePK comprobantePK, String rucReceptor);
    
    public List<RetDocRel> obtenerDetalleRetencion(ComprobantePK comprobantePK);

    public Retencion obtenerComprobante(ComprobantePK comprobantePK, String rucReceptor);
    
    public List<Retencion> obtenerComprobantesxFiltro(
    		ComprobantePK comprobantePK,String fechaIni,String fechaFin,int NumIni,
    		int NumFin,String codIdDoc,String numIdDoc,String codEstado);

}
