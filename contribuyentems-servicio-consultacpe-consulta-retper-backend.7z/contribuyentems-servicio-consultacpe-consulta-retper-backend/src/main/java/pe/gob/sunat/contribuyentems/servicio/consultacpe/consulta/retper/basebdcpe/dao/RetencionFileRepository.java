package pe.gob.sunat.contribuyentems.servicio.consultacpe.consulta.retper.basebdcpe.dao;

import pe.gob.sunat.contribuyentems.servicio.consultacpe.consulta.retper.basebdcpe.RetencionXML;
import pe.gob.sunat.contribuyentems.servicio.consultacpe.consulta.retper.basebdcpe.RetencionXMLPK;
import pe.gob.sunat.tecnologiams.arquitectura.framework.jpa.dao.BaseDao;

public interface RetencionFileRepository extends BaseDao<RetencionXML, RetencionXMLPK>{
	
	public RetencionXML findComprobanteXmlService(RetencionXMLPK retencionXMLPK);
	

}
