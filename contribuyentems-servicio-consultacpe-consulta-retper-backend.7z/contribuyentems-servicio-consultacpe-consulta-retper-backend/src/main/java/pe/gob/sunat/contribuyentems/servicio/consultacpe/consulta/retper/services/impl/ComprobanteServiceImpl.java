package pe.gob.sunat.contribuyentems.servicio.consultacpe.consulta.retper.services.impl;


import pe.gob.sunat.contribuyentems.servicio.consultacpe.consulta.retper.basebdconsultacpe.domain.dao.repository.GranContribuyenteRepository;
import pe.gob.sunat.contribuyentems.servicio.consultacpe.consulta.retper.basebdparametros.domain.Contribuyentes;
import pe.gob.sunat.contribuyentems.servicio.consultacpe.consulta.retper.basebdparametros.domain.UbigeoContribuyente;
import pe.gob.sunat.contribuyentems.servicio.consultacpe.consulta.retper.basebdparametros.domain.dao.ContribuyenteRepository;
import pe.gob.sunat.contribuyentems.servicio.consultacpe.consulta.retper.domain.*;
import pe.gob.sunat.contribuyentems.servicio.consultacpe.consulta.retper.main.config.PropertiesBean;

import org.apache.commons.io.FileUtils;
import org.apache.commons.lang3.StringUtils;

import net.sf.jasperreports.engine.JasperFillManager;
import net.sf.jasperreports.engine.JasperPrint;
import pe.gob.sunat.contribuyentems.servicio.consultacpe.consulta.retper.repository.ComprobantesRepository;
import pe.gob.sunat.contribuyentems.servicio.consultacpe.consulta.retper.services.ComprobanteService;
import pe.gob.sunat.contribuyentems.servicio.consultacpe.consulta.retper.util.Constantes;
import pe.gob.sunat.contribuyentems.servicio.consultacpe.consulta.retper.util.ValidatorParams;
import pe.gob.sunat.contribuyentems.servicio.consultacpe.consulta.retper.util.exceptions.ErrorEnum;
import pe.gob.sunat.contribuyentems.servicio.consultacpe.consulta.retper.util.exceptions.ErrorMessage;
import pe.gob.sunat.contribuyentems.servicio.consultacpe.consulta.retper.util.exceptions.UnprocessableEntityException;
import pe.gob.sunat.contribuyentems.servicio.consultacpe.consulta.retper.ws.dto.ArchivoRequestDTO;
import pe.gob.sunat.contribuyentems.servicio.consultacpe.consulta.retper.ws.dto.ArchivoResponseDTO;
import pe.gob.sunat.contribuyentems.servicio.consultacpe.consulta.retper.ws.dto.ComprobanteIndividualRequestDTO;
import pe.gob.sunat.contribuyentems.servicio.consultacpe.consulta.retper.ws.dto.ComprobanteIndividualResponseDTO;
import pe.gob.sunat.contribuyentems.servicio.consultacpe.consulta.retper.ws.dto.ComprobanteMasivaRequestDTO;
import pe.gob.sunat.contribuyentems.servicio.consultacpe.consulta.retper.ws.dto.ComprobanteMasivaResponseDTO;
import pe.gob.sunat.contribuyentems.servicio.consultacpe.consulta.retper.ws.dto.ResumenDTO;
import pe.gob.sunat.tecnologiams.arquitectura.framework.common.util.ConstantesUtils;
import pe.gob.sunat.tecnologiams.arquitectura.framework.core.util.UtilLog;

import javax.inject.Inject;
import javax.servlet.http.HttpServletRequest;
import javax.ws.rs.core.StreamingOutput;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.stream.Collectors;
import java.util.zip.ZipEntry;
import java.util.zip.ZipOutputStream;

import net.sf.jasperreports.engine.JRException;
import net.sf.jasperreports.engine.JRExporterParameter;
import net.sf.jasperreports.engine.data.JRBeanCollectionDataSource;
import net.sf.jasperreports.engine.export.JRPdfExporter;
import pe.gob.sunat.contribuyentems.servicio.consultacpe.consulta.retper.basebdconsultacpe.domain.Contribuyente;
import pe.gob.sunat.contribuyentems.servicio.consultacpe.consulta.retper.basebdconsultacpe.domain.DocRelacionadoRet;
import pe.gob.sunat.contribuyentems.servicio.consultacpe.consulta.retper.basebdconsultacpe.domain.PkComprobante;
import pe.gob.sunat.contribuyentems.servicio.consultacpe.consulta.retper.basebdconsultacpe.domain.Retencion;
import pe.gob.sunat.contribuyentems.servicio.consultacpe.consulta.retper.basebdconsultacpe.domain.Ubigeo;
import pe.gob.sunat.contribuyentems.servicio.consultacpe.consulta.retper.basebdconsultacpe.domain.Percepcion;
import pe.gob.sunat.contribuyentems.servicio.consultacpe.consulta.retper.basebdconsultacpe.domain.DocRelacionadoPer;
import pe.gob.sunat.contribuyentems.servicio.consultacpe.consulta.retper.util.Utils;

public class ComprobanteServiceImpl implements ComprobanteService {
    @Inject
    private UtilLog utilLog;
    @Inject
    private ValidatorParams validatorParams;
    @Inject
    private ComprobantesRepository comprobantesRepository;
    @Inject
    private GranContribuyenteRepository granContribuyenteRepository;
    @Inject
    private ContribuyenteRepository contribuyenteRepository;
	@Inject
	private PropertiesBean properties;
    @Override
    public ComprobanteIndividualResponseDTO obtenerComprobanteIndividual(ComprobanteIndividualRequestDTO request)
            throws Exception {

        utilLog.imprimirLog(ConstantesUtils.LEVEL_DEBUG,
                "==== INICIO ---> ComprobanteService - metodo: obtenerComprobanteIndividual  1 =====");

        validatorParams.checkNumRuc(request.getNumRucHeader());
        validatorParams.checkNumRucEmisor(request.getNumRucEmisor(),request.getNumRucHeader(),request.getCodFiltroCpe());
        validatorParams.checkCodCpe(request.getCodCpe());
        validatorParams.checkNumeroSerieCpe(request.getNumSerieCpe(),request.getCodFiltroCpe());
        validatorParams.checkNumCpe(request.getCodCpe(),request.getNumSerieCpe(),request.getCodFiltroCpe());
        validatorParams.checkCodFiltroCpe(request.getCodFiltroCpe());
		Date fechaemision = comprobantesRepository.obtenerFechaEmision(request);
		if (Objects.nonNull(fechaemision)) {
			validatorParams.checkFechaEmisionIndividual(fechaemision, properties.getCntMesesIndividual());
		} else {
			throw new UnprocessableEntityException(new ErrorMessage(ErrorEnum.ERROR_113));
		}
        List<Comprobantes> listaComprobantes = comprobantesRepository.obtenerComprobanteIndividual(request);

        if (Objects.isNull(listaComprobantes) || listaComprobantes.size() == 0) {
            throw new UnprocessableEntityException(new ErrorMessage(ErrorEnum.ERROR_113));
        }
        utilLog.imprimirLog(ConstantesUtils.LEVEL_DEBUG,
                "==== INICIO ---> ComprobanteService - metodo: obtenerComprobanteIndividual  3 =====");

        ComprobanteIndividualResponseDTO response = new ComprobanteIndividualResponseDTO();
        response.setCntTotalReg(listaComprobantes.size());
        response.setNumeroPaginas(properties.getNumeroPaginas());
        response.setComprobantes(listaComprobantes);

        return  response;
            }
    
    @Override
    public ComprobanteMasivaResponseDTO obtenerComprobanteMasiva(ComprobanteMasivaRequestDTO request) throws Exception {
        validatorParams.checkNumRuc(request.getNumRucHeader());
        validatorParams.checkCodFiltroCpe(request.getCodFiltroCpe());
        if(request.getCodFiltroCpe().equals(Constantes.COD_CPE_EMISOR)){
            if (!Objects.isNull(request.getNumRucEmisor()) && !request.getNumRucEmisor().isEmpty()) {
                validatorParams.checkNumRucEmisor(request.getNumRucEmisor(), request.getNumRucHeader(), request.getCodFiltroCpe());
              }
            boolean granemisor = granContribuyenteRepository.validarContribuyente(request.getNumRucHeader(),
                    request.getCodCpe(), Constantes.COD_CPE_EMISOR);
            boolean granreceptor = granContribuyenteRepository.validarContribuyente(request.getNumRucHeader(),
                    request.getCodCpe(), Constantes.COD_CPE_RECEPTOR);
            validatorParams.checkCodCpe(request.getCodCpe());
            //validatorParams.checkNumeroSerieCpeMasiva(request.getNumSerieCpe(), request.getCodFiltroCpe(),granemisor);

            validatorParams.checkNumCpeIniMasiva(request.getNumCpeIni(), request.getCodFiltroCpe(),granemisor);
            validatorParams.checkNumCpeFinMasiva(request.getNumCpeFin(), request.getNumCpeIni(), request.getCodFiltroCpe(),granemisor,Integer.parseInt(properties.getParamLimitInformix()));

            if (!Objects.isNull(request.getCodEstado())) {
                validatorParams.checkCodEstado(request.getCodEstado());
            }
            if (!Objects.isNull(request.getCodDocIde())) {
                validatorParams.checkCodDocIdeRecep(request.getCodDocIde());

            }
            if (!Objects.isNull(request.getNumDocIde())) {
                validatorParams.checkNumDocIdeRecep(request.getNumDocIde());

            }


            validatorParams.checkFechaEmision(request.getFecEmisionIni(), request.getFecEmisionFin(), request.getCodFiltroCpe(),
                    granemisor, granreceptor);

            int meses=properties.getCntMesesMasiva();
            if(Objects.nonNull(request.getFecEmisionIni())){
                validatorParams.checkFechaEmisionMasiva(request.getFecEmisionIni(),meses);

            }


        }else if(request.getCodFiltroCpe().equals(Constantes.COD_CPE_RECEPTOR)) {
            if (!Objects.isNull(request.getNumRucEmisor()) && !request.getNumRucEmisor().isEmpty()) {
                validatorParams.checkNumRucEmisor(request.getNumRucEmisor(), request.getNumRucHeader(), request.getCodFiltroCpe());
            }
            validatorParams.checkCodEstado(request.getCodEstado());

            if (!Objects.isNull(request.getCodDocIde())) {
                validatorParams.checkCodDocIdeRecep(request.getCodDocIde());
            }
            if (!Objects.isNull(request.getNumDocIde())) {
                validatorParams.checkNumDocIdeRecep(request.getNumDocIde());
            }
            String numRucEmisor = request.getNumRucEmisor();

            boolean granemisor = granContribuyenteRepository.validarContribuyente(numRucEmisor,
                    request.getCodCpe(), Constantes.COD_CPE_EMISOR);
            boolean granreceptor = granContribuyenteRepository.validarContribuyente(numRucEmisor,
                    request.getCodCpe(), Constantes.COD_CPE_RECEPTOR);
            validatorParams.checkFechaEmision(request.getFecEmisionIni(), request.getFecEmisionFin(), request.getCodFiltroCpe(),
                    granemisor, granreceptor);
            int meses=properties.getCntMesesMasiva();
            if(Objects.nonNull(request.getFecEmisionIni())){
                validatorParams.checkFechaEmisionMasiva(request.getFecEmisionIni(),meses);

            }

        }


        validatorParams.checkCodFiltroCpe(request.getCodFiltroCpe());
        List<Comprobantes> comprobanteDTOList=new ArrayList<>();
        List<Comprobantes> listaComprobantes = comprobantesRepository.obtenerComprobanteMasiva(request);
        if (Objects.isNull(listaComprobantes) || listaComprobantes.size() == 0) {
            throw new UnprocessableEntityException(new ErrorMessage(ErrorEnum.ERROR_113));
        }else {
            for (Comprobantes comprobante : listaComprobantes) {
                comprobanteDTOList.add(comprobante);
            }
        }

        utilLog.imprimirLog(ConstantesUtils.LEVEL_DEBUG,
                "==== INICIO ---> ComprobanteService - metodo: obtenerComprobanteIndividual  3 =====");
        ComprobanteMasivaResponseDTO response = new ComprobanteMasivaResponseDTO();
        response.setCntTotalReg(listaComprobantes.size());
        response.setNumeroPaginas(properties.getNumeroPaginas());
        response.setComprobantes(comprobanteDTOList);
        response.setResumen(obtenerResumen(comprobanteDTOList));
        return response;
    }
    
    @Override
    public ArchivoResponseDTO descargarComprobante(ArchivoRequestDTO archivoRequestDTO, ComprobanteIndividualRequestDTO request) throws Exception {
        UnprocessableEntityException exception = new UnprocessableEntityException();

        validatorParams.checkNumRuc(archivoRequestDTO.getNumRucHeader());
        validatorParams.checkNumRucEmisor(archivoRequestDTO.getNumRucEmisor(),archivoRequestDTO.getNumRucHeader(),archivoRequestDTO.getCodFiltroCpe());
        validatorParams.checkCodCpe(archivoRequestDTO.getCodCpe());
        validatorParams.checkNumeroSerieCpe(archivoRequestDTO.getNumSerieCpe(),archivoRequestDTO.getCodFiltroCpe());
        validatorParams.checkNumCpe(archivoRequestDTO.getCodCpe(),archivoRequestDTO.getNumSerieCpe(),archivoRequestDTO.getCodFiltroCpe());
        validatorParams.checkCodTipDes(!Objects.isNull(archivoRequestDTO.getCodTipDes())? archivoRequestDTO.getCodTipDes():StringUtils.EMPTY );
        validatorParams.checkCodFiltroCpe(request.getCodFiltroCpe());
//		Date fechaemision = comprobantesRepository.obtenerFechaEmision(request);
//		if (Objects.nonNull(fechaemision)) {
//			validatorParams.checkFechaEmisionIndividual(fechaemision, properties.getCntMesesIndividual());
//		} else {
//			throw new UnprocessableEntityException(new ErrorMessage(ErrorEnum.ERROR_113));
//		}
        List<Comprobantes> listaComprobantes = comprobantesRepository.obtenerComprobanteIndividual(request);

        if (Objects.isNull(listaComprobantes) || listaComprobantes.size() == 0) {
            throw new UnprocessableEntityException(new ErrorMessage(ErrorEnum.ERROR_113));
        }
        
        ArchivoResponseDTO archivoResponseDTO=new ArchivoResponseDTO();
        StreamingOutput streamingOutput = null;
        
        if(archivoRequestDTO.getCodTipDes().equals(Constantes.COD_DESCARGA_PDF)) {

        	return descargarPDF(archivoRequestDTO, request);

        }
        
        
            File file = comprobantesRepository.recuperaComprobanteService(archivoRequestDTO.getNumRucEmisor(), archivoRequestDTO.getNumCpe().toString(),
            		archivoRequestDTO.getCodCpe(), archivoRequestDTO.getNumSerieCpe(), archivoRequestDTO.getCodTipDes(), archivoRequestDTO.getCodFiltroCpe(), archivoRequestDTO.getNumRucHeader());
            
            if (file == null) {
                exception.addError(true, "113", ErrorEnum.ERROR_113.getMsg());
                throw exception;
            }
            
            streamingOutput = ZipFile(file);
            archivoResponseDTO.setValArchivo(convertToByte(streamingOutput));
            
            String tipoCp = archivoRequestDTO.getCodTipDes().equals(Constantes.COD_DESCARGA_XML) ? "XML" : "CDR";
        	
        String nombreArchivo = archivoRequestDTO.getNumRucEmisor() +
        		"-"+archivoRequestDTO.getCodCpe()+
        		"-"+archivoRequestDTO.getNumSerieCpe()+
        		"-"+archivoRequestDTO.getNumCpe()+"-" +tipoCp +".zip";

        archivoResponseDTO.setNomArchivo(nombreArchivo);

        return archivoResponseDTO;
    }    
    
    public ArchivoResponseDTO descargarPDF(ArchivoRequestDTO archivoRequestDTO, ComprobanteIndividualRequestDTO request) throws Exception{
    	
        StreamingOutput streamingOutput =  output ->  {
            try {
                List<Comprobantes> listaComprobantes = comprobantesRepository.obtenerComprobanteIndividual(request);
//                Map<String, Object> param = obtenerParametroPDF(listaComprobantes, obtenerUbigeo(archivoRequestDTO.getNumRucEmisor()));
                Retencion param=new Retencion();
                Percepcion paramPer=new Percepcion();
                Collection<Retencion> listRetencion = new ArrayList<Retencion>();
                Collection<Percepcion> listPercepcion = new ArrayList<Percepcion>();
                if(request.getCodCpe().equals(Constantes.COD_CPE_PERCEPCION)) {
                paramPer = obtenerParametroPercepcionBean(listaComprobantes, obtenerUbigeo(archivoRequestDTO.getNumRucEmisor()), obtenerUbigeo(archivoRequestDTO.getNumRucEmisor()));
		listPercepcion.add(paramPer);
                }
                if(request.getCodCpe().equals(Constantes.COD_CPE_RETENCION)) {
                param = obtenerParametroBean(listaComprobantes, obtenerUbigeo(archivoRequestDTO.getNumRucEmisor()), obtenerUbigeo(archivoRequestDTO.getNumRucEmisor()));
		listRetencion.add(param);
                }

                InputStream jasperStream = null;
                byte[] pdfBytes = null;
                
                if(request.getCodCpe().equals(Constantes.COD_CPE_PERCEPCION)) {
                jasperStream = getClass().getResourceAsStream("/reports/percepcion/percepcion_report_portal.jasper");
                        Map<String, Object> paramData = new HashMap<String, Object>();

                        paramData.put("net.sf.jasperreports.engine.export.JRPdfExporterParameter.METADATA_AUTHOR", "sunat.gob.pe");
                        paramData.put("net.sf.jasperreports.engine.export.JRPdfExporterParameter.METADATA_CREATOR", "SUNAT Java GenDoc derechos reservados");
                        paramData.put("net.sf.jasperreports.engine.export.JRPdfExporterParameter.INPUT_FILE_NAME", jasperStream);
                        paramData.put("SUBREPORT_DIR", "reports/percepcion/");
                        try {
                                if(listPercepcion == null) {
                                        listPercepcion = new ArrayList<Percepcion>();
                                }
                                JasperPrint print = JasperFillManager.fillReport(jasperStream, paramData, 
                                		new JRBeanCollectionDataSource(listPercepcion));

                                ByteArrayOutputStream outputStream = new ByteArrayOutputStream();
                                JRPdfExporter exporter = new JRPdfExporter();
                                exporter.setParameter(JRExporterParameter.JASPER_PRINT, print);
                            exporter.setParameter(JRExporterParameter.OUTPUT_STREAM, outputStream);
                                exporter.exportReport();
                                pdfBytes = outputStream.toByteArray();
                        } catch (JRException e) {
                                throw new RuntimeException("ocurrio un error al crear el pdf",e);
                        }
                }
                if(request.getCodCpe().equals(Constantes.COD_CPE_RETENCION)) {
                        jasperStream = getClass().getResourceAsStream("/reports/retencion/retencion_report_portal.jasper");
                        Map<String, Object> paramData = new HashMap<String, Object>();

                        paramData.put("net.sf.jasperreports.engine.export.JRPdfExporterParameter.METADATA_AUTHOR", "sunat.gob.pe");
                        paramData.put("net.sf.jasperreports.engine.export.JRPdfExporterParameter.METADATA_CREATOR", "SUNAT Java GenDoc derechos reservados");
                        paramData.put("net.sf.jasperreports.engine.export.JRPdfExporterParameter.INPUT_FILE_NAME", jasperStream);
                        paramData.put("SUBREPORT_DIR", "reports/retencion/");
                        try {
                                if(listRetencion == null) {
                                        listRetencion = new ArrayList<Retencion>();
                                }
                                JasperPrint print = JasperFillManager.fillReport(jasperStream, paramData, new JRBeanCollectionDataSource(listRetencion));

                                ByteArrayOutputStream outputStream = new ByteArrayOutputStream();
                                JRPdfExporter exporter = new JRPdfExporter();
                                exporter.setParameter(JRExporterParameter.JASPER_PRINT, print);
                            exporter.setParameter(JRExporterParameter.OUTPUT_STREAM, outputStream);
                                exporter.exportReport();
                                pdfBytes = outputStream.toByteArray();
                        } catch (JRException e) {
                                throw new RuntimeException("ocurrio un error al crear el pdf",e);
                        }
                        }

                output.write(pdfBytes);
                output.flush();
                output.close();
                jasperStream.close();

            } catch (Exception e) {
                utilLog.generarLogException((HttpServletRequest) null,
                        "ComprobanteServiceImpl.descargarPdf - Exception " + e.getMessage(), e);
                // throw new WebApplicationException(e);
            }
        };  
        
        ArchivoResponseDTO archivoResponseDTO=new ArchivoResponseDTO();
    
	    String nombreArchivo = archivoRequestDTO.getNumRucEmisor() +
	    		"-"+archivoRequestDTO.getCodCpe()+
	    		"-"+archivoRequestDTO.getNumSerieCpe()+
	    		"-"+archivoRequestDTO.getNumCpe()+"-PDF" +".zip";
	    
	    String nombreArchivoPdf = archivoRequestDTO.getNumRucEmisor() +
	    		"-"+archivoRequestDTO.getCodCpe()+
	    		"-"+archivoRequestDTO.getNumSerieCpe()+
	    		"-"+archivoRequestDTO.getNumCpe()+".pdf";
	    File newFilePdf = new File(nombreArchivoPdf);
        FileUtils.writeByteArrayToFile(newFilePdf,convertToByte(streamingOutput));
        StreamingOutput outputzip=ZipFile(newFilePdf);
        archivoResponseDTO.setNomArchivo(nombreArchivo);
        archivoResponseDTO.setValArchivo(convertToByte(outputzip));
        
        return archivoResponseDTO;
    }
    
    public Map<String, Object> obtenerParametroPDF(List<Comprobantes> lstCp, UbigeoContribuyente ubigeo) {
        Map<String, Object> param = new HashMap<>();

        for (Comprobantes comprobante : lstCp) {
            param.put("ruc", comprobante.getDatosEmisor().getNumRuc());
            param.put("numeroComprobante",String.valueOf(comprobante.getNumCpe()));
            param.put("serieComprobante", comprobante.getNumSerie());
            param.put("razonSocialEmisor",  String.valueOf(comprobante.getDatosEmisor().getDesRazonSocialEmis()));
            param.put("numDireccionEmisor",  String.valueOf(comprobante.getDatosEmisor().getDesDirEmis()));
            param.put("urbanizacionEmisor",  String.valueOf(ubigeo.getDesNomZon()));
            param.put("departamentoEmisor",  String.valueOf(ubigeo.getDesDepartamento()));
            param.put("provinciaEmisor",  String.valueOf(ubigeo.getDesProvincia()));
            param.put("distritoEmisor",  String.valueOf(ubigeo.getDesDistrito()));
            param.put("fechaEmision",  String.valueOf(comprobante.getFecEmision()));
            param.put("nombreCliente",  String.valueOf(comprobante.getDatosReceptor().getDesRazonSocialRecep()));
            param.put("rucReceptor",  String.valueOf(comprobante.getDatosReceptor().getNumDocIdeRecep()));
            //param.put("DireccionCliente",  String.valueOf(comprobante.getDatosReceptor().get()));
            param.put("tipoDocumentoReceptor",  String.valueOf(comprobante.getDatosReceptor().getCodDocIdeRecep()));
            param.put("numDocumentoReceptor",  String.valueOf(comprobante.getDatosReceptor().getNumDocIdeRecep()));
            
            //detalle
            //param.put("numDocumentoReceptor",  String.valueOf(comprobante.getInformacionItems()));
            //param.put("Observacion",  String.valueOf(comprobante.getDatosReceptor().getDesObservacion()));

        }
        return param;
    }    
    
    private UbigeoContribuyente obtenerUbigeo(String numRuc){
        //String desRazonSocialEmis = "";
        UbigeoContribuyente ubigeo = new UbigeoContribuyente();
        
        try{
            Contribuyentes contribuyente = contribuyenteRepository.obtenerContribuyente(numRuc.trim());
            if(contribuyente != null){
                //desRazonSocialEmis = contribuyente.getUbigeo().getDesNomZon();
            	ubigeo.setCodUbigeo(contribuyente.getUbigeo().getCodUbigeo());
            	ubigeo.setDesNumer1(contribuyente.getUbigeo().getDesNumer1());
            	ubigeo.setCodTipvia(contribuyente.getUbigeo().getCodTipvia());
            	ubigeo.setDesNomVia(contribuyente.getUbigeo().getDesNomVia());
            	ubigeo.setDesNomZon(contribuyente.getUbigeo().getDesNomZon());
            	ubigeo.setDesDepartamento(contribuyente.getUbigeo().getDesDepartamento());
            	ubigeo.setDesProvincia(contribuyente.getUbigeo().getDesProvincia());
            	ubigeo.setDesDistrito(contribuyente.getUbigeo().getDesDistrito());
                
            }
        }catch(Exception ex){
            utilLog.imprimirLog(ConstantesUtils.LEVEL_DEBUG, ex.getMessage());
        }
        return ubigeo;
    }
    
    public  StreamingOutput ZipFile(File file){

        StreamingOutput streamingOutput = output -> {

            try {
                byte[] buffer = new byte[1024];

                ZipOutputStream zos = new ZipOutputStream(output);

                addFileContentToZipOutputStream(buffer, zos, file);

                zos.close();

                FileUtils.forceDelete(file);
            } catch (Exception e) {
                utilLog.generarLogException((HttpServletRequest) null,
                        "XmlComprobanteServiceImpl.descargarReciboPorHonorario - Exception " + e.getMessage(), e);
                // throw new WebApplicationException(e);
            }
        };
        return  streamingOutput;
    }    
    
    private void addFileContentToZipOutputStream(byte[] buffer, ZipOutputStream zos, File file) throws IOException {
        // add the first file to the zip
        ZipEntry zipEntry = new ZipEntry(file.getName());
        zos.putNextEntry(zipEntry);
        FileInputStream fis = new FileInputStream(file);

        int len;
        while ((len = fis.read(buffer)) > 0) {
            zos.write(buffer, 0, len);
        }

        fis.close();
        zos.closeEntry();
    } 
    public static   byte[] convertToByte(StreamingOutput streamingOutput) throws IOException {
        ByteArrayOutputStream outputStream = new ByteArrayOutputStream();
        try {
            streamingOutput.write(outputStream);
        } catch (IOException e) {
            
        }
        byte[] data = outputStream.toByteArray();

        return data;
    }    
    
    public Retencion obtenerParametroBean(List<Comprobantes> lstCp, UbigeoContribuyente ubigeoEmi,UbigeoContribuyente ubigeoRecep) {
            
        DateFormat fmt = new SimpleDateFormat("yyyy-MM-dd");
			
	//Construyendo el Obteto model Retencion  - PDF
        Retencion retencionModel = new Retencion();


        for (Comprobantes comprobante : lstCp) {
           
            Contribuyente emisor=new Contribuyente();
            Contribuyente receptor=new Contribuyente();
            PkComprobante pkComprobante = new PkComprobante(comprobante.getDatosEmisor().getNumRuc(), comprobante.getCodCpe(), comprobante.getNumSerie(), comprobante.getNumCpe());

            Ubigeo ubigeoEmisor = new Ubigeo();
            ubigeoEmisor.setCodUbigeo(Objects.nonNull(ubigeoEmi.getCodUbigeo()) ? 
            		ubigeoEmi.getCodUbigeo() : Constantes.DEFAULT_FIELD);
			ubigeoEmisor.setDireccion(Objects.nonNull(ubigeoEmi.getDesNomVia())? 
					obtenerTipoVia(ubigeoEmi.getCodTipvia()) +" " + ubigeoEmi.getDesNomVia() : Constantes.DEFAULT_FIELD);
			ubigeoEmisor.setUrbanizacion(Objects.nonNull(ubigeoEmi.getDesNomZon())?
					ubigeoEmi.getDesNumer1()+" "+ubigeoEmi.getDesNomZon() : Constantes.DEFAULT_FIELD);
			ubigeoEmisor.setProvincia(Objects.nonNull(ubigeoEmi.getDesProvincia())? 
					ubigeoEmi.getDesProvincia() : Constantes.DEFAULT_FIELD);
			ubigeoEmisor.setDepartamento(Objects.nonNull(ubigeoEmi.getDesDepartamento())?
					ubigeoEmi.getDesDepartamento() : Constantes.DEFAULT_FIELD);
			ubigeoEmisor.setDistrito(Objects.nonNull(ubigeoEmi.getDesDistrito())? 
					ubigeoEmi.getDesDistrito() : Constantes.DEFAULT_FIELD);
			ubigeoEmisor.setCodPais("PE");
                        
            emisor.setNumDocIdentidad(comprobante.getDatosEmisor().getNumRuc());
            emisor.setCodTipoDoc("6");
            emisor.setRazonSocial(comprobante.getDatosEmisor().getDesRazonSocialEmis());
            emisor.setUbigeo(ubigeoEmisor);
            
            Ubigeo ubigeoReceptor = new Ubigeo();
            ubigeoReceptor.setCodUbigeo(ubigeoEmi.getCodUbigeo());
			ubigeoReceptor.setDireccion(obtenerTipoVia(ubigeoEmi.getCodTipvia()) +" " + ubigeoEmi.getDesNomVia());
			ubigeoReceptor.setUrbanizacion(ubigeoEmi.getDesNumer1()+" "+ubigeoEmi.getDesNomZon());
			ubigeoReceptor.setProvincia(ubigeoEmi.getDesProvincia());
			ubigeoReceptor.setDepartamento(ubigeoEmi.getDesDepartamento());
			ubigeoReceptor.setDistrito(ubigeoEmi.getDesDistrito());
			ubigeoReceptor.setCodPais("PE");
            receptor.setCodTipoDoc(comprobante.getDatosReceptor().getCodDocIdeRecep());
            receptor.setNumDocIdentidad(comprobante.getDatosReceptor().getNumDocIdeRecep());
            receptor.setDesTipoDoc(Utils.descCodDoc(comprobante.getDatosReceptor().getCodDocIdeRecep()));
            receptor.setRazonSocial(comprobante.getDatosReceptor().getDesRazonSocialRecep());
            receptor.setNombreComercial("NombreComercial");
            receptor.setUbigeo(ubigeoReceptor);

			retencionModel.setPkRetencion(pkComprobante);
			retencionModel.setEmisor(emisor);
			retencionModel.setReceptor(receptor);
			retencionModel.setFechaEmision(comprobante.getFecEmision());
			retencionModel.setCodRegimenRet(comprobante.getRegRetencion());
//			String[] parts = comprobante.getRegRetencion().split("\\|");
//                        String part1 = parts[0]; // DESC
//                        String part2 = parts[1]; // porc
			retencionModel.setDesRegimenRet(comprobante.getRegRetencion());
			retencionModel.setPorcentajeRet(comprobante.getInformacionItems().get(0).getPorTasa().doubleValue());
			retencionModel.setMontoTotalRetenido(comprobante.getMtoTotalRet().doubleValue());
			retencionModel.setMontoTotalPagado(comprobante.getMtoTotalCobrado().doubleValue());

			List<DocRelacionadoRet> listaDocRel = new ArrayList<DocRelacionadoRet>();
            if(comprobante.getInformacionItems().size() > 0) {
			for(InformacionItems retDocRel : comprobante.getInformacionItems()) {
				DocRelacionadoRet docRel = new DocRelacionadoRet();
				docRel.setCodTipoCpeRel(retDocRel.getCodCpe());
				docRel.setDesTipoCpeRel(Constantes.NOMBRE_COMPROBANTE_ESTANDAR);
				docRel.setNumSerieCpeRel(retDocRel.getNumSerie());
				docRel.setNumCpeRel(retDocRel.getNumCpe()+"");
				docRel.setFechaEmisionCpeRel(retDocRel.getFecEmision());
				docRel.setMontoTotalCpeRel(retDocRel.getMtoTotalCpeRel().doubleValue());
				docRel.setCodMonedaCpeRel(retDocRel.getCodMonedaCpeRel());
				docRel.setSimboloMonedaCpeRel(Utils.descSimboloMoneda(retDocRel.getCodMonedaCpeRel()));
                docRel.setMontoPagado(retDocRel.getMtoImporteNetoPagado().doubleValue());
				//docRel.setIndTipoCalculo(indTipoCalculo);
				docRel.setFechaPago(retDocRel.getFecEmision());
				docRel.setNumPago(retDocRel.getNroPago().toString());
				docRel.setMontoPago(retDocRel.getMtoImportePago().doubleValue());
				docRel.setCodMonedaPago(retDocRel.getCodMonedaPago());
				docRel.setSimboloMonedaPago(Utils.descSimboloMoneda(retDocRel.getCodMonedaPago()));
				docRel.setMontoRetenido(retDocRel.getMtoRetencion().doubleValue());
				docRel.setFechaRetencion(retDocRel.getFecEmision());
				
				listaDocRel.add(docRel);

			}
		}
		
		retencionModel.setLstDocRel(listaDocRel);

        }
        return retencionModel;
    } 

    
    public Percepcion obtenerParametroPercepcionBean(List<Comprobantes> lstCp, UbigeoContribuyente ubigeoEmi,UbigeoContribuyente ubigeoRecep) {
            
        DateFormat fmt = new SimpleDateFormat("yyyy-MM-dd");
			
	//Construyendo el Obteto model Percepcion  - PDF
        Percepcion percepcionModel = new Percepcion();

        for (Comprobantes comprobante : lstCp) {
           
            Contribuyente emisor=new Contribuyente();
            Contribuyente receptor=new Contribuyente();
            PkComprobante pkComprobante = new PkComprobante(comprobante.getDatosEmisor().getNumRuc(), comprobante.getCodCpe(), comprobante.getNumSerie(), comprobante.getNumCpe());

            Ubigeo ubigeoEmisor = new Ubigeo();
            ubigeoEmisor.setCodUbigeo(Objects.nonNull(ubigeoEmi.getCodUbigeo()) ? 
            		ubigeoEmi.getCodUbigeo() : Constantes.DEFAULT_FIELD);
			ubigeoEmisor.setDireccion(Objects.nonNull(ubigeoEmi.getDesNomVia())? 
					obtenerTipoVia(ubigeoEmi.getCodTipvia()) +" " + ubigeoEmi.getDesNomVia() : Constantes.DEFAULT_FIELD);
			ubigeoEmisor.setUrbanizacion(Objects.nonNull(ubigeoEmi.getDesNomZon())?
					ubigeoEmi.getDesNumer1()+" "+ubigeoEmi.getDesNomZon() : Constantes.DEFAULT_FIELD);
			ubigeoEmisor.setProvincia(Objects.nonNull(ubigeoEmi.getDesProvincia())? 
					ubigeoEmi.getDesProvincia() : Constantes.DEFAULT_FIELD);
			ubigeoEmisor.setDepartamento(Objects.nonNull(ubigeoEmi.getDesDepartamento())?
					ubigeoEmi.getDesDepartamento() : Constantes.DEFAULT_FIELD);
			ubigeoEmisor.setDistrito(Objects.nonNull(ubigeoEmi.getDesDistrito())? 
					ubigeoEmi.getDesDistrito() : Constantes.DEFAULT_FIELD);
			ubigeoEmisor.setCodPais("PE");
                        
            emisor.setNumDocIdentidad(comprobante.getDatosEmisor().getNumRuc());
            emisor.setCodTipoDoc("6");
            emisor.setRazonSocial(comprobante.getDatosEmisor().getDesRazonSocialEmis());
            emisor.setUbigeo(ubigeoEmisor);
            
                        Ubigeo ubigeoReceptor = new Ubigeo();
                        ubigeoReceptor.setCodUbigeo(ubigeoEmi.getCodUbigeo());
			ubigeoReceptor.setDireccion(ubigeoEmi.getDesNomVia());
			ubigeoReceptor.setUrbanizacion(ubigeoEmi.getDesNomZon());
			ubigeoReceptor.setProvincia(ubigeoEmi.getDesProvincia());
			ubigeoReceptor.setDepartamento(ubigeoEmi.getDesDepartamento());
			ubigeoReceptor.setDistrito(ubigeoEmi.getDesDistrito());
			ubigeoReceptor.setCodPais("PE");
                        receptor.setCodTipoDoc(comprobante.getDatosReceptor().getCodDocIdeRecep());
                        receptor.setNumDocIdentidad(comprobante.getDatosReceptor().getNumDocIdeRecep());
                        receptor.setDesTipoDoc(Utils.descCodDoc(comprobante.getDatosReceptor().getCodDocIdeRecep()));
                        receptor.setRazonSocial(comprobante.getDatosReceptor().getDesRazonSocialRecep());
                        receptor.setNombreComercial("Nombre Comercial");
                        receptor.setUbigeo(ubigeoReceptor);

			percepcionModel.setPkPercepcion(pkComprobante);
			percepcionModel.setEmisor(emisor);
			percepcionModel.setReceptor(receptor);
			percepcionModel.setFechaEmision(comprobante.getFecEmision());
//                        String[] parts = comprobante.getRegPercepcion().split("\\|");
//                        String part1 = parts[0]; // DESC
//                        String part2 = parts[1]; // porc
			percepcionModel.setDesRegimenPer(comprobante.getRegPercepcion());
			percepcionModel.setPorcentajePer(comprobante.getInformacionItems().get(0).getPorTasa().doubleValue());
                        percepcionModel.setMontoTotalCobrado(comprobante.getMtoTotalCobrado().doubleValue());
			percepcionModel.setMontoTotalPercibido(comprobante.getMtoTotalPer().doubleValue());
                                
			List<DocRelacionadoPer> listaDocRel = new ArrayList<DocRelacionadoPer>();
            if(comprobante.getInformacionItems().size() > 0) {
			for(InformacionItems retDocPer : comprobante.getInformacionItems()) {
				DocRelacionadoPer docRel = new DocRelacionadoPer();
				docRel.setCodTipoCpeRel(retDocPer.getCodCpe());
				docRel.setDesTipoCpeRel(Constantes.NOMBRE_COMPROBANTE_ESTANDAR);
				docRel.setNumSerieCpeRel(retDocPer.getNumSerie());
				docRel.setNumCpeRel(retDocPer.getNumCpe()+"");
				docRel.setFechaEmisionCpeRel(retDocPer.getFecEmision());
				docRel.setMontoTotalCpeRel(retDocPer.getMtoTotalCpeRel().doubleValue());
				docRel.setCodMonedaCpeRel(retDocPer.getCodMonedaCpeRel());
				docRel.setSimboloMonedaCpeRel(Utils.descSimboloMoneda(retDocPer.getCodMonedaCpeRel()));
				docRel.setMontoCobrado(retDocPer.getMtoImporteNetoCobrado().doubleValue());

				docRel.setFechaPago(retDocPer.getFecEmision());
				docRel.setNumPago(retDocPer.getNroCobro().toString());

				docRel.setMontoPago(retDocPer.getMtoImporteCobro().doubleValue());
				docRel.setCodMonedaPago(retDocPer.getCodMonedaPago());
				docRel.setSimboloMonedaPago(Utils.descSimboloMoneda(retDocPer.getCodMonedaPago()));
				docRel.setMontoPercibido(retDocPer.getMtoPercepcion().doubleValue());
				docRel.setFechaPercepcion(retDocPer.getFecEmision());
				
				listaDocRel.add(docRel);

			}
		}
		
		percepcionModel.setLstDocRel(listaDocRel);

        }
        return percepcionModel;
    } 
    
	private List<ResumenDTO> obtenerResumen(List<Comprobantes> comprobanteDTOS){
		List<ResumenDTO> resumenDTOS= new ArrayList<>();
		Map<Date,Long> conteoPorFecha = comprobanteDTOS.stream()
				.collect(Collectors.groupingBy(Comprobantes::getFecEmision, Collectors.counting()));
		final int[] contador = {1};
		conteoPorFecha.entrySet().stream()
				.sorted(Map.Entry.comparingByKey()).forEach((entry) -> {
				ResumenDTO resumenDTO= new ResumenDTO();
				resumenDTO.setNumCorrel(contador[0]);
				resumenDTO.setFecCpe(entry.getKey());
				resumenDTO.setCntCpe(entry.getValue().intValue());
				resumenDTOS.add((resumenDTO));
				contador[0] = contador[0] +1;
		});

		return resumenDTOS;
	}
    
    private String obtenerTipoVia(String desNomvia) {
        HashMap<String, String> tipodesNomvia = new HashMap<>();
        String tipoAfectacionStr = desNomvia.toString();
        
        tipodesNomvia.put("01", "Av.");
        tipodesNomvia.put("02", "Jr.");
        return tipodesNomvia.get(tipoAfectacionStr);
    }
    
}
