package pe.gob.sunat.contribuyentems.servicio.consultacpe.consulta.retper.main.config;

import pe.gob.sunat.contribuyentems.servicio.consultacpe.consulta.retper.util.Constantes;

import static javax.persistence.SynchronizationType.SYNCHRONIZED;

import javax.enterprise.context.ApplicationScoped;
import javax.enterprise.inject.Produces;
import javax.inject.Named;
import javax.persistence.EntityManager;
import javax.persistence.Persistence;
import javax.persistence.PersistenceContext;


public class EntityManagerInit {

    @PersistenceContext(unitName = Constantes.DGCPE)
    private EntityManager emDgCpe;

    @Produces
    @Named(Constantes.DGCPE)
    @ApplicationScoped
    public EntityManager createEntityManagerFactoryCpe() {
        if (emDgCpe == null) {
            return getEntityManager(Constantes.DGCPE);
        }

        return emDgCpe;
    }

    private EntityManager getEntityManager(String unitName) {
        return Persistence.createEntityManagerFactory(unitName).createEntityManager(SYNCHRONIZED);
    }
}