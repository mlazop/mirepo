package pe.gob.sunat.contribuyentems.servicio.consultacpe.consulta.retper.repository;

import org.bson.conversions.Bson;

import pe.gob.sunat.tecnologia.arquitectura.framework.mongodb.client.MongoDBClient;

public abstract class MongoDBRepository {

	protected final String DS_LECTURA = "dcbdServMige";
	protected final String DS_ESCRITURA = "dgbdServMige";

	/*
	public <T> MongoCollection<T> getCollection(String colname, Class<T> t) {

		MongoCollection<T> collection = MongoDBClient.getCollection(DS_LECTURA, colname, t);
		return collection;
	}

	
	public <T> MongoCollection<T> insertCollection(String colname, Class<T> t, List<T> l) {

		MongoCollection<T> collection = MongoDBClient.getCollection(DS_ESCRITURA, colname, t);
		collection.insertMany(l);

		collection = MongoDBClient.getCollection(DS_ESCRITURA, colname, t);
		return collection;
	}
	*/

	protected <T> T findOne(String collectionName, Class<T> className) throws Exception {
		return MongoDBClient.getCollection(DS_LECTURA, collectionName, className).find().first();
	}
	
	protected <T> T findOne(String collectionName, Class<T> className, Bson objFilter) throws Exception {

		return MongoDBClient.getCollection(DS_LECTURA, collectionName, className).find(objFilter).first();
	}
	
}

