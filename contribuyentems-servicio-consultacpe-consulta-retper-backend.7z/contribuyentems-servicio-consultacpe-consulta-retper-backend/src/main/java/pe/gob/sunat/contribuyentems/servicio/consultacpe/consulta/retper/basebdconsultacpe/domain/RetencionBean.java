package pe.gob.sunat.contribuyentems.servicio.consultacpe.consulta.retper.basebdconsultacpe.domain;

import java.io.Serializable;
import java.math.BigDecimal;
import java.util.Date;
import java.util.List;

public class RetencionBean implements Serializable{
	
	private static final long serialVersionUID = 1L;
	
	private String numRuc;
	private String codCpe;
	private String numSerieCpe;
	private Integer numCpe;
	private String codTipoDocRecep;
	private String numDocRecep;
	private String descNombreRecep;
	private Date fechaEmision;
	private String codRegimenRet;
	private String descObservacion;
	private BigDecimal montoTotalRetenido;
	private BigDecimal montoTotalPagado;
	private String codEstadoCpe;
	private String indProcedencia;
	private String indCompFisico;
	private String descMotivoReversion;
	private Date fechaReversion;
	private String codUsuReversion;
	private Long numTicket;
	private String codCorreoRecep;
	private String codMotivoContin;
	private Date fechaRegistro;
	private String codUsuRegistro;
	private Date fechaModificacion;
	private String codUsuModificacion;
	private List<RetDocRelBean> listaDocumentosRel;
	
	//descripciones
	private String descNombreEmisor;
	private String descTipoDocRecep;
	private String descTipoRegimenRet;
	private String descEstadoCpe;
	
	// hquispeon - Agregar revertido
	private String indReempRev;
	
	//PAS20165E210300193 wsandovalh nuevos Atributos
	private String numPeriodo;
	private BigDecimal montoBaseCalculo;
	
	public String getNumRuc() {
		return numRuc;
	}
	public void setNumRuc(String numRuc) {
		this.numRuc = numRuc;
	}
	public String getCodCpe() {
		return codCpe;
	}
	public void setCodCpe(String codCpe) {
		this.codCpe = codCpe;
	}
	public String getNumSerieCpe() {
		return numSerieCpe;
	}
	public void setNumSerieCpe(String numSerieCpe) {
		this.numSerieCpe = numSerieCpe;
	}
	public Integer getNumCpe() {
		return numCpe;
	}
	public void setNumCpe(Integer numCpe) {
		this.numCpe = numCpe;
	}
	public String getCodTipoDocRecep() {
		return codTipoDocRecep;
	}
	public void setCodTipoDocRecep(String codTipoDocRecep) {
		this.codTipoDocRecep = codTipoDocRecep;
	}
	public String getNumDocRecep() {
		return numDocRecep;
	}
	public void setNumDocRecep(String numDocRecep) {
		this.numDocRecep = numDocRecep;
	}
	public String getDescNombreRecep() {
		return descNombreRecep;
	}
	public void setDescNombreRecep(String descNombreRecep) {
		this.descNombreRecep = descNombreRecep;
	}
	public Date getFechaEmision() {
		return fechaEmision;
	}
	public void setFechaEmision(Date fechaEmision) {
		this.fechaEmision = fechaEmision;
	}
	public String getCodRegimenRet() {
		return codRegimenRet;
	}
	public void setCodRegimenRet(String codRegimenRet) {
		this.codRegimenRet = codRegimenRet;
	}
	public String getDescObservacion() {
		return descObservacion;
	}
	public void setDescObservacion(String descObservacion) {
		this.descObservacion = descObservacion;
	}
	public BigDecimal getMontoTotalRetenido() {
		return montoTotalRetenido;
	}
	public void setMontoTotalRetenido(BigDecimal montoTotalRetenido) {
		this.montoTotalRetenido = montoTotalRetenido;
	}
	public BigDecimal getMontoTotalPagado() {
		return montoTotalPagado;
	}
	public void setMontoTotalPagado(BigDecimal montoTotalPagado) {
		this.montoTotalPagado = montoTotalPagado;
	}
	public String getCodEstadoCpe() {
		return codEstadoCpe;
	}
	public void setCodEstadoCpe(String codEstadoCpe) {
		this.codEstadoCpe = codEstadoCpe;
	}
	public String getIndProcedencia() {
		return indProcedencia;
	}
	public void setIndProcedencia(String indProcedencia) {
		this.indProcedencia = indProcedencia;
	}
	public String getIndCompFisico() {
		return indCompFisico;
	}
	public void setIndCompFisico(String indCompFisico) {
		this.indCompFisico = indCompFisico;
	}
	public String getDescMotivoReversion() {
		return descMotivoReversion;
	}
	public void setDescMotivoReversion(String descMotivoReversion) {
		this.descMotivoReversion = descMotivoReversion;
	}
	public Date getFechaReversion() {
		return fechaReversion;
	}
	public void setFechaReversion(Date fechaReversion) {
		this.fechaReversion = fechaReversion;
	}
	public String getCodUsuReversion() {
		return codUsuReversion;
	}
	public void setCodUsuReversion(String codUsuReversion) {
		this.codUsuReversion = codUsuReversion;
	}
	public Long getNumTicket() {
		return numTicket;
	}
	public void setNumTicket(Long numTicket) {
		this.numTicket = numTicket;
	}
	public String getCodCorreoRecep() {
		return codCorreoRecep;
	}
	public void setCodCorreoRecep(String codCorreoRecep) {
		this.codCorreoRecep = codCorreoRecep;
	}
	public String getCodMotivoContin() {
		return codMotivoContin;
	}
	public void setCodMotivoContin(String codMotivoContin) {
		this.codMotivoContin = codMotivoContin;
	}
	public Date getFechaRegistro() {
		return fechaRegistro;
	}
	public void setFechaRegistro(Date fechaRegistro) {
		this.fechaRegistro = fechaRegistro;
	}
	public String getCodUsuRegistro() {
		return codUsuRegistro;
	}
	public void setCodUsuRegistro(String codUsuRegistro) {
		this.codUsuRegistro = codUsuRegistro;
	}
	public Date getFechaModificacion() {
		return fechaModificacion;
	}
	public void setFechaModificacion(Date fechaModificacion) {
		this.fechaModificacion = fechaModificacion;
	}
	public String getCodUsuModificacion() {
		return codUsuModificacion;
	}
	public void setCodUsuModificacion(String codUsuModificacion) {
		this.codUsuModificacion = codUsuModificacion;
	}
	public List<RetDocRelBean> getListaDocumentosRel() {
		return listaDocumentosRel;
	}
	public void setListaDocumentosRel(List<RetDocRelBean> listaDocumentosRel) {
		this.listaDocumentosRel = listaDocumentosRel;
	}
	public String getDescNombreEmisor() {
		return descNombreEmisor;
	}
	public void setDescNombreEmisor(String descNombreEmisor) {
		this.descNombreEmisor = descNombreEmisor;
	}
	public String getDescTipoDocRecep() {
		return descTipoDocRecep;
	}
	public void setDescTipoDocRecep(String descTipoDocRecep) {
		this.descTipoDocRecep = descTipoDocRecep;
	}
	public String getDescTipoRegimenRet() {
		return descTipoRegimenRet;
	}
	public void setDescTipoRegimenRet(String descTipoRegimenRet) {
		this.descTipoRegimenRet = descTipoRegimenRet;
	}
	public String getDescEstadoCpe() {
		return descEstadoCpe;
	}
	public void setDescEstadoCpe(String descEstadoCpe) {
		this.descEstadoCpe = descEstadoCpe;
	}
	public String getIndReempRev() {
		return indReempRev;
	}
	public void setIndReempRev(String indReempRev) {
		this.indReempRev = indReempRev;
	}
	public String getNumPeriodo() {
		return numPeriodo;
	}
	public void setNumPeriodo(String numPeriodo) {
		this.numPeriodo = numPeriodo;
	}
	public BigDecimal getMontoBaseCalculo() {
		return montoBaseCalculo;
	}
	public void setMontoBaseCalculo(BigDecimal montoBaseCalculo) {
		this.montoBaseCalculo = montoBaseCalculo;
	}

}
