package pe.gob.sunat.contribuyentems.servicio.consultacpe.consulta.retper.util;

import java.util.HashMap;
import java.util.Map;

public class Constantes {
	private Constantes() {
		throw new IllegalStateException("Utility class");
	}

	public static final String DGCPE = "dccpe";
	public static final String COLLECTION_NAME_GRAN_CONTRIBUYENTE = "grandesContribuyentes";
	public static final String COD_SIN_RUC="0";
	public static final String COD_DNI="1";
	public static final String COD_CARNET="4";
	public static final String COD_REGISTRO_UNICO="6";
	public static final int NUM_RUC_SIZE = 11;
	public static final int NUM_OTRO_DOCUMENTO_SIZE =30;
	public static final int NUM_CPE_SIZE = 8;
	public static final int NUM_SERIE_CEP_SIZE = 4;
	public static final String NUM_SERIE_CPE_NUMERIC_REGEX = "[0-9]+";
	public static final String NUM_SERIE_F_PREFIX = "F";
	public static final String NUM_SERIE_P_PREFIX = "P";
	public static final String NUM_SERIE_R_PREFIX = "R";
	public static final String NUM_SERIE_E_PREFIX = "E";
	public static final String NUM_SERIE_B_PREFIX = "B";
	public static final String COD_CPE_FACTURA = "01";
	public static final String COD_CPE_PERCEPCION = "40";
	public static final String COD_CPE_RETENCION = "20";
	public static final String COD_CPE_BOLETA = "03";
	public static final String COD_CPE_NOTA_CREDITO = "07";
	public static final String COD_CPE_NOTA_DEBITO = "08";
	public static final String COD_CPE_LIQUIDACION_COMPRA= "04";
	public static final String COD_CPE_EMISOR= "1";
	public static final String COD_CPE_RECEPTOR= "2";
	public static final String COD_ESTADO_ACTIVO="1";
	public static final String COD_ESTADO_ANULADO="0";
	public static final String COD_ESTADO_TODOS="10";
	
	public static final String DEFAULT_FIELD = "-";
	
	public static final String COD_ESTADO_EMITIDO="1";
	public static final String COD_ESTADO_BAJA="2";
	public static final String COD_ESTADO_REVERTIDO="3";
	public static final String COD_ESTADO_EMITIDO_ZERO="01";
	public static final String COD_ESTADO_BAJA_ZERO="02";
	public static final String COD_ESTADO_REVERTIDO_ZERO="03";
	
	public  static  final String COD_DESCARGA_XML="02";
	public  static  final String COD_DESCARGA_PDF="01";
	public  static  final String COD_DESCARGA_CDR="03";
	
	public  static  final String COD_DESCARGA_XML_BD="1";
	public  static  final String COD_DESCARGA_CDR_BD="0";
	
	public  static  final String COD_IND_PROCEDENCIA_PORTAL="1";
	public  static  final String COD_IND_PROCEDENCIA_GEM="2";
	public  static  final String NOMBRE_COMPROBANTE_RETENCION="Comprobante de Retención";
    public  static  final String NOMBRE_COMPROBANTE_PERCEPCION="Comprobante de Percepción";
    public  static  final String NOMBRE_COMPROBANTE_ESTANDAR="FACTURA";
	
	public static final String TIME_ZONE_GMT_5 = "GMT-5:00";
	public static final String DATE_FORMAT = "dd/MM/yyyy";
	protected static final String[] COD_CPE_ALLOWED = {COD_CPE_PERCEPCION, COD_CPE_RETENCION};
	protected static final String[] COD_CPE_FILTRO = { COD_CPE_EMISOR, COD_CPE_RECEPTOR};
	protected static final String[] COD_CPE_TIP_DES = { COD_DESCARGA_XML, COD_DESCARGA_PDF, COD_DESCARGA_CDR};
	protected static final String[] COD_NUM_SERIE_CPE_ALLOWED = { NUM_SERIE_P_PREFIX, NUM_SERIE_E_PREFIX, NUM_SERIE_R_PREFIX};
	protected static final String[] COD_CPE_ESTADO = { COD_ESTADO_EMITIDO,COD_ESTADO_BAJA,
			COD_ESTADO_REVERTIDO,COD_ESTADO_EMITIDO_ZERO,COD_ESTADO_BAJA_ZERO,COD_ESTADO_REVERTIDO_ZERO, COD_ESTADO_TODOS };
	protected static final String[] COD_ID_RECEP = { COD_SIN_RUC, COD_DNI,COD_CARNET,COD_REGISTRO_UNICO};

	public static final String DATE_FORMAT_JSON = "yyyy-MM-dd'T'HH:mm:ss.SSS";
}
