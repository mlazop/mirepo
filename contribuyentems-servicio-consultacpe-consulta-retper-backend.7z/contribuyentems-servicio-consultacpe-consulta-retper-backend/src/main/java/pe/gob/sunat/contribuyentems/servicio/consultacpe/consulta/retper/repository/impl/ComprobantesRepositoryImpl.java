package pe.gob.sunat.contribuyentems.servicio.consultacpe.consulta.retper.repository.impl;


import pe.gob.sunat.contribuyentems.servicio.consultacpe.consulta.retper.basebdcpe.*;


import pe.gob.sunat.contribuyentems.servicio.consultacpe.consulta.retper.basebdcpe.dao.PercepcionRepository;
import pe.gob.sunat.contribuyentems.servicio.consultacpe.consulta.retper.basebdcpe.dao.RetencionFileRepository;
import pe.gob.sunat.contribuyentems.servicio.consultacpe.consulta.retper.basebdcpe.dao.PercepcionFileRepository;
import pe.gob.sunat.contribuyentems.servicio.consultacpe.consulta.retper.basebdcpe.dao.RetencionRepository;
import pe.gob.sunat.contribuyentems.servicio.consultacpe.consulta.retper.basebdparametros.domain.Contribuyentes;
import pe.gob.sunat.contribuyentems.servicio.consultacpe.consulta.retper.basebdparametros.domain.UbigeoContribuyente;
import pe.gob.sunat.contribuyentems.servicio.consultacpe.consulta.retper.basebdparametros.domain.dao.ContribuyenteRepository;
import pe.gob.sunat.contribuyentems.servicio.consultacpe.consulta.retper.basebdrecauda.dao.ParamRepository;
import pe.gob.sunat.contribuyentems.servicio.consultacpe.consulta.retper.domain.*;
import pe.gob.sunat.contribuyentems.servicio.consultacpe.consulta.retper.main.config.PropertiesBean;
import pe.gob.sunat.contribuyentems.servicio.consultacpe.consulta.retper.repository.ComprobantesRepository;
import pe.gob.sunat.contribuyentems.servicio.consultacpe.consulta.retper.repository.MongoDBRepository;
import pe.gob.sunat.contribuyentems.servicio.consultacpe.consulta.retper.util.Constantes;
import pe.gob.sunat.contribuyentems.servicio.consultacpe.consulta.retper.util.Utils;
import pe.gob.sunat.contribuyentems.servicio.consultacpe.consulta.retper.util.exceptions.ErrorEnum;
import pe.gob.sunat.contribuyentems.servicio.consultacpe.consulta.retper.util.exceptions.ErrorMessage;
import pe.gob.sunat.contribuyentems.servicio.consultacpe.consulta.retper.util.exceptions.UnprocessableEntityException;
import pe.gob.sunat.contribuyentems.servicio.consultacpe.consulta.retper.ws.dto.ComprobanteIndividualRequestDTO;
import pe.gob.sunat.contribuyentems.servicio.consultacpe.consulta.retper.ws.dto.ComprobanteMasivaRequestDTO;
import pe.gob.sunat.tecnologiams.arquitectura.framework.common.util.ConstantesUtils;
import pe.gob.sunat.tecnologiams.arquitectura.framework.core.util.UtilLog;

import javax.inject.Inject;

import org.apache.commons.io.FileUtils;
import org.apache.commons.lang3.StringUtils;

import java.io.File;
import java.math.BigDecimal;
import java.math.BigInteger;
import java.text.Format;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.*;
import java.util.stream.Collectors;

public class ComprobantesRepositoryImpl extends MongoDBRepository implements ComprobantesRepository {
    @Inject
    private PercepcionRepository percepcionRepository;
    @Inject
    private RetencionRepository retencionRepository;
    @Inject
    private ParamRepository paramRepository;
    @Inject
    private ContribuyenteRepository contribuyenteRepository;
    @Inject
    private PercepcionFileRepository percepcionXMLRepository;
    @Inject
    private RetencionFileRepository retencionXMLRepository;    
    @Inject
    private UtilLog utilLog;
    @Inject
    private Utils util;
    @Inject
	private PropertiesBean properties;
    
    @Override
    public List<Comprobantes> obtenerComprobanteIndividual(ComprobanteIndividualRequestDTO request) throws ParseException {

        List<Comprobantes> comprobantes= new ArrayList<>();
        DatosEmisor datosEmisor =new DatosEmisor();
        DatosReceptor datosReceptor =new DatosReceptor();
        ComprobantePK comprobantePk=new ComprobantePK();
        Comprobantes  comprobanteInd=new Comprobantes();
        comprobantePk.setCodCpe(request.getCodCpe());
        comprobantePk.setNumCpe(request.getNumCpe().intValue());
        comprobantePk.setNumRuc(request.getNumRucEmisor());
        comprobantePk.setNumSerieCpe(request.getNumSerieCpe());
        
        String rucReceptor = null;
        if(request.getCodFiltroCpe().equals(Constantes.COD_CPE_RECEPTOR)){
        	rucReceptor = Objects.nonNull(request.getNumRucHeader())? 
            		request.getNumRucHeader() : StringUtils.EMPTY;
        }
        
        
        //RETENCION
        if(request.getCodCpe().equals(Constantes.COD_CPE_RETENCION)) {
            
        Retencion comprobante = Optional
                .ofNullable(retencionRepository.obtenerComprobante(comprobantePk,rucReceptor))
                .orElse(null);
        if(Objects.nonNull(comprobante)){
        	
            List<RetDocRel> listaPerDocRel = Optional
                    .ofNullable(retencionRepository.obtenerDetalleRetencion(comprobantePk))
                    .orElse(null);
            
            datosEmisor.setNumRuc(comprobante.getRetencionPK().getNumRuc());
            datosEmisor.setDesRazonSocialEmis(obtenerRazonSocial(comprobante.getRetencionPK().getNumRuc()));
            datosEmisor.setDesDirEmis(obtenerDireccion(comprobante.getRetencionPK().getNumRuc()));
            
            datosReceptor.setCodDocIdeRecep(comprobante.getCodTipoDocRecep());
            datosReceptor.setNumDocIdeRecep(comprobante.getNumDocRecep());
            datosReceptor.setDesRazonSocialRecep(comprobante.getDesNomRecep());
            comprobanteInd.setCodCpe(comprobante.getRetencionPK().getCodCpe());
            comprobanteInd.setNumSerie(comprobante.getRetencionPK().getNumSerieCpe());
            comprobanteInd.setNumCpe(comprobante.getRetencionPK().getNumCpe());
            comprobanteInd.setFecEmision(comprobante.getFecEmi());
            comprobanteInd.setFecRegistro(comprobante.getFecRegis());
            comprobanteInd.setIndEstadoCpe(comprobante.getCodEstCpe());
            comprobanteInd.setIndProcedencia(comprobante.getIndProcedencia());
            comprobanteInd.setMtoTotalCobrado(comprobante.getMtoTotalPagado());
            comprobanteInd.setMtoTotalRet(comprobante.getMtoTotalRet());
            comprobanteInd.setUbigeo(obtenerUbigeo(comprobante.getRetencionPK().getNumRuc()));
            comprobanteInd.setCodEstCpe(comprobante.getCodEstCpe());
            comprobanteInd.setFecReversion(comprobante.getFecRev());
            comprobanteInd.setObservacion(comprobante.getDesObservacion());
            comprobanteInd.setMotivoReversion(comprobante.getDesMotivoRev());
            // paramRepository
             String respuesta = Optional
             .ofNullable(paramRepository.obtenerParametros(comprobantePk.getCodCpe(),comprobante.getCodRegRet()))
             .orElse(null);
             String[] parts = respuesta.split("\\|");
             String part1 = parts[0];
               String part2 = parts[1]; // porc
               Double porceptaje=Double.valueOf(part2);
            comprobanteInd.setRegRetencion(part1);
            
            List<InformacionItems> lstInfItems = new ArrayList<>();
            for(RetDocRel a : listaPerDocRel) {
            	InformacionItems infItems = new InformacionItems();
            	infItems.setCodCpe(a.getCodTipCpeRel());
            	infItems.setNumSerie(a.getNumSerieCpeRel());
            	infItems.setNumCpe(Integer.valueOf(a.getNumCpeRel()));
            	infItems.setFecEmision(a.getFecEmiCpeRel());
            	infItems.setCodMonedaCpeRel(a.getCodMonedaCpeRel());
            	infItems.setCodMonedaPago(a.getCodMonedaPago());
            	infItems.setMtoTotal(a.getMtoTotalCpeRel());
            	//mongo
            	infItems.setNroPago(new BigDecimal(a.getNumPago()));
            	infItems.setMtoImportePago(a.getMtoPago());
            	infItems.setPorTasa(BigDecimal.valueOf(porceptaje));
            	infItems.setMtoRetencion(a.getMtoRet());
            	infItems.setMtoImporteNetoPagado(a.getMtoPagado());
                infItems.setMtoTotalCpeRel(a.getMtoTotalCpeRel());
            	lstInfItems.add(infItems);
            	
            }
            
            comprobanteInd.setDatosEmisor(datosEmisor);
            comprobanteInd.setDatosReceptor(datosReceptor);
            comprobanteInd.setInformacionItems(lstInfItems);
            comprobantes.add(comprobanteInd);

        }
        
        }        
        
      //PERCEPCION
        if(request.getCodCpe().equals(Constantes.COD_CPE_PERCEPCION)) {
        
        Percepcion comprobante = Optional
                .ofNullable(percepcionRepository.obtenerComprobante(comprobantePk,rucReceptor))
                .orElse(null);
        if(Objects.nonNull(comprobante)){
        	
            List<PerDocRel> listaPerDocRel = Optional
                    .ofNullable(percepcionRepository.obtenerDetallePercepcion(comprobantePk))
                    .orElse(null);

            datosEmisor.setNumRuc(comprobante.getPercepcionPK().getNumRuc());
            datosEmisor.setDesRazonSocialEmis(obtenerRazonSocial(comprobante.getPercepcionPK().getNumRuc()));
            datosEmisor.setDesDirEmis(obtenerDireccion(comprobante.getPercepcionPK().getNumRuc()));
            
            datosReceptor.setCodDocIdeRecep(comprobante.getCodTipoDocRecep());
            datosReceptor.setNumDocIdeRecep(comprobante.getNumDocRecep());
            datosReceptor.setDesRazonSocialRecep(comprobante.getDesNomRecep());
            comprobanteInd.setCodCpe(comprobante.getPercepcionPK().getCodCpe());
            comprobanteInd.setNumSerie(comprobante.getPercepcionPK().getNumSerieCpe());
            comprobanteInd.setNumCpe(comprobante.getPercepcionPK().getNumCpe());
            comprobanteInd.setFecEmision(comprobante.getFecEmi());
            comprobanteInd.setFecRegistro(comprobante.getFecRegis());
            comprobanteInd.setIndEstadoCpe(comprobante.getCodEstCpe());
            comprobanteInd.setIndProcedencia(comprobante.getIndProcedencia());
            comprobanteInd.setMtoTotalCobrado(comprobante.getMtoTotalCobrado());
            comprobanteInd.setMtoTotalPer(comprobante.getMtoTotalPer());
            comprobanteInd.setUbigeo(obtenerUbigeo(comprobante.getPercepcionPK().getNumRuc()));

            comprobanteInd.setCodEstCpe(comprobante.getCodEstCpe());
            comprobanteInd.setFecReversion(comprobante.getFecRev());
            comprobanteInd.setObservacion(comprobante.getDesObservacion());
            comprobanteInd.setMotivoReversion(comprobante.getDesMotivoRev());
            comprobanteInd.setIndReempReve(comprobante.getIndReempRev());
         // paramRepository
        String respuesta = Optional
        .ofNullable(paramRepository.obtenerParametros(comprobantePk.getCodCpe(),comprobante.getCodRegPer()))
        .orElse(null);
        String[] parts = respuesta.split("\\|");
        String part1 = parts[0]; // porc
          String part2 = parts[1]; // porc
          Double porceptaje=Double.valueOf(part2);
            comprobanteInd.setRegPercepcion(part1 + " " + part2 );
            BigDecimal totalItems= BigDecimal.ZERO;
            List<InformacionItems> lstInfItems = new ArrayList<>();
            for(PerDocRel a : listaPerDocRel) {
            	InformacionItems infItems = new InformacionItems();
            	infItems.setCodCpe(a.getCodTipCpeRel());
            	infItems.setNumSerie(a.getNumSerieCpeRel());
            	infItems.setNumCpe(Integer.valueOf(a.getNumCpeRel()));
            	infItems.setFecEmision(a.getFecEmiCpeRel());
            	infItems.setCodMonedaCpeRel(a.getCodMonedaCpeRel());
            	infItems.setCodMonedaPago(a.getCodMonedaPago());
            	infItems.setMtoTotal(a.getMtoTotalCpeRel());
            	//mongo
                infItems.setNroCobro(new BigDecimal(a.getNumPago()));
            	infItems.setMtoImporteCobro(a.getMtoPago());
            	infItems.setPorTasa(BigDecimal.valueOf(porceptaje));
            	infItems.setMtoPercepcion(a.getMtoPer());
            	infItems.setMtoImporteNetoCobrado(a.getMtoCobrado());
            	infItems.setMtoTotalCpeRel(a.getMtoTotalCpeRel());
                totalItems=totalItems.add(infItems.getMtoImporteNetoCobrado());
            	lstInfItems.add(infItems);
            	
            }
            comprobanteInd.setMtoRedondeo(totalItems.subtract(comprobante.getMtoTotalCobrado()));
            //Comprobantes  comprobanteInd=new Comprobantes();
            comprobanteInd.setDatosEmisor(datosEmisor);
            comprobanteInd.setDatosReceptor(datosReceptor);
            comprobanteInd.setInformacionItems(lstInfItems);
            comprobantes.add(comprobanteInd);

        }
        
        }
        return comprobantes;
    }

    @Override
    public List<Comprobantes> obtenerComprobanteMasiva(ComprobanteMasivaRequestDTO request) throws ParseException, UnprocessableEntityException {

    	//comprobantes
        List<Comprobantes> comprobantesList= new ArrayList<>();
;		int limit=Integer.parseInt(properties.getParamLimitInformix());
		int cntComp=properties.getCntComp();

        ComprobantePK comprobantePk=new ComprobantePK();
        Comprobantes  comprobanteInd=new Comprobantes();
        comprobantePk.setCodCpe(request.getCodCpe());
//        comprobantePk.setNumCpe(request.getNumCpe().intValue());
        String numRucEmisor="";
        if(request.getCodFiltroCpe().contains(Constantes.COD_CPE_EMISOR)){
            if(Objects.isNull(request.getNumRucEmisor())|| request.getNumRucEmisor().isEmpty()) {
                numRucEmisor = request.getNumRucHeader();
                comprobantePk.setNumRuc(numRucEmisor);
            }else{
                numRucEmisor = request.getNumRucEmisor();
                comprobantePk.setNumRuc(numRucEmisor);
            }
        }else{
            numRucEmisor=request.getNumRucEmisor()==null ? "":request.getNumRucEmisor();
            comprobantePk.setNumRuc(numRucEmisor);
        }
        comprobantePk.setNumSerieCpe(request.getNumSerieCpe());
        
        
        String rucReceptor = null;
        if(request.getCodFiltroCpe().equals(Constantes.COD_CPE_RECEPTOR)){
        	rucReceptor = Objects.nonNull(request.getNumRucHeader())? 
            		request.getNumRucHeader() : StringUtils.EMPTY;
        }
       
        //RETENCION
        if(request.getCodCpe().equals(Constantes.COD_CPE_RETENCION)) {
            
        	//comprobante
        	List<Retencion> comprobantesTotal = Optional
                .ofNullable(retencionRepository.obtenerComprobantesxFiltro(comprobantePk,request.getFecEmisionIni(),
                		request.getFecEmisionFin(),request.getNumCpeIni(),request.getNumCpeFin(),request.getCodDocIde(),
                		rucReceptor,request.getCodEstado()))
                .orElse(null);
        if(Objects.nonNull(comprobantesTotal)){
        	
        	if (comprobantesTotal.size() > limit) {
            	throw new UnprocessableEntityException(new ErrorMessage("231", "Debe mejorar el filtro b\u00FAsqueda porque excede los "+limit+" comprobantes."));
            }
        	
        	List<Retencion> comprobantes = comprobantesTotal.stream()
                    .limit(properties.getCntComp())
                    .collect(Collectors.toList());
        	
        	for(Retencion comprobante:comprobantes){
        		Comprobantes  comprobanteIndCpe=new Comprobantes();
                DatosEmisor datosEmisor =new DatosEmisor();
                DatosReceptor datosReceptor =new DatosReceptor();
                ComprobantePK comprobantePkList=new ComprobantePK();
                comprobantePkList.setCodCpe(comprobante.getRetencionPK().getCodCpe());
                comprobantePk.setNumCpe(comprobante.getRetencionPK().getNumCpe());
                comprobantePkList.setNumCpe(comprobante.getRetencionPK().getNumCpe());
                comprobantePkList.setNumRuc(comprobante.getRetencionPK().getNumRuc());
                comprobantePkList.setNumSerieCpe(comprobante.getRetencionPK().getNumSerieCpe());
                
                datosEmisor.setNumRuc(comprobante.getRetencionPK().getNumRuc());
                datosEmisor.setDesRazonSocialEmis(obtenerRazonSocial(comprobante.getRetencionPK().getNumRuc()));
                datosEmisor.setDesDirEmis(obtenerDireccion(comprobante.getRetencionPK().getNumRuc()));
                
                datosReceptor.setCodDocIdeRecep(comprobante.getCodTipoDocRecep());
                datosReceptor.setNumDocIdeRecep(comprobante.getNumDocRecep());
                datosReceptor.setDesRazonSocialRecep(comprobante.getDesNomRecep());
                comprobanteIndCpe.setCodCpe(comprobante.getRetencionPK().getCodCpe());
                comprobanteIndCpe.setNumSerie(comprobante.getRetencionPK().getNumSerieCpe());
                comprobanteIndCpe.setNumCpe(comprobante.getRetencionPK().getNumCpe());
                comprobanteIndCpe.setFecEmision(comprobante.getFecEmi());
                comprobanteIndCpe.setFecRegistro(comprobante.getFecRegis());
                comprobanteIndCpe.setIndEstadoCpe(comprobante.getCodEstCpe());
                comprobanteIndCpe.setIndProcedencia(comprobante.getIndProcedencia());
                comprobanteIndCpe.setUbigeo(obtenerUbigeo(comprobante.getRetencionPK().getNumRuc()));
                comprobanteIndCpe.setMtoTotalCobrado(comprobante.getMtoTotalPagado());
                comprobanteIndCpe.setMtoTotalRet(comprobante.getMtoTotalRet());
                comprobanteIndCpe.setCodEstCpe(comprobante.getCodEstCpe());
                comprobanteIndCpe.setFecReversion(comprobante.getFecRev());
                
                 // paramRepository
		        String respuesta = Optional
		        .ofNullable(paramRepository.obtenerParametros(comprobantePk.getCodCpe(),comprobante.getCodRegRet()))
		        .orElse(null);
		        String[] parts = respuesta.split("\\|");
		        String part1 = parts[0];
		        String part2 = parts[1]; // porc
		        Double porceptaje=Double.valueOf(part2);
            //comprobanteInd.setRegPercepcion(respuesta);
            
		        comprobanteIndCpe.setRegRetencion(part1);
        		
                List<RetDocRel> listaPerDocRel = Optional
                        .ofNullable(retencionRepository.obtenerDetalleRetencion(comprobantePkList))
                        .orElse(null);
                
                List<InformacionItems> lstInfItems = new ArrayList<>();
                for(RetDocRel a : listaPerDocRel) {
                	InformacionItems infItems = new InformacionItems();
            	infItems.setCodCpe(a.getRetDocRelPK().getCodCpe());
            	infItems.setNumSerie(a.getRetDocRelPK().getNumSerieCpe());
            	infItems.setNumCpe(a.getRetDocRelPK().getNumCpe());
            	infItems.setFecEmision(a.getFecEmiCpeRel());
            	infItems.setCodMonedaCpeRel(a.getCodMonedaCpeRel());
            	infItems.setCodMonedaPago(a.getCodMonedaPago());
            	infItems.setMtoTotal(a.getMtoTotalCpeRel());
            	//mongo
            	infItems.setNroPago(new BigDecimal(a.getNumPago()));
            	infItems.setMtoImportePago(a.getMtoPago());
            	infItems.setPorTasa(BigDecimal.valueOf(porceptaje));
            	infItems.setMtoRetencion(a.getMtoRet());
            	infItems.setMtoImporteNetoPagado(a.getMtoPagado());
            	lstInfItems.add(infItems);
                	
                }
                
                
                comprobanteIndCpe.setDatosEmisor(datosEmisor);
                comprobanteIndCpe.setDatosReceptor(datosReceptor);
                comprobanteIndCpe.setInformacionItems(lstInfItems);
                comprobantesList.add(comprobanteIndCpe);
        		
        	}
        	


        }
        
        }        
        
      //PERCEPCION
        if(request.getCodCpe().equals(Constantes.COD_CPE_PERCEPCION)) {
        
        //comprobante	
        List<Percepcion> comprobantesTotal = Optional
                .ofNullable(percepcionRepository.obtenerComprobantesxFiltro(comprobantePk,request.getFecEmisionIni(),
                		request.getFecEmisionFin(),request.getNumCpeIni(),request.getNumCpeFin(),request.getCodDocIde(),
                		rucReceptor,request.getCodEstado()))
                .orElse(null);
        if(Objects.nonNull(comprobantesTotal)){
        	
        	if (comprobantesTotal.size() > limit) {
            	throw new UnprocessableEntityException(new ErrorMessage("231", "Debe mejorar el filtro b\u00FAsqueda porque excede los "+limit+" comprobantes."));
            }
        	
        	List<Percepcion> comprobantes = comprobantesTotal.stream()
                    .limit(properties.getCntComp())
                    .collect(Collectors.toList());
        	
        	for(Percepcion comprobante:comprobantes){
                DatosEmisor datosEmisor =new DatosEmisor();
                DatosReceptor datosReceptor =new DatosReceptor();
        		Comprobantes  comprobanteIndCpe=new Comprobantes();
        		
                ComprobantePK comprobantePkList=new ComprobantePK();
                comprobantePkList.setCodCpe(comprobante.getPercepcionPK().getCodCpe());
                comprobantePkList.setNumCpe(comprobante.getPercepcionPK().getNumCpe());
                comprobantePkList.setNumRuc(comprobante.getPercepcionPK().getNumRuc());
                comprobantePkList.setNumSerieCpe(comprobante.getPercepcionPK().getNumSerieCpe());
                
                datosEmisor.setNumRuc(comprobante.getPercepcionPK().getNumRuc());
                datosEmisor.setDesRazonSocialEmis(obtenerRazonSocial(comprobante.getPercepcionPK().getNumRuc()));
                datosEmisor.setDesDirEmis(obtenerDireccion(comprobante.getPercepcionPK().getNumRuc()));
                
                datosReceptor.setCodDocIdeRecep(comprobante.getCodTipoDocRecep());
                datosReceptor.setNumDocIdeRecep(comprobante.getNumDocRecep());
                datosReceptor.setDesRazonSocialRecep(comprobante.getDesNomRecep());
                comprobanteIndCpe.setCodCpe(comprobante.getPercepcionPK().getCodCpe());
                comprobanteIndCpe.setNumSerie(comprobante.getPercepcionPK().getNumSerieCpe());
                comprobanteIndCpe.setNumCpe(comprobante.getPercepcionPK().getNumCpe());
                comprobanteIndCpe.setFecEmision(comprobante.getFecEmi());
                comprobanteIndCpe.setFecRegistro(comprobante.getFecRegis());
                comprobanteIndCpe.setIndEstadoCpe(comprobante.getCodEstCpe());
                comprobanteIndCpe.setIndProcedencia(comprobante.getIndProcedencia());
                comprobanteIndCpe.setUbigeo(obtenerUbigeo(comprobante.getPercepcionPK().getNumRuc()));
                comprobanteIndCpe.setMtoTotalCobrado(comprobante.getMtoTotalCobrado());
                comprobanteIndCpe.setMtoTotalPer(comprobante.getMtoTotalPer());
                comprobanteIndCpe.setCodEstCpe(comprobante.getCodEstCpe());
                comprobanteIndCpe.setFecReversion(comprobante.getFecRev());
                                 // paramRepository
        String respuesta = Optional
        .ofNullable(paramRepository.obtenerParametros(comprobantePk.getCodCpe(),comprobante.getCodRegPer()))
        .orElse(null);
        String[] parts = respuesta.split("\\|");
          String part2 = parts[1]; // porc
          Double porceptaje=Double.valueOf(part2);
          comprobanteIndCpe.setRegPercepcion(respuesta);
            
          comprobanteIndCpe.setRegPercepcion(respuesta);
                
                List<PerDocRel> listaPerDocRel = Optional
                        .ofNullable(percepcionRepository.obtenerDetallePercepcion(comprobantePkList))
                        .orElse(null);
                
                List<InformacionItems> lstInfItems = new ArrayList<>();
                for(PerDocRel a : listaPerDocRel) {
                	InformacionItems infItems = new InformacionItems();
            	infItems.setCodCpe(a.getPerDocRelPK().getCodCpe());
            	infItems.setNumSerie(a.getPerDocRelPK().getNumSerieCpe());
            	infItems.setNumCpe(a.getPerDocRelPK().getNumCpe());
            	infItems.setFecEmision(a.getFecEmiCpeRel());
                infItems.setCodMonedaCpeRel(a.getCodMonedaCpeRel());
            	infItems.setCodMonedaPago(a.getCodMonedaPago());
            	infItems.setMtoTotal(a.getMtoTotalCpeRel());
            	//mongo
                infItems.setNroCobro(new BigDecimal(a.getNumPago()));
            	infItems.setMtoImporteCobro(a.getMtoPago());
            	infItems.setPorTasa(BigDecimal.valueOf(porceptaje));
            	infItems.setMtoPercepcion(a.getMtoPer());
            	infItems.setMtoImporteNetoCobrado(a.getMtoCobrado());
            	lstInfItems.add(infItems);
                	
                }
                
                //Comprobantes  comprobanteInd=new Comprobantes();
                comprobanteIndCpe.setDatosEmisor(datosEmisor);
                comprobanteIndCpe.setDatosReceptor(datosReceptor);
                comprobanteIndCpe.setInformacionItems(lstInfItems);
                comprobantesList.add(comprobanteIndCpe);
        		
        	}
        }  
        }
        return comprobantesList;
    }
    
    @Override
    public Date obtenerFechaEmision(ComprobanteIndividualRequestDTO request) throws ParseException {
        ComprobantePK comprobantePk = new ComprobantePK();
        comprobantePk.setCodCpe(request.getCodCpe());
        comprobantePk.setNumCpe(request.getNumCpe().intValue());
        comprobantePk.setNumRuc(request.getNumRucEmisor());
        comprobantePk.setNumSerieCpe(request.getNumSerieCpe());
        
        String rucReceptor = null;
        if(request.getCodFiltroCpe().equals(Constantes.COD_CPE_RECEPTOR)){
        	rucReceptor = Objects.nonNull(request.getNumRucHeader())? 
            		request.getNumRucHeader() : StringUtils.EMPTY;
        }
        
        Optional<Date> fecha = null;
        if(request.getCodCpe().equals(Constantes.COD_CPE_PERCEPCION)){
        	fecha = Optional.ofNullable(percepcionRepository.obtenerFechaEmision(comprobantePk, rucReceptor));
        }
        if(request.getCodCpe().equals(Constantes.COD_CPE_RETENCION)){
        	fecha = Optional.ofNullable(retencionRepository.obtenerFechaEmision(comprobantePk, rucReceptor));
        }
        
        
        if (fecha.isPresent()) {
            return fecha.get();

        } else {
            return null;
        }
    }
    
    
    private String obtenerRazonSocial(String numRuc){

        String desRazonSocialEmis = "";
        try{
            Contribuyentes contribuyente = contribuyenteRepository.obtenerContribuyente(numRuc.trim());
            if(contribuyente != null){
                desRazonSocialEmis = contribuyente.getDesNombre().trim();
            }
        }catch(Exception ex){
            utilLog.imprimirLog(ConstantesUtils.LEVEL_DEBUG, ex.getMessage());
        }
        return desRazonSocialEmis;
    }
    private String obtenerDireccion(String numRuc){

        String desRazonSocialEmis = "";
        try{
            Contribuyentes contribuyente = contribuyenteRepository.obtenerContribuyente(numRuc.trim());
            if(contribuyente != null){
                desRazonSocialEmis = contribuyente.getUbigeo().getDesNomZon();
            }
        }catch(Exception ex){
            utilLog.imprimirLog(ConstantesUtils.LEVEL_DEBUG, ex.getMessage());
        }
        return desRazonSocialEmis;
    }
    
    private String obtenerUbigeo(String numRuc){
        String ubigeoStr = "";
        
        try{
            Contribuyentes contribuyente = contribuyenteRepository.obtenerContribuyente(numRuc.trim());
            if(contribuyente != null){	
            	ubigeoStr = ubigeoStr
            			.concat(contribuyente.getUbigeo().getDesNomZon()+"-")
            			.concat(contribuyente.getUbigeo().getDesDepartamento()+ "-")
            			.concat(contribuyente.getUbigeo().getDesProvincia() + "-")
            			.concat(contribuyente.getUbigeo().getDesDistrito());
            }
        }catch(Exception ex){
            utilLog.imprimirLog(ConstantesUtils.LEVEL_DEBUG, ex.getMessage());
        }
        return ubigeoStr;
    }
    
    public File recuperaComprobanteService(String numRuc, String numCpe, String codCpe, String numSerieCpe,
    		String codTipDes, String codFiltro, String rucHeader) throws UnprocessableEntityException {
    	
        utilLog.imprimirLog(ConstantesUtils.LEVEL_DEBUG,
                "XmlComprobanteServiceImpl.recuperaComprobanteXmlService - INICIO");
        try {
        	String numTicket;
        	byte[] byteArray = null;
        	String fileName = "";
        	ComprobantePK comprobantePK = new ComprobantePK();
        	comprobantePK.setNumRuc(numRuc);
        	comprobantePK.setNumCpe(Integer.parseInt(numCpe));
        	comprobantePK.setCodCpe(codCpe);
        	comprobantePK.setNumSerieCpe(numSerieCpe);
        	
            String rucReceptor = null;
            if(codFiltro.equals(Constantes.COD_CPE_RECEPTOR)){
            	rucReceptor = Objects.nonNull(rucHeader)? 
            			rucHeader : StringUtils.EMPTY;
            }
        	
        	
        	if(codCpe.equals(Constantes.COD_CPE_PERCEPCION)) {
            	Percepcion percepcion = percepcionRepository.obtenerComprobante(comprobantePK, rucReceptor);
//            	if(percepcion.getIndProcedencia().equals(Constantes.COD_IND_PROCEDENCIA_PORTAL) 
//            			&& codTipDes.equals(Constantes.COD_DESCARGA_CDR)) {
//            		throw new UnprocessableEntityException(new ErrorMessage(ErrorEnum.ERROR_150));
//            	}
            	
                if(codTipDes.equals(Constantes.COD_DESCARGA_XML)) {
                	codTipDes = "1";

                } else if (codTipDes.equals(Constantes.COD_DESCARGA_CDR)){
                	codTipDes = "0";

                }
            	numTicket = percepcion.getNumTicket();
            	
                PercepcionXML comprobanteArchivo = new PercepcionXML();
                PercepcionXMLPK pk = new PercepcionXMLPK();
                pk.setIndModo(codTipDes);
                pk.setNumTicket(Long.parseLong(numTicket));
                comprobanteArchivo =percepcionXMLRepository.findComprobanteXmlService(pk);
                byteArray = comprobanteArchivo.getDatosArchivo();
                if(codTipDes.equals(Constantes.COD_DESCARGA_CDR_BD)){
                	fileName = nomFileCDR(comprobanteArchivo.getNomArchivo());
                	
                } else {
                	fileName = comprobanteArchivo.getNomArchivo();
                }
        	}
        	
        	if(codCpe.equals(Constantes.COD_CPE_RETENCION)) {
            	Retencion retencion = retencionRepository.obtenerComprobante(comprobantePK, rucReceptor);
//            	if(retencion.getIndProcedencia().equals(Constantes.COD_IND_PROCEDENCIA_PORTAL) 
//            			&& codTipDes.equals(Constantes.COD_DESCARGA_CDR)) {
//            		throw new UnprocessableEntityException(new ErrorMessage(ErrorEnum.ERROR_150));
//            	}
            	
                if(codTipDes.equals(Constantes.COD_DESCARGA_XML)) {
                	codTipDes = "1";

                } else if (codTipDes.equals(Constantes.COD_DESCARGA_CDR)){
                	codTipDes = "0";

                }
            	numTicket = retencion.getNumTicket();
                RetencionXML comprobanteArchivo = new RetencionXML();
                RetencionXMLPK pk = new RetencionXMLPK();
                pk.setIndModo(codTipDes);
                pk.setNumTicket(Long.parseLong(numTicket));
                comprobanteArchivo =retencionXMLRepository.findComprobanteXmlService(pk);
                byteArray = comprobanteArchivo.getDatosArchivo();
                
                
                if(codTipDes.equals(Constantes.COD_DESCARGA_CDR_BD)){
                	fileName = nomFileCDR(comprobanteArchivo.getNomArchivo());
                	
                } else {
                	fileName = comprobanteArchivo.getNomArchivo();
                }
        	}


            File newFile = new File(fileName);
            FileUtils.writeByteArrayToFile(newFile, byteArray);
        		
            utilLog.imprimirLog(ConstantesUtils.LEVEL_DEBUG,
                    "XmlComprobanteServiceImpl.recuperaComprobanteXmlService - FIN");
            return newFile;
        } catch (Exception e) {
            return null;
        }
    }
    
    private String nomFileCDR(String nomFile) {
    	String[] parts = nomFile.split("\\.");
    	return parts[0] + "." + "zip";
    	
    }
    
    

}
