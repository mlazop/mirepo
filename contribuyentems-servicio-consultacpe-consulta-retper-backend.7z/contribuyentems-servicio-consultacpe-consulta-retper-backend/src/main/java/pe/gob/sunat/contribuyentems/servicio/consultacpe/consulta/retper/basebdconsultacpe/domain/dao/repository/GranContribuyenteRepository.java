package pe.gob.sunat.contribuyentems.servicio.consultacpe.consulta.retper.basebdconsultacpe.domain.dao.repository;

public interface GranContribuyenteRepository {
    boolean validarContribuyente(String numRuc,String codigoComprobante,String codigoTipoContribuyente);
}
