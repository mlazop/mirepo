package pe.gob.sunat.contribuyentems.servicio.consultacpe.consulta.retper.basebdcpe;

import com.fasterxml.jackson.databind.annotation.JsonSerialize;
import com.fasterxml.jackson.databind.ser.std.ToStringSerializer;
import org.bson.codecs.pojo.annotations.BsonId;

import javax.persistence.Column;
import javax.persistence.EmbeddedId;
import javax.persistence.Entity;
import javax.persistence.Table;
import java.io.Serializable;
import java.math.BigDecimal;
import java.util.Date;

@Entity
@Table(name = "t6574retdocrel")
public class RetDocRel implements Serializable {
    private static final long serialVersionUID = 1L;

    @BsonId
    @JsonSerialize(using = ToStringSerializer.class)
    @EmbeddedId
    public RetDocRelPK retDocRelPK;
    @Column(name="cod_tip_cpe_rel")
    public String codTipCpeRel;
    @Column(name="num_serie_cpe_rel")
    public String numSerieCpeRel;
    @Column(name="num_cpe_rel")
    public String numCpeRel;
    @Column(name="num_pago")
    public String numPago;
    @Column(name="fec_emi_cpe_rel")
    public Date fecEmiCpeRel;
    @Column(name="mto_total_cpe_rel")
    public BigDecimal mtoTotalCpeRel;
    @Column(name="cod_moneda_cpe_rel")
    public String codMonedaCpeRel;
    @Column(name="fec_pago")
    public Date fecPago;
    @Column(name="mto_pago")
    public BigDecimal mtoPago;
    @Column(name="cod_moneda_pago")
    public String codMonedaPago;
    @Column(name="mto_ret")
    public BigDecimal mtoRet;
    @Column(name="fec_ret")
    public Date fecRet;
    @Column(name="mto_pagado")
    public BigDecimal mtoPagado;
    @Column(name="mto_tip_cambio")
    public BigDecimal mtoTipCambio;
    @Column(name="ind_cpe_rel_rev")
    public String indCpeRelRev;
    @Column(name="fec_regis")
    public Date fecRegis;
    @Column(name="cod_usuregis")
    public String codUsuRegis;
    @Column(name="fec_modif")
    public Date fecModif;
    @Column(name="cod_usumodif")
    public String codUsuModif;

	public RetDocRelPK getRetDocRelPK() {
		return retDocRelPK;
	}
	public void setRetDocRelPK(RetDocRelPK retDocRelPK) {
		this.retDocRelPK = retDocRelPK;
	}
	public String getCodTipCpeRel() {
		return codTipCpeRel;
	}
	public void setCodTipCpeRel(String codTipCpeRel) {
		this.codTipCpeRel = codTipCpeRel;
	}
	public String getNumSerieCpeRel() {
		return numSerieCpeRel;
	}
	public void setNumSerieCpeRel(String numSerieCpeRel) {
		this.numSerieCpeRel = numSerieCpeRel;
	}
	public String getNumCpeRel() {
		return numCpeRel;
	}
	public void setNumCpeRel(String numCpeRel) {
		this.numCpeRel = numCpeRel;
	}
	public String getNumPago() {
		return numPago;
	}
	public void setNumPago(String numPago) {
		this.numPago = numPago;
	}
	public Date getFecEmiCpeRel() {
		return fecEmiCpeRel;
	}
	public void setFecEmiCpeRel(Date fecEmiCpeRel) {
		this.fecEmiCpeRel = fecEmiCpeRel;
	}
	public BigDecimal getMtoTotalCpeRel() {
		return mtoTotalCpeRel;
	}
	public void setMtoTotalCpeRel(BigDecimal mtoTotalCpeRel) {
		this.mtoTotalCpeRel = mtoTotalCpeRel;
	}
	public String getCodMonedaCpeRel() {
		return codMonedaCpeRel;
	}
	public void setCodMonedaCpeRel(String codMonedaCpeRel) {
		this.codMonedaCpeRel = codMonedaCpeRel;
	}
	public Date getFecPago() {
		return fecPago;
	}
	public void setFecPago(Date fecPago) {
		this.fecPago = fecPago;
	}
	public BigDecimal getMtoPago() {
		return mtoPago;
	}
	public void setMtoPago(BigDecimal mtoPago) {
		this.mtoPago = mtoPago;
	}
	public String getCodMonedaPago() {
		return codMonedaPago;
	}
	public void setCodMonedaPago(String codMonedaPago) {
		this.codMonedaPago = codMonedaPago;
	}

	public BigDecimal getMtoRet() {
		return mtoRet;
	}
	public void setMtoRet(BigDecimal mtoRet) {
		this.mtoRet = mtoRet;
	}
	public Date getFecRet() {
		return fecRet;
	}
	public void setFecRet(Date fecRet) {
		this.fecRet = fecRet;
	}
	public BigDecimal getMtoPagado() {
		return mtoPagado;
	}
	public void setMtoPagado(BigDecimal mtoPagado) {
		this.mtoPagado = mtoPagado;
	}
	public BigDecimal getMtoTipCambio() {
		return mtoTipCambio;
	}
	public void setMtoTipCambio(BigDecimal mtoTipCambio) {
		this.mtoTipCambio = mtoTipCambio;
	}
	public String getIndCpeRelRev() {
		return indCpeRelRev;
	}
	public void setIndCpeRelRev(String indCpeRelRev) {
		this.indCpeRelRev = indCpeRelRev;
	}
	public Date getFecRegis() {
		return fecRegis;
	}
	public void setFecRegis(Date fecRegis) {
		this.fecRegis = fecRegis;
	}
	public String getCodUsuRegis() {
		return codUsuRegis;
	}
	public void setCodUsuRegis(String codUsuRegis) {
		this.codUsuRegis = codUsuRegis;
	}
	public Date getFecModif() {
		return fecModif;
	}
	public void setFecModif(Date fecModif) {
		this.fecModif = fecModif;
	}
	public String getCodUsuModif() {
		return codUsuModif;
	}
	public void setCodUsuModif(String codUsuModif) {
		this.codUsuModif = codUsuModif;
	}
    


    

}
