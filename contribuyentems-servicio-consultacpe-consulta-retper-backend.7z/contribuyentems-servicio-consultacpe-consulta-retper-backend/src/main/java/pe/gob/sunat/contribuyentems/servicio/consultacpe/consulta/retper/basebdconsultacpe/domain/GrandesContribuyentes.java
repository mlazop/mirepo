package pe.gob.sunat.contribuyentems.servicio.consultacpe.consulta.retper.basebdconsultacpe.domain;

import com.fasterxml.jackson.databind.annotation.JsonSerialize;
import com.fasterxml.jackson.databind.ser.std.ToStringSerializer;
import org.bson.codecs.pojo.annotations.BsonId;
import org.bson.types.ObjectId;

import java.io.Serializable;

public class GrandesContribuyentes implements Serializable {

    @BsonId
    @JsonSerialize(using = ToStringSerializer.class)
    private ObjectId id;
    private String numRuc;
    private String codCpe;
    private  String codTipContrib;
    private boolean indEstad;

    public String getNumRuc() {
        return numRuc;
    }

    public void setNumRuc(String numRuc) {
        this.numRuc = numRuc;
    }

    public String getCodCpe() {
        return codCpe;
    }

    public void setCodCpe(String codCpe) {
        this.codCpe = codCpe;
    }

    public String getCodTipContrib() {
        return codTipContrib;
    }

    public void setCodTipContrib(String codTipContrib) {
        this.codTipContrib = codTipContrib;
    }

    public boolean getisIndEstad() {
        return indEstad;
    }

    public void setIndEstad(boolean indEstad) {
        this.indEstad = indEstad;
    }

    public ObjectId getId() {
        return id;
    }

    public void setId(ObjectId id) {
        this.id = id;
    }
}
