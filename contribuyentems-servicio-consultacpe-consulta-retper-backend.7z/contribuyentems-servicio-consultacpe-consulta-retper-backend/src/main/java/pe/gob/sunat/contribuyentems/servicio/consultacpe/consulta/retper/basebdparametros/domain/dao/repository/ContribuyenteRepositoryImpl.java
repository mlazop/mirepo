package pe.gob.sunat.contribuyentems.servicio.consultacpe.consulta.retper.basebdparametros.domain.dao.repository;

import static com.mongodb.client.model.Filters.eq;

import org.bson.Document;
import org.bson.conversions.Bson;

import com.mongodb.client.FindIterable;
import com.mongodb.client.MongoCollection;

import pe.gob.sunat.contribuyentems.servicio.consultacpe.consulta.retper.basebdparametros.domain.Contribuyentes;
import pe.gob.sunat.contribuyentems.servicio.consultacpe.consulta.retper.basebdparametros.domain.dao.ContribuyenteRepository;
import pe.gob.sunat.tecnologia.arquitectura.framework.mongodb.client.MongoDBClient;
import pe.gob.sunat.contribuyentems.servicio.consultacpe.consulta.retper.repository.*;
public class ContribuyenteRepositoryImpl extends MongoDBRepositoryParametros implements ContribuyenteRepository {

	private static final String CAMPONUMRUC = "numRuc";

	@Override
	public Contribuyentes buscarContribuyentePorRUC(String numRuc) {
		Bson query = new Document(CAMPONUMRUC, numRuc);
		return null;
	}

	@Override
	public Contribuyentes obtenerContribuyente(String numRuc) throws Exception {
		MongoCollection<Contribuyentes> collection = MongoDBClient.getCollection("dcbdrheparametros", "contribuyentes", Contribuyentes.class);		
		FindIterable<Contribuyentes>  findIterable  =  collection.find(eq(CAMPONUMRUC, numRuc));
		return findIterable.first();
	}


}
