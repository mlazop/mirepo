package pe.gob.sunat.contribuyentems.servicio.consultacpe.consulta.retper.basebdrecauda;

import com.fasterxml.jackson.databind.annotation.JsonSerialize;
import com.fasterxml.jackson.databind.ser.std.ToStringSerializer;
import org.bson.codecs.pojo.annotations.BsonId;

import javax.persistence.Column;
import javax.persistence.EmbeddedId;
import javax.persistence.Entity;
import javax.persistence.Table;

import java.io.Serializable;
import java.util.Date;

@Entity
@Table(name = "t01param")
public class Param implements Serializable {
    private static final long serialVersionUID = 1L;

    @BsonId
    @JsonSerialize(using = ToStringSerializer.class)
	@EmbeddedId
	protected ParamPK paramPK;

	@Column(name = "t01_factualiz")
	private Date t01Factualiz;

	@Column(name = "t01_funcion")
	private String t01Funcion;

	@Column(name = "t01_hora")
	private String t01Hora;

	@Column(name = "t01_user")
	private String t01User;

	public ParamPK getParamPK() {
		return paramPK;
	}

	public void setParamPK(ParamPK paramPK) {
		this.paramPK = paramPK;
	}

	public Date getT01Factualiz() {
		return t01Factualiz;
	}

	public void setT01Factualiz(Date t01Factualiz) {
		this.t01Factualiz = t01Factualiz;
	}

	public String getT01Funcion() {
		return t01Funcion;
	}

	public void setT01Funcion(String t01Funcion) {
		this.t01Funcion = t01Funcion;
	}

	public String getT01Hora() {
		return t01Hora;
	}

	public void setT01Hora(String t01Hora) {
		this.t01Hora = t01Hora;
	}

	public String getT01User() {
		return t01User;
	}

	public void setT01User(String t01User) {
		this.t01User = t01User;
	}
	
	


}
