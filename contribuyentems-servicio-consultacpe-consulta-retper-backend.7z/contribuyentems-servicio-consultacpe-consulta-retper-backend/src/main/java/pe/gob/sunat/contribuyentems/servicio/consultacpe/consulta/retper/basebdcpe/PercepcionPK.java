package pe.gob.sunat.contribuyentems.servicio.consultacpe.consulta.retper.basebdcpe;

import javax.persistence.Column;
import javax.persistence.Embeddable;
import java.io.Serializable;
@Embeddable
public class PercepcionPK implements   Serializable {
    private static final long serialVersionUID = -4582067725772956170L;

    @Column(name="num_ruc")
    public String numRuc;
    @Column(name="cod_cpe")
    public String codCpe;
    @Column(name="num_serie_cpe")
    public String numSerieCpe;
    @Column(name="num_cpe")
    public int numCpe;

    public String getNumRuc() {
        return numRuc;
    }

    public void setNumRuc(String numRuc) {
        this.numRuc = numRuc;
    }

    public String getCodCpe() {
        return codCpe;
    }

    public void setCodCpe(String codCpe) {
        this.codCpe = codCpe;
    }

    public String getNumSerieCpe() {
        return numSerieCpe;
    }

    public void setNumSerieCpe(String numSerieCpe) {
        this.numSerieCpe = numSerieCpe;
    }

    public int getNumCpe() {
        return numCpe;
    }

    public void setNumCpe(int numCpe) {
        this.numCpe = numCpe;
    }
}
