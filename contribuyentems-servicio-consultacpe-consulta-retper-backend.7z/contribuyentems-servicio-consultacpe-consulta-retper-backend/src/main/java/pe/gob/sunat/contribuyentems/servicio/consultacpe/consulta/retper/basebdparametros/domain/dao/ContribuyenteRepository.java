package pe.gob.sunat.contribuyentems.servicio.consultacpe.consulta.retper.basebdparametros.domain.dao;


import pe.gob.sunat.contribuyentems.servicio.consultacpe.consulta.retper.basebdparametros.domain.Contribuyentes;

public interface ContribuyenteRepository {

	public Contribuyentes buscarContribuyentePorRUC(String numRuc) throws Exception;
	public Contribuyentes obtenerContribuyente(String numRuc) throws Exception;
	
}
