package pe.gob.sunat.contribuyentems.servicio.consultacpe.consulta.retper.basebdcpe.dao;

import pe.gob.sunat.contribuyentems.servicio.consultacpe.consulta.retper.basebdcpe.PercepcionXML;
import pe.gob.sunat.contribuyentems.servicio.consultacpe.consulta.retper.basebdcpe.PercepcionXMLPK;
import pe.gob.sunat.tecnologiams.arquitectura.framework.jpa.dao.BaseDao;

public interface PercepcionFileRepository extends BaseDao<PercepcionXML, PercepcionXMLPK>{
	
	public PercepcionXML findComprobanteXmlService(PercepcionXMLPK percepcionXMLPK);
	
	

}
