package pe.gob.sunat.contribuyentems.servicio.consultacpe.consulta.retper.basebdcpe.dao.jpa;

import java.util.HashMap;
import java.util.Map;
import javax.inject.Inject;
import javax.inject.Named;
import javax.persistence.EntityManager;
import javax.persistence.NoResultException;
import javax.persistence.Query;

import pe.gob.sunat.contribuyentems.servicio.consultacpe.consulta.retper.basebdcpe.RetencionXML;
import pe.gob.sunat.contribuyentems.servicio.consultacpe.consulta.retper.basebdcpe.RetencionXMLPK;
import pe.gob.sunat.contribuyentems.servicio.consultacpe.consulta.retper.basebdcpe.dao.RetencionFileRepository;
import pe.gob.sunat.contribuyentems.servicio.consultacpe.consulta.retper.util.Constantes;
import pe.gob.sunat.tecnologiams.arquitectura.framework.common.util.ConstantesUtils;
import pe.gob.sunat.tecnologiams.arquitectura.framework.core.util.UtilLog;
import pe.gob.sunat.tecnologiams.arquitectura.framework.jpa.dao.AbstractDao;

public class RetencionFileRepositoryImpl extends AbstractDao<RetencionXML, RetencionXMLPK> implements RetencionFileRepository{
	
    @Inject
    @Named(Constantes.DGCPE)
    private EntityManager entityManager;
    
	@Override
	public EntityManager buildEntityManager() {
		return entityManager;
	}
    
    @Inject
    private UtilLog utilLog;
   

	@Override
	public Class<RetencionXML> provideEntityClass() {
		return RetencionXML.class;
	}
	
	@Override
	public RetencionXML findComprobanteXmlService(RetencionXMLPK retencionXMLPK) {
	// Usamos un Map para almacenar los parametros de la consulta
        Map<Integer, Object> parameters = new HashMap<>();
        
        StringBuilder sb = new StringBuilder("select a.num_ticket, a.ind_modo, a.arc_archivo, a.nom_archivo from t6576archret a ");
        sb.append("where a.num_ticket = ? and a.ind_modo = ? ");
        //seteamos los parametros
        parameters.put(1, retencionXMLPK.getNumTicket());
        parameters.put(2, retencionXMLPK.getIndModo());
        
        if(retencionXMLPK.getIndModo().equals(Constantes.COD_DESCARGA_XML)) {
        	String msj = "Tipo de descarga es XML : " + Constantes.COD_DESCARGA_XML;
        	utilLog.imprimirLog(ConstantesUtils.LEVEL_INFO, msj);
        }
        if(retencionXMLPK.getIndModo().equals(Constantes.COD_DESCARGA_CDR)) {
        	String msj = "Tipo de descarga es CDR : " + Constantes.COD_DESCARGA_CDR;
        	utilLog.imprimirLog(ConstantesUtils.LEVEL_INFO, msj);
        }

        RetencionXML comprobanteXML;
        try {
            Query query = entityManager.createNativeQuery(sb.toString(), RetencionXML.class);
            
             // Añadimos los parametros a la consulta
            parameters.entrySet().forEach((entry) -> {
                query.setParameter(entry.getKey(), entry.getValue());
            });
            
            comprobanteXML = (RetencionXML) query.getSingleResult();
        } catch ( NoResultException nre) {
            utilLog.imprimirLog(ConstantesUtils.LEVEL_ERROR, nre.getMessage());
            comprobanteXML = null;
        } catch (Exception e) {
            utilLog.imprimirLog(ConstantesUtils.LEVEL_ERROR, e.getMessage());
            comprobanteXML = null;
        }
		return comprobanteXML;
	}


}
