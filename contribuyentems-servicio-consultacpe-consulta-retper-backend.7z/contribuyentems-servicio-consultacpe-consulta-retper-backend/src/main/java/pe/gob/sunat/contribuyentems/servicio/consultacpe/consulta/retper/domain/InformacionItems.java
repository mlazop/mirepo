package pe.gob.sunat.contribuyentems.servicio.consultacpe.consulta.retper.domain;

import java.io.Serializable;
import java.math.BigDecimal;
import java.util.Date;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;

import pe.gob.sunat.contribuyentems.servicio.consultacpe.consulta.retper.util.Constantes;

public class InformacionItems implements Serializable {

    private String codCpe;
    private String numSerie;
    private int numCpe;
    @JsonFormat(shape = JsonFormat.Shape.STRING, pattern = Constantes.DATE_FORMAT)
    private Date fecEmision;
    private BigDecimal mtoTotal;
    private BigDecimal porTasa;
    
    @JsonInclude(Include.NON_NULL)
    private String codMonedaCpeRel;
    @JsonInclude(Include.NON_NULL)
    private String codMonedaPago;
    //Percepcion
    @JsonInclude(Include.NON_NULL)
    public BigDecimal nroCobro;
    @JsonInclude(Include.NON_NULL)
    public BigDecimal mtoImporteCobro;
    @JsonInclude(Include.NON_NULL)
    public BigDecimal mtoImporteNetoCobrado;
    @JsonInclude(Include.NON_NULL)
    public BigDecimal mtoPercepcion;

    //Retencion
    @JsonInclude(Include.NON_NULL)
    private BigDecimal nroPago;
    @JsonInclude(Include.NON_NULL)
    private BigDecimal mtoImportePago;
    @JsonInclude(Include.NON_NULL)
    private BigDecimal mtoImporteNetoPagado;
    @JsonInclude(Include.NON_NULL)
    private BigDecimal mtoRetencion;

    @JsonInclude(Include.NON_NULL)
    private BigDecimal mtoTotalCpeRel;

    
    public BigDecimal getMtoRetencion() {
        return mtoRetencion;
    }

    public void setMtoRetencion(BigDecimal mtoRetencion) {
        this.mtoRetencion = mtoRetencion;
    }

    public String getCodCpe() {
        return codCpe;
    }

    public void setCodCpe(String codCpe) {
        this.codCpe = codCpe;
    }

    public String getNumSerie() {
        return numSerie;
    }

    public void setNumSerie(String numSerie) {
        this.numSerie = numSerie;
    }

    public int getNumCpe() {
        return numCpe;
    }

    public void setNumCpe(int numCpe) {
        this.numCpe = numCpe;
    }

    public Date getFecEmision() {
        return fecEmision;
    }

    public void setFecEmision(Date fecEmision) {
        this.fecEmision = fecEmision;
    }

    public BigDecimal getMtoTotal() {
        return mtoTotal;
    }

    public void setMtoTotal(BigDecimal mtoTotal) {
        this.mtoTotal = mtoTotal;
    }

    public BigDecimal getNroCobro() {
        return nroCobro;
    }

    public void setNroCobro(BigDecimal nroCobro) {
        this.nroCobro = nroCobro;
    }

    public BigDecimal getMtoImporteCobro() {
        return mtoImporteCobro;
    }

    public void setMtoImporteCobro(BigDecimal mtoImporteCobro) {
        this.mtoImporteCobro = mtoImporteCobro;
    }

    public BigDecimal getPorTasa() {
        return porTasa;
    }

    public void setPorTasa(BigDecimal porTasa) {
        this.porTasa = porTasa;
    }

    public BigDecimal getMtoPercepcion() {
        return mtoPercepcion;
    }

    public void setMtoPercepcion(BigDecimal mtoPercepcion) {
        this.mtoPercepcion = mtoPercepcion;
    }

    public BigDecimal getMtoImporteNetoCobrado() {
        return mtoImporteNetoCobrado;
    }

    public void setMtoImporteNetoCobrado(BigDecimal mtoImporteNetoCobrado) {
        this.mtoImporteNetoCobrado = mtoImporteNetoCobrado;
    }

    public String getCodMonedaCpeRel() {
        return codMonedaCpeRel;
    }

    public void setCodMonedaCpeRel(String codMonedaCpeRel) {
        this.codMonedaCpeRel = codMonedaCpeRel;
    }

    public String getCodMonedaPago() {
        return codMonedaPago;
    }

    public void setCodMonedaPago(String codMonedaPago) {
        this.codMonedaPago = codMonedaPago;
    }

    public BigDecimal getNroPago() {
        return nroPago;
    }

    public void setNroPago(BigDecimal nroPago) {
        this.nroPago = nroPago;
    }

    public BigDecimal getMtoImportePago() {
        return mtoImportePago;
    }

    public void setMtoImportePago(BigDecimal mtoImportePago) {
        this.mtoImportePago = mtoImportePago;
    }

    public BigDecimal getMtoImporteNetoPagado() {
        return mtoImporteNetoPagado;
    }

    public void setMtoImporteNetoPagado(BigDecimal mtoImporteNetoPagado) {
        this.mtoImporteNetoPagado = mtoImporteNetoPagado;
    }

    public BigDecimal getMtoTotalCpeRel() {
        return mtoTotalCpeRel;
    }

    public void setMtoTotalCpeRel(BigDecimal mtoTotalCpeRel) {
        this.mtoTotalCpeRel = mtoTotalCpeRel;
    }


}
