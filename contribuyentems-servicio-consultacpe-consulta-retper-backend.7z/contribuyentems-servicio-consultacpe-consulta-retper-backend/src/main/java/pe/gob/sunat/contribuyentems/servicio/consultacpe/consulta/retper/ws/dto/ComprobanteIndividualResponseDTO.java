package pe.gob.sunat.contribuyentems.servicio.consultacpe.consulta.retper.ws.dto;

import pe.gob.sunat.contribuyentems.servicio.consultacpe.consulta.retper.main.config.Pagina;
import pe.gob.sunat.contribuyentems.servicio.consultacpe.consulta.retper.domain.Comprobantes;

import java.util.List;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;
import java.io.Serializable;

public class ComprobanteIndividualResponseDTO{

    private int cntTotalReg;
	@JsonInclude(Include.NON_DEFAULT)
    private int numPag;
	@JsonInclude(Include.NON_DEFAULT)
    private int numRegPag;
    private List<Pagina> numeroPaginas;
    private List<Comprobantes> comprobantes;

    public int getCntTotalReg() {
        return cntTotalReg;
    }

    public void setCntTotalReg(int cntTotalReg) {
        this.cntTotalReg = cntTotalReg;
    }

    public int getNumPag() {
        return numPag;
    }

    public void setNumPag(int numPag) {
        this.numPag = numPag;
    }

    public int getNumRegPag() {
        return numRegPag;
    }

    public void setNumRegPag(int numRegPag) {
        this.numRegPag = numRegPag;
    }

    public List<Pagina> getNumeroPaginas() {
        return numeroPaginas;
    }

    public void setNumeroPaginas(List<Pagina> numeroPaginas) {
        this.numeroPaginas = numeroPaginas;
    }

    public List<Comprobantes> getComprobantes() {
        return comprobantes;
    }

    public void setComprobantes(List<Comprobantes> comprobantes) {
        this.comprobantes = comprobantes;
    }
}
