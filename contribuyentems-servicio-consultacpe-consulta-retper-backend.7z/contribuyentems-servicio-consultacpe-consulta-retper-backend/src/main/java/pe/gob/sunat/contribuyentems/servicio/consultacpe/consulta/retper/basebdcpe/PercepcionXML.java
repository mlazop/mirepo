package pe.gob.sunat.contribuyentems.servicio.consultacpe.consulta.retper.basebdcpe;

import javax.persistence.Column;
import javax.persistence.EmbeddedId;
import javax.persistence.Entity;
import javax.persistence.Lob;
import javax.persistence.Table;

import org.bson.codecs.pojo.annotations.BsonId;

import com.fasterxml.jackson.databind.annotation.JsonSerialize;
import com.fasterxml.jackson.databind.ser.std.ToStringSerializer;

import java.io.Serializable;
import java.util.Date;

@Entity
@Table(name = "t6575archper")
public class PercepcionXML  implements Serializable {
        private static final long serialVersionUID = -5843889833667047706L;

        @BsonId
        @JsonSerialize(using = ToStringSerializer.class)
        @EmbeddedId
        public PercepcionXMLPK percepcionXMLPK;
        @Column(name="ind_modo")
    	private String indModo;
        @Lob
        @Column(name="arc_archivo")
    	private byte[] datosArchivo;
        
        @Column(name="nom_archivo")
    	private String nomArchivo;
        
        
        
		public String getNomArchivo() {
			return nomArchivo;
		}
		public void setNomArchivo(String nomArchivo) {
			this.nomArchivo = nomArchivo;
		}
		public PercepcionXMLPK getPercepcionXMLPK() {
			return percepcionXMLPK;
		}
		public void setPercepcionXMLPK(PercepcionXMLPK percepcionXMLPK) {
			this.percepcionXMLPK = percepcionXMLPK;
		}
		public String getIndModo() {
			return indModo;
		}
		public void setIndModo(String indModo) {
			this.indModo = indModo;
		}
		public byte[] getDatosArchivo() {
			return datosArchivo;
		}
		public void setDatosArchivo(byte[] datosArchivo) {
			this.datosArchivo = datosArchivo;
		}




}
