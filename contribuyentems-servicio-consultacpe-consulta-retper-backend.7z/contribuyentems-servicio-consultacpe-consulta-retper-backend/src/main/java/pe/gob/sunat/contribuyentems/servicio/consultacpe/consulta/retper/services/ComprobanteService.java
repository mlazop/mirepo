package pe.gob.sunat.contribuyentems.servicio.consultacpe.consulta.retper.services;


import pe.gob.sunat.contribuyentems.servicio.consultacpe.consulta.retper.ws.dto.ArchivoRequestDTO;
import pe.gob.sunat.contribuyentems.servicio.consultacpe.consulta.retper.ws.dto.ArchivoResponseDTO;
import pe.gob.sunat.contribuyentems.servicio.consultacpe.consulta.retper.ws.dto.ComprobanteIndividualRequestDTO;
import pe.gob.sunat.contribuyentems.servicio.consultacpe.consulta.retper.ws.dto.ComprobanteIndividualResponseDTO;
import pe.gob.sunat.contribuyentems.servicio.consultacpe.consulta.retper.ws.dto.ComprobanteMasivaRequestDTO;
import pe.gob.sunat.contribuyentems.servicio.consultacpe.consulta.retper.ws.dto.ComprobanteMasivaResponseDTO;

/**
 */
public interface ComprobanteService {
	ComprobanteIndividualResponseDTO obtenerComprobanteIndividual(ComprobanteIndividualRequestDTO request)
	            throws Exception;
	
	ComprobanteMasivaResponseDTO obtenerComprobanteMasiva(ComprobanteMasivaRequestDTO request)
	        throws Exception;
	
	ArchivoResponseDTO descargarComprobante(ArchivoRequestDTO requestDTO, ComprobanteIndividualRequestDTO request) throws Exception;
}
