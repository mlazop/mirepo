package pe.gob.sunat.contribuyentems.servicio.consultacpe.consulta.retper.basebdconsultacpe.domain;

import java.io.Serializable;
import java.util.Date;

import com.fasterxml.jackson.annotation.JsonFormat;

import pe.gob.sunat.contribuyentems.servicio.consultacpe.consulta.retper.basebdconsultacpe.domain.TipoCambio;
import pe.gob.sunat.contribuyentems.servicio.consultacpe.consulta.retper.util.Constantes;

public class DocRelacionadoPer implements Serializable {
	
	private static final long serialVersionUID = -3172279674952361119L;
	
	private String codTipoCpeRel;
	private String desTipoCpeRel;
	private String numSerieCpeRel;
	private String numCpeRel;
	@JsonFormat(shape = JsonFormat.Shape.STRING, pattern = Constantes.DATE_FORMAT)
	private Date fechaEmisionCpeRel;
	private double montoTotalCpeRel;
	private String codMonedaCpeRel;
	private String simboloMonedaCpeRel;
	@JsonFormat(shape = JsonFormat.Shape.STRING, pattern = Constantes.DATE_FORMAT)
	private Date fechaPago;
	private String numPago;
	private double montoPago;
	private String codMonedaPago;
	private String simboloMonedaPago;
	private double montoPercibido;
	private String codMonedaMontoPercibido;
	@JsonFormat(shape = JsonFormat.Shape.STRING, pattern = Constantes.DATE_FORMAT)
	private Date fechaPercepcion;
	private double montoCobrado;
	private String indCpeRelRevertido; // hquispeon - Agregar revertido
	private String codMonedaMontoCobrado;
	private String indTipoCalculo;
	private TipoCambio tipoCambio;
	
	
	public String getCodTipoCpeRel() {
		return codTipoCpeRel;
	}
	public void setCodTipoCpeRel(String codTipoCpeRel) {
		this.codTipoCpeRel = codTipoCpeRel;
	}
	public String getDesTipoCpeRel() {
		return desTipoCpeRel;
	}
	public void setDesTipoCpeRel(String desTipoCpeRel) {
		this.desTipoCpeRel = desTipoCpeRel;
	}
	public String getNumSerieCpeRel() {
		return numSerieCpeRel;
	}
	public void setNumSerieCpeRel(String numSerieCpeRel) {
		this.numSerieCpeRel = numSerieCpeRel;
	}
	public String getNumCpeRel() {
		return numCpeRel;
	}
	public void setNumCpeRel(String numCpeRel) {
		this.numCpeRel = numCpeRel;
	}
	public Date getFechaEmisionCpeRel() {
		return fechaEmisionCpeRel;
	}
	public void setFechaEmisionCpeRel(Date fechaEmisionCpeRel) {
		this.fechaEmisionCpeRel = fechaEmisionCpeRel;
	}
	public double getMontoTotalCpeRel() {
		return montoTotalCpeRel;
	}
	public void setMontoTotalCpeRel(double montoTotalCpeRel) {
		this.montoTotalCpeRel = montoTotalCpeRel;
	}
	public String getCodMonedaCpeRel() {
		return codMonedaCpeRel;
	}
	public void setCodMonedaCpeRel(String codMonedaCpeRel) {
		this.codMonedaCpeRel = codMonedaCpeRel;
	}
	public String getSimboloMonedaCpeRel() {
		return simboloMonedaCpeRel;
	}
	public void setSimboloMonedaCpeRel(String simboloMonedaCpeRel) {
		this.simboloMonedaCpeRel = simboloMonedaCpeRel;
	}
	public Date getFechaPago() {
		return fechaPago;
	}
	public void setFechaPago(Date fechaPago) {
		this.fechaPago = fechaPago;
	}
	public String getNumPago() {
		return numPago;
	}
	public void setNumPago(String numPago) {
		this.numPago = numPago;
	}
	public double getMontoPago() {
		return montoPago;
	}
	public void setMontoPago(double montoPago) {
		this.montoPago = montoPago;
	}
	public String getCodMonedaPago() {
		return codMonedaPago;
	}
	public void setCodMonedaPago(String codMonedaPago) {
		this.codMonedaPago = codMonedaPago;
	}
	public String getSimboloMonedaPago() {
		return simboloMonedaPago;
	}
	public void setSimboloMonedaPago(String simboloMonedaPago) {
		this.simboloMonedaPago = simboloMonedaPago;
	}
	public double getMontoPercibido() {
		return montoPercibido;
	}
	public void setMontoPercibido(double montoPercibido) {
		this.montoPercibido = montoPercibido;
	}
	public String getCodMonedaMontoPercibido() {
		return codMonedaMontoPercibido;
	}
	public void setCodMonedaMontoPercibido(String codMonedaMontoPercibido) {
		this.codMonedaMontoPercibido = codMonedaMontoPercibido;
	}
	public Date getFechaPercepcion() {
		return fechaPercepcion;
	}
	public void setFechaPercepcion(Date fechaPercepcion) {
		this.fechaPercepcion = fechaPercepcion;
	}
	public double getMontoCobrado() {
		return montoCobrado;
	}
	public void setMontoCobrado(double montoCobrado) {
		this.montoCobrado = montoCobrado;
	}
	public String getCodMonedaMontoCobrado() {
		return codMonedaMontoCobrado;
	}
	public void setCodMonedaMontoCobrado(String codMonedaMontoCobrado) {
		this.codMonedaMontoCobrado = codMonedaMontoCobrado;
	}
	public String getIndTipoCalculo() {
		return indTipoCalculo;
	}
	public void setIndTipoCalculo(String indTipoCalculo) {
		this.indTipoCalculo = indTipoCalculo;
	}
	public TipoCambio getTipoCambio() {
		return tipoCambio;
	}
	public void setTipoCambio(TipoCambio tipoCambio) {
		this.tipoCambio = tipoCambio;
	}
	public String getIndCpeRelRevertido() {
		return indCpeRelRevertido;
	}
	public void setIndCpeRelRevertido(String indCpeRelRevertido) {
		this.indCpeRelRevertido = indCpeRelRevertido;
	}
	
}
