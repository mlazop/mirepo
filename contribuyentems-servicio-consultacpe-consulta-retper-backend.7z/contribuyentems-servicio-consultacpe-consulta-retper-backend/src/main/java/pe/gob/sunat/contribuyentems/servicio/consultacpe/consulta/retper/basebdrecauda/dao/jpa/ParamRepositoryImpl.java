package pe.gob.sunat.contribuyentems.servicio.consultacpe.consulta.retper.basebdrecauda.dao.jpa;

import pe.gob.sunat.contribuyentems.servicio.consultacpe.consulta.retper.basebdrecauda.Param;
import pe.gob.sunat.contribuyentems.servicio.consultacpe.consulta.retper.basebdrecauda.ParamPK;
import pe.gob.sunat.contribuyentems.servicio.consultacpe.consulta.retper.basebdrecauda.dao.ParamRepository;
import pe.gob.sunat.contribuyentems.servicio.consultacpe.consulta.retper.util.Constantes;
import pe.gob.sunat.tecnologiams.arquitectura.framework.common.util.ConstantesUtils;
import pe.gob.sunat.tecnologiams.arquitectura.framework.core.util.UtilLog;
import pe.gob.sunat.tecnologiams.arquitectura.framework.jpa.dao.AbstractDao;

import javax.inject.Inject;

import javax.persistence.EntityManager;
import javax.persistence.NoResultException;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

import java.text.DecimalFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class ParamRepositoryImpl extends AbstractDao<Param, ParamPK>  implements ParamRepository {
    @PersistenceContext(unitName = "dcrecauda")
    private EntityManager entityManager;

    @Inject
    private UtilLog utilLog;
    public EntityManager getDccpe() {
        return this.entityManager;
    }
    @Override
    public EntityManager buildEntityManager() {
        return entityManager;
    }

    public static ParamRepositoryImpl forEntityManager(EntityManager entityManager) {
        ParamRepositoryImpl dao = new ParamRepositoryImpl();
        dao.entityManager = entityManager;
        dao.init();
        return dao;
    }


    @Override
    public Class<Param> provideEntityClass() {
        return Param.class;
    }

    @SuppressWarnings("unchecked")
    @Override
    public String obtenerParametros(String codcpe, String codReg) {
        // Usamos un Map para almacenar los parametros de la consulta
        Map<Integer, Object> parameters = new HashMap<>();
        
        String respuesta="";
        StringBuilder sb = new StringBuilder();
        
        if(codcpe.equals(Constantes.COD_CPE_PERCEPCION)) {
            sb.append("select * from t01param t ");
            sb.append("where t.t01_numero = ? and t.t01_argumento= ? ");
            //seteamos los parametros
            parameters.put(1, "974");
            parameters.put(2, codReg);
        }
        
        if(codcpe.equals(Constantes.COD_CPE_RETENCION)) {
            sb.append("select * from t01param t ");
            sb.append("where t.t01_numero = ? and t.t01_argumento= ? ");
            //seteamos los parametros
            parameters.put(1, "975");
            parameters.put(2, codReg);
        }
        List<Param> lst= new ArrayList<>();
        String porcentajeString = "0.00";
        try {    	
        	Query query = entityManager.createNativeQuery(sb.toString());  
                
                 // Añadimos los parametros a la consulta
                parameters.entrySet().forEach((entry) -> {
                    query.setParameter(entry.getKey(), entry.getValue());
                });
                
        	List<Object[]> rows  = query.getResultList();

        	for (Object[] row : rows) {
        		Param param = new Param();
        		ParamPK paramPK = new ParamPK();
        		paramPK.setT01Numero(row[0].toString());
        		paramPK.setT01Tipo(row[1].toString());
        		paramPK.setT01Argumento(row[2].toString());
        		param.setParamPK(paramPK);
        		param.setT01Funcion(row[3].toString());
        		param.setT01User(row[4].toString());
        		param.setT01Factualiz((Date)row[5]);
        		param.setT01Hora(row[6].toString());
          		      		
        		lst.add(param);      	
        	}
        	        	      	
        	String nombreLargo = lst.get(0).getT01Funcion();
                String nombreCorto=nombreLargo.trim();
                String[] parts = nombreCorto.split("     ");
                String descripcion = parts[0]; // 123
                
                String numeroCadena = nombreCorto.substring(nombreCorto.length() - 5, nombreCorto.length());
                if(!numeroCadena.isEmpty())  {
                	double doubleValue = Double.parseDouble(numeroCadena);
                    DecimalFormat decimalFormat = new DecimalFormat("0.00");
                    porcentajeString = decimalFormat.format(doubleValue).replace(",", ".");  
                }
                	     
                respuesta= descripcion + "|" + porcentajeString ;
                
        } catch ( NoResultException | NumberFormatException nre) {
            utilLog.imprimirLog(ConstantesUtils.LEVEL_ERROR, nre.getMessage());
            lst = null;
        }
        return respuesta;
    }    
}
