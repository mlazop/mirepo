package pe.gob.sunat.contribuyentems.servicio.consultacpe.consulta.retper.ws.dto;

import java.io.Serializable;

public class ArchivoResponseDTO implements Serializable {
    private String nomArchivo;
    private byte[] valArchivo;

    public String getNomArchivo() {
        return nomArchivo;
    }

    public void setNomArchivo(String nomArchivo) {
        this.nomArchivo = nomArchivo;
    }

    public byte[] getValArchivo() {
        return valArchivo;
    }

    public void setValArchivo(byte[] valArchivo) {
        this.valArchivo = valArchivo;
    }
}
