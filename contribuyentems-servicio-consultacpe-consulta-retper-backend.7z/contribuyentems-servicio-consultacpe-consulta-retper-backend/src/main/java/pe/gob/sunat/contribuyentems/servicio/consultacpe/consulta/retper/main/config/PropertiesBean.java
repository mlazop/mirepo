package pe.gob.sunat.contribuyentems.servicio.consultacpe.consulta.retper.main.config;

import pe.gob.sunat.contribuyentems.servicio.consultacpe.consulta.retper.main.config.ConsultaCpeConfig;
import pe.gob.sunat.contribuyentems.servicio.consultacpe.consulta.retper.main.config.Pagina;
import pe.gob.sunat.contribuyentems.servicio.consultacpe.consulta.retper.util.exceptions.UnprocessableEntityException;

import java.util.List;
import java.util.Optional;

public class PropertiesBean {

    private List<Pagina> numeroPaginas;
    private String paramLimitInformix;
    
    private int cntMesesIndividual;
    private int  cntMesesMasiva;
    private int cntComp;
    public PropertiesBean() throws UnprocessableEntityException {


        this.numeroPaginas = Optional.ofNullable(ConsultaCpeConfig.getConfig().getParamconfig().getNumeroPaginas())
                .orElseThrow(() -> new UnprocessableEntityException().addError("No se encontro Numero de paginas en Config Yaml"));
        
        this.paramLimitInformix = Optional.ofNullable(ConsultaCpeConfig.getConfig().getParamconfig().getParamLimitInformix())
                .orElseThrow(() -> new UnprocessableEntityException().addError("No se encontro Parametro de limite Informix en Config Yaml"));
        
        this.cntMesesIndividual = Optional.ofNullable(ConsultaCpeConfig.getConfig().getParamconfig().getCntMesesIndividual())
                .orElseThrow(() -> new UnprocessableEntityException().addError("No se encontro Parametro de limite cantidad de meses Individual en Config Yaml"));

        this.cntMesesMasiva = Optional.ofNullable(ConsultaCpeConfig.getConfig().getParamconfig().getCntMesesMasiva())
                .orElseThrow(() -> new UnprocessableEntityException().addError("No se encontro Numero de paginas en Config Yaml"));
        this.cntComp = Optional.ofNullable(ConsultaCpeConfig.getConfig().getParamconfig().getCntComp())
                .orElseThrow(() -> new UnprocessableEntityException().addError("No se encontro Numero de paginas en Config Yaml"));

    }
    
    
    
    public int getCntMesesMasiva() {
		return cntMesesMasiva;
	}

    public int getCntComp() {
        return cntComp;
    }

    public void setCntComp(int cntComp) {
        this.cntComp = cntComp;
    }

	public void setCntMesesMasiva(int cntMesesMasiva) {
		this.cntMesesMasiva = cntMesesMasiva;
	}



	public int getCntMesesIndividual() {
		return cntMesesIndividual;
	}

	public void setCntMesesIndividual(int cntMesesIndividual) {
		this.cntMesesIndividual = cntMesesIndividual;
	}

	public String getParamLimitInformix() {
		return paramLimitInformix;
	}



	public void setParamLimitInformix(String paramLimitInformix) {
		this.paramLimitInformix = paramLimitInformix;
	}



	public PropertiesBean(List<Pagina> numeroPaginas) {
        this.numeroPaginas = numeroPaginas;
    }


    public List<Pagina> getNumeroPaginas() {
        return numeroPaginas;
    }

    public void setNumeroPaginas(List<Pagina> numeroPaginas) {
        this.numeroPaginas = numeroPaginas;
    }
}
