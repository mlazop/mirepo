package pe.gob.sunat.contribuyentems.servicio.consultacpe.consulta.retper.main.config;

import java.util.List;

public class ParamConfig {

    private int numDiasAtencionMax;
    private int numDiasAtencionMaxAdic;
    private List<Pagina> numeroPaginas;
    private String paramLimitInformix;
    private int cntMesesIndividual;
    private int cntMesesMasiva;
    private  int cntComp;
    private String datoRutaConsultaRol;
    private String datoRutaConsulta;
    private String datoConcurrentRequests;
    private String datoParametriaHCLatencia;
    private String datoWithExecutionTimeoutInMilliseconds;
    private String datoWithMaxQueueSize;
    private String datoWithQueueSizeRejectionThreshold;
    
    
    

    public int getCntMesesMasiva() {
		return cntMesesMasiva;
	}

	public void setCntMesesMasiva(int cntMesesMasiva) {
		this.cntMesesMasiva = cntMesesMasiva;
	}

	public int getCntMesesIndividual() {
		return cntMesesIndividual;
	}

	public void setCntMesesIndividual(int cntMesesIndividual) {
		this.cntMesesIndividual = cntMesesIndividual;
	}

	public String getParamLimitInformix() {
		return paramLimitInformix;
	}

	public void setParamLimitInformix(String paramLimitInformix) {
		this.paramLimitInformix = paramLimitInformix;
	}

	public String getDatoRutaConsulta() {
        return datoRutaConsulta;
    }

    public void setDatoRutaConsulta(String datoRutaConsulta) {
        this.datoRutaConsulta = datoRutaConsulta;
    }

    public String getDatoRutaConsultaRol() {
        return datoRutaConsultaRol;
    }

    public void setDatoRutaConsultaRol(String datoRutaConsultaRol) {
        this.datoRutaConsultaRol = datoRutaConsultaRol;
    }

    public int getNumDiasAtencionMax() {
        return numDiasAtencionMax;
    }

    public void setNumDiasAtencionMax(int numDiasAtencionMax) {
        this.numDiasAtencionMax = numDiasAtencionMax;
    }

    public int getNumDiasAtencionMaxAdic() {
        return numDiasAtencionMaxAdic;
    }

    public void setNumDiasAtencionMaxAdic(int numDiasAtencionMaxAdic) {
        this.numDiasAtencionMaxAdic = numDiasAtencionMaxAdic;
    }

    public List<Pagina> getNumeroPaginas() {
        return numeroPaginas;
    }

    public void setNumeroPaginas(List<Pagina> numeroPaginas) {
        this.numeroPaginas = numeroPaginas;
    }

    public String getDatoConcurrentRequests() {
        return datoConcurrentRequests;
    }

    public void setDatoConcurrentRequests(String datoConcurrentRequests) {
        this.datoConcurrentRequests = datoConcurrentRequests;
    }

    public String getDatoParametriaHCLatencia() {
        return datoParametriaHCLatencia;
    }

    public void setDatoParametriaHCLatencia(String datoParametriaHCLatencia) {
        this.datoParametriaHCLatencia = datoParametriaHCLatencia;
    }

    public String getDatoWithExecutionTimeoutInMilliseconds() {
        return datoWithExecutionTimeoutInMilliseconds;
    }

    public void setDatoWithExecutionTimeoutInMilliseconds(String datoWithExecutionTimeoutInMilliseconds) {
        this.datoWithExecutionTimeoutInMilliseconds = datoWithExecutionTimeoutInMilliseconds;
    }

    public String getDatoWithMaxQueueSize() {
        return datoWithMaxQueueSize;
    }

    public void setDatoWithMaxQueueSize(String datoWithMaxQueueSize) {
        this.datoWithMaxQueueSize = datoWithMaxQueueSize;
    }

    public String getDatoWithQueueSizeRejectionThreshold() {
        return datoWithQueueSizeRejectionThreshold;
    }

    public void setDatoWithQueueSizeRejectionThreshold(String datoWithQueueSizeRejectionThreshold) {
        this.datoWithQueueSizeRejectionThreshold = datoWithQueueSizeRejectionThreshold;
    }
    public int getCntComp() {
        return cntComp;
    }

    public void setCntComp(int cntComp) {
        this.cntComp = cntComp;
    }
}
