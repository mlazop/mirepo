package pe.gob.sunat.contribuyentems.servicio.consultacpe.consulta.retper.ws.dto;

import java.io.Serializable;

public class ArchivoRequestDTO implements Serializable {
    private String codCpe;
    private String numRucEmisor;
    private String numRucHeader;
    private Long numCpe;
    private String numSerieCpe;
    private String codFiltroCpe;
    private String codTipDes;

    public String getCodCpe() {
        return codCpe;
    }

    public void setCodCpe(String codCpe) {
        this.codCpe = codCpe;
    }

    public String getNumRucEmisor() {
        return numRucEmisor;
    }

    public void setNumRucEmisor(String numRucEmisor) {
        this.numRucEmisor = numRucEmisor;
    }

    public String getNumRucHeader() {
        return numRucHeader;
    }

    public void setNumRucHeader(String numRucHeader) {
        this.numRucHeader = numRucHeader;
    }

    public Long getNumCpe() {
        return numCpe;
    }

    public void setNumCpe(Long numCpe) {
        this.numCpe = numCpe;
    }

    public String getNumSerieCpe() {
        return numSerieCpe;
    }

    public void setNumSerieCpe(String numSerieCpe) {
        this.numSerieCpe = numSerieCpe;
    }

    public String getCodFiltroCpe() {
        return codFiltroCpe;
    }

    public void setCodFiltroCpe(String codFiltroCpe) {
        this.codFiltroCpe = codFiltroCpe;
    }

    public String getCodTipDes() {
        return codTipDes;
    }

    public void setCodTipDes(String codTipDes) {
        codTipDes = codTipDes;
    }

    public ArchivoRequestDTO(String codCpe, String numRucEmisor, String numRucHeader, Long numCpe, String numSerieCpe, String codFiltroCpe, String codTipDes) {
        this.codCpe = codCpe;
        this.numRucEmisor = numRucEmisor;
        this.numRucHeader = numRucHeader;
        this.numCpe = numCpe;
        this.numSerieCpe = numSerieCpe;
        this.codFiltroCpe = codFiltroCpe;
        this.codTipDes = codTipDes;
    }

    public static class Builder {
        private String codCpe;
        private String numRucEmisor;
        private String numRucHeader;
        private Long numCpe;
        private String numSerieCpe;
        private String codFiltroCpe;
        private String codTipDes;

        public Builder setCodCpe(String codCpe) {
            this.codCpe = codCpe;
            return this;

        }


        public Builder setNumRucEmisor(String numRucEmisor) {
            this.numRucEmisor = numRucEmisor;
            return this;

        }

        public Builder setNumRucHeader(String numRucHeader) {
            this.numRucHeader = numRucHeader;
            return this;
        }


        public Builder setNumCpe(Long numCpe) {
            this.numCpe = numCpe;
            return this;

        }


        public Builder setNumSerieCpe(String numSerieCpe) {
            this.numSerieCpe = numSerieCpe;
            return this;

        }

        public Builder setCodFiltroCpe(String codFiltroCpe) {
            this.codFiltroCpe = codFiltroCpe;
            return this;

        }

        public Builder setCodTipDes(String codTipDes) {
            this.codTipDes = codTipDes;
            return this;

        }
        public ArchivoRequestDTO build() {
            return new ArchivoRequestDTO(codCpe,numRucEmisor,numRucHeader , numCpe, numSerieCpe,codFiltroCpe,codTipDes);
        }
    }
}
