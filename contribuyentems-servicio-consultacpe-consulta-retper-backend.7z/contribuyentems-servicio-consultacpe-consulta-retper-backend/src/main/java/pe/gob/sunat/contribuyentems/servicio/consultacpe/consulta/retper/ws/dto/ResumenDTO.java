package pe.gob.sunat.contribuyentems.servicio.consultacpe.consulta.retper.ws.dto;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.annotation.JsonInclude;

import pe.gob.sunat.contribuyentems.servicio.consultacpe.consulta.retper.util.Constantes;

import java.io.Serializable;
import java.util.Date;

@JsonInclude(JsonInclude.Include.NON_NULL)

public class ResumenDTO implements Serializable {
    private int numCorrel;
    @JsonFormat(shape = JsonFormat.Shape.STRING, pattern = Constantes.DATE_FORMAT)
    private Date fecCpe;
    private int cntCpe;

    public int getNumCorrel() {
        return numCorrel;
    }

    public void setNumCorrel(int numCorrel) {
        this.numCorrel = numCorrel;
    }

    public Date getFecCpe() {
        return fecCpe;
    }

    public void setFecCpe(Date fecCpe) {
        this.fecCpe = fecCpe;
    }

    public int getCntCpe() {
        return cntCpe;
    }

    public void setCntCpe(int cntCpe) {
        this.cntCpe = cntCpe;
    }
}
