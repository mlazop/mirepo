package pe.gob.sunat.contribuyentems.servicio.consultacpe.consulta.retper.ws.rest;
import static javax.ws.rs.core.MediaType.APPLICATION_JSON;

import pe.gob.sunat.contribuyentems.servicio.consultacpe.consulta.retper.services.ComprobanteService;
import pe.gob.sunat.contribuyentems.servicio.consultacpe.consulta.retper.util.Constantes;
import pe.gob.sunat.contribuyentems.servicio.consultacpe.consulta.retper.util.exceptions.ErrorEnum;
import pe.gob.sunat.contribuyentems.servicio.consultacpe.consulta.retper.util.exceptions.ErrorMessage;
import pe.gob.sunat.contribuyentems.servicio.consultacpe.consulta.retper.util.exceptions.UnprocessableEntityException;
import pe.gob.sunat.contribuyentems.servicio.consultacpe.consulta.retper.ws.dto.ArchivoRequestDTO;
import pe.gob.sunat.contribuyentems.servicio.consultacpe.consulta.retper.ws.dto.ArchivoResponseDTO;
import pe.gob.sunat.contribuyentems.servicio.consultacpe.consulta.retper.ws.dto.ComprobanteIndividualRequestDTO;
import pe.gob.sunat.contribuyentems.servicio.consultacpe.consulta.retper.ws.dto.ComprobanteMasivaRequestDTO;
import pe.gob.sunat.tecnologiams.arquitectura.framework.core.util.UtilLog;

import javax.inject.Inject;
import javax.ws.rs.*;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;
import java.nio.charset.StandardCharsets;
import java.util.Objects;
@Consumes(MediaType.APPLICATION_JSON)
@Produces(APPLICATION_JSON + ";charset=utf-8")
@Path("/v1/contribuyente/consultacpe")
public class ComprobanteRestService {
    @Inject
    private UtilLog utilLog;
    @Inject
    private ComprobanteService comprobanteService;

    @GET
    @Path(value = "/e/comprobantes/retper/{numRucEmisor}-{codCpe}-{numSerie}-{numCpe}-{codFiltroCpe}")
    @Produces(MediaType.APPLICATION_JSON)
    public Response obtenerComprobantes(
            @HeaderParam("numRuc") String numRucHeader,
            @PathParam("numRucEmisor") String numRuc,
            @PathParam("codCpe") String codCpe,
            @PathParam("numSerie") String numSerie,
            @PathParam("numCpe") Long numCpe,
            @PathParam("codFiltroCpe") String codFiltroCpe
    ) throws Exception {

        ComprobanteIndividualRequestDTO requestDTO = new ComprobanteIndividualRequestDTO.Builder()
                .setNumRucHeader(numRucHeader)
                .setNumRuc(numRuc)
                .setCodCpe(codCpe)
                .setNumSerie(numSerie)
                .setNumCpe(numCpe)
                .setCodFiltroCpe(codFiltroCpe)
                .build();
        return Response.ok(comprobanteService.obtenerComprobanteIndividual(requestDTO))
                .type(MediaType.APPLICATION_JSON_TYPE.withCharset(StandardCharsets.UTF_8.name())).build();

    }
    
    @GET
    @Path(value = "/e/comprobantes/retper/{numRucEmisor:.*}-{codCpe}-{codFiltroCpe}")
    @Produces(MediaType.APPLICATION_JSON)
    public Response obtenerComprobantesMasiva(
            @HeaderParam("numRuc") String numRucHeader,
            @PathParam("numRucEmisor") String numRuc,
            @PathParam("codCpe") String codCpe,
            @PathParam("codFiltroCpe") String codFiltroCpe,
            @QueryParam("numSerieCpe") String numSerieCpe,
            @QueryParam("numCpeInicio") String numCpeInicio,
            @QueryParam("numCpeFin") String numCpeFin,
            @QueryParam("codEstado") String codEstado,
            @QueryParam("codDocIde") String codDocIde,
            @QueryParam("numDocIde") String numDocIde,
            @QueryParam("fecEmisionIni") String fecEmisionIni,
            @QueryParam("fecEmisionFin") String fecEmisionFin
    ) throws Exception {

        ComprobanteMasivaRequestDTO requestDTO = new ComprobanteMasivaRequestDTO.Builder()
                .setNumRucHeader(numRucHeader)
                .setNumRucEmisor(numRuc)
                .setCodCpe(codCpe)
                .setCodFiltroCpe(codFiltroCpe)
                .setNumSerieCpe(numSerieCpe)
                .setNumCpeIni(Objects.isNull(numCpeInicio)||numCpeInicio.equals("") ?  0:Integer.parseInt(numCpeInicio))
                .setNumCpeFin(Objects.isNull(numCpeFin)||numCpeFin.equals("") ?  0:Integer.parseInt(numCpeFin))
                .setCodEstado(codEstado)
                .setCodDocIde(codDocIde)
                .setNumDocIde(numDocIde)
                .setFecEmisionIni(fecEmisionIni)
                .setFecEmisionFin(fecEmisionFin)
                .build();
        return Response.ok(comprobanteService.obtenerComprobanteMasiva(requestDTO))
                .type(MediaType.APPLICATION_JSON_TYPE.withCharset(StandardCharsets.UTF_8.name())).build();

    }
    @GET
    @Path(value = "/e/comprobantes/retper/{numRucEmisor}-{codCpe}-{numSerie}-{numCpe}-{codFiltroCpe}/{codTipDes}")
    @Produces(MediaType.APPLICATION_JSON)
    @Consumes({MediaType.APPLICATION_JSON})
    public Response descargaComprobante(
            @HeaderParam("numRuc") String numRucHeader,
            @PathParam("numRucEmisor") String numRuc,
            @PathParam("codCpe") String codCpe,
            @PathParam("numSerie") String numSerie,
            @PathParam("numCpe") Long numCpe,
            @PathParam("codFiltroCpe") String codFiltroCpe,
            @PathParam("codTipDes") String codTipDes

    ) throws Exception {
        ArchivoRequestDTO requestDTO = new ArchivoRequestDTO.Builder()
                .setNumRucHeader(numRucHeader)
                .setNumRucEmisor(numRuc)
                .setCodCpe(codCpe)
                .setCodFiltroCpe(codFiltroCpe)
                .setNumSerieCpe(numSerie)
                .setNumCpe(numCpe)
                .setCodFiltroCpe(codFiltroCpe)
                .setCodTipDes(codTipDes)
                .build();
        ArchivoResponseDTO archivoResponseDTO=new ArchivoResponseDTO();
        if (Objects.isNull(requestDTO)) {
            throw new UnprocessableEntityException(new ErrorMessage(ErrorEnum.ERROR_146));
        }
        
        ComprobanteIndividualRequestDTO request = new ComprobanteIndividualRequestDTO.Builder()
                .setNumRucHeader(numRucHeader)
                .setNumRuc(numRuc)
                .setCodCpe(codCpe)
                .setNumSerie(numSerie)
                .setNumCpe(numCpe)
                .setCodFiltroCpe(codFiltroCpe)
                .build();

            archivoResponseDTO = comprobanteService.descargarComprobante(requestDTO,request);

        return Response.ok((archivoResponseDTO))
                .type(MediaType.APPLICATION_JSON_TYPE.withCharset(StandardCharsets.UTF_8.name())).build();

    }    
}
