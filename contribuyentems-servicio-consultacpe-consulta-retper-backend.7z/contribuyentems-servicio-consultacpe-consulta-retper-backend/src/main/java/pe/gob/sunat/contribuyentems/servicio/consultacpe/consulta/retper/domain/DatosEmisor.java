package pe.gob.sunat.contribuyentems.servicio.consultacpe.consulta.retper.domain;

import java.io.Serializable;

public class DatosEmisor implements Serializable {

	private static final long serialVersionUID = 1L;

	private String numRuc;

	private String desRazonSocialEmis;

	private String desDirEmis;

	public String getNumRuc() {
		return numRuc;
	}

	public void setNumRuc(String numRuc) {
		this.numRuc = numRuc;
	}

	public String getDesRazonSocialEmis() {
		return desRazonSocialEmis;
	}

	public void setDesRazonSocialEmis(String desRazonSocialEmis) {
		if(desRazonSocialEmis.isEmpty()){
			desRazonSocialEmis = "-";
		} 
		this.desRazonSocialEmis = desRazonSocialEmis;
	}

	public String getDesDirEmis() {
		return desDirEmis;
	}

	public void setDesDirEmis(String desDirEmis) {
		if(desDirEmis.isEmpty()){
			desDirEmis = "-";
		} 
		this.desDirEmis = desDirEmis;
	}
}
