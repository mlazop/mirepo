package pe.gob.sunat.contribuyentems.servicio.consultacpe.consulta.retper.basebdcpe.dao.jpa;


import pe.gob.sunat.contribuyentems.servicio.consultacpe.consulta.retper.basebdcpe.ComprobantePK;
import pe.gob.sunat.contribuyentems.servicio.consultacpe.consulta.retper.basebdcpe.PerDocRel;
import pe.gob.sunat.contribuyentems.servicio.consultacpe.consulta.retper.basebdcpe.PerDocRelPK;
import pe.gob.sunat.contribuyentems.servicio.consultacpe.consulta.retper.basebdcpe.Percepcion;
import pe.gob.sunat.contribuyentems.servicio.consultacpe.consulta.retper.basebdcpe.PercepcionPK;
import pe.gob.sunat.contribuyentems.servicio.consultacpe.consulta.retper.basebdcpe.dao.PercepcionRepository;
import pe.gob.sunat.contribuyentems.servicio.consultacpe.consulta.retper.main.config.PropertiesBean;
import pe.gob.sunat.contribuyentems.servicio.consultacpe.consulta.retper.util.Constantes;
import pe.gob.sunat.tecnologiams.arquitectura.framework.common.util.ConstantesUtils;
import pe.gob.sunat.tecnologiams.arquitectura.framework.core.util.UtilLog;
import pe.gob.sunat.tecnologiams.arquitectura.framework.jpa.dao.AbstractDao;

import javax.inject.Inject;
import javax.persistence.EntityManager;
import javax.persistence.NoResultException;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

import org.joda.time.DateTime;
import org.joda.time.LocalDate;
import org.joda.time.format.DateTimeFormat;
import org.joda.time.format.DateTimeFormatter;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class PercepcionRepositoryImpl extends AbstractDao<Percepcion, PercepcionPK>  implements PercepcionRepository {
    @PersistenceContext(unitName = "dccpe")
    private EntityManager entityManager;

    @Inject
    private UtilLog utilLog;
    
    @Inject
    private PropertiesBean properties;
    
    public EntityManager getDccpe() {
        return this.entityManager;
    }
    @Override
    public EntityManager buildEntityManager() {
        return entityManager;
    }

    public static PercepcionRepositoryImpl forEntityManager(EntityManager entityManager) {
        PercepcionRepositoryImpl dao = new PercepcionRepositoryImpl();
        dao.entityManager = entityManager;
        dao.init();
        return dao;
    }


    @Override
    public Class<Percepcion> provideEntityClass() {
        return Percepcion.class;
    }
    @Override
    public Date obtenerFechaEmision(ComprobantePK comprobantePK, String rucReceptor) {
        // Usamos un Map para almacenar los parametros de la consulta
        Map<Integer, Object> parameters = new HashMap<>();
        
        StringBuilder sb = new StringBuilder();
        sb.append("select t.fec_emi from t6571percepcion t ");
        sb.append("where t.num_ruc = ? and t.cod_cpe = ? and t.num_serie_cpe = ? and t.num_cpe = ? ");
        
        //seteamos los parametros
        parameters.put(1, comprobantePK.getNumRuc());
        parameters.put(2, comprobantePK.getCodCpe());
        parameters.put(3, comprobantePK.getNumSerieCpe());
        parameters.put(4, comprobantePK.getNumCpe());        
        
        int index = 5;
        if (rucReceptor!= null) {
            sb.append("and t.num_doc_recep = ? ");
            parameters.put(index++, rucReceptor);
        }

        Date fecha;
        try {
            Query query = entityManager.createNativeQuery(sb.toString());
            
             // Añadimos los parametros a la consulta
            parameters.entrySet().forEach((entry) -> {
                query.setParameter(entry.getKey(), entry.getValue());
            });
            
            fecha = (Date)query.getSingleResult();
        } catch ( NoResultException nre) {
            utilLog.imprimirLog(ConstantesUtils.LEVEL_ERROR, nre.getMessage());
            fecha = null;
        } catch (Exception e) {
            utilLog.imprimirLog(ConstantesUtils.LEVEL_ERROR, e.getMessage());
            fecha = null;
        }
        return  fecha;
    }
    @Override
    public Percepcion obtenerComprobante(ComprobantePK comprobantePK, String rucReceptor) {
        // Usamos un Map para almacenar los parametros de la consulta
        Map<Integer, Object> parameters = new HashMap<>();
        StringBuilder sb = new StringBuilder();
        sb.append("select * from t6571percepcion t ");
        sb.append("where t.num_ruc = ? and t.cod_cpe = ? and t.num_serie_cpe = ? and t.num_cpe = ? ");
        
        //seteamos los parametros
        parameters.put(1, comprobantePK.getNumRuc());
        parameters.put(2, comprobantePK.getCodCpe());
        parameters.put(3, comprobantePK.getNumSerieCpe());
        parameters.put(4, comprobantePK.getNumCpe());        
        
        int index = 5;
        if (rucReceptor!= null) {
            sb.append("and t.num_doc_recep = ? ");
            parameters.put(index++, rucReceptor);
        }
        Percepcion element;
        try {
            Query query = entityManager.createNativeQuery(sb.toString(), Percepcion.class);
            
             // Añadimos los parametros a la consulta
            parameters.entrySet().forEach((entry) -> {
                query.setParameter(entry.getKey(), entry.getValue());
            });
            
            element = (Percepcion)query.getSingleResult();
        } catch ( NoResultException nre) {
            utilLog.imprimirLog(ConstantesUtils.LEVEL_ERROR, nre.getMessage());
            element = null;
        } catch (Exception e) {
            utilLog.imprimirLog(ConstantesUtils.LEVEL_ERROR, e.getMessage());
            element = null;
        }
        return element;
    }
    
    @Override
    public List<PerDocRel> obtenerDetallePercepcion(ComprobantePK comprobantePK) {
        // Usamos un Map para almacenar los parametros de la consulta
        Map<Integer, Object> parameters = new HashMap<>();
        
        StringBuilder sb = new StringBuilder();
        sb.append("select * from t6572perdocrel t ");
        sb.append("where t.num_ruc = ? and t.cod_cpe = ? and t.num_serie_cpe = ? and t.num_cpe = ? ");
        
        //seteamos los parametros
        parameters.put(1, comprobantePK.getNumRuc());
        parameters.put(2, comprobantePK.getCodCpe());
        parameters.put(3, comprobantePK.getNumSerieCpe());
        parameters.put(4, comprobantePK.getNumCpe());
        
        List<PerDocRel> lst= new ArrayList<>();
        try {    	
        	Query query = entityManager.createNativeQuery(sb.toString());  
                
                 // Añadimos los parametros a la consulta
                    parameters.entrySet().forEach((entry) -> {
                        query.setParameter(entry.getKey(), entry.getValue());
                    });
            
        	List<Object[]> rows  = query.getResultList();

        	for (Object[] row : rows) {
        		PerDocRel perDocRel = new PerDocRel();
        		PerDocRelPK perDocRelPK = new PerDocRelPK();
        		perDocRelPK.setNumRuc(row[0].toString());
        		perDocRelPK.setCodCpe(row[1].toString());
        		perDocRelPK.setNumSerieCpe(row[2].toString());
        		perDocRelPK.setNumCpe( Integer.parseInt(row[3].toString()));
        		perDocRel.setPerDocRelPK(perDocRelPK);
        		perDocRel.setCodTipCpeRel(row[4].toString());
        		perDocRel.setNumSerieCpeRel(row[5].toString());
        		perDocRel.setNumCpeRel(row[6].toString());
        		perDocRel.setNumPago(row[7].toString());
        		perDocRel.setFecEmiCpeRel((Date)row[8]);
        		perDocRel.setMtoTotalCpeRel((BigDecimal)row[9]);
        		perDocRel.setCodMonedaCpeRel(row[10].toString());
        		perDocRel.setFecPago((Date)row[11]);
        		perDocRel.setMtoPago((BigDecimal)row[12]);
        		perDocRel.setCodMonedaPago(row[13].toString());
        		perDocRel.setMtoPer((BigDecimal)row[14]);
        		perDocRel.setFecPer((Date)row[15]);
        		perDocRel.setMtoCobrado((BigDecimal)row[16]);
        		perDocRel.setIndTipCalculo(row[17].toString());
        		perDocRel.setMtoTipCambio((BigDecimal)row[18]);
        		perDocRel.setIndCpeRelRev(row[19].toString());
        		perDocRel.setFecRegis((Date)row[20]);
        		perDocRel.setCodUsuRegis(row[21].toString());
        		perDocRel.setFecModif((Date)row[22]);
        		perDocRel.setCodUsuModif(row[23].toString());
        		      		
        		lst.add(perDocRel);      	
        	}

    
        } catch ( NoResultException nre) {
            utilLog.imprimirLog(ConstantesUtils.LEVEL_ERROR, nre.getMessage());
            lst = null;
        } catch (Exception e) {
            utilLog.imprimirLog(ConstantesUtils.LEVEL_ERROR, e.getMessage());
            lst = null;
        }
        return lst;
    }
    
    @Override
    public List<Percepcion> obtenerComprobantesxFiltro(ComprobantePK comprobantePK,String fechaIni,String fechaFin,int NumIni,int NumFin,String codIdDoc,String numIdDoc,String codEstado) {
        List<Percepcion> lista = new ArrayList<>();
        // Usamos un Map para almacenar los parametros de la consulta
        Map<Integer, Object> parameters = new HashMap<>();
        
        StringBuilder sb = new StringBuilder();

        sb.append("select "
        		+ " num_ruc,cod_tip_doc_recep,num_doc_recep,des_nom_recep,"
        		+ "cod_cpe,num_serie_cpe,num_cpe,fec_emi,fec_regis,cod_est_cpe,ind_procedencia,cod_reg_per,mto_total_cobrado,mto_total_per from t6571percepcion t ");
        sb.append("where ");
        
        int index = 1;
        if ( comprobantePK.getNumRuc()!= null&& !comprobantePK.getNumRuc().isEmpty()) {
            sb.append("t.num_ruc = ? ");
            parameters.put(index++, comprobantePK.getNumRuc());
            if ( comprobantePK.getCodCpe()!= null) {
                sb.append("and t.cod_cpe = ? ");
                parameters.put(index++, comprobantePK.getCodCpe());
            }
        }else{
            if ( comprobantePK.getCodCpe()!= null) {
                sb.append("t.cod_cpe = ? ");
                parameters.put(index++, comprobantePK.getCodCpe());
            }
        }

        //ind_estado
        if ( codEstado!= null && !codEstado.isEmpty()) {
            if (!codEstado.equals(Constantes.COD_ESTADO_TODOS)) {
            sb.append("and t.cod_est_cpe = ? ");
            parameters.put(index++, codEstado);
            }
        }
        //cod_docide_recep
        if ( codIdDoc!= null && !codIdDoc.isEmpty()) {
            sb.append("and t.cod_tip_doc_recep in (?,?,?) " );
            parameters.put(index++, codIdDoc);
            parameters.put(index++, codIdDoc+" ");
            parameters.put(index++, "0"+codIdDoc);
        }
        //num_docide_recep
        if ( numIdDoc!= null) {
            sb.append("and t.num_doc_recep = ? ");
            parameters.put(index++, numIdDoc);
            
        }
        if ((NumIni>0 && NumFin>0 ) && (NumIni!=0 && NumFin!=0)) {
            sb.append("and t.num_cpe >= ? and t.num_cpe <= ? ");
            parameters.put(index++, NumIni);
            parameters.put(index++, NumFin);
        }
        
        if (comprobantePK.getNumSerieCpe() != null) {
        	sb.append("and t.num_serie_cpe = ? ");
                parameters.put(index++, comprobantePK.getNumSerieCpe());
        } 

        if (fechaIni != null && fechaFin != null) {
            DateTimeFormatter FORMATTER = DateTimeFormat.forPattern(Constantes.DATE_FORMAT);
            DateTime fechaInicio = FORMATTER.parseDateTime(fechaIni);
            LocalDate fechaInicioLocalDate = fechaInicio.toLocalDate();

            DateTime fechaFinal= FORMATTER.parseDateTime(fechaFin);
            LocalDate fechaFinalLocalDate = fechaFinal.toLocalDate();
            sb.append("and t.fec_emi >= ? and t.fec_emi <= ? ");
            parameters.put(index++, fechaInicioLocalDate.toString() + " 00:00:00");
            parameters.put(index++, fechaFinalLocalDate.toString() + " 23:59:59");
        }
        
        sb.append("order by t.fec_emi,t.fec_regis desc LIMIT ").append(Integer.parseInt(properties.getParamLimitInformix())+1);

        try {
            Query query = entityManager.createNativeQuery(sb.toString());
            
             // Añadimos los parametros a la consulta
            parameters.entrySet().forEach((entry) -> {
                query.setParameter(entry.getKey(), entry.getValue());
            });
            
            List<Object[]> rows  = query.getResultList();
            for (Object[] row : rows) {
            	Percepcion comprobante = new Percepcion();
                PercepcionPK compPK= new PercepcionPK();
                compPK.setNumRuc(row[0].toString());
                comprobante.setCodTipoDocRecep(row[1].toString());
                comprobante.setNumDocRecep(row[2].toString());
                comprobante.setDesNomRecep(row[3].toString());
                compPK.setCodCpe(row[4].toString());
                compPK.setNumSerieCpe(row[5].toString());
                compPK.setNumCpe((int)row[6]);
                comprobante.setFecEmi((Date)row[7]);
                comprobante.setFecRegis((Date)row[8]);
                comprobante.setCodEstCpe(row[9].toString());
                comprobante.setIndProcedencia(row[10].toString());
                comprobante.setCodRegPer(row[11].toString());
                comprobante.setMtoTotalCobrado((BigDecimal)row[12]);
                comprobante.setMtoTotalPer((BigDecimal)row[13]);
                comprobante.setPercepcionPK(compPK);

                lista.add(comprobante);
            }
        } catch ( NoResultException nre) {
            utilLog.imprimirLog(ConstantesUtils.LEVEL_ERROR, nre.getMessage());
            lista = null;
        } catch (Exception e) {
            utilLog.imprimirLog(ConstantesUtils.LEVEL_ERROR, e.getMessage());
            lista = null;
        }
        return lista;
    }
     
}
