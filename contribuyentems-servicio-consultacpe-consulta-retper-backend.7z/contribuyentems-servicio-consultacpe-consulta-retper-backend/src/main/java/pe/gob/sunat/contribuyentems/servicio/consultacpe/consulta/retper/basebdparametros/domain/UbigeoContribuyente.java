package pe.gob.sunat.contribuyentems.servicio.consultacpe.consulta.retper.basebdparametros.domain;

import java.io.Serializable;

public class UbigeoContribuyente  implements Serializable{

	private static final long serialVersionUID = 1L;
	
	private String codCiudad;
	private String codUbigeo;
	private String desDepartamento;
	private String desProvincia;
	private String desDistrito;
	private String desNomVia;
	private String desNumer1;
	private String codInter1;
	private String desNomZon;
	private String desRefer1;
	private String codTipvia;
	private String codTipZon;
	public String getCodCiudad() {
		return codCiudad;
	}
	public void setCodCiudad(String codCiudad) {
		if(codCiudad.isEmpty()){
			codCiudad = "-";
		} 
		this.codCiudad = codCiudad;
	}
	public String getCodUbigeo() {
		return codUbigeo;
	}
	public void setCodUbigeo(String codUbigeo) {
		if(codUbigeo.isEmpty()){
			codUbigeo = "-";
		} 
		this.codUbigeo = codUbigeo;
	}
	public String getDesDepartamento() {
		return desDepartamento;
	}
	public void setDesDepartamento(String desDepartamento) {
		if(desDepartamento.isEmpty()){
			desDepartamento = "-";
		} 
		this.desDepartamento = desDepartamento;
	}
	public String getDesProvincia() {
		return desProvincia;
	}
	public void setDesProvincia(String desProvincia) {
		if(desProvincia.isEmpty()){
			desProvincia = "-";
		} 
		this.desProvincia = desProvincia;
	}
	public String getDesDistrito() {
		return desDistrito;
	}
	public void setDesDistrito(String desDistrito) {
		if(desDistrito.isEmpty()){
			desDistrito = "-";
		} 
		this.desDistrito = desDistrito;
	}
	public String getDesNomVia() {
		return desNomVia;
	}
	public void setDesNomVia(String desNomVia) {
		if(desNomVia.isEmpty()){
			desNomVia = "-";
		} 
		this.desNomVia = desNomVia;
	}
	public String getDesNumer1() {
		return desNumer1;
	}
	public void setDesNumer1(String desNumer1) {
		this.desNumer1 = desNumer1;
	}
	public String getCodInter1() {
		return codInter1;
	}
	public void setCodInter1(String codInter1) {
		if(codInter1.isEmpty()){
			codInter1 = "-";
		} 
		this.codInter1 = codInter1;
	}
	public String getDesNomZon() {
		return desNomZon;
	}
	public void setDesNomZon(String desNomZon) {
		if(desNomZon.isEmpty()){
			desNomZon = "-";
		} 
		this.desNomZon = desNomZon;
	}
	public String getDesRefer1() {
		return desRefer1;
	}
	public void setDesRefer1(String desRefer1) {
		if(desRefer1.isEmpty()){
			desRefer1 = "-";
		} 
		this.desRefer1 = desRefer1;
	}
	public String getCodTipvia() {
		return codTipvia;
	}
	public void setCodTipvia(String codTipvia) {
		if(codTipvia.isEmpty()){
			codTipvia = "-";
		} 
		this.codTipvia = codTipvia;
	}
	public String getCodTipZon() {
		return codTipZon;
	}
	public void setCodTipZon(String codTipZon) {
		if(codTipZon.isEmpty()){
			codTipZon = "-";
		} 
		this.codTipZon = codTipZon;
	}
	
}
