package pe.gob.sunat.contribuyentems.servicio.consultacpe.consulta.retper.main.config;

import pe.gob.sunat.tecnologia.arquitectura.framework.mongodb.config.MongoDBConfig;
//import pe.gob.sunat.tecnologia.arquitectura.framework.mongodb.config.MongoDBConfig;
//import pe.gob.sunat.tecnologia3.arquitectura.framework.kafka.config.KafkaConsumerConfig;
//import pe.gob.sunat.tecnologia3.arquitectura.framework.kafka.config.KafkaProducerConfig;
import pe.gob.sunat.tecnologiams.arquitectura.framework.core.config.MicroserviceConfig;

public class ConsultaCpeConfig extends MicroserviceConfig {

    private static ConsultaCpeConfig config;
    private MongoDBConfig mongodb;
    private ParamConfig paramconfig;
    // private KafkaProducerConfig kafkaProducer;
    // private KafkaConsumerConfig kafkaConsumer;

    public static ConsultaCpeConfig getConfig() {
        return config;
    }

    public void loadConfig() {
        ConsultaCpeConfig.config = this;
    }

    public MongoDBConfig getMongodb() {
        return mongodb;
    }

    public void setMongodb(MongoDBConfig mongodb) {
        this.mongodb = mongodb;
    }

    public ParamConfig getParamconfig() {
        return paramconfig;
    }

    public void setParamconfig(ParamConfig paramconfig) {
        this.paramconfig = paramconfig;
    }

    /*
     * public KafkaProducerConfig getKafkaProducer() { return kafkaProducer; }
     *
     * public void setKafkaProducer(KafkaProducerConfig kafkaProducer) {
     * this.kafkaProducer = kafkaProducer; }
     *
     * public KafkaConsumerConfig getKafkaConsumer() { return kafkaConsumer; }
     *
     * public void setKafkaConsumer(KafkaConsumerConfig kafkaConsumer) {
     * this.kafkaConsumer = kafkaConsumer; }
     */
}