package pe.gob.sunat.contribuyentems.servicio.consultacpe.consulta.retper.main.config;

public class Pagina {
    private Integer numPagFront;

    public Integer getNumPagFront() {
        return numPagFront;
    }

    public void setNumPagFront(Integer numPagFront) {
        this.numPagFront = numPagFront;
    }
}
