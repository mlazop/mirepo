package pe.gob.sunat.contribuyentems.servicio.consultacpe.consulta.retper.main;

import io.dropwizard.server.DefaultServerFactory;
import io.dropwizard.setup.Bootstrap;
import io.dropwizard.setup.Environment;
import io.dropwizard.views.ViewBundle;
import org.glassfish.jersey.media.multipart.MultiPartFeature;
import pe.gob.sunat.contribuyentems.servicio.consultacpe.consulta.retper.main.config.ConsultaCpeConfig;
import pe.gob.sunat.contribuyentems.servicio.consultacpe.consulta.retper.util.exceptions.UnprocessableEntityExceptionMapper;
import pe.gob.sunat.contribuyentems.servicio.consultacpe.consulta.retper.ws.rest.ComprobanteRestService;
import pe.gob.sunat.tecnologiams.arquitectura.framework.core.exception.GenericExceptionMapper;
import pe.gob.sunat.tecnologiams.arquitectura.framework.core.exception.ObjectNotFoundExceptionMapper;

public class ConsultaCpeApplication extends pe.gob.sunat.contribuyentems.servicio.consultacpe.consulta.retper.core.ConsultaCpeBaseApplication<ConsultaCpeConfig> {

	@Override
	public void onRun(ConsultaCpeConfig myConfig, Environment environment) throws Exception {
		environment.jersey().register(ObjectNotFoundExceptionMapper.class);
		environment.jersey().register(GenericExceptionMapper.class);
		environment.jersey().register(UnprocessableEntityExceptionMapper.class);
		environment.jersey().register(ComprobanteRestService.class);
		myConfig.loadConfig();
		myConfig.getMongodb().loadConfig();
	}

	@Override
	public void onInitialize(Bootstrap<ConsultaCpeConfig> bootstrap) {
		// Empty implementation for default
		bootstrap.addBundle(new ViewBundle<>());
	}
	public static void main(String... params) throws Exception {
		new ConsultaCpeApplication().run(params);
	}

}
