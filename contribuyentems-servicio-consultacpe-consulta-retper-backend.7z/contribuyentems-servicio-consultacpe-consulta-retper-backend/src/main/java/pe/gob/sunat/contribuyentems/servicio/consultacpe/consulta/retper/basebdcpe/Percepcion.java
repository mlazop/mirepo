package pe.gob.sunat.contribuyentems.servicio.consultacpe.consulta.retper.basebdcpe;

import com.fasterxml.jackson.databind.annotation.JsonSerialize;
import com.fasterxml.jackson.databind.ser.std.ToStringSerializer;
import org.bson.codecs.pojo.annotations.BsonId;

import javax.persistence.Column;
import javax.persistence.EmbeddedId;
import javax.persistence.Entity;
import javax.persistence.Table;
import java.io.Serializable;
import java.math.BigDecimal;
import java.util.Date;

@Entity
@Table(name = "t6571percepcion")
public class Percepcion implements Serializable {
    private static final long serialVersionUID = 1L;

    @BsonId
    @JsonSerialize(using = ToStringSerializer.class)
    @EmbeddedId
    public PercepcionPK percepcionPK;
    @Column(name="cod_tip_doc_recep")
    public String codTipoDocRecep;
    @Column(name="num_doc_recep")
    public String numDocRecep;
    @Column(name="des_nom_recep")
    public String desNomRecep;
    @Column(name="fec_emi")
    public Date fecEmi;
    @Column(name="cod_reg_per")
    public String codRegPer;
    @Column(name="des_observacion")
    public String desObservacion;
    @Column(name="mto_total_per")
    public BigDecimal mtoTotalPer;
    @Column(name="mto_total_cobrado")
    public BigDecimal MtoTotalCobrado;
    @Column(name="cod_est_cpe")
    public String codEstCpe;
    @Column(name="ind_procedencia")
    public String indProcedencia;
    @Column(name="ind_cpe_fisico")
    public String indCpeFisico;
    @Column(name="des_motivo_rev")
    public String desMotivoRev;
    @Column(name="fec_rev")
    public Date fecRev;
    @Column(name="cod_usu_rev")
    public String codUsuRev;
    @Column(name="num_ticket")
    public String numTicket;
    @Column(name="cod_correo_recep")
    public String codCorreoRecep;
    @Column(name="cod_mot_contin")
    public String codMotContin;
    @Column(name="num_periodo")
    public String numPeriodo;
    @Column(name="mto_base_calculo")
    public BigDecimal mtoBaseCalculo;
    @Column(name="ind_reemp_rev")
    public String indReempRev;
    @Column(name="fec_regis")	
    public Date FecRegis;
    @Column(name="cod_usuregis")
    public String codUsuregis;
    @Column(name="fec_modif")
    public Date fecModif;
    @Column(name="cod_usumodif")
    public String codUsumodif;
    
    
	public PercepcionPK getPercepcionPK() {
		return percepcionPK;
	}
	public void setPercepcionPK(PercepcionPK percepcionPK) {
		this.percepcionPK = percepcionPK;
	}
	public String getCodTipoDocRecep() {
		return codTipoDocRecep;
	}
	public void setCodTipoDocRecep(String codTipoDocRecep) {
		this.codTipoDocRecep = codTipoDocRecep;
	}
	public String getNumDocRecep() {
		return numDocRecep;
	}
	public void setNumDocRecep(String numDocRecep) {
		this.numDocRecep = numDocRecep;
	}
	public String getDesNomRecep() {
		return desNomRecep;
	}
	public void setDesNomRecep(String desNomRecep) {
		this.desNomRecep = desNomRecep;
	}
	public Date getFecEmi() {
		return fecEmi;
	}
	public void setFecEmi(Date fecEmi) {
		this.fecEmi = fecEmi;
	}
	public String getCodRegPer() {
		return codRegPer;
	}
	public void setCodRegPer(String codRegPer) {
		this.codRegPer = codRegPer;
	}
	public String getDesObservacion() {
		return desObservacion;
	}
	public void setDesObservacion(String desObservacion) {
		this.desObservacion = desObservacion;
	}
	public BigDecimal getMtoTotalPer() {
		return mtoTotalPer;
	}
	public void setMtoTotalPer(BigDecimal mtoTotalPer) {
		this.mtoTotalPer = mtoTotalPer;
	}
	public BigDecimal getMtoTotalCobrado() {
		return MtoTotalCobrado;
	}
	public void setMtoTotalCobrado(BigDecimal mtoTotalCobrado) {
		MtoTotalCobrado = mtoTotalCobrado;
	}
	public String getCodEstCpe() {
		return codEstCpe;
	}
	public void setCodEstCpe(String codEstCpe) {
		this.codEstCpe = codEstCpe;
	}
	public String getIndProcedencia() {
		return indProcedencia;
	}
	public void setIndProcedencia(String indProcedencia) {
		this.indProcedencia = indProcedencia;
	}
	public String getIndCpeFisico() {
		return indCpeFisico;
	}
	public void setIndCpeFisico(String indCpeFisico) {
		this.indCpeFisico = indCpeFisico;
	}
	public String getDesMotivoRev() {
		return desMotivoRev;
	}
	public void setDesMotivoRev(String desMotivoRev) {
		this.desMotivoRev = desMotivoRev;
	}
	public Date getFecRev() {
		return fecRev;
	}
	public void setFecRev(Date fecRev) {
		this.fecRev = fecRev;
	}
	public String getCodUsuRev() {
		return codUsuRev;
	}
	public void setCodUsuRev(String codUsuRev) {
		this.codUsuRev = codUsuRev;
	}
	public String getNumTicket() {
		return numTicket;
	}
	public void setNumTicket(String numTicket) {
		this.numTicket = numTicket;
	}
	public String getCodCorreoRecep() {
		return codCorreoRecep;
	}
	public void setCodCorreoRecep(String codCorreoRecep) {
		this.codCorreoRecep = codCorreoRecep;
	}
	public String getCodMotContin() {
		return codMotContin;
	}
	public void setCodMotContin(String codMotContin) {
		this.codMotContin = codMotContin;
	}
	public String getNumPeriodo() {
		return numPeriodo;
	}
	public void setNumPeriodo(String numPeriodo) {
		this.numPeriodo = numPeriodo;
	}
	public BigDecimal getMtoBaseCalculo() {
		return mtoBaseCalculo;
	}
	public void setMtoBaseCalculo(BigDecimal mtoBaseCalculo) {
		this.mtoBaseCalculo = mtoBaseCalculo;
	}
	public String getIndReempRev() {
		return indReempRev;
	}
	public void setIndReempRev(String indReempRev) {
		this.indReempRev = indReempRev;
	}
	public Date getFecRegis() {
		return FecRegis;
	}
	public void setFecRegis(Date fecRegis) {
		FecRegis = fecRegis;
	}
	public String getCodUsuregis() {
		return codUsuregis;
	}
	public void setCodUsuregis(String codUsuregis) {
		this.codUsuregis = codUsuregis;
	}
	public Date getFecModif() {
		return fecModif;
	}
	public void setFecModif(Date fecModif) {
		this.fecModif = fecModif;
	}
	public String getCodUsumodif() {
		return codUsumodif;
	}
	public void setCodUsumodif(String codUsumodif) {
		this.codUsumodif = codUsumodif;
	}
	public static long getSerialversionuid() {
		return serialVersionUID;
	}


    

}
