package pe.gob.sunat.contribuyentems.servicio.consultacpe.consulta.retper.basebdrecauda;

import javax.persistence.Column;
import javax.persistence.Embeddable;
import java.io.Serializable;
@Embeddable
public class ParamPK implements   Serializable {
    private static final long serialVersionUID = -4582067725772956170L;

	@Column(name = "t01_argumento")
	private String t01Argumento;

	@Column(name = "t01_numero")
	private String t01Numero;

	@Column(name = "t01_tipo")
	private String t01Tipo;

	public String getT01Argumento() {
		return t01Argumento;
	}

	public void setT01Argumento(String t01Argumento) {
		this.t01Argumento = t01Argumento;
	}

	public String getT01Numero() {
		return t01Numero;
	}

	public void setT01Numero(String t01Numero) {
		this.t01Numero = t01Numero;
	}

	public String getT01Tipo() {
		return t01Tipo;
	}

	public void setT01Tipo(String t01Tipo) {
		this.t01Tipo = t01Tipo;
	}
	
	

}
