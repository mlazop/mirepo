package pe.gob.sunat.contribuyentems.servicio.consultacpe.consulta.retper.util;
import org.apache.commons.lang3.StringUtils;
public enum RubrosEnum {
   RUBRO_988("988"),
   RUBRO_989("989"),
    RUBRO_986("986"),
    RUBRO_987("987"),
    RUBRO_962("962"),
    RUBRO_960("960"),
    RUBRO_959("959"),
    RUBRO_201("201"),
    RUBRO_120("120"),
    RUBRO_134("134"),
    RUBRO_101("101"),
    RUBRO_166("166"),
    RUBRO_102("102"),
    RUBRO_130("130"),
    RUBRO_103("103"),
    RUBRO_104("104"),
    RUBRO_106("106"),
    RUBRO_105("105"),
    RUBRO_107("107"),
    RUBRO_984("984"),
 RUBRO_995("995");
    private RubrosEnum(String code ) {
        this.code = code;
    }
    private String code;
    public String getCode() {
        return code;
    }

}
