package pe.gob.sunat.contribuyentems.servicio.consultacpe.consulta.retper.basebdconsultacpe.domain;

import java.io.Serializable;
import java.util.Date;
import java.util.List;

import com.fasterxml.jackson.annotation.JsonFormat;

import pe.gob.sunat.contribuyentems.servicio.consultacpe.consulta.retper.basebdconsultacpe.domain.Contribuyente;
import pe.gob.sunat.contribuyentems.servicio.consultacpe.consulta.retper.basebdconsultacpe.domain.PkComprobante;
import pe.gob.sunat.contribuyentems.servicio.consultacpe.consulta.retper.util.Constantes;

public class Percepcion implements Serializable{
	
	private static final long serialVersionUID = 1577456876627633730L;

	//datos de percepcion
		private PkComprobante pkPercepcion;
		private Contribuyente emisor;
		private Contribuyente receptor;
		
		@JsonFormat(shape = JsonFormat.Shape.STRING, pattern = Constantes.DATE_FORMAT)
		private Date fechaEmision;
		private String codRegimenPer;
		private String desRegimenPer;
		private String factorRegimenPer;
		private double porcentajePer;
		private String descObservacion;
		private double montoTotalPercibido;
		private String codMonedaMontoTotalPercibido;
		private double montoTotalCobrado;
		private String codMonedaMontoTotalCobrado;
		private String codEstadoCpe;
		private String indProcedencia;
		private String indCompFisico;
		private String codCorreoRecep;
		private String codMotivoContin;
		//datos complementarios
		private String usuario;
		private long ticket;
		// hquispeon - Agregar revertido
		private String numPeriodo;
		private double montoBaseCalculo;
		private String indReemplazoReversion;
		//documentos relacionados
		private List<DocRelacionadoPer> lstDocRel;
		
		

		public PkComprobante getPkPercepcion() {
			return pkPercepcion;
		}

		public void setPkPercepcion(PkComprobante pkPercepcion) {
			this.pkPercepcion = pkPercepcion;
		}

		public Contribuyente getEmisor() {
			return emisor;
		}

		public void setEmisor(Contribuyente emisor) {
			this.emisor = emisor;
		}

		public Contribuyente getReceptor() {
			return receptor;
		}

		public void setReceptor(Contribuyente receptor) {
			this.receptor = receptor;
		}

		public Date getFechaEmision() {
			return fechaEmision;
		}

		public void setFechaEmision(Date fechaEmision) {
			this.fechaEmision = fechaEmision;
		}

		public String getCodRegimenPer() {
			return codRegimenPer;
		}

		public void setCodRegimenPer(String codRegimenPer) {
			this.codRegimenPer = codRegimenPer;
		}

		public String getDesRegimenPer() {
			return desRegimenPer;
		}

		public void setDesRegimenPer(String desRegimenPer) {
			this.desRegimenPer = desRegimenPer;
		}

		public String getFactorRegimenPer() {
			return factorRegimenPer;
		}

		public void setFactorRegimenPer(String factorRegimenPer) {
			this.factorRegimenPer = factorRegimenPer;
		}

		public double getPorcentajePer() {
			return porcentajePer;
		}

		public void setPorcentajePer(double porcentajePer) {
			this.porcentajePer = porcentajePer;
		}

		public String getDescObservacion() {
			return descObservacion;
		}

		public void setDescObservacion(String descObservacion) {
			this.descObservacion = descObservacion;
		}

		public double getMontoTotalPercibido() {
			return montoTotalPercibido;
		}

		public void setMontoTotalPercibido(double montoTotalPercibido) {
			this.montoTotalPercibido = montoTotalPercibido;
		}

		public String getCodMonedaMontoTotalPercibido() {
			return codMonedaMontoTotalPercibido;
		}

		public void setCodMonedaMontoTotalPercibido(String codMonedaMontoTotalPercibido) {
			this.codMonedaMontoTotalPercibido = codMonedaMontoTotalPercibido;
		}

		public double getMontoTotalCobrado() {
			return montoTotalCobrado;
		}

		public void setMontoTotalCobrado(double montoTotalCobrado) {
			this.montoTotalCobrado = montoTotalCobrado;
		}

		public String getCodMonedaMontoTotalCobrado() {
			return codMonedaMontoTotalCobrado;
		}

		public void setCodMonedaMontoTotalCobrado(String codMonedaMontoTotalCobrado) {
			this.codMonedaMontoTotalCobrado = codMonedaMontoTotalCobrado;
		}

		public String getCodEstadoCpe() {
			return codEstadoCpe;
		}

		public void setCodEstadoCpe(String codEstadoCpe) {
			this.codEstadoCpe = codEstadoCpe;
		}

		public String getIndProcedencia() {
			return indProcedencia;
		}

		public void setIndProcedencia(String indProcedencia) {
			this.indProcedencia = indProcedencia;
		}

		public String getIndCompFisico() {
			return indCompFisico;
		}

		public void setIndCompFisico(String indCompFisico) {
			this.indCompFisico = indCompFisico;
		}

		public String getCodCorreoRecep() {
			return codCorreoRecep;
		}

		public void setCodCorreoRecep(String codCorreoRecep) {
			this.codCorreoRecep = codCorreoRecep;
		}

		public String getCodMotivoContin() {
			return codMotivoContin;
		}

		public void setCodMotivoContin(String codMotivoContin) {
			this.codMotivoContin = codMotivoContin;
		}

		public String getUsuario() {
			return usuario;
		}

		public void setUsuario(String usuario) {
			this.usuario = usuario;
		}

		public long getTicket() {
			return ticket;
		}

		public void setTicket(long ticket) {
			this.ticket = ticket;
		}

		public List<DocRelacionadoPer> getLstDocRel() {
			return lstDocRel;
		}

		public void setLstDocRel(List<DocRelacionadoPer> lstDocRel) {
			this.lstDocRel = lstDocRel;
		}

		public String getNumPeriodo() {
			return numPeriodo;
		}

		public void setNumPeriodo(String numPeriodo) {
			this.numPeriodo = numPeriodo;
		}

		public double getMontoBaseCalculo() {
			return montoBaseCalculo;
		}

		public void setMontoBaseCalculo(double montoBaseCalculo) {
			this.montoBaseCalculo = montoBaseCalculo;
		}

		public String getIndReemplazoReversion() {
			return indReemplazoReversion;
		}

		public void setIndReemplazoReversion(String indReemplazoReversion) {
			this.indReemplazoReversion = indReemplazoReversion;
		}	
	
}
