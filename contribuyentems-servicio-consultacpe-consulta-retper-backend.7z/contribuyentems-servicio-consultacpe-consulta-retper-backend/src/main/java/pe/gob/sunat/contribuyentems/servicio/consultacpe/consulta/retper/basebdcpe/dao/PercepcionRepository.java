package pe.gob.sunat.contribuyentems.servicio.consultacpe.consulta.retper.basebdcpe.dao;
import pe.gob.sunat.contribuyentems.servicio.consultacpe.consulta.retper.basebdcpe.ComprobantePK;
import pe.gob.sunat.contribuyentems.servicio.consultacpe.consulta.retper.basebdcpe.PerDocRel;
import pe.gob.sunat.contribuyentems.servicio.consultacpe.consulta.retper.basebdcpe.Percepcion;
import pe.gob.sunat.contribuyentems.servicio.consultacpe.consulta.retper.basebdcpe.PercepcionPK;
import pe.gob.sunat.contribuyentems.servicio.consultacpe.consulta.retper.basebdcpe.Retencion;
import pe.gob.sunat.tecnologiams.arquitectura.framework.jpa.dao.BaseDao;

import java.util.Date;
import java.util.List;

public interface PercepcionRepository extends BaseDao<Percepcion, PercepcionPK> {
    public Date obtenerFechaEmision(ComprobantePK comprobantePK, String rucReceptor);
    
    public List<PerDocRel> obtenerDetallePercepcion(ComprobantePK comprobantePK);

    public Percepcion obtenerComprobante(ComprobantePK comprobantePK, String rucReceptor);
    
    public List<Percepcion> obtenerComprobantesxFiltro(
    		ComprobantePK comprobantePK,String fechaIni,String fechaFin,int NumIni,
    		int NumFin,String codIdDoc,String numIdDoc,String codEstado);

}
