package pe.gob.sunat.contribuyentems.servicio.consultacpe.consulta.retper.basebdcpe;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Embeddable;

@Embeddable
public class RetencionXMLPK implements Serializable{
	
	private static final long serialVersionUID = -8648030054793352647L;
	@Column(name="num_ticket")
	private Long numTicket;
    @Column(name="ind_modo")
	private String indModo;
	public Long getNumTicket() {
		return numTicket;
	}
	public void setNumTicket(Long numTicket) {
		this.numTicket = numTicket;
	}
	public String getIndModo() {
		return indModo;
	}
	public void setIndModo(String indModo) {
		this.indModo = indModo;
	}
    
    

}
