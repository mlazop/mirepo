package pe.gob.sunat.contribuyentems.servicio.consultacpe.consulta.retper.domain;

import java.io.Serializable;
import java.util.Date;
import java.util.List;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;

import pe.gob.sunat.contribuyentems.servicio.consultacpe.consulta.retper.util.Constantes;

import java.math.BigDecimal;

public class Comprobantes implements Serializable {

    private DatosEmisor datosEmisor;

    private DatosReceptor datosReceptor;

    private String codCpe;
    private String numSerie;
    private int numCpe;
    @JsonFormat(shape = JsonFormat.Shape.STRING, pattern = Constantes.DATE_FORMAT)
    private Date fecEmision;
    @JsonFormat(shape = JsonFormat.Shape.STRING, pattern = Constantes.DATE_FORMAT)
    private Date fecRegistro;
    private String indEstadoCpe;
    private String indProcedencia;
    @JsonInclude(Include.NON_NULL)
    private String regPercepcion;
    @JsonInclude(Include.NON_NULL)
    private String regRetencion;
    
    @JsonInclude(Include.NON_NULL)
    private BigDecimal mtoTotalPer;
    @JsonInclude(Include.NON_NULL)
    private BigDecimal MtoTotalCobrado;

    @JsonInclude(Include.NON_NULL)
    private BigDecimal mtoTotalRet;
    @JsonInclude(Include.NON_NULL)
    private BigDecimal mtoRedondeo;
    @JsonInclude(Include.NON_NULL)
    private String ubigeo;
    
    @JsonInclude(Include.NON_NULL)
    private String codEstCpe;
    
    @JsonInclude(Include.NON_NULL)
    @JsonFormat(shape = JsonFormat.Shape.STRING, pattern = Constantes.DATE_FORMAT)
    private Date fecReversion;
    
    private String observacion;
    
    private String motivoReversion;
    
    private String indReempReve;
    
    public String getCodEstCpe() {
		return codEstCpe;
	}

	public void setCodEstCpe(String codEstCpe) {
		this.codEstCpe = codEstCpe;
	}

	public Date getFecReversion() {
		return fecReversion;
	}

	public void setFecReversion(Date fecReversion) {
		this.fecReversion = fecReversion;
	}

	public String getUbigeo() {
		return ubigeo;
	}

	public void setUbigeo(String ubigeo) {
		if(ubigeo.isEmpty()){
			ubigeo = "-";
		} 
		this.ubigeo = ubigeo;
	}

	@JsonInclude(Include.NON_NULL)
    private List<InformacionItems> informacionItems;

    public String getCodCpe() {
        return codCpe;
    }

    public void setCodCpe(String codCpe) {
        this.codCpe = codCpe;
    }

    public String getNumSerie() {
        return numSerie;
    }

    public void setNumSerie(String numSerie) {
        this.numSerie = numSerie;
    }

    public int getNumCpe() {
        return numCpe;
    }

    public void setNumCpe(int numCpe) {
        this.numCpe = numCpe;
    }

    public BigDecimal getMtoRedondeo() {
        return mtoRedondeo;
    }

    public void setMtoRedondeo(BigDecimal mtoRedondeo) {
        this.mtoRedondeo = mtoRedondeo;
    }

    public Date getFecEmision() {
        return fecEmision;
    }

    public void setFecEmision(Date fecEmision) {
        this.fecEmision = fecEmision;
    }

    public Date getFecRegistro() {
        return fecRegistro;
    }

    public void setFecRegistro(Date fecRegistro) {
        this.fecRegistro = fecRegistro;
    }

    public String getIndEstadoCpe() {
        return indEstadoCpe;
    }

    public void setIndEstadoCpe(String indEstadoCpe) {
        this.indEstadoCpe = indEstadoCpe;
    }

    public String getIndProcedencia() {
        return indProcedencia;
    }

    public void setIndProcedencia(String indProcedencia) {
        this.indProcedencia = indProcedencia;
    }

    public String getRegPercepcion() {
        return regPercepcion;
    }

    public void setRegPercepcion(String regPercepcion) {
        this.regPercepcion = regPercepcion;
    }

    public String getRegRetencion() {
        return regRetencion;
    }

    public void setRegRetencion(String regRetencion) {
        this.regRetencion = regRetencion;
    }

    public DatosEmisor getDatosEmisor() {
        return datosEmisor;
    }

    public void setDatosEmisor(DatosEmisor datosEmisor) {
        this.datosEmisor = datosEmisor;
    }

    public DatosReceptor getDatosReceptor() {
        return datosReceptor;
    }

    public void setDatosReceptor(DatosReceptor datosReceptor) {
        this.datosReceptor = datosReceptor;
    }

    /**
     * @return the informacionItemsPer
     */
    public List<InformacionItems> getInformacionItems() {
        return informacionItems;
    }

    /**
     * @param informacionItemsPer the informacionItemsPer to set
     */
    public void setInformacionItems(List<InformacionItems> informacionItems) {
        this.informacionItems = informacionItems;
    }

    /**
     * @return the mtoTotalPer
     */
    public BigDecimal getMtoTotalPer() {
        return mtoTotalPer;
    }

    /**
     * @param mtoTotalPer the mtoTotalPer to set
     */
    public void setMtoTotalPer(BigDecimal mtoTotalPer) {
        this.mtoTotalPer = mtoTotalPer;
    }

    /**
     * @return the MtoTotalCobrado
     */
    public BigDecimal getMtoTotalCobrado() {
        return MtoTotalCobrado;
    }

    /**
     * @param MtoTotalCobrado the MtoTotalCobrado to set
     */
    public void setMtoTotalCobrado(BigDecimal MtoTotalCobrado) {
        this.MtoTotalCobrado = MtoTotalCobrado;
    }

    /**
     * @return the mtoTotalRet
     */
    public BigDecimal getMtoTotalRet() {
        return mtoTotalRet;
    }

    /**
     * @param mtoTotalRet the mtoTotalRet to set
     */
    public void setMtoTotalRet(BigDecimal mtoTotalRet) {
        this.mtoTotalRet = mtoTotalRet;
    }

	public String getObservacion() {
		return observacion;
	}

	public void setObservacion(String observacion) {
		this.observacion = observacion;
	}

	public String getMotivoReversion() {
		return motivoReversion;
	}

	public void setMotivoReversion(String motivoReversion) {
		this.motivoReversion = motivoReversion;
	}

	public String getIndReempReve() {
		return indReempReve;
	}

	public void setIndReempReve(String indReempReve) {
		this.indReempReve = indReempReve;
	}

}
