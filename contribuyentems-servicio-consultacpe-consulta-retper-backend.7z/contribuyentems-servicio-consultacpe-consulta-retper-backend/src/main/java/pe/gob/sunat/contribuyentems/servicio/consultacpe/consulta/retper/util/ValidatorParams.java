package pe.gob.sunat.contribuyentems.servicio.consultacpe.consulta.retper.util;

import org.apache.commons.lang3.StringUtils;
import pe.gob.sunat.contribuyentems.servicio.consultacpe.consulta.retper.util.exceptions.ErrorEnum;
import pe.gob.sunat.contribuyentems.servicio.consultacpe.consulta.retper.util.exceptions.ErrorMessage;
import pe.gob.sunat.contribuyentems.servicio.consultacpe.consulta.retper.util.exceptions.UnprocessableEntityException;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Arrays;
import java.util.Calendar;
import java.util.Date;

public class ValidatorParams {

    public void checkNumRuc(String numRuc) throws UnprocessableEntityException {
        if (StringUtils.isBlank(numRuc) || numRuc==null) {
            throw new UnprocessableEntityException(new ErrorMessage(ErrorEnum.ERROR_100));
        }

        if (Constantes.NUM_RUC_SIZE != numRuc.length()) {
            throw new UnprocessableEntityException(new ErrorMessage(ErrorEnum.ERROR_101));
        }
    }
    public void checkNumRucEmisor(String numRucEmisor,String numRucLogeado,String codFiltroCpe ) throws UnprocessableEntityException {
        if(codFiltroCpe.equals(Constantes.COD_CPE_EMISOR)) {
            if (StringUtils.isBlank(numRucEmisor)) {
                throw new UnprocessableEntityException(new ErrorMessage(ErrorEnum.ERROR_102));
            }
            if (!numRucLogeado.equals(numRucEmisor)) {
                throw new UnprocessableEntityException(new ErrorMessage(ErrorEnum.ERROR_105));
            }
        } else{
            if(codFiltroCpe.equals(Constantes.COD_CPE_RECEPTOR)){
                if (numRucEmisor.equals(numRucLogeado)) {
                    throw new UnprocessableEntityException(new ErrorMessage(ErrorEnum.ERROR_104));
                }
            }
        }

        if (Constantes.NUM_RUC_SIZE != numRucEmisor.length()) {
            throw new UnprocessableEntityException(new ErrorMessage(ErrorEnum.ERROR_101));
        }
        if(Constantes.COD_CPE_EMISOR.equals(codFiltroCpe)) {
            if (null==numRucEmisor || StringUtils.isBlank(numRucEmisor)) {
                throw new UnprocessableEntityException(new ErrorMessage(ErrorEnum.ERROR_102));
            }
            if (!numRucLogeado.equals(numRucEmisor)) {
                throw new UnprocessableEntityException(new ErrorMessage(ErrorEnum.ERROR_105));
            }
        } else{
            if(Constantes.COD_CPE_RECEPTOR.equals(codFiltroCpe)){

                if (numRucEmisor==null || StringUtils.isBlank(numRucEmisor) ) {
                    throw new UnprocessableEntityException(new ErrorMessage(ErrorEnum.ERROR_102));
                }
                if (numRucEmisor.equals(numRucLogeado)) {
                    throw new UnprocessableEntityException(new ErrorMessage(ErrorEnum.ERROR_104));
                }
            }
        }
        if (Constantes.NUM_RUC_SIZE != numRucEmisor.length()) {
            throw new UnprocessableEntityException(new ErrorMessage(ErrorEnum.ERROR_101));
        }

    }
    public void checkCodCpe(String codCpe) throws UnprocessableEntityException {
        if (StringUtils.isBlank(codCpe) || codCpe==null ){
            throw new UnprocessableEntityException(new ErrorMessage(ErrorEnum.ERROR_106));
        }

        if (!Arrays.asList(Constantes.COD_CPE_ALLOWED).contains(codCpe) ) {
            throw new UnprocessableEntityException(new ErrorMessage(ErrorEnum.ERROR_107));
        }
    }
    public void checkNumeroSerieCpe(String numeroSerieCpe,String codFiltroCpe) throws UnprocessableEntityException {
        boolean valido=false;
        if(Arrays.asList(Constantes.COD_CPE_ALLOWED).contains(codFiltroCpe)){
            if ( StringUtils.isBlank(numeroSerieCpe)) {
                throw new UnprocessableEntityException(new ErrorMessage(ErrorEnum.ERROR_108));
            }
        }
        for (String prefijo : Constantes.COD_NUM_SERIE_CPE_ALLOWED) {
            if(numeroSerieCpe.startsWith(prefijo) || numeroSerieCpe.matches(Constantes.NUM_SERIE_CPE_NUMERIC_REGEX)){
                valido=true;
            }
        }
        if(!valido || Constantes.NUM_SERIE_CEP_SIZE != numeroSerieCpe.length()){
            throw new UnprocessableEntityException(new ErrorMessage(ErrorEnum.ERROR_109));

        }



    }
    public void checkNumCpe(String numCpe,String numSerieCpe,String codFiltroCpe) throws UnprocessableEntityException {

   if(Arrays.asList(Constantes.COD_CPE_ALLOWED).contains(codFiltroCpe)){
       if (StringUtils.isBlank(numCpe) || StringUtils.isBlank(numSerieCpe)) {
           throw new UnprocessableEntityException(new ErrorMessage(ErrorEnum.ERROR_108));
       }
   }
        if (numCpe.length()>=Constantes.NUM_CPE_SIZE) {
            throw new UnprocessableEntityException(new ErrorMessage(ErrorEnum.ERROR_111));
        }


        if (!Arrays.asList(Constantes.COD_CPE_ALLOWED).contains(numCpe)) {
            throw new UnprocessableEntityException(new ErrorMessage(ErrorEnum.ERROR_107));
        }
    }
    public void checkCodFiltroCpe(String codFiltroCpe) throws UnprocessableEntityException {
        if (StringUtils.isBlank(codFiltroCpe)) {
            throw new UnprocessableEntityException(new ErrorMessage(ErrorEnum.ERROR_148));
        }

        if (!Arrays.asList(Constantes.COD_CPE_FILTRO).contains(codFiltroCpe)) {
            throw new UnprocessableEntityException(new ErrorMessage(ErrorEnum.ERROR_149));
        }
    }
    
    public void checkNumeroSerieCpeMasiva(String numeroSerieCpe,String codFiltroCpe, boolean granemisor) throws UnprocessableEntityException {
        boolean valido=false;
        if(granemisor) {
            if (codFiltroCpe.equals(Constantes.COD_CPE_EMISOR)) {
                if (StringUtils.isBlank(numeroSerieCpe)) {
                    throw new UnprocessableEntityException(new ErrorMessage(ErrorEnum.ERROR_115));
                }
            }
            for (String prefijo : Constantes.COD_NUM_SERIE_CPE_ALLOWED) {
                if (numeroSerieCpe.startsWith(prefijo)) {
                    valido = true;
                }
            }
            if (valido = false && Constantes.NUM_SERIE_CEP_SIZE != numeroSerieCpe.length()) {
                throw new UnprocessableEntityException(new ErrorMessage(ErrorEnum.ERROR_109));

            }
            if (codFiltroCpe.equals(Constantes.COD_CPE_RECEPTOR)) {
                if (!StringUtils.isBlank(numeroSerieCpe)) {
                    throw new UnprocessableEntityException(new ErrorMessage(ErrorEnum.ERROR_116));
                }
            }
        }
    }
    public void checkNumCpeIniMasiva(int numCpeIni,String codFiltroCpe, boolean granemisor) throws UnprocessableEntityException {

        if (granemisor) {
            if (codFiltroCpe.equals(Constantes.COD_CPE_EMISOR)) {
                if (StringUtils.isBlank(Integer.toString(numCpeIni))) {
                    throw new UnprocessableEntityException(new ErrorMessage(ErrorEnum.ERROR_117));
                }
            }

            if (Integer.toString(numCpeIni).length() >= Constantes.NUM_CPE_SIZE) {
                throw new UnprocessableEntityException(new ErrorMessage(ErrorEnum.ERROR_118));
            }
            if (codFiltroCpe.equals(Constantes.COD_CPE_RECEPTOR)) {
                if (numCpeIni != 0) {
                    throw new UnprocessableEntityException(new ErrorMessage(ErrorEnum.ERROR_114));
                }
            }


        }
    }

    public void checkNumCpeFinMasiva(int numCpeFin, int numCpeIni, String codFiltroCpe, boolean granemisor,int cntMaxima) throws UnprocessableEntityException {
 if(granemisor) {
            if (codFiltroCpe.equals(Constantes.COD_CPE_EMISOR)) {
                if (numCpeIni == 0) {
                    throw new UnprocessableEntityException(new ErrorMessage(ErrorEnum.ERROR_119));
                }
            }
            if (Integer.toString(numCpeFin).length() >= Constantes.NUM_CPE_SIZE) {
                throw new UnprocessableEntityException(new ErrorMessage(ErrorEnum.ERROR_120));
            }


            if (numCpeIni > numCpeFin && numCpeIni != 0) {
                throw new UnprocessableEntityException(new ErrorMessage(ErrorEnum.ERROR_123));
            }
            if (codFiltroCpe.equals(Constantes.COD_CPE_RECEPTOR)) {
                if (numCpeFin != 0) {
                    throw new UnprocessableEntityException(new ErrorMessage(ErrorEnum.ERROR_121));
                }
            }
     if (validarRangoCPE(numCpeIni, numCpeFin,cntMaxima)) {
                throw new UnprocessableEntityException(new ErrorMessage(ErrorEnum.ERROR_124));

            }
        }else{
     if(numCpeFin !=0){
         if (Integer.toString(numCpeFin).length() >= Constantes.NUM_CPE_SIZE) {
             throw new UnprocessableEntityException(new ErrorMessage(ErrorEnum.ERROR_120));
         }
         if(numCpeIni != 0){
             if (validarRangoCPE(numCpeIni, numCpeFin,cntMaxima) ){
                 throw new UnprocessableEntityException(new ErrorMessage(ErrorEnum.ERROR_124));

             }
         }
         if (numCpeIni > numCpeFin && numCpeIni != 0) {
             throw new UnprocessableEntityException(new ErrorMessage(ErrorEnum.ERROR_123));
         }
     }
 }
    }
    public static boolean validarRangoCPE(int cpeInicio, int cpeFin,int cntMaxima) {
        int diferencia = Math.abs(cpeFin - cpeInicio);
        return diferencia ==cntMaxima;
    }
    public void checkCodEstado(String codEstado) throws UnprocessableEntityException {
        if (StringUtils.isBlank(codEstado)) {
            throw new UnprocessableEntityException(new ErrorMessage(ErrorEnum.ERROR_127));
        }

        if (!Arrays.asList(Constantes.COD_CPE_ESTADO).contains(codEstado)) {
            throw new UnprocessableEntityException(new ErrorMessage(ErrorEnum.ERROR_128));
        }
    } 
    public void checkCodDocIdeRecep(String codDocIdeRecep) throws UnprocessableEntityException {
        if(Arrays.asList(Constantes.COD_CPE_ALLOWED).contains(codDocIdeRecep)) {
            if (StringUtils.isBlank(codDocIdeRecep)) {
                throw new UnprocessableEntityException(new ErrorMessage(ErrorEnum.ERROR_130));
            }
        }
//        if (!Arrays.asList(Constantes.COD_ID_RECEP).contains(codDocIdeRecep.replaceAll("0", ""))) {
//            throw new UnprocessableEntityException(new ErrorMessage(ErrorEnum.ERROR_131));
//        }
    } 
    public void checkNumDocIdeRecep(String numDocIdeRecep) throws UnprocessableEntityException {
        if(Arrays.asList(Constantes.COD_CPE_ALLOWED).contains(numDocIdeRecep)) {

            if (StringUtils.isBlank(numDocIdeRecep)) {
            throw new UnprocessableEntityException(new ErrorMessage(ErrorEnum.ERROR_133));
        }
        }

//        if (numDocIdeRecep.equals(Constantes.COD_DNI)) {
//            if (numDocIdeRecep.length()>=Constantes.NUM_CPE_SIZE) {
//                throw new UnprocessableEntityException(new ErrorMessage(ErrorEnum.ERROR_133));
//
//            }
//        }
//        if (numDocIdeRecep.equals(Constantes.COD_REGISTRO_UNICO)) {
//            if (numDocIdeRecep.length()>=Constantes.NUM_RUC_SIZE) {
//                throw new UnprocessableEntityException(new ErrorMessage(ErrorEnum.ERROR_134));
//
//            }
//        }
//        if (!numDocIdeRecep.equals(Constantes.COD_REGISTRO_UNICO) && !numDocIdeRecep.equals(Constantes.COD_DNI)) {
//            if (numDocIdeRecep.length()>=Constantes.NUM_OTRO_DOCUMENTO_SIZE) {
//                throw new UnprocessableEntityException(new ErrorMessage(ErrorEnum.ERROR_135));
//
//            }
//        }
    }
    
    public void checkCodTipDes(String codTipDes) throws UnprocessableEntityException {
        if(Arrays.asList(Constantes.COD_CPE_TIP_DES).contains(codTipDes)) {
            if (StringUtils.isBlank(codTipDes)) {
                throw new UnprocessableEntityException(new ErrorMessage(ErrorEnum.ERROR_130));
            }
        }
    }

    public void checkFechaEmision(String  fechaIni, String fechaFin,String codFiltro,
                                  boolean indGranEmisor,boolean indGranReceptor) throws UnprocessableEntityException {
        if(!indGranEmisor) {
            if (StringUtils.isBlank(fechaIni) && fechaIni ==null) {
                throw new UnprocessableEntityException(new ErrorMessage(ErrorEnum.ERROR_137));
            }
            if(fechaIni !=null){
                if(!validarFormatoFecha(fechaIni)){
                    throw new UnprocessableEntityException(new ErrorMessage(ErrorEnum.ERROR_138));

                }
            }
            if(fechaIni !=null && fechaFin==null) {
                throw new UnprocessableEntityException(new ErrorMessage(ErrorEnum.ERROR_230));

            }
            if(fechaFin!=null){
                if (!validarFormatoFecha(fechaFin)) {
                    throw new UnprocessableEntityException(new ErrorMessage(ErrorEnum.ERROR_141));
                }
            }

            if(fechaIni!=null && fechaFin!=null) {
                if(isDate1AfterDate2(fechaIni,fechaFin,Constantes.DATE_FORMAT)){
                    throw new UnprocessableEntityException(new ErrorMessage(ErrorEnum.ERROR_143));

                }
                if (!validarRangoFechas(fechaIni,fechaFin,30)){
                    throw new UnprocessableEntityException(new ErrorMessage(ErrorEnum.ERROR_142));

                }
                if(indGranReceptor){
                    if(codFiltro.contains(Constantes.COD_CPE_RECEPTOR)){
                        if (!validarRangoFechas(fechaIni,fechaFin,1)){
                            throw new UnprocessableEntityException(new ErrorMessage(ErrorEnum.ERROR_140));

                        }
                    }

                }
            }
        }
        if(indGranEmisor){
            if(codFiltro.contains(Constantes.COD_CPE_EMISOR)){
                if (!StringUtils.isBlank(fechaIni) && fechaIni !=null) {
                    throw new UnprocessableEntityException(new ErrorMessage(ErrorEnum.ERROR_144));
                }
            }
        }
    }

    public static boolean isDate1AfterDate2(String date1Str, String date2Str, String dateFormat) {
        SimpleDateFormat sdf = new SimpleDateFormat(dateFormat);

        try {
            Date date1 = sdf.parse(date1Str);
            Date date2 = sdf.parse(date2Str);

            return date1.after(date2);
        } catch (ParseException e) {
            return false;
        }
    }
    public static boolean validarFormatoFecha(String fechaEmision) {
        SimpleDateFormat dateFormat = new SimpleDateFormat(Constantes.DATE_FORMAT);
        dateFormat.setLenient(false);

        try {
            Date fecha = dateFormat.parse(fechaEmision);
            String fechaFormateada = dateFormat.format(fecha);
            return fechaEmision.equals(fechaFormateada);
        } catch (ParseException e) {
            return false;
        }
    }
    public static boolean validarRangoFechas(String fechaInicio, String fechaFin,long dias) {
        SimpleDateFormat dateFormat = new SimpleDateFormat(Constantes.DATE_FORMAT);
        dateFormat.setLenient(false);

        try {
            Date inicio = dateFormat.parse(fechaInicio);
            Date fin = dateFormat.parse(fechaFin);

            long diff = Math.abs(fin.getTime() - inicio.getTime());
            long diffDays = diff / (24 * 60 * 60 * 1000);

            return diffDays <= dias;
        } catch (ParseException e) {
            return false;
        }
    }
    public static boolean validarRangoFechasEmision(String fechaInicio, String fechaFin) {
        SimpleDateFormat dateFormat = new SimpleDateFormat(Constantes.DATE_FORMAT);
        dateFormat.setLenient(false);

        try {
            Date inicio = dateFormat.parse(fechaInicio);
            Date fin = dateFormat.parse(fechaFin);

            Calendar calInicio = Calendar.getInstance();
            calInicio.setTime(inicio);

            Calendar calFin = Calendar.getInstance();
            calFin.setTime(fin);

            calFin.add(Calendar.MONTH, -6);

            return calInicio.after(calFin);
        } catch (ParseException e) {
            return false;
        }
    }
    
    public void checkFechaEmisionIndividual(Date fechaEmision, int cantMesesIndv) throws UnprocessableEntityException {

        if (esFechaEmisionMayorMeses(fechaEmision,cantMesesIndv)) {
            throw new UnprocessableEntityException(new ErrorMessage(ErrorEnum.ERROR_112));
        }
    }

    public void checkFechaEmisionMasiva(String fechaEmision,int meses) throws UnprocessableEntityException, ParseException {

        SimpleDateFormat dateFormat = new SimpleDateFormat(Constantes.DATE_FORMAT);
        Date fecha = dateFormat.parse(fechaEmision);
        if (esFechaEmisionMayorMeses(fecha,meses)) {
            throw new UnprocessableEntityException(new ErrorMessage(ErrorEnum.ERROR_145));

        }
    }
    
    public static boolean esFechaEmisionMayorMeses(Date fechaEmision,int meses) {
        Calendar calendarEmision = Calendar.getInstance();
        calendarEmision.setTime(fechaEmision);
        Calendar calendarActual = Calendar.getInstance();
        calendarEmision.add(Calendar.MONTH, meses);

        return calendarActual.after(calendarEmision);
    }

    

}
