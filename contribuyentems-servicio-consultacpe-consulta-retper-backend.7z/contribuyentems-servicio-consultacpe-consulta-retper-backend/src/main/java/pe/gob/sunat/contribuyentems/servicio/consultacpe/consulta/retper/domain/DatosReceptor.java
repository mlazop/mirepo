package pe.gob.sunat.contribuyentems.servicio.consultacpe.consulta.retper.domain;

import java.io.Serializable;

import java.util.Date;

public class DatosReceptor implements Serializable {

	private static final long serialVersionUID = 1L;

	private String codDocIdeRecep;

	private String numDocIdeRecep;

	private String desRazonSocialRecep;

	public String getCodDocIdeRecep() {
		return codDocIdeRecep;
	}
	public void setCodDocIdeRecep(String codDocIdeRecep) {
		this.codDocIdeRecep = codDocIdeRecep;
	}
	public String getNumDocIdeRecep() {
		return numDocIdeRecep;
	}
	public void setNumDocIdeRecep(String numDocIdeRecep) {
		this.numDocIdeRecep = numDocIdeRecep;
	}
	public String getDesRazonSocialRecep() {
		return desRazonSocialRecep;
	}
	public void setDesRazonSocialRecep(String desRazonSocialRecep) {
		this.desRazonSocialRecep = desRazonSocialRecep;
	}




}
