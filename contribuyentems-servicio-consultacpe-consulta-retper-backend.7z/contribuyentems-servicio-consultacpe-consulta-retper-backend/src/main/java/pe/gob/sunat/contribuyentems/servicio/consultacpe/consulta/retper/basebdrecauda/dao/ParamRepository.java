package pe.gob.sunat.contribuyentems.servicio.consultacpe.consulta.retper.basebdrecauda.dao;

import pe.gob.sunat.contribuyentems.servicio.consultacpe.consulta.retper.basebdrecauda.Param;
import pe.gob.sunat.contribuyentems.servicio.consultacpe.consulta.retper.basebdrecauda.ParamPK;
import pe.gob.sunat.tecnologiams.arquitectura.framework.jpa.dao.BaseDao;


public interface ParamRepository extends BaseDao<Param, ParamPK> {


    public String obtenerParametros(String codcpe,String codReg);

}
