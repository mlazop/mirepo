package pe.gob.sunat.contribuyentems.servicio.consultacpe.consulta.facbolliq.basebdcpe.dao.jpa;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.Reader;
import java.sql.Clob;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import pe.gob.sunat.contribuyentems.servicio.consultacpe.consulta.facbolliq.basebdcpe.*;
import pe.gob.sunat.contribuyentems.servicio.consultacpe.consulta.facbolliq.basebdcpe.dao.ComprobanteXMLRepository;
import pe.gob.sunat.contribuyentems.servicio.consultacpe.consulta.facbolliq.util.Constantes;
import pe.gob.sunat.tecnologiams.arquitectura.framework.common.util.ConstantesUtils;
import pe.gob.sunat.tecnologiams.arquitectura.framework.core.util.UtilLog;
import pe.gob.sunat.tecnologiams.arquitectura.framework.jpa.dao.AbstractDao;

import javax.inject.Inject;
import javax.inject.Named;
import javax.persistence.EntityManager;
import javax.persistence.NoResultException;
import javax.persistence.Query;
import javax.sql.rowset.serial.SerialClob;

import org.springframework.jdbc.support.lob.LobHandler;

public class ComprobanteXMLRepositoryImpl extends AbstractDao<ComprobanteXML, ComprobanteXMLPK> implements ComprobanteXMLRepository {
    @Inject
    @Named(Constantes.DGCPE)
    private EntityManager entityManager;
    @Override
    public EntityManager buildEntityManager() {
        return entityManager;
    }
    @Inject
    private UtilLog utilLog;
    
    private LobHandler lobHandler;
    private static final String CONECTORAND = "' and ";
    


    @Override
    public Class<ComprobanteXML> provideEntityClass() {
        return ComprobanteXML.class;
    }
    public ComprobanteXML findComprobanteXmlService(String numRuc, String numCpe, String codCpe, String numSerieCpe) {
    	Map<Integer, Object> parameters = new HashMap<>();
        StringBuilder sb = new StringBuilder("select num_ruc, cod_cpe, num_serie_cpe, num_cpe, num_id_xml, arc_xml, ind_procedencia, des_nombre, cod_usumodif  "+
        "from t4243xmlcpe a "+
        "where a.num_ruc = ? "+
        "and a.cod_cpe = ? "+
        "and a.num_serie_cpe = ? "+
        "and a.num_cpe = ? ");
        parameters.put(1, numRuc);
        parameters.put(2, codCpe);
        parameters.put(3, numSerieCpe);
        parameters.put(4, numCpe);
        List<ComprobanteXML> lista= new ArrayList<>();
        try {
            Query query = entityManager.createNativeQuery(sb.toString());
            // agregamos los parametros a la consulta
            for (Map.Entry<Integer, Object> entry : parameters.entrySet()) {
                query.setParameter(entry.getKey(), entry.getValue());
            }
            List<Object[]> rows  = query.getResultList();
            if(rows.isEmpty()){
            	return null;
            }
            for (Object[] row : rows) {
            	ComprobanteXML comprobanteXML=new ComprobanteXML();
            	ComprobanteXMLPK comprobanteXMLPK =new ComprobanteXMLPK();
            	comprobanteXMLPK.setNumRuc(row[0].toString());
            	comprobanteXMLPK.setCodCpe(row[1].toString());
            	comprobanteXMLPK.setMumSerieCpe(row[2].toString());
            	comprobanteXMLPK.setNumCpe((Integer) row[3]);
            	comprobanteXML.setComprobanteXMLPK(comprobanteXMLPK);
            	comprobanteXML.setNumIdXml((Integer) row[4]);
            	String arcXml=clobToString((String) row[5]);
            	comprobanteXML.setArcXml(arcXml);
            	comprobanteXML.setIndProcedencia(row[6].toString());
            	comprobanteXML.setDesNombre(row[7].toString());
            	comprobanteXML.setCodUsumodif(row[7].toString());
                lista.add(comprobanteXML);
            }
            
        } catch ( NoResultException nre) {
        	nre.printStackTrace();
            utilLog.imprimirLog(ConstantesUtils.LEVEL_ERROR, nre.getMessage());
        } catch (Exception e) {
        	e.printStackTrace();
            utilLog.imprimirLog(ConstantesUtils.LEVEL_ERROR, e.getMessage());
        }
        return lista.get(0);
    }
    
    public int findComprobanteXmlServiceVerificar(String numRuc, String numCpe, String codCpe, String numSerieCpe) {
    	
    	Map<Integer, Object> parameters = new HashMap<>();
        StringBuilder sb = new StringBuilder("select cast(count(num_ruc) as int) as cantidad "+
        "from t4243xmlcpe a "+
        "where a.num_ruc = ? "+
        "and a.cod_cpe = ? "+
        "and a.num_serie_cpe = ? "+
        "and a.num_cpe = ? ");
        
        parameters.put(1, numRuc);
        parameters.put(2, codCpe);
        parameters.put(3, numSerieCpe);
        parameters.put(4, numCpe);
        
        int cantidad = 0;
        try {
            Query query = entityManager.createNativeQuery(sb.toString());
            
            // agregamos los parametros a la consulta
            for (Map.Entry<Integer, Object> entry : parameters.entrySet()) {
                query.setParameter(entry.getKey(), entry.getValue());
            }
            
            List<Integer> rows  = query.getResultList();
            for (Integer row : rows) {
                int intValue = row; //
                cantidad=intValue;
            }
        } catch ( NoResultException nre) {
            utilLog.imprimirLog(ConstantesUtils.LEVEL_ERROR, nre.getMessage());
            cantidad = 0;
        } catch (Exception e) {
            utilLog.imprimirLog(ConstantesUtils.LEVEL_ERROR, e.getMessage());
            cantidad = 0;
        }
        return cantidad;
    }
    
    public String clobToString(String mensaje) {
    	StringBuilder sb = new StringBuilder();
        try {
        	char[] charArray = mensaje.toCharArray();
        	Clob clob = new SerialClob(charArray);
            Reader reader = clob.getCharacterStream();
            BufferedReader br = new BufferedReader(reader);
            String line;
            while ((line = br.readLine()) != null) {
                sb.append(line);
            }
            br.close();
        } catch (SQLException | IOException e) {
            e.printStackTrace();
        }
        return sb.toString();
    }


}
