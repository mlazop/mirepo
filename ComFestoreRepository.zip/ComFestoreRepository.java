package pe.gob.sunat.contribuyentems.servicio.consultacpe.consulta.facbolliq.basebdcpe.dao.jpa;

import pe.gob.sunat.contribuyentems.servicio.consultacpe.consulta.facbolliq.basebdcpe.ComprobanteFestore;
import pe.gob.sunat.contribuyentems.servicio.consultacpe.consulta.facbolliq.basebdcpe.ComprobanteFestorePK;
import pe.gob.sunat.contribuyentems.servicio.consultacpe.consulta.facbolliq.basebdcpe.dao.CompFestoreRepository;
import pe.gob.sunat.contribuyentems.servicio.consultacpe.consulta.facbolliq.util.Constantes;
import pe.gob.sunat.tecnologiams.arquitectura.framework.common.util.ConstantesUtils;
import pe.gob.sunat.tecnologiams.arquitectura.framework.core.util.UtilLog;
import pe.gob.sunat.tecnologiams.arquitectura.framework.jpa.dao.AbstractDao;

import java.util.HashMap;
import java.util.Map;

import javax.inject.Inject;
import javax.inject.Named;
import javax.persistence.EntityManager;
import javax.persistence.NoResultException;
import javax.persistence.Query;

public class CompFestoreRepositoryImpl extends AbstractDao<ComprobanteFestore, ComprobanteFestorePK> implements CompFestoreRepository {
    @Inject
    @Named(Constantes.DGCPE)
    private EntityManager entityManager;
    @Override
    public EntityManager buildEntityManager() {
        return entityManager;
    }
    @Inject
    private UtilLog utilLog;
    private static final String CONECTORAND = "' and ";

    @Override
    public Class<ComprobanteFestore> provideEntityClass() {
        return ComprobanteFestore.class;
    }
    @Override
    public ComprobanteFestore   findComprobanteCDRService(String numRuc, String numCpe, String codCpe, String numSerieCpe) {
    	
    	Map<Integer, Object> parameters = new HashMap<>();
    	
        StringBuilder sb = new StringBuilder("select t.num_ticket, t.num_correl,t.ind_modo, t.arc_input, t.cod_usumodif,t.fec_modif  "+ 
        "from t4534relcompelec a " +
        "join t4536festore t on t.num_ticket=a.num_ticket "+
        "where a.num_ruc = ? "+ 
        "and a.cod_cpe = ? "+ 
        "and a.num_serie_cpe = ? "+
        "and a.num_cpe = ? "+
        "and t.ind_modo = ?");
        
        parameters.put(1, numRuc);
        parameters.put(2, codCpe);
        parameters.put(3, numSerieCpe);
        parameters.put(4, numCpe);
        parameters.put(5, "0");
        
        ComprobanteFestore element = null;

        try {
            Query query = entityManager.createNativeQuery(sb.toString(), ComprobanteFestore.class);
            
            // agregamos los parametros a la consulta
            for (Map.Entry<Integer, Object> entry : parameters.entrySet()) {
                query.setParameter(entry.getKey(), entry.getValue());
            }
            
            element= (ComprobanteFestore) query.getSingleResult();
        } catch ( NoResultException nre) {
            utilLog.imprimirLog(ConstantesUtils.LEVEL_ERROR, nre.getMessage());
            element = null;
        } catch (Exception e) {
            utilLog.imprimirLog(ConstantesUtils.LEVEL_ERROR, e.getMessage());
            element = null;
        }
        return element;
    }
    public ComprobanteFestore findComprobanteCDRResumenService(String numRuc, String numCpe, String codCpe, String numSerieCpe) {

    	Map<Integer, Object> parameters = new HashMap<>();
    	StringBuilder sb = new StringBuilder("select t.num_ticket, t.num_correl,t.ind_modo, t.arc_input, t.cod_usumodif,t.fec_modif  "+
        "from t4704detresbol a "+
        "join t4536festore t on t.num_ticket=a.num_ticket "+
        "where a.num_ruc = ? "+
        "and a.cod_cpe = ? "+ 
        "and a.num_serie_cpe = ? "+
        "and a.num_desde = ? "+
        "and t.ind_modo = ? ");
        
    	parameters.put(1, numRuc);
        parameters.put(2, codCpe);
        parameters.put(3, numSerieCpe);
        parameters.put(4, numCpe);
        parameters.put(5, "0");
        
        ComprobanteFestore element = null;

        try {
            Query query = entityManager.createNativeQuery(sb.toString(), ComprobanteFestore.class);
            
            // agregamos los parametros a la consulta
            for (Map.Entry<Integer, Object> entry : parameters.entrySet()) {
                query.setParameter(entry.getKey(), entry.getValue());
            }
            
            element= (ComprobanteFestore) query.getSingleResult();
        } catch ( NoResultException nre) {
            utilLog.imprimirLog(ConstantesUtils.LEVEL_ERROR, nre.getMessage());
            element = null;
        } catch (Exception e) {
            utilLog.imprimirLog(ConstantesUtils.LEVEL_ERROR, e.getMessage());
            element = null;
        }
        return element;
    }
    @Override
    public ComprobanteFestore findComprobanteXmlService(String numRuc, String numCpe, String codCpe, String numSerieCpe) {
    	
    	Map<Integer, Object> parameters = new HashMap<>();
        StringBuilder sb = new StringBuilder("select t.num_ticket, t.num_correl,t.ind_modo, t.arc_input, t.cod_usumodif,t.fec_modif  "+
        "from t4534relcompelec a "+
        "join t4536festore t on t.num_ticket=a.num_ticket "+
        "where a.num_ruc = ? "+
        "and a.cod_cpe = ? "+
        "and a.num_serie_cpe = ? "+
        "and a.num_cpe = ? "+
        "and t.ind_modo = ? ");
        
        parameters.put(1, numRuc);
        parameters.put(2, codCpe);
        parameters.put(3, numSerieCpe);
        parameters.put(4, numCpe);
        parameters.put(5, "1");
        ComprobanteFestore element = null;
        
        try {
            Query query = entityManager.createNativeQuery(sb.toString(), ComprobanteFestore.class);
            
            // agregamos los parametros a la consulta
            for (Map.Entry<Integer, Object> entry : parameters.entrySet()) {
                query.setParameter(entry.getKey(), entry.getValue());
            }
            
            element= (ComprobanteFestore) query.getSingleResult();
        } catch ( NoResultException nre) {
            utilLog.imprimirLog(ConstantesUtils.LEVEL_ERROR, nre.getMessage());
            element = null;
        } catch (Exception e) {
            utilLog.imprimirLog(ConstantesUtils.LEVEL_ERROR, e.getMessage());
            element = null;
        }
        return element;
    }

    public ComprobanteFestore findComprobanteXmlResumenService(String numRuc, String numCpe, String codCpe, String numSerieCpe) {
    	
    	Map<Integer, Object> parameters = new HashMap<>();
        StringBuilder sb = new StringBuilder("select t.num_ticket, t.num_correl,t.ind_modo, t.arc_input, t.cod_usumodif,t.fec_modif  "+
        "from t4704detresbol a "+
        "join t4536festore t on t.num_ticket=a.num_ticket "+
        "where a.num_ruc = ? "+
        "and a.cod_cpe = ? "+ 
        "and a.num_serie_cpe = ? "+
        "and a.num_desde = ? "+
        "and t.ind_modo = ? ");
        
        parameters.put(1, numRuc);
        parameters.put(2, codCpe);
        parameters.put(3, numSerieCpe);
        parameters.put(4, numCpe);
        parameters.put(5, "1");
        ComprobanteFestore element = null;

        try {
            Query query = entityManager.createNativeQuery(sb.toString(), ComprobanteFestore.class);
            
            // agregamos los parametros a la consulta
            for (Map.Entry<Integer, Object> entry : parameters.entrySet()) {
                query.setParameter(entry.getKey(), entry.getValue());
            }
            
            element= (ComprobanteFestore) query.getSingleResult();
        } catch ( NoResultException nre) {
            utilLog.imprimirLog(ConstantesUtils.LEVEL_ERROR, nre.getMessage());
            element = null;
        } catch (Exception e) {
            utilLog.imprimirLog(ConstantesUtils.LEVEL_ERROR, e.getMessage());
            element = null;
        }
        return element;
    }
}
